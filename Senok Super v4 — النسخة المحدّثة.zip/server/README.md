# مواصفات خادم سرد — البند 45 (اختياري)

هذا الملف هو عقد تكامل مرجعي للخادم، وليس خادماً جاهزاً للنشر. يجب أن يكون كل المسارات تحت `API_BASE_URL` وأن تستخدم HTTPS في الإنتاج.

## المصادقة والحساب
- `POST /auth/register` — `{name,email,password}` → `{token,user}`.
- `POST /auth/login` — `{email,password}` → `{token,user}`.
- `POST /auth/forgot-password` — `{email}`؛ أعد رسالة عامة لا تكشف وجود البريد.
- `POST /auth/google` — `{id_token}`؛ تحقّق من الرمز على الخادم باستخدام Google OAuth، ولا تثق برمز يرسله العميل دون تحقق.
- `GET /users/me` و`POST /users/me` — الملف الشخصي؛ يتطلبان Bearer token.

## المكتبة والتقدم
- `GET /library` → `{followed:[],lists:[],history:[]}`.
- `POST /library/sync` — `{followed_series:[],read_chapters:{},progress:{},local_flags:[]}`.
- `POST /library/lists` — `{name,is_public}`.
- `POST /library/lists/:listId/items` — `{series_id}`.

## الفهرس والقارئ
- `GET /home` → `{featured:[],suggestions:[],latest:[],popular:[]}`.
- `GET /search?q=&type=&sort=&genres=&status=&year=&exclude=` → قائمة أعمال أو `{items:[]}`.
- `GET /catalog/:section?page=&limit=` و`GET /genres/:genre?page=&limit=`.
- `GET /series/:id/chapters`، ثم `GET /series/:id/chapters/:number/pages`.
- `GET /series/:id/related?limit=`.
- `POST /series/:id/rating` — `{rating}` عدد صحيح من 1 إلى 10.

## المجتمع
- `GET /series/:id/comments`.
- `POST /series/:id/comments` — `{text,parent_id}`.
- `POST /series/:id/comments/:commentId/like`.
- `GET /news` و`GET /news/:id`.
- `GET /notifications?series_ids=id1,id2`.

## القراءة المشتركة
- `POST /read-rooms` — `{series_id,series_title,chapter,friend_id}` → `{id,chat_id,...,friend:{id,name,badge,online,position:{chapter,page,total}}}`؛ أنشئ محادثة للغرفة وأعد معرّفها في `chat_id`.
- `GET /read-rooms/:id` — حالة الغرفة وموضع الصديق (للأعضاء فقط).
- `POST /read-rooms/:id/position` — `{chapter,page,total}`.
- `POST /read-rooms/:id/leave`.
- الدردشة عبر `GET/POST /chats/:chat_id/messages` الموجودة.

## متطلبات إنتاج إلزامية
1. استخدم قاعدة بيانات فعلية مع migrations ونسخ احتياطية؛ لا تخزّن كلمات المرور كنص صريح، بل استخدم Argon2id أو bcrypt بإعداد قوي.
2. طبّق صلاحيات ملكية المستخدم على المكتبة والقوائم والتقدم والتقييمات والتعليقات.
3. تحقق من Google ID token على الخادم، واستخدم جلسات قصيرة العمر أو access/refresh tokens قابلة للإبطال.
4. أضف rate limiting، والتحقق من المدخلات، وحدود حجم الطلب، وCORS مضبوطاً، وسجلات لا تتضمن كلمات مرور أو رموز جلسات.
5. لا تضع مفاتيح خاصة أو أسرار قاعدة البيانات في تطبيق Flutter أو `build_config.json`؛ الأسرار في متغيرات بيئة الخادم فقط.
6. أعد JSON متسقاً ورموز HTTP مناسبة؛ يترجم التطبيق أخطاء الاتصال الشائعة إلى رسائل عربية.

لا يُنصح بنشر خادم تجريبي أو in-memory على أنه إنتاجي. يلزم تحديد مزود الاستضافة وقاعدة البيانات ومزود البريد قبل إنشاء تنفيذ فعلي.
