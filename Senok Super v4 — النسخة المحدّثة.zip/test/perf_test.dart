// اختبارات وحدة لمنطق الأداء والأوفلاين v2 في Senok.
// تغطي: محرك التنزيل v2، المزامنة وحل التعارضات، النسخ الاحتياطي،
// التخزين، التذكيرات، وخط الصور — كلها منطق محلي قابل للاختبار دون شبكة.
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/perf/backup_restore.dart';
import 'package:senok_app/core/perf/download_engine_v2.dart';
import 'package:senok_app/core/perf/image_pipeline.dart';
import 'package:senok_app/core/perf/reading_reminders.dart';
import 'package:senok_app/core/perf/storage_manager.dart';
import 'package:senok_app/core/perf/sync_engine.dart';
import 'package:senok_app/core/storage/settings.dart';

Future<SharedPreferences> _prefs([Map<String, Object> values = const {}]) async {
  SharedPreferences.setMockInitialValues(values);
  return SharedPreferences.getInstance();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // ═════════════════════════════════════════════════════════════════════
  //  تنسيق الأحجام
  // ═════════════════════════════════════════════════════════════════════
  group('formatBytesAr', () {
    test('بايتات صغيرة', () {
      expect(formatBytesAr(0), '0 ب');
      expect(formatBytesAr(512), '512 ب');
      expect(formatBytesAr(1023), '1023 ب');
    });

    test('كيلوبايت وميغابايت وغيغابايت', () {
      expect(formatBytesAr(2048), '2 ك.ب');
      expect(formatBytesAr(1536), '1.5 ك.ب');
      expect(formatBytesAr(5 * 1024 * 1024), '5 م.ب');
      expect(formatBytesAr((1536 * 1024 * 1024).round()), '1.5 غ.ب');
    });

    test('السرعة', () {
      expect(formatSpeedAr(0), '0 ب/ث');
      expect(formatSpeedAr(2048), '2 ك.ب/ث');
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  مهمة التنزيل v2
  // ═════════════════════════════════════════════════════════════════════
  group('V2DownloadJob', () {
    V2DownloadJob job({int completed = 4, V2DownloadState state = V2DownloadState.downloading}) {
      return V2DownloadJob(
        id: 's1_12_1',
        seriesId: 's1',
        seriesTitle: 'عمل تجريبي',
        chapter: 12,
        pageUrls: List<String>.generate(10, (i) => 'https://example.com/p$i.jpg'),
        completedPages: completed,
        state: state,
        priority: V2DownloadPriority.high,
        bytesDownloaded: 400 * 1024,
        totalBytes: 1000 * 1024,
        createdAt: DateTime(2026, 11, 26),
      );
    }

    test('التقدّم والنسبة', () {
      final j = job();
      expect(j.totalPages, 10);
      expect(j.remainingPages, 6);
      expect(j.progress, 0.4);
      expect(j.percent, 40);
      expect(j.canPause, isTrue);
      expect(j.displayTitle, 'عمل تجريبي — الفصل 12');
    });

    test('JSON ذهاباً وإياباً', () {
      final j = job();
      final back = V2DownloadJob.fromJson(j.toJson());
      expect(back.id, j.id);
      expect(back.seriesId, 's1');
      expect(back.chapter, 12);
      expect(back.completedPages, 4);
      expect(back.state, V2DownloadState.downloading);
      expect(back.priority, V2DownloadPriority.high);
      expect(back.pageUrls.length, 10);
    });

    test('الحالات', () {
      expect(V2DownloadState.completed.isFinished, isTrue);
      expect(V2DownloadState.cancelled.isFinished, isTrue);
      expect(V2DownloadState.paused.canResume, isTrue);
      expect(V2DownloadState.failed.canResume, isTrue);
      expect(V2DownloadState.downloading.canResume, isFalse);
      expect(V2DownloadState.queued.isWaiting, isTrue);
    });

    test('ترتيب الطابور: الأولوية ثم الأقدم', () {
      final urgent = job().copyWith(priority: V2DownloadPriority.urgent);
      final low = job().copyWith(priority: V2DownloadPriority.low);
      final list = <V2DownloadJob>[low, urgent]..sort(V2DownloadEngine.compareQueue);
      expect(list.first.priority, V2DownloadPriority.urgent);
    });

    test('إحصاءات من المهام', () {
      final jobs = <V2DownloadJob>[
        job(state: V2DownloadState.downloading),
        job(state: V2DownloadState.queued),
        job(state: V2DownloadState.completed),
        job(state: V2DownloadState.failed),
      ];
      final stats = V2DownloadStats.fromJobs(jobs);
      expect(stats.active, 1);
      expect(stats.queued, 1);
      expect(stats.completed, 1);
      expect(stats.failed, 1);
      expect(stats.totalJobs, 4);
      expect(stats.hasActive, isTrue);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  محرك التنزيل v2
  // ═════════════════════════════════════════════════════════════════════
  group('V2DownloadEngine', () {
    test('إضافة وإيقاف واستئناف', () async {
      await _prefs();
      final engine = V2DownloadEngine.testInstance();
      final job = await engine.enqueue(
        seriesId: 's1',
        seriesTitle: 'عمل',
        chapter: 3,
        pages: const [PageSrc('https://example.com/1.jpg'), PageSrc('https://example.com/2.jpg')],
        priority: V2DownloadPriority.high,
      );
      expect(engine.jobs.length, 1);
      expect(job.state, V2DownloadState.queued);
      expect(engine.jobForChapter('s1', 3), isNotNull);
      expect(engine.isDownloaded('s1', 3), isFalse);

      await engine.pause(job.id);
      expect(engine.job(job.id)?.state, V2DownloadState.paused);

      await engine.resume(job.id);
      expect(engine.job(job.id)?.state, V2DownloadState.queued);

      await engine.remove(job.id);
      expect(engine.jobs, isEmpty);
    });

    test('صفحات فارغة ترفض', () async {
      await _prefs();
      final engine = V2DownloadEngine.testInstance();
      expect(
        () => engine.enqueue(seriesId: 's1', seriesTitle: 'عمل', chapter: 1, pages: const []),
        throwsA(isA<V2DownloadException>()),
      );
    });

    test('إعادة إضافة المكتمل تعيد نفس المهمة', () async {
      await _prefs();
      final engine = V2DownloadEngine.testInstance();
      final pages = const [PageSrc('https://example.com/1.jpg')];
      final first = await engine.enqueue(seriesId: 's1', seriesTitle: 'عمل', chapter: 1, pages: pages);
      final second = await engine.enqueue(seriesId: 's1', seriesTitle: 'عمل', chapter: 1, pages: pages);
      expect(second.id, first.id);
      expect(engine.jobs.length, 1);
    });

    test('الإعدادات تُحفظ وتُستعاد', () async {
      await _prefs();
      final engine = V2DownloadEngine.testInstance();
      await engine.setPolicy(V2NetworkPolicy.wifiOrMobile);
      await engine.setMaxConcurrent(4);
      await engine.setCellularLimitMB(500);
      expect(engine.policy, V2NetworkPolicy.wifiOrMobile);
      expect(engine.maxConcurrent, 4);
      expect(engine.cellularLimitBytes, 500 * 1024 * 1024);
      expect(engine.cellularLimitReached, isFalse);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  المزامنة
  // ═════════════════════════════════════════════════════════════════════
  group('SyncRecord', () {
    SyncRecord rec({int chapter = 3, int page = 10, int seconds = 100, DateTime? at}) {
      return SyncRecord(
        seriesId: 's1',
        chapter: chapter,
        page: page,
        total: 100,
        seconds: seconds,
        updatedAt: at ?? DateTime(2026, 11, 26, 10),
      );
    }

    test('الدمج: الفصل الأبعد يفوز', () {
      final merged = rec(chapter: 3, page: 90).mergeWith(rec(chapter: 5, page: 2));
      expect(merged.chapter, 5);
      expect(merged.page, 2);
    });

    test('الدمج: نفس الفصل فالصفحة الأبعد', () {
      final merged = rec(chapter: 3, page: 10).mergeWith(rec(chapter: 3, page: 40));
      expect(merged.chapter, 3);
      expect(merged.page, 40);
    });

    test('الدمج: الثواني بالأعلى لا بالجمع', () {
      final merged = rec(seconds: 100).mergeWith(rec(seconds: 250));
      expect(merged.seconds, 250);
    });

    test('JSON ذهاباً وإياباً', () {
      final back = SyncRecord.fromJson(rec().toJson());
      expect(back.seriesId, 's1');
      expect(back.chapter, 3);
      expect(back.fraction, closeTo(0.09, 0.01));
    });

    test('كشف التعارض: تغيّر الطرفان معاً', () {
      final lastSync = DateTime(2026, 11, 26, 9);
      final conflict = detectSyncConflict(
        local: rec(chapter: 4, at: DateTime(2026, 11, 26, 10)),
        server: rec(chapter: 2, at: DateTime(2026, 11, 26, 11)),
        seriesTitle: 'عمل',
        lastSyncAt: lastSync,
      );
      expect(conflict, isNotNull);
      expect(conflict!.field, SyncField.chapter);
      expect(conflict.describe, contains('الفصل'));
    });

    test('لا تعارض إن تغيّر طرف واحد فقط', () {
      final lastSync = DateTime(2026, 11, 26, 9);
      final conflict = detectSyncConflict(
        local: rec(chapter: 4, at: DateTime(2026, 11, 26, 8)),
        server: rec(chapter: 2, at: DateTime(2026, 11, 26, 11)),
        seriesTitle: 'عمل',
        lastSyncAt: lastSync,
      );
      expect(conflict, isNull);
    });

    test('لا تعارض عند تطابق القيم', () {
      final conflict = detectSyncConflict(
        local: rec(),
        server: rec(),
        seriesTitle: 'عمل',
        lastSyncAt: DateTime(2026, 11, 26, 9),
      );
      expect(conflict, isNull);
    });

    test('دمج الخرائط', () {
      final merged = mergeRecordMaps(
        {'s1': rec(chapter: 2)},
        {'s1': rec(chapter: 4), 's2': rec(chapter: 1)},
      );
      expect(merged['s1']!.chapter, 4);
      expect(merged['s2']!.chapter, 1);
    });
  });

  group('SyncEngine', () {
    test('تسجيل محلي وطابور رفع', () async {
      await _prefs();
      final engine = SyncEngine.testInstance();
      await engine.recordLocalProgress(seriesId: 's1', chapter: 2, page: 5, total: 50, seconds: 60);
      expect(engine.recordOf('s1')?.chapter, 2);
      expect(engine.pendingUploadCount, 1);
    });

    test('مزامنة بلا ناقل تعيد تقرير خطأ ولا تحذف الطابور', () async {
      await _prefs();
      final engine = SyncEngine.testInstance();
      await engine.recordLocalProgress(seriesId: 's1', chapter: 2, page: 5, total: 50, seconds: 60);
      final report = await engine.syncNow();
      expect(report.success, isFalse);
      expect(engine.pendingUploadCount, 1);
    });

    test('مزامنة بناقل وهمي ترفع وتمسح الطابور', () async {
      await _prefs();
      final engine = SyncEngine.testInstance();
      await engine.recordLocalProgress(seriesId: 's1', chapter: 2, page: 5, total: 50, seconds: 60);
      var transportCalled = false;
      final report = await engine.syncNow(
        transport: (upload) async {
          transportCalled = true;
          expect(upload.length, 1);
          return const <Map<String, dynamic>>[];
        },
      );
      expect(transportCalled, isTrue);
      expect(report.success, isTrue);
      expect(report.uploaded, 1);
      expect(engine.pendingUploadCount, 0);
    });

    test('تعارض حقيقي يُفتح ثم يُحلّ بنسخة الخادم', () async {
      await _prefs();
      final engine = SyncEngine.testInstance();
      await engine.recordLocalProgress(seriesId: 's1', chapter: 2, page: 5, total: 50, seconds: 60);
      await engine.syncNow(transport: (upload) async => const <Map<String, dynamic>>[]);
      // تقدّم محلي جديد بعد المزامنة (بطابع زمني صريح بعدها).
      await engine.recordLocalProgress(
        seriesId: 's1', chapter: 4, page: 10, total: 50, seconds: 120,
        at: DateTime.now().add(const Duration(seconds: 5)),
      );
      // وتقدّم مختلف على الخادم بعد المزامنة أيضاً.
      final server = SyncRecord(
        seriesId: 's1',
        chapter: 3,
        page: 20,
        total: 50,
        seconds: 90,
        updatedAt: DateTime.now().add(const Duration(seconds: 10)),
        deviceId: 'other_device',
      );
      final created = await engine.applyServerRecords([server], titlesById: const {'s1': 'عمل'});
      expect(created.length, 1);
      expect(engine.pendingConflictCount, 1);
      final solved = await engine.resolveConflict(created.first.id, SyncResolution.keepServer);
      expect(solved?.chapter, 3);
      expect(engine.pendingConflictCount, 0);
    });

    test('دمج تلقائي عند اختلاف طرف واحد', () async {
      await _prefs();
      final engine = SyncEngine.testInstance();
      await engine.recordLocalProgress(seriesId: 's1', chapter: 2, page: 5, total: 50, seconds: 60);
      await engine.syncNow(transport: (upload) async => const <Map<String, dynamic>>[]);
      // الخادم وحده تقدّم (المحلي لم يتغيّر بعد المزامنة).
      final server = SyncRecord(
        seriesId: 's1',
        chapter: 5,
        page: 1,
        total: 50,
        seconds: 200,
        updatedAt: DateTime.now(),
        deviceId: 'other_device',
      );
      final created = await engine.applyServerRecords([server]);
      expect(created, isEmpty);
      expect(engine.recordOf('s1')?.chapter, 5);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  النسخ الاحتياطي
  // ═════════════════════════════════════════════════════════════════════
  group('BackupCodec', () {
    test('البصمة مستقرة وتكشف التغيير', () {
      const payload = '{"a":1}';
      final sum = BackupCodec.checksumOf(payload);
      expect(BackupCodec.checksumOf(payload), sum);
      expect(BackupCodec.checksumOf('{"a":2}'), isNot(sum));
      expect(BackupCodec.verifyChecksum({'a': 1}, sum), isTrue);
    });

    test('التمويه ذهاباً وإياباً وعبارة خاطئة تفشل', () {
      const text = '{"secret":"value"}';
      final encoded = BackupCodec.obfuscate(text, 'mypass');
      expect(BackupCodec.deobfuscate(encoded, 'mypass'), text);
      expect(BackupCodec.deobfuscate(encoded, 'wrong'), isNot(text));
    });

    test('حزمة كاملة: ترميز وفك بلا عبارة', () {
      final package = BackupCodec.build(
        data: {'library': {'followed_series': ['s1']}},
        sections: const [BackupSection.library],
      );
      final encoded = package.encode();
      expect(encoded.startsWith('SENOKBK1.'), isTrue);
      final back = BackupPackage.decode(encoded);
      expect(back, isNotNull);
      expect(back!.manifest.sections, [BackupSection.library]);
    });

    test('حزمة مقفلة: بلا عبارة تفشل، وبالعبارة تنجح', () {
      final package = BackupCodec.build(
        data: {'library': {'a': 1}},
        sections: const [BackupSection.library],
      );
      final encoded = package.encode(passphrase: 'secret');
      expect(encoded.startsWith('SENOKBK1L.'), isTrue);
      expect(BackupPackage.decode(encoded), isNull);
      expect(BackupPackage.decode(encoded, passphrase: 'wrong'), isNull);
      expect(BackupPackage.decode(encoded, passphrase: 'secret'), isNotNull);
    });

    test('التحقق: فارغ ومقفلة وصالحة', () {
      final store = BackupStore.testInstance();
      expect(store.validate('').isValid, isFalse);
      final package = BackupCodec.build(data: {'a': 1}, sections: const [BackupSection.settings]);
      final locked = package.encode(passphrase: 'x');
      final v1 = store.validate(locked);
      expect(v1.isValid, isFalse);
      expect(v1.needsPassphrase, isTrue);
      final v2 = store.validate(package.encode());
      expect(v2.isValid, isTrue);
      expect(v2.describe, contains('صالحة'));
    });
  });

  group('BackupStore', () {
    test('تصدير ثم استيراد يعيد البيانات', () async {
      final prefs = await _prefs({'followed_series': ['s1', 's2'], 'theme': 'paper'});
      expect(prefs.getStringList('followed_series'), ['s1', 's2']);
      final store = BackupStore.testInstance();
      await store.load();
      final package = await store.exportBackup();
      final encoded = package.encode();
      // امسح البيانات ثم استعدها.
      await prefs.remove('followed_series');
      await prefs.setString('theme', 'obsidian');
      final result = await store.importBackup(encoded);
      expect(result.success, isTrue);
      expect(result.applied, contains(BackupSection.library));
      expect(prefs.getStringList('followed_series'), ['s1', 's2']);
      expect(prefs.getString('theme'), 'paper');
    });

    test('نسخة تجريبية صالحة', () {
      final package = BackupStore.demoPackage();
      expect(BackupPackage.decode(package.encode()), isNotNull);
      final contents = BackupStore.estimateContents(package);
      expect(contents['chapters'], 3);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  التخزين
  // ═════════════════════════════════════════════════════════════════════
  group('StorageManager (منطق خالص)', () {
    test('مستويات الامتلاء', () {
      expect(StorageTier.fromFraction(0.1), StorageTier.healthy);
      expect(StorageTier.fromFraction(0.8), StorageTier.warning);
      expect(StorageTier.fromFraction(0.95), StorageTier.critical);
    });

    test('الحدود JSON ذهاباً وإياباً', () {
      const limits = StorageLimits(downloadLimitMB: 1024, cacheLimitMB: 256, keepDownloadsDays: 30);
      final back = StorageLimits.fromJson(limits.toJson());
      expect(back.downloadLimitMB, 1024);
      expect(back.cacheLimitMB, 256);
      expect(back.keepDownloadsDays, 30);
      expect(back.downloadLimitBytes, 1024 * 1024 * 1024);
    });

    test('تسمية الاستخدام', () {
      expect(storageUsageLabel(2048, 0), '2 ك.ب');
      expect(storageUsageLabel(2048, 4096), '2 ك.ب من 4 ك.ب');
    });

    test('لقطة الاستخدام: كسور وحدود', () {
      final usage = StorageUsage(
        downloadsBytes: 800 * 1024 * 1024,
        imageCacheBytes: 100 * 1024 * 1024,
        tempBytes: 50 * 1024 * 1024,
        otherBytes: 0,
        downloadsCount: 12,
        cacheFilesCount: 300,
        measuredAt: DateTime(2026, 11, 26),
      );
      expect(usage.totalBytes, 950 * 1024 * 1024);
      expect(usage.reclaimableBytes, 150 * 1024 * 1024);
      expect(usage.fractionOf(1024 * 1024 * 1024), closeTo(0.93, 0.01));
      expect(usage.tierFor(1024 * 1024 * 1024), StorageTier.critical);
      final back = StorageUsage.fromJson(usage.toJson());
      expect(back.downloadsCount, 12);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  التذكيرات
  // ═════════════════════════════════════════════════════════════════════
  group('ReminderSettings', () {
    test('ساعات الهدوء 23-08', () {
      const s = ReminderSettings();
      expect(s.isQuietAt(DateTime(2026, 11, 26, 23, 30)), isTrue);
      expect(s.isQuietAt(DateTime(2026, 11, 26, 7, 0)), isTrue);
      expect(s.isQuietAt(DateTime(2026, 11, 26, 8, 0)), isFalse);
      expect(s.isQuietAt(DateTime(2026, 11, 26, 12, 0)), isFalse);
      expect(s.isQuietAt(DateTime(2026, 11, 26, 22, 59)), isFalse);
    });

    test('بداية ونهاية متساويتان تعني بلا هدوء', () {
      const s = ReminderSettings(quietStartHour: 0, quietEndHour: 0);
      expect(s.isQuietAt(DateTime(2026, 11, 26, 3)), isFalse);
    });

    test('JSON ذهاباً وإياباً', () {
      const s = ReminderSettings(dailyHour: 9, dailyMinute: 30, daysOfWeek: {1, 3, 5});
      final back = ReminderSettings.fromJson(s.toJson());
      expect(back.dailyHour, 9);
      expect(back.dailyMinute, 30);
      expect(back.daysOfWeek, {1, 3, 5});
      expect(back.dailyTimeLabel, '09:30');
    });

    test('نصوص قواعديّة حسب الساعة والسلسلة', () {
      expect(DailyReminderTexts.titleForHour(8), DailyReminderTexts.morningTitles.first);
      expect(DailyReminderTexts.titleForHour(21), DailyReminderTexts.nightTitles.first);
      expect(StreakReminderTexts.titleFor(30), contains('30'));
      expect(StreakReminderTexts.bodyFor(0), contains('فصلاً واحداً'));
      expect(arabicWeekdayName(5), 'الجمعة');
      expect(arabicWeekdayName(7), 'الأحد');
    });
  });

  group('ReminderCenter', () {
    test('تذكير اليوم يُبنى مرة واحدة يومياً', () async {
      await _prefs();
      final center = ReminderCenter.testInstance();
      final now = DateTime(2026, 11, 26, 21, 0);
      final first = await center.refreshForToday(
        streak: 1, minutesToday: 0, goalChapters: 0, readChaptersToday: 0, now: now,
      );
      expect(first, isNotNull);
      expect(first!.kind, ReminderKind.daily);
      final second = await center.refreshForToday(
        streak: 1, minutesToday: 0, goalChapters: 0, readChaptersToday: 0, now: now,
      );
      expect(second, isNull);
    });

    test('من حقق هدفه لا يُذكَّر', () async {
      await _prefs();
      final center = ReminderCenter.testInstance();
      final r = await center.refreshForToday(
        streak: 2, minutesToday: 40, goalChapters: 3, readChaptersToday: 3,
        now: DateTime(2026, 11, 26, 21, 0),
      );
      expect(r, isNull);
    });

    test('سلسلة 7 أيام تعطي تذكير مواظبة', () async {
      await _prefs();
      final center = ReminderCenter.testInstance();
      final r = await center.refreshForToday(
        streak: 7, minutesToday: 0, goalChapters: 0, readChaptersToday: 0,
        now: DateTime(2026, 11, 26, 21, 0),
      );
      expect(r?.kind, ReminderKind.streak);
    });

    test('المستحق يحترم ساعات الهدوء', () async {
      await _prefs();
      final center = ReminderCenter.testInstance();
      await center.scheduleNewChapter(
        seriesId: 's1', seriesTitle: 'عمل', chapter: 5,
        now: DateTime(2026, 11, 26, 20, 0),
      );
      expect(center.dueReminders(now: DateTime(2026, 11, 26, 20, 30)).length, 1);
      expect(center.dueReminders(now: DateTime(2026, 11, 26, 23, 30)), isEmpty);
    });

    test('تذكير الفصل لا يتكرر، والتسليم يخفيه', () async {
      await _prefs();
      final center = ReminderCenter.testInstance();
      final now = DateTime(2026, 11, 26, 20, 0);
      final first = await center.scheduleNewChapter(seriesId: 's1', seriesTitle: 'عمل', chapter: 5, now: now);
      expect(first, isNotNull);
      final dup = await center.scheduleNewChapter(seriesId: 's1', seriesTitle: 'عمل', chapter: 5, now: now);
      expect(dup, isNull);
      await center.markDelivered(first!.id);
      expect(center.dueReminders(now: now.add(const Duration(minutes: 5))), isEmpty);
    });

    test('التأجيل يخفي التذكير ساعتين', () async {
      await _prefs();
      final center = ReminderCenter.testInstance();
      final now = DateTime(2026, 11, 26, 17, 0);
      final r = await center.scheduleNewChapter(seriesId: 's1', seriesTitle: 'عمل', chapter: 9, now: now);
      await center.snooze(r!.id, by: const Duration(hours: 2), now: now);
      expect(center.dueReminders(now: now.add(const Duration(hours: 1))), isEmpty);
      expect(center.dueReminders(now: now.add(const Duration(minutes: 150))).length, 1);
    });

    test('موعد التذكير التالي يتخطى الأيام المعطّلة', () {
      const s = ReminderSettings(dailyHour: 20, dailyMinute: 0, daysOfWeek: {6});
      final center = ReminderCenter.testInstance();
      // اختبار مباشر لمنطق الموعد عبر نسخة إعدادات معدّلة.
      final next = _nextDailyFor(s, DateTime(2026, 11, 26, 21, 0)); // الخميس
      expect(next.weekday, 6); // السبت
      expect(next.hour, 20);
      expect(center.nextDailyTime(now: DateTime(2026, 11, 26, 10, 0)).hour, 20);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  خط الصور
  // ═════════════════════════════════════════════════════════════════════
  group('ImagePipeline', () {
    test('جودة تلقائية حسب الوضع والشبكة', () {
      expect(qualityFor(DataMode.mobile, V2NetworkCondition.wifi), ImageQuality.low);
      expect(qualityFor(DataMode.hd, V2NetworkCondition.wifi), ImageQuality.original);
      expect(qualityFor(DataMode.hd, V2NetworkCondition.mobile), ImageQuality.high);
      expect(qualityFor(DataMode.always, V2NetworkCondition.wifi), ImageQuality.high);
      expect(qualityFor(DataMode.always, V2NetworkCondition.mobile), ImageQuality.medium);
    });

    test('حلّ رابط الصفحة حسب الجودة', () {
      const src = PageSrc('https://example.com/high.jpg', low: 'https://example.com/low.jpg');
      expect(resolvePageUrl(src, ImageQuality.low), 'https://example.com/low.jpg');
      expect(resolvePageUrl(src, ImageQuality.high), 'https://example.com/high.jpg');
      const noLow = PageSrc('https://example.com/high.jpg');
      expect(resolvePageUrl(noLow, ImageQuality.low), 'https://example.com/high.jpg');
    });

    test('إحصاءات الإصابات', () {
      final stats = ImagePipelineStats();
      expect(stats.hitRateLabel, '—');
      stats.hits = 3;
      stats.misses = 1;
      expect(stats.hitRate, 0.75);
      expect(stats.hitRateLabel, '75٪');
    });

    test('لون الغلاف ثابت لنفس العمل', () {
      expect(coverToneColor('series_1'), coverToneColor('series_1'));
    });
  });
  //  إضافات: سجل الأحداث، التشخيص، التوصيات، خطة الأسبوع
  // ═════════════════════════════════════════════════════════════════════
  group('إضافات v2', () {
    test('سجل أحداث المحرك: إضافة وعدّ وإفراغ', () {
      final log = V2EngineEventLog();
      log.add(V2EngineEventKind.enqueued, 'أضيف فصل');
      log.add(V2EngineEventKind.completed, 'اكتمل فصل');
      log.add(V2EngineEventKind.completed, 'اكتمل فصل آخر');
      expect(log.events.length, 3);
      expect(log.countOf(V2EngineEventKind.completed), 2);
      expect(log.ofKind(V2EngineEventKind.enqueued).length, 1);
      log.clear();
      expect(log.events, isEmpty);
    });

    test('تشخيص المحرك يقرأ الحالة', () async {
      await _prefs();
      final engine = V2DownloadEngine.testInstance();
      await engine.setPolicy(V2NetworkPolicy.wifiOnly);
      final diag = v2EngineDiagnostics(engine, V2NetworkCondition.wifi);
      expect(diag['policy'], 'wifiOnly');
      expect(diag['network'], 'wifi');
      expect(diag['jobs'], isA<Map<String, dynamic>>());
      final snapshot = V2QueueSnapshot.fromEngine(engine);
      expect(snapshot.total, 0);
      expect(snapshot.summary, 'لا توجد تنزيلات');
    });

    test('ملخص التعارضات وتصدير السجلات', () {
      final now = DateTime(2026, 11, 26, 10);
      final local = SyncRecord(seriesId: 's1', chapter: 4, page: 1, total: 10, seconds: 10, updatedAt: now);
      final server = SyncRecord(seriesId: 's1', chapter: 2, page: 1, total: 10, seconds: 10, updatedAt: now);
      final conflict = SyncConflict(
        id: 'c1', seriesId: 's1', seriesTitle: 'عمل', field: SyncField.chapter,
        local: local, server: server, detectedAt: now,
      );
      final summary = SyncConflictSummary.fromConflicts([conflict]);
      expect(summary.total, 1);
      expect(summary.byField[SyncField.chapter], 1);
      expect(summary.describe, contains('تعارض'));
      final text = exportSyncRecordsText({'s1': local});
      expect(text, contains('s1'));
      expect(text, contains('الفصل 4'));
      final solved = applyAutoResolveRule(conflict, SyncAutoResolveRule.mergeAlways);
      expect(solved.chapter, 4);
      expect(resolutionForRule(SyncAutoResolveRule.localWins), SyncResolution.keepLocal);
      expect(resolutionForRule(SyncAutoResolveRule.ask), SyncResolution.pending);
    });

    test('توصيات التخزين من القياس', () {
      final usage = StorageUsage(
        downloadsBytes: 100 * 1024 * 1024,
        imageCacheBytes: 600 * 1024 * 1024,
        tempBytes: 200 * 1024 * 1024,
        otherBytes: 0,
        downloadsCount: 5,
        cacheFilesCount: 400,
        measuredAt: DateTime(2026, 11, 26),
      );
      const limits = StorageLimits(cacheLimitMB: 512);
      final recs = buildStorageRecommendations(usage, limits);
      expect(recs.any((r) => r.action == StorageActionKind.cleanCache), isTrue);
      expect(recs.any((r) => r.action == StorageActionKind.cleanTemp), isTrue);
      final healthy = buildStorageRecommendations(
        StorageUsage(
          downloadsBytes: 0, imageCacheBytes: 0, tempBytes: 0, otherBytes: 0,
          downloadsCount: 0, cacheFilesCount: 0,
          measuredAt: DateTime(2026, 11, 26),
        ),
        limits,
      );
      expect(healthy.single.action, StorageActionKind.nothing);
    });

    test('نصوص الهدف والعودة وخطة الأسبوع', () {
      expect(GoalReminderTexts.titleFor(1), contains('فصل واحد'));
      expect(GoalReminderTexts.titleFor(0), contains('حققتَ'));
      expect(WelcomeBackTexts.titleFor(40), contains('غياب طويل'));
      expect(WelcomeBackTexts.bodyFor(3), contains('فصل واحد'));
      final center = ReminderCenter.testInstance();
      final plan = center.weekPlan(now: DateTime(2026, 11, 26, 10, 0)); // الخميس
      expect(plan.activeDays, 4); // الخميس..الأحد
      expect(plan.hasReminderOn(5), isTrue); // الجمعة
      expect(plan.hasReminderOn(1), isFalse); // الاثنين مضى
      expect(plan.summary, contains('تذكيرات في'));
    });

    test('إعدادات جودة الصور', () {
      const s = ImageQualitySettings();
      expect(s.qualityForCondition(V2NetworkCondition.wifi), ImageQuality.high);
      expect(s.qualityForCondition(V2NetworkCondition.mobile), ImageQuality.low);
      final fixed = s.copyWith(autoQuality: false, wifiQuality: ImageQuality.original);
      expect(fixed.qualityForCondition(V2NetworkCondition.mobile), ImageQuality.original);
      final back = ImageQualitySettings.fromJson(s.toJson());
      expect(back.mobileQuality, ImageQuality.low);
      expect(back.prefetchNextChapter, isTrue);
    });

    test('سجل تسليم التذكيرات وإحصاءاته', () async {
      await _prefs();
      final center = ReminderCenter.testInstance();
      final now = DateTime(2026, 11, 26, 20, 0);
      final r = await center.scheduleNewChapter(seriesId: 's1', seriesTitle: 'عمل', chapter: 2, now: now);
      await center.markDelivered(r!.id);
      expect(center.deliveryLog.length, 1);
      expect(center.deliveryStats.deliveredThisWeek, 1);
      expect(center.deliveryStats.actionRateLabel, '0٪');
      await center.markActionTaken(r.id);
      expect(center.deliveryStats.actionTakenThisWeek, 1);
      expect(center.deliveryStats.actionRateLabel, '100٪');
    });

    test('تقدير أقسام النسخة من التفضيلات', () async {
      await _prefs({'followed_series': ['s1'], 'theme': 'paper', 'progress': '{}'});
      final infos = await estimateBackupSections();
      expect(infos.length, BackupSection.values.length);
      final library = infos.firstWhere((e) => e.section == BackupSection.library);
      expect(library.keyCount, 1); // followed_series فقط من المفاتيح المزروعة
      final settingsInfo = infos.firstWhere((e) => e.section == BackupSection.settings);
      expect(settingsInfo.keyCount, 1); // theme فقط
      final progressInfo = infos.firstWhere((e) => e.section == BackupSection.progress);
      expect(progressInfo.keyCount, 1); // progress فقط
      expect(BackupPresets.everything.length, 4);
    });

    test('ملفات النسخ المحلية في بيئة اختبار فارغة', () async {
      final list = await BackupFileHelper.listLocalBackups();
      expect(list, isEmpty);
    });
  });
}

/// نسخة مستقلة من منطق «التذكير التالي» للاختبار المباشر بإعدادات مخصصة.
DateTime _nextDailyFor(ReminderSettings s, DateTime now) {
  var next = DateTime(now.year, now.month, now.day, s.dailyHour, s.dailyMinute);
  if (!next.isAfter(now)) next = next.add(const Duration(days: 1));
  while (!s.isDayEnabled(next.weekday)) {
    next = next.add(const Duration(days: 1));
  }
  return next;
}

  // ═════════════════════════════════════════════════════════════════════
