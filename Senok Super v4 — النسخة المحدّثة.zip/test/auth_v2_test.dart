// اختبارات وحدة لمنطق الحساب الاحترافي v2 في Senok.
// تغطي: التحقق من البريد وكلمة المرور، قوة كلمة المرور، حارس المحاولات،
// رمز PIN، الجلسات، نقاط الأمان، حدود الضيف، الترحيب، الأهداف، والملف الشخصي.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/account_repository.dart';
import 'package:senok_app/core/data/api_client.dart';
import 'package:senok_app/core/storage/settings.dart';
import 'package:senok_app/core/theme/app_themes.dart';
import 'package:senok_app/features/auth/account_actions.dart';
import 'package:senok_app/features/auth/auth_v2.dart';
import 'package:senok_app/features/auth/guest_mode.dart';
import 'package:senok_app/features/auth/onboarding_v2.dart';
import 'package:senok_app/features/auth/profile_v2.dart';
import 'package:senok_app/features/auth/reading_goals.dart';
import 'package:senok_app/features/auth/security_screen.dart';
import 'package:senok_app/features/auth/session_manager.dart';
import 'package:senok_app/widgets/sard_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// تاريخ ثابت للاختبارات التي تحتاج DateTime ثابتاً.
class _FixedDate {
  static final DateTime fallback = DateTime(2026, 11, 26, 1, 30);
}

Future<SharedPreferences> _prefs([Map<String, Object> values = const {}]) async {
  SharedPreferences.setMockInitialValues(values);
  return SharedPreferences.getInstance();
}

void main() {
  group('التحقق من البريد', () {
    test('بريد صالح يُقبل', () {
      expect(isValidEmail('name@example.com'), isTrue);
      expect(isValidEmail('  user.name+tag@sub.domain.co  '), isTrue);
      expect(validateEmail('name@example.com'), isNull);
    });

    test('بريد غير صالح يُرفض مع رسالة عربية', () {
      expect(isValidEmail('not-an-email'), isFalse);
      expect(isValidEmail('a@b'), isFalse);
      expect(isValidEmail('a b@c.com'), isFalse);
      expect(validateEmail(''), contains('اكتب'));
      expect(validateEmail('x'), contains('صيغة'));
      expect(validateEmail(null), isNotNull);
    });

    test('اقتراح تصحيح النطاقات الشائعة', () {
      expect(suggestEmailFix('user@gmial.com'), 'user@gmail.com');
      expect(suggestEmailFix('user@hotmal.com'), 'user@hotmail.com');
      expect(suggestEmailFix('user@gmail.com'), isNull);
      expect(suggestEmailFix('no-at-sign'), isNull);
    });

    test('النطاقات العامة المعروفة', () {
      expect(isCommonEmailDomain('a@gmail.com'), isTrue);
      expect(isCommonEmailDomain('a@company.example'), isFalse);
    });
  });

  group('كلمة المرور', () {
    test('التحقق الأساسي', () {
      expect(validatePassword(''), contains('اكتب'));
      expect(validatePassword('short'), contains('8 أحرف'));
      expect(validatePassword('longenough1'), isNull);
      expect(validatePassword('abcdefgh', strict: true), contains('رقماً'));
      expect(validatePassword('12345678', strict: true), contains('حرفاً'));
      expect(validatePassword('Abcdef12', strict: true), isNull);
    });

    test('تأكيد كلمة المرور', () {
      expect(validatePasswordConfirmation('', 'x'), isNotNull);
      expect(validatePasswordConfirmation('a', 'b'), contains('غير متطابقتين'));
      expect(validatePasswordConfirmation('same', 'same'), isNull);
    });

    test('قوة كلمة المرور', () {
      expect(evaluatePasswordStrength('abc').strength, PasswordStrength.veryWeak);
      expect(evaluatePasswordStrength('password1').isCommon, isTrue);
      expect(evaluatePasswordStrength('12345678').hasSequence, isTrue);
      final strong = evaluatePasswordStrength('S@r0k!Zm9Qv2');
      expect(strong.strength.index, greaterThanOrEqualTo(PasswordStrength.strong.index));
      expect(strong.suggestions, isEmpty);
      expect(isPasswordStrongEnough('S@r0k!Zm9Qv2'), isTrue);
      expect(isPasswordStrongEnough('abc123'), isFalse);
    });

    test('تسميات القوة وألوانها', () {
      expect(PasswordStrength.veryWeak.label, 'ضعيفة جداً');
      expect(PasswordStrength.veryStrong.label, 'قوية جداً');
      expect(PasswordStrength.strong.fraction, closeTo(0.8, 0.001));
    });

    test('الاسم المعروض', () {
      expect(validateDisplayName(''), isNotNull);
      expect(validateDisplayName('س'), contains('قصير'));
      expect(validateDisplayName('سارة'), isNull);
    });
  });

  group('أخطاء الدخول الودودة', () {
    test('خطأ عدم الاتصال يتحول لرسالة عربية', () {
      final e = ApiException('x', failure: ApiFailure.offline);
      expect(friendlyAuthError(e), contains('لا يوجد اتصال'));
    });

    test('خطأ 401 يعني بيانات غير صحيحة', () {
      final e = ApiException('x', failure: ApiFailure.unauthorized);
      expect(friendlyAuthError(e), contains('بيانات الدخول غير صحيحة'));
    });

    test('خطأ 404 يعني حساباً غير موجود', () {
      final e = ApiException('x', failure: ApiFailure.notFound);
      expect(friendlyAuthError(e), contains('لم نعثر على هذا الحساب'));
    });

    test('خطأ الخادم والمهلة', () {
      expect(
        friendlyAuthError(ApiException('x', failure: ApiFailure.server)),
        contains('الخادم'),
      );
      expect(
        friendlyAuthError(ApiException('x', failure: ApiFailure.timeout)),
        contains('وقتاً طويلاً'),
      );
    });
  });

  group('حارس المحاولات', () {
    test('خمس محاولات فاشلة تقفل الدخول', () {
      final g = AttemptGuard(maxAttempts: 5, lockout: const Duration(minutes: 5));
      expect(g.isLocked, isFalse);
      expect(g.remainingAttempts, 5);
      for (var i = 0; i < 4; i++) {
        g.recordFailure();
        expect(g.isLocked, isFalse);
      }
      expect(g.remainingAttempts, 1);
      g.recordFailure();
      expect(g.isLocked, isTrue);
      expect(g.remainingSeconds, greaterThan(0));
      expect(g.lockMessage, contains('محاولات كثيرة'));
      g.recordSuccess();
      expect(g.isLocked, isFalse);
      expect(g.remainingAttempts, 5);
    });

    test('JSON ذهاباً وإياباً', () {
      final g = AttemptGuard();
      g.recordFailure();
      g.recordFailure();
      final back = AttemptGuard.fromJson(g.toJson());
      expect(back.failures, 2);
      expect(back.isLocked, isFalse);
    });
  });

  group('نموذج المستخدم', () {
    test('الأحرف الأولى والاسم المعروض', () {
      const u = AuthUser(id: '1', name: 'سارة أحمد', email: 's@example.com');
      expect(u.displayName, 'سارة أحمد');
      expect(u.initials, 'سأ');
      expect(const AuthUser(id: '2', name: '', email: 'e').displayName, 'قارئ');
    });

    test('JSON ذهاباً وإياباً', () {
      const u = AuthUser(id: '1', name: 'سارة', email: 's@example.com', isLocalDemo: true);
      final back = AuthUser.fromJson(u.toJson());
      expect(back.id, '1');
      expect(back.isLocalDemo, isTrue);
      expect(back.name, 'سارة');
    });

    test('تسميات حالة الدخول', () {
      expect(AuthState.guest.label, 'ضيف');
      expect(AuthState.localDemo.label, 'وضع تجريبي محلي');
    });
  });

  group('قفل PIN', () {
    test('التجزئة حتمية وتتغير مع الملح', () {
      expect(fnv1aHash64('hello'), fnv1aHash64('hello'));
      expect(pinHash('1234', 'salt-a'), isNot(pinHash('1234', 'salt-b')));
      expect(pinHash('1234', 's'), isNot(pinHash('4321', 's')));
      expect(generatePinSalt().length, 32);
    });

    test('صيغة PIN والضعف الواضح', () {
      expect(isValidPinFormat('1234'), isTrue);
      expect(isValidPinFormat('123456'), isTrue);
      expect(isValidPinFormat('123'), isFalse);
      expect(isValidPinFormat('12a4'), isFalse);
      expect(isWeakPin('1234'), isTrue);
      expect(isWeakPin('0000'), isTrue);
      expect(isWeakPin('1111'), isTrue);
      expect(isWeakPin('4829'), isFalse);
      expect(isWeakPin('9753'), isFalse);
    });

    test('تعيين وتحقق عبر المخزن', () async {
      final prefs = await _prefs();
      final store = PinStore.fromPrefs(prefs);
      expect(store.pinEnabled, isFalse);
      expect(await store.setPin('4829'), isTrue);
      expect(store.pinEnabled, isTrue);
      expect(store.pinLength, 4);
      expect(await store.verifyPin('4829'), isTrue);
      expect(await store.verifyPin('0000'), isFalse);
      expect(store.failedAttempts, 1);
      await store.disablePin();
      expect(store.pinEnabled, isFalse);
    });

    test('خمس محاولات خاطئة تقفل مؤقتاً', () async {
      final prefs = await _prefs();
      final store = PinStore.fromPrefs(prefs);
      await store.setPin('4829');
      for (var i = 0; i < 5; i++) {
        expect(await store.verifyPin('1111'), isFalse);
      }
      expect(store.isLocked, isTrue);
      expect(store.lockRemainingSeconds, greaterThan(0));
      expect(await store.verifyPin('4829'), isFalse); // مقفل رغم صحة الرمز
    });

    test('تغيير PIN والبصمة كتفضيل', () async {
      final prefs = await _prefs();
      final store = PinStore.fromPrefs(prefs);
      await store.setPin('4829');
      expect(await store.changePin('0000', '9753'), isFalse);
      expect(await store.changePin('4829', '9753'), isTrue);
      expect(await store.verifyPin('9753'), isTrue);
      expect(store.biometricPreferred, isFalse);
      await store.setBiometricPreferred(true);
      expect(store.biometricPreferred, isTrue);
    });

    test('نقاط الأمان', () {
      final full = computeSecurityScore(
        pinEnabled: true,
        biometricPreferred: true,
        strongPassword: true,
        activeSessions: 1,
        emailVerified: true,
      );
      expect(full.total, 95);
      expect(full.label, 'ممتاز');
      expect(full.items.length, 5);
      final weak = computeSecurityScore(
        pinEnabled: false,
        biometricPreferred: false,
        strongPassword: false,
        activeSessions: 4,
        emailVerified: false,
      );
      expect(weak.total, 0);
      expect(weak.label, 'ضعيف');
      expect(
        computeSecurityScoreValue(
          pinEnabled: true,
          biometricPreferred: false,
          strongPassword: true,
          activeSessions: 1,
          emailVerified: false,
        ),
        75,
      );
    });
  });

  group('الجلسات', () {
    test('معرّف الجلسة فريد', () {
      expect(generateSessionId(), isNot(generateSessionId()));
      expect(generateSessionId().startsWith('sess_'), isTrue);
    });

    test('تسميات انتهاء الجلسة', () {
      final now = DateTime.now();
      final expired = SessionInfo(
        id: 'a',
        deviceLabel: 'هاتف',
        deviceKind: DeviceKind.android,
        createdAt: now.subtract(const Duration(days: 40)),
        lastActiveAt: now.subtract(const Duration(days: 40)),
        expiresAt: now.subtract(const Duration(days: 10)),
      );
      expect(expired.isExpired, isTrue);
      expect(expired.expiryLabel, 'منتهية');
      final soon = SessionInfo(
        id: 'b',
        deviceLabel: 'هاتف',
        deviceKind: DeviceKind.android,
        createdAt: now,
        lastActiveAt: now,
        expiresAt: now.add(const Duration(hours: 5, minutes: 30)),
      );
      expect(soon.expiresWithin(const Duration(days: 1)), isTrue);
      expect(soon.expiryLabel, contains('5 ساعة'));
    });

    test('JSON ذهاباً وإياباً', () {
      final now = DateTime.now();
      final s = SessionInfo(
        id: 's1',
        deviceLabel: 'هذا الجهاز',
        deviceKind: DeviceKind.web,
        createdAt: now,
        lastActiveAt: now,
        expiresAt: now.add(const Duration(days: 30)),
        isCurrent: true,
      );
      final back = SessionInfo.fromJson(s.toJson());
      expect(back.id, 's1');
      expect(back.deviceKind, DeviceKind.web);
      expect(back.isCurrent, isTrue);
    });

    test('مدير الجلسات ينشئ جلسة محلية', () async {
      final prefs = await _prefs();
      final manager = SessionManager.fromPrefs(prefs);
      await manager.init();
      expect(manager.currentSession, isNotNull);
      expect(manager.hasActiveSession, isTrue);
      expect(manager.serverAvailable, isFalse); // بلا مستودع خادم
      expect(manager.timeToExpiry, isNotNull);
      expect(manager.expiringSoon, isFalse);
      expect(await manager.renameSession(manager.currentSession!.id, 'هاتف العمل'), isTrue);
      expect(manager.currentSession!.deviceLabel, 'هاتف العمل');
      expect(await manager.revokeAllExceptCurrent(), 0);
      await manager.touch();
      expect(manager.currentSession, isNotNull);
      manager.dispose();
    });
  });

  group('حدود الضيف', () {
    test('الحدود الافتراضية', () {
      const limits = GuestLimits.defaults;
      expect(limits.maxFollowed, 10);
      expect(limits.commentsAllowed, isFalse);
      expect(limits.downloadsAllowed, isFalse);
      expect(limits.maxDailyChapters, 50);
      final back = GuestLimits.fromJson(limits.toJson());
      expect(back.maxFollowed, 10);
      expect(back.maxLists, 1);
    });

    test('فحص المتابعة والتعليق', () async {
      final prefs = await _prefs();
      final guest = GuestModeController.fromPrefs(prefs);
      expect(guest.isGuest, isFalse);
      await guest.enterGuest();
      expect(guest.isGuest, isTrue);
      expect(guest.canFollow(3).allowed, isTrue);
      expect(guest.canFollow(10).allowed, isFalse);
      expect(guest.canFollow(10).message, contains('10 أعمال'));
      expect(guest.canComment.allowed, isFalse);
      expect(guest.canDownload.message, contains('التنزيل'));
      expect(guest.canPost.allowed, isFalse);
      expect(guest.canCreateList(0).allowed, isTrue);
      expect(guest.canCreateList(1).allowed, isFalse);
    });

    test('عدّاد فصول اليوم', () async {
      final prefs = await _prefs();
      final guest = GuestModeController.fromPrefs(prefs);
      expect(guest.todayChapters, 0);
      await guest.noteChapterRead();
      await guest.noteChapterRead();
      expect(guest.todayChapters, 2);
      expect(guest.canReadAnotherChapter.allowed, isTrue);
    });

    test('عنصر بيانات الضيف', () {
      const item = GuestDataItem(label: 'أعمال متابَعة', count: 7, icon: SardIcons.bookmark_rounded);
      expect(item.count, 7);
      expect(item.label, 'أعمال متابَعة');
    });

    test('ترحيل بيانات الضيف', () async {
      final prefs = await _prefs();
      final guest = GuestModeController.fromPrefs(prefs);
      await guest.enterGuest();
      await guest.noteChapterRead();
      final result = GuestMigration.plan(guest: guest, followed: 4, lists: 1);
      expect(result.followedMigrated, 4);
      expect(result.totalMigrated, 6);
      expect(result.summary, contains('4 متابَعة'));
      final done = await GuestMigration.execute(guest: guest, followed: 4, lists: 1);
      expect(guest.isGuest, isFalse);
      expect(done.totalMigrated, 6);
    });
  });

  group('أهداف القراءة', () {
    test('هدف إلى JSON وعودته', () {
      final goal = SardReadingGoal(
        id: 'g1',
        type: ReadingGoalType.dailyChapters,
        target: 5,
        createdAt: _FixedDate.fallback,
      );
      expect(goal.defaultTitle, contains('5'));
      expect(goal.defaultTitle, contains('فصول'));
      expect(goal.fraction, 0);
      expect(goal.isComplete, isFalse);
      expect(goal.remaining, 5);
      final back = SardReadingGoal.fromJson(goal.toJson());
      expect(back.id, 'g1');
      expect(back.type, ReadingGoalType.dailyChapters);
      expect(back.target, 5);
      expect(back.createdAt, _FixedDate.fallback);
    });

    test('عناوين الأهداف الافتراضية عربية', () {
      final daily = SardReadingGoal(id: 'a', type: ReadingGoalType.dailyChapters, target: 5, createdAt: _FixedDate.fallback);
      expect(daily.defaultTitle, contains('5'));
      expect(daily.defaultTitle, contains('فصول'));
      final minutes = SardReadingGoal(id: 'b', type: ReadingGoalType.dailyMinutes, target: 30, createdAt: _FixedDate.fallback);
      expect(minutes.defaultTitle, contains('30 دقيقة'));
      final monthly = SardReadingGoal(id: 'c', type: ReadingGoalType.monthlySeries, target: 2, createdAt: _FixedDate.fallback);
      expect(monthly.defaultTitle, contains('أعمال'));
      expect(ReadingGoalType.dailyChapters.suggestedTarget, 3);
      expect(ReadingGoalType.dailyMinutes.maxTarget, 720);
    });

    test('المخزن: إضافة وتقدّم وأرشفة', () async {
      final prefs = await _prefs();
      final store = SardReadingGoalsStore.fromPrefs(prefs);
      await store.init();
      expect(store.goals, isEmpty);
      final goal = await store.addGoal(ReadingGoalType.dailyChapters, 3);
      expect(store.activeGoals.length, 1);
      await store.recordChapter();
      await store.recordChapter();
      expect(store.activeGoals.first.progress, 2);
      expect(store.activeGoals.first.isComplete, isFalse);
      await store.recordChapter();
      expect(store.activeGoals.first.isComplete, isTrue);
      expect(store.activeGoals.first.streak, 1);
      expect(store.completedToday, 1);
      expect(store.allComplete, isTrue);
      await store.archiveGoal(goal.id);
      expect(store.activeGoals, isEmpty);
      expect(store.archivedGoals.length, 1);
      await store.restoreGoal(goal.id);
      expect(store.activeGoals.length, 1);
      await store.removeGoal(goal.id);
      expect(store.goals, isEmpty);
    });

    test('الدقائق والأعمال الشهرية', () async {
      final prefs = await _prefs();
      final store = SardReadingGoalsStore.fromPrefs(prefs);
      await store.init();
      await store.addGoal(ReadingGoalType.dailyMinutes, 30);
      await store.addGoal(ReadingGoalType.monthlySeries, 2);
      await store.recordMinutes(20);
      expect(store.activeGoals.firstWhere((g) => g.type == ReadingGoalType.dailyMinutes).progress, 20);
      await store.recordSeriesFinished();
      expect(store.activeGoals.firstWhere((g) => g.type == ReadingGoalType.monthlySeries).progress, 1);
      await store.recordMinutes(0); // لا أثر
      expect(store.activeGoals.firstWhere((g) => g.type == ReadingGoalType.dailyMinutes).progress, 20);
    });

    test('التقرير الأسبوعي ونص المشاركة', () async {
      final prefs = await _prefs();
      final store = SardReadingGoalsStore.fromPrefs(prefs);
      await store.init();
      await store.addGoal(ReadingGoalType.dailyChapters, 2);
      await store.recordChapter();
      await store.recordChapter();
      final report = buildWeeklyReport(store, now: DateTime(2026, 11, 26));
      expect(report.total, 1);
      expect(report.completedCount, 1);
      expect(report.headline, contains('مثالي'));
      expect(report.toShareText(), contains('Senok'));
      expect(report.toShareText(), contains('فصول'));
    });
  });

  group('الملف الشخصي v2', () {
    test('مستويات القارئ', () {
      expect(ReaderLevel.fromChapters(0), ReaderLevel.beginner);
      expect(ReaderLevel.fromChapters(49), ReaderLevel.beginner);
      expect(ReaderLevel.fromChapters(50), ReaderLevel.reader);
      expect(ReaderLevel.fromChapters(600), ReaderLevel.bookworm);
      expect(ReaderLevel.fromChapters(1000), ReaderLevel.legend);
      expect(ReaderLevel.beginner.chaptersToNext(0), 50);
      expect(ReaderLevel.legend.chaptersToNext(1500), 0);
      expect(ReaderLevel.legend.next, isNull);
    });

    test('بيانات الملف JSON ذهاباً وإياباً', () {
      const data = ProfileV2Data(
        name: 'سارة',
        bio: 'أقرأ المانهوا',
        avatarPresetId: 'jade',
        isPublic: true,
      );
      expect(data.displayName, 'سارة');
      expect(data.initials, 'س');
      expect(data.visibilityLabel, contains('عام'));
      final back = ProfileV2Data.fromJson(data.toJson());
      expect(back.name, 'سارة');
      expect(back.bio, 'أقرأ المانهوا');
      expect(back.avatarPresetId, 'jade');
      expect(back.isPublic, isTrue);
    });

    test('اكتمال الملف', () {
      const empty = ProfileV2Data(name: '');
      final c0 = computeProfileCompletion(empty);
      expect(c0.percent, 0);
      expect(c0.label, contains('فارغ'));
      expect(c0.missing.length, 4);
      const full = ProfileV2Data(
        name: 'سارة',
        bio: 'نبذة',
        avatarPresetId: 'jade',
      );
      final c1 = computeProfileCompletion(full, hasGoal: true);
      expect(c1.percent, 100);
      expect(c1.isComplete, isTrue);
    });

    test('إحصاءات السنة من بيانات حقيقية', () async {
      await _prefs({
        'reading_seconds': '{"s1": 3600, "s2": 1800}',
        'read_chapters': '{"s1": [1, 2, 3]}',
        'read_days': ['2026-11-26', '2026-11-25'],
        'followed_series': ['s1', 's2'],
      });
      final settings = await SettingsController.load();
      // ملاحظة: load() يقرأ النسخة الوهمية نفسها عبر getInstance.
      final stats = YearStats.fromSettings(settings, year: 2026);
      expect(stats.chapters, 3);
      expect(stats.minutes, 90);
      expect(stats.days, 2);
      expect(stats.followed, 2);
      expect(stats.bestMonthName, '—');
      expect(stats.readingTimeLabel, '1 س 30 د');
      expect(stats.chaptersPerDay, closeTo(1.5, 0.001));
    });
  });

  group('الترحيب v2', () {
    test('خمس صفحات ثابتة', () {
      expect(kOnboardingV2Pages.length, 5);
      expect(kOnboardingV2Pages.map((p) => p.id).toSet().length, 5);
      for (final page in kOnboardingV2Pages) {
        expect(page.title, isNotEmpty);
        expect(page.body, isNotEmpty);
        expect(page.example, isNotEmpty);
      }
    });

    test('مخزن الإكمال', () async {
      await _prefs();
      final store = await OnboardingV2Store.load();
      expect(store.done, isFalse);
      await store.markPageSeen(2);
      expect(store.lastPage, 2);
      await store.markDone(themeId: 'paper');
      expect(store.done, isTrue);
      expect(store.chosenThemeId, 'paper');
      await store.reset();
      expect(store.done, isFalse);
    });
  });

  group('تصدير البيانات وحذف الحساب', () {
    test('بناء التصدير من بيانات حقيقية', () async {
      await _prefs({
        'reading_seconds': '{"s1": 600}',
        'read_chapters': '{"s1": [1]}',
        'followed_series': ['s1'],
      });
      final settings = await SettingsController.load();
      final export = buildAccountExport(
        settings: settings,
        appVersion: '0.2.0',
        profile: {'name': 'سارة'},
      );
      expect(export.appVersion, '0.2.0');
      final json = export.toJson();
      expect(json['app'], 'Senok');
      expect((json['reading'] as Map)['total_chapters'], 1);
      expect(export.itemCount, greaterThanOrEqualTo(2));
      expect(export.toJsonString(), contains('Senok'));
    });

    test('قوائم الحذف واضحة وكاملة', () {
      expect(kDeleteAccountItems.length, 6);
      expect(kDeleteAccountKeeps.length, 2);
      expect(kDeleteAccountItems.first, contains('حسابك'));
      expect(DataPortabilityInfo.sections.length, 5);
      expect(DataPortabilityInfo.note, contains('JSON'));
    });
  });

  group('مخزن الدخول v2', () {
    test('الحالة الأولية والضيف', () async {
      await _prefs();
      final store = AuthV2Store(AuthV2Service(AccountRepository(ApiClient())));
      expect(store.state, AuthState.unknown);
      expect(store.signedIn, isFalse);
      await store.load();
      expect(store.state, AuthState.signedOut);
      store.enterGuest();
      expect(store.state, AuthState.guest);
      expect(store.guard.remainingAttempts, 5);
      store.clearError();
      expect(store.lastError, isNull);
    });
  });

  group('سجل التدقيق', () {
    test('تسجيل الأحداث وعدّ الفشل الحديث', () async {
      final prefs = await _prefs();
      final log = AuthAuditLog.fromPrefs(prefs);
      expect(log.events, isEmpty);
      await log.record(AuthAuditKind.signInSuccess);
      await log.record(AuthAuditKind.signInFailed, detail: 'بريد خاطئ');
      await log.record(AuthAuditKind.signInFailed);
      expect(log.events.length, 3);
      expect(log.recentFailures, 2);
      expect(log.events.first.kind, AuthAuditKind.signInFailed);
      await log.clear();
      expect(log.events, isEmpty);
    });
  });

  testWidgets('شريط قوة كلمة المرور يعرض التسمية', (tester) async {
    // نستخدم ThemeData عادياً مع ملحق SardPalette بدل buildTheme الكامل
    // (buildTheme الأصلي يطلق تأكيداً في بيئة الاختبار).
    await tester.pumpWidget(
      MaterialApp(
        theme: ThemeData(extensions: const <ThemeExtension<dynamic>>[SardThemes.obsidian]),
        home: const Scaffold(
          body: PasswordStrengthBar(password: 'S@r0k!Zm9Qv2'),
        ),
      ),
    );
    await tester.pump();
    expect(find.textContaining('قوية'), findsWidgets);
  });
}
