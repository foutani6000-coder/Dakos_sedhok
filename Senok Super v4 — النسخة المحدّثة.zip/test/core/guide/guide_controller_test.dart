import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/guide/guide_content.dart';
import 'package:senok_app/core/guide/guide_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues(<String, Object>{}));

  test('الشرح يظهر مرة واحدة فقط', () async {
    final g = await GuideController.load();
    g.show('tab.home');
    expect(g.current?.id, 'tab.home');
    g.dismiss();
    expect(g.hasSeen('tab.home'), isTrue);
    g.show('tab.home');
    expect(g.current, isNull);
  });

  test('الخطوات تتقدم ثم يُغلق الشرح عند آخر خطوة', () async {
    final g = await GuideController.load();
    g.show('welcome');
    final n = kGuide['welcome']!.steps.length;
    for (var i = 0; i < n - 1; i++) {
      g.next();
      expect(g.current?.id, 'welcome');
    }
    g.next();
    expect(g.current, isNull);
    expect(g.hasSeen('welcome'), isTrue);
  });

  test('run ينفّذ إجراء الزر بعد «فهمت» وفوراً في المرات التالية', () async {
    final g = await GuideController.load();
    var count = 0;
    g.run('btn.follow', () => count++);
    expect(count, 0);
    expect(g.current?.blocking, isTrue);
    for (var i = 0; i < kGuide['btn.follow']!.steps.length; i++) {
      g.next();
    }
    await Future<void>.delayed(Duration.zero);
    expect(count, 1);
    g.run('btn.follow', () => count++);
    expect(count, 2);
  });

  test('إيقاف المساعدة ينفّذ الإجراء المعلّق ولا يعرض شيئاً بعدها', () async {
    final g = await GuideController.load();
    var ran = false;
    g.run('btn.rate', () => ran = true);
    g.stopAll();
    await Future<void>.delayed(Duration.zero);
    expect(ran, isTrue);
    expect(g.enabled, isFalse);
    g.show('tab.search');
    expect(g.current, isNull);
  });

  test('resetAll يعيد الشروحات', () async {
    final g = await GuideController.load();
    g.show('tab.search');
    g.dismiss();
    g.resetAll();
    expect(g.hasSeen('tab.search'), isFalse);
    expect(g.enabled, isTrue);
  });

  test('كل مدخل له خطوة واحدة على الأقل', () {
    for (final e in kGuide.entries) {
      expect(e.value.steps, isNotEmpty, reason: e.key);
    }
  });
}
