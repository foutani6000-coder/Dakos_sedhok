import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/stamps/stamps.dart';
import 'package:senok_app/core/storage/settings.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<SettingsController> _fresh([Map<String, Object>? initial]) async {
  SharedPreferences.setMockInitialValues(initial ?? <String, Object>{});
  return SettingsController.load();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Stamps', () {
    test('ids are unique', () {
      final ids = kStamps.map((d) => d.id).toList();
      expect(ids.toSet().length, ids.length);
    });

    test('finishing the first chapter unlocks the first stamp and starts a streak', () async {
      final s = await _fresh();
      expect(s.hasStamp('first_stamp'), isFalse);
      s.markRead('a', 1);
      expect(s.hasStamp('first_stamp'), isTrue);
      expect(s.streak, 1);
      expect(s.stampToast.value?.id, 'first_stamp');
    });

    test('re-reading the same chapter does not count twice', () async {
      final s = await _fresh();
      s.markRead('a', 1);
      s.markRead('a', 1);
      expect(s.totalChaptersRead, 1);
    });

    test('five chapters in one day unlock the marathon stamp', () async {
      final s = await _fresh();
      for (var i = 1; i <= 5; i++) {
        s.markRead('a', i);
      }
      expect(s.hasStamp('marathon_5'), isTrue);
    });

    test('streak counts consecutive days and stays alive until tomorrow', () async {
      final now = DateTime.now();
      String key(DateTime d) =>
          '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
      final days = [
        for (var i = 1; i <= 3; i++) key(DateTime(now.year, now.month, now.day - i)),
      ];
      final s = await _fresh(<String, Object>{'read_days': days});
      expect(s.streak, 3); // قرأ أمس وقبله ولم يقرأ اليوم بعد
      expect(s.hasStamp('streak_3'), isTrue); // ويُمنح بصمت من التاريخ السابق
      expect(s.stampToast.value, isNull);
    });

    test('fontScale defaults to 0.88 and clamps', () async {
      final s = await _fresh();
      expect(s.fontScale, 0.88);
      s.setFontScale(3);
      expect(s.fontScale, 1.15);
    });
  });
}
