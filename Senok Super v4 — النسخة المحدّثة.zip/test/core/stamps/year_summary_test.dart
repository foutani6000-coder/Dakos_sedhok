import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/storage/settings.dart';
import 'package:senok_app/features/account/year_card_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

Series _series(String id, List<String> genres, {String title = 'عمل'}) => Series(
      id: id,
      title: title,
      chapters: 10,
      rating: 8.5,
      views: 1500,
      genres: genres,
      isNew: false,
    );

Future<SettingsController> _fresh() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  return SettingsController.load();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Prefetch setting', () {
    test('defaults to wifi only and persists the choice', () async {
      final s = await _fresh();
      expect(s.prefetchMode, PrefetchMode.wifi);
      s.setPrefetchMode(PrefetchMode.always);
      expect(s.prefetchMode, PrefetchMode.always);
      s.setPrefetchMode(PrefetchMode.off);
      expect(s.prefetchMode, PrefetchMode.off);
    });
  });

  group('Year summary', () {
    test('empty reader has an empty summary', () async {
      final s = await _fresh();
      final d = YearSummary.of(s);
      expect(d.isEmpty, isTrue);
      expect(d.chapters, 0);
      expect(d.topGenre, isNull);
      expect(d.topTitle, isNull);
    });

    test('counts chapters, days this year and the favourite genre', () async {
      final s = await _fresh();
      s.cacheSeries(_series('a', const ['أكشن'], title: 'الأول'));
      s.cacheSeries(_series('b', const ['دراما'], title: 'الثاني'));
      s.markRead('a', 1);
      s.markRead('a', 2);
      s.markRead('b', 1);
      s.addReadingSeconds('a', 600);
      final d = YearSummary.of(s);
      expect(d.chapters, 3);
      expect(d.daysThisYear, 1);
      expect(d.topGenre, 'أكشن');
      expect(d.topTitle, 'الأول');
      expect(d.toShareText(), contains('3 فصل'));
    });
  });
}
