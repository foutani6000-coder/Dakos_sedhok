import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/stamps/stamps.dart';

void main() {
  test('لكل ختم ملصقان SVG (مفتوح ومقفل)', () {
    for (final d in kStamps) {
      expect(File('assets/stamps/${d.id}.svg').existsSync(), isTrue, reason: 'ملصق ${d.id} مفقود');
      expect(File('assets/stamps/${d.id}_locked.svg').existsSync(), isTrue, reason: 'ملصق ${d.id} المقفل مفقود');
    }
  });
}
