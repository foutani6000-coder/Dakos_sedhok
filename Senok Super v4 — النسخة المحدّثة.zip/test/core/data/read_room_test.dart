import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/data/repository.dart';
import 'package:senok_app/core/data/social_repository.dart';
import 'package:senok_app/features/reader/read_room.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('SardReadRoom.fromJson', () {
    test('يقرأ الصيغة المتداخلة (friend.position)', () {
      final r = SardReadRoom.fromJson({
        'id': 7,
        'chat_id': 'abc',
        'series_id': 's1',
        'series_title': 'عمل',
        'chapter': 3,
        'friend': {
          'id': 'u1',
          'name': 'نورا',
          'online': true,
          'position': {'chapter': 3, 'page': 12, 'total': 30},
        },
      });
      expect(r.id, '7');
      expect(r.chatId, 'abc');
      expect(r.friendName, 'نورا');
      expect(r.friendPage, 12);
      expect(r.friendTotal, 30);
      expect(r.friendOnline, isTrue);
      expect(r.friendKnown, isTrue);
    });

    test('يقبل الصيغة المسطّحة ويشتق chat_id عند غيابه', () {
      final r = SardReadRoom.fromJson({'id': 'x', 'chapter': '2', 'friend_id': 'u2', 'friend_name': 'سيف'});
      expect(r.chatId, 'room_x');
      expect(r.chapter, 2);
      expect(r.friendKnown, isFalse);
    });
  });

  group('القراءة المشتركة في الوضع التجريبي', () {
    final repo = SardRepository();

    test('تنشئ غرفة بدردشة جاهزة وتحدّث موضع الصديق', () async {
      final room = await repo.createReadRoom(
        seriesId: 's1',
        seriesTitle: 'عمل',
        chapter: 4,
        friendId: 'u_nora',
        friendName: 'نورا القارئة',
      );
      expect(room.chatId, startsWith('room_'));
      expect((await repo.chatMessages(room.chatId)), isNotEmpty);
      final fresh = await repo.readRoom(room);
      expect(fresh.friendChapter, 4);
      expect(fresh.friendPage, greaterThanOrEqualTo(1));
      await repo.leaveReadRoom(room.id);
    });
  });

  group('ReadRoomController', () {
    test('يقارن الموضعين ويصوغ الحالة', () async {
      final repo = SardRepository();
      final room = (await repo.createReadRoom(
        seriesId: 's1',
        seriesTitle: 'عمل',
        chapter: 1,
        friendId: 'u1',
        friendName: 'سيف',
      ))
          .copyWith(friendChapter: 1, friendPage: 10, friendTotal: 20);
      final c = ReadRoomController(repo, room);

      c.report(1, 7, 20);
      expect(c.delta, 3);
      expect(c.status, 'أمامك · 3 صفحات');

      c.report(1, 10, 20);
      expect(c.status, 'معك على الصفحة نفسها');

      c.report(1, 14, 20);
      expect(c.delta, -4);
      expect(c.status, startsWith('خلفك'));

      c.report(2, 1, 20);
      expect(c.delta, isNull);
      expect(c.status, 'خلفك · فصل 1');

      c.dispose();
    });

    test('صيغ جمع الصفحات', () {
      expect(readRoomPages(1), 'صفحة');
      expect(readRoomPages(2), 'صفحتين');
      expect(readRoomPages(5), '5 صفحات');
      expect(readRoomPages(15), '15 صفحة');
    });
  });
}
