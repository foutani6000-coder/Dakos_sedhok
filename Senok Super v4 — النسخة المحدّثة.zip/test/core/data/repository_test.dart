import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('SardRepository in mock mode', () {
    final repository = SardRepository();

    test('returns home sections', () async {
      final home = await repository.home();
      expect(home.featured, isNotEmpty);
      expect(home.latest, isNotEmpty);
    });

    test('search returns a list without throwing', () async {
      final results = await repository.search('');
      expect(results, isA<List>());
    });

    test('rating validates its allowed range', () async {
      await expectLater(repository.rateSeries('series-1', 0), throwsArgumentError);
      await expectLater(repository.rateSeries('series-1', 11), throwsArgumentError);
      await repository.rateSeries('series-1', 8);
    });
  });
}
