import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/storage/settings.dart';
import 'package:shared_preferences/shared_preferences.dart';

Series _series(String id, {String title = 'عمل تجريبي'}) => Series(
      id: id,
      title: title,
      chapters: 10,
      rating: 8.5,
      views: 1500,
      genres: const ['خيال'],
      isNew: true,
    );

Future<SettingsController> _fresh() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  return SettingsController.load();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('SettingsController favorites', () {
    test('setFavorite adds, orders newest first and removes', () async {
      final s = await _fresh();
      expect(s.favoriteIds, isEmpty);

      s.setFavorite(_series('a'), true);
      s.setFavorite(_series('b'), true);
      expect(s.isFavorite('a'), isTrue);
      expect(s.isFavorite('b'), isTrue);
      expect(s.favoriteIds, ['b', 'a']);

      s.setFavorite(_series('a'), false);
      expect(s.isFavorite('a'), isFalse);
      expect(s.favoriteIds, ['b']);
    });

    test('adding the same series twice does not duplicate it', () async {
      final s = await _fresh();
      s.setFavorite(_series('a'), true);
      s.setFavorite(_series('b'), true);
      s.setFavorite(_series('a'), true);
      expect(s.favoriteIds, ['a', 'b']);
    });

    test('keeps a cached copy of the series for the shelves', () async {
      final s = await _fresh();
      s.setFavorite(_series('a', title: 'اسم محفوظ'), true);
      final cached = s.cachedSeries('a');
      expect(cached, isNotNull);
      expect(cached!.title, 'اسم محفوظ');
      expect(s.cachedSeries('missing'), isNull);
    });
  });

  group('SettingsController read later', () {
    test('setReadLater adds and removes independently of favorites', () async {
      final s = await _fresh();
      s.setReadLater(_series('a'), true);
      s.setReadLater(_series('b'), true);
      expect(s.laterIds, ['b', 'a']);
      expect(s.isReadLater('a'), isTrue);
      expect(s.isFavorite('a'), isFalse);

      s.setReadLater(_series('b'), false);
      expect(s.laterIds, ['a']);
      expect(s.isReadLater('b'), isFalse);
    });

    test('favorites and read later survive reloading from storage', () async {
      final s = await _fresh();
      s.setFavorite(_series('a'), true);
      s.setReadLater(_series('b'), true);

      final again = await SettingsController.load();
      expect(again.favoriteIds, ['a']);
      expect(again.laterIds, ['b']);
    });
  });

  group('SettingsController reading shelf', () {
    test('readingIds lists series with progress, newest first', () async {
      final s = await _fresh();
      expect(s.readingIds, isEmpty);

      s.saveProgress('a', 1, 3, 10);
      s.saveProgress('b', 2, 5, 12);
      expect(s.readingIds, ['b', 'a']);

      // قراءة عمل «a» من جديد تعيده إلى المقدمة
      s.saveProgress('a', 1, 4, 10);
      expect(s.readingIds, ['a', 'b']);
    });

    test('removeProgress deletes only the chosen series', () async {
      final s = await _fresh();
      s.saveProgress('a', 1, 3, 10);
      s.saveProgress('b', 2, 5, 12);

      s.removeProgress('a');
      expect(s.progressOf('a'), isNull);
      expect(s.readingIds, ['b']);
      expect(s.progressOf('b')!.chapter, 2);
      expect(s.progressOf('b')!.page, 5);
    });

    test('removeProgress is saved and removing a missing id is harmless', () async {
      final s = await _fresh();
      s.saveProgress('a', 1, 3, 10);
      s.removeProgress('a');
      s.removeProgress('does-not-exist');

      final again = await SettingsController.load();
      expect(again.readingIds, isEmpty);
    });
  });
}
