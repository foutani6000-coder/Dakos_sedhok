import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';

void main() {
  group('Chapter.fromJson', () {
    test('يقبل number كنص و pages كقائمة', () {
      final c = Chapter.fromJson({'number': '12', 'title': 'البداية', 'pages': ['a', 'b', 'c'], 'created_at': '2026/11/01'});
      expect(c.number, 12);
      expect(c.pages, 3);
      expect(c.date, '2026/11/01');
    });

    test('يستخرج الرقم من العنوان إن غاب number', () {
      expect(Chapter.fromJson({'title': 'فصل 7'}).number, 7);
    });
  });

  group('PageSrc.fromJson', () {
    test('يقبل نصاً أو كائناً', () {
      expect(PageSrc.fromJson('u').url, 'u');
      expect(PageSrc.fromJson({'url': 'u', 'low': 'l'}).low, 'l');
      expect(PageSrc.fromJson({'image': 'i'}).url, 'i');
    });
  });
}
