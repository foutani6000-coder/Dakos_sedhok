import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/data/search_filters.dart';

void main() {
  const a = Series(id: 'a', title: 'A', type: 'مانهوا كورية', chapters: 24, rating: 9.1, views: 900000, genres: ['أكشن', 'دراما'], year: 2024);
  const b = Series(id: 'b', title: 'B', type: 'مانغا يابانية', status: 'مكتمل', chapters: 182, rating: 8.2, views: 2100000, genres: ['دراما', 'فانتازيا'], year: 2020);
  const c = Series(id: 'c', title: 'C', type: 'مانهوا صينية', chapters: 240, rating: 7.4, views: 50000, genres: ['أكشن'], year: 2022);
  const all = [a, b, c];

  test('فلتر عدد الفصول', () {
    expect(const SearchFilters(chaptersMin: 100).apply(all).map((s) => s.id), containsAll(['b', 'c']));
    expect(const SearchFilters(chaptersMax: 40).apply(all).map((s) => s.id), ['a']);
  });

  test('النوع والحالة والتقييم', () {
    expect(const SearchFilters(types: {'مانغا يابانية'}).apply(all).length, 1);
    expect(const SearchFilters(statuses: {'مكتمل'}).apply(all).single.id, 'b');
    expect(const SearchFilters(minRating: 8).apply(all).length, 2);
  });

  test('التصنيفات: الكل مقابل أي واحد + الاستبعاد', () {
    expect(const SearchFilters(genres: {'أكشن', 'دراما'}).apply(all).single.id, 'a');
    expect(const SearchFilters(genres: {'أكشن', 'دراما'}, matchAllGenres: false).apply(all).length, 3);
    expect(const SearchFilters(exclude: {'أكشن'}).apply(all).single.id, 'b');
  });

  test('الترتيب وعدد الفلاتر المفعّلة', () {
    expect(const SearchFilters(sort: 'chapters').apply(all).first.id, 'c');
    expect(const SearchFilters(chaptersMin: 10, minRating: 8, sort: 'views').activeCount, 2);
    expect(SearchFilters.none.isActive, false);
  });
}
