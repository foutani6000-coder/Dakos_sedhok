import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';

void main() {
  group('formatCount', () {
    test('keeps values below one thousand exact', () {
      expect(formatCount(0), '0');
      expect(formatCount(999), '999');
    });

    test('formats thousands and millions compactly', () {
      expect(formatCount(1000), '1 ألف');
      expect(formatCount(12500), '12.5 ألف');
      expect(formatCount(1000000), '1 م');
      expect(formatCount(1250000), '1.3 م');
    });
  });

  group('Series.fromJson', () {
    test('parses values and applies safe defaults', () {
      final series = Series.fromJson({
        'id': 42,
        'title': 'اختبار',
        'chapters': 18,
        'rating': 8.7,
        'views': 12000,
        'genres': ['خيال', 'مغامرة'],
        'is_new': true,
        'year': '2024',
      });

      expect(series.id, '42');
      expect(series.title, 'اختبار');
      expect(series.chapters, 18);
      expect(series.rating, 8.7);
      expect(series.views, 12000);
      expect(series.genres, ['خيال', 'مغامرة']);
      expect(series.isNew, isTrue);
      expect(series.year, 2024);
    });

    test('handles missing optional fields', () {
      final series = Series.fromJson({'id': 'x', 'title': 'عمل'});
      expect(series.status, 'مستمر');
      expect(series.chapters, 0);
      expect(series.genres, isEmpty);
      expect(series.year, 2025);
    });
  });

  group('Series toJson/fromJson round trip', () {
    void expectSame(Series a, Series b) {
      expect(b.id, a.id);
      expect(b.title, a.title);
      expect(b.cover, a.cover);
      expect(b.type, a.type);
      expect(b.status, a.status);
      expect(b.chapters, a.chapters);
      expect(b.rating, a.rating);
      expect(b.views, a.views);
      expect(b.genres, a.genres);
      expect(b.synopsis, a.synopsis);
      expect(b.isNew, a.isNew);
      expect(b.year, a.year);
    }

    test('keeps every field after a full round trip', () {
      const original = Series(
        id: 'series-7',
        title: 'Senok الحبر',
        cover: 'https://example.com/cover.jpg',
        type: 'مانغا يابانية',
        status: 'مكتمل',
        chapters: 120,
        rating: 9.1,
        views: 3400000,
        genres: ['أكشن', 'دراما'],
        synopsis: 'ملخص تجريبي للعمل.',
        isNew: true,
        year: 2021,
      );
      expectSame(original, Series.fromJson(original.toJson()));
    });

    test('keeps defaults and a null cover', () {
      const original = Series(id: 'x', title: 'عمل بسيط');
      final copy = Series.fromJson(original.toJson());
      expect(copy.cover, isNull);
      expectSame(original, copy);
    });

    test('survives a second round trip unchanged', () {
      const original = Series(id: '9', title: 'ثنائي', rating: 7.5, genres: ['خيال']);
      final once = Series.fromJson(original.toJson());
      final twice = Series.fromJson(once.toJson());
      expectSame(once, twice);
    });
  });
}
