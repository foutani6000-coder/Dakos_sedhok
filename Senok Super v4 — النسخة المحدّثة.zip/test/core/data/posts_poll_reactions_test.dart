import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';

void main() {
  test('reaction counts move between types', () {
    const p = SardPost(id: '1', author: 'a', body: 'b', createdAt: 'x', reactions: {SardReaction.like: 2});
    final a = p.react(SardReaction.love);
    expect(a.likes, 3);
    expect(a.myReaction, SardReaction.love);
    final b = a.react(SardReaction.wow);
    expect(b.reactions[SardReaction.love], 0);
    expect(b.reactions[SardReaction.wow], 1);
    final c = b.react(null);
    expect(c.likes, 2);
    expect(c.myReaction, isNull);
  });

  test('poll vote, change and withdraw', () {
    const poll = SardPoll(question: 'q', options: [
      SardPollOption(id: 'a', text: 'A', votes: 1),
      SardPollOption(id: 'b', text: 'B', votes: 1),
    ]);
    final v1 = poll.withVote('a');
    expect(v1.totalVotes, 3);
    final v2 = v1.withVote('b');
    expect(v2.options[0].votes, 1);
    expect(v2.options[1].votes, 2);
    final v3 = v2.withVote(null);
    expect(v3.totalVotes, 2);
    expect(v3.myVote, isNull);
  });

  test('post json parsing', () {
    final p = SardPost.fromJson({
      'id': 7, 'body': 'hi', 'images': ['http://x/1.jpg'],
      'reactions': {'like': 3, 'sad': 1}, 'my_reaction': 'sad',
      'poll': {'question': 'q', 'options': [{'id': 1, 'text': 'A', 'votes': 4}], 'my_vote': 1},
    });
    expect(p.likes, 4);
    expect(p.myReaction, SardReaction.sad);
    expect(p.poll!.myVote, '1');
    expect(p.images.length, 1);
  });
}
