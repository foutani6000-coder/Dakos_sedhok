import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/repository.dart';
import 'package:senok_app/core/data/social_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('SardSocialRepository in mock mode', () {
    final repo = SardRepository();

    test('returns posts and can add one', () async {
      final before = (await repo.posts()).length;
      await repo.addPost('منشور تجريبي');
      expect((await repo.posts()).length, before + 1);
    });

    test('returns chats and appends sent messages', () async {
      final chats = await repo.chats();
      expect(chats, isNotEmpty);
      final id = chats.first.id;
      final before = (await repo.chatMessages(id)).length;
      await repo.sendMessage(id, 'مرحباً');
      expect((await repo.chatMessages(id)).length, before + 1);
    });
  });
}
