import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';

void main() {
  test('badge parsing', () {
    expect(SardBadge.fromJson('purple'), SardBadge.purple);
    expect(SardBadge.fromJson('أزرق'), SardBadge.blue);
    expect(SardBadge.fromJson('gold'), SardBadge.yellow);
    expect(SardBadge.fromJson(true), SardBadge.blue);
    expect(SardBadge.fromJson(null), SardBadge.none);
  });

  test('reading time format', () {
    expect(formatReadingTime(0), '0 د');
    expect(formatReadingTime(30), 'أقل من دقيقة');
    expect(formatReadingTime(5400), '1 س 30 د');
    expect(readingHoursLabel(5400), '1.5');
  });
}
