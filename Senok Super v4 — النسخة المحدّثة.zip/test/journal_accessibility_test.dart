/// اختبارات وحدة اليوميات + إمكانية الوصول في Senok.
/// تغطي: مخزن اليوميات، مراجعة السنة، الاقتباسات، ممر الذكريات،
/// الموجز الذكي، الوضع العائلي، وحزمة الوصول — كلها ضد الواجهات
/// الحقيقية فقط، وبلا أي افتراض لدوال غير موجودة.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:senok_app/core/accessibility/accessibility_suite.dart';
import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/storage/settings.dart';
import 'package:senok_app/features/journal/family_mode.dart';
import 'package:senok_app/features/journal/memory_lane.dart';
import 'package:senok_app/features/journal/quotes_collection.dart';
import 'package:senok_app/features/journal/reading_journal.dart';
import 'package:senok_app/features/journal/smart_digest.dart';
import 'package:senok_app/features/journal/year_in_review.dart';

/// بيئة اختبار كاملة: كل المخازن على التفضيلات المزيفة نفسها.
class _Env {
  _Env(
    this.prefs,
    this.settings,
    this.journal,
    this.quotes,
    this.digests,
    this.family,
    this.a11y,
  );

  final SharedPreferences prefs;
  final SettingsController settings;
  final JournalStore journal;
  final QuoteStore quotes;
  final DigestStore digests;
  final FamilyStore family;
  final A11yStore a11y;
}

/// يبذر التفضيلات بمفاتيح [seed] ثم يفتح كل المخازن.
Future<_Env> _loadEnv({Map<String, Object>? seed}) async {
  SharedPreferences.setMockInitialValues(seed ?? const <String, Object>{});
  final prefs = await SharedPreferences.getInstance();
  final settings = await SettingsController.load();
  return _Env(
    prefs,
    settings,
    JournalStore.forPrefs(prefs),
    QuoteStore.forPrefs(prefs),
    DigestStore.forPrefs(prefs),
    FamilyStore.forPrefs(prefs),
    A11yStore.forPrefs(prefs),
  );
}

/// بذور إعدادات قراءة واقعية: ثوانٍ وفصول وأيام قراءة ومتابَعات.
Map<String, Object> _readingSeed({
  String seconds = '{"s1": 3600, "s2": 1800}',
  String chapters = '{"s1": [1, 2, 3], "s2": [1]}',
  List<String> days = const ['2026-11-20', '2026-11-21', '2026-11-25'],
  List<String> followed = const ['s1', 's2'],
  String cache = '{"s1": {"genres": ["أكشن"]}, "s2": {"genres": ["أكشن", "دراما"]}}',
}) =>
    <String, Object>{
      'reading_seconds': seconds,
      'read_chapters': chapters,
      'read_days': days,
      'followed_series': followed,
      'series_cache': cache,
    };

void main() {
  group('JournalStore — الأساسيات', () {
    test('إضافة إدخال ثم قراءته (الأحدث أولاً)', () async {
      final env = await _loadEnv();
      final first = await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'عمل أول',
        chapter: 3,
        text: 'فصل قوي',
        mood: JournalMood.amazing,
        rating: 5,
        at: DateTime(2026, 11, 20, 10),
      );
      await env.journal.add(
        seriesId: 's2',
        seriesTitle: 'عمل ثانٍ',
        chapter: 1,
        text: 'بداية جيدة',
        mood: JournalMood.calm,
        rating: 4,
        at: DateTime(2026, 11, 25, 10),
      );
      expect(env.journal.length, 2);
      expect(env.journal.entries.first.seriesTitle, 'عمل ثانٍ');
      expect(env.journal.entries.last.id, first.id);
      expect(env.journal.entries.last.seriesTitle, 'عمل أول');
      expect(first.chapter, 3);
      expect(first.rating, 5);
      expect(first.starsLabel, '★★★★★');
      expect(first.chapterLabel, 'الفصل 3');
    });

    test('ملاحظة بلا فصل وبلا تقييم', () async {
      final env = await _loadEnv();
      final e = await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'عمل',
        text: 'ملاحظة عامة',
      );
      expect(e.chapter, 0);
      expect(e.chapterLabel, 'ملاحظة عامة');
      expect(e.hasRating, isFalse);
      expect(e.hasChapter, isFalse);
      expect(e.starsLabel, '☆☆☆☆☆');
      expect(e.mood, JournalMood.calm);
    });

    test('التقييم يُقلَّم إلى 0..5', () async {
      final env = await _loadEnv();
      final high = await env.journal.add(
          seriesId: 's1', seriesTitle: 'عمل', rating: 99);
      final low = await env.journal.add(
          seriesId: 's1', seriesTitle: 'عمل', rating: -3);
      expect(high.rating, 5);
      expect(low.rating, 0);
    });

    test('تحديث إدخال وحذفه', () async {
      final env = await _loadEnv();
      final e = await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'عمل',
        chapter: 1,
        text: 'قديم',
        rating: 2,
      );
      final ok = await env.journal.update(e.copyWith(
        text: 'جديد',
        rating: 5,
        mood: JournalMood.happy,
      ));
      expect(ok, isTrue);
      expect(env.journal.entries.single.text, 'جديد');
      expect(env.journal.entries.single.rating, 5);
      expect(env.journal.entries.single.mood, JournalMood.happy);

      expect(await env.journal.update(e.copyWith(id: 'غير_موجود')), isFalse);
      expect(await env.journal.remove('غير_موجود'), isFalse);
      expect(await env.journal.remove(e.id), isTrue);
      expect(env.journal.isEmpty, isTrue);
    });

    test('إدخالات عمل محدد فقط', () async {
      final env = await _loadEnv();
      await env.journal.add(seriesId: 's1', seriesTitle: 'ألف');
      await env.journal.add(seriesId: 's2', seriesTitle: 'باء');
      await env.journal.add(seriesId: 's1', seriesTitle: 'ألف');
      expect(env.journal.entriesForSeries('s1').length, 2);
      expect(env.journal.entriesForSeries('s2').length, 1);
      expect(env.journal.entriesForSeries('s3'), isEmpty);
    });

    test('إحصاءات: المجموع والمزاج والأعلى والمتوسط', () async {
      final env = await _loadEnv();
      await env.journal.add(
          seriesId: 's1', seriesTitle: 'ألف', mood: JournalMood.happy, rating: 4);
      await env.journal.add(
          seriesId: 's1', seriesTitle: 'ألف', mood: JournalMood.happy, rating: 5);
      await env.journal.add(
          seriesId: 's2', seriesTitle: 'باء', mood: JournalMood.sad, rating: 0);
      final stats = env.journal.stats;
      expect(stats.total, 3);
      expect(stats.perMood[JournalMood.happy], 2);
      expect(stats.perMood[JournalMood.sad], 1);
      expect(stats.topSeriesTitle, 'ألف');
      expect(stats.averageRating, 4.5);
      expect(stats.ratedCount, 2);
      expect(stats.totalChapters, 0);
      expect(stats.dominantMood, JournalMood.happy);
    });

    test('إحصاءات فارغة: متوسط 0 وبلا أعلى', () async {
      final env = await _loadEnv();
      final stats = env.journal.stats;
      expect(stats.total, 0);
      expect(stats.averageRating, 0.0);
      expect(stats.averageRatingLabel, '—');
      expect(stats.topSeriesTitle, isNull);
      expect(stats.dominantMood, isNull);
    });

    test('بحث نصي في الملاحظات والاقتباسات والعناوين', () async {
      final env = await _loadEnv();
      await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'سولو ليفلينغ',
        text: 'قتال مذهل',
        quote: 'انهض مجدداً',
      );
      await env.journal.add(
        seriesId: 's2',
        seriesTitle: 'عمل آخر',
        text: 'هدوء جميل',
      );
      expect(env.journal.search('قتال').length, 1);
      expect(env.journal.search('انهض').length, 1);
      expect(env.journal.search('سولو').length, 1);
      expect(env.journal.search('غير_موجود'), isEmpty);
      expect(env.journal.search('').length, 2);
    });

    test('في مثل هذا اليوم: سنوات سابقة فقط', () async {
      final env = await _loadEnv();
      await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'قديم',
        at: DateTime(2025, 11, 26, 10),
      );
      await env.journal.add(
        seriesId: 's2',
        seriesTitle: 'اليوم',
        at: DateTime(2026, 11, 26, 10),
      );
      await env.journal.add(
        seriesId: 's3',
        seriesTitle: 'يوم آخر',
        at: DateTime(2025, 11, 25, 10),
      );
      final list = env.journal.onThisDay(today: DateTime(2026, 11, 26));
      expect(list.length, 1);
      expect(list.single.seriesTitle, 'قديم');
    });

    test('آخر نشاط لكل عمل', () async {
      final env = await _loadEnv();
      await env.journal.add(
          seriesId: 's1', seriesTitle: 'ألف', at: DateTime(2026, 1, 1));
      await env.journal.add(
          seriesId: 's1', seriesTitle: 'ألف', at: DateTime(2026, 5, 1));
      await env.journal.add(
          seriesId: 's2', seriesTitle: 'باء', at: DateTime(2026, 3, 1));
      final last = env.journal.lastActivityBySeries();
      expect(last['s1'], DateTime(2026, 5, 1));
      expect(last['s2'], DateTime(2026, 3, 1));
      expect(last.length, 2);
    });

    test('تصدير نصي يبدأ بالترويسة ثم استيراد JSON ذهاباً وإياباً',
        () async {
      final env = await _loadEnv();
      await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'ألف',
        chapter: 7,
        text: 'ملاحظة',
        quote: 'سطر جميل',
        mood: JournalMood.amazing,
        rating: 5,
        at: DateTime(2026, 11, 25),
      );
      final text = env.journal.exportText();
      expect(text, startsWith('يومياتي في القراءة على Senok'));
      expect(text, contains('ألف'));
      expect(text, contains('الفصل 7'));
      expect(text, contains('«سطر جميل»'));

      final json = env.journal.exportJson();
      final env2 = await _loadEnv();
      expect(await env2.journal.importJson(json), 1);
      expect(env2.journal.entries.single.seriesTitle, 'ألف');
      expect(env2.journal.entries.single.rating, 5);
      // إعادة الاستيراد نفسه لا تكرر الإدخالات.
      expect(await env2.journal.importJson(json), 0);
      expect(await env2.journal.importJson('ليس json'), 0);
      expect(await env2.journal.importJson('{"a": 1}'), 0);
    });

    test('إدخالات نطاق زمني وسنة وشهر', () async {
      final env = await _loadEnv();
      await env.journal.add(
          seriesId: 's1', seriesTitle: 'أ', at: DateTime(2026, 3, 5));
      await env.journal.add(
          seriesId: 's1', seriesTitle: 'أ', at: DateTime(2026, 3, 20));
      await env.journal.add(
          seriesId: 's1', seriesTitle: 'أ', at: DateTime(2025, 3, 5));
      expect(env.journal.entriesInYear(2026).length, 2);
      expect(env.journal.entriesInYear(2025).length, 1);
      expect(env.journal.entriesInMonth(2026, 3).length, 2);
      expect(env.journal.entriesInMonth(2026, 4), isEmpty);
      expect(
        env.journal
            .entriesInRange(DateTime(2026, 3, 1), DateTime(2026, 3, 10))
            .length,
        1,
      );
      expect(env.journal.distinctDays, 3);
    });
  });

  group('JournalMood — القيم والتسميات', () {
    test('خمس قيم فقط بتسميات عربية', () {
      expect(JournalMood.values.length, 5);
      expect(JournalMood.amazing.label, 'مذهل');
      expect(JournalMood.happy.label, 'سعيد');
      expect(JournalMood.calm.label, 'هادئ');
      expect(JournalMood.tense.label, 'متوتر');
      expect(JournalMood.sad.label, 'حزين');
      expect(JournalMood.fromKey('happy'), JournalMood.happy);
      expect(JournalMood.fromKey('غير_معروف'), JournalMood.calm);
      expect(JournalMood.fromKey(null), JournalMood.calm);
    });
  });

  group('YearInReviewData — مراجعة السنة', () {
    test('يبني المراجعة من الإعدادات واليوميات', () async {
      final env = await _loadEnv(seed: _readingSeed());
      await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'ألف',
        chapter: 1,
        rating: 4,
        mood: JournalMood.happy,
        at: DateTime(2026, 3, 5),
      );
      await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'ألف',
        chapter: 2,
        rating: 5,
        mood: JournalMood.happy,
        at: DateTime(2026, 3, 20),
      );
      await env.journal.add(
        seriesId: 's2',
        seriesTitle: 'باء',
        chapter: 1,
        rating: 0,
        at: DateTime(2026, 5, 2),
      );
      final data = YearInReviewData.of(
        env.settings,
        env.journal,
        env.quotes,
        year: 2026,
      );
      // من بذور الإعدادات: 4 فصول، 5400 ثانية = 90 دقيقة، 3 أيام قراءة.
      expect(data.chapters, 4);
      expect(data.minutes, 90);
      expect(data.days, 3);
      expect(data.journalEntries, 3);
      expect(data.bestMonth, 3);
      expect(data.bestMonthName, 'مارس');
      expect(data.averageRating, 4.5);
      expect(data.monthlyDistributionEstimated[2], 2);
      expect(data.monthlyDistributionEstimated[4], 1);
      expect(data.monthlyDistributionEstimated[0], 0);
      expect(data.topSeriesTitle, 'ألف');
      expect(data.hoursLabel, '1.5');
      expect(data.toShareText(), contains('2026'));
      expect(data.toShareText(), contains('Senok'));
      expect(data.toShareText(), contains('مارس'));
    });

    test('بلا إدخالات: أفضل شهر 0 واسمه — ومتوسط 0.0', () async {
      final env = await _loadEnv(seed: _readingSeed(days: const []));
      final data = YearInReviewData.of(
        env.settings,
        env.journal,
        env.quotes,
        year: 2026,
      );
      expect(data.bestMonth, 0);
      expect(data.bestMonthName, '—');
      expect(data.averageRating, 0.0);
      expect(data.averageRatingLabel, '—');
      expect(data.journalEntries, 0);
      expect(data.days, 0);
      expect(data.maxMonthValue, 0);
    });
  });

  group('QuoteStore — الاقتباسات', () {
    test('إضافة وحذف وتبديل المفضلة', () async {
      final env = await _loadEnv();
      final q = await env.quotes.add(
        text: 'سطر جميل',
        seriesTitle: 'عمل',
        chapter: 4,
        category: QuoteCategory.epic,
      );
      expect(env.quotes.length, 1);
      expect(q.sourceLabel, 'عمل — الفصل 4');
      expect(await env.quotes.toggleFavorite(q.id), isTrue);
      expect(env.quotes.favorites.length, 1);
      expect(await env.quotes.toggleFavorite(q.id), isFalse);
      expect(env.quotes.favorites, isEmpty);
      expect(await env.quotes.toggleFavorite('غير_موجود'), isNull);
      expect(await env.quotes.remove('غير_موجود'), isFalse);
      expect(await env.quotes.remove(q.id), isTrue);
      expect(env.quotes.isEmpty, isTrue);
    });

    test('التصنيفات الستة والتصفية بها', () async {
      final env = await _loadEnv();
      expect(QuoteCategory.values.length, 6);
      await env.quotes.add(text: 'أ', category: QuoteCategory.wisdom);
      await env.quotes.add(text: 'ب', category: QuoteCategory.wisdom);
      await env.quotes.add(text: 'ج', category: QuoteCategory.funny);
      expect(env.quotes.byCategory(QuoteCategory.wisdom).length, 2);
      expect(env.quotes.byCategory(QuoteCategory.funny).length, 1);
      expect(env.quotes.byCategory(QuoteCategory.sad), isEmpty);
      expect(env.quotes.countsByCategory[QuoteCategory.wisdom], 2);
      expect(QuoteCategory.fromKey('romantic'), QuoteCategory.romantic);
      expect(QuoteCategory.fromKey('خطأ'), QuoteCategory.wisdom);
    });

    test('بحث ومشاركة', () async {
      final env = await _loadEnv();
      final q = await env.quotes.add(
        text: 'النور يولد من الظلام',
        seriesTitle: 'عمل الظلام',
        category: QuoteCategory.epic,
      );
      expect(env.quotes.search('النور').length, 1);
      expect(env.quotes.search('الظلام').length, 1);
      expect(env.quotes.search('غير_موجود'), isEmpty);
      final shared = env.quotes.shareText(q);
      expect(shared, contains('«النور يولد من الظلام»'));
      expect(shared, contains('عمل الظلام'));
      expect(shared, contains('#Senok'));
    });

    test('اقتباس اليوم حتمي: البذرة = سنة×372 + شهر×31 + يوم', () async {
      final env = await _loadEnv();
      await env.quotes.add(
          text: 'الأول', category: QuoteCategory.wisdom, at: DateTime(2026, 1, 1));
      await env.quotes.add(
          text: 'الثاني',
          category: QuoteCategory.motivational,
          at: DateTime(2026, 1, 2));
      await env.quotes.add(
          text: 'الثالث', category: QuoteCategory.funny, at: DateTime(2026, 1, 3));
      // الترتيب الداخلي (الأحدث أولاً): الثالث، الثاني، الأول.
      final day = DateTime(2026, 11, 26);
      final seed = day.year * 372 + day.month * 31 + day.day;
      expect(seed, 754039);
      expect(seed % 3, 1);
      final first = env.quotes.quoteOfDay(day: day);
      final second = env.quotes.quoteOfDay(day: day);
      expect(first, isNotNull);
      expect(first, second);
      expect(first!.text, 'الثاني');
      // يوم آخر قد يعطي اقتباساً آخر، لكنه ثابت أيضاً.
      final other = env.quotes.quoteOfDay(day: DateTime(2026, 11, 27));
      expect(other, env.quotes.quoteOfDay(day: DateTime(2026, 11, 27)));
    });

    test('اقتباس اليوم null عند عدم وجود اقتباسات', () async {
      final env = await _loadEnv();
      expect(env.quotes.quoteOfDay(), isNull);
    });

    test('استيراد JSON يتخطى المكرر', () async {
      final env = await _loadEnv();
      await env.quotes.add(text: 'سطر', category: QuoteCategory.wisdom);
      final json = env.quotes.exportJson();
      final env2 = await _loadEnv();
      expect(await env2.quotes.importJson(json), 1);
      expect(await env2.quotes.importJson(json), 0);
      expect(await env2.quotes.importJson('خطأ'), 0);
    });
  });

  group('MemoryLaneEngine — ممر الذكريات', () {
    test('في مثل هذا اليوم وقبل شهر وإعادة اكتشاف', () async {
      final env = await _loadEnv();
      final today = DateTime(2026, 11, 26);
      final entries = <JournalEntry>[
        JournalEntry(
          id: 'e1',
          seriesId: 's-same',
          seriesTitle: 'عمل السنة الماضية',
          chapter: 5,
          text: 'قراءة قديمة',
          mood: JournalMood.happy,
          rating: 5,
          at: DateTime(2025, 11, 26, 10),
        ),
        JournalEntry(
          id: 'e2',
          seriesId: 's-month',
          seriesTitle: 'عمل الشهر الماضي',
          chapter: 2,
          text: '',
          mood: JournalMood.calm,
          rating: 0,
          at: DateTime(2026, 10, 27, 10),
        ),
        JournalEntry(
          id: 'e3',
          seriesId: 's-old',
          seriesTitle: 'عمل منسي',
          chapter: 9,
          text: '',
          mood: JournalMood.calm,
          rating: 0,
          at: DateTime(2026, 6, 1, 10),
        ),
      ];
      final memories = MemoryLaneEngine.build(
        entries: entries,
        settings: env.settings,
        today: today,
      );
      final kinds = memories.map((m) => m.kind).toSet();
      expect(kinds, contains(MemoryKind.sameDay));
      expect(kinds, contains(MemoryKind.monthAgo));
      expect(kinds, contains(MemoryKind.rediscover));
      final same = memories.firstWhere((m) => m.kind == MemoryKind.sameDay);
      expect(same.seriesId, 's-same');
      expect(same.seriesTitle, 'عمل السنة الماضية');
      expect(same.daysAgo, 365);
      final old = memories.firstWhere((m) => m.kind == MemoryKind.rediscover);
      expect(old.seriesId, 's-old');
      expect(old.agoLabel, contains('شهر'));
    });

    test('يوم قراءة من سجل الأيام بلا إدخال يومية', () async {
      final env = await _loadEnv(
        seed: _readingSeed(days: const ['2024-11-26', '2026-11-20']),
      );
      final memories = MemoryLaneEngine.build(
        entries: const [],
        settings: env.settings,
        today: DateTime(2026, 11, 26),
      );
      expect(memories.map((m) => m.kind), contains(MemoryKind.readDay));
      final day = memories.firstWhere((m) => m.kind == MemoryKind.readDay);
      expect(day.date, DateTime(2024, 11, 26));
      expect(day.seriesId, '');
    });

    test('بلا بيانات: لا ذكريات', () async {
      final env = await _loadEnv();
      final memories = MemoryLaneEngine.build(
        entries: const [],
        settings: env.settings,
        today: DateTime(2026, 11, 26),
      );
      expect(memories, isEmpty);
    });

    test('الحد الأقصى 8 ذكريات', () async {
      final env = await _loadEnv();
      final entries = List<JournalEntry>.generate(
        12,
        (i) => JournalEntry(
          id: 'old$i',
          seriesId: 's-old$i',
          seriesTitle: 'عمل $i',
          chapter: 1,
          text: '',
          mood: JournalMood.calm,
          rating: 0,
          at: DateTime(2026, 1, 1).add(Duration(days: i)),
        ),
      );
      final memories = MemoryLaneEngine.build(
        entries: entries,
        settings: env.settings,
        today: DateTime(2026, 11, 26),
      );
      expect(memories.length, lessThanOrEqualTo(8));
    });
  });

  group('DigestBuilder و DigestStore — الموجز الذكي', () {
    test('يبني موجزاً أسبوعياً من يوميات الفترة فقط', () async {
      final env = await _loadEnv(seed: _readingSeed());
      await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'ألف',
        chapter: 5,
        at: DateTime(2026, 11, 25, 10),
      );
      await env.journal.add(
        seriesId: 's1',
        seriesTitle: 'ألف',
        chapter: 0,
        at: DateTime(2026, 11, 24, 10),
      );
      await env.journal.add(
        seriesId: 's2',
        seriesTitle: 'باء',
        chapter: 3,
        at: DateTime(2026, 11, 10, 10),
      );
      await env.quotes.add(
        text: 'اقتباس جديد',
        at: DateTime(2026, 11, 25, 11),
      );
      final digest = DigestBuilder.build(
        settings: env.settings,
        journal: env.journal,
        quotes: env.quotes,
        period: DigestPeriod.weekly,
        now: DateTime(2026, 11, 26, 12),
      );
      // فصل واحد بفصل>0 داخل الفترة + ملاحظتان داخل الفترة.
      expect(digest.chaptersRead, 1);
      expect(digest.journalEntries, 2);
      expect(digest.minutesEstimate, 1 * 8 + 2 * 2);
      expect(digest.newQuotes, 1);
      expect(digest.topGenre, 'أكشن');
      expect(digest.topSeriesTitle, 'ألف');
      expect(digest.followedCount, 2);
      expect(digest.recommendationTitle, contains('ألف'));
      expect(digest.recommendationReason, isNotEmpty);
      expect(digest.periodLabel, contains('نوفمبر 2026'));
      expect(digest.toShareText(), startsWith('موجزي في القراءة على Senok'));
    });

    test('موجز بلا نشاط: توصية البداية ونص صادق', () async {
      final env = await _loadEnv();
      final digest = DigestBuilder.build(
        settings: env.settings,
        journal: env.journal,
        quotes: env.quotes,
        period: DigestPeriod.daily,
        now: DateTime(2026, 11, 26),
      );
      expect(digest.hasActivity, isFalse);
      expect(digest.chaptersRead, 0);
      expect(digest.minutesEstimate, 0);
      expect(digest.topGenre, isNull);
      expect(digest.recommendationTitle, 'ابدأ أول فصل اليوم');
      expect(digest.periodLabel, contains('26 نوفمبر 2026'));
      expect(digest.toShareText(), contains('لم أقرأ شيئاً'));
    });

    test('المخزن يحتفظ بآخر 4 موجزات فقط', () async {
      final env = await _loadEnv(seed: _readingSeed());
      for (var i = 0; i < 5; i++) {
        await env.digests.generate(
          settings: env.settings,
          journal: env.journal,
          quotes: env.quotes,
          period: DigestPeriod.values[i % 3],
          now: DateTime(2026, 11, 20 + i),
        );
      }
      expect(env.digests.digests.length, 4);
      expect(env.digests.latest, isNotNull);
      final id = env.digests.latest!.id;
      expect(await env.digests.remove('غير_موجود'), isFalse);
      expect(await env.digests.remove(id), isTrue);
      expect(env.digests.digests.length, 3);
    });

    test('تسميات الفترات', () {
      expect(DigestPeriod.daily.label, 'اليوم');
      expect(DigestPeriod.weekly.label, 'هذا الأسبوع');
      expect(DigestPeriod.monthly.label, 'هذا الشهر');
      expect(DigestPeriod.fromKey('monthly'), DigestPeriod.monthly);
      expect(DigestPeriod.fromKey('خطأ'), DigestPeriod.weekly);
    });
  });

  group('FamilyStore — الوضع العائلي', () {
    test('التصنيف العمري التقديري من التصنيفات', () {
      const horror = Series(id: 'h', title: 'رعب', genres: ['رعب']);
      const crime = Series(id: 'c', title: 'جريمة', genres: ['جريمة']);
      const romance = Series(id: 'r', title: 'رومانسي', genres: ['رومانسي']);
      const action = Series(id: 'a', title: 'أكشن', genres: ['أكشن']);
      const plain = Series(id: 'p', title: 'عام');
      expect(ageRatingForSeries(horror), 16);
      expect(ageRatingForSeries(crime), 13);
      expect(ageRatingForSeries(romance), 12);
      expect(ageRatingForSeries(action), 7);
      expect(ageRatingForSeries(plain), 7);
      expect(isSeriesAllowedForAge(horror, 16), isTrue);
      expect(isSeriesAllowedForAge(horror, 15), isFalse);
      expect(isSeriesAllowedForAge(crime, 13), isTrue);
      expect(isSeriesAllowedForAge(romance, 12), isTrue);
      expect(isSeriesAllowedForAge(action, 7), isTrue);
      expect(isSeriesAllowedForAge(action, 6), isFalse);
    });

    test('إضافة طفل: الحد الافتراضي 60 دقيقة', () async {
      final env = await _loadEnv();
      final child = await env.family.addChild(name: 'سارة', age: 9);
      expect(child.dailyLimitMinutes, 60);
      expect(child.age, 9);
      expect(env.family.children.length, 1);
      expect(env.family.childById(child.id)?.name, 'سارة');
      expect(env.family.childById('غير_موجود'), isNull);
    });

    test('تسجيل القراءة والتقرير الأسبوعي', () async {
      final env = await _loadEnv();
      final child = await env.family.addChild(
        name: 'عمر',
        age: 10,
        dailyLimitMinutes: 60,
      );
      final monday = startOfWeek(DateTime.now());
      await env.family.recordReading(
        child.id,
        minutes: 70,
        chapters: 3,
        at: monday,
      );
      await env.family.recordReading(
        child.id,
        minutes: 30,
        chapters: 1,
        at: monday.add(const Duration(days: 1)),
      );
      expect(env.family.minutesToday(child.id), greaterThanOrEqualTo(0));
      expect(env.family.activityOn(child.id, monday).minutes, 70);
      expect(env.family.activityOn(child.id, monday).chapters, 3);
      final report = env.family.weeklyReport(child.id);
      expect(report, isNotNull);
      expect(report!.childName, 'عمر');
      expect(report.perDayMinutes.length, 7);
      expect(report.totalMinutes, 100);
      expect(report.totalChapters, 4);
      expect(report.daysActive, 2);
      expect(report.limitExceededDays, 1);
      expect(report.stayedWithinLimit, isFalse);
      expect(report.dailyLimitMinutes, 60);
      expect(report.toShareText(), contains('عمر'));
      expect(report.toShareText(), contains('100 دقيقة'));
      expect(env.family.weeklyReport('غير_موجود'), isNull);
    });

    test('الحد اليومي والتجاوز', () async {
      final env = await _loadEnv();
      final child = await env.family.addChild(
        name: 'ليلى',
        age: 8,
        dailyLimitMinutes: 60,
      );
      expect(env.family.remainingToday(child.id), 60);
      expect(env.family.exceededToday(child.id), isFalse);
      await env.family.recordReading(child.id, minutes: 61);
      expect(env.family.exceededToday(child.id), isTrue);
      expect(env.family.remainingToday(child.id), 0);
      expect(
        await env.family.recordReading('غير_موجود', minutes: 10),
        isFalse,
      );
    });

    test('السماح بالقراءة: العمر والحظر الصريح', () async {
      final env = await _loadEnv();
      final child = await env.family.addChild(name: 'آدم', age: 10);
      const horror = Series(id: 'h', title: 'رعب', genres: ['رعب']);
      const action = Series(id: 'a', title: 'أكشن', genres: ['أكشن']);
      expect(env.family.canRead(child.id, horror), isFalse);
      expect(env.family.canRead(child.id, action), isTrue);
      expect(env.family.canRead('غير_موجود', action), isFalse);
      // حظر صريح من الوالدين يمنع حتى العمل المناسب.
      await env.family.updateChild(
        child.copyWith(blockedSeriesIds: const ['a']),
      );
      expect(env.family.canRead(child.id, action), isFalse);
    });

    test('تحديث وحذف ملف طفل', () async {
      final env = await _loadEnv();
      final child = await env.family.addChild(name: 'يوسف', age: 12);
      expect(
        await env.family.updateChild(child.copyWith(dailyLimitMinutes: 90)),
        isTrue,
      );
      expect(env.family.childById(child.id)!.dailyLimitMinutes, 90);
      expect(
        await env.family.updateChild(child.copyWith(id: 'غير_موجود')),
        isFalse,
      );
      expect(await env.family.removeChild('غير_موجود'), isFalse);
      expect(await env.family.removeChild(child.id), isTrue);
      expect(env.family.children, isEmpty);
    });

    test('بداية الأسبوع هي الاثنين', () {
      // 26 نوفمبر 2026 يوم خميس؛ الاثنين قبله هو 23 نوفمبر.
      final thursday = DateTime(2026, 11, 26);
      expect(thursday.weekday, DateTime.thursday);
      expect(startOfWeek(thursday), DateTime(2026, 11, 23));
      expect(startOfWeek(DateTime(2026, 11, 23)), DateTime(2026, 11, 23));
    });
  });

  group('A11ySettings و A11yStore — إمكانية الوصول', () {
    test('القيم الافتراضية', () {
      const s = A11ySettings();
      expect(s.textScale, 1.0);
      expect(s.eyeComfortWarmth, 0.18);
      expect(s.minTouchTarget, isTrue);
      expect(s.reduceMotion, isFalse);
      expect(s.highContrast, isFalse);
      expect(s.boldText, isFalse);
      expect(s, A11ySettings.defaults);
    });

    test('fromJson يقلّم النطاقات', () {
      final high = A11ySettings.fromJson(const {
        'text_scale': 5.0,
        'eye_comfort_warmth': 0.9,
      });
      expect(high.textScale, 2.0);
      expect(high.eyeComfortWarmth, 0.35);

      final low = A11ySettings.fromJson(const {
        'text_scale': 0.2,
        'eye_comfort_warmth': 0.0,
      });
      expect(low.textScale, 1.0);
      expect(low.eyeComfortWarmth, 0.05);

      final mid = A11ySettings.fromJson(const {
        'text_scale': 1.4,
        'eye_comfort_warmth': 0.25,
        'min_touch_target': false,
        'reduce_motion': true,
      });
      expect(mid.textScale, 1.4);
      expect(mid.eyeComfortWarmth, 0.25);
      expect(mid.minTouchTarget, isFalse);
      expect(mid.reduceMotion, isTrue);
      expect(A11ySettings.fromJson(const {}), A11ySettings.defaults);
    });

    test('toJson يستعمل المفاتيح الحقيقية وذهاباً وإياباً', () {
      const s = A11ySettings(
        textScale: 1.5,
        eyeComfortWarmth: 0.3,
        minTouchTarget: false,
      );
      final json = s.toJson();
      expect(json['text_scale'], 1.5);
      expect(json['eye_comfort_warmth'], 0.3);
      expect(json['min_touch_target'], isFalse);
      expect(A11ySettings.fromJson(json), s);
      expect(s.copyWith(textScale: 1.2).textScale, 1.2);
      expect(s.copyWith().eyeComfortWarmth, 0.3);
    });

    test('المخزن: تعيين مع التقليم والتحديث وإعادة التعيين', () async {
      final env = await _loadEnv();
      expect(env.a11y.textScale, 1.0);
      await env.a11y.setTextScale(3.0);
      expect(env.a11y.textScale, 2.0);
      await env.a11y.setTextScale(0.5);
      expect(env.a11y.textScale, 1.0);
      await env.a11y.setTextScale(1.6);
      expect(env.a11y.textScale, 1.6);
      await env.a11y.setEyeComfortWarmth(0.9);
      expect(env.a11y.eyeComfortWarmth, 0.35);
      await env.a11y.setEyeComfortWarmth(0.01);
      expect(env.a11y.eyeComfortWarmth, 0.05);
      await env.a11y.update(const A11ySettings(
        textScale: 1.3,
        reduceMotion: true,
        highContrast: true,
      ));
      expect(env.a11y.reduceMotion, isTrue);
      expect(env.a11y.highContrast, isTrue);
      await env.a11y.reset();
      expect(env.a11y.settings, A11ySettings.defaults);
      expect(env.a11y.minTouchSize, 48.0);
    });

    test('المخزن يقرأ القيم المبذورة ويحفظ التغييرات', () async {
      final env = await _loadEnv(seed: const {
        'a11y_settings_v1': '{"text_scale": 1.7, "eye_comfort_warmth": 0.3}',
      });
      expect(env.a11y.textScale, 1.7);
      expect(env.a11y.eyeComfortWarmth, 0.3);
      await env.a11y.setTextScale(1.2);
      final env2 = await _loadEnv();
      // البيئة الثانية تبدأ من بذور فارغة، فتبقى القيم الافتراضية.
      expect(env2.a11y.textScale, 1.0);
    });

    test('نسبة التباين: الأسود على الأبيض عالية', () {
      const black = Color(0xFF000000);
      const white = Color(0xFFFFFFFF);
      expect(a11yContrastRatio(black, white), closeTo(21.0, 0.5));
      expect(a11yContrastRatio(white, white), closeTo(1.0, 0.01));
      expect(a11yContrastRatio(black, black), closeTo(1.0, 0.01));
    });
  });

  group('SettingsController — البذور الحقيقية', () {
    test('يقرأ الثواني والفصول والأيام من المفاتيح الحقيقية', () async {
      final env = await _loadEnv(seed: _readingSeed());
      expect(env.settings.totalReadingSeconds, 5400);
      expect(env.settings.totalChaptersRead, 4);
      expect(env.settings.stampStats.chapters, 4);
      expect(env.settings.stampStats.minutes, 90);
      expect(env.settings.readDaysInYear(2026), 3);
      expect(env.settings.readDaysInYear(2025), 0);
      expect(env.settings.followedSeries.length, 2);
      expect(env.settings.isFollowing('s1'), isTrue);
      expect(env.settings.topGenre, 'أكشن');
    });

    test('markRead يبذر الفصول والأيام', () async {
      final env = await _loadEnv();
      expect(env.settings.totalChaptersRead, 0);
      env.settings.markRead('s9', 1);
      env.settings.markRead('s9', 2);
      env.settings.markRead('s9', 1);
      expect(env.settings.totalChaptersRead, 2);
      expect(env.settings.readChapters('s9'), {1, 2});
      expect(env.settings.readOnDay(DateTime.now()), isTrue);
    });
  });
}
