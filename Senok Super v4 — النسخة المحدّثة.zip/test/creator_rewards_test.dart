import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:senok_app/features/creator/creator_analytics.dart';
import 'package:senok_app/features/creator/creator_chapters.dart';
import 'package:senok_app/features/creator/creator_earnings.dart';
import 'package:senok_app/features/creator/creator_studio.dart';
import 'package:senok_app/features/rewards/coins_rewards.dart';
import 'package:senok_app/features/rewards/membership.dart';
import 'package:senok_app/features/rewards/referrals.dart';
import 'package:senok_app/widgets/sard_icons.dart';

Future<SharedPreferences> _prefs() async {
  SharedPreferences.setMockInitialValues({});
  return SharedPreferences.getInstance();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // ───────── استوديو الناشر ─────────
  group('استوديو الناشر', () {
    test('التحقق يرفض العنوان الفارغ', () {
      expect(
        validateSubmission(
          title: '',
          synopsis: 'ملخص طويل بما يكفي ليجتاز حد الثلاثين حرفاً المطلوب هنا.',
          genres: const ['أكشن'],
          type: 'مانهوا كورية',
        ),
        isNotNull,
      );
    });

    test('التحقق يرفض الملخص القصير', () {
      expect(
        validateSubmission(
          title: 'عمل جميل',
          synopsis: 'قصير',
          genres: const ['أكشن'],
          type: 'مانهوا كورية',
        ),
        contains('30'),
      );
    });

    test('التحقق يرفض أكثر من 4 تصنيفات', () {
      expect(
        validateSubmission(
          title: 'عمل جميل',
          synopsis: 'ملخص طويل بما يكفي ليجتاز حد الثلاثين حرفاً المطلوب هنا.',
          genres: const ['أكشن', 'دراما', 'رومانسي', 'فانتازيا', 'رعب'],
          type: 'مانهوا كورية',
        ),
        isNotNull,
      );
    });

    test('التحقق يقبل إرسالاً صالحاً', () {
      expect(
        validateSubmission(
          title: 'سيف الفجر',
          synopsis: 'ملخص طويل بما يكفي ليجتاز حد الثلاثين حرفاً المطلوب هنا.',
          genres: const ['أكشن', 'فانتازيا'],
          type: 'مانهوا كورية',
        ),
        isNull,
      );
    });

    test('إنشاء مسودة ثم إرسالها للمراجعة', () async {
      final store = CreatorStudioStore.testInstance(await _prefs());
      final created = store.createDraft(
        title: 'اختبار العمل',
        type: 'مانغا يابانية',
        genres: const ['دراما'],
        synopsis: 'ملخص طويل بما يكفي ليجتاز حد الثلاثين حرفاً المطلوب هنا.',
      );
      expect(created, isNotNull);
      expect(created!.status, CreatorSubmissionStatus.draft);
      expect(store.sendForReview(created.id), isTrue);
      expect(
        store.byId(created.id)!.status,
        CreatorSubmissionStatus.underReview,
      );
      expect(store.byId(created.id)!.submittedAt, isNotNull);
    });

    test('النشر يتطلب القبول أولاً', () async {
      final store = CreatorStudioStore.testInstance(await _prefs());
      final created = store.createDraft(
        title: 'عمل للنشر',
        type: 'مانهوا كورية',
        genres: const ['أكشن'],
        synopsis: 'ملخص طويل بما يكفي ليجتاز حد الثلاثين حرفاً المطلوب هنا.',
      );
      expect(store.publish(created!.id), isFalse);
      store.sendForReview(created.id);
      expect(
        store.simulateReview(created.id, CreatorSubmissionStatus.approved),
        isTrue,
      );
      expect(store.publish(created.id), isTrue);
      expect(
        store.byId(created.id)!.status,
        CreatorSubmissionStatus.published,
      );
    });

    test('تعديل عمل طُلب تعديله يعيده مسودة', () async {
      final store = CreatorStudioStore.testInstance(await _prefs());
      final created = store.createDraft(
        title: 'عمل للتعديل',
        type: 'مانهوا كورية',
        genres: const ['أكشن'],
        synopsis: 'ملخص طويل بما يكفي ليجتاز حد الثلاثين حرفاً المطلوب هنا.',
      );
      store.sendForReview(created!.id);
      store.simulateReview(
        created.id,
        CreatorSubmissionStatus.changesRequested,
        note: 'أعد رسم الغلاف.',
      );
      expect(
        store.updateDraft(created.id, title: 'عمل للتعديل v2'),
        isTrue,
      );
      expect(
        store.byId(created.id)!.status,
        CreatorSubmissionStatus.draft,
      );
    });

    test('سطر التاريخ يغطي كل الحالات بلا استثناء', () async {
      final store = CreatorStudioStore.testInstance(await _prefs());
      final item = store.submissions.first;
      for (final s in CreatorSubmissionStatus.values) {
        final label = store.dateForStep(item, s);
        expect(label, isNotEmpty);
      }
    });

    test('حذف مسودة يعمل وحذف المنشور يفشل', () async {
      final store = CreatorStudioStore.testInstance(await _prefs());
      final created = store.createDraft(
        title: 'عمل للحذف',
        type: 'مانهوا كورية',
        genres: const ['أكشن'],
        synopsis: 'ملخص طويل بما يكفي ليجتاز حد الثلاثين حرفاً المطلوب هنا.',
      );
      expect(store.delete(created!.id), isTrue);
      final published = store.byStatus(CreatorSubmissionStatus.published).first;
      expect(store.delete(published.id), isFalse);
    });

    test('الإرسال إلى JSON وعودته', () {
      final item = CreatorSubmission(
        id: 'x1',
        title: 'عنوان',
        type: 'مانهوا كورية',
        genres: ['أكشن'],
        synopsis: 'ملخص',
        coverUrl: '',
        createdAt: _FixedDate.fallback,
        status: CreatorSubmissionStatus.draft,
      );
      final back = CreatorSubmission.fromJson(item.toJson());
      expect(back.id, 'x1');
      expect(back.title, 'عنوان');
      expect(back.status, CreatorSubmissionStatus.draft);
      expect(back.createdAt, _FixedDate.fallback);
    });
  });

  // ───────── فصول الناشر ─────────
  group('فصول الناشر', () {
    test('إضافة فصل ورقم الفصل التالي', () async {
      final store = CreatorChapterStore.testInstance(await _prefs());
      store.clearDemo();
      final ch = store.addChapter(
        submissionId: 's1',
        number: 1,
        title: 'البداية',
        pageCount: 30,
      );
      expect(ch, isNotNull);
      expect(store.nextNumber('s1'), 2);
      expect(store.ofSubmission('s1').length, 1);
    });

    test('رقم فصل مكرر مرفوض', () async {
      final store = CreatorChapterStore.testInstance(await _prefs());
      store.clearDemo();
      store.addChapter(submissionId: 's1', number: 1, pageCount: 10);
      expect(
        store.addChapter(submissionId: 's1', number: 1, pageCount: 10),
        isNull,
      );
    });

    test('التحقق يرفض رقم صفر', () {
      expect(
        validateCreatorChapter(number: 0, title: '', pageCount: 10),
        isNotNull,
      );
    });

    test('نشر فصل وجدولة فصل في المستقبل', () async {
      final store = CreatorChapterStore.testInstance(await _prefs());
      store.clearDemo();
      final ch = store.addChapter(
        submissionId: 's1',
        number: 1,
        pageCount: 20,
      );
      expect(store.publishChapter(ch!.id), isTrue);
      expect(store.byId(ch.id)!.isPublished, isTrue);
      final ch2 = store.addChapter(
        submissionId: 's1',
        number: 2,
        pageCount: 20,
      );
      expect(
        store.scheduleChapter(
          ch2!.id,
          DateTime.now().add(const Duration(days: 2)),
        ),
        isTrue,
      );
      expect(store.byId(ch2.id)!.status, CreatorChapterStatus.scheduled);
      expect(store.byId(ch2.id)!.scheduleDue, isFalse);
    });

    test('جدولة في الماضي مرفوضة', () async {
      final store = CreatorChapterStore.testInstance(await _prefs());
      store.clearDemo();
      final ch = store.addChapter(
        submissionId: 's1',
        number: 1,
        pageCount: 20,
      );
      expect(
        store.scheduleChapter(
          ch!.id,
          DateTime.now().subtract(const Duration(days: 1)),
        ),
        isFalse,
      );
    });

    test('إعادة الترقيم 1..N', () async {
      final store = CreatorChapterStore.testInstance(await _prefs());
      store.clearDemo();
      store.addChapter(submissionId: 's1', number: 1, pageCount: 10);
      store.addChapter(submissionId: 's1', number: 3, pageCount: 10);
      store.addChapter(submissionId: 's1', number: 7, pageCount: 10);
      store.renumber('s1');
      final nums = store.ofSubmission('s1').map((e) => e.number).toList();
      expect(nums, [1, 2, 3]);
    });
  });

  // ───────── التحليلات ─────────
  group('تحليلات الناشر', () {
    test('المشاهدات اليومية حتمية (نفس المدخلات = نفس النتيجة)', () {
      final day = DateTime(2026, 11, 20);
      expect(
        CreatorAnalyticsStore.demoViewsFor('demo_1', day),
        CreatorAnalyticsStore.demoViewsFor('demo_1', day),
      );
    });

    test('مشاهدات آخر N يوماً بطول N', () async {
      final studio = CreatorStudioStore.testInstance(await _prefs());
      final chapters = CreatorChapterStore.testInstance(await _prefs());
      final analytics =
          CreatorAnalyticsStore(studio: studio, chapters: chapters);
      expect(analytics.viewsLastNDays(7).length, 7);
      expect(analytics.viewsLastNDays(30).length, 30);
    });

    test('ملخص الفترة بلا NaN', () async {
      final studio = CreatorStudioStore.testInstance(await _prefs());
      final chapters = CreatorChapterStore.testInstance(await _prefs());
      final analytics =
          CreatorAnalyticsStore(studio: studio, chapters: chapters);
      final s = analytics.summary(30);
      expect(s.totalViews, greaterThanOrEqualTo(0));
      expect(s.growthPercent.isNaN, isFalse);
      expect(s.averageDaily, greaterThanOrEqualTo(0));
    });

    test('توزيع التقييمات مجموعه أكبر من صفر', () async {
      final studio = CreatorStudioStore.testInstance(await _prefs());
      final chapters = CreatorChapterStore.testInstance(await _prefs());
      final analytics =
          CreatorAnalyticsStore(studio: studio, chapters: chapters);
      expect(analytics.ratingBreakdown().total, greaterThan(0));
    });

    test('أفضل الأعمال مرتبة تنازلياً', () async {
      final studio = CreatorStudioStore.testInstance(await _prefs());
      final chapters = CreatorChapterStore.testInstance(await _prefs());
      final analytics =
          CreatorAnalyticsStore(studio: studio, chapters: chapters);
      final top = analytics.topSeries();
      for (var i = 1; i < top.length; i++) {
        expect(top[i - 1].views, greaterThanOrEqualTo(top[i].views));
      }
    });
  });

  // ───────── الأرباح ─────────
  group('أرباح الناشر', () {
    test('تنسيق العملات', () {
      expect(formatCoins(12500), '12,500 عملة');
      expect(formatCoins(500), '500 عملة');
      expect(formatCoins(0), '0 عملة');
    });

    test('الرصيد المتاح يجمع المتاح فقط', () async {
      final store = CreatorEarningsStore.testInstance(await _prefs());
      expect(store.availableCoins, greaterThan(0));
      expect(store.pendingCoins, greaterThanOrEqualTo(0));
      expect(
        store.availableCoins + store.pendingCoins,
        lessThanOrEqualTo(store.totalEarnedCoins),
      );
    });

    test('طلب سحب أقل من الحد مرفوض', () async {
      final store = CreatorEarningsStore.testInstance(await _prefs());
      expect(
        store.requestPayout(
          amountCoins: 100,
          method: 'تحويل بنكي تجريبي',
        ),
        isNotNull,
      );
    });

    test('طلب سحب أكبر من الرصيد مرفوض', () async {
      final store = CreatorEarningsStore.testInstance(await _prefs());
      expect(
        store.requestPayout(
          amountCoins: store.availableCoins + 100000,
          method: 'تحويل بنكي تجريبي',
        ),
        isNotNull,
      );
    });

    test('طلب سحب صالح ينشئ طلباً وينقص الرصيد', () async {
      final store = CreatorEarningsStore.testInstance(await _prefs());
      final before = store.availableCoins;
      final payoutsBefore = store.payouts.length;
      final err = store.requestPayout(
        amountCoins: 5000,
        method: 'تحويل بنكي تجريبي',
      );
      expect(err, isNull);
      expect(store.payouts.length, payoutsBefore + 1);
      expect(store.availableCoins, before - 5000);
    });

    test('تحرير المعلّق القديم', () async {
      final store = CreatorEarningsStore.testInstance(await _prefs());
      final released = store.releasePending();
      expect(released, greaterThanOrEqualTo(1));
    });
  });

  // ───────── العضوية ─────────
  group('العضوية', () {
    test('المجاني نشط دائماً', () async {
      final store = MembershipStore.testInstance(await _prefs());
      expect(store.tier, MembershipTier.free);
      expect(store.state.isActive, isTrue);
      expect(store.isPlus, isFalse);
    });

    test('الترقية إلى بلس تفعّل 30 يوماً', () async {
      final store = MembershipStore.testInstance(await _prefs());
      store.upgradeTo(MembershipTier.plus);
      expect(store.isPlus, isTrue);
      expect(store.state.daysLeft, greaterThan(20));
    });

    test('إضافة فرد عائلة على المجاني مرفوضة', () async {
      final store = MembershipStore.testInstance(await _prefs());
      final err = await store.addFamilyMember('أحمد');
      expect(err, contains('عائلي'));
    });

    test('إضافة فرد عائلة على باقة عائلي تعمل', () async {
      final store = MembershipStore.testInstance(await _prefs());
      store.upgradeTo(MembershipTier.family);
      expect(await store.addFamilyMember('أحمد'), isNull);
      expect(await store.addFamilyMember('أحمد'), contains('بالفعل'));
      expect(store.state.familyMembers, contains('أحمد'));
      expect(store.removeFamilyMember('أحمد'), isTrue);
    });

    test('الحد الأقصى 5 أفراد', () async {
      final store = MembershipStore.testInstance(await _prefs());
      store.upgradeTo(MembershipTier.family);
      for (var i = 1; i <= 5; i++) {
        expect(await store.addFamilyMember('فرد $i'), isNull);
      }
      expect(await store.addFamilyMember('فرد 6'), contains('الحد الأقصى'));
    });

    test('التجديد يمدد الانتهاء', () async {
      final store = MembershipStore.testInstance(await _prefs());
      store.upgradeTo(MembershipTier.plus);
      final first = store.state.expiresAt!;
      expect(store.renew(), isTrue);
      expect(store.state.expiresAt!.isAfter(first), isTrue);
    });

    test('الرجوع إلى المجاني يمسح الباقة', () async {
      final store = MembershipStore.testInstance(await _prefs());
      store.upgradeTo(MembershipTier.plus);
      store.downgradeToFree();
      expect(store.tier, MembershipTier.free);
      expect(store.isPlus, isFalse);
    });
  });

  // ───────── العملات والمكافآت ─────────
  group('العملات والمكافآت', () {
    test('قراءة فصل تمنح 5 عملات والحد اليومي 50', () async {
      final store = SardCoinsStore.testInstance(await _prefs());
      var total = 0;
      for (var i = 0; i < 12; i++) {
        total += store.recordChapterRead(seriesTitle: 'عمل');
      }
      expect(total, kDailyChapterCoinsCap);
      expect(store.chapterCoinsToday(), kDailyChapterCoinsCap);
    });

    test('تسجيل الدخول: أول مرة +10 والثانية في اليوم 0', () async {
      final store = SardCoinsStore.testInstance(await _prefs());
      final day = DateTime(2026, 11, 26);
      expect(store.recordDailyCheckIn(now: day), 10);
      expect(store.recordDailyCheckIn(now: day), 0);
      expect(store.checkInStreak, 1);
    });

    test('سلسلة يومين متتاليين ترفع المكافأة', () async {
      final store = SardCoinsStore.testInstance(await _prefs());
      store.recordDailyCheckIn(now: DateTime(2026, 11, 26));
      final second = store.recordDailyCheckIn(now: DateTime(2026, 11, 27));
      expect(second, 15);
      expect(store.checkInStreak, 2);
    });

    test('إنفاق أكثر من الرصيد مرفوض', () async {
      final store = SardCoinsStore.testInstance(await _prefs());
      expect(
        store.spendCoins(store.balance + 1000, 'اختبار'),
        isNotNull,
      );
    });

    test('إنفاق صالح ينقص الرصيد', () async {
      final store = SardCoinsStore.testInstance(await _prefs());
      final before = store.balance;
      expect(store.spendCoins(50, 'اختبار'), isNull);
      expect(store.balance, before - 50);
    });

    test('شراء عنصر مرتين: الثانية مرفوضة', () async {
      final store = SardCoinsStore.testInstance(await _prefs());
      store.grantReward(1000, 'اختبار');
      const item = CoinShopItem(
        id: 'test_item',
        title: 'عنصر اختبار',
        description: 'للاختبار فقط',
        priceCoins: 200,
        icon: SardIcons.star_rounded,
      );
      expect(store.buyShopItem(item), isNull);
      expect(store.owns('test_item'), isTrue);
      expect(store.buyShopItem(item), contains('بالفعل'));
    });
  });

  // ───────── الإحالات ─────────
  group('الإحالات', () {
    test('رابط الإحالة بنطاق senok.app', () async {
      final store = ReferralStore.testInstance(await _prefs());
      expect(store.myLink, startsWith('https://senok.app/r/'));
      expect(store.myCode.length, kReferralCodeLength);
    });

    test('التحقق من الرمز: قصير مرفوض ورمزك مرفوض', () async {
      final store = ReferralStore.testInstance(await _prefs());
      expect(validateReferralCode('ABC'), isNotNull);
      expect(validateReferralCode(store.myCode, ownCode: store.myCode), isNotNull);
      expect(validateReferralCode('A7K2M9', ownCode: store.myCode), isNull);
    });

    test('تطبيق رمز مرتين: الثانية مرفوضة', () async {
      final store = ReferralStore.testInstance(await _prefs());
      expect(store.applyCode('A7K2M9'), isNull);
      expect(store.applyCode('B8L3N4'), contains('من قبل'));
    });

    test('محاكاة انضمام صديق تمنح المكافأة', () async {
      final coins = SardCoinsStore.testInstance(await _prefs());
      final store = ReferralStore.testInstance(await _prefs(), coins: coins);
      final before = coins.balance;
      expect(store.simulateFriendJoined('T6W4D8'), isTrue);
      expect(coins.balance, before + kReferralBonusCoins);
      expect(store.simulateFriendJoined('T6W4D8'), isFalse);
    });

    test('توليد الرمز حتمي وطوله 6', () {
      expect(generateReferralCode('seed_x'), generateReferralCode('seed_x'));
      expect(generateReferralCode('seed_x').length, kReferralCodeLength);
      expect(generateReferralCode('seed_y'), isNot(generateReferralCode('seed_x')));
    });
  });
}

/// تاريخ ثابت للاختبارات التي تحتاج DateTime ثابتاً.
class _FixedDate {
  static final DateTime fallback = DateTime(2026, 11, 26, 1, 30);
}
