import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/features/admin/admin_repository.dart';

void main() {
  AdminChapter baseChapter({
    int number = 3,
    String title = 'اختبار',
    List<String>? pages,
    AdminChapterStatus status = AdminChapterStatus.draft,
    DateTime? publishAt,
  }) {
    return AdminChapter(
      id: 'ch_test_$number',
      seriesId: 's1',
      number: number,
      title: title,
      pages: pages ?? const ['https://example.com/p1.jpg'],
      status: status,
      publishAt: publishAt,
      createdAt: DateTime(2026, 11, 1),
      updatedAt: DateTime(2026, 11, 1),
    );
  }

  group('AdminChapter: التحقق والعنوان والجدولة', () {
    test('فصل صالح بلا أخطاء', () {
      expect(baseChapter().validate(), isNull);
    });

    test('رقم فصل صفر مرفوض', () {
      expect(baseChapter(number: 0).validate(), isNotNull);
    });

    test('رقم فصل سالب مرفوض', () {
      expect(baseChapter(number: -2).validate(), isNotNull);
    });

    test('بلا صفحات مرفوض', () {
      expect(baseChapter(pages: const []).validate(), isNotNull);
    });

    test('رابط صفحة غير صالح مرفوض', () {
      expect(baseChapter(pages: const ['notaurl']).validate(), isNotNull);
      expect(baseChapter(pages: const ['ftp://example.com/p.jpg']).validate(), isNotNull);
    });

    test('عنوان طويل جداً مرفوض', () {
      expect(baseChapter(title: 'ع' * 121).validate(), isNotNull);
    });

    test('عنوان العرض يستخدم الرقم عند غياب العنوان', () {
      expect(baseChapter(title: '').displayTitle, 'الفصل 3');
      expect(baseChapter().displayTitle, 'الفصل 3: اختبار');
    });

    test('مجدول بلا موعد مرفوض', () {
      expect(
        baseChapter(status: AdminChapterStatus.scheduled).validate(),
        isNotNull,
      );
    });

    test('مجدول بموعد في الماضي مرفوض', () {
      expect(
        baseChapter(
          status: AdminChapterStatus.scheduled,
          publishAt: DateTime.now().subtract(const Duration(days: 1)),
        ).validate(),
        isNotNull,
      );
    });

    test('مجدول بموعد مستقبلي صالح', () {
      expect(
        baseChapter(
          status: AdminChapterStatus.scheduled,
          publishAt: DateTime.now().add(const Duration(days: 1)),
        ).validate(),
        isNull,
      );
    });

    test('scheduleDue صحيح فقط للمجدول الذي حان وقته', () {
      final due = baseChapter(
        status: AdminChapterStatus.scheduled,
        publishAt: DateTime.now().subtract(const Duration(hours: 1)),
      );
      final future = baseChapter(
        status: AdminChapterStatus.scheduled,
        publishAt: DateTime.now().add(const Duration(days: 1)),
      );
      final published = baseChapter(status: AdminChapterStatus.published);
      expect(due.scheduleDue, isTrue);
      expect(future.scheduleDue, isFalse);
      expect(published.scheduleDue, isFalse);
      expect(future.isScheduledFuture, isTrue);
      expect(due.isScheduledFuture, isFalse);
    });

    test('JSON ذهاباً وإياباً', () {
      final c = baseChapter(status: AdminChapterStatus.published);
      final back = AdminChapter.fromJson(c.toJson());
      expect(back.id, c.id);
      expect(back.number, 3);
      expect(back.status, AdminChapterStatus.published);
      expect(back.pages, ['https://example.com/p1.jpg']);
      expect(back.displayTitle, c.displayTitle);
    });

    test('copyWith يمسح موعد النشر عند الطلب', () {
      final c = baseChapter(
        status: AdminChapterStatus.scheduled,
        publishAt: DateTime.now().add(const Duration(days: 1)),
      ).copyWith(status: AdminChapterStatus.published, clearPublishAt: true);
      expect(c.publishAt, isNull);
      expect(c.status, AdminChapterStatus.published);
    });
  });

  group('AdminSeries: التحقق والتحويل', () {
    AdminSeries baseSeries({String title = 'عمل تجريبي', String? cover, int year = 2024}) {
      return AdminSeries(
        id: 'sr_test',
        title: title,
        cover: cover,
        type: 'مانهوا كورية',
        status: 'مستمر',
        genres: const ['أكشن'],
        synopsis: 'ملخص قصير.',
        chapters: 10,
        rating: 8.5,
        views: 1000,
        year: year,
        createdAt: DateTime(2026, 1, 1),
        updatedAt: DateTime(2026, 1, 1),
      );
    }

    test('عمل صالح بلا أخطاء', () {
      expect(baseSeries().validate(), isNull);
    });

    test('عنوان فارغ مرفوض', () {
      expect(baseSeries(title: '   ').validate(), isNotNull);
    });

    test('رابط غلاف غير صالح مرفوض', () {
      expect(baseSeries(cover: 'notaurl').validate(), isNotNull);
      expect(baseSeries(cover: 'https://example.com/cover.jpg').validate(), isNull);
    });

    test('سنة غير منطقية مرفوضة', () {
      expect(baseSeries(year: 1970).validate(), isNotNull);
      expect(baseSeries(year: 3000).validate(), isNotNull);
    });

    test('أكثر من 8 تصنيفات مرفوض', () {
      final s = baseSeries().copyWith(
        genres: List<String>.generate(9, (i) => 'تصنيف $i'),
      );
      expect(s.validate(), isNotNull);
    });

    test('fromSeries و toSeries يحافظان على الحقول', () {
      const series = Series(
        id: 'x1',
        title: 'عنوان',
        type: 'مانغا يابانية',
        status: 'مكتمل',
        chapters: 42,
        rating: 9.2,
        views: 5000,
        genres: ['دراما'],
        synopsis: 'قصة.',
        year: 2023,
      );
      final admin = AdminSeries.fromSeries(series);
      final back = admin.toSeries();
      expect(back.id, 'x1');
      expect(back.title, 'عنوان');
      expect(back.chapters, 42);
      expect(back.rating, 9.2);
      expect(admin.state, AdminSeriesState.completed);
      expect(admin.typeShort, 'مانغا');
    });

    test('JSON ذهاباً وإياباً', () {
      final back = AdminSeries.fromJson(baseSeries().toJson());
      expect(back.title, 'عمل تجريبي');
      expect(back.genres, ['أكشن']);
      expect(back.isNew, isFalse);
    });
  });

  group('AdminUser: التحقق', () {
    AdminUser baseUser({String email = 'a@b.com', AdminUserStatus status = AdminUserStatus.active}) {
      return AdminUser(
        id: 'u_test',
        name: 'مستخدم اختبار',
        email: email,
        role: AdminRole.user,
        status: status,
        joinedAt: DateTime(2026, 1, 1),
        lastActiveAt: DateTime.now(),
      );
    }

    test('مستخدم صالح', () {
      expect(baseUser().validate(), isNull);
    });

    test('بريد غير صالح مرفوض', () {
      expect(baseUser(email: 'not-an-email').validate(), isNotNull);
      expect(baseUser(email: 'a@b').validate(), isNotNull);
    });

    test('محظور بلا سبب مرفوض', () {
      expect(baseUser(status: AdminUserStatus.banned).validate(), isNotNull);
      final banned = baseUser(status: AdminUserStatus.banned).copyWith(bannedReason: 'إزعاج متكرر');
      expect(banned.validate(), isNull);
    });

    test('الحروف الأولى للاسم', () {
      expect(adminInitials('ليلى حسن'), 'لح');
      expect(adminInitials('عمر'), 'عم');
      expect(adminInitials('  '), '؟');
    });
  });

  group('AdminAnnouncement: التحقق والحالة', () {
    AdminAnnouncement baseAnn({bool active = true, DateTime? publishAt, DateTime? expiresAt}) {
      return AdminAnnouncement(
        id: 'an_test',
        title: 'إعلان',
        body: 'نص الإعلان.',
        target: AdminAnnouncementTarget.all,
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        active: active,
        publishAt: publishAt,
        expiresAt: expiresAt,
      );
    }

    test('إعلان صالح ونشط', () {
      final a = baseAnn();
      expect(a.validate(), isNull);
      expect(a.isLive, isTrue);
      expect(a.statusLabel, 'نشط الآن');
    });

    test('عنوان فارغ مرفوض', () {
      final a = baseAnn().copyWith(title: '  ');
      expect(a.validate(), isNotNull);
    });

    test('انتهاء قبل النشر مرفوض', () {
      final a = baseAnn(
        publishAt: DateTime.now().add(const Duration(days: 5)),
        expiresAt: DateTime.now().add(const Duration(days: 1)),
      );
      expect(a.validate(), isNotNull);
    });

    test('مجدول مستقبلاً ليس حياً', () {
      final a = baseAnn(publishAt: DateTime.now().add(const Duration(days: 2)));
      expect(a.isLive, isFalse);
      expect(a.statusLabel, 'مجدول');
    });

    test('متوقف ليس حياً', () {
      final a = baseAnn(active: false);
      expect(a.isLive, isFalse);
      expect(a.statusLabel, 'متوقف');
    });

    test('منتهي ليس حياً', () {
      final a = baseAnn(expiresAt: DateTime.now().subtract(const Duration(days: 1)));
      expect(a.isLive, isFalse);
      expect(a.statusLabel, 'منتهي');
    });
  });

  group('AdminRepository: البيانات التجريبية والبحث', () {
    test('الزرع التجريبي يملأ كل المجموعات', () {
      final repo = AdminRepository.memory();
      expect(repo.series, isNotEmpty);
      expect(repo.chapters, isNotEmpty);
      expect(repo.users.length, 12);
      expect(repo.reports.length, 6);
      expect(repo.announcements.length, 3);
      expect(repo.audit, isNotEmpty);
      expect(repo.isLoaded, isTrue);
    });

    test('بحث الأعمال بالعنوان والتصنيف والفلتر', () {
      final repo = AdminRepository.memory();
      final byTitle = repo.searchSeries(AdminSeriesFilter(query: repo.series.first.title));
      expect(byTitle, isNotEmpty);
      final byGenre = repo.searchSeries(const AdminSeriesFilter(genre: 'أكشن'));
      expect(byGenre.every((s) => s.genres.contains('أكشن')), isTrue);
      final featured = repo.searchSeries(const AdminSeriesFilter(onlyFeatured: true));
      expect(featured, isEmpty); // لا أعمال مثبّتة في الزرع الافتراضي
      final sorted = repo.searchSeries(const AdminSeriesFilter(sort: AdminSeriesSort.views));
      for (var i = 1; i < sorted.length; i++) {
        expect(sorted[i - 1].views >= sorted[i].views, isTrue);
      }
    });

    test('بحث المستخدمين بالدور والحالة', () {
      final repo = AdminRepository.memory();
      final mods = repo.searchUsers(const AdminUserFilter(role: AdminRole.moderator));
      expect(mods.length, 1);
      expect(mods.first.name, 'سارة أحمد');
      final suspended = repo.searchUsers(const AdminUserFilter(status: AdminUserStatus.suspended));
      expect(suspended.length, 1);
      final byName = repo.searchUsers(const AdminUserFilter(query: 'ليلى'));
      expect(byName.length, 1);
    });
  });

  group('AdminRepository: CRUD الأعمال والفصول', () {
    test('إضافة عمل وتعديله ثم حذفه مع فصوله', () async {
      final repo = AdminRepository.memory();
      final before = repo.series.length;
      final series = AdminSeries.blank().copyWith(title: 'عمل جديد للاختبار');
      final added = await repo.addSeries(series);
      expect(added.isOk, isTrue);
      expect(repo.series.length, before + 1);

      final chapter = AdminChapter.blank(seriesId: series.id, number: 1).copyWith(
        pages: const ['https://example.com/p1.jpg'],
        status: AdminChapterStatus.published,
      );
      final chAdded = await repo.addChapter(chapter);
      expect(chAdded.isOk, isTrue);
      expect(repo.chaptersOf(series.id).length, 1);

      final updated = await repo.updateSeries(series.copyWith(title: 'عمل معدل'));
      expect(updated.isOk, isTrue);
      expect(repo.seriesById(series.id)?.title, 'عمل معدل');

      final deleted = await repo.deleteSeries(series.id);
      expect(deleted.isOk, isTrue);
      expect(repo.seriesById(series.id), isNull);
      expect(repo.chaptersOf(series.id), isEmpty);
    });

    test('إضافة عمل بعنوان فارغ تفشل', () async {
      final repo = AdminRepository.memory();
      final res = await repo.addSeries(AdminSeries.blank());
      expect(res.isOk, isFalse);
      expect(res.error, isNotNull);
    });

    test('رقم فصل مكرر في العمل نفسه مرفوض', () async {
      final repo = AdminRepository.memory();
      final s = repo.series.first;
      final existing = repo.chaptersOf(s.id).first;
      final dup = AdminChapter.blank(seriesId: s.id, number: existing.number).copyWith(
        pages: const ['https://example.com/p1.jpg'],
      );
      final res = await repo.addChapter(dup);
      expect(res.isOk, isFalse);
    });

    test('نشر الفصول المجدولة التي حان وقتها', () async {
      final repo = AdminRepository.memory();
      final dueBefore = repo.chapters.where((c) => c.scheduleDue).length;
      expect(dueBefore, greaterThanOrEqualTo(1));
      final published = await repo.publishDueChapters();
      expect(published, dueBefore);
      expect(repo.chapters.where((c) => c.scheduleDue), isEmpty);
    });

    test('تغيير حالة فصل يسجَّل في التدقيق', () async {
      final repo = AdminRepository.memory();
      final draft = repo.chapters.firstWhere((c) => c.status == AdminChapterStatus.draft);
      final auditBefore = repo.audit.length;
      final res = await repo.setChapterStatus(draft.id, AdminChapterStatus.published);
      expect(res.isOk, isTrue);
      expect(repo.chapterById(draft.id)?.status, AdminChapterStatus.published);
      expect(repo.audit.length, greaterThan(auditBefore));
      expect(repo.audit.first.action, AdminAuditAction.publish);
    });

    test('جدولة فصل بلا موعد تفشل', () async {
      final repo = AdminRepository.memory();
      final draft = repo.chapters.firstWhere((c) => c.status == AdminChapterStatus.draft);
      final res = await repo.setChapterStatus(draft.id, AdminChapterStatus.scheduled);
      expect(res.isOk, isFalse);
    });
  });

  group('AdminRepository: المستخدمون والبلاغات والإعلانات', () {
    test('تغيير دور وحالة مستخدم', () async {
      final repo = AdminRepository.memory();
      final user = repo.users.firstWhere((u) => u.role == AdminRole.user);
      final roleRes = await repo.setUserRole(user.id, AdminRole.moderator);
      expect(roleRes.isOk, isTrue);
      expect(repo.userById(user.id)?.role, AdminRole.moderator);

      final banRes = await repo.setUserStatus(user.id, AdminUserStatus.banned);
      expect(banRes.isOk, isFalse); // الحظر يحتاج سبباً

      final banOk = await repo.setUserStatus(
        user.id,
        AdminUserStatus.banned,
        reason: 'اختبار',
      );
      expect(banOk.isOk, isTrue);
      expect(repo.userById(user.id)?.status, AdminUserStatus.banned);
      expect(repo.userById(user.id)?.bannedReason, 'اختبار');

      final unban = await repo.setUserStatus(user.id, AdminUserStatus.active);
      expect(unban.isOk, isTrue);
      expect(repo.userById(user.id)?.bannedReason, isNull);
    });

    test('توثيق مستخدم ينعكس فوراً', () async {
      final repo = AdminRepository.memory();
      final user = repo.users.firstWhere((u) => !u.isVerified);
      await repo.toggleUserVerified(user.id);
      expect(repo.userById(user.id)?.isVerified, isTrue);
    });

    test('إضافة مستخدم جديد وبريد مكرر مرفوض', () async {
      final repo = AdminRepository.memory();
      final before = repo.users.length;
      final now = DateTime.now();
      final user = AdminUser(
        id: 'u_new_1',
        name: 'مستخدم جديد',
        email: 'new@example.com',
        role: AdminRole.translator,
        status: AdminUserStatus.active,
        joinedAt: now,
        lastActiveAt: now,
      );
      final res = await repo.addUser(user);
      expect(res.isOk, isTrue);
      expect(repo.users.length, before + 1);
      final dup = await repo.addUser(AdminUser(
        id: 'u_new_2',
        name: 'مستخدم آخر',
        email: 'new@example.com',
        role: AdminRole.user,
        status: AdminUserStatus.active,
        joinedAt: now,
        lastActiveAt: now,
      ));
      expect(dup.isOk, isFalse);
      final badEmail = await repo.addUser(AdminUser(
        id: 'u_new_3',
        name: 'مستخدم آخر',
        email: 'bad',
        role: AdminRole.user,
        status: AdminUserStatus.active,
        joinedAt: now,
        lastActiveAt: now,
      ));
      expect(badEmail.isOk, isFalse);
    });

    test('معالجة بلاغ ورفض آخر', () async {
      final repo = AdminRepository.memory();
      final pending = repo.reports.firstWhere((r) => r.status == AdminReportStatus.pending);
      final res = await repo.setReportStatus(
        pending.id,
        AdminReportStatus.resolved,
        note: 'حُذف المحتوى.',
      );
      expect(res.isOk, isTrue);
      final after = repo.reportById(pending.id)!;
      expect(after.status, AdminReportStatus.resolved);
      expect(after.resolutionNote, 'حُذف المحتوى.');
      expect(after.resolvedAt, isNotNull);

      final other = repo.reports.firstWhere(
        (r) => r.status == AdminReportStatus.pending,
        orElse: () => repo.reports.first,
      );
      final rej = await repo.setReportStatus(other.id, AdminReportStatus.rejected, note: 'غير صحيح.');
      expect(rej.isOk, isTrue);
    });

    test('إضافة إعلان وتفعيله وإيقافه وحذفه', () async {
      final repo = AdminRepository.memory();
      final before = repo.announcements.length;
      final ann = AdminAnnouncement(
        id: 'an_test_add',
        title: 'إعلان اختبار',
        body: 'نص قصير.',
        target: AdminAnnouncementTarget.all,
        createdAt: DateTime.now(),
        active: true,
      );
      expect((await repo.addAnnouncement(ann)).isOk, isTrue);
      expect(repo.announcements.length, before + 1);
      expect((await repo.toggleAnnouncement(ann.id, false)).isOk, isTrue);
      expect(repo.announcementById(ann.id)?.isLive, isFalse);
      expect((await repo.deleteAnnouncement(ann.id)).isOk, isTrue);
      expect(repo.announcementById(ann.id), isNull);
    });

    test('الإحصاءات متسقة مع البيانات', () {
      final repo = AdminRepository.memory();
      final stats = repo.computeStats();
      expect(stats.totalSeries, repo.series.length);
      expect(stats.totalUsers, repo.users.length);
      expect(stats.totalChapters, repo.chapters.length);
      expect(
        stats.publishedChapters + stats.draftChapters + stats.scheduledChapters,
        lessThanOrEqualTo(stats.totalChapters),
      );
      expect(stats.openReports, repo.reports.where((r) => r.isOpen).length);
      expect(stats.viewsLast14Days.length, 14);
      expect(stats.topSeries.length, lessThanOrEqualTo(5));
      expect(stats.publishedRatio, inInclusiveRange(0.0, 1.0));
    });
  });

  group('AdminRepository: تصدير واستيراد', () {
    test('تصدير ثم استيراد يعيد البيانات نفسها', () async {
      final repo = AdminRepository.memory();
      final json = repo.exportAllJson();
      expect(json.contains('senok-admin'), isTrue);

      final other = AdminRepository.memory();
      await other.deleteSeries(other.series.first.id);
      final seriesBefore = other.series.length;
      final res = await other.importAllJson(json);
      expect(res.isOk, isTrue);
      expect(other.series.length, greaterThan(seriesBefore));
      expect(other.series.length, repo.series.length);
      expect(other.users.length, repo.users.length);
    });

    test('استيراد ملف تالف يفشل برسالة عربية', () async {
      final repo = AdminRepository.memory();
      final bad = await repo.importAllJson('ليس json');
      expect(bad.isOk, isFalse);
      final wrongApp = await repo.importAllJson('{"app":"other"}');
      expect(wrongApp.isOk, isFalse);
    });

    test('إعادة التعيين تعيد الزرع التجريبي', () async {
      final repo = AdminRepository.memory();
      await repo.deleteSeries(repo.series.first.id);
      final countAfterDelete = repo.series.length;
      await repo.resetToDemo();
      expect(repo.series.length, greaterThan(countAfterDelete));
      expect(repo.users.length, 12);
    });
  });

  group('AdminAuth: الدخول التجريبي', () {
    test('دخول صحيح وفاشل', () async {
      final auth = AdminAuth.memory();
      expect(auth.isLoggedIn, isFalse);
      expect(auth.mustChangePassword, isTrue);
      expect(await auth.login('admin', 'خطأ'), isNotNull);
      expect(await auth.login('غير_صحيح', 'admin123'), isNotNull);
      expect(await auth.login('', ''), isNotNull);
      expect(await auth.login('admin', 'admin123'), isNull);
      expect(auth.isLoggedIn, isTrue);
      auth.logout();
      expect(auth.isLoggedIn, isFalse);
    });

    test('تغيير كلمة المرور والتحقق منها', () async {
      final auth = AdminAuth.memory();
      expect(await auth.changePassword('خطأ', 'جديدة123', 'جديدة123'), isNotNull);
      expect(await auth.changePassword('admin123', 'قصير', 'قصير'), isNotNull);
      expect(await auth.changePassword('admin123', 'جديدة123', 'مختلفة'), isNotNull);
      expect(await auth.changePassword('admin123', 'admin123', 'admin123'), isNotNull);
      expect(await auth.changePassword('admin123', 'جديدة123', 'جديدة123'), isNull);
      expect(auth.mustChangePassword, isFalse);
      expect(await auth.login('admin', 'admin123'), isNotNull);
      expect(await auth.login('admin', 'جديدة123'), isNull);
    });
  });

  group('AdminRepository: بحث شامل ومهام ومعالجة جماعية', () {
    test('globalSearch يجد أعمالاً ومستخدمين وبلاغات', () {
      final repo = AdminRepository.memory();
      final firstTitle = repo.series.first.title;
      final res = repo.globalSearch(firstTitle);
      expect(res.series, isNotEmpty);
      expect(res.isEmpty, isFalse);
      final empty = repo.globalSearch('   ');
      expect(empty.isEmpty, isTrue);
      final none = repo.globalSearch('zzz_no_match_zzz');
      expect(none.isEmpty, isTrue);
    });

    test('auditFiltered يفلتر حسب الإجراء والنص', () {
      final repo = AdminRepository.memory();
      final logins = repo.auditFiltered(action: AdminAuditAction.login);
      expect(logins, isNotEmpty);
      expect(logins.every((e) => e.action == AdminAuditAction.login), isTrue);
      final byQuery = repo.auditFiltered(query: 'تجريبي');
      expect(byQuery, isNotEmpty);
      final future = repo.auditFiltered(since: DateTime.now().add(const Duration(days: 1)));
      expect(future, isEmpty);
    });

    test('نسخ عمل يضاعف العمل مع فصوله كمسودات', () async {
      final repo = AdminRepository.memory();
      final s = repo.series.first;
      final chaptersBefore = repo.chaptersOf(s.id).length;
      final res = await repo.duplicateSeries(s.id);
      expect(res.isOk, isTrue);
      final copy = repo.series.firstWhere((x) => x.title.contains('(نسخة)'));
      expect(copy.chapters, chaptersBefore);
      expect(repo.chaptersOf(copy.id).every((c) => c.status == AdminChapterStatus.draft), isTrue);
    });

    test('معالجة جماعية للبلاغات', () async {
      final repo = AdminRepository.memory();
      final openIds = repo.reports.where((r) => r.isOpen).map((r) => r.id).toList();
      expect(openIds, isNotEmpty);
      final res = await repo.bulkResolveReports(openIds);
      expect(res.isOk, isTrue);
      expect(repo.reports.where((r) => r.isOpen), isEmpty);
      final again = await repo.bulkResolveReports(openIds);
      expect(again.isOk, isFalse);
    });

    test('attentionItems يلتقط الفصول الحان وقتها والبلاغات المفتوحة', () {
      final repo = AdminRepository.memory();
      final items = repo.attentionItems();
      final kinds = items.map((i) => i.kind).toSet();
      expect(kinds.contains(AdminAttentionKind.dueChapters), isTrue);
      expect(kinds.contains(AdminAttentionKind.openReports), isTrue);
    });
  });

  group('أدوات مساعدة', () {
    test('formatSardDate و timeAgoArabic', () {
      expect(formatSardDate(DateTime(2026, 11, 5)), '2026/11/05');
      final now = DateTime(2026, 11, 26, 12, 0);
      expect(timeAgoArabic(now, now: now), 'الآن');
      expect(timeAgoArabic(now.subtract(const Duration(minutes: 5)), now: now), 'قبل 5 دقائق');
      expect(timeAgoArabic(now.subtract(const Duration(minutes: 1)), now: now), 'قبل دقيقة');
      expect(timeAgoArabic(now.subtract(const Duration(hours: 2)), now: now), 'قبل ساعتين');
      expect(timeAgoArabic(now.subtract(const Duration(days: 1)), now: now), 'أمس');
      expect(timeAgoArabic(now.subtract(const Duration(days: 3)), now: now), 'قبل 3 أيام');
      expect(timeAgoArabic(DateTime(2026, 10, 1), now: now), '2026/10/01');
    });

    test('adminEllipsis يقصّ النص الطويل', () {
      expect(adminEllipsis('قصير', 10), 'قصير');
      final long = adminEllipsis('هذا نص طويل جداً يجب قصّه', 10);
      expect(long.endsWith('…'), isTrue);
      expect(long.length, lessThanOrEqualTo(11));
    });

    test('formatSardDateTime', () {
      expect(formatSardDateTime(DateTime(2026, 11, 26, 9, 5)), '2026/11/26 — 09:05');
    });
  });
}
