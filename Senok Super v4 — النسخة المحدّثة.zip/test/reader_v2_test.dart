// اختبارات وحدة القارئ v2 في Senok.
// تغطي: مناطق النقر والإيماءات، وضع اللوحات، سجلّ التقدم والجلسات،
// الإشارات المرجعية، إعدادات القارئ والتجاوزات، أهداف القراءة.
import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/storage/settings.dart';
import 'package:senok_app/features/reader/panel_mode.dart';
import 'package:senok_app/features/reader/reader_bookmarks.dart';
import 'package:senok_app/features/reader/reader_gestures.dart';
import 'package:senok_app/features/reader/reader_progress.dart';
import 'package:senok_app/features/reader/reader_settings.dart';
import 'package:senok_app/features/reader/reading_goals.dart';

Future<SharedPreferences> _prefs([Map<String, Object> values = const {}]) async {
  SharedPreferences.setMockInitialValues(values);
  return SharedPreferences.getInstance();
}

Series _series([String id = 's1']) => Series(
      id: id,
      title: 'عمل الاختبار',
      chapters: 10,
      rating: 4.5,
      views: 1200,
    );

ChapterRecord _record({
  String seriesId = 's1',
  int chapter = 1,
  int seconds = 120,
  int pages = 5,
  bool done = true,
  DateTime? at,
}) {
  final t = at ?? DateTime.now();
  return ChapterRecord(
    seriesId: seriesId,
    seriesTitle: 'عمل الاختبار',
    chapter: chapter,
    seconds: seconds,
    pagesRead: pages,
    totalPages: 10,
    startedAt: t,
    finishedAt: done ? t.add(const Duration(minutes: 2)) : null,
    speedPpm: 2.5,
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // ═════════════════════════════════════════════════════════════════════
  //  تنسيقات المدة
  // ═════════════════════════════════════════════════════════════════════
  group('تنسيق المدة العربية', () {
    test('ثوانٍ ودقائق وساعات', () {
      expect(formatDurationArabic(0), '0 ثوانٍ');
      expect(formatDurationArabic(1), 'ثانية واحدة');
      expect(formatDurationArabic(2), 'ثانيتان');
      expect(formatDurationArabic(5), '5 ثوانٍ');
      expect(formatDurationArabic(45), '45 ثانية');
      expect(formatDurationArabic(60), 'دقيقة واحدة');
      expect(formatDurationArabic(120), 'دقيقتان');
      expect(formatDurationArabic(300), '5 دقائق');
      expect(formatDurationArabic(3600), 'ساعة واحدة');
      expect(formatDurationArabic(7260), 'ساعتان ودقيقة واحدة');
      expect(formatDurationArabic(9000), 'ساعتان و30 دقيقة');
    });

    test('ملخص القراءة مع السرعة وبدونها', () {
      expect(formatReadSummary(seconds: 120, speedPpm: 0), 'قرأت دقيقتان');
      expect(
        formatReadSummary(seconds: 120, speedPpm: 2.5),
        'قرأت دقيقتان · 2.5 صفحة/دقيقة',
      );
      expect(formatSpeedLabel(0), '—');
      expect(formatSpeedLabel(3.5), '3.5 صفحة/دقيقة');
    });

    test('تسميات الأيام', () {
      final now = DateTime(2026, 11, 26);
      expect(formatRv2DayLabel(DateTime(2026, 11, 26), now: now), 'اليوم');
      expect(formatRv2DayLabel(DateTime(2026, 11, 25), now: now), 'أمس');
      expect(formatRv2Date(DateTime(2026, 1, 5)), '5 يناير 2026');
      expect(rv2DayKey(DateTime(2026, 11, 26)), '2026-11-26');
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  سجلّ الفصل والجلسة
  // ═════════════════════════════════════════════════════════════════════
  group('ChapterRecord والجلسة', () {
    test('JSON ذهاباً وإياباً', () {
      final r = _record();
      final back = ChapterRecord.fromJson(r.toJson());
      expect(back.seriesId, 's1');
      expect(back.chapter, 1);
      expect(back.seconds, 120);
      expect(back.completed, isTrue);
      expect(back.fraction, 0.5);
      expect(back.summaryLabel, contains('الفصل 1'));
    });

    test('نسبة الإكمال والنسخ', () {
      final r = _record(pages: 10, done: false);
      expect(r.fraction, 1.0);
      expect(r.completed, isFalse);
      final c = r.copyWith(seconds: 300);
      expect(c.seconds, 300);
      expect(c.chapter, 1);
    });

    test('الجلسة تعدّ الصفحات والثواني', () {
      final s = ReadingSession(series: _series(), chapter: 3, totalPages: 20);
      s.onPage(1);
      s.onPage(4);
      expect(s.currentPage, 4);
      expect(s.maxPageReached, 4);
      expect(s.pagesRead, 4);
      expect(s.seconds, greaterThanOrEqualTo(0));
      final rec = s.toRecord();
      expect(rec.chapter, 3);
      expect(rec.pagesRead, 4);
      expect(rec.completed, isFalse);
      s.markFinished();
      expect(s.toRecord().completed, isTrue);
    });

    test('إيقاف الجلسة واستئنافها', () {
      final s = ReadingSession(series: _series(), chapter: 1, totalPages: 5);
      expect(s.isPaused, isFalse);
      s.pause();
      expect(s.isPaused, isTrue);
      s.resume();
      expect(s.isPaused, isFalse);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  مخزن التقدم
  // ═════════════════════════════════════════════════════════════════════
  group('ReaderProgressStore', () {
    test('إضافة واسترجاع وإحصاءات', () async {
      final store = ReaderProgressStore.testInstance();
      await store.addRecord(_record(chapter: 1, seconds: 120));
      await store.addRecord(_record(chapter: 2, seconds: 180, pages: 8));
      expect(store.count, 2);
      expect(store.totalSeconds, 300);
      expect(store.totalCompletedChapters, 2);
      final last = store.lastRecord('s1');
      expect(last, isNotNull);
      expect(last!.chapter, 2);
      final stats = store.statsFor('s1', 'عمل الاختبار');
      expect(stats.totalChapters, 2);
      expect(stats.totalSeconds, 300);
      expect(stats.timeLabel, '5 دقائق');
    });

    test('دمج سجلّي الفصل نفسه في اليوم', () async {
      final store = ReaderProgressStore.testInstance();
      await store.addRecord(_record(chapter: 1, seconds: 60, pages: 3));
      await store.addRecord(_record(chapter: 1, seconds: 60, pages: 5));
      expect(store.count, 1);
      expect(store.totalSeconds, 120);
      expect(store.records.first.pagesRead, 5);
    });

    test('ملخصات الأيام والسلسلة', () async {
      final store = ReaderProgressStore.testInstance();
      final today = DateTime.now();
      await store.addRecord(_record(at: today, seconds: 120));
      await store.addRecord(_record(at: today.subtract(const Duration(days: 1)), chapter: 2, seconds: 60));
      expect(store.streak(), 2);
      final days = store.lastDays(days: 7);
      expect(days.length, 2);
      expect(days.first.seconds, 120);
    });

    test('تصدير واستيراد JSON', () async {
      final store = ReaderProgressStore.testInstance();
      await store.addRecord(_record());
      final json = store.exportJson();
      final other = ReaderProgressStore.testInstance();
      final n = await other.importJson(json);
      expect(n, 1);
      expect(other.count, 1);
      expect(await other.importJson('not-json'), 0);
    });

    test('حذف ومسح', () async {
      final store = ReaderProgressStore.testInstance();
      await store.addRecord(_record(chapter: 1));
      await store.addRecord(_record(chapter: 2));
      await store.removeRecord(store.records.first);
      expect(store.count, 1);
      await store.clearSeries('s1');
      expect(store.count, 0);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  الإيماءات
  // ═════════════════════════════════════════════════════════════════════
  group('إيماءات القارئ', () {
    test('مناطق النقر: طرفان 28٪ ووسط 44٪', () {
      const size = Size(400, 800);
      expect(tapZoneFor(const Offset(10, 400), size), ReaderTapZone.first);
      expect(tapZoneFor(const Offset(111, 400), size), ReaderTapZone.first);
      expect(tapZoneFor(const Offset(113, 400), size), ReaderTapZone.center);
      expect(tapZoneFor(const Offset(200, 400), size), ReaderTapZone.center);
      expect(tapZoneFor(const Offset(287, 400), size), ReaderTapZone.center);
      expect(tapZoneFor(const Offset(289, 400), size), ReaderTapZone.last);
      expect(tapZoneFor(const Offset(399, 400), size), ReaderTapZone.last);
    });

    test('مستطيلات المناطق تغطي الصفحة كاملة', () {
      const size = Size(400, 800);
      final rects = tapZoneRects(size);
      expect(rects[ReaderTapZone.first]!.width, closeTo(112, 0.01));
      expect(rects[ReaderTapZone.center]!.width, closeTo(176, 0.01));
      expect(rects[ReaderTapZone.last]!.width, closeTo(112, 0.01));
      expect(rects[ReaderTapZone.first]!.left, 0);
      expect(rects[ReaderTapZone.last]!.right, 400);
    });

    test('تصنيف السحب', () {
      expect(classifySwipe(const Offset(0, -100), 500), ReaderSwipeDirection.up);
      expect(classifySwipe(const Offset(0, 100), 500), ReaderSwipeDirection.down);
      expect(classifySwipe(const Offset(-100, 0), 500), ReaderSwipeDirection.left);
      expect(classifySwipe(const Offset(100, 0), 500), ReaderSwipeDirection.right);
      expect(classifySwipe(const Offset(5, 5), 50), ReaderSwipeDirection.none);
      expect(isHorizontalSwipe(ReaderSwipeDirection.left), isTrue);
      expect(isVerticalSwipe(ReaderSwipeDirection.up), isTrue);
    });

    test('السحبة إلى إجراء حسب الوضع', () {
      expect(
        swipeToAction(ReaderSwipeDirection.up, vertical: true, rtl: true),
        ReaderGestureAction.nextPage,
      );
      expect(
        swipeToAction(ReaderSwipeDirection.down, vertical: true, rtl: true),
        ReaderGestureAction.prevPage,
      );
      expect(
        swipeToAction(ReaderSwipeDirection.left, vertical: false, rtl: true),
        ReaderGestureAction.nextPage,
      );
      expect(
        swipeToAction(ReaderSwipeDirection.right, vertical: false, rtl: false),
        ReaderGestureAction.nextPage,
      );
      expect(
        swipeToAction(ReaderSwipeDirection.none, vertical: true, rtl: true),
        ReaderGestureAction.none,
      );
    });

    test('إعدادات الإيماءات JSON ذهاباً وإياباً', () {
      const s = ReaderGestureSettings(
        tapZonesEnabled: false,
        edgeFraction: 0.2,
        doubleTap: ReaderDoubleTapAction.nextPage,
      );
      final back = ReaderGestureSettings.fromJson(s.toJson());
      expect(back.tapZonesEnabled, isFalse);
      expect(back.edgeFraction, 0.2);
      expect(back.doubleTap, ReaderDoubleTapAction.nextPage);
      expect(back.actionForZone(ReaderTapZone.first), ReaderGestureAction.none);
    });

    test('إجراء النقر حسب المنطقة', () {
      const s = ReaderGestureSettings();
      expect(s.actionForZone(ReaderTapZone.first), ReaderGestureAction.prevPage);
      expect(s.actionForZone(ReaderTapZone.last), ReaderGestureAction.nextPage);
      expect(s.actionForZone(ReaderTapZone.center), ReaderGestureAction.toggleUi);
      expect(s.actionForTap(const Offset(10, 400), const Size(400, 800)), ReaderGestureAction.prevPage);
    });

    test('مخزن الإيماءات يحفظ ويستعيد', () async {
      await _prefs();
      final store = ReaderGestureStore.testInstance();
      await store.update(const ReaderGestureSettings(edgeFraction: 0.35));
      expect(store.settings.edgeFraction, 0.35);
      await store.reset();
      expect(store.settings.edgeFraction, kRv2TapEdgeFraction);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  وضع اللوحات
  // ═════════════════════════════════════════════════════════════════════
  group('وضع اللوحات', () {
    test('عدد اللوحات حسب نسبة الأبعاد', () {
      expect(panelCountForAspect(1.5), 1);
      expect(panelCountForAspect(1.0), 2);
      expect(panelCountForAspect(0.6), 3);
      expect(panelCountForAspect(0.4), 4);
      expect(panelCountForAspect(0.3), 5);
      expect(panelCountForAspect(0.1), 6);
      expect(panelCountForAspect(0.1, maxPanels: 3), 3);
    });

    test('تقسيم صفحة ويبتون طويلة', () {
      final plan = splitPageIntoPanels(
        pageIndex: 0,
        pageAspect: 0.3,
        strategy: PanelSplitStrategy.byAspect,
      );
      expect(plan.count, 5);
      expect(plan.panels.first.top, 0);
      expect(plan.panels.last.bottom, closeTo(1.0, 0.001));
      // اللوحات متتالية دون فجوات كبيرة
      for (var i = 1; i < plan.panels.length; i++) {
        expect(plan.panels[i].top, lessThan(plan.panels[i - 1].bottom));
      }
    });

    test('صفحة عريضة بلا تقسيم', () {
      final plan = splitPageIntoPanels(
        pageIndex: 2,
        pageAspect: 1.6,
        strategy: PanelSplitStrategy.byAspect,
      );
      expect(plan.isSingle, isTrue);
      expect(plan.count, 1);
    });

    test('تقسيم بعدد ثابت', () {
      final plan = splitPageIntoPanels(
        pageIndex: 0,
        pageAspect: 0.5,
        strategy: PanelSplitStrategy.byCount,
        count: 4,
      );
      expect(plan.count, 4);
    });

    test('خطط فصل كامل وJSON', () {
      final plans = splitChapterIntoPanels(
        pageAspects: [0.4, 1.5, 0.6],
        strategy: PanelSplitStrategy.byAspect,
      );
      expect(plans.length, 3);
      expect(plans[0].count, 4);
      expect(plans[1].count, 1);
      expect(plans[2].count, 3);
      final back = PanelPlan.fromJson(plans[0].toJson());
      expect(back.count, plans[0].count);
      expect(back.pageIndex, 0);
    });

    test('ملّاح اللوحات يتنقل لوحةً لوحة', () {
      final plans = splitChapterIntoPanels(
        pageAspects: [0.4, 0.4],
        strategy: PanelSplitStrategy.byCount,
        count: 2,
      );
      final nav = PanelNavigator(plans: plans);
      expect(nav.totalPanels, 4);
      expect(nav.isFirst, isTrue);
      expect(nav.next(), isTrue);
      expect(nav.panel, 1);
      expect(nav.next(), isTrue);
      expect(nav.page, 1);
      expect(nav.panel, 0);
      expect(nav.globalPanelIndex, 2);
      expect(nav.prev(), isTrue);
      expect(nav.page, 0);
      expect(nav.panel, 1);
      nav.jumpToGlobal(3);
      expect(nav.isLast, isTrue);
      expect(nav.next(), isFalse);
      nav.jumpTo(0, 0);
      expect(nav.isFirst, isTrue);
      expect(nav.prev(), isFalse);
    });

    test('إعدادات اللوحات JSON', () {
      const s = PanelModeSettings(enabled: true, maxPanels: 4, overlap: 0.1);
      final back = PanelModeSettings.fromJson(s.toJson());
      expect(back.enabled, isTrue);
      expect(back.maxPanels, 4);
      expect(back.overlap, 0.1);
    });

    test('تقدير نسبة الأبعاد والحد الأقصى', () {
      expect(estimatePageAspect(widthPx: 800, heightPx: 2000), closeTo(0.4, 0.001));
      expect(estimatePageAspect(widthPx: 0, heightPx: 0), 0.5);
      expect(maxPanelsForHeight(1000), 2);
      expect(maxPanelsForHeight(9000), 6);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  إعدادات القارئ
  // ═════════════════════════════════════════════════════════════════════
  group('إعدادات القارئ v2', () {
    test('الافتراضيات', () {
      final s = ReaderV2Settings.testInstance();
      expect(s.background, ReaderBackground.paper);
      expect(s.mode, ReaderMode.vertical);
      expect(s.fontScale, 1.0);
      expect(s.brightness, 1.0);
      expect(s.keepAwake, isTrue);
      expect(s.summaryText, contains('عمودي'));
    });

    test('تغيير الخلفية والوضع والخط', () {
      final s = ReaderV2Settings.testInstance();
      s.setBackground(ReaderBackground.night);
      expect(s.background, ReaderBackground.night);
      expect(s.background.isDark, isTrue);
      expect(s.background.label, 'ليلي');
      s.setMode(ReaderMode.pagedRtl);
      expect(s.mode, ReaderMode.pagedRtl);
      s.setFontScale(1.4);
      expect(s.fontScale, 1.4);
      s.setFontScale(3.0);
      expect(s.fontScale, 1.6); // يُقيَّد بالحد الأقصى
      s.setBrightness(0.1);
      expect(s.brightness, 0.25); // يُقيَّد بالحد الأدنى
    });

    test('تسميات وألوان الخلفيات', () {
      expect(ReaderBackground.paper.label, 'ورقي');
      expect(ReaderBackground.sepia.label, 'عتيق');
      expect(ReaderBackground.ink.label, 'حبر');
      expect(ReaderBackground.dawn.label, 'فجر');
      expect(ReaderBackground.night.isDark, isTrue);
      expect(ReaderBackground.paper.isDark, isFalse);
      expect(readerBackgroundFromIndex(99), ReaderBackground.paper);
      expect(ReaderBackground.fromKey('night'), ReaderBackground.night);
      expect(ReaderBackground.fromKey('غير موجود'), ReaderBackground.paper);
    });

    test('سرعات التمرير التلقائي', () {
      expect(ReaderAutoSpeed.slow.label, 'بطيء');
      expect(ReaderAutoSpeed.fast.pixelsPerSecond, 170);
      expect(ReaderAutoSpeed.slow.secondsPerPage, 14);
    });

    test('تجاوزات عمل واحد', () async {
      final s = ReaderV2Settings.testInstance();
      expect(s.backgroundFor('s1'), ReaderBackground.paper);
      await s.setOverrides(
        's1',
        const ReaderSeriesOverrides(background: ReaderBackground.ink, fontScale: 1.2),
      );
      expect(s.backgroundFor('s1'), ReaderBackground.ink);
      expect(s.fontScaleFor('s1'), 1.2);
      expect(s.modeFor('s1'), ReaderMode.vertical); // بلا تجاوز = العام
      expect(s.overriddenSeriesIds, ['s1']);
      await s.clearOverrides('s1');
      expect(s.backgroundFor('s1'), ReaderBackground.paper);
      expect(s.overriddenSeriesIds, isEmpty);
    });

    test('تجاوز فارغ يُحذف تلقائياً', () async {
      final s = ReaderV2Settings.testInstance();
      await s.setOverrides('s1', const ReaderSeriesOverrides());
      expect(s.overriddenSeriesIds, isEmpty);
    });

    test('إعادة التعيين', () async {
      final s = ReaderV2Settings.testInstance();
      s.setBackground(ReaderBackground.ink);
      s.setFontScale(1.5);
      await s.resetAll();
      expect(s.background, ReaderBackground.paper);
      expect(s.fontScale, 1.0);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  الإشارات المرجعية
  // ═════════════════════════════════════════════════════════════════════
  group('الإشارات المرجعية', () {
    test('إضافة وتكرار الموضع يحدّث بدل التكرار', () async {
      final store = ReaderBookmarkStore.testInstance();
      final b = await store.add(series: _series(), chapter: 2, page: 5, totalPages: 20, note: 'مشهد مهم');
      expect(store.count, 1);
      expect(b.positionLabel, 'الفصل 2 · صفحة 5');
      expect(b.hasNote, isTrue);
      final b2 = await store.add(series: _series(), chapter: 2, page: 5, totalPages: 20, note: 'ملاحظة جديدة');
      expect(store.count, 1);
      expect(b2.note, 'ملاحظة جديدة');
    });

    test('تبديل الإشارة', () async {
      final store = ReaderBookmarkStore.testInstance();
      expect(await store.toggle(series: _series(), chapter: 1, page: 3, totalPages: 10), isTrue);
      expect(store.hasAt('s1', 1, 3), isTrue);
      expect(await store.toggle(series: _series(), chapter: 1, page: 3, totalPages: 10), isFalse);
      expect(store.hasAt('s1', 1, 3), isFalse);
    });

    test('تجميع حسب العمل والتصفية', () async {
      final store = ReaderBookmarkStore.testInstance();
      await store.add(series: _series('s1'), chapter: 1, page: 2, totalPages: 10);
      await store.add(series: _series('s1'), chapter: 2, page: 4, totalPages: 10);
      await store.add(series: _series('s2'), chapter: 1, page: 1, totalPages: 10);
      expect(store.forSeries('s1').length, 2);
      expect(store.forChapter('s1', 1).length, 1);
      final groups = store.seriesWithBookmarks();
      expect(groups.length, 2);
      final s1Group = groups.firstWhere((g) => g.$1 == 's1');
      expect(s1Group.$3, 2);
      expect(groups.map((g) => g.$1).toSet(), {'s1', 's2'});
    });

    test('تحديث وحذف وتصدير', () async {
      final store = ReaderBookmarkStore.testInstance();
      final b = await store.add(series: _series(), chapter: 1, page: 1, totalPages: 5);
      await store.update(b.id, note: 'محدّثة', color: BookmarkColor.blue);
      expect(store.at('s1', 1, 1)!.note, 'محدّثة');
      expect(store.at('s1', 1, 1)!.color, BookmarkColor.blue);
      final json = store.exportJson();
      final other = ReaderBookmarkStore.testInstance();
      expect(await other.importJson(json), 1);
      await store.remove(b.id);
      expect(store.count, 0);
    });

    test('ألوان الإشارات', () {
      expect(BookmarkColor.fromKey('blue'), BookmarkColor.blue);
      expect(BookmarkColor.fromKey('غير موجود'), BookmarkColor.amber);
      expect(BookmarkColor.red.label, 'أحمر');
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  أهداف القراءة
  // ═════════════════════════════════════════════════════════════════════
  group('أهداف القراءة v2', () {
    test('عناوين الأهداف الافتراضية عربية', () {
      final daily = ReadingGoal(id: 'a', kind: ReadingGoalKind.dailyChapters, target: 5, createdAt: DateTime(2026, 11, 26));
      expect(daily.defaultTitle, contains('5'));
      expect(daily.defaultTitle, contains('فصل'));
      expect(daily.fullTitle, contains('يومي'));
      final weekly = ReadingGoal(id: 'b', kind: ReadingGoalKind.weeklyChapters, target: 10, createdAt: DateTime(2026, 11, 26));
      expect(weekly.fullTitle, contains('أسبوعي'));
    });

    test('JSON ذهاباً وإياباً', () {
      final g = ReadingGoal(id: 'g1', kind: ReadingGoalKind.dailyMinutes, target: 30, createdAt: DateTime(2026, 11, 26));
      final back = ReadingGoal.fromJson(g.toJson());
      expect(back.kind, ReadingGoalKind.dailyMinutes);
      expect(back.target, 30);
    });

    test('تقدّم هدف الفصول اليومية من سجلّ v2', () async {
      await _prefs();
      final settings = await SettingsController.load();
      final progress = ReaderProgressStore.testInstance();
      await progress.addRecord(_record(chapter: 1, seconds: 120));
      final goal = ReadingGoal(id: 'g1', kind: ReadingGoalKind.dailyChapters, target: 3, createdAt: DateTime(2026, 11, 26));
      final pr = goal.progress(settings: settings, progress: progress);
      expect(pr.current, 1);
      expect(pr.target, 3);
      expect(pr.fraction, closeTo(1 / 3, 0.001));
      expect(pr.done, isFalse);
      expect(pr.label, '1 من 3 فصل');
      expect(pr.remaining, 2);
    });

    test('تقدّم هدف الدقائق اليومية', () async {
      await _prefs();
      final settings = await SettingsController.load();
      final progress = ReaderProgressStore.testInstance();
      await progress.addRecord(_record(seconds: 1800)); // 30 دقيقة
      final goal = ReadingGoal(id: 'g1', kind: ReadingGoalKind.dailyMinutes, target: 30, createdAt: DateTime(2026, 11, 26));
      final pr = goal.progress(settings: settings, progress: progress);
      expect(pr.current, 30);
      expect(pr.done, isTrue);
      expect(pr.remainingLabel, contains('اكتمل'));
    });

    test('مخزن الأهداف: إضافة وأرشفة وحذف', () async {
      final store = ReadingGoalsStore.testInstance();
      final g = await store.add(kind: ReadingGoalKind.dailyChapters, target: 2);
      expect(store.count, 1);
      expect(store.activeGoals.length, 1);
      await store.update(g.id, target: 5);
      expect(store.byId(g.id)!.target, 5);
      await store.archive(g.id);
      expect(store.activeGoals, isEmpty);
      expect(store.archivedGoals.length, 1);
      await store.archive(g.id, archived: false);
      expect(store.activeGoals.length, 1);
      await store.remove(g.id);
      expect(store.count, 0);
    });

    test('تقدّم كل الأهداف وعدد المكتملة', () async {
      await _prefs();
      final settings = await SettingsController.load();
      final progress = ReaderProgressStore.testInstance();
      await progress.addRecord(_record(seconds: 1800));
      final store = ReadingGoalsStore.testInstance();
      await store.add(kind: ReadingGoalKind.dailyMinutes, target: 30);
      await store.add(kind: ReadingGoalKind.dailyChapters, target: 5);
      final all = store.progressAll(settings: settings, progress: progress);
      expect(all.length, 2);
      expect(store.doneCount(settings: settings, progress: progress), 1);
    });
  });

  // ═════════════════════════════════════════════════════════════════════
  //  الإضافات: المخطط الأسبوعي، القوالب، المشاركة، اللوحات
  // ═════════════════════════════════════════════════════════════════════
  group('المخطط الأسبوعي والقوالب والمشاركة', () {
    test('نقاط مخطط الأسبوع 7 أيام', () async {
      final store = ReaderProgressStore.testInstance();
      final today = DateTime.now();
      await store.addRecord(_record(at: today, seconds: 600));
      await store.addRecord(_record(at: today.subtract(const Duration(days: 2)), chapter: 2, seconds: 300));
      final points = buildWeekChartPoints(store);
      expect(points.length, 7);
      expect(points.last.seconds, 600);
      expect(points[4].seconds, 300);
      expect(points.first.seconds, 0);
      expect(points.last.dayName, isNotEmpty);
    });

    test('نص مشاركة الأسبوع', () {
      final days = [
        DayReadingSummary(dayKey: '2026-11-26', date: DateTime(2026, 11, 26), seconds: 1800, chapters: 3, pages: 30, seriesTitles: ['عمل']),
      ];
      final text = buildWeeklyShareText(days: days, totalSeconds: 1800, totalChapters: 3);
      expect(text, contains('30 دقيقة'));
      expect(text, contains('3'));
    });

    test('قوالب الأهداف المقترحة حسب المستوى', () {
      expect(suggestedTemplatesFor(totalChaptersRead: 0, streak: 0).length, 1);
      expect(suggestedTemplatesFor(totalChaptersRead: 5, streak: 0).length, greaterThan(1));
      expect(suggestedTemplatesFor(totalChaptersRead: 50, streak: 10).length, greaterThan(0));
      expect(kGoalTemplates.length, 8);
      expect(kGoalTemplates.first.title, 'بداية خفيفة');
    });

    test('جمل التشجيع حسب النسبة', () {
      expect(goalEncouragement(1.0), contains('مذهل'));
      expect(goalEncouragement(0.8), contains('اقتربت'));
      expect(goalEncouragement(0.5), contains('النصف'));
      expect(goalEncouragement(0.0), contains('يوم جديد'));
    });

    test('نص مشاركة إشارة مرجعية', () async {
      final store = ReaderBookmarkStore.testInstance();
      final b = await store.add(series: _series(), chapter: 3, page: 7, totalPages: 20, note: 'مشهد');
      final text = buildBookmarkShareText(b);
      expect(text, contains('الفصل 3'));
      expect(text, contains('مشهد'));
      final listText = buildBookmarksListText('عمل الاختبار', [b]);
      expect(listText, contains('الفصل 3'));
      expect(buildBookmarksListText('عمل الاختبار', []), contains('لا إشارات'));
    });

    test('العدد المثالي للوحات من البكسل', () {
      // 800×2000: النسبة 0.4 توحي بـ 4 لوحات لكن حد الارتفاع 2000 بكسل = 3 كحد أقصى
      expect(idealPanelCountForPixels(widthPx: 800, heightPx: 2000), 3);
      expect(idealPanelCountForPixels(widthPx: 800, heightPx: 5000), 5);
      expect(idealPanelCountForPixels(widthPx: 1200, heightPx: 800), 1);
    });

    test('سجلّ إكمال هدف JSON', () {
      final log = GoalCompletionLog(goalId: 'g1', goalTitle: 'هدف يومي', completedAt: DateTime(2026, 11, 26));
      final back = GoalCompletionLog.fromJson(log.toJson());
      expect(back.goalId, 'g1');
      expect(back.goalTitle, 'هدف يومي');
    });
  });
}
