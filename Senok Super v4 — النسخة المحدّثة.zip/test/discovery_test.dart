import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/core/data/search_filters.dart';
import 'package:senok_app/core/discovery/reading_history.dart';
import 'package:senok_app/core/discovery/recommendation_engine.dart';
import 'package:senok_app/core/discovery/search_suggestions.dart';
import 'package:senok_app/core/discovery/taste_profile.dart';
import 'package:senok_app/core/discovery/trending_engine.dart';
import 'package:senok_app/core/storage/settings.dart';
import 'package:senok_app/features/discover/advanced_search.dart';
import 'package:senok_app/features/discover/collections.dart';
import 'package:senok_app/features/discover/reading_challenges.dart';
import 'package:senok_app/features/discover/reading_stats.dart';
import 'package:senok_app/features/discover/weekly_digest.dart';

Series _s({
  required String id,
  required String title,
  List<String> genres = const [],
  double rating = 0,
  int views = 0,
  int year = 2026,
  int chapters = 10,
  String status = 'مستمر',
  bool isNew = false,
  String type = 'مانهوا كورية',
}) =>
    Series(
      id: id,
      title: title,
      genres: genres,
      rating: rating,
      views: views,
      year: year,
      chapters: chapters,
      status: status,
      isNew: isNew,
      type: type,
    );

Future<SharedPreferences> _prefs(
    [Map<String, Object> values = const {}]) async {
  SharedPreferences.setMockInitialValues(values);
  return SharedPreferences.getInstance();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('TasteProfile', () {
    test('أوزان التصنيفات والتقارب', () {
      var p = TasteProfile.empty;
      expect(p.isEmpty, isTrue);
      expect(p.genreWeight('أكشن'), 0);
      p = p.withGenreWeight('أكشن', 8);
      expect(p.genreWeight('أكشن'), 8);
      expect(p.topGenres(1), ['أكشن']);
      expect(p.dominantGenre, 'أكشن');
      final s = _s(id: 'a', title: 'أ', genres: ['أكشن']);
      expect(p.affinityScore(s), 0.8);
      final other = _s(id: 'b', title: 'ب', genres: ['رومانسي']);
      expect(p.affinityScore(other), 0);
    });

    test('المكروهات تصفّر التقارب', () {
      final p = TasteProfile.empty
          .withGenreWeight('رعب', 9)
          .withDisliked('رعب', true);
      expect(p.genreWeight('رعب'), 0);
      expect(p.dislikes('رعب'), isTrue);
      final s = _s(id: 'a', title: 'أ', genres: ['رعب']);
      expect(p.affinityScore(s), 0);
    });

    test('توحيد أسماء التصنيفات', () {
      expect(normalizeGenre('مغامرات'), 'مغامرة');
      expect(normalizeGenre('رومانسية'), 'رومانسي');
      expect(normalizeGenre('أكشن'), 'أكشن');
    });

    test('البناء من السجل: فصول + إكمال + تقييم', () {
      final s1 = _s(id: 's1', title: 'واحد', genres: ['أكشن']);
      final profile = TasteProfileBuilder.buildFromHistory(
        readChapters: {'s1': 4},
        seriesById: {'s1': s1},
        finishedIds: {'s1'},
        ratings: {'s1': 9},
      );
      // 4 فصول × 0.25 = 1.0 + إكمال 2.0 + تقييم عالٍ 1.5 = 4.5
      expect(profile.genreWeight('أكشن'), 4.5);
      expect(profile.likedTypes, contains('مانهوا كورية'));
      expect(profile.affinityScore(s1), greaterThanOrEqualTo(0.5));
    });

    test('التقييم المنخفض يخصم', () {
      final s1 = _s(id: 's1', title: 'واحد', genres: ['دراما']);
      final profile = TasteProfileBuilder.buildFromHistory(
        readChapters: {'s1': 4},
        seriesById: {'s1': s1},
        ratings: {'s1': 3},
      );
      // 1.0 - 1.0 = 0
      expect(profile.genreWeight('دراما'), 0);
    });

    test('JSON ذهاباً وإياباً', () {
      final p = TasteProfile.empty
          .withGenreWeight('فانتازيا', 7)
          .withLikedType('مانغا يابانية', true);
      final back = TasteProfile.fromJsonString(p.toJsonString());
      expect(back, isNotNull);
      expect(back!.genreWeight('فانتازيا'), 7);
      expect(back.likedTypes, contains('مانغا يابانية'));
      expect(TasteProfile.fromJsonString('ليس json'), isNull);
    });

    test('المخزن يحفظ ويستعيد', () async {
      final prefs = await _prefs();
      final store = TasteProfileStore.testInstance(prefs);
      store.setGenreWeight('غموض', 6);
      expect(store.profile.genreWeight('غموض'), 6);
      final again = TasteProfileStore.testInstance(prefs);
      expect(again.profile.genreWeight('غموض'), 6);
      store.reset();
      expect(store.profile.isEmpty, isTrue);
    });
  });

  group('RecommendationEngine', () {
    final all = [
      _s(id: 'a', title: 'أكشن الملك', genres: ['أكشن'], rating: 9.2, views: 900000, year: 2026, isNew: true),
      _s(id: 'b', title: 'رومانسية هادئة', genres: ['رومانسي'], rating: 6.5, views: 20000, year: 2022),
      _s(id: 'c', title: 'سيف الأكشن', genres: ['أكشن', 'مغامرة'], rating: 8.8, views: 500000, year: 2025),
      _s(id: 'd', title: 'غموض الليل', genres: ['غموض'], rating: 9.5, views: 800000, year: 2026),
    ];

    test('الذوق يرفع الأكشن أولاً', () {
      final profile =
          TasteProfile.empty.withGenreWeight('أكشن', 10);
      final out = RecommendationEngine.recommend(
        RecommendationInput(all: all, profile: profile),
        limit: 4,
      );
      expect(out, isNotEmpty);
      expect(out.first.series.id, 'a');
      expect(out.first.explanation, contains('أكشن'));
    });

    test('المتابَع والمقروء يُستبعدان افتراضياً', () {
      final out = RecommendationEngine.recommend(
        RecommendationInput(
          all: all,
          followedIds: {'a'},
          readIds: {'c'},
        ),
        limit: 10,
      );
      expect(out.map((e) => e.series.id), isNot(contains('a')));
      expect(out.map((e) => e.series.id), isNot(contains('c')));
    });

    test('similarTo يجد المشترك في التصنيف', () {
      final sim = RecommendationEngine.similarTo(all[0], all);
      expect(sim, isNotEmpty);
      expect(sim.first.series.id, 'c');
      expect(sim.first.reasons.first.label, contains('أكشن'));
    });

    test('becauseYouRead يقترح من آخر المقروء', () {
      final out = RecommendationEngine.becauseYouRead([all[0]], all);
      expect(out.map((e) => e.series.id), contains('c'));
    });

    test('مختارات المحرر والجواهر المخفية', () {
      final picks = EditorPicks.pick(all, limit: 2);
      expect(picks.first.rating, greaterThanOrEqualTo(7.5));
      final gems = EditorPicks.hiddenGems([
        _s(id: 'g', title: 'جوهرة', genres: ['دراما'], rating: 9.0, views: 1000),
        _s(id: 'h', title: 'مشهور', genres: ['دراما'], rating: 9.0, views: 900000),
      ]);
      expect(gems.map((s) => s.id), ['g']);
      final marathon = EditorPicks.marathonReads([
        _s(id: 'm', title: 'طويل', genres: [], chapters: 120, status: 'مكتمل'),
        _s(id: 'n', title: 'قصير', genres: [], chapters: 10, status: 'مكتمل'),
      ]);
      expect(marathon.map((s) => s.id), ['m']);
    });
  });

  group('TrendingEngine', () {
    final all = [
      _s(id: 'top', title: 'الأول', genres: ['أكشن'], rating: 9.5, views: 1000000, year: 2026, isNew: true, chapters: 80),
      _s(id: 'mid', title: 'الثاني', genres: ['دراما'], rating: 8.0, views: 100000, year: 2025),
      _s(id: 'low', title: 'الثالث', genres: ['رومانسي'], rating: 5.0, views: 100, year: 2020),
    ];

    test('الترتيب: الأعلى نقاطاً أولاً مع ترقيم صحيح', () {
      final ranked = TrendingEngine.rank(all, limit: 3);
      expect(ranked.first.series.id, 'top');
      expect(ranked.first.rank, 1);
      expect(ranked[1].rank, 2);
      expect(ranked[2].rank, 3);
      expect(ranked.first.score, greaterThan(ranked[1].score));
    });

    test('الرائج حسب التصنيف', () {
      final list = TrendingEngine.topByGenre(all, 'دراما');
      expect(list.map((e) => e.series.id), ['mid']);
    });

    test('الأعلى تقييماً والأكثر مشاهدة والجديد', () {
      expect(TrendingEngine.topRated(all).first.id, 'top');
      expect(TrendingEngine.mostViewed(all).first.id, 'top');
      final fresh = TrendingEngine.freshThisWeek(all);
      expect(fresh.map((s) => s.id), contains('top'));
      expect(fresh.map((s) => s.id), isNot(contains('low')));
    });

    test('ملخص الرائج يذكر المتصدر', () {
      final ranked = TrendingEngine.rank(all, limit: 3);
      final summary =
          TrendingEngine.summaryFor(ranked, TrendingPeriod.week);
      expect(summary, contains('الأول'));
      expect(TrendingRankLabel.isPodium(1), isTrue);
      expect(TrendingRankLabel.isPodium(5), isFalse);
    });
  });

  group('ReadingHistory و PaceEstimator', () {
    test('وتيرة القراءة ووقت الإنهاء', () {
      expect(
        PaceEstimator.chaptersPerActiveDay(totalChapters: 60, activeDays: 10),
        6.0,
      );
      expect(
        PaceEstimator.estimatedDaysToFinish(
            remainingChapters: 30, chaptersPerDay: 6),
        5.0,
      );
      expect(
        PaceEstimator.finishLabel(
            remainingChapters: 0, chaptersPerDay: 6),
        'أنهيت كل الفصول',
      );
      expect(
        PaceEstimator.finishLabel(
            remainingChapters: 12, chaptersPerDay: 0),
        contains('اقرأ بعض الفصول'),
      );
      expect(
        PaceEstimator.minutesPerChapter(
            totalSeconds: 3600, totalChapters: 12),
        5.0,
      );
    });

    test('تسميات الأيام النسبية', () {
      final now = DateTime(2026, 11, 26, 12);
      expect(relativeDayLabel(DateTime(2026, 11, 26, 11), now: now),
          'قبل ساعة');
      expect(relativeDayLabel(DateTime(2026, 11, 25, 12), now: now), 'أمس');
      expect(relativeDayLabel(DateTime(2026, 11, 24, 12), now: now),
          'قبل يومين');
      expect(dayKey(DateTime(2026, 1, 5)), '2026-01-05');
      expect(formatSardDay(DateTime(2026, 11, 26)), '26 نوفمبر 2026');
    });

    test('المخزن: تسجيل وفصول اليوم والسلسلة', () async {
      final prefs = await _prefs();
      final store = ReadingHistoryStore.testInstance(prefs);
      store.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 1,
        at: DateTime(2026, 11, 24, 20),
      );
      store.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 2,
        at: DateTime(2026, 11, 25, 20),
      );
      store.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 3,
        at: DateTime(2026, 11, 26, 20),
      );
      expect(store.totalChapters, 3);
      expect(store.chaptersOnDay(DateTime(2026, 11, 25)), 1);
      expect(store.streak(now: DateTime(2026, 11, 26, 21)), 3);
      expect(store.hasRead('s1', 2), isTrue);
      expect(store.hasRead('s1', 9), isFalse);
      expect(store.lastChapterOf('s1'), 3);
      // التكرار الدقيق يُتجاهل.
      store.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 3,
        at: DateTime(2026, 11, 26, 20),
      );
      expect(store.totalChapters, 3);
      // الاستعادة من التخزين.
      final again = ReadingHistoryStore.testInstance(prefs);
      expect(again.totalChapters, 3);
      // التصدير والاستيراد.
      final json = store.exportJson();
      store.clear();
      expect(store.totalChapters, 0);
      expect(store.importJson(json), 3);
    });

    test('ملخص فترة وتوزيع شهري', () async {
      final prefs = await _prefs();
      final store = ReadingHistoryStore.testInstance(prefs);
      store.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 1,
        at: DateTime(2026, 11, 23, 10),
      );
      store.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 2,
        at: DateTime(2026, 11, 23, 11),
      );
      store.recordRead(
        seriesId: 's2',
        seriesTitle: 'اثنان',
        chapter: 1,
        at: DateTime(2026, 11, 25, 10),
      );
      final summary = store.summaryBetween(
        DateTime(2026, 11, 23),
        DateTime(2026, 11, 30),
      );
      expect(summary.chapters, 3);
      expect(summary.activeDays, 2);
      expect(summary.distinctSeries, 2);
      expect(summary.topSeriesTitle, 'واحد');
      expect(summary.topSeriesChapters, 2);
      expect(store.chaptersByMonth(2026)[11], 3);
      expect(store.readChaptersBySeries, {'s1': 2, 's2': 1});
    });
  });

  group('SearchSuggestions', () {
    final all = [
      _s(id: 'a', title: 'مملكة النار', genres: ['أكشن'], rating: 9.0, views: 500000),
      _s(id: 'b', title: 'مملكة الثلج', genres: ['فانتازيا'], rating: 8.0, views: 300000),
      _s(id: 'c', title: 'حكاية هادئة', genres: ['رومانسي'], rating: 7.0, views: 10000),
    ];

    test('اقتراحات نص: بادئة العنوان أولاً', () {
      final out = SearchSuggestionEngine.suggest(
        query: 'ممل',
        all: all,
      );
      expect(out, isNotEmpty);
      expect(out.first.text, contains('مملكة'));
      expect(out.first.kind, SuggestionKind.title);
    });

    test('اقتراحات التصنيف', () {
      final out = SearchSuggestionEngine.suggest(
        query: 'أكشن',
        all: all,
      );
      expect(out.any((s) => s.kind == SuggestionKind.genre), isTrue);
    });

    test('حقل فارغ يعطي اقتراحات عامة', () {
      final out = SearchSuggestionEngine.suggest(
        query: '',
        all: all,
        profile: TasteProfile.empty.withGenreWeight('فانتازيا', 9),
        recentQueries: ['مملكة النار'],
      );
      expect(out, isNotEmpty);
      expect(out.first.kind, SuggestionKind.history);
      expect(out.any((s) => s.text == 'فانتازيا'), isTrue);
    });

    test('تطبيع الاستعلام وترتيب النتائج', () {
      expect(SearchSuggestionEngine.normalizeQuery('  أَكشن  '), 'اكشن');
      final ranked = SearchSuggestionEngine.rankTextResults('مملكة', all);
      expect(ranked.length, 2);
      expect(ranked.first.views, greaterThan(ranked.last.views));
      expect(SearchSuggestionEngine.matchesTitle('مملكة', all[0]), isTrue);
    });

    test('مخزن عمليات البحث الأخيرة', () async {
      final prefs = await _prefs();
      final store = RecentQueriesStore.testInstance(prefs);
      store.add('أكشن');
      store.add('فانتازيا');
      store.add('أكشن');
      expect(store.queries, ['أكشن', 'فانتازيا']);
      store.remove('فانتازيا');
      expect(store.queries, ['أكشن']);
      store.clear();
      expect(store.queries, isEmpty);
    });

    test('عبارات شائعة حسب الذوق', () {
      final phrases = PopularSearchPhrases.forProfile(
        TasteProfile.empty.withGenreWeight('غموض', 10),
      );
      expect(phrases.first, 'غموض');
      expect(phrases.length, lessThanOrEqualTo(8));
    });
  });

  group('ReadingCollection والروابط', () {
    test('رابط المشاركة ذهاباً وإياباً', () {
      final now = DateTime(2026, 1, 1);
      final c = ReadingCollection(
        id: 'col_1',
        name: 'أفضل ما قرأت',
        description: 'مختاراتي',
        isPublic: true,
        seriesIds: ['a', 'b'],
        createdAt: now,
        updatedAt: now,
      );
      final link = CollectionLinkCodec.encode(c);
      expect(link, startsWith('senok://collection/'));
      final back = CollectionLinkCodec.decode(link);
      expect(back, isNotNull);
      expect(back!.name, 'أفضل ما قرأت');
      expect(back.seriesIds, ['a', 'b']);
      expect(CollectionLinkCodec.shareText(c), contains('أفضل ما قرأت'));
      expect(CollectionLinkCodec.decode('not-a-link'), isNull);
      expect(CollectionLinkCodec.decode('senok://collection/!!!'), isNull);
      expect(now, isNotNull);
    });

    test('إضافة وإزالة وإعادة ترتيب', () {
      final c = ReadingCollection(
        id: 'col_1',
        name: 'تجربة',
        createdAt: DateTime(2026, 1, 1),
        updatedAt: DateTime(2026, 1, 1),
      );
      final added = c.withAdded('a').withAdded('b').withAdded('a');
      expect(added.seriesIds, ['a', 'b']); // بلا تكرار
      final removed = added.withRemoved('a');
      expect(removed.seriesIds, ['b']);
      final reordered = ReadingCollection(
        id: 'col_1',
        name: 'تجربة',
        seriesIds: ['a', 'b', 'c'],
        createdAt: DateTime(2026, 1, 1),
        updatedAt: DateTime(2026, 1, 1),
      ).withMoved(0, 2);
      expect(reordered.seriesIds, ['b', 'c', 'a']);
      expect(reordered.withMovedToTop('c').seriesIds.first, 'c');
      expect(c.withMoved(0, 9), c); // خارج النطاق = بلا تغيير
    });

    test('مخزن المجموعات: إنشاء وإضافة واستيراد', () async {
      final prefs = await _prefs();
      final store = CollectionsStore.testInstance(prefs);
      final c = store.create(name: 'قائمتي');
      expect(store.count, 1);
      expect(store.addTo(c.id, 's1'), isTrue);
      expect(store.addTo(c.id, 's1'), isFalse); // تكرار مرفوض
      expect(store.byId(c.id)!.count, 1);
      expect(store.toggleIn(c.id, 's1'), isTrue); // يزيل
      expect(store.byId(c.id)!.count, 0);
      store.toggleIn(c.id, 's2');
      expect(store.containing('s2').length, 1);
      // استيراد من رابط.
      final other = ReadingCollection(
        id: 'x',
        name: 'مستوردة',
        seriesIds: ['s9'],
        createdAt: DateTime(2026, 1, 1),
        updatedAt: DateTime(2026, 1, 1),
      );
      final imported = store.importFromLink(other.toShareLink());
      expect(imported, isNotNull);
      expect(imported!.name, 'مستوردة');
      expect(store.importFromLink('رابط تالف'), isNull);
      // الاستعادة.
      final again = CollectionsStore.testInstance(prefs);
      expect(again.count, 2);
    });

    test('المجموعات الجاهزة', () {
      final starters = StarterCollections.build();
      expect(starters.length, 3);
      expect(starters.map((c) => c.name), contains('أفضل ما قرأت'));
    });
  });

  group('AdvancedSearch و SavedSearch', () {
    test('استخدام وحفظ وإعادة تسمية', () {
      final s = SavedSearch(
        id: 's1',
        label: 'أكشن مكتمل',
        query: '',
        filters: const SearchFilters(
          genres: {'أكشن'},
          statuses: {'مكتمل'},
          minRating: 8.5,
          sort: 'rating',
        ),
        createdAt: DateTime(2026, 1, 1),
      );
      expect(s.summary, contains('أكشن'));
      expect(s.summary, contains('مكتمل'));
      final used = s.used();
      expect(used.useCount, 1);
      expect(used.lastUsedAt, isNotNull);
      expect(s.renamed('جديد').label, 'جديد');
      final back = SavedSearch.fromJson(s.toJson());
      expect(back.filters.genres, {'أكشن'});
      expect(back.filters.minRating, 8.5);
      expect(back.filters.sort, 'rating');
      expect(back.used().useCount, 1);
    });

    test('مخزن المحفوظات مرتبة بالأكثر استخداماً', () async {
      final prefs = await _prefs();
      final store = SavedSearchStore.testInstance(prefs);
      final a = store.save(label: 'أ', filters: SearchFilters.none);
      final b = store.save(label: 'ب', filters: SearchFilters.none);
      store.recordUse(b.id);
      store.recordUse(b.id);
      expect(store.items.first.id, b.id);
      expect(store.items.first.useCount, 2);
      expect(store.rename(a.id, 'أ جديد'), isTrue);
      expect(store.byId(a.id)!.label, 'أ جديد');
      expect(store.remove(a.id), isTrue);
      expect(store.items.length, 1);
    });
  });

  group('ReadingChallenges', () {
    test('ماراثون اليوم وأسبوع القارئ', () async {
      final prefs = await _prefs();
      final store = ChallengeStore.testInstance(prefs);
      final day = DateTime(2026, 11, 26, 20);
      for (var i = 0; i < 10; i++) {
        store.recordChapter(at: day);
      }
      expect(store.isCompleted('marathon_day_10'), isTrue);
      expect(store.isCompleted('chapters_week_10'), isTrue);
      expect(store.completedCount, greaterThanOrEqualTo(2));
      final p = store.progressFor('chapters_month_30');
      expect(p.current, 10);
      expect(p.remaining, 20);
      expect(p.fraction, closeTo(10 / 30, 0.001));
      expect(p.progressLabel, '10 / 30 فصلاً');
    });

    test('مواظبة 7 أيام متتالية', () async {
      final prefs = await _prefs();
      final store = ChallengeStore.testInstance(prefs);
      for (var d = 20; d <= 26; d++) {
        store.recordChapter(at: DateTime(2026, 11, d, 20));
      }
      expect(store.isCompleted('streak_7'), isTrue);
      expect(store.progressFor('streak_7').current, 7);
    });

    test('بومة الليل والتصنيفات والأعمال الجديدة', () async {
      final prefs = await _prefs();
      final store = ChallengeStore.testInstance(prefs);
      for (var i = 0; i < 5; i++) {
        store.recordChapter(at: DateTime(2026, 11, 26, 2));
      }
      expect(store.isCompleted('night_owl_5'), isTrue);
      for (final g in ['أكشن', 'دراما', 'رومانسي', 'غموض', 'كوميديا']) {
        store.recordChapter(
          at: DateTime(2026, 11, 26, 21),
          genres: [g],
        );
      }
      expect(store.isCompleted('genre_explorer_5'), isTrue);
      for (var i = 0; i < 3; i++) {
        store.recordChapter(
          at: DateTime(2026, 11, 26, 22),
          isNewSeries: true,
        );
      }
      expect(store.isCompleted('new_series_3'), isTrue);
      store.recordSeriesFinished('s1');
      expect(store.isCompleted('finish_one'), isTrue);
    });

    test('العودة بعد غياب', () async {
      final prefs = await _prefs();
      final store = ChallengeStore.testInstance(prefs);
      store.recordChapter(at: DateTime(2026, 11, 10, 20));
      store.recordChapter(at: DateTime(2026, 11, 20, 20));
      store.recordChapter(at: DateTime(2026, 11, 20, 21));
      store.recordChapter(at: DateTime(2026, 11, 20, 22));
      expect(store.isCompleted('comeback_3'), isTrue);
    });

    test('أقرب تحدٍّ للإكمال ونص المشاركة', () async {
      final prefs = await _prefs();
      final store = ChallengeStore.testInstance(prefs);
      for (var i = 0; i < 9; i++) {
        store.recordChapter(at: DateTime(2026, 11, 26, 20));
      }
      final closest = store.closestToCompletion;
      expect(closest, isNotNull);
      expect(closest!.fraction, greaterThan(0.5));
      final done = store.progressFor('marathon_day_10');
      expect(store.shareText(done), contains('Senok'));
    });

    test('التحديات الاثنا عشر معرّفة', () {
      expect(kReadingChallenges.length, 12);
      final ids = kReadingChallenges.map((c) => c.id).toSet();
      expect(ids.length, 12);
      for (final c in kReadingChallenges) {
        expect(c.target, greaterThan(0));
        expect(c.title, isNotEmpty);
        expect(c.reward, isNotEmpty);
      }
    });
  });

  group('ReadingStats', () {
    test('من أرقام خام: أفضل شهر ومتوسط يومي', () {
      final data = ReadingStatsCalculator.fromRaw(
        totalChapters: 100,
        totalSeconds: 36000,
        daysActive: 10,
        streak: 5,
        bestStreak: 9,
        bestDayChapters: 12,
        topGenre: 'أكشن',
        topSeriesTitle: 'الأول',
        topSeriesChapters: 40,
        monthlyChapters: {3: 10, 5: 20, 11: 5},
        chaptersThisWeek: 14,
        chaptersThisMonth: 40,
      );
      expect(data.bestMonth, 5);
      expect(data.bestMonthName, 'مايو');
      expect(data.chaptersPerActiveDay, 10);
      expect(data.totalMinutes, 600);
      expect(data.minutesThisWeekEstimate, 70);
      expect(data.averageMinutesPerDay, 60);
      expect(data.toShareText(), contains('Senok'));
      expect(data.toShareText(), contains('100 فصلاً'));
    });

    test('فارغ بلا نشاط', () {
      expect(ReadingStatsData.empty.hasActivity, isFalse);
      expect(ReadingStatsData.empty.bestMonthName, '—');
    });

    test('من متحكم وسجل حقيقيين', () async {
      final prefs = await _prefs({
        'reading_seconds': jsonEncode({'s1': 3600}),
        'read_chapters': jsonEncode({'s1': [1, 2, 3]}),
        'read_days': ['2026-11-24', '2026-11-25', '2026-11-26'],
        'followed_series': ['s1'],
        'series_cache': jsonEncode({
          's1': _s(id: 's1', title: 'واحد', genres: ['أكشن']).toJson(),
        }),
      });
      final settings = await SettingsController.load();
      final history = ReadingHistoryStore.testInstance(prefs);
      history.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 1,
        seconds: 300,
        at: DateTime(2026, 11, 26, 10),
      );
      final data = ReadingStatsCalculator.build(
        settings: settings,
        history: history,
        now: DateTime(2026, 11, 26, 12),
      );
      expect(data.totalChapters, 3);
      expect(data.totalMinutes, 60);
      expect(data.topGenre, 'أكشن');
      expect(data.streak, 3);
    });
  });

  group('WeeklyDigest', () {
    test('بناء موجز أسبوع من سجل حقيقي', () async {
      final prefs = await _prefs({
        'followed_series': ['s1', 's2'],
      });
      final settings = await SettingsController.load();
      final history = ReadingHistoryStore.testInstance(prefs);
      // الاثنين 23 نوفمبر 2026 (أسبوع 23–29 نوفمبر).
      history.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 1,
        seconds: 300,
        at: DateTime(2026, 11, 23, 10),
      );
      history.recordRead(
        seriesId: 's1',
        seriesTitle: 'واحد',
        chapter: 2,
        seconds: 300,
        at: DateTime(2026, 11, 23, 11),
      );
      history.recordRead(
        seriesId: 's2',
        seriesTitle: 'اثنان',
        chapter: 1,
        seconds: 300,
        at: DateTime(2026, 11, 25, 10),
      );
      final digest = WeeklyDigestBuilder.build(
        settings: settings,
        history: history,
        now: DateTime(2026, 11, 25, 12),
      );
      expect(digest.chaptersRead, 3);
      expect(digest.activeDays, 2);
      expect(digest.distinctSeries, 2);
      expect(digest.topSeriesTitle, 'واحد');
      expect(digest.topSeriesChapters, 2);
      expect(digest.minutesEstimate, 15);
      expect(digest.followedCount, 2);
      expect(digest.periodLabel, contains('2026'));
      expect(digest.quoteOfPeriod, isNotEmpty);
      expect(digest.toShareText(), contains('Senok'));
      expect(digest.toShareText(), contains('3 فصلاً'));
      // ذهاب وعودة JSON.
      final back = WeeklyDigest.fromJson(digest.toJson());
      expect(back.chaptersRead, 3);
      expect(back.id, digest.id);
    });

    test('مخزن الموجزات يحتفظ بآخر 4 فقط', () async {
      final prefs = await _prefs();
      final settings = await SettingsController.load();
      final history = ReadingHistoryStore.testInstance(prefs);
      final store = DigestStore.testInstance(prefs);
      for (var w = 0; w < 6; w++) {
        store.generate(
          settings: settings,
          history: history,
          now: DateTime(2026, 10, 5 + w * 7, 12),
        );
      }
      expect(store.digests.length, 4);
      expect(store.latest, isNotNull);
      store.remove(store.latest!.id);
      expect(store.digests.length, 3);
    });
  });
}
