import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:senok_app/core/data/models.dart';
import 'package:senok_app/features/social/achievements.dart';
import 'package:senok_app/features/social/comments_v2.dart';
import 'package:senok_app/features/social/friends_activity.dart';
import 'package:senok_app/features/social/notifications_v2.dart';
import 'package:senok_app/features/social/reading_circles.dart';
import 'package:senok_app/features/social/reviews.dart';
import 'package:senok_app/features/social/share_cards.dart';

Future<SharedPreferences> _prefs([Map<String, Object> values = const {}]) async {
  SharedPreferences.setMockInitialValues(values);
  return SharedPreferences.getInstance();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // ───────── التعليقات ─────────
  group('التعليقات v2', () {
    test('نشر تعليق والتحقق من القواعد', () async {
      final p = await _prefs();
      final store = CommentsV2Store(p);
      final empty = await store.add(
        seriesId: 's1',
        chapter: 1,
        authorId: 'me',
        authorName: 'أنا',
        text: '   ',
      );
      expect(empty.ok, isFalse);
      expect(empty.error, contains('اكتب'));

      final long = await store.add(
        seriesId: 's1',
        chapter: 1,
        authorId: 'me',
        authorName: 'أنا',
        text: 'x' * 1001,
      );
      expect(long.ok, isFalse);

      final ok = await store.add(
        seriesId: 's1',
        chapter: 1,
        authorId: 'me',
        authorName: 'أنا',
        text: 'فصل رائع!',
      );
      expect(ok.ok, isTrue);
      expect(store.countFor('s1'), 1);
      expect(store.countFor('s1', chapter: 1), 1);
      expect(store.countFor('s1', chapter: 2), 0);
    });

    test('الإعجاب والرد والتعديل والحذف', () async {
      final p = await _prefs();
      final store = CommentsV2Store(p);
      final added = await store.add(
        seriesId: 's1',
        chapter: 3,
        authorId: 'me',
        authorName: 'أنا',
        text: 'تعليق أول',
      );
      final id = added.comment!.id;
      await store.toggleLike(id);
      expect(store.byId(id)!.likes, 1);
      expect(store.byId(id)!.likedByMe, isTrue);
      await store.toggleLike(id);
      expect(store.byId(id)!.likes, 0);

      final reply = await store.addReply(
        parentId: id,
        authorId: 'u2',
        authorName: 'سارة',
        text: 'أتفق معك',
      );
      expect(reply.ok, isTrue);
      expect(store.byId(id)!.replyCount, 1);
      expect(store.stats('s1').replies, 1);

      final edited = await store.edit(id, 'تعليق معدّل');
      expect(edited, isTrue);
      expect(store.byId(id)!.text, 'تعليق معدّل');
      expect(store.byId(id)!.editedAt, isNotNull);

      final deleted = await store.delete(reply.comment!.id);
      expect(deleted, isTrue);
      expect(store.byId(id)!.replyCount, 0);
    });

    test('البلاغات تحجب التعليق بعد 3 بلاغات', () async {
      final p = await _prefs();
      final store = CommentsV2Store(p);
      final added = await store.add(
        seriesId: 's1',
        chapter: 1,
        authorId: 'me',
        authorName: 'أنا',
        text: 'تعليق مسيء',
      );
      final id = added.comment!.id;
      await store.report(id, V2ReportReason.spam);
      await store.report(id, V2ReportReason.insult);
      expect(store.byId(id)!.visible, isTrue);
      await store.report(id, V2ReportReason.other);
      expect(store.byId(id)!.visible, isFalse);
      expect(store.byId(id)!.reportCount, 3);
      await store.unhide(id);
      expect(store.byId(id)!.visible, isTrue);
    });

    test('الترتيب والترقيم والبحث', () async {
      final p = await _prefs();
      final store = CommentsV2Store(p);
      final base = DateTime(2026, 1, 1);
      for (var i = 0; i < 12; i++) {
        await store.add(
          seriesId: 's1',
          chapter: 1,
          authorId: 'u$i',
          authorName: 'قارئ $i',
          text: 'تعليق رقم $i',
          at: base.add(Duration(minutes: i)),
        );
      }
      expect(store.pageCount('s1', pageSize: 10), 2);
      expect(store.page('s1', 0, pageSize: 10).length, 10);
      expect(store.page('s1', 1, pageSize: 10).length, 2);
      expect(store.page('s1', 5, pageSize: 10), isEmpty);
      final newest = store.forSeries('s1', sort: V2CommentSort.newest);
      expect(newest.first.text, 'تعليق رقم 11');
      final oldest = store.forSeries('s1', sort: V2CommentSort.oldest);
      expect(oldest.first.text, 'تعليق رقم 0');
      expect(store.search('s1', 'رقم 5').length, 1);
      expect(store.topComments('s1', limit: 2).length, 2);
    });

    test('الحفظ والاستعادة من التخزين', () async {
      final p = await _prefs();
      final store = CommentsV2Store(p);
      await store.add(seriesId: 's1', chapter: 1, authorId: 'me', authorName: 'أنا', text: 'محفوظ');
      final restored = CommentsV2Store(p);
      expect(restored.countFor('s1'), 1);
      expect(restored.forSeries('s1').first.text, 'محفوظ');
    });

    test('صياغة الوقت الاجتماعي', () {
      final now = DateTime(2026, 1, 10, 12, 0);
      expect(socialTimeAgo(now, now: now), 'الآن');
      expect(socialTimeAgo(now.subtract(const Duration(minutes: 5)), now: now), 'قبل 5 د');
      expect(socialTimeAgo(now.subtract(const Duration(hours: 3)), now: now), 'قبل 3 س');
      expect(socialTimeAgo(now.subtract(const Duration(days: 1)), now: now), 'أمس');
      expect(socialTimeAgo(now.subtract(const Duration(days: 3)), now: now), 'قبل 3 أيام');
    });
  });

  // ───────── المراجعات ─────────
  group('المراجعات', () {
    test('الملخص والتوزيع والتوصية', () async {
      final p = await _prefs();
      final store = ReviewsStore(p);
      expect(store.summary('s1'), ReviewSummary.empty);
      await store.upsert(seriesId: 's1', authorId: 'a', authorName: 'أ', rating: 5, title: 'ممتاز', body: 'نص مراجعة طويل بما يكفي للتحقق.');
      await store.upsert(seriesId: 's1', authorId: 'b', authorName: 'ب', rating: 4, title: 'جيد جداً', body: 'نص مراجعة طويل بما يكفي للتحقق.');
      await store.upsert(seriesId: 's1', authorId: 'c', authorName: 'ج', rating: 3, title: 'جيد', body: 'نص مراجعة طويل بما يكفي للتحقق.');
      final s = store.summary('s1');
      expect(s.count, 3);
      expect(s.average, 4.0);
      expect(s.distribution[5], 1);
      expect(s.distribution[4], 1);
      expect(s.distribution[3], 1);
      expect(s.shareOf(5), closeTo(1 / 3, 0.01));
      expect(s.recommendedPercent, 67);
      expect(s.verdict, contains('ممتاز'));
    });

    test('مراجعة واحدة لكل مستخدم وتحديثها', () async {
      final p = await _prefs();
      final store = ReviewsStore(p);
      await store.upsert(seriesId: 's1', authorId: 'me', authorName: 'أنا', rating: 3, title: 'أولى', body: 'نص مراجعة طويل بما يكفي للتحقق.');
      final updated = await store.upsert(seriesId: 's1', authorId: 'me', authorName: 'أنا', rating: 5, title: 'معدّلة', body: 'نص مراجعة طويل بما يكفي للتحقق.');
      expect(store.countFor('s1'), 1);
      expect(updated!.rating, 5);
      expect(updated.editedAt, isNotNull);
      expect(store.myReview('s1', 'me')!.title, 'معدّلة');
    });

    test('التحقق القواعدي من المراجعة', () {
      expect(validateReview(title: '', body: 'نص طويل بما يكفي للتحقق من الطول.', rating: 5), isNotNull);
      expect(validateReview(title: 'عنوان', body: 'قصير', rating: 5), isNotNull);
      expect(validateReview(title: 'عنوان', body: 'نص مراجعة طويل بما يكفي للتحقق.', rating: 0), isNotNull);
      expect(validateReview(title: 'عنوان', body: 'نص مراجعة طويل بما يكفي للتحقق.', rating: 5), isNull);
    });

    test('زر مفيد والترتيب والترشيح بالنجوم', () async {
      final p = await _prefs();
      final store = ReviewsStore(p);
      await store.upsert(seriesId: 's1', authorId: 'a', authorName: 'أ', rating: 5, title: 'خمس نجوم', body: 'نص مراجعة طويل بما يكفي للتحقق.');
      await store.upsert(seriesId: 's1', authorId: 'b', authorName: 'ب', rating: 1, title: 'نجمة واحدة', body: 'نص مراجعة طويل بما يكفي للتحقق.');
      final five = store.forSeries('s1', stars: 5);
      expect(five.length, 1);
      expect(five.first.rating, 5);
      final highest = store.forSeries('s1', sort: ReviewSort.highest);
      expect(highest.first.rating, 5);
      final lowest = store.forSeries('s1', sort: ReviewSort.lowest);
      expect(lowest.first.rating, 1);
      final id = store.forSeries('s1').first.id;
      await store.toggleHelpful(id);
      expect(store.forSeries('s1').firstWhere((r) => r.id == id).helpful, 1);
    });

    test('وصف التقييم بالعربية', () {
      final r = SeriesReview(id: 'x', seriesId: 's1', authorId: 'a', authorName: 'أ', rating: 5, title: 'ت', body: 'ب', createdAt: DateTime(2026, 1, 1));
      expect(r.ratingLabel, 'تحفة فنية');
    });
  });

  // ───────── دوائر القراءة ─────────
  group('دوائر القراءة', () {
    test('إنشاء دائرة وكود دعوة من 6 أحرف', () async {
      final p = await _prefs();
      final store = ReadingCirclesStore(p);
      final c = await store.create(
        name: 'دائرة الاختبار',
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        ownerId: 'me',
        ownerName: 'أنا',
        targetChapter: 10,
      );
      expect(c, isNotNull);
      expect(c!.inviteCode.length, 6);
      expect(c.memberCount, 1);
      expect(c.ownerId, 'me');
      expect(c.averageProgress, 0);
      expect(store.byInviteCode(c.inviteCode.toLowerCase())?.id, c.id);
    });

    test('الانضمام والمغادرة ونقل الملكية', () async {
      final p = await _prefs();
      final store = ReadingCirclesStore(p);
      final c = (await store.create(
        name: 'دائرة',
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        ownerId: 'me',
        ownerName: 'أنا',
        maxMembers: 2,
      ))!;
      var err = await store.join(c.id, 'u2', 'سارة');
      expect(err, isNull);
      expect(store.byId(c.id)!.memberCount, 2);
      err = await store.join(c.id, 'u3', 'عمر');
      expect(err, contains('ممتلئة'));
      err = await store.join(c.id, 'u2', 'سارة');
      expect(err, contains('بالفعل'));
      err = await store.leave(c.id, 'me');
      expect(err, isNull);
      expect(store.byId(c.id)!.ownerId, 'u2');
    });

    test('الدائرة الخاصة تتطلب كوداً صحيحاً', () async {
      final p = await _prefs();
      final store = ReadingCirclesStore(p);
      final c = (await store.create(
        name: 'خاصة',
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        ownerId: 'me',
        ownerName: 'أنا',
        isPublic: false,
      ))!;
      var err = await store.join(c.id, 'u2', 'سارة');
      expect(err, contains('كود الدعوة'));
      err = await store.join(c.id, 'u2', 'سارة', inviteCode: 'XXXXXX');
      expect(err, contains('كود الدعوة'));
      err = await store.join(c.id, 'u2', 'سارة', inviteCode: c.inviteCode);
      expect(err, isNull);
    });

    test('التقدم والترتيب ورسائل التقدم', () async {
      final p = await _prefs();
      final store = ReadingCirclesStore(p);
      final c = (await store.create(
        name: 'دائرة',
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        ownerId: 'me',
        ownerName: 'أنا',
        targetChapter: 10,
      ))!;
      await store.join(c.id, 'u2', 'سارة');
      await store.updateProgress(c.id, 'me', 5, userName: 'أنا');
      await store.updateProgress(c.id, 'u2', 8, userName: 'سارة');
      final after = store.byId(c.id)!;
      expect(after.leaderboard.first.userId, 'u2');
      expect(after.averageProgress, closeTo(0.65, 0.01));
      final msgs = store.messages(c.id);
      expect(msgs.any((m) => m.type == CircleMessageType.progress), isTrue);
    });

    test('النقاش والتحقق من كود الدعوة', () async {
      final p = await _prefs();
      final store = ReadingCirclesStore(p);
      final c = (await store.create(
        name: 'دائرة',
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        ownerId: 'me',
        ownerName: 'أنا',
      ))!;
      final msg = await store.postMessage(circleId: c.id, authorId: 'me', authorName: 'أنا', text: 'مرحباً بالجميع');
      expect(msg, isNotNull);
      expect(store.messageCount(c.id), 2);
      final outsider = await store.postMessage(circleId: c.id, authorId: 'u9', authorName: 'غريب', text: 'أهلاً');
      expect(outsider, isNull);
      expect(validateCircle(name: '', maxMembers: 20, targetChapter: 0, seriesChapters: 0), isNotNull);
      expect(validateCircle(name: 'دائرة', maxMembers: 1, targetChapter: 0, seriesChapters: 0), isNotNull);
      expect(validateCircle(name: 'دائرة', maxMembers: 20, targetChapter: 5, seriesChapters: 3), isNotNull);
      expect(validateCircle(name: 'دائرة', maxMembers: 20, targetChapter: 2, seriesChapters: 10), isNull);
    });

    test('توليد أكواد دعوة فريدة', () {
      final codes = <String>{};
      for (var i = 0; i < 50; i++) {
        codes.add(generateInviteCode());
      }
      expect(codes.length, greaterThan(45));
      for (final code in codes) {
        expect(code.length, 6);
        expect(RegExp(r'^[A-Z0-9]+$').hasMatch(code), isTrue);
      }
    });
  });

  // ───────── نشاط الأصدقاء ─────────
  group('نشاط الأصدقاء', () {
    test('التسجيل والترشيح والتجميع', () async {
      final p = await _prefs();
      final store = FriendsActivityStore(p);
      final now = DateTime(2026, 1, 10, 12, 0);
      await store.record(
        friendId: 'u1',
        friendName: 'أحمد',
        kind: FriendActivityKind.finishedChapter,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        chapter: 5,
        at: now,
      );
      await store.record(
        friendId: 'u2',
        friendName: 'سارة',
        kind: FriendActivityKind.rated,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        rating: 5,
        at: now.subtract(const Duration(days: 1)),
      );
      expect(store.feed.length, 2);
      expect(store.unseenCount, 2);
      expect(store.filtered(kind: FriendActivityKind.rated).length, 1);
      expect(store.filtered(friendId: 'u1').length, 1);
      final groups = store.groupedByDay(now: now);
      expect(groups.containsKey('اليوم'), isTrue);
      expect(groups.containsKey('أمس'), isTrue);
      await store.markAllSeen();
      expect(store.unseenCount, 0);
    });

    test('جملة النشاط والإعجاب', () async {
      final p = await _prefs();
      final store = FriendsActivityStore(p);
      final a = await store.record(
        friendId: 'u1',
        friendName: 'أحمد',
        kind: FriendActivityKind.finishedChapter,
        seriesTitle: 'سيف الفجر',
        chapter: 7,
      );
      expect(a.sentence, contains('أحمد'));
      expect(a.sentence, contains('الفصل 7'));
      await store.toggleLike(a.id);
      expect(store.feed.first.likes, 1);
      expect(store.feed.first.likedByMe, isTrue);
    });

    test('حالة الصديق', () {
      final f = SocialFriend(
        id: 'u1',
        name: 'أحمد',
        online: true,
        currentSeriesTitle: 'سيف الفجر',
        currentChapter: 5,
      );
      expect(f.statusLabel(), 'متصل الآن');
      final off = f.copyWith(online: false);
      expect(off.statusLabel(), contains('سيف الفجر'));
    });
  });

  // ───────── بطاقات المشاركة ─────────
  group('بطاقات المشاركة', () {
    const series = Series(
      id: 's1',
      title: 'سيف الفجر',
      type: 'مانهوا كورية',
      status: 'مستمر',
      chapters: 120,
      rating: 4.6,
      views: 1250000,
      genres: ['أكشن', 'مغامرة'],
      year: 2024,
    );

    test('روابط عميقة ونصوص مشاركة', () {
      expect(ShareTextBuilder.seriesLink('s1'), 'senok://series/s1');
      expect(ShareTextBuilder.chapterLink('s1', 5), 'senok://series/s1/chapter/5');
      expect(ShareTextBuilder.circleLink('ABC123'), 'senok://circle/ABC123');
      final text = ShareTextBuilder.seriesShareText(series);
      expect(text, contains('سيف الفجر'));
      expect(text, contains('senok://series/s1'));
      expect(text, contains('#سينوك'));
      expect(text, contains('1.3 م'));
      final quote = ShareTextBuilder.quoteShareText(series, 3, 'اقتباس جميل');
      expect(quote, contains('اقتباس جميل'));
      final stats = ShareTextBuilder.statsShareText(chapters: 12, minutes: 90, streakDays: 5);
      expect(stats, contains('12 فصلاً'));
      expect(stats, contains('5'));
    });

    test('تسجيل البطاقات والسجل', () async {
      final p = await _prefs();
      final store = ShareCardsStore(p);
      await store.shareSeries(series, ShareCardTheme.ink);
      await store.shareChapter(series, 5, ShareCardTheme.gold);
      await store.shareQuote(series, 3, 'اقتباس', ShareCardTheme.night);
      await store.shareAchievement('قارئ ناشئ', seriesTitle: 'سيف الفجر');
      await store.shareStats(label: 'فصول', value: '12');
      expect(store.totalShared, 5);
      expect(store.countByKind[ShareCardKind.series], 1);
      expect(store.countByKind[ShareCardKind.quote], 1);
      expect(store.history.first.kind, ShareCardKind.stats);
      final id = store.history.first.id;
      expect(await store.delete(id), isTrue);
      expect(store.totalShared, 4);
      expect(store.history.first.shareText, contains('سينوك'));
    });

    test('سمات البطاقات لها ألوان مميزة', () {
      expect(ShareCardTheme.ink.background, isNot(ShareCardTheme.gold.background));
      expect(ShareCardTheme.gold.accent, isNot(ShareCardTheme.night.accent));
      for (final t in ShareCardTheme.values) {
        expect(t.foreground, isNot(t.background));
      }
    });
  });

  // ───────── الإنجازات ─────────
  group('الإنجازات', () {
    test('التعريفات 16 إنجازاً بلا تكرار', () {
      expect(kAchievements.length, 16);
      final ids = kAchievements.map((d) => d.id).toSet();
      expect(ids.length, 16);
      for (final d in kAchievements) {
        expect(d.target, greaterThan(0));
        expect(d.rarity.points, greaterThan(0));
      }
      final secret = kAchievements.where((d) => d.secret).toList();
      expect(secret.length, 2);
    });

    test('التقييم يفتح المستحق فقط', () async {
      final p = await _prefs();
      final store = AchievementsStore(p);
      final stats = const AchievementStats(chaptersRead: 10, streakDays: 7, comments: 1);
      final opened = await store.evaluate(stats);
      expect(opened.map((d) => d.id), contains('first_chapter'));
      expect(opened.map((d) => d.id), contains('ten_chapters'));
      expect(opened.map((d) => d.id), contains('seven_streak'));
      expect(opened.map((d) => d.id), contains('first_comment'));
      expect(opened.map((d) => d.id), isNot(contains('hundred_chapters')));
      expect(store.unlockedCount, opened.length);
      expect(store.totalPoints, greaterThan(0));
      final again = await store.evaluate(stats);
      expect(again, isEmpty);
    });

    test('التقدم والأقرب للفتح', () async {
      final p = await _prefs();
      final store = AchievementsStore(p);
      const stats = AchievementStats(chaptersRead: 50, streakDays: 3);
      final def = kAchievements.firstWhere((d) => d.id == 'hundred_chapters');
      expect(def.progressOf(stats), closeTo(0.5, 0.001));
      expect(def.unlockedBy(stats), isFalse);
      final next = store.nextAchievements(stats, limit: 3);
      expect(next.length, 3);
      expect(next.first.progressOf(stats), greaterThanOrEqualTo(next.last.progressOf(stats)));
    });

    test('إشعارات الفتح المعلّقة', () async {
      final p = await _prefs();
      final store = AchievementsStore(p);
      await store.evaluate(const AchievementStats(chaptersRead: 1));
      expect(store.pendingToasts.length, 1);
      await store.markShown('first_chapter');
      expect(store.pendingToasts, isEmpty);
      expect(store.progressFor('first_chapter').unlocked, isTrue);
    });

    test('قيمة إحصاءة غير معروفة صفر', () {
      const stats = AchievementStats();
      expect(stats.valueOf('unknown_metric'), 0);
      expect(stats.valueOf('chaptersRead'), 0);
    });
  });

  // ───────── الإشعارات v2 ─────────
  group('الإشعارات v2', () {
    test('الإضافة والقراءة والحذف', () async {
      final p = await _prefs();
      final store = NotificationsV2Store(p);
      final n = await store.add(
        kind: NotificationKind.newChapter,
        title: 'فصل جديد',
        body: 'صدر الفصل 5',
        seriesId: 's1',
        chapter: 5,
      );
      expect(n, isNotNull);
      expect(store.unreadCount, 1);
      expect(store.unreadFor(NotificationKind.newChapter), 1);
      await store.markRead(n!.id);
      expect(store.unreadCount, 0);
      expect(await store.delete(n.id), isTrue);
      expect(store.all, isEmpty);
    });

    test('النوع المعطّل لا يضيف إشعاراً', () async {
      final p = await _prefs();
      final store = NotificationsV2Store(p);
      await store.setKindEnabled(NotificationKind.reminder, false);
      expect(store.settings.isEnabled(NotificationKind.reminder), isFalse);
      final n = await store.add(kind: NotificationKind.reminder, title: 'تذكير', body: 'اقرأ');
      expect(n, isNull);
      expect(store.all, isEmpty);
      final ok = await store.add(kind: NotificationKind.system, title: 'نظام', body: 'مرحباً');
      expect(ok, isNotNull);
    });

    test('الترشيح والتجميع ومسح المقروءة', () async {
      final p = await _prefs();
      final store = NotificationsV2Store(p);
      final now = DateTime(2026, 1, 10, 12, 0);
      await store.add(kind: NotificationKind.like, title: 'إعجاب', body: 'أعجب أحدهم', at: now);
      await store.add(kind: NotificationKind.system, title: 'نظام', body: 'تحديث', at: now.subtract(const Duration(days: 1)));
      expect(store.filtered(kind: NotificationKind.like).length, 1);
      expect(store.filtered(unreadOnly: true).length, 2);
      final groups = store.groupedByDay(now: now);
      expect(groups.containsKey('اليوم'), isTrue);
      expect(groups.containsKey('أمس'), isTrue);
      await store.markAllRead();
      expect(store.unreadCount, 0);
      await store.clearRead();
      expect(store.all, isEmpty);
    });

    test('الحد الأقصى 200 إشعار', () async {
      final p = await _prefs();
      final store = NotificationsV2Store(p);
      for (var i = 0; i < 205; i++) {
        await store.add(kind: NotificationKind.system, title: 'إشعار $i', body: 'نص');
      }
      expect(store.all.length, 200);
    });
  });
}
