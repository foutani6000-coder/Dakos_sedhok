import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:senok_app/widgets/sard_icon_set.dart';
import 'package:senok_app/widgets/sard_icons.dart';

void main() {
  test('كل أيقونة لها رسم SVG صالح', () {
    expect(kSardIconSet.length, greaterThan(100));
    for (final e in kSardIconSet.entries) {
      expect(e.value.svg.startsWith('<svg'), isTrue, reason: e.key);
      expect(e.value.svg.endsWith('</svg>'), isTrue, reason: e.key);
    }
  });

  test('أسماء SardIcons مرتبطة برسم موجود', () {
    for (final i in [
      SardIcons.home_rounded,
      SardIcons.favorite_rounded,
      SardIcons.arrow_back_rounded,
      SardIcons.settings_rounded,
      SardIcons.close,
      SardIcons.person_outline,
    ]) {
      expect(kSardIconSet.containsKey(i.id), isTrue, reason: i.id);
    }
  });

  testWidgets('SIcon يُرسم بالحجم المطلوب', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: Center(child: SIcon(SardIcons.favorite_rounded, size: 30, glow: false, animate: false))),
    ));
    expect(tester.getSize(find.byType(SIcon)), const Size(30, 30));
  });
}
