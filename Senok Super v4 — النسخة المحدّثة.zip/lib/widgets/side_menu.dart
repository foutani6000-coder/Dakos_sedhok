import 'dart:convert';

import 'package:flutter/material.dart';

import '../core/config/app_config.dart';
import '../core/guide/guide_controller.dart';
import 'package:provider/provider.dart';

import '../core/storage/auth_store.dart';
import '../core/storage/settings.dart';
import '../core/theme/app_themes.dart';
import '../features/account/auth_screen.dart';
import '../features/admin/admin_dashboard.dart';
import '../features/discover/discover_screen.dart';
import '../features/settings/settings_pro.dart';
import '../features/account/library_screen.dart';
import '../features/account/profile_screen.dart';
import '../features/account/shelf_screen.dart';
import '../features/account/stamps_screen.dart';
import '../features/account/year_card_screen.dart';
import '../features/misc/chats_screen.dart';
import '../features/misc/companion_screen.dart';
import '../features/misc/legal_screen.dart';
import '../features/misc/settings_screen.dart';
import 'fx.dart';
import 'pickers.dart';
import 'pills.dart';
import 'routes.dart';
import 'sard_icons.dart';

/// زر القائمة (☰) يفتح القائمة الجانبية من أي صفحة داخل الهيكل الرئيسي
class MenuButton extends StatelessWidget {
  const MenuButton({super.key});

  @override
  Widget build(BuildContext context) {
    return RoundIconButton(
      icon: SardIcons.menu_rounded,
      onTap: () => GuideController.instance.run(
        'btn.menu',
        () => Scaffold.maybeOf(context)?.openDrawer(),
      ),
    );
  }
}

class _Entry {
  const _Entry(this.icon, this.title, this.subtitle, this.color, this.onTap, {this.badge = 0});
  final SIconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  final int badge;
}

/// القائمة الجانبية: بطاقة حساب في الأعلى، وصول سريع بأيقونات ملوّنة،
/// ثم القوانين والخصوصية. تظهر عناصرها بالتتابع عند الفتح.
class SardDrawer extends StatefulWidget {
  const SardDrawer({super.key});

  @override
  State<SardDrawer> createState() => _SardDrawerState();
}

class _SardDrawerState extends State<SardDrawer> {
  bool _logged = false;
  String? _name;
  String? _email;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    String? name;
    String? email;
    final token = await AuthStore.token();
    final raw = await AuthStore.userJson();
    if (raw != null) {
      try {
        final m = jsonDecode(raw);
        if (m is Map) {
          final u = m['user'] is Map ? m['user'] as Map : m;
          name = (u['name'] ?? u['username'])?.toString();
          email = u['email']?.toString();
        }
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _logged = token != null;
      _name = name;
      _email = email;
    });
  }

  /// يغلق القائمة ثم يفتح الصفحة
  void _open(Widget page) {
    final nav = Navigator.of(context);
    nav.pop();
    nav.push(sardRoute(page)).then((_) => _load());
  }

  void _openAppearance() {
    final nav = Navigator.of(context);
    nav.pop();
    final p = context.pal;
    GuideController.instance.show('sheet.appearance');
    showModalBottomSheet<void>(
      context: nav.context,
      isScrollControlled: true,
      backgroundColor: p.surface,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              SectionHeader(title: 'خزانة المظهر'),
              ThemePicker(),
              SizedBox(height: 14),
              AccentTonePicker(),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _logout() async {
    await AuthStore.clear();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final width = (MediaQuery.of(context).size.width * 0.86).clamp(280.0, 360.0).toDouble();

    final st = context.watch<SettingsController>();
    int count(ShelfKind k) => switch (k) {
          ShelfKind.favorites => st.favoriteIds.length,
          ShelfKind.reading => st.readingIds.length,
          ShelfKind.later => st.laterIds.length,
        };
    final shelves = <_Entry>[
      _Entry(SardIcons.favorite_rounded, 'المفضلة', 'أعمالك المحبّبة', const Color(0xFFE0457B),
          () => _open(const ShelfScreen(initial: ShelfKind.favorites)), badge: count(ShelfKind.favorites)),
      _Entry(SardIcons.auto_stories_rounded, 'أقرؤها حالياً', 'أكمل من حيث توقّفت', const Color(0xFF3B9EFF),
          () => _open(const ShelfScreen(initial: ShelfKind.reading)), badge: count(ShelfKind.reading)),
      _Entry(SardIcons.watch_later_rounded, 'القراءة لاحقاً', 'أعمال محفوظة لوقت آخر', const Color(0xFFF5A524),
          () => _open(const ShelfScreen(initial: ShelfKind.later)), badge: count(ShelfKind.later)),
    ];

    final quick = <_Entry>[
      _Entry(SardIcons.person_rounded, 'الملف الشخصي', 'لوحتك والإحصاءات', const Color(0xFF3B9EFF), () => _open(const ProfileScreen())),
      _Entry(SardIcons.explore_rounded, 'اكتشف', 'توصيات وتحديات وموجز', const Color(0xFF22C7D6), () => _open(const DiscoverScreen())),
      _Entry(SardIcons.shield_rounded, 'لوحة الأدمن', 'إدارة الأعمال والفصول', const Color(0xFFE0457B), () => _open(const AdminDashboardScreen())),
      _Entry(SardIcons.tune_rounded, 'الإعدادات الاحترافية', 'تنزيلات وتخزين ومزامنة', const Color(0xFFA463F2), () => _open(const SettingsProScreen())),
      _Entry(SardIcons.download_rounded, 'تنزيلات v2', 'طابور التنزيل الجديد', const Color(0xFFF5A524), () => _open(const V2DownloadQueueScreen())),
      _Entry(SardIcons.auto_awesome_rounded, 'أختامي', 'إنجازاتك وشعلة القراءة', const Color(0xFFF2C14E), () => _open(const StampsScreen())),
      _Entry(SardIcons.calendar_today_rounded, 'سنتي في القراءة', 'حصيلتك في بطاقة واحدة', const Color(0xFF3B9EFF), () => _open(const YearCardScreen())),
      _Entry(SardIcons.chat_bubble_rounded, 'المحادثات', 'تحدّث مع القرّاء', const Color(0xFF2FCB7A), () => _open(const ChatsScreen()), badge: 2),
      _Entry(SardIcons.collections_bookmark_rounded, 'قوائمي', 'مكتبتك وسجل القراءة', const Color(0xFFA463F2), () => _open(const LibraryScreen())),
      _Entry(SardIcons.auto_awesome_rounded, 'خزانة المظهر', 'ثيمات وألوان لتطبيقك', const Color(0xFFF5A524), _openAppearance),
      _Entry(SardIcons.pets_rounded, 'رفيقي', 'اسمه وحالته', const Color(0xFFE0457B), () => _open(const CompanionScreen())),
      _Entry(SardIcons.settings_rounded, 'الإعدادات', 'الخصوصية والتخزين', const Color(0xFF22C7D6), () => _open(const SettingsScreen(standalone: true))),
    ];

    final legal = <_Entry>[
      _Entry(SardIcons.shield_rounded, 'سياسة الخصوصية', '', const Color(0xFF8FA3B8), () => _open(LegalScreen.privacy())),
      _Entry(SardIcons.gavel_rounded, 'شروط الاستخدام', '', const Color(0xFF8FA3B8), () => _open(LegalScreen.terms())),
      _Entry(SardIcons.copyright_rounded, 'حقوق النشر والإبلاغ', '', const Color(0xFF8FA3B8), () => _open(LegalScreen.copyright())),
    ];

    var idx = 0;
    return Drawer(
      width: width,
      backgroundColor: p.bg,
      surfaceTintColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadiusDirectional.only(
          topEnd: Radius.circular(32),
          bottomEnd: Radius.circular(32),
        ),
      ),
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
          children: [
            FadeSlide(index: idx++, child: _accountCard(context)),
            const SizedBox(height: 22),
            _label(context, 'رفّي'),
            for (final e in shelves) FadeSlide(index: idx++, dy: 12, child: _tile(context, e)),
            const SizedBox(height: 14),
            _label(context, 'الوصول السريع'),
            for (final e in quick) FadeSlide(index: idx++, dy: 12, child: _tile(context, e)),
            const SizedBox(height: 14),
            _label(context, 'القوانين والخصوصية'),
            for (final e in legal) FadeSlide(index: idx++, dy: 12, child: _tile(context, e, compact: true)),
            const SizedBox(height: 14),
            Center(child: Text('${AppConfig.appName} · ${AppConfig.version}', style: context.ts(size: 12, color: p.textDim))),
          ],
        ),
      ),
    );
  }

  Widget _label(BuildContext context, String t) => Padding(
        padding: const EdgeInsets.fromLTRB(6, 0, 6, 10),
        child: Text(t, style: context.ts(size: 12.5, w: FontWeight.w700, color: context.pal.textDim)),
      );

  Widget _accountCard(BuildContext context) {
    final p = context.pal;
    final name = _logged ? (_name ?? 'قارئ Senok') : 'زائر ${AppConfig.appName}';
    final initial = name.characters.first;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(p.r(1.3).clamp(12.0, 34.0).toDouble()),
        border: Border.all(color: p.border, width: p.borderW),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [tint(p.accent, 0.26), p.surface],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: [p.accent, p.gold]),
                ),
                child: Container(
                  width: 54,
                  height: 54,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: p.surface),
                  child: Text(initial, style: context.ds(size: 26, color: p.accent)),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.ds(size: 21)),
                    const SizedBox(height: 3),
                    Text(
                      _logged ? (_email ?? 'حساب متصل') : 'ادخل لحفظ مكتبتك ومتابعة المجتمع',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: context.ts(size: 12, color: p.textDim),
                    ),
                  ],
                ),
              ),
              if (_logged)
                IconButton(tooltip: 'تسجيل الخروج', onPressed: _logout, icon: SIcon(SardIcons.logout_rounded, color: p.textDim, size: 22)),
            ],
          ),
          if (!_logged) ...[
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: () => _open(const AuthScreen()),
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                    child: const Text('تسجيل الدخول'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _open(const AuthScreen(startRegister: true)),
                    style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                    child: Text('حساب جديد', style: context.ts(size: 13, w: FontWeight.w700)),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, _Entry e, {bool compact = false}) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Pressable(
        scale: 0.975,
        onTap: e.onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: compact ? 10 : 12),
          decoration: BoxDecoration(
            color: p.glass ? tint(p.surface, 0.7) : p.surface,
            borderRadius: BorderRadius.circular(p.r(1).clamp(10.0, 28.0).toDouble()),
            border: Border.all(color: p.border, width: p.borderW),
          ),
          child: Row(
            children: [
              Container(
                width: compact ? 38 : 46,
                height: compact ? 38 : 46,
                decoration: BoxDecoration(
                  color: tint(e.color, 0.16),
                  borderRadius: BorderRadius.circular(p.r(compact ? 0.65 : 0.8).clamp(8.0, 18.0).toDouble()),
                ),
                child: SIcon(e.icon, color: e.color, size: compact ? 20 : 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(e.title, style: context.ts(size: compact ? 13.5 : 15, w: FontWeight.w700)),
                    if (e.subtitle.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(e.subtitle, style: context.ts(size: 11.5, color: p.textDim)),
                    ],
                  ],
                ),
              ),
              if (e.badge > 0)
                Container(
                  margin: const EdgeInsetsDirectional.only(end: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: e.color, borderRadius: BorderRadius.circular(99)),
                  child: Text('${e.badge}', style: context.ts(size: 11, w: FontWeight.w800, color: Colors.white)),
                ),
              SIcon(SardIcons.chevron_left_rounded, color: p.textDim),
            ],
          ),
        ),
      ),
    );
  }
}
