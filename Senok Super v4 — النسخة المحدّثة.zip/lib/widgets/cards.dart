import 'package:flutter/material.dart';

import '../core/data/models.dart';
import '../core/theme/app_themes.dart';
import 'cover_art.dart';
import 'fx.dart';
import 'sard_icons.dart';

/// وسم «جديد» صغير
class NewTag extends StatelessWidget {
  const NewTag({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: p.accent,
        borderRadius: BorderRadius.circular(p.r(0.4).clamp(5.0, 12.0).toDouble()),
        boxShadow: p.glow > 0
            ? [BoxShadow(color: tint(p.accent, 0.5 * p.glow), blurRadius: 8)]
            : null,
      ),
      child: Text('جديد', style: context.ts(size: 10, w: FontWeight.w700, color: p.onAccent)),
    );
  }
}

/// تقييم ذهبي صغير (نجمة + رقم)
class RatingMark extends StatelessWidget {
  const RatingMark({super.key, required this.rating, this.size = 13, this.onDark = false});
  final double rating;
  final double size;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SIcon(SardIcons.star_rounded, size: size + 3, color: p.gold),
        const SizedBox(width: 3),
        Text(
          rating.toStringAsFixed(1),
          style: context.ts(
            size: size,
            w: FontWeight.w700,
            color: onDark ? Colors.white : p.text,
          ),
        ),
      ],
    );
  }
}

/// بطاقة غلاف عمودية (للقوائم الأفقية): الغلاف بتدرّج سفلي والتقييم داخله.
class PosterCard extends StatelessWidget {
  const PosterCard({
    super.key,
    required this.series,
    required this.onTap,
    this.width = 140,
    this.subtitle,
    this.heroTag,
  });

  final Series series;
  final VoidCallback onTap;
  final double width;
  final String? subtitle;
  final String? heroTag;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final rad = p.r(0.9).clamp(8.0, 28.0).toDouble();
    final cover = CoverArt(series: series, radius: rad);
    final tone = seriesTone(series);
    return Pressable(
      onTap: onTap,
      child: SizedBox(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 0.7,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(rad),
                  border: Border.all(color: tint(p.text, 0.06), width: p.borderW),
                  boxShadow: [
                    BoxShadow(
                      color: tint(tone, p.isDark ? 0.24 : 0.16),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                    ...softShadow(p, strength: 0.8),
                  ],
                ),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    heroTag == null ? cover : Hero(tag: heroTag!, child: cover),
                    // لمعة زجاجية خفيفة في الزاوية العلوية
                    Positioned.fill(
                      child: IgnorePointer(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(rad),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [tint(Colors.white, 0.14), tint(Colors.white, 0)],
                              stops: const [0, 0.4],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      height: 64,
                      child: IgnorePointer(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.vertical(bottom: Radius.circular(rad)),
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.transparent, tint(Colors.black, 0.78)],
                            ),
                          ),
                        ),
                      ),
                    ),
                    if (series.isNew)
                      const PositionedDirectional(top: 8, end: 8, child: NewTag()),
                    PositionedDirectional(
                      bottom: 9,
                      start: 9,
                      child: Text(
                        '${series.chapters} فصل',
                        style: context.ts(size: 10.5, w: FontWeight.w700, color: tint(Colors.white, 0.85)),
                      ),
                    ),
                    if (series.rating > 0)
                      PositionedDirectional(
                        top: 8,
                        start: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: tint(Colors.black, 0.42),
                            borderRadius: BorderRadius.circular(99),
                            border: Border.all(color: tint(Colors.white, 0.14), width: 0.8),
                          ),
                          child: RatingMark(rating: series.rating, size: 12, onDark: true),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              series.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: context.ts(size: 13.5, w: FontWeight.w600, height: 1.3),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle ?? '${series.type} · ${series.chapters} فصل',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.ts(size: 11.5, color: p.textDim),
            ),
          ],
        ),
      ),
    );
  }
}

/// صف عمل أفقي (للترتيب وللبحث)
class SeriesTile extends StatelessWidget {
  const SeriesTile({super.key, required this.series, required this.onTap, this.rank, this.heroTag});
  final Series series;
  final VoidCallback onTap;
  final int? rank;
  final String? heroTag;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final cover = CoverArt(series: series, radius: p.r(0.7).clamp(6.0, 20.0).toDouble());
    final top = rank != null && rank! <= 3;
    final genres = series.genres.take(2).join(' · ');
    return Pressable(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(20, 0, 20, 12),
        padding: const EdgeInsets.fromLTRB(12, 10, 14, 10),
        decoration: BoxDecoration(
          color: p.glass ? tint(p.surface, 0.78) : p.surface,
          borderRadius: BorderRadius.circular(p.r(1.2).clamp(10.0, 32.0).toDouble()),
          border: Border.all(color: top ? tint(p.accent, 0.4) : tint(p.border, 0.65), width: p.borderW),
          boxShadow: softShadow(p, strength: top ? 0.9 : 0.55),
        ),
        child: Row(
          children: [
            if (rank != null)
              SizedBox(
                width: 40,
                child: Center(
                  child: top
                      ? ShaderMask(
                          blendMode: BlendMode.srcIn,
                          shaderCallback: (r) => LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [p.gold, Color.lerp(p.gold, p.accent, 0.65)!],
                          ).createShader(r),
                          child: Text('$rank', style: context.ds(size: 34, color: Colors.white)),
                        )
                      : Text(
                          '$rank',
                          style: context.ds(size: 26, color: tint(p.textDim, 0.7)),
                        ),
                ),
              ),
            SizedBox(
              width: 62,
              height: 88,
              child: heroTag == null ? cover : Hero(tag: heroTag!, child: cover),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    series.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.ts(size: 15, w: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    genres.isEmpty ? series.type : genres,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.ts(size: 12, color: p.textDim),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      SIcon(SardIcons.menu_book_rounded, size: 14, color: p.textDim),
                      const SizedBox(width: 4),
                      Text('${series.chapters} فصل',
                          style: context.ts(size: 11.5, w: FontWeight.w500, color: p.textDim)),
                      const SizedBox(width: 12),
                      SIcon(SardIcons.visibility_rounded, size: 14, color: p.textDim),
                      const SizedBox(width: 4),
                      Text(formatCount(series.views),
                          style: context.ts(size: 11.5, w: FontWeight.w500, color: p.textDim)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            if (series.rating > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                decoration: BoxDecoration(
                  color: tint(p.gold, 0.13),
                  borderRadius: BorderRadius.circular(p.r(0.6).clamp(6.0, 16.0).toDouble()),
                ),
                child: RatingMark(rating: series.rating),
              )
            else
              SIcon(SardIcons.chevron_left_rounded, color: p.textDim),
          ],
        ),
      ),
    );
  }
}
