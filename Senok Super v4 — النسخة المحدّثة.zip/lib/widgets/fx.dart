import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/data/models.dart';
import '../core/theme/app_themes.dart';

/// ضغطة بتأثير تصغير ناعم
class Pressable extends StatefulWidget {
  const Pressable({super.key, required this.child, this.onTap, this.scale = 0.965});
  final Widget child;
  final VoidCallback? onTap;
  final double scale;

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) => setState(() => _down = false),
      onTapCancel: () => setState(() => _down = false),
      onTap: widget.onTap == null
          ? null
          : () {
              HapticFeedback.selectionClick();
              widget.onTap!();
            },
      // ضغط سريع، ثم ارتداد مرن ناعم عند الإفلات
      child: AnimatedScale(
        scale: _down ? widget.scale : 1,
        duration: Duration(milliseconds: _down ? 110 : 420),
        curve: _down ? Curves.easeOutCubic : Curves.elasticOut,
        child: AnimatedOpacity(
          opacity: _down ? 0.9 : 1,
          duration: const Duration(milliseconds: 140),
          child: widget.child,
        ),
      ),
    );
  }
}

/// ظهور تدريجي مع انزلاق خفيف. index يؤخّر العناصر اللاحقة.
class FadeSlide extends StatelessWidget {
  const FadeSlide({super.key, required this.child, this.index = 0, this.dy = 18});
  final Widget child;
  final int index;
  final double dy;

  @override
  Widget build(BuildContext context) {
    final i = index > 10 ? 10 : index;
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 650 + i * 80),
      curve: Curves.easeOutQuart,
      builder: (context, v, ch) => Opacity(
        opacity: Curves.easeOut.transform(v.clamp(0.0, 1.0)),
        child: Transform.translate(
          offset: Offset(0, (1 - v) * dy),
          child: Transform.scale(scale: 0.97 + 0.03 * v, child: ch),
        ),
      ),
      child: child,
    );
  }
}

/// مربع تحميل نابض
class Skeleton extends StatefulWidget {
  const Skeleton({super.key, this.width, this.height, this.radius = 14});
  final double? width;
  final double? height;
  final double radius;

  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) => Container(
        width: widget.width,
        height: widget.height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(widget.radius),
          // لمعان انسيابي يعبر العنصر
          gradient: LinearGradient(
            begin: Alignment(-1.6 + 3.2 * _c.value, -0.3),
            end: Alignment(-0.6 + 3.2 * _c.value, 0.3),
            colors: [p.surface, Color.lerp(p.surface, p.surfaceHi, 0.9)!, p.surface],
          ),
        ),
      ),
    );
  }
}

/// عدّاد يرتفع من الصفر (للمشاهدات)
class CountUp extends StatelessWidget {
  const CountUp({super.key, required this.value, this.style});
  final int value;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: value.toDouble()),
      duration: const Duration(milliseconds: 1300),
      curve: Curves.easeOutCubic,
      builder: (context, v, _) => Text(formatCount(v.round()), style: style),
    );
  }
}
