import 'package:flutter/material.dart';

import '../core/data/models.dart';
import '../core/theme/app_themes.dart';

/// لون كل نوع توثيق: بنفسجي / أزرق / أصفر
Color badgeColor(SardBadge b) {
  switch (b) {
    case SardBadge.purple:
      return const Color(0xFF9B5CFF);
    case SardBadge.blue:
      return const Color(0xFF3B9EFF);
    case SardBadge.yellow:
      return const Color(0xFFFFC21A);
    case SardBadge.none:
      return Colors.transparent;
  }
}

/// علامة التوثيق. اضغط عليها لمعرفة معنى كل لون.
class VerifiedBadge extends StatelessWidget {
  const VerifiedBadge(this.badge, {super.key, this.size = 16, this.tappable = true});
  final SardBadge badge;
  final double size;
  final bool tappable;

  @override
  Widget build(BuildContext context) {
    if (badge.isNone) return const SizedBox.shrink();
    final icon = Icon(Icons.verified_rounded, size: size, color: badgeColor(badge));
    if (!tappable) return icon;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => showBadgeInfo(context, current: badge),
      child: icon,
    );
  }
}

/// الاسم + علامة التوثيق بجانبه
class NameWithBadge extends StatelessWidget {
  const NameWithBadge(this.name, this.badge, {super.key, this.style, this.badgeSize = 16, this.center = false});
  final String name;
  final SardBadge badge;
  final TextStyle? style;
  final double badgeSize;
  final bool center;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: center ? MainAxisAlignment.center : MainAxisAlignment.start,
      children: [
        Flexible(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: style)),
        if (!badge.isNone) ...[
          const SizedBox(width: 5),
          VerifiedBadge(badge, size: badgeSize),
        ],
      ],
    );
  }
}

/// ورقة تشرح أنواع التوثيق الثلاثة
Future<void> showBadgeInfo(BuildContext context, {SardBadge current = SardBadge.none}) {
  final p = context.pal;
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: p.surface,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (sheet) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(22, 20, 22, 22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('أنواع التوثيق', style: context.ds(size: 22)),
            const SizedBox(height: 14),
            for (final b in const [SardBadge.purple, SardBadge.blue, SardBadge.yellow])
              Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: tint(badgeColor(b), b == current ? 0.16 : 0.08),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: tint(badgeColor(b), b == current ? 0.7 : 0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.verified_rounded, size: 30, color: badgeColor(b)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(b.label, style: context.ts(size: 14.5, w: FontWeight.w800)),
                          const SizedBox(height: 2),
                          Text(b.description, style: context.ts(size: 12, color: p.textDim, height: 1.6)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    ),
  );
}

/// أفاتار دائري بحلقة بلون التوثيق (إن وُجد)
class RingAvatar extends StatelessWidget {
  const RingAvatar({super.key, required this.name, this.badge = SardBadge.none, this.size = 40, this.image});
  final String name;
  final SardBadge badge;
  final double size;
  final ImageProvider? image;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = badge.isNone ? p.accent : badgeColor(badge);
    final t = name.trim();
    final initial = t.isEmpty ? '؟' : String.fromCharCode(t.runes.first);
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: tint(c, 0.18),
        image: image == null ? null : DecorationImage(image: image!, fit: BoxFit.cover),
        border: Border.all(color: badge.isNone ? tint(c, 0.5) : c, width: badge.isNone ? 1.4 : 2.2),
      ),
      child: image == null ? Text(initial, style: context.ds(size: size * 0.44, color: c)) : null,
    );
  }
}
