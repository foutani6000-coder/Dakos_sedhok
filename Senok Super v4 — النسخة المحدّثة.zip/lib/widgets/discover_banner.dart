import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../core/data/models.dart';
import '../core/theme/app_themes.dart';
import 'cover_art.dart';
import 'fx.dart';
import 'sard_icons.dart';

String _hex(Color c) => '#${c.value.toRadixString(16).padLeft(8, '0').substring(2)}';

/// لافتة «أورورا» في الرئيسية:
///  • خلفية شفقية: ثلاث بقع ضوء تنساب باستمرار + نجوم تومض.
///  • مروحة من أغلفة حقيقية تطفو وتتمايل (أو رسمة SVG إن لم تتوفر أغلفة).
///  • نص تلميحي يتبدّل تلقائياً، وزر ذهبي نابض يفتح البحث الدقيق.
/// تتوقف الحركة تلقائياً عند تفعيل «تقليل الحركة» في النظام.
class DiscoverBanner extends StatefulWidget {
  const DiscoverBanner({super.key, required this.onTap, this.covers = const []});

  final VoidCallback onTap;

  /// أغلفة تظهر في المروحة (يُؤخذ أول ثلاثة).
  final List<Series> covers;

  @override
  State<DiscoverBanner> createState() => _DiscoverBannerState();
}

class _DiscoverBannerState extends State<DiscoverBanner> with SingleTickerProviderStateMixin {
  static const _hints = <String>[
    'بحث دقيق بالفصول والنوع والتقييم',
    'أكشن · خيال · رومانسي · غموض',
    'رتّب بالأحدث أو الأعلى تقييماً',
  ];

  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 14),
  );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.of(context).disableAnimations) {
      _c.stop();
    } else if (!_c.isAnimating) {
      _c.repeat();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  String _art(Color accent, Color gold) {
    final a = _hex(accent);
    final g = _hex(gold);
    return '''
<svg viewBox="0 0 160 130" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="glow" cx="50%" cy="55%" r="50%">
      <stop offset="0" stop-color="$a" stop-opacity="0.6"/>
      <stop offset="1" stop-color="$a" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="page" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="$g"/>
      <stop offset="1" stop-color="$a"/>
    </linearGradient>
    <linearGradient id="crown" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#FFF1B8"/>
      <stop offset="1" stop-color="$g"/>
    </linearGradient>
  </defs>
  <circle cx="80" cy="70" r="64" fill="url(#glow)"/>
  <path d="M80 52 C62 42 38 42 20 50 V104 C38 96 62 96 80 106 Z" fill="url(#page)" fill-opacity="0.95"/>
  <path d="M80 52 C98 42 122 42 140 50 V104 C122 96 98 96 80 106 Z" fill="url(#page)" fill-opacity="0.68"/>
  <path d="M80 52 V106" stroke="#FFFFFF" stroke-opacity="0.55" stroke-width="1.6"/>
  <path d="M32 62 C46 58 58 60 70 66" stroke="#FFFFFF" stroke-opacity="0.6" stroke-width="2.2" stroke-linecap="round" fill="none"/>
  <path d="M32 74 C46 70 58 72 70 78" stroke="#FFFFFF" stroke-opacity="0.45" stroke-width="2.2" stroke-linecap="round" fill="none"/>
  <path d="M90 66 C102 60 114 58 128 62" stroke="#FFFFFF" stroke-opacity="0.45" stroke-width="2.2" stroke-linecap="round" fill="none"/>
  <path d="M62 36 L69 14 L80 28 L91 14 L98 36 Z" fill="url(#crown)"/>
  <circle cx="69" cy="12" r="3" fill="#FFF1B8"/>
  <circle cx="80" cy="25" r="2.6" fill="#FFFFFF"/>
  <circle cx="91" cy="12" r="3" fill="#FFF1B8"/>
  <path d="M130 22 L132.6 29.4 L140 32 L132.6 34.6 L130 42 L127.4 34.6 L120 32 L127.4 29.4 Z" fill="#FFFFFF" fill-opacity="0.95"/>
</svg>
''';
  }

  /// مروحة الأغلفة: جانبان مائلان وغلاف مركزي، تتمايل جميعها بلطف.
  Widget _fan(List<Series> items) {
    final n = items.length;
    final angles = n == 1
        ? const <double>[0.0]
        : n == 2
            ? const <double>[-0.17, 0.17]
            : const <double>[-0.27, 0.27, 0.0];
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final bob = math.sin(_c.value * math.pi * 2);
        return Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            for (var i = 0; i < n; i++)
              Transform.translate(
                offset: Offset(angles[i] * 96, (angles[i] == 0 ? -4.0 : 7.0) + bob * (2.5 + i * 1.3)),
                child: Transform.rotate(
                  angle: angles[i] + bob * 0.014 * (i.isEven ? 1 : -1),
                  child: _MiniCover(series: items[i]),
                ),
              ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final covers = widget.covers.take(3).toList();
    final base1 = Color.lerp(p.surface, p.accent, p.isDark ? 0.3 : 0.2)!;
    final base2 = Color.lerp(p.bg, p.accent, p.isDark ? 0.1 : 0.06)!;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Pressable(
        scale: 0.98,
        onTap: widget.onTap,
        child: RepaintBoundary(
          child: Container(
            height: 156,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: tint(p.gold, 0.55), width: 1.2),
              boxShadow: [
                BoxShadow(color: tint(p.accent, 0.3), blurRadius: 28, offset: const Offset(0, 10)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(27),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  CustomPaint(
                    painter: _AuroraPainter(
                      t: _c,
                      accent: p.accent,
                      gold: p.gold,
                      base1: base1,
                      base2: base2,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(10, 10, 18, 10),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 128,
                          child: covers.isEmpty
                              ? AnimatedBuilder(
                                  animation: _c,
                                  builder: (context, child) => Transform.translate(
                                    offset: Offset(0, math.sin(_c.value * math.pi * 2) * 4),
                                    child: child,
                                  ),
                                  child: SvgPicture.string(_art(p.accent, p.gold), fit: BoxFit.contain),
                                )
                              : _fan(covers),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'اكتشف حكايتك القادمة',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: context.ts(size: 17, w: FontWeight.w800),
                              ),
                              const SizedBox(height: 4),
                              AnimatedBuilder(
                                animation: _c,
                                builder: (context, _) {
                                  final i = (_c.value * _hints.length).floor() % _hints.length;
                                  return AnimatedSwitcher(
                                    duration: const Duration(milliseconds: 500),
                                    transitionBuilder: (child, anim) => FadeTransition(
                                      opacity: anim,
                                      child: SlideTransition(
                                        position: Tween<Offset>(
                                          begin: const Offset(0, 0.4),
                                          end: Offset.zero,
                                        ).animate(anim),
                                        child: child,
                                      ),
                                    ),
                                    layoutBuilder: (current, previous) => Stack(
                                      alignment: AlignmentDirectional.centerStart,
                                      children: [...previous, if (current != null) current],
                                    ),
                                    child: Text(
                                      _hints[i],
                                      key: ValueKey(i),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: context.ts(size: 11.5, color: p.textDim, height: 1.4),
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(height: 11),
                              AnimatedBuilder(
                                animation: _c,
                                builder: (context, child) {
                                  final pulse = (math.sin(_c.value * math.pi * 2 * 7) + 1) / 2;
                                  return Transform.scale(
                                    scale: 1 + 0.025 * pulse,
                                    alignment: AlignmentDirectional.centerStart,
                                    child: Container(
                                      padding: const EdgeInsetsDirectional.fromSTEB(15, 8, 11, 8),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [p.gold, Color.lerp(p.gold, Colors.white, 0.35)!],
                                        ),
                                        borderRadius: BorderRadius.circular(99),
                                        boxShadow: [
                                          BoxShadow(
                                            color: tint(p.gold, 0.28 + 0.22 * pulse),
                                            blurRadius: 10 + 8 * pulse,
                                          ),
                                        ],
                                      ),
                                      child: child,
                                    ),
                                  );
                                },
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      'ابدأ الاستكشاف',
                                      style: context.ts(size: 12.5, w: FontWeight.w800, color: Colors.black),
                                    ),
                                    const SizedBox(width: 6),
                                    const SIcon(
                                      SardIcons.arrow_back_rounded,
                                      size: 15,
                                      color: Colors.black,
                                      animate: false,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// غلاف مصغّر داخل المروحة.
class _MiniCover extends StatelessWidget {
  const _MiniCover({required this.series});
  final Series series;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 66,
      height: 94,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(11),
        boxShadow: [
          BoxShadow(
            color: tint(Colors.black, 0.45),
            blurRadius: 14,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      foregroundDecoration: BoxDecoration(
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: tint(Colors.white, 0.4), width: 1),
      ),
      child: CoverArt(series: series, radius: 11, showTitle: false),
    );
  }
}

/// خلفية شفقية متحركة. كل الترددات أعداد صحيحة لتكرّر الحركة دون قفزة.
class _AuroraPainter extends CustomPainter {
  _AuroraPainter({
    required this.t,
    required this.accent,
    required this.gold,
    required this.base1,
    required this.base2,
  }) : super(repaint: t);

  final Animation<double> t;
  final Color accent;
  final Color gold;
  final Color base1;
  final Color base2;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final v = t.value * math.pi * 2;

    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [base1, base2],
        ).createShader(rect),
    );

    void blob(double fx, double fy, double phase, double radius, Color c, double alpha) {
      final cx = size.width * (0.5 + 0.44 * math.sin(v * fx + phase));
      final cy = size.height * (0.5 + 0.42 * math.cos(v * fy + phase * 1.3));
      final r = size.shortestSide * radius;
      final center = Offset(cx, cy);
      canvas.drawCircle(
        center,
        r,
        Paint()
          ..shader = RadialGradient(
            colors: [tint(c, alpha), tint(c, 0)],
          ).createShader(Rect.fromCircle(center: center, radius: r)),
      );
    }

    blob(1, 1, 0.0, 0.95, accent, 0.55);
    blob(1, 2, 2.1, 0.8, gold, 0.38);
    blob(2, 1, 4.2, 0.7, Color.lerp(accent, Colors.white, 0.35)!, 0.3);

    // نجوم تومض
    final r = math.Random(11);
    for (var i = 0; i < 16; i++) {
      final x = r.nextDouble() * size.width;
      final y = r.nextDouble() * size.height;
      final k = 1 + r.nextInt(3);
      final phase = r.nextDouble() * math.pi * 2;
      final tw = (math.sin(v * k + phase) + 1) / 2;
      canvas.drawCircle(
        Offset(x, y),
        0.7 + r.nextDouble() * 1.1,
        Paint()..color = tint(Colors.white, 0.12 + 0.6 * tw),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _AuroraPainter old) =>
      old.accent != accent || old.gold != gold || old.base1 != base1 || old.base2 != base2;
}
