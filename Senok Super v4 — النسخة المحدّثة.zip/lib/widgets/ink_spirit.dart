import 'package:flutter/material.dart';

import '../core/theme/app_themes.dart';
import 'sard_icons.dart';

/// شعار التطبيق: «ختم Senok» — مربع مدوّر قرمزي بإطار داخلي رفيع كختم الخطّاط
/// وفي وسطه حرف «س».
class LogoMark extends StatelessWidget {
  const LogoMark({super.key, this.size = 40, this.glow = false});
  final double size;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final r = size * 0.3;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            Color.lerp(p.accent, Colors.white, 0.2)!,
            p.accent,
            Color.lerp(p.accent, Colors.black, 0.28)!,
          ],
          stops: const [0, 0.5, 1],
        ),
        boxShadow: glow
            ? [
                BoxShadow(
                  color: tint(p.accent, 0.45),
                  blurRadius: size * 0.8,
                  spreadRadius: size * 0.02,
                ),
              ]
            : null,
      ),
      child: Padding(
        padding: EdgeInsets.all(size * 0.09),
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(r * 0.7),
            border: Border.all(
              color: tint(p.onAccent, 0.5),
              width: size > 60 ? 1.6 : 1.1,
            ),
          ),
          child: Center(
            child: Text(
              'س',
              style: context.ds(
                size: size * 0.52,
                w: FontWeight.w600,
                color: p.onAccent,
                height: 1.1,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// تعابير الشارة الصغيرة تتبدل بحسب سياق الشاشة.
enum InkSpiritMood { calm, happy, curious, sleepy, concerned, excited }

/// ختم «Senok» عائم بهالة ناعمة. يُستخدم في الحالات الفارغة وشاشات الخطأ.
/// (حافظنا على الاسم القديم ليبقى باقي التطبيق يعمل دون تغيير.)
class InkSpirit extends StatefulWidget {
  const InkSpirit({super.key, this.size = 84, this.mood = InkSpiritMood.calm});
  final double size;
  final InkSpiritMood mood;

  @override
  State<InkSpirit> createState() => _InkSpiritState();
}

class _InkSpiritState extends State<InkSpirit> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2600),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  SIconData? get _badge {
    switch (widget.mood) {
      case InkSpiritMood.concerned:
        return SardIcons.priority_high_rounded;
      case InkSpiritMood.excited:
        return SardIcons.auto_awesome_rounded;
      case InkSpiritMood.sleepy:
        return SardIcons.bedtime_rounded;
      case InkSpiritMood.curious:
        return SardIcons.question_mark_rounded;
      case InkSpiritMood.happy:
        return SardIcons.favorite_rounded;
      case InkSpiritMood.calm:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final s = widget.size;
    final badge = _badge;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final t = Curves.easeInOut.transform(_c.value);
        return SizedBox(
          width: s * 1.4,
          height: s * 1.4,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // هالة
              Container(
                width: s * (1.15 + 0.1 * t),
                height: s * (1.15 + 0.1 * t),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [tint(p.accent, 0.22), tint(p.accent, 0)],
                  ),
                ),
              ),
              // ظل أرضي
              Positioned(
                bottom: s * 0.04,
                child: Container(
                  width: s * (0.5 - 0.1 * t),
                  height: s * 0.07,
                  decoration: BoxDecoration(
                    color: tint(p.text, 0.1),
                    borderRadius: BorderRadius.circular(s),
                  ),
                ),
              ),
              Transform.translate(
                offset: Offset(0, -s * (0.04 + 0.07 * t)),
                child: Transform.rotate(
                  angle: (t - 0.5) * 0.08,
                  child: LogoMark(size: s * 0.78, glow: true),
                ),
              ),
              if (badge != null)
                Positioned(
                  top: s * 0.12,
                  right: s * 0.12,
                  child: Container(
                    width: s * 0.3,
                    height: s * 0.3,
                    decoration: BoxDecoration(
                      color: p.surface,
                      shape: BoxShape.circle,
                      border: Border.all(color: p.border),
                    ),
                    child: SIcon(badge, size: s * 0.17, color: p.gold),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
