import 'package:flutter/material.dart';

import '../core/guide/guide_routes.dart';
import 'guide_assistant.dart';

/// انتقال موحّد سلس: الصفحة الجديدة تصعد وتتلاشى للداخل بمنحنى ناعم،
/// والصفحة التي خلفها تتراجع قليلاً وتخفت (إحساس عمق).
Route<T> sardRoute<T>(Widget page) {
  // المساعدة: شرح الشاشة عند فتحها لأول مرة
  final gid = guideIdForPage(page);
  final Widget shown = gid == null ? page : GuideOnEnter(id: gid, child: page);
  return PageRouteBuilder<T>(
    transitionDuration: const Duration(milliseconds: 520),
    reverseTransitionDuration: const Duration(milliseconds: 380),
    pageBuilder: (context, a, b) => shown,
    transitionsBuilder: (context, anim, secondary, child) {
      final inCurve = CurvedAnimation(
        parent: anim,
        curve: Curves.easeOutQuart,
        reverseCurve: Curves.easeInCubic,
      );
      final backCurve = CurvedAnimation(parent: secondary, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: Tween<double>(begin: 0.0, end: 1.0).animate(
          CurvedAnimation(parent: anim, curve: const Interval(0.0, 0.7, curve: Curves.easeOut)),
        ),
        child: ScaleTransition(
          scale: Tween<double>(begin: 1.0, end: 0.965).animate(backCurve),
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.045), end: Offset.zero)
                .animate(inCurve),
            child: child,
          ),
        ),
      );
    },
  );
}
