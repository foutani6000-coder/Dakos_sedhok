import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../core/storage/settings.dart';
import '../core/theme/app_themes.dart';
import 'fx.dart';
import 'sard_icons.dart';

/// منتقي الثيمات: بطاقات معاينة أفقية (أبيض ← أسود)
class ThemePicker extends StatelessWidget {
  const ThemePicker({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsController>();
    return SizedBox(
      height: 214,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        children: [
          _SystemThemeCard(selected: s.themeId == 'system', onTap: () => s.setTheme('system')),
          for (final pal in SardThemes.all)
            _ThemeCard(
              pal: pal,
              selected: s.themeId == pal.id,
              onTap: () => s.setTheme(pal.id),
            ),
        ],
      ),
    );
  }
}

Widget _bar(Color c, double w, double h) => Container(
      width: w,
      height: h,
      decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(h)),
    );

Widget _dot(Color c, double d) => Container(
      width: d,
      height: d,
      decoration: BoxDecoration(color: c, shape: BoxShape.circle),
    );

class _ThemeCard extends StatelessWidget {
  const _ThemeCard({required this.pal, required this.selected, required this.onTap});
  final SardPalette pal;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cur = context.pal;
    return Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        width: 112,
        margin: const EdgeInsets.only(left: 12),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: cur.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: selected ? cur.accent : cur.border,
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Expanded(child: _Mini(pal: pal)),
            const SizedBox(height: 8),
            Row(
              children: [
                AnimatedOpacity(
                  opacity: selected ? 1 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: SIcon(SardIcons.check_circle_rounded, size: 16, color: cur.accent),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    pal.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.ts(size: 13, w: FontWeight.w700),
                  ),
                ),
              ],
            ),
            if (pal.tag.isNotEmpty)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: Padding(
                  padding: const EdgeInsetsDirectional.only(start: 20),
                  child: Text(pal.tag, style: context.ts(size: 10.5, color: cur.textDim)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _Mini extends StatelessWidget {
  const _Mini({required this.pal});
  final SardPalette pal;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: pal.bg,
        borderRadius: BorderRadius.circular(pal.r(0.8).clamp(6.0, 22.0).toDouble()),
        border: Border.all(color: pal.border, width: pal.borderW),
        boxShadow: pal.glow > 0
            ? [BoxShadow(color: tint(pal.accent, 0.35 * pal.glow), blurRadius: 12)]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [_dot(pal.accent, 8), const SizedBox(width: 4), _bar(pal.textDim, 30, 5)]),
          const SizedBox(height: 8),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: pal.glass ? tint(pal.surfaceHi, 0.6) : pal.surfaceHi,
                borderRadius: BorderRadius.circular(pal.r(0.5).clamp(4.0, 14.0).toDouble()),
                border: pal.glass ? Border.all(color: tint(pal.text, 0.18)) : null,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _bar(pal.text, 46, 6),
                  const SizedBox(height: 4),
                  Row(children: [
                    _bar(pal.accent, 18, 5),
                    const SizedBox(width: 3),
                    _bar(pal.textDim, 14, 5),
                  ]),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          _bar(pal.textDim, 54, 5),
          const SizedBox(height: 4),
          _bar(pal.border, 40, 5),
          const SizedBox(height: 8),
          Align(alignment: Alignment.centerRight, child: _dot(pal.accent, 10)),
        ],
      ),
    );
  }
}

/// منتقي لون التمييز.
class AccentTonePicker extends StatelessWidget {
  const AccentTonePicker({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsController>();
    final p = context.pal;
    const labels = {
      'auto': 'الثيم',
      'vermilion': 'قرمزي',
      'amber': 'عنبري',
      'jade': 'يشم',
      'indigo': 'نيلي',
      'rose': 'وردي',
    };
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: p.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('لون التمييز', style: context.ts(size: 13, w: FontWeight.w700)),
            const SizedBox(height: 12),
            Row(
              children: [
                for (final entry in <MapEntry<String, Color>>[
                  MapEntry('auto', SardThemes.byId(settings.themeId).accent),
                  ...sardAccentTones.entries,
                ])
                  Expanded(
                    child: Pressable(
                      onTap: () => settings.setAccentId(entry.key),
                      child: Column(
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 220),
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: entry.value,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: settings.accentId == entry.key ? p.accent : p.border,
                                width: settings.accentId == entry.key ? 3 : 1,
                              ),
                            ),
                            child: settings.accentId == entry.key
                                ? const SIcon(SardIcons.check_rounded, color: Colors.white, size: 19)
                                : null,
                          ),
                          const SizedBox(height: 6),
                          Text(labels[entry.key] ?? entry.key, style: context.ts(size: 10.5, color: p.textDim)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SystemThemeCard extends StatelessWidget {
  const _SystemThemeCard({required this.selected, required this.onTap});
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        width: 112,
        margin: const EdgeInsets.only(left: 12),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: selected ? p.accent : p.border, width: selected ? 2 : 1),
        ),
        child: Column(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Row(children: [
                  Expanded(child: Container(color: SardThemes.paper.bg, child: SIcon(SardIcons.wb_sunny_rounded, color: SardThemes.paper.text))),
                  Expanded(child: Container(color: SardThemes.obsidian.bg, child: SIcon(SardIcons.nightlight_round, color: SardThemes.obsidian.text))),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              SIcon(selected ? SardIcons.check_circle_rounded : SardIcons.brightness_auto_rounded, size: 15, color: p.accent),
              const SizedBox(width: 4),
              Expanded(child: Text('تلقائي', style: context.ts(size: 13, w: FontWeight.w700))),
            ]),
          ],
        ),
      ),
    );
  }
}

/// منتقي توفير البيانات
class DataModePicker extends StatelessWidget {
  const DataModePicker({super.key});

  static const _modes = [
    (DataMode.hd, SardIcons.hd_rounded, 'جودة كاملة', 'الأغلفة والصفحات بدقتها الأصلية دائماً.'),
    (DataMode.mobile, SardIcons.signal_cellular_alt_rounded, 'بيانات الجوال', 'تُخفَّض الجودة تلقائياً عند استعمال بيانات الجوال فقط.'),
    (DataMode.always, SardIcons.data_saver_on_rounded, 'توفير دائم', 'جودة مخفّضة دائماً لأقل استهلاك للإنترنت.'),
  ];

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsController>();
    final p = context.pal;
    final current = _modes.firstWhere((m) => m.$1 == s.dataMode);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Row(
            children: [
              for (var i = 0; i < _modes.length; i++) ...[
                if (i > 0) const SizedBox(width: 10),
                Expanded(
                  child: Pressable(
                    onTap: () => s.setDataMode(_modes[i].$1),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOutCubic,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        color: s.dataMode == _modes[i].$1 ? p.accent : p.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: s.dataMode == _modes[i].$1 ? p.accent : p.border),
                      ),
                      child: Column(
                        children: [
                          SIcon(_modes[i].$2,
                              size: 26,
                              color: s.dataMode == _modes[i].$1 ? p.onAccent : p.text),
                          const SizedBox(height: 8),
                          Text(
                            _modes[i].$3,
                            textAlign: TextAlign.center,
                            style: context.ts(
                              size: 12.5,
                              w: FontWeight.w700,
                              color: s.dataMode == _modes[i].$1 ? p.onAccent : p.text,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 12),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: Text(
              current.$4,
              key: ValueKey(current.$1),
              textAlign: TextAlign.center,
              style: context.ts(size: 13, color: p.textDim, height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}

/// تبويبات منزلقة (تفاصيل / فصول / تعليقات)
class Segmented extends StatelessWidget {
  const Segmented({super.key, required this.labels, required this.index, required this.onChanged});
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: p.surfaceHi,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 280),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: i == index ? p.accent : Colors.transparent,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: i == index
                        ? [BoxShadow(color: tint(p.accent, 0.35), blurRadius: 12, offset: const Offset(0, 4))]
                        : null,
                  ),
                  child: Text(
                    labels[i],
                    style: context.ts(
                      size: 13.5,
                      w: FontWeight.w700,
                      color: i == index ? p.onAccent : p.textDim,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// شريحة خيار (فلاتر البحث)
class SardChip extends StatelessWidget {
  const SardChip({super.key, required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? tint(p.accent, 0.14) : p.surface,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: selected ? p.accent : p.border),
        ),
        child: Text(
          label,
          style: context.ts(
            size: 13,
            w: FontWeight.w600,
            color: selected ? p.accent : p.text,
          ),
        ),
      ),
    );
  }
}
