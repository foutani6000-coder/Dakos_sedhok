import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../cover_art.dart';
import '../ink_spirit.dart';
import '../sard_icons.dart';
import 'atelier_motion.dart';
import 'atelier_theme.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// بطاقات Atelier — بطاقة عمل، بطاقة فصل، بطاقة رفيق «حبّار» مع فقاعة
/// كلام، بطاقة متابعة، بطاقة إحصاء، بطاقة عرض، بطاقة تصنيف، بطاقة
/// ترتيب، بطاقة اقتباس، وبطاقة سلسلة أيام.
///
/// كل بطاقة:
///   • تشتق ألوانها من [SardPalette] عبر [AtelierPalette] و[AtelierTone].
///   • تستجيب للمس عبر [AtelierPressable].
///   • تحترم «تقليل الحركة» عبر مكوّنات [atelier_motion.dart].
///   • نصوصها عربية بالكامل.
/// ──────────────────────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة عمل (غلاف عمودي)
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة عمل عمودية: غلاف + عنوان + تقييم + مشاهدات + شارة حالة.
///
/// تُستعمل في صفوف «اقتراحات» و«رائج» وشبكات الأعمال.
class AtelierSeriesCard extends StatelessWidget {
  const AtelierSeriesCard({
    super.key,
    required this.series,
    this.onTap,
    this.width = 132,
    this.showRating = true,
    this.showViews = true,
    this.showStatus = true,
    this.heroTag,
    this.rank,
  });

  final Series series;
  final VoidCallback? onTap;
  final double width;
  final bool showRating;
  final bool showViews;
  final bool showStatus;
  final String? heroTag;
  final int? rank;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = AtelierTone.forSeries(series);
    final cover = Hero(
      tag: heroTag ?? 'atelier-${series.id}',
      child: ClipRRect(
        borderRadius: BorderRadius.circular(p.r(0.8)),
        child: SizedBox(
          width: width,
          height: width / AtelierSpacing.posterAspect,
          child: Stack(
            fit: StackFit.expand,
            children: [
              CoverArt(series: series, radius: 0, showTitle: false),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.black.withAlpha(70)],
                      stops: const [0.7, 1.0],
                    ),
                  ),
                ),
              ),
              if (series.isNew)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: AtelierDecor.badge(tone.color),
                    child: const Text(
                      'جديد',
                      style: TextStyle(
                        fontFamily: sardBodyFont,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        height: 1.2,
                      ),
                    ),
                  ),
                ),
              if (rank != null)
                Positioned(
                  left: 6,
                  bottom: 6,
                  child: Text(
                    '$rank',
                    style: TextStyle(
                      fontFamily: sardFont,
                      fontSize: 30,
                      fontWeight: FontWeight.w800,
                      color: Colors.white.withAlpha(235),
                      height: 1,
                      shadows: const [
                        Shadow(color: Colors.black54, blurRadius: 8, offset: Offset(0, 2)),
                      ],
                    ),
                  ),
                ),
              Positioned(
                left: 8,
                right: 8,
                bottom: 8,
                child: Row(
                  children: [
                    if (showRating) ...[
                      const SIcon(SardIcons.star_rounded, size: 13, color: Color(0xFFFFC94D)),
                      const SizedBox(width: 3),
                      Text(
                        atelierRatingLabel(series.rating),
                        style: const TextStyle(
                          fontFamily: sardBodyFont,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                          height: 1,
                        ),
                      ),
                    ],
                    const Spacer(),
                    if (showViews)
                      Text(
                        formatCount(series.views),
                        style: TextStyle(
                          fontFamily: sardBodyFont,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.white.withAlpha(220),
                          height: 1,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );

    final body = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        cover,
        const SizedBox(height: 8),
        SizedBox(
          width: width,
          child: Text(
            series.title,
            style: AtelierType.subtitle(context, size: 13.5),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        const SizedBox(height: 2),
        SizedBox(
          width: width,
          child: Text(
            '${atelierChaptersLabel(series.chapters)} · ${series.type}',
            style: AtelierType.caption(context, size: 11),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (showStatus) ...[
          const SizedBox(height: 6),
          _StatusDot(status: series.status),
        ],
      ],
    );

    return AtelierPressable(
      onTap: onTap,
      child: body,
    );
  }
}

/// نقطة حالة صغيرة ملوّنة مع نص الحالة.
class _StatusDot extends StatelessWidget {
  const _StatusDot({required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    final tone = atelierStatusTone(status);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 7,
          height: 7,
          decoration: BoxDecoration(shape: BoxShape.circle, color: tone.color),
        ),
        const SizedBox(width: 5),
        Text(status, style: AtelierType.caption(context, color: tone.color, size: 11)),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة عمل أفقية (صف في قائمة)
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة عمل أفقية: غلاف صغير على اليمين + تفاصيل على اليسار.
///
/// تُستعمل في «أحدث الفصول» وقوائم البحث والمتابَعات.
class AtelierSeriesRowCard extends StatelessWidget {
  const AtelierSeriesRowCard({
    super.key,
    required this.series,
    this.onTap,
    this.trailing,
    this.subtitle,
    this.showProgress = false,
    this.progress = 0,
    this.heroTag,
  });

  final Series series;
  final VoidCallback? onTap;
  final Widget? trailing;
  final String? subtitle;
  final bool showProgress;
  final double progress;
  final String? heroTag;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = AtelierTone.forSeries(series);
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.card(p, radius: 20),
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(p.r(0.6)),
              child: SizedBox(
                width: 64,
                height: 88,
                child: Hero(
                  tag: heroTag ?? 'atelier-row-${series.id}',
                  child: CoverArt(series: series, radius: 0, showTitle: false),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          series.title,
                          style: AtelierType.subtitle(context, size: 15),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: AtelierDecor.pill(tone.color),
                        child: Text(
                          series.status,
                          style: AtelierType.caption(context, color: tone.color, size: 10.5),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle ?? '${series.type} · ${series.year} · ${atelierChaptersLabel(series.chapters)}',
                    style: AtelierType.caption(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const SIcon(SardIcons.star_rounded, size: 14, color: Color(0xFFFFC94D)),
                      const SizedBox(width: 3),
                      Text(atelierRatingLabel(series.rating), style: AtelierType.caption(context, color: p.text)),
                      const SizedBox(width: 4),
                      const AtelierDot(),
                      const SizedBox(width: 4),
                      const SIcon(SardIcons.visibility_rounded, size: 14, color: null),
                      const SizedBox(width: 3),
                      Text(formatCount(series.views), style: AtelierType.caption(context)),
                      const Spacer(),
                      if (series.genres.isNotEmpty)
                        Text(series.genres.first, style: AtelierType.caption(context, color: p.gold)),
                    ],
                  ),
                  if (showProgress) ...[
                    const SizedBox(height: 8),
                    AtelierProgressBar(fraction: progress, height: 6),
                    const SizedBox(height: 4),
                    Text('تقدّمك ${atelierPercent(progress)}', style: AtelierType.caption(context, size: 11)),
                  ],
                ],
              ),
            ),
            if (trailing != null) ...[
              const SizedBox(width: 8),
              trailing!,
            ],
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة فصل
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة فصل: رقم الفصل + عنوانه + تاريخه + حالة القراءة.
///
/// تُستعمل في شبكة «أحدث الفصول» وفي قوائم التفاصيل.
class AtelierChapterCard extends StatelessWidget {
  const AtelierChapterCard({
    super.key,
    required this.series,
    required this.chapter,
    this.chapterTitle = '',
    this.date = '',
    this.isRead = false,
    this.isNew = false,
    this.onTap,
    this.onDownload,
  });

  final Series series;
  final int chapter;
  final String chapterTitle;
  final String date;
  final bool isRead;
  final bool isNew;
  final VoidCallback? onTap;
  final VoidCallback? onDownload;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = AtelierTone.forSeries(series);
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        height: AtelierSpacing.chapterHeight,
        decoration: AtelierDecor.card(p, radius: 18),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                gradient: tone.gradient,
                borderRadius: BorderRadius.circular(14),
              ),
              alignment: Alignment.center,
              child: Text(
                '$chapter',
                style: const TextStyle(
                  fontFamily: sardFont,
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  height: 1,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          chapterTitle.isEmpty ? 'الفصل $chapter' : chapterTitle,
                          style: AtelierType.subtitle(context, size: 14),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (isNew) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: AtelierDecor.badge(p.accent),
                          child: const Text(
                            'جديد',
                            style: TextStyle(
                              fontFamily: sardBodyFont,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    '${series.title}${date.isEmpty ? '' : ' · $date'}',
                    style: AtelierType.caption(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      SIcon(
                        isRead ? SardIcons.check_circle_rounded : SardIcons.menu_book_rounded,
                        size: 13,
                        color: isRead ? p.gold : p.textDim,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        isRead ? 'مقروء' : 'لم تقرأه بعد',
                        style: AtelierType.caption(
                          context,
                          color: isRead ? p.gold : p.textDim,
                          size: 11,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (onDownload != null)
              IconButton(
                onPressed: onDownload,
                icon: SIcon(SardIcons.download_rounded, size: 20, color: p.textDim),
                tooltip: 'تنزيل الفصل',
                visualDensity: VisualDensity.compact,
              ),
            SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة «واصل القراءة»
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة متابعة القراءة: غلاف العمل + الفصل الحالي + شريط تقدّم +
/// زر «واصل» ذهبي.
class AtelierContinueCard extends StatelessWidget {
  const AtelierContinueCard({
    super.key,
    required this.series,
    required this.chapter,
    required this.progress,
    this.totalPages = 0,
    this.currentPage = 0,
    this.onTap,
    this.onDismiss,
  });

  final Series series;
  final int chapter;
  final double progress;
  final int totalPages;
  final int currentPage;
  final VoidCallback? onTap;
  final VoidCallback? onDismiss;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = AtelierTone.forSeries(series);
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.gold(p, radius: 22),
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                width: 72,
                height: 100,
                child: CoverArt(series: series, radius: 0, showTitle: false),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: AtelierDecor.pill(p.gold),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SIcon(SardIcons.history_rounded, size: 12, color: p.gold),
                            const SizedBox(width: 4),
                            Text('واصل القراءة', style: AtelierType.caption(context, color: p.gold, size: 11)),
                          ],
                        ),
                      ),
                      const Spacer(),
                      if (onDismiss != null)
                        GestureDetector(
                          onTap: onDismiss,
                          child: SIcon(SardIcons.close_rounded, size: 18, color: p.textDim),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(series.title, style: AtelierType.subtitle(context, size: 16), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 3),
                  Text(
                    totalPages > 0
                        ? 'الفصل $chapter · الصفحة $currentPage من $totalPages'
                        : 'الفصل $chapter',
                    style: AtelierType.caption(context),
                  ),
                  const SizedBox(height: 10),
                  AtelierProgressBar(fraction: progress, height: 7),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text('تقدّمك ${atelierPercent(progress)}', style: AtelierType.caption(context, color: tone.color, size: 11)),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [p.gold, Color.lerp(p.gold, Colors.white, 0.25)!],
                          ),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SIcon(SardIcons.play_arrow_rounded, size: 14, color: Colors.white),
                            const SizedBox(width: 4),
                            Text('واصل', style: AtelierType.button(context, color: Colors.white, size: 12.5)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة الرفيق «حبّار»
// ═══════════════════════════════════════════════════════════════════════════

/// فقاعة كلام بذيل سفلي (لرفيق الصفحة الرئيسية).
class _SpeechBubblePainter extends CustomPainter {
  _SpeechBubblePainter({required this.color, required this.border});
  final Color color;
  final Color border;

  @override
  void paint(Canvas canvas, Size size) {
    const r = 18.0;
    const tailW = 16.0;
    const tailH = 12.0;
    final path = Path();
    path.moveTo(r, 0);
    path.lineTo(size.width - r, 0);
    path.quadraticBezierTo(size.width, 0, size.width, r);
    path.lineTo(size.width, size.height - r - tailH);
    path.quadraticBezierTo(size.width, size.height - tailH, size.width - r, size.height - tailH);
    final tx = size.width * 0.22;
    path.lineTo(tx + tailW / 2, size.height - tailH);
    path.lineTo(tx, size.height);
    path.lineTo(tx - tailW / 2, size.height - tailH);
    path.lineTo(r, size.height - tailH);
    path.quadraticBezierTo(0, size.height - tailH, 0, size.height - r - tailH);
    path.lineTo(0, r);
    path.quadraticBezierTo(0, 0, r, 0);
    path.close();
    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..style = PaintingStyle.fill,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = border
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
  }

  @override
  bool shouldRepaint(covariant _SpeechBubblePainter old) =>
      old.color != color || old.border != border;
}

/// بطاقة الرفيق: روح الحبر «حبّار» + فقاعة كلام بسطر قواعدي + زر.
///
/// تُعرض أسفل التحية في الرئيسية، وتتبدل رسالتها حسب سياق القراءة.
class AtelierCompanionCard extends StatelessWidget {
  const AtelierCompanionCard({
    super.key,
    required this.line,
    this.name = 'حبّار',
    this.mood = InkSpiritMood.calm,
    this.onTap,
    this.onAction,
    this.actionLabel = 'ماذا أقرأ؟',
    this.showBubble = true,
  });

  final String line;
  final String name;
  final InkSpiritMood mood;
  final VoidCallback? onTap;
  final VoidCallback? onAction;
  final String actionLabel;
  final bool showBubble;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final bubble = CustomPaint(
      painter: _SpeechBubblePainter(color: p.surface, border: p.border),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Text(name, style: AtelierType.overline(context, color: p.gold)),
                const SizedBox(width: 6),
                const AtelierDot(size: 3),
                const SizedBox(width: 6),
                Text('رفيقك في القراءة', style: AtelierType.caption(context, size: 11)),
              ],
            ),
            const SizedBox(height: 6),
            Text(line, style: AtelierType.quote(context, size: 15), maxLines: 3, overflow: TextOverflow.ellipsis),
            if (onAction != null) ...[
              const SizedBox(height: 10),
              GestureDetector(
                onTap: onAction,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: AtelierDecor.pill(p.accent),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(SardIcons.auto_awesome_rounded, size: 14, color: p.accent),
                      const SizedBox(width: 5),
                      Text(actionLabel, style: AtelierType.caption(context, color: p.accent, size: 12)),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );

    return AtelierPressable(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            AtelierScaleIn(
              onceKey: 'companion-spirit',
              child: InkSpirit(size: 74, mood: mood),
            ),
            const SizedBox(width: 10),
            Expanded(child: showBubble ? bubble : Text(line, style: AtelierType.quote(context, size: 15))),
          ],
        ),
      ),
    );
  }
}

/// نسخة مصغّرة من الرفيق (لشريط علوي أو نافذة منبثقة).
class AtelierCompanionChip extends StatelessWidget {
  const AtelierCompanionChip({super.key, required this.line, this.mood = InkSpiritMood.happy, this.onTap});

  final String line;
  final InkSpiritMood mood;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: AtelierDecor.card(p, radius: 999),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            InkSpirit(size: 30, mood: mood),
            const SizedBox(width: 8),
            Flexible(
              child: Text(line, style: AtelierType.caption(context, color: p.text), maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقات إحصاء وسلسلة أيام
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة إحصاء واحدة: رقم متحرك + تسمية + أيقونة ملوّنة.
class AtelierStatCard extends StatelessWidget {
  const AtelierStatCard({
    super.key,
    required this.value,
    required this.label,
    this.icon,
    this.tone = AtelierTone.gold,
    this.compact = false,
    this.onTap,
  });

  final int value;
  final String label;
  final SIconData? icon;
  final AtelierTone tone;
  final bool compact;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.card(p, radius: 20),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: tone.color.withAlpha(26),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  alignment: Alignment.center,
                  child: SIcon(icon ?? SardIcons.menu_book_rounded, size: 18, color: tone.color),
                ),
                const Spacer(),
                SIcon(SardIcons.local_fire_department_rounded, size: 14, color: p.textDim),
              ],
            ),
            const SizedBox(height: 12),
            AtelierCountUp(
              value: value,
              compact: compact,
              style: AtelierType.numeral(context, size: 26),
            ),
            const SizedBox(height: 2),
            Text(label, style: AtelierType.caption(context)),
          ],
        ),
      ),
    );
  }
}

/// بطاقة سلسلة أيام: حلقة تقدّم + عدد الأيام + أفضل سلسلة.
class AtelierStreakCard extends StatelessWidget {
  const AtelierStreakCard({
    super.key,
    required this.streak,
    required this.bestStreak,
    this.goal = 30,
    this.onTap,
  });

  final int streak;
  final int bestStreak;
  final int goal;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final fraction = goal <= 0 ? 0.0 : (streak / goal).clamp(0.0, 1.0);
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.toned(AtelierTone.seal, radius: 22),
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            AtelierRingProgress(
              fraction: fraction,
              size: 66,
              stroke: 6,
              color: Colors.white,
              child: const SIcon(SardIcons.local_fire_department_rounded, size: 26, color: Colors.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'سلسلة أيامك',
                    style: TextStyle(
                      fontFamily: sardBodyFont,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text(
                        '$streak',
                        style: const TextStyle(
                          fontFamily: sardFont,
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          height: 1.1,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        'يوم متتالٍ',
                        style: TextStyle(
                          fontFamily: sardBodyFont,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'أفضل سلسلة: $bestStreak يوم · الهدف $goal يوماً',
                    style: TextStyle(
                      fontFamily: sardBodyFont,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w500,
                      color: Colors.white.withAlpha(220),
                    ),
                  ),
                ],
              ),
            ),
            const SIcon(SardIcons.chevron_left_rounded, size: 20, color: Colors.white),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة عرض ذهبية
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة عرض ذهبية: عنوان + وصف + زر + غبار ذهب متحرك خلفها.
class AtelierPromoCard extends StatelessWidget {
  const AtelierPromoCard({
    super.key,
    required this.title,
    required this.subtitle,
    this.badge = 'عرض خاص',
    this.actionLabel = 'اكتشف الآن',
    this.onTap,
    this.tone = AtelierTone.gold,
  });

  final String title;
  final String subtitle;
  final String badge;
  final String actionLabel;
  final VoidCallback? onTap;
  final AtelierTone tone;

  @override
  Widget build(BuildContext context) {
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [tone.color, tone.dark, const Color(0xFF1C1612)],
          ),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(color: tone.color.withAlpha(70), blurRadius: 22, offset: const Offset(0, 10)),
          ],
        ),
        child: Stack(
          children: [
            const Positioned.fill(child: AtelierGoldDust(count: 18)),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withAlpha(26),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: Colors.white.withAlpha(60)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SIcon(SardIcons.local_fire_department_rounded, size: 13, color: Colors.white),
                        const SizedBox(width: 4),
                        Text(
                          badge,
                          style: const TextStyle(
                            fontFamily: sardBodyFont,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    title,
                    style: const TextStyle(
                      fontFamily: sardFont,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontFamily: sardBodyFont,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w500,
                      color: Colors.white.withAlpha(225),
                      height: 1.6,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      actionLabel,
                      style: TextStyle(
                        fontFamily: sardBodyFont,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: tone.dark,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقات تصنيف وترتيب واقتباس
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة تصنيف: أيقونة + اسم + عدد الأعمال.
class AtelierGenreCard extends StatelessWidget {
  const AtelierGenreCard({
    super.key,
    required this.genre,
    required this.count,
    this.tone = AtelierTone.indigo,
    this.onTap,
  });

  final String genre;
  final int count;
  final AtelierTone tone;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.card(p, radius: 18),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                gradient: tone.gradient,
                borderRadius: BorderRadius.circular(13),
              ),
              alignment: Alignment.center,
              child: Text(
                genre.isEmpty ? '؟' : genre.substring(0, 1),
                style: const TextStyle(
                  fontFamily: sardFont,
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(genre, style: AtelierType.subtitle(context, size: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text('$count عمل', style: AtelierType.caption(context)),
                ],
              ),
            ),
            SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
          ],
        ),
      ),
    );
  }
}

/// صف ترتيب: رقم كبير + بطاقة عمل أفقية مصغّرة.
class AtelierRankRow extends StatelessWidget {
  const AtelierRankRow({
    super.key,
    required this.series,
    required this.rank,
    this.onTap,
    this.subtitle,
  });

  final Series series;
  final int rank;
  final VoidCallback? onTap;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = rank <= 3 ? AtelierTone.gold : AtelierTone.ink;
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.card(p, radius: 18),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            SizedBox(
              width: 34,
              child: Text(
                '$rank',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: sardFont,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: tone.color,
                  height: 1,
                ),
              ),
            ),
            const SizedBox(width: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: SizedBox(
                width: 48,
                height: 66,
                child: CoverArt(series: series, radius: 0, showTitle: false),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(series.title, style: AtelierType.subtitle(context, size: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 3),
                  Text(
                    subtitle ?? '${atelierChaptersLabel(series.chapters)} · ${formatCount(series.views)} مشاهدة',
                    style: AtelierType.caption(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const SIcon(SardIcons.star_rounded, size: 13, color: Color(0xFFFFC94D)),
                      const SizedBox(width: 3),
                      Text(atelierRatingLabel(series.rating), style: AtelierType.caption(context, color: p.text)),
                    ],
                  ),
                ],
              ),
            ),
            SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
          ],
        ),
      ),
    );
  }
}

/// بطاقة اقتباس: نص كبير بخط العناوين + اسم العمل + زر مشاركة.
class AtelierQuoteCard extends StatelessWidget {
  const AtelierQuoteCard({
    super.key,
    required this.quote,
    required this.seriesTitle,
    this.chapter,
    this.onShare,
    this.onTap,
  });

  final String quote;
  final String seriesTitle;
  final int? chapter;
  final VoidCallback? onShare;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.card(p, radius: 22),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '«',
              style: TextStyle(
                fontFamily: sardFont,
                fontSize: 34,
                fontWeight: FontWeight.w800,
                color: p.gold,
                height: 0.9,
              ),
            ),
            const SizedBox(height: 8),
            Text('«$quote»', style: AtelierType.quote(context, size: 16), maxLines: 4, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 12),
            Row(
              children: [
                const AtelierSealStamp(letter: 'ق', size: 30, tone: AtelierTone.gold),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(seriesTitle, style: AtelierType.subtitle(context, size: 13.5), maxLines: 1, overflow: TextOverflow.ellipsis),
                      if (chapter != null) Text('الفصل $chapter', style: AtelierType.caption(context)),
                    ],
                  ),
                ),
                if (onShare != null)
                  GestureDetector(
                    onTap: onShare,
                    child: Container(
                      padding: const EdgeInsets.all(9),
                      decoration: AtelierDecor.pill(p.accent),
                      child: SIcon(SardIcons.share_rounded, size: 16, color: p.accent),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقات مجموعة وتزيين
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة مجموعة: ثلاثة أغلفة متداخلة + اسم المجموعة + عدد الأعمال.
class AtelierCollectionCard extends StatelessWidget {
  const AtelierCollectionCard({
    super.key,
    required this.title,
    required this.series,
    this.subtitle,
    this.onTap,
    this.tone = AtelierTone.indigo,
  });

  final String title;
  final List<Series> series;
  final String? subtitle;
  final VoidCallback? onTap;
  final AtelierTone tone;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final shown = series.take(3).toList();
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.card(p, radius: 22),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 110,
              child: Stack(
                children: [
                  for (var i = 0; i < shown.length; i++)
                    Positioned(
                      right: i * 54.0,
                      top: i * 4.0,
                      child: Transform.rotate(
                        angle: atelierTiltOf(shown[i].id),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: p.surface, width: 2),
                            boxShadow: softShadow(p),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: SizedBox(
                              width: 72,
                              height: 100,
                              child: CoverArt(series: shown[i], radius: 0, showTitle: false),
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (series.length > 3)
                    Positioned(
                      left: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: AtelierDecor.badge(tone.color),
                        child: Text(
                          '+${series.length - 3}',
                          style: const TextStyle(
                            fontFamily: sardBodyFont,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(title, style: AtelierType.subtitle(context, size: 15), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(
              subtitle ?? '${series.length} ${series.length == 1 ? 'عمل' : 'أعمال'}',
              style: AtelierType.caption(context),
            ),
          ],
        ),
      ),
    );
  }
}

/// صف أفقي مصغّر من الأغلفة (لـ«لأنك قرأت…»).
class AtelierMiniPosterRow extends StatelessWidget {
  const AtelierMiniPosterRow({
    super.key,
    required this.series,
    this.onTap,
    this.height = 150,
  });

  final List<Series> series;
  final void Function(Series)? onTap;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        itemCount: series.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final s = series[i];
          return AtelierPressable(
            onTap: onTap == null ? null : () => onTap!(s),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                width: height * AtelierSpacing.posterAspect,
                child: CoverArt(series: s, radius: 0, showTitle: false),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// بطاقة قسم عامة: عنوان + محتوى + إجراء اختياري.
class AtelierSectionCard extends StatelessWidget {
  const AtelierSectionCard({
    super.key,
    required this.title,
    required this.child,
    this.subtitle,
    this.actionLabel,
    this.onAction,
    this.icon,
    this.tone = AtelierTone.gold,
    this.padding = const EdgeInsets.all(16),
  });

  final String title;
  final Widget child;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;
  final SIconData? icon;
  final AtelierTone tone;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
      decoration: AtelierDecor.card(p, radius: 22),
      padding: padding,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: tone.color.withAlpha(26),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.center,
                  child: SIcon(icon!, size: 19, color: tone.color),
                ),
                const SizedBox(width: 10),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: AtelierType.subtitle(context, size: 15)),
                    if (subtitle != null) Text(subtitle!, style: AtelierType.caption(context)),
                  ],
                ),
              ),
              if (actionLabel != null && onAction != null)
                GestureDetector(
                  onTap: onAction,
                  child: Text(actionLabel!, style: AtelierType.caption(context, color: p.accent)),
                ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

/// رسّام ختم دائري: دائرة حمراء بخط مزدوج + لمعة علوية بيضاوية.
///
/// ملاحظة: Canvas لا يملك drawEllipse؛ يُرسم الشكل البيضاوي بـ drawOval.
class AtelierSealPainter extends CustomPainter {
  AtelierSealPainter({required this.color, this.inner = 0.72, this.letter = ''});

  final Color color;
  final double inner;
  final String letter;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final r = size.shortestSide / 2;
    final outer = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, r, outer);
    final ring = Paint()
      ..color = Colors.white.withAlpha(200)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6;
    canvas.drawCircle(center, r * inner, ring);
    // لمعة علوية بيضاوية.
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(center.dx - r * 0.28, center.dy - r * 0.45),
        width: r * 0.9,
        height: r * 0.5,
      ),
      Paint()..color = Colors.white.withAlpha(70),
    );
    if (letter.isNotEmpty) {
      final tp = TextPainter(
        text: TextSpan(
          text: letter,
          style: TextStyle(
            fontFamily: sardFont,
            fontSize: r * 0.85,
            fontWeight: FontWeight.w800,
            color: Colors.white,
            height: 1,
          ),
        ),
        textDirection: TextDirection.rtl,
      )..layout();
      tp.paint(canvas, Offset(center.dx - tp.width / 2, center.dy - tp.height / 2));
    }
  }

  @override
  bool shouldRepaint(covariant AtelierSealPainter old) =>
      old.color != color || old.inner != inner || old.letter != letter;
}

/// ختم دائري مرسوم (للتوقيع على بطاقة إنجاز أو غلاف).
class AtelierPaintedSeal extends StatelessWidget {
  const AtelierPaintedSeal({super.key, this.size = 44, this.color, this.letter = 'س'});

  final double size;
  final Color? color;
  final String letter;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(
        painter: AtelierSealPainter(color: color ?? context.pal.accent, letter: letter),
      ),
    );
  }
}

/// رسّام بقعة حبر زخرفية (خلفية عنوان قسم).
class AtelierInkBlotPainter extends CustomPainter {
  AtelierInkBlotPainter({required this.color, this.seed = 11});
  final Color color;
  final int seed;

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(seed);
    final center = Offset(size.width * 0.5, size.height * 0.55);
    final paint = Paint()..color = color;
    // جسم البقعة: دوائر متداخلة.
    for (var i = 0; i < 7; i++) {
      final a = r.nextDouble() * math.pi * 2;
      final d = r.nextDouble() * size.shortestSide * 0.28;
      final rad = size.shortestSide * (0.22 + r.nextDouble() * 0.2);
      canvas.drawCircle(
        Offset(center.dx + math.cos(a) * d, center.dy + math.sin(a) * d * 0.7),
        rad,
        paint,
      );
    }
    // قطرات صغيرة حولها.
    for (var i = 0; i < 5; i++) {
      final a = r.nextDouble() * math.pi * 2;
      final d = size.shortestSide * (0.45 + r.nextDouble() * 0.25);
      canvas.drawCircle(
        Offset(center.dx + math.cos(a) * d, center.dy + math.sin(a) * d * 0.6),
        2 + r.nextDouble() * 3.5,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant AtelierInkBlotPainter old) => old.color != color || old.seed != seed;
}

/// بقعة حبر زخرفية خلف طفل (لعناوين الأقسام الكبيرة).
class AtelierInkBlot extends StatelessWidget {
  const AtelierInkBlot({
    super.key,
    required this.child,
    this.color,
    this.seed = 11,
    this.size = 120,
  });

  final Widget child;
  final Color? color;
  final int seed;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        SizedBox.square(
          dimension: size,
          child: CustomPaint(
            painter: AtelierInkBlotPainter(
              color: (color ?? context.pal.accent).withAlpha(26),
              seed: seed,
            ),
          ),
        ),
        child,
      ],
    );
  }
}

/// شارة إنجاز صغيرة: أيقونة ذهبية + تسمية.
class AtelierAchievementChip extends StatelessWidget {
  const AtelierAchievementChip({
    super.key,
    required this.label,
    this.icon,
    this.unlocked = true,
    this.onTap,
  });

  final String label;
  final SIconData? icon;
  final bool unlocked;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final gold = unlocked ? p.gold : p.textDim;
    return AtelierPressable(
      onTap: onTap,
      child: Opacity(
        opacity: unlocked ? 1 : 0.55,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: unlocked ? tint(p.gold, 0.1) : p.surfaceHi,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: unlocked ? tint(p.gold, 0.5) : p.border),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SIcon(icon ?? SardIcons.star_rounded, size: 15, color: gold),
              const SizedBox(width: 6),
              Text(label, style: AtelierType.caption(context, color: unlocked ? p.text : p.textDim)),
            ],
          ),
        ),
      ),
    );
  }
}

/// فاصل بعنوان وسطي: «— اقتراحات لك —».
class AtelierDividerLabel extends StatelessWidget {
  const AtelierDividerLabel({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page, vertical: 8),
      child: Row(
        children: [
          Expanded(child: Container(height: 1, color: p.border)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(label, style: AtelierType.overline(context, color: p.textDim)),
          ),
          Expanded(child: Container(height: 1, color: p.border)),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شريط أسبوع وهدف ورفّ
// ═══════════════════════════════════════════════════════════════════════════

/// شريط أيام الأسبوع: 7 دوائر، المقرؤ منها ذهبي مملوء.
///
/// [readDays] مجموعة أرقام أيام الأسبوع المقروءة (1 = الاثنين… 7 = الأحد).
class AtelierWeekStrip extends StatelessWidget {
  const AtelierWeekStrip({
    super.key,
    required this.readDays,
    this.today,
    this.onDayTap,
  });

  final Set<int> readDays;
  final DateTime? today;
  final ValueChanged<int>? onDayTap;

  static const _labels = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح'];

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final now = today ?? DateTime.now();
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        for (var i = 1; i <= 7; i++)
          _WeekDay(
            label: _labels[i - 1],
            read: readDays.contains(i),
            isToday: now.weekday == i,
            onTap: onDayTap == null ? null : () => onDayTap!(i),
            gold: p.gold,
            dim: p.textDim,
            border: p.border,
          ),
      ],
    );
  }
}

class _WeekDay extends StatelessWidget {
  const _WeekDay({
    required this.label,
    required this.read,
    required this.isToday,
    required this.gold,
    required this.dim,
    required this.border,
    this.onTap,
  });

  final String label;
  final bool read;
  final bool isToday;
  final Color gold;
  final Color dim;
  final Color border;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: read
                  ? LinearGradient(colors: [gold, Color.lerp(gold, Colors.white, 0.25)!])
                  : null,
              color: read ? null : Colors.transparent,
              border: Border.all(color: isToday ? gold : border, width: isToday ? 1.6 : 1),
            ),
            alignment: Alignment.center,
            child: read
                ? const SIcon(SardIcons.check_rounded, size: 17, color: Colors.white)
                : Text(
                    label,
                    style: TextStyle(
                      fontFamily: sardBodyFont,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: isToday ? gold : dim,
                    ),
                  ),
          ),
          const SizedBox(height: 4),
          if (isToday)
            Container(width: 5, height: 5, decoration: BoxDecoration(shape: BoxShape.circle, color: gold)),
        ],
      ),
    );
  }
}

/// بطاقة هدف قراءة: عنوان + تقدّم + زر زيادة.
///
/// تُستعمل في الرئيسية والملف الشخصي (أهداف يومية/أسبوعية).
class AtelierGoalCard extends StatelessWidget {
  const AtelierGoalCard({
    super.key,
    required this.title,
    required this.current,
    required this.target,
    required this.unit,
    this.icon,
    this.tone = AtelierTone.gold,
    this.onTap,
  });

  final String title;
  final int current;
  final int target;
  final String unit;
  final SIconData? icon;
  final AtelierTone tone;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final fraction = target <= 0 ? 0.0 : (current / target).clamp(0.0, 1.0);
    final done = current >= target;
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        decoration: AtelierDecor.card(p, radius: 20),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: tone.color.withAlpha(26),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.center,
                  child: SIcon(icon ?? SardIcons.local_fire_department_rounded, size: 19, color: tone.color),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(title, style: AtelierType.subtitle(context, size: 14.5)),
                ),
                if (done)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: AtelierDecor.badge(AtelierTone.jade.color),
                    child: const Text(
                      'اكتمل',
                      style: TextStyle(
                        fontFamily: sardBodyFont,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text('$current', style: AtelierType.numeral(context, size: 26, color: tone.color)),
                const SizedBox(width: 5),
                Text('/ $target $unit', style: AtelierType.caption(context, size: 12.5)),
                const Spacer(),
                Text(atelierPercent(fraction), style: AtelierType.caption(context, color: tone.color)),
              ],
            ),
            const SizedBox(height: 8),
            AtelierProgressBar(fraction: fraction, height: 8, foreground: tone.color),
          ],
        ),
      ),
    );
  }
}

/// شريط رائج أفقي مرقّم: غلاف صغير + رقم كبير + عنوان.
class AtelierTrendingStrip extends StatelessWidget {
  const AtelierTrendingStrip({
    super.key,
    required this.series,
    this.onTap,
    this.title = 'رائج الآن',
  });

  final List<Series> series;
  final void Function(Series)? onTap;
  final String title;

  @override
  Widget build(BuildContext context) {
    if (series.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AtelierHeading(kicker: 'الأكثر مشاهدة', title: title),
        SizedBox(
          height: 150,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
            itemCount: series.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (context, i) {
              final s = series[i];
              return AtelierPressable(
                onTap: onTap == null ? null : () => onTap!(s),
                child: SizedBox(
                  width: 240,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${i + 1}',
                        style: TextStyle(
                          fontFamily: sardFont,
                          fontSize: 44,
                          fontWeight: FontWeight.w800,
                          color: context.pal.gold.withAlpha(200),
                          height: 1,
                        ),
                      ),
                      const SizedBox(width: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: SizedBox(
                          width: 76,
                          height: 106,
                          child: CoverArt(series: s, radius: 0, showTitle: false),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(s.title, style: AtelierType.subtitle(context, size: 13.5), maxLines: 2, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                const SIcon(SardIcons.star_rounded, size: 13, color: Color(0xFFFFC94D)),
                                const SizedBox(width: 3),
                                Text(atelierRatingLabel(s.rating), style: AtelierType.caption(context, color: context.pal.text)),
                              ],
                            ),
                            const SizedBox(height: 3),
                            Text('${formatCount(s.views)} مشاهدة', style: AtelierType.caption(context)),
                            const SizedBox(height: 3),
                            Text(atelierChaptersLabel(s.chapters), style: AtelierType.caption(context)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

/// رفّ مكتبة: أغلفة واقفة على رف خشبي مرسوم (إحساس مكتبة حقيقية).
class AtelierShelfRow extends StatelessWidget {
  const AtelierShelfRow({
    super.key,
    required this.series,
    this.onTap,
    this.height = 170,
  });

  final List<Series> series;
  final void Function(Series)? onTap;
  final double height;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: height,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
            itemCount: series.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final s = series[i];
              return AtelierPressable(
                onTap: onTap == null ? null : () => onTap!(s),
                child: Transform.rotate(
                  angle: atelierTiltOf(s.id),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: softShadow(p, strength: 0.8),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: SizedBox(
                        width: height * AtelierSpacing.posterAspect,
                        height: height,
                        child: CoverArt(series: s, radius: 0, showTitle: false),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 6),
        Container(
          height: 8,
          margin: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [const Color(0xFF8A6A45), const Color(0xFF6B4F31), const Color(0xFF8A6A45)],
            ),
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(color: Colors.black.withAlpha(40), blurRadius: 8, offset: const Offset(0, 4)),
            ],
          ),
        ),
      ],
    );
  }
}
