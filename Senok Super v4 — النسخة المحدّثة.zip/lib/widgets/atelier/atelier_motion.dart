import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import 'atelier_theme.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// حركات Atelier السينمائية — انتقالات صفحات، ظهور متدرج، نبض، Parallax.
/// كل حركة تُبطل تلقائياً عند تفعيل «تقليل الحركة» في النظام
/// (MediaQuery.disableAnimations) فتظهر العناصر فوراً دون انتظار.
///
/// القواعد:
///   • الظهور المتدرج يحدث مرة واحدة فقط لكل عنصر (لا يتكرر عند
///     إعادة البناء أو التمرير ذهاباً وإياباً).
///   • كل المدد والمنحنيات موحّدة في [AtelierMotion].
///   • لا شيء هنا يعتمد على حزم خارجية.
/// ──────────────────────────────────────────────────────────────────────────

/// هل يجب إبطال الحركات؟ (تقليل الحركة من النظام)
bool atelierReducedMotion(BuildContext context) =>
    MediaQuery.disableAnimationsOf(context);

/// مدد ومنحنيات Atelier الموحّدة.
abstract final class AtelierMotion {
  /// ظهور سريع (بطاقات صغيرة).
  static const Duration fast = Duration(milliseconds: 220);

  /// ظهور عادي (أقسام).
  static const Duration normal = Duration(milliseconds: 380);

  /// ظهور بطيء (بطل، انتقالات).
  static const Duration slow = Duration(milliseconds: 650);

  /// نبض ذهبي.
  static const Duration pulse = Duration(milliseconds: 1400);

  /// عدّاد رقمي.
  static const Duration count = Duration(milliseconds: 900);

  /// المنحنى الافتراضي للظهور.
  static const Curve easeOut = Curves.easeOutCubic;

  /// المنحنى الافتراضي للدخول من الأسفل.
  static const Curve enter = Curves.easeOutQuart;

  /// منحنى النبض.
  static const Curve pulseCurve = Curves.easeInOut;
}

/// سجل العناصر التي ظهرت مرة واحدة (مفاتيح نصية يمررها المطوّر).
///
/// يُستعمل من [FadeSlide] و[AtelierStagger] لضمان أن الحركة لا تتكرر
/// عند إعادة بناء الشجرة (مثلاً بعد تبديل ثيم أو تحديث بيانات).
final class AtelierSeen {
  AtelierSeen._();
  static final Set<String> _seen = <String>{};

  static bool mark(String key) => _seen.add(key);
  static bool has(String key) => _seen.contains(key);
  static void reset() => _seen.clear();
  static void forget(String key) => _seen.remove(key);
}

/// ظهور متدرج مع انزلاق خفيف — يحدث مرة واحدة فقط.
///
/// عند أول بناء يبدأ شفافاً ومنزاحاً قليلاً للأسفل ثم يظهر؛ وعند أي
/// إعادة بناء لاحقة يظهر فوراً دون حركة. إن فُعّل «تقليل الحركة»
/// يظهر فوراً من البداية. يمكن تمرير [onceKey] لربط «مرة واحدة»
/// بمفتاح ثابت عبر إعادة إنشاء الويدجت.
class FadeSlide extends StatefulWidget {
  const FadeSlide({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = AtelierMotion.normal,
    this.offset = 18,
    this.onceKey,
    this.curve = AtelierMotion.enter,
  });

  final Widget child;
  final Duration delay;
  final Duration duration;
  final double offset;
  final String? onceKey;
  final Curve curve;

  @override
  State<FadeSlide> createState() => _FadeSlideState();
}

class _FadeSlideState extends State<FadeSlide> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _opacity;
  late final Animation<double> _slide;
  bool _instant = false;

  @override
  void initState() {
    super.initState();
    if (widget.onceKey != null && AtelierSeen.has(widget.onceKey!)) {
      _instant = true;
    }
    _c = AnimationController(vsync: this, duration: widget.duration);
    _opacity = CurvedAnimation(parent: _c, curve: widget.curve);
    _slide = Tween<double>(begin: widget.offset, end: 0).animate(
      CurvedAnimation(parent: _c, curve: widget.curve),
    );
    if (_instant) {
      _c.value = 1;
    } else {
      if (widget.onceKey != null) AtelierSeen.mark(widget.onceKey!);
      if (widget.delay == Duration.zero) {
        _c.forward();
      } else {
        Future.delayed(widget.delay, () {
          if (mounted) _c.forward();
        });
      }
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_instant || atelierReducedMotion(context)) {
      return widget.child;
    }
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) => Opacity(
        opacity: _opacity.value,
        child: Transform.translate(
          offset: Offset(0, _slide.value),
          child: child,
        ),
      ),
      child: widget.child,
    );
  }
}

/// ظهور متدرج فقط (بلا انزلاق) — للعناوين والأيقونات الصغيرة.
class AtelierFade extends StatefulWidget {
  const AtelierFade({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = AtelierMotion.normal,
    this.onceKey,
  });

  final Widget child;
  final Duration delay;
  final Duration duration;
  final String? onceKey;

  @override
  State<AtelierFade> createState() => _AtelierFadeState();
}

class _AtelierFadeState extends State<AtelierFade> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  bool _instant = false;

  @override
  void initState() {
    super.initState();
    if (widget.onceKey != null && AtelierSeen.has(widget.onceKey!)) {
      _instant = true;
    }
    _c = AnimationController(vsync: this, duration: widget.duration);
    if (_instant) {
      _c.value = 1;
    } else {
      if (widget.onceKey != null) AtelierSeen.mark(widget.onceKey!);
      if (widget.delay == Duration.zero) {
        _c.forward();
      } else {
        Future.delayed(widget.delay, () {
          if (mounted) _c.forward();
        });
      }
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_instant || atelierReducedMotion(context)) return widget.child;
    return FadeTransition(opacity: _c, child: widget.child);
  }
}

/// تكبير دخول ناعم (للأختام والشارات والرفيق).
class AtelierScaleIn extends StatefulWidget {
  const AtelierScaleIn({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = AtelierMotion.normal,
    this.from = 0.82,
    this.onceKey,
  });

  final Widget child;
  final Duration delay;
  final Duration duration;
  final double from;
  final String? onceKey;

  @override
  State<AtelierScaleIn> createState() => _AtelierScaleInState();
}

class _AtelierScaleInState extends State<AtelierScaleIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _scale;
  late final Animation<double> _opacity;
  bool _instant = false;

  @override
  void initState() {
    super.initState();
    if (widget.onceKey != null && AtelierSeen.has(widget.onceKey!)) {
      _instant = true;
    }
    _c = AnimationController(vsync: this, duration: widget.duration);
    _scale = Tween<double>(begin: widget.from, end: 1).animate(
      CurvedAnimation(parent: _c, curve: AtelierMotion.easeOut),
    );
    _opacity = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    if (_instant) {
      _c.value = 1;
    } else {
      if (widget.onceKey != null) AtelierSeen.mark(widget.onceKey!);
      if (widget.delay == Duration.zero) {
        _c.forward();
      } else {
        Future.delayed(widget.delay, () {
          if (mounted) _c.forward();
        });
      }
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_instant || atelierReducedMotion(context)) return widget.child;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) => Opacity(
        opacity: _opacity.value,
        child: Transform.scale(scale: _scale.value, child: child),
      ),
      child: widget.child,
    );
  }
}

/// ظهور متتالٍ لأطفال عمود (كل طفل يتأخر عن سابقه بمقدار [stagger]).
///
/// يُستعمل لأقسام الصفحة الرئيسية: العنوان، ثم البطل، ثم الصفوف.
class AtelierStagger extends StatelessWidget {
  const AtelierStagger({
    super.key,
    required this.children,
    this.stagger = const Duration(milliseconds: 70),
    this.baseDelay = Duration.zero,
    this.offset = 18,
    this.duration = AtelierMotion.normal,
    this.oncePrefix,
  });

  final List<Widget> children;
  final Duration stagger;
  final Duration baseDelay;
  final double offset;
  final Duration duration;
  final String? oncePrefix;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < children.length; i++)
          FadeSlide(
            delay: baseDelay + stagger * i,
            offset: offset,
            duration: duration,
            onceKey: oncePrefix == null ? null : '$oncePrefix-$i',
            child: children[i],
          ),
      ],
    );
  }
}

/// ظهور متتالٍ أفقي (لصف بطاقات).
class AtelierStaggerRow extends StatelessWidget {
  const AtelierStaggerRow({
    super.key,
    required this.children,
    this.stagger = const Duration(milliseconds: 60),
    this.baseDelay = Duration.zero,
    this.oncePrefix,
  });

  final List<Widget> children;
  final Duration stagger;
  final Duration baseDelay;
  final String? oncePrefix;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (var i = 0; i < children.length; i++)
          Expanded(
            child: FadeSlide(
              delay: baseDelay + stagger * i,
              onceKey: oncePrefix == null ? null : '$oncePrefix-$i',
              child: children[i],
            ),
          ),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────────────
//  نبض وتوهّج وعدّادات
// ──────────────────────────────────────────────────────────────────────────

/// نبض ذهبي متكرر (لشارة عرض أو زر مميز).
class AtelierPulse extends StatefulWidget {
  const AtelierPulse({
    super.key,
    required this.child,
    this.duration = AtelierMotion.pulse,
    this.minScale = 1.0,
    this.maxScale = 1.06,
    this.glowColor,
  });

  final Widget child;
  final Duration duration;
  final double minScale;
  final double maxScale;
  final Color? glowColor;

  @override
  State<AtelierPulse> createState() => _AtelierPulseState();
}

class _AtelierPulseState extends State<AtelierPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration);
    _scale = Tween<double>(begin: widget.minScale, end: widget.maxScale).animate(
      CurvedAnimation(parent: _c, curve: AtelierMotion.pulseCurve),
    );
    _c.repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (atelierReducedMotion(context)) return widget.child;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) => Transform.scale(scale: _scale.value, child: child),
      child: widget.child,
    );
  }
}

/// توهّج ذهبي نابض خلف طفل (لغلاف مميز أو ختم).
class AtelierGlowPulse extends StatefulWidget {
  const AtelierGlowPulse({
    super.key,
    required this.child,
    this.duration = AtelierMotion.pulse,
    this.color,
    this.maxBlur = 26,
  });

  final Widget child;
  final Duration duration;
  final Color? color;
  final double maxBlur;

  @override
  State<AtelierGlowPulse> createState() => _AtelierGlowPulseState();
}

class _AtelierGlowPulseState extends State<AtelierGlowPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _a;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration);
    _a = Tween<double>(begin: 0.35, end: 1).animate(
      CurvedAnimation(parent: _c, curve: AtelierMotion.pulseCurve),
    );
    _c.repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (atelierReducedMotion(context)) return widget.child;
    final p = context.pal;
    final color = widget.color ?? p.gold;
    return AnimatedBuilder(
      animation: _a,
      builder: (context, child) => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
              color: color.withAlpha((50 * _a.value).round()),
              blurRadius: widget.maxBlur * _a.value,
              spreadRadius: 2 * _a.value,
            ),
          ],
        ),
        child: child,
      ),
      child: widget.child,
    );
  }
}

/// عدّاد رقمي متحرك: يعدّ من 0 إلى [value] خلال [duration].
///
/// يعرض بالتنسيق العربي المختصر (ألف/م) عبر [formatCount] عندما
/// يكون [compact] صحيحاً، وإلا يعرض الرقم كاملاً.
class AtelierCountUp extends StatefulWidget {
  const AtelierCountUp({
    super.key,
    required this.value,
    this.duration = AtelierMotion.count,
    this.compact = false,
    this.style,
    this.prefix = '',
    this.suffix = '',
  });

  final int value;
  final Duration duration;
  final bool compact;
  final TextStyle? style;
  final String prefix;
  final String suffix;

  @override
  State<AtelierCountUp> createState() => _AtelierCountUpState();
}

class _AtelierCountUpState extends State<AtelierCountUp> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<int> _n;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration);
    _n = IntTween(begin: 0, end: widget.value).animate(
      CurvedAnimation(parent: _c, curve: Curves.easeOutQuart),
    );
    _c.forward();
  }

  @override
  void didUpdateWidget(covariant AtelierCountUp old) {
    super.didUpdateWidget(old);
    if (old.value != widget.value) {
      _n = IntTween(begin: old.value, end: widget.value).animate(
        CurvedAnimation(parent: _c, curve: Curves.easeOutQuart),
      );
      _c
        ..reset()
        ..forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (atelierReducedMotion(context)) {
      final label = widget.compact ? formatCount(widget.value) : '${widget.value}';
      return Text('${widget.prefix}$label${widget.suffix}', style: widget.style);
    }
    return AnimatedBuilder(
      animation: _n,
      builder: (context, _) {
        final label = widget.compact ? formatCount(_n.value) : '${_n.value}';
        return Text('${widget.prefix}$label${widget.suffix}', style: widget.style);
      },
    );
  }
}

/// شريط تقدّم ذهبي متحرك (لسلسلة أيام أو هدف قراءة).
class AtelierProgressBar extends StatelessWidget {
  const AtelierProgressBar({
    super.key,
    required this.fraction,
    this.height = 8,
    this.background,
    this.foreground,
    this.duration = AtelierMotion.normal,
    this.showGlow = true,
  });

  final double fraction;
  final double height;
  final Color? background;
  final Color? foreground;
  final Duration duration;
  final bool showGlow;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final f = fraction.clamp(0.0, 1.0);
    final fg = foreground ?? p.gold;
    final track = Container(
      height: height,
      decoration: BoxDecoration(
        color: background ?? p.border,
        borderRadius: BorderRadius.circular(999),
      ),
    );
    final fill = LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth * f;
        final bar = AnimatedContainer(
          duration: atelierReducedMotion(context) ? Duration.zero : duration,
          curve: Curves.easeOutCubic,
          width: w,
          height: height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerRight,
              end: Alignment.centerLeft,
              colors: [fg, Color.lerp(fg, Colors.white, 0.35)!],
            ),
            borderRadius: BorderRadius.circular(999),
            boxShadow: showGlow
                ? [BoxShadow(color: fg.withAlpha(70), blurRadius: 8, offset: const Offset(0, 2))]
                : null,
          ),
        );
        return Align(alignment: Alignment.centerRight, child: bar);
      },
    );
    return Stack(children: [track, Positioned.fill(child: fill)]);
  }
}

/// ضغط قابل للنقر يصغّر قليلاً عند اللمس (للبطاقات والأزرار).
class AtelierPressable extends StatefulWidget {
  const AtelierPressable({
    super.key,
    required this.child,
    this.onTap,
    this.scale = 0.97,
    this.duration = const Duration(milliseconds: 120),
  });

  final Widget child;
  final VoidCallback? onTap;
  final double scale;
  final Duration duration;

  @override
  State<AtelierPressable> createState() => _AtelierPressableState();
}

class _AtelierPressableState extends State<AtelierPressable> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) => setState(() => _down = false),
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? widget.scale : 1.0,
        duration: widget.duration,
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}

/// دوران بطيء لعنصر زخرفي (حلقة أو ختم خلفية).
class AtelierSlowSpin extends StatefulWidget {
  const AtelierSlowSpin({
    super.key,
    required this.child,
    this.duration = const Duration(seconds: 24),
  });

  final Widget child;
  final Duration duration;

  @override
  State<AtelierSlowSpin> createState() => _AtelierSlowSpinState();
}

class _AtelierSlowSpinState extends State<AtelierSlowSpin> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration)..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (atelierReducedMotion(context)) return widget.child;
    return RotationTransition(turns: _c, child: widget.child);
  }
}

// ──────────────────────────────────────────────────────────────────────────
//  Parallax وغبار ذهب وانتقالات
// ──────────────────────────────────────────────────────────────────────────

/// Parallax خفيف: يحرّك الطفل عمودياً بنسبة من تمرير القائمة.
///
/// يُربط بـ [ScrollController] الصفحة؛ كلما تقدّم التمرير تحرّك
/// الغلاف ببطء في الاتجاه المعاكس (إحساس عمق سينمائي).
class AtelierParallax extends StatefulWidget {
  const AtelierParallax({
    super.key,
    required this.controller,
    required this.child,
    this.factor = 0.25,
    this.height = 300,
  });

  final ScrollController controller;
  final Widget child;
  final double factor;
  final double height;

  @override
  State<AtelierParallax> createState() => _AtelierParallaxState();
}

class _AtelierParallaxState extends State<AtelierParallax> {
  double _offset = 0;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onScroll);
  }

  void _onScroll() {
    if (!mounted) return;
    final next = (widget.controller.offset * widget.factor).clamp(0.0, widget.height * 0.5);
    if ((next - _offset).abs() > 0.5) setState(() => _offset = next);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onScroll);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: widget.height,
      child: ClipRect(
        child: OverflowBox(
          maxHeight: widget.height * (1 + widget.factor),
          alignment: Alignment.topCenter,
          child: Transform.translate(
            offset: Offset(0, -_offset),
            child: SizedBox(height: widget.height * (1 + widget.factor), child: widget.child),
          ),
        ),
      ),
    );
  }
}

/// رسّام غبار ذهب عائم (نقاط متلألئة تتحرك ببطء للأعلى).
class GoldDustPainter extends CustomPainter {
  GoldDustPainter({required this.progress, required this.color, this.count = 26, this.seed = 7});

  final double progress;
  final Color color;
  final int count;
  final int seed;

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(seed);
    for (var i = 0; i < count; i++) {
      final x0 = r.nextDouble();
      final y0 = r.nextDouble();
      final speed = 0.02 + r.nextDouble() * 0.05;
      final sizeMul = 0.6 + r.nextDouble() * 1.8;
      final twinkle = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(progress * 6.28 * 2 + i * 1.7));
      final y = (y0 - progress * speed) % 1.0;
      final paint = Paint()..color = color.withAlpha((150 * twinkle).round().clamp(0, 255));
      canvas.drawCircle(
        Offset(x0 * size.width, y * size.height),
        1.1 * sizeMul,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant GoldDustPainter old) => old.progress != progress || old.color != color;
}

/// غبار ذهب متحرك يغطي مساحته (للبطل وشاشة البداية).
class AtelierGoldDust extends StatefulWidget {
  const AtelierGoldDust({
    super.key,
    this.count = 26,
    this.seed = 7,
    this.color,
    this.duration = const Duration(seconds: 14),
  });

  final int count;
  final int seed;
  final Color? color;
  final Duration duration;

  @override
  State<AtelierGoldDust> createState() => _AtelierGoldDustState();
}

class _AtelierGoldDustState extends State<AtelierGoldDust> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration)..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (atelierReducedMotion(context)) {
      return CustomPaint(
        painter: GoldDustPainter(progress: 0.3, color: widget.color ?? context.pal.gold, count: widget.count, seed: widget.seed),
      );
    }
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) => CustomPaint(
        painter: GoldDustPainter(progress: _c.value, color: widget.color ?? context.pal.gold, count: widget.count, seed: widget.seed),
      ),
    );
  }
}

/// انتقال صفحة Atelier: تلاشٍ + انزلاق خفيف من الأسفل.
PageRouteBuilder<T> atelierPageRoute<T>(Widget page, {Duration duration = AtelierMotion.slow}) {
  return PageRouteBuilder<T>(
    transitionDuration: duration,
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (context, animation, secondary) => page,
    transitionsBuilder: (context, animation, secondary, child) {
      final fade = CurvedAnimation(parent: animation, curve: Curves.easeOut);
      final slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(
        CurvedAnimation(parent: animation, curve: Curves.easeOutQuart),
      );
      return FadeTransition(
        opacity: fade,
        child: SlideTransition(position: slide, child: child),
      );
    },
  );
}

/// نقاط تنقّل دائرية لقسم بطل (النقطة النشطة أطول وذهبية).
class AtelierCarouselDots extends StatelessWidget {
  const AtelierCarouselDots({
    super.key,
    required this.count,
    required this.index,
    this.onTap,
    this.activeColor,
  });

  final int count;
  final int index;
  final ValueChanged<int>? onTap;
  final Color? activeColor;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final active = activeColor ?? p.gold;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < count; i++)
          GestureDetector(
            onTap: onTap == null ? null : () => onTap!(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
              width: i == index ? 22 : 7,
              height: 7,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: i == index ? active : Colors.white.withAlpha(110),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
      ],
    );
  }
}

/// شارة تقدّم دائرية متحركة (لحلقة هدف أو سلسلة أيام).
class AtelierRingProgress extends StatelessWidget {
  const AtelierRingProgress({
    super.key,
    required this.fraction,
    required this.child,
    this.size = 64,
    this.stroke = 6,
    this.color,
    this.duration = AtelierMotion.normal,
  });

  final double fraction;
  final Widget child;
  final double size;
  final double stroke;
  final Color? color;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = color ?? p.gold;
    return SizedBox.square(
      dimension: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox.square(
            dimension: size,
            child: CircularProgressIndicator(
              value: fraction.clamp(0.0, 1.0),
              strokeWidth: stroke,
              color: c,
              backgroundColor: p.border,
              strokeCap: StrokeCap.round,
            ),
          ),
          child,
        ],
      ),
    );
  }
}

/// نص عدّاد: «128 فصلاً مقروءاً» بعدّ متحرك.
class AtelierCountLabel extends StatelessWidget {
  const AtelierCountLabel({
    super.key,
    required this.value,
    required this.label,
    this.compact = false,
    this.style,
    this.labelStyle,
  });

  final int value;
  final String label;
  final bool compact;
  final TextStyle? style;
  final TextStyle? labelStyle;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        AtelierCountUp(value: value, compact: compact, style: style ?? context.atelierNumeral),
        const SizedBox(width: 6),
        Text(label, style: labelStyle ?? context.atelierCaption),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────────────
//  كتابة آلية وارتداد وتبديل متحرك
// ──────────────────────────────────────────────────────────────────────────

/// نص يُكتب حرفاً حرفاً (لشاشات الترحيب وعناوين البطل).
class AtelierTypewriter extends StatefulWidget {
  const AtelierTypewriter({
    super.key,
    required this.text,
    this.style,
    this.speed = const Duration(milliseconds: 45),
    this.startDelay = Duration.zero,
    this.onDone,
  });

  final String text;
  final TextStyle? style;
  final Duration speed;
  final Duration startDelay;
  final VoidCallback? onDone;

  @override
  State<AtelierTypewriter> createState() => _AtelierTypewriterState();
}

class _AtelierTypewriterState extends State<AtelierTypewriter> {
  int _shown = 0;
  bool _started = false;

  @override
  void initState() {
    super.initState();
    if (atelierReducedMotion(context)) {
      _shown = widget.text.length;
      _started = true;
      return;
    }
    Future.delayed(widget.startDelay, () {
      if (!mounted) return;
      setState(() => _started = true);
      _tick();
    });
  }

  void _tick() {
    if (!mounted) return;
    if (_shown >= widget.text.length) {
      widget.onDone?.call();
      return;
    }
    Future.delayed(widget.speed, () {
      if (!mounted) return;
      setState(() => _shown++);
      _tick();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_started) return Text('', style: widget.style);
    final text = widget.text.substring(0, _shown.clamp(0, widget.text.length));
    return Text(text, style: widget.style);
  }
}

/// ارتداد دخول: يكبر قليلاً ثم يستقر (لأزرار وأختام).
class AtelierBounceIn extends StatefulWidget {
  const AtelierBounceIn({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 520),
    this.onceKey,
  });

  final Widget child;
  final Duration delay;
  final Duration duration;
  final String? onceKey;

  @override
  State<AtelierBounceIn> createState() => _AtelierBounceInState();
}

class _AtelierBounceInState extends State<AtelierBounceIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _scale;
  bool _instant = false;

  @override
  void initState() {
    super.initState();
    if (widget.onceKey != null && AtelierSeen.has(widget.onceKey!)) {
      _instant = true;
    }
    _c = AnimationController(vsync: this, duration: widget.duration);
    _scale = Tween<double>(begin: 0.6, end: 1).animate(
      CurvedAnimation(parent: _c, curve: Curves.elasticOut),
    );
    if (_instant) {
      _c.value = 1;
    } else {
      if (widget.onceKey != null) AtelierSeen.mark(widget.onceKey!);
      if (widget.delay == Duration.zero) {
        _c.forward();
      } else {
        Future.delayed(widget.delay, () {
          if (mounted) _c.forward();
        });
      }
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_instant || atelierReducedMotion(context)) return widget.child;
    return ScaleTransition(scale: _scale, child: widget.child);
  }
}

/// تبديل متحرك بين طفلين (لتبديل محتوى بطاقة دون قفزة).
class AtelierAnimatedSwap extends StatelessWidget {
  const AtelierAnimatedSwap({
    super.key,
    required this.showFirst,
    required this.first,
    required this.second,
    this.duration = const Duration(milliseconds: 300),
  });

  final bool showFirst;
  final Widget first;
  final Widget second;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: atelierReducedMotion(context) ? Duration.zero : duration,
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      transitionBuilder: (child, animation) => FadeTransition(
        opacity: animation,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(animation),
          child: child,
        ),
      ),
      child: showFirst
          ? KeyedSubtree(key: const ValueKey('first'), child: first)
          : KeyedSubtree(key: const ValueKey('second'), child: second),
    );
  }
}

/// اهتزاز خفيف لعنصر (لتنبيه دون إزعاج — مثلاً زر عند خطأ).
class AtelierNudge extends StatefulWidget {
  const AtelierNudge({
    super.key,
    required this.child,
    this.nudgeKey,
  });

  final Widget child;
  final Key? nudgeKey;

  @override
  State<AtelierNudge> createState() => _AtelierNudgeState();
}

class _AtelierNudgeState extends State<AtelierNudge> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _x;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _x = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -7.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -7.0, end: 6.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: 6.0, end: -4.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -4.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }

  /// يشغّل الاهتزاز (يستدعيه الأب عبر مفتاح [GlobalKey]).
  void nudge() {
    if (atelierReducedMotion(context)) return;
    _c
      ..reset()
      ..forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _x,
      builder: (context, child) => Transform.translate(
        offset: Offset(_x.value, 0),
        child: child,
      ),
      child: widget.child,
    );
  }
}
