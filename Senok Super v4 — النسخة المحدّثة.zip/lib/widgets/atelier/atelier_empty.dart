import 'package:flutter/material.dart';

import '../../core/theme/app_themes.dart';
import '../ink_spirit.dart';
import '../sard_icons.dart';
import 'atelier_cards.dart';
import 'atelier_motion.dart';
import 'atelier_theme.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// حالات الفراغ الأنيقة — لكل قسم في التطبيق حالة فراغ خاصة به:
/// مكتبة، بحث، تنزيلات، إشعارات، تعليقات، مفضلة، سجل، بلا اتصال، خطأ.
///
/// كل حالة: روح حبر بمزاج مناسب + عنوان + وصف + زر إجراء اختياري.
/// تظهر بتدرّج لطيف (مرة واحدة) وتحترم «تقليل الحركة».
/// ──────────────────────────────────────────────────────────────────────────

/// حالة فراغ عامة قابلة لإعادة الاستخدام في كل الأقسام.
class AtelierEmptyState extends StatelessWidget {
  const AtelierEmptyState({
    super.key,
    required this.title,
    required this.subtitle,
    this.mood = InkSpiritMood.calm,
    this.icon,
    this.actionLabel,
    this.onAction,
    this.secondaryLabel,
    this.onSecondary,
    this.size = 120,
  });

  final String title;
  final String subtitle;
  final InkSpiritMood mood;
  final SIconData? icon;
  final String? actionLabel;
  final VoidCallback? onAction;
  final String? secondaryLabel;
  final VoidCallback? onSecondary;
  final double size;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return FadeSlide(
      onceKey: 'empty-$title',
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                AtelierInkBlot(
                  size: size + 40,
                  color: p.accent,
                  seed: title.hashCode & 0x7fffffff,
                  child: const SizedBox.shrink(),
                ),
                InkSpirit(size: size, mood: mood),
              ],
            ),
            const SizedBox(height: 16),
            if (icon != null) ...[
              Container(
                padding: const EdgeInsets.all(10),
                decoration: AtelierDecor.pill(p.gold),
                child: SIcon(icon!, size: 20, color: p.gold),
              ),
              const SizedBox(height: 12),
            ],
            Text(
              title,
              textAlign: TextAlign.center,
              style: AtelierType.title(context, size: 19),
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: AtelierType.muted(context, size: 13.5),
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 20),
              GestureDetector(
                onTap: onAction,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                  decoration: BoxDecoration(
                    color: p.accent,
                    borderRadius: BorderRadius.circular(999),
                    boxShadow: [BoxShadow(color: tint(p.accent, 0.3), blurRadius: 14, offset: const Offset(0, 6))],
                  ),
                  child: Text(actionLabel!, style: AtelierType.button(context, color: p.onAccent)),
                ),
              ),
            ],
            if (secondaryLabel != null && onSecondary != null) ...[
              const SizedBox(height: 10),
              GestureDetector(
                onTap: onSecondary,
                child: Text(secondaryLabel!, style: AtelierType.caption(context, color: p.accent)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// فراغ البحث: بلا نتائج لكلمة البحث.
class AtelierEmptySearch extends StatelessWidget {
  const AtelierEmptySearch({super.key, required this.query, this.onClear, this.onBrowse});

  final String query;
  final VoidCallback? onClear;
  final VoidCallback? onBrowse;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا نتائج لـ «$query»',
      subtitle: 'جرّب كلمة أخرى، أو تصفّح التصنيفات فقد تجد حكاية أجمل مما تبحث عنه.',
      mood: InkSpiritMood.curious,
      icon: SardIcons.search_rounded,
      actionLabel: 'مسح البحث',
      onAction: onClear,
      secondaryLabel: 'تصفّح التصنيفات',
      onSecondary: onBrowse,
    );
  }
}

/// فراغ المكتبة: لا أعمال متابَعة بعد.
class AtelierEmptyLibrary extends StatelessWidget {
  const AtelierEmptyLibrary({super.key, this.onExplore});

  final VoidCallback? onExplore;

  @override
  Widget build(BuildContext context) {
    return const AtelierEmptyState(
      title: 'مكتبتك فارغة',
      subtitle: 'تابع أعمالاً تحبها وستظهر هنا، مع فصولها الجديدة أولاً بأول.',
      mood: InkSpiritMood.calm,
      icon: SardIcons.collections_bookmark_rounded,
    );
  }
}

/// فراغ التنزيلات: لا فصول منزّلة.
class AtelierEmptyDownloads extends StatelessWidget {
  const AtelierEmptyDownloads({super.key, this.onBrowse});

  final VoidCallback? onBrowse;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا تنزيلات بعد',
      subtitle: 'نزّل فصولاً لتقرأها بلا إنترنت — مثالية للسفر والأماكن بلا شبكة.',
      mood: InkSpiritMood.sleepy,
      icon: SardIcons.download_rounded,
      actionLabel: 'تصفّح الأعمال',
      onAction: onBrowse,
    );
  }
}

/// فراغ الإشعارات: كل شيء مقروء.
class AtelierEmptyNotifications extends StatelessWidget {
  const AtelierEmptyNotifications({super.key});

  @override
  Widget build(BuildContext context) {
    return const AtelierEmptyState(
      title: 'لا إشعارات جديدة',
      subtitle: 'كل شيء مقروء. عندما تصل فصول جديدة من أعمالك ستظهر هنا فوراً.',
      mood: InkSpiritMood.happy,
      icon: SardIcons.notifications_none_rounded,
    );
  }
}

/// فراغ التعليقات: كن أول من يعلّق.
class AtelierEmptyComments extends StatelessWidget {
  const AtelierEmptyComments({super.key, this.onComment});

  final VoidCallback? onComment;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا تعليقات بعد',
      subtitle: 'كن أول من يشارك رأيه في هذا الفصل — كلمة منك قد تغيّر رأي قارئ آخر.',
      mood: InkSpiritMood.curious,
      icon: SardIcons.chat_bubble_outline_rounded,
      actionLabel: 'اكتب أول تعليق',
      onAction: onComment,
    );
  }
}

/// فراغ المفضلة: لا أعمال مفضلة.
class AtelierEmptyFavorites extends StatelessWidget {
  const AtelierEmptyFavorites({super.key, this.onExplore});

  final VoidCallback? onExplore;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا مفضلات بعد',
      subtitle: 'اضغط على القلب في أي عمل ليظهر هنا — مكتبتك الخاصة بأجمل الحكايات.',
      mood: InkSpiritMood.calm,
      icon: SardIcons.favorite_rounded,
      actionLabel: 'اكتشف أعمالاً',
      onAction: onExplore,
    );
  }
}

/// فراغ السجل: لم تقرأ شيئاً بعد.
class AtelierEmptyHistory extends StatelessWidget {
  const AtelierEmptyHistory({super.key, this.onStart});

  final VoidCallback? onStart;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'سجلك فارغ',
      subtitle: 'اقرأ أول فصل وسيبدأ سجلّك هنا — ومعه إحصاءاتك وسلسلة أيامك.',
      mood: InkSpiritMood.calm,
      icon: SardIcons.history_rounded,
      actionLabel: 'ابدأ القراءة',
      onAction: onStart,
    );
  }
}

/// فراغ بلا اتصال: الشبكة مقطوعة.
class AtelierEmptyOffline extends StatelessWidget {
  const AtelierEmptyOffline({super.key, this.onRetry, this.onDownloads});

  final VoidCallback? onRetry;
  final VoidCallback? onDownloads;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا يوجد اتصال',
      subtitle: 'يبدو أن الشبكة مقطوعة. يمكنك قراءة فصولك المنزّلة حتى تعود.',
      mood: InkSpiritMood.concerned,
      icon: SardIcons.cloud_off_rounded,
      actionLabel: 'إعادة المحاولة',
      onAction: onRetry,
      secondaryLabel: 'عرض التنزيلات',
      onSecondary: onDownloads,
    );
  }
}

/// فراغ الخطأ: تعذّر التحميل مع زر إعادة.
class AtelierEmptyError extends StatelessWidget {
  const AtelierEmptyError({super.key, this.message, this.onRetry});

  final String? message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'تعذّر التحميل',
      subtitle: message ?? 'حدث خطأ أثناء جلب البيانات. تحقق من اتصالك وحاول مجدداً.',
      mood: InkSpiritMood.concerned,
      icon: SardIcons.refresh_rounded,
      actionLabel: 'إعادة المحاولة',
      onAction: onRetry,
    );
  }
}

/// فراغ الأهداف: لم تحدّد هدف قراءة بعد.
class AtelierEmptyGoals extends StatelessWidget {
  const AtelierEmptyGoals({super.key, this.onSetGoal});

  final VoidCallback? onSetGoal;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا هدف بعد',
      subtitle: 'حدّد هدفاً صغيراً — فصل واحد يومياً يكفي لبناء عادة قراءة تدوم.',
      mood: InkSpiritMood.excited,
      icon: SardIcons.local_fire_department_rounded,
      actionLabel: 'حدّد هدفك',
      onAction: onSetGoal,
    );
  }
}

/// فراغ المجموعات: لم تنشئ مجموعة بعد.
class AtelierEmptyCollections extends StatelessWidget {
  const AtelierEmptyCollections({super.key, this.onCreate});

  final VoidCallback? onCreate;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا مجموعات بعد',
      subtitle: 'اجمع أعمالك المفضلة في مجموعات — «أفضل ما قرأت»، «للعطلة»، «أعيد قراءتها».',
      mood: InkSpiritMood.calm,
      icon: SardIcons.folder_copy_outlined,
      actionLabel: 'أنشئ مجموعتك الأولى',
      onAction: onCreate,
    );
  }
}

/// فراغ الأصدقاء: لا نشاط لأصدقائك بعد.
class AtelierEmptyFriends extends StatelessWidget {
  const AtelierEmptyFriends({super.key, this.onInvite});

  final VoidCallback? onInvite;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا أصدقاء بعد',
      subtitle: 'ادعُ أصدقاءك ليقرأوا معك — القراءة أجمل حين تشاركها.',
      mood: InkSpiritMood.curious,
      icon: SardIcons.groups_rounded,
      actionLabel: 'ادعُ صديقاً',
      onAction: onInvite,
    );
  }
}

// ──────────────────────────────────────────────────────────────────────────
//  حالات فراغ مصغّرة وداخلية
// ──────────────────────────────────────────────────────────────────────────

/// حالة فراغ مصغّرة داخل قائمة (بلا روح حبر كبيرة).
class AtelierEmptyInline extends StatelessWidget {
  const AtelierEmptyInline({
    super.key,
    required this.title,
    this.subtitle,
    this.icon,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? subtitle;
  final SIconData? icon;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: p.surfaceHi,
              shape: BoxShape.circle,
              border: Border.all(color: p.border),
            ),
            alignment: Alignment.center,
            child: SIcon(icon ?? SardIcons.menu_book_rounded, size: 24, color: p.textDim),
          ),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: AtelierType.subtitle(context, size: 15)),
          if (subtitle != null) ...[
            const SizedBox(height: 5),
            Text(subtitle!, textAlign: TextAlign.center, style: AtelierType.muted(context)),
          ],
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: 12),
            GestureDetector(
              onTap: onAction,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: AtelierDecor.pill(p.accent),
                child: Text(actionLabel!, style: AtelierType.caption(context, color: p.accent)),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// فراغ «لا فصول جديدة اليوم».
class AtelierEmptyToday extends StatelessWidget {
  const AtelierEmptyToday({super.key, this.onBrowse});

  final VoidCallback? onBrowse;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyInline(
      title: 'لا فصول جديدة اليوم',
      subtitle: 'تابع أعمالك وستصلك فصولها هنا فور صدورها.',
      icon: SardIcons.calendar_today_rounded,
      actionLabel: 'تصفّح الأعمال',
      onAction: onBrowse,
    );
  }
}

/// فراغ الإنجازات: لم تفتح إنجازاً بعد.
class AtelierEmptyAchievements extends StatelessWidget {
  const AtelierEmptyAchievements({super.key, this.onView});

  final VoidCallback? onView;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا إنجازات بعد',
      subtitle: 'اقرأ 5 فصول لفتح أول إنجاز — وهناك 16 إنجازاً بانتظارك.',
      mood: InkSpiritMood.excited,
      icon: SardIcons.star_rounded,
      actionLabel: 'عرض الإنجازات',
      onAction: onView,
    );
  }
}

/// شريط خطأ داخلي أنيق (يظهر أعلى قائمة بدل صفحة كاملة).
class AtelierErrorStrip extends StatelessWidget {
  const AtelierErrorStrip({
    super.key,
    required this.message,
    this.onRetry,
    this.onDismiss,
  });

  final String message;
  final VoidCallback? onRetry;
  final VoidCallback? onDismiss;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: AtelierDecor.seal(p, radius: 16),
      child: Row(
        children: [
          SIcon(SardIcons.info_outline_rounded, size: 20, color: p.accent),
          const SizedBox(width: 10),
          Expanded(
            child: Text(message, style: AtelierType.body(context, size: 13)),
          ),
          if (onRetry != null)
            GestureDetector(
              onTap: onRetry,
              child: Text('إعادة', style: AtelierType.caption(context, color: p.accent, size: 12.5)),
            ),
          if (onDismiss != null) ...[
            const SizedBox(width: 10),
            GestureDetector(
              onTap: onDismiss,
              child: SIcon(SardIcons.close_rounded, size: 16, color: p.textDim),
            ),
          ],
        ],
      ),
    );
  }
}

/// شريط «بلا اتصال» داخلي (يظهر أعلى الصفحة عند انقطاع الشبكة).
class AtelierOfflineStrip extends StatelessWidget {
  const AtelierOfflineStrip({super.key, this.onDownloads});

  final VoidCallback? onDownloads;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: tint(p.gold, 0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: tint(p.gold, 0.4)),
      ),
      child: Row(
        children: [
          SIcon(SardIcons.cloud_off_rounded, size: 18, color: p.gold),
          const SizedBox(width: 10),
          const Expanded(
            child: Text(
              'أنت بلا اتصال — تعرض نسخة محفوظة من مكتبتك.',
              style: TextStyle(
                fontFamily: sardBodyFont,
                fontSize: 13,
                fontWeight: FontWeight.w500,
                height: 1.5,
              ),
            ),
          ),
          if (onDownloads != null)
            GestureDetector(
              onTap: onDownloads,
              child: Text('التنزيلات', style: AtelierType.caption(context, color: p.gold, size: 12.5)),
            ),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────────────
//  حالات فراغ إضافية
// ──────────────────────────────────────────────────────────────────────────

/// فراغ الإشارات المرجعية: لا صفحات محفوظة.
class AtelierEmptyBookmarks extends StatelessWidget {
  const AtelierEmptyBookmarks({super.key, this.onRead});

  final VoidCallback? onRead;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا إشارات مرجعية',
      subtitle: 'احفظ صفحة أثناء القراءة لتعود إليها لاحقاً بنقرة واحدة.',
      mood: InkSpiritMood.calm,
      icon: SardIcons.bookmark_rounded,
      actionLabel: 'ابدأ القراءة',
      onAction: onRead,
    );
  }
}

/// فراغ المراجعات: لم تكتب مراجعة بعد.
class AtelierEmptyReviews extends StatelessWidget {
  const AtelierEmptyReviews({super.key, this.onWrite});

  final VoidCallback? onWrite;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لم تكتب مراجعة بعد',
      subtitle: 'رأيك يهمّ القرّاء الآخرين — قيّم عملاً قرأته وشارك انطباعك.',
      mood: InkSpiritMood.curious,
      icon: SardIcons.star_rounded,
      actionLabel: 'اكتب مراجعة',
      onAction: onWrite,
    );
  }
}

/// فراغ هدف القراءة اليومي: اكتمل اليوم!
class AtelierEmptyReadingGoal extends StatelessWidget {
  const AtelierEmptyReadingGoal({super.key, this.onBrowse});

  final VoidCallback? onBrowse;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'أنجزت هدف اليوم',
      subtitle: 'قرأت ما خططت له اليوم — استرح أو واصل إن شئت، فالحكاية لا تنتهي.',
      mood: InkSpiritMood.happy,
      icon: SardIcons.check_circle_rounded,
      actionLabel: 'تصفّح المزيد',
      onAction: onBrowse,
    );
  }
}

/// فراغ الدوائر: لم تنضم لدائرة قراءة بعد.
class AtelierEmptyCircles extends StatelessWidget {
  const AtelierEmptyCircles({super.key, this.onJoin});

  final VoidCallback? onJoin;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا دوائر بعد',
      subtitle: 'انضم لدائرة قراءة لمناقشة فصولك المفضلة مع قرّاء يشبهونك.',
      mood: InkSpiritMood.curious,
      icon: SardIcons.groups_outlined,
      actionLabel: 'استكشف الدوائر',
      onAction: onJoin,
    );
  }
}

/// فراغ التنبيهات: لم تفعّل تنبيهات بعد.
class AtelierEmptyReminders extends StatelessWidget {
  const AtelierEmptyReminders({super.key, this.onEnable});

  final VoidCallback? onEnable;

  @override
  Widget build(BuildContext context) {
    return AtelierEmptyState(
      title: 'لا تذكيرات مفعّلة',
      subtitle: 'فعّل تذكيراً يومياً بوقت قراءتك المفضل — لافتة لطيفة، بلا إزعاج.',
      mood: InkSpiritMood.sleepy,
      icon: SardIcons.notifications_none_rounded,
      actionLabel: 'تفعيل تذكير',
      onAction: onEnable,
    );
  }
}
