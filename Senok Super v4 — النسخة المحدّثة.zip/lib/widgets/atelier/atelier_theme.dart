import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../cover_art.dart';
import '../sard_icons.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// ثيم Atelier — هوية «Senok» بمستوى أرقى: حبر وختم، ورق عتيق، وذهب.
/// لوحات جديدة مبنية على [SardPalette] الحالي فيستعملها [buildTheme]
/// مباشرة دون أي ثيم منفصل، وكل مكوّنات Atelier تشتق ألوانها من اللوحة
/// النشطة عبر [BuildContext.pal] كما في بقية التطبيق.
///
/// ما يقدّمه هذا الملف:
///   • [AtelierPalette] — ألوان مشتقة (حبر، ورق، ذهب، ختم، ضباب، توهّج).
///   • [AtelierTone] — نغمات لونية للأقسام والبطاقات.
///   • [AtelierType] و[AtelierContext] — سلّم طباعي كامل (عرض، عنوان،
///     جسم، تسمية، اقتباس، أرقام كبيرة).
///   • [AtelierDecor] — زخارف جاهزة: بطاقة، بطل، ختم، إطار ذهبي، زجاج.
///   • [AtelierSpacing] — مقاسات ومسافات موحّدة.
///   • تحيات حسب الوقت وخطوط رفيق قواعديّة ([atelierGreeting]،
///     [atelierCompanionLine]).
///   • [AtelierHeading] و[AtelierRuler] و[AtelierDot] — مكوّنات صغيرة.
/// ──────────────────────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════
//  النغمات اللونية
// ═══════════════════════════════════════════════════════════════════════════

/// نغمة لونية لقسم أو بطاقة. كل نغمة لها لون أساسي ولون خافت ولون نص
/// فاتح يقرأ عليها، وتُشتق درجاتها من اللوحة النشطة حيث أمكن.
enum AtelierTone {
  /// حبر داكن دافئ — الافتراضي.
  ink('حبر', 0xFF2B2118, 0xFF6B5B49),

  /// ذهب — للتمييز والعروض.
  gold('ذهب', 0xFFC98A12, 0xFF8A5E0B),

  /// ختم قرمزي — للتنبيه والجديد.
  seal('ختم', 0xFFE63E2A, 0xFFB02A1A),

  /// يشب أخضر — للاكتمال والنجاح.
  jade('يشب', 0xFF0F9D75, 0xFF0B6E52),

  /// نيلي — للاكتشاف والتوصيات.
  indigo('نيلي', 0xFF5B5BEA, 0xFF3E3EB0),

  /// وردي — للرومانسية والمفضلة.
  rose('وردي', 0xFFE0457B, 0xFFB02A5C),

  /// بنفسجي ليلي — للغموض والرعب.
  violet('بنفسجي', 0xFF7C4DFF, 0xFF5A34C2),

  /// سماوي — للمغامرة والبحر.
  azure('سماوي', 0xFF1E9FC4, 0xFF14708F);

  const AtelierTone(this.label, this.base, this.deep);
  final String label;
  final int base;
  final int deep;

  Color get color => Color(base);
  Color get dark => Color(deep);

  /// تدرّج عمودي من [color] إلى [dark] (لبطاقات ملوّنة).
  LinearGradient get gradient => LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [color, dark],
      );

  /// تدرّج فاتح شفاف للخلفيات (لون بنسبة 14% ثم شفاف).
  LinearGradient softGradient({double opacity = 0.14}) => LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [color.withAlpha((opacity * 255).round()), color.withAlpha(0)],
      );

  /// نغمة مشتقة من تصنيفات العمل: رعب → بنفسجي، رومانسي → وردي،
  /// أكشن/مغامرة → سماوي، فانتازيا → نيلي، دراما → ذهب، وإلا حبر.
  static AtelierTone forGenres(List<String> genres) {
    final joined = genres.join(' ');
    if (joined.contains('رعب') || joined.contains('غموض')) return AtelierTone.violet;
    if (joined.contains('رومانس') || joined.contains('شوجو')) return AtelierTone.rose;
    if (joined.contains('أكشن') || joined.contains('مغامرة') || joined.contains('بحر')) {
      return AtelierTone.azure;
    }
    if (joined.contains('فانتازيا') || joined.contains('سحر') || joined.contains('خيال')) {
      return AtelierTone.indigo;
    }
    if (joined.contains('دراما') || joined.contains('تاريخي')) return AtelierTone.gold;
    if (joined.contains('كوميديا') || joined.contains('حياة')) return AtelierTone.jade;
    return AtelierTone.ink;
  }

  /// نغمة مشتقة من العمل نفسه عبر تصنيفاته.
  static AtelierTone forSeries(Series s) => forGenres(s.genres);
}

// ═══════════════════════════════════════════════════════════════════════════
//  اللوحة المشتقة
// ═══════════════════════════════════════════════════════════════════════════

/// ألوان Atelier المشتقة من [SardPalette] النشطة.
///
/// القاعدة: لا ألوان خامسة في المكوّنات؛ كل مكوّن Atelier يأخذ ألوانه
/// من هنا، فتتبدّل الهوية كاملةً بتبديل الثيم من الإعدادات.
@immutable
class AtelierPalette {
  const AtelierPalette({
    required this.ink,
    required this.paper,
    required this.paperHi,
    required this.gold,
    required this.goldDeep,
    required this.seal,
    required this.sealDeep,
    required this.mist,
    required this.line,
    required this.onInk,
    required this.onGold,
    required this.isDark,
  });

  /// لون الحبر (نصوص قوية / خلفية داكنة).
  final Color ink;

  /// لون الورق (خلفية فاتحة / سطح).
  final Color paper;

  /// ورق أفتح قليلاً (سطح مرتفع).
  final Color paperHi;

  /// ذهب التمييز.
  final Color gold;

  /// ذهب عميق (للنص الذهبي على الفاتح).
  final Color goldDeep;

  /// قرمزي الختم.
  final Color seal;

  /// قرمزي عميق.
  final Color sealDeep;

  /// ضباب (نص ثانوي خافت).
  final Color mist;

  /// لون الخطوط والحدود.
  final Color line;

  /// نص يقرأ على الحبر.
  final Color onInk;

  /// نص يقرأ على الذهب.
  final Color onGold;

  final bool isDark;

  /// يبني اللوحة من لوحة Senok النشطة.
  factory AtelierPalette.of(SardPalette p) {
    final goldDeep = Color.lerp(p.gold, const Color(0xFF7A5200), p.isDark ? 0.1 : 0.35)!;
    return AtelierPalette(
      ink: p.text,
      paper: p.surface,
      paperHi: p.surfaceHi,
      gold: p.gold,
      goldDeep: goldDeep,
      seal: p.accent,
      sealDeep: Color.lerp(p.accent, Colors.black, 0.25)!,
      mist: p.textDim,
      line: p.border,
      onInk: p.bg,
      onGold: p.isDark ? const Color(0xFF241A00) : const Color(0xFFFFFFFF),
      isDark: p.isDark,
    );
  }

  /// تدرّج ذهبي أفقي (لشريط علوي أو ختم).
  LinearGradient get goldGradient => LinearGradient(
        begin: Alignment.centerRight,
        end: Alignment.centerLeft,
        colors: [goldDeep, gold, const Color(0xFFF6D47C), gold],
        stops: const [0.0, 0.35, 0.65, 1.0],
      );

  /// تدرّج حبري عمودي (للبطل السينمائي).
  LinearGradient get inkGradient => LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [ink.withAlpha(0), ink.withAlpha(110), ink.withAlpha(215)],
        stops: const [0.0, 0.55, 1.0],
      );

  /// تدرّج ختم (قرمزي إلى عميق).
  LinearGradient get sealGradient => LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [seal, sealDeep],
      );

  /// لون ختم دائري بدرجة ذهبية خفيفة (لشارة «جديد»).
  Color get newBadge => seal;

  /// لون نجمة التقييم (ذهب اللوحة نفسه).
  Color get star => gold;

  /// ظل ذهبي ناعم حول العناصر المميزة.
  List<BoxShadow> goldGlow({double strength = 1}) => [
        BoxShadow(
          color: gold.withAlpha((38 * strength).round().clamp(0, 255)),
          blurRadius: 22 * strength,
          offset: const Offset(0, 8),
        ),
      ];

  /// ظل حبري ناعم للبطاقات.
  List<BoxShadow> softShadow({double strength = 1}) => softShadowFor(isDark, strength: strength);
}

/// ظل ناعم متعدد الطبقات يطابق [softShadow] في app_themes لكن بلا اعتماد
/// على اللوحة كاملةً (يُستعمل من رسّامين لا يملكون [SardPalette]).
List<BoxShadow> softShadowFor(bool isDark, {double strength = 1}) {
  final a = (isDark ? 0.30 : 0.06) * strength;
  return [
    BoxShadow(color: Colors.black.withAlpha((a * 255).round()), blurRadius: 24, offset: const Offset(0, 10)),
    BoxShadow(color: Colors.black.withAlpha((a * 0.45 * 255).round()), blurRadius: 4, offset: const Offset(0, 1)),
  ];
}

// ═══════════════════════════════════════════════════════════════════════════
//  المقاسات والمسافات
// ═══════════════════════════════════════════════════════════════════════════

/// مقاسات Atelier الموحّدة. كل الأقسام والبطاقات تستعمل هذه القيم
/// فتبدو الصفحة متناسقة مهما كثرت المكوّنات.
abstract final class AtelierSpacing {
  /// هامش الصفحة الجانبي.
  static const double page = 20;

  /// هامش ضيق (داخل بطاقة).
  static const double tight = 12;

  /// مسافة بين الأقسام.
  static const double section = 28;

  /// مسافة بين عناصر القسم الواحد.
  static const double item = 12;

  /// ارتفاع شريط البطل.
  static const double heroHeight = 300;

  /// عرض بطاقة العمل في الصف الأفقي.
  static const double posterWidth = 132;

  /// نسبة أبعاد الغلاف (عرض/ارتفاع).
  static const double posterAspect = 0.72;

  /// ارتفاع بطاقة الفصل.
  static const double chapterHeight = 92;

  /// نصف قطر البطاقة الكبيرة.
  static const double cardRadius = 24;

  /// نصف قطر البطاقة الصغيرة.
  static const double chipRadius = 14;

  /// ارتفاع شارة صغيرة.
  static const double badgeHeight = 24;
}

/// نصف قطر موحّد من اللوحة النشطة (يُحترم شكل الثيم المختار).
double atelierRadius(SardPalette p, [double factor = 1]) => p.r(factor);

// ═══════════════════════════════════════════════════════════════════════════
//  السلّم الطباعي
// ═══════════════════════════════════════════════════════════════════════════

/// السلّم الطباعي لـ Atelier.
///
/// الخطوط نفسها من [buildTheme]: Alexandria للعناوين والأرقام الكبيرة،
/// وTajawal للنصوص. هنا فقط المقاسات والأوزان والارتفاعات الموحّدة،
/// فلا يعود كل مكوّن يخترع مقاساً جديداً.
abstract final class AtelierType {
  /// عنوان عرض كبير (اسم التطبيق في البطل، أرقام الإحصاءات الكبيرة).
  static TextStyle display(BuildContext context, {Color? color, double size = 34}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardFont,
      fontFamilyFallback: const [sardBodyFont],
      fontSize: size,
      fontWeight: FontWeight.w800,
      letterSpacing: 0,
      height: 1.15,
      color: color ?? p.text,
    );
  }

  /// عنوان قسم أو بطاقة.
  static TextStyle title(BuildContext context, {Color? color, double size = 19}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardFont,
      fontFamilyFallback: const [sardBodyFont],
      fontSize: size,
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.25,
      color: color ?? p.text,
    );
  }

  /// عنوان فرعي (اسم عمل في بطاقة صغيرة، عنوان فصل).
  static TextStyle subtitle(BuildContext context, {Color? color, double size = 15}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardFont,
      fontFamilyFallback: const [sardBodyFont],
      fontSize: size,
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.3,
      color: color ?? p.text,
    );
  }

  /// نص جسم عادي.
  static TextStyle body(BuildContext context, {Color? color, double size = 14, FontWeight? w}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardBodyFont,
      fontFamilyFallback: const [sardFont],
      fontSize: size * kBodyOptical,
      fontWeight: w ?? FontWeight.w400,
      letterSpacing: 0,
      height: 1.55,
      color: color ?? p.text,
    );
  }

  /// نص ثانوي خافت.
  static TextStyle muted(BuildContext context, {double size = 13, FontWeight? w}) {
    final p = context.pal;
    return body(context, color: p.textDim, size: size, w: w ?? FontWeight.w500);
  }

  /// تسمية صغيرة (فوق بطاقة، شارة، تاريخ).
  static TextStyle caption(BuildContext context, {Color? color, double size = 12}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardBodyFont,
      fontFamilyFallback: const [sardFont],
      fontSize: size * kBodyOptical,
      fontWeight: FontWeight.w600,
      letterSpacing: 0,
      height: 1.4,
      color: color ?? p.textDim,
    );
  }

  /// تسمية علوية بأحرف متباعدة قليلاً (عناوين الأقسام الصغيرة).
  static TextStyle overline(BuildContext context, {Color? color, double size = 11}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardFont,
      fontFamilyFallback: const [sardBodyFont],
      fontSize: size,
      fontWeight: FontWeight.w800,
      letterSpacing: 0.4,
      height: 1.4,
      color: color ?? p.textDim,
    );
  }

  /// اقتباس بخط عنوان مائل الهوية (لحكمة اليوم، كلام الرفيق).
  static TextStyle quote(BuildContext context, {Color? color, double size = 16}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardFont,
      fontFamilyFallback: const [sardBodyFont],
      fontSize: size,
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.7,
      color: color ?? p.text,
    );
  }

  /// رقم كبير (إحصاءات: فصول مقروءة، دقائق، سلسلة أيام).
  static TextStyle numeral(BuildContext context, {Color? color, double size = 30}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardFont,
      fontFamilyFallback: const [sardBodyFont],
      fontSize: size,
      fontWeight: FontWeight.w800,
      letterSpacing: 0,
      height: 1.05,
      color: color ?? p.text,
    );
  }

  /// زر نصي (تسمية زر).
  static TextStyle button(BuildContext context, {Color? color, double size = 14}) {
    final p = context.pal;
    return TextStyle(
      fontFamily: sardBodyFont,
      fontFamilyFallback: const [sardFont],
      fontSize: size * kBodyOptical,
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.3,
      color: color ?? p.onAccent,
    );
  }
}

/// اختصارات طباعية على [BuildContext] — تستعملها كل مكوّنات Atelier
/// بدل استدعاء [AtelierType] المطوّل.
///
/// مثال: `Text('مرحباً', style: context.atelierTitle)`.
extension AtelierContext on BuildContext {
  /// عنوان عرض كبير.
  TextStyle get atelierDisplay => AtelierType.display(this);

  /// عنوان قسم أو بطاقة.
  TextStyle get atelierTitle => AtelierType.title(this);

  /// عنوان فرعي.
  TextStyle get atelierSubtitle => AtelierType.subtitle(this);

  /// نص جسم عادي.
  TextStyle get atelierBody => AtelierType.body(this);

  /// نص ثانوي خافت.
  TextStyle get atelierMuted => AtelierType.muted(this);

  /// تسمية صغيرة.
  TextStyle get atelierCaption => AtelierType.caption(this);

  /// تسمية علوية.
  TextStyle get atelierOverline => AtelierType.overline(this);

  /// اقتباس.
  TextStyle get atelierQuote => AtelierType.quote(this);

  /// رقم كبير.
  TextStyle get atelierNumeral => AtelierType.numeral(this);

  /// زر نصي.
  TextStyle get atelierButton => AtelierType.button(this);

  /// لوحة Atelier المشتقة من الثيم النشط.
  AtelierPalette get atelier => AtelierPalette.of(pal);

  /// لون مميّز ثابت لكل عمل (يطابق ألوان غلافه المولَّد).
  Color atelierToneFor(Series s) => seriesTone(s);
}

// ═══════════════════════════════════════════════════════════════════════════
//  الزخارف الجاهزة
// ═══════════════════════════════════════════════════════════════════════════

/// زخارف Atelier الجاهزة: حدود وظلال وتدرّجات موحّدة.
///
/// كل دالة تأخذ [SardPalette] وتعيد [BoxDecoration] جاهزاً، فيبقى شكل
/// البطاقات متناسقاً عبر التطبيق كله.
abstract final class AtelierDecor {
  /// بطاقة عادية: سطح + حد رفيع + ظل ناعم.
  static BoxDecoration card(SardPalette p, {double radius = 24, Color? color}) {
    return BoxDecoration(
      color: color ?? p.surface,
      borderRadius: BorderRadius.circular(p.r(1).clamp(12.0, 28.0).toDouble() * (radius / 24)),
      border: Border.all(color: p.border, width: p.borderW),
      boxShadow: softShadow(p),
    );
  }

  /// بطاقة مرتفعة قليلاً (سطح أعلى وظل أقوى).
  static BoxDecoration cardHi(SardPalette p, {double radius = 24}) {
    return BoxDecoration(
      color: p.surfaceHi,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: p.border, width: p.borderW),
      boxShadow: softShadow(p, strength: 1.4),
    );
  }

  /// بطاقة زجاجية (للثيمات الزجاجية أو فوق صور).
  static BoxDecoration glass(SardPalette p, {double radius = 24, double opacity = 0.82}) {
    return BoxDecoration(
      color: tint(p.surface, opacity),
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: tint(Colors.white, p.isDark ? 0.14 : 0.5), width: 1),
      boxShadow: softShadow(p),
    );
  }

  /// بطاقة ذهبية (عرض، باقة، إنجاز): حد ذهبي + توهّج خفيف.
  static BoxDecoration gold(SardPalette p, {double radius = 24}) {
    return BoxDecoration(
      color: p.surface,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: tint(p.gold, 0.55), width: 1.4),
      boxShadow: [
        ...softShadow(p),
        BoxShadow(color: tint(p.gold, 0.16), blurRadius: 20, offset: const Offset(0, 6)),
      ],
    );
  }

  /// بطاقة ختم (تنبيه، جديد): حد قرمزي خفيف + خلفية قرمزية شفافة.
  static BoxDecoration seal(SardPalette p, {double radius = 24}) {
    return BoxDecoration(
      color: tint(p.accent, 0.08),
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: tint(p.accent, 0.4), width: 1.2),
    );
  }

  /// بطاقة ملوّنة بالكامل بنغمة [tone] (لأقسام مميزة).
  static BoxDecoration toned(AtelierTone tone, {double radius = 24}) {
    return BoxDecoration(
      gradient: tone.gradient,
      borderRadius: BorderRadius.circular(radius),
      boxShadow: [
        BoxShadow(color: tone.color.withAlpha(70), blurRadius: 20, offset: const Offset(0, 8)),
      ],
    );
  }

  /// خلفية بطل: تدرّج حبري فوق صورة (لقراءة النص فوق الغلاف).
  static BoxDecoration heroScrim(SardPalette p) {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Colors.black.withAlpha(0),
          Colors.black.withAlpha(90),
          Colors.black.withAlpha(205),
        ],
        stops: const [0.35, 0.68, 1.0],
      ),
    );
  }

  /// شارة صغيرة مستديرة (جديد، حصري، مكتمل).
  static BoxDecoration badge(Color color, {double radius = 999}) {
    return BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(radius),
      boxShadow: [
        BoxShadow(color: color.withAlpha(80), blurRadius: 8, offset: const Offset(0, 3)),
      ],
    );
  }

  /// حبّة إحصائية (خلفية شفافة ملوّنة).
  static BoxDecoration pill(Color color, {double opacity = 0.12}) {
    return BoxDecoration(
      color: color.withAlpha((opacity * 255).round()),
      borderRadius: BorderRadius.circular(999),
    );
  }

  /// إطار ذهبي مزدوج (لغلاف مميز أو صورة رفيق).
  static BoxDecoration doubleGoldFrame(SardPalette p, {double radius = 20}) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: tint(p.gold, 0.7), width: 1.4),
      boxShadow: [
        BoxShadow(color: tint(p.gold, 0.12), blurRadius: 16, offset: const Offset(0, 4)),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  التحيات والرفيق
// ═══════════════════════════════════════════════════════════════════════════

/// جزء اليوم (يحدد التحية ولونها ومزاج الرفيق).
enum AtelierDayPart {
  dawn('فجر', 'فجر هادئ'),
  morning('صباح', 'صباح الخير'),
  noon('ظهر', 'نهارك سعيد'),
  afternoon('عصر', 'مساء الخير'),
  evening('مساء', 'مساء الخير'),
  night('ليل', 'ليلة سعيدة');

  const AtelierDayPart(this.key, this.greeting);
  final String key;
  final String greeting;

  /// يحدد جزء اليوم من الساعة (قواعدي بحت).
  static AtelierDayPart of(DateTime now) {
    final h = now.hour;
    if (h >= 5 && h < 8) return AtelierDayPart.dawn;
    if (h >= 8 && h < 12) return AtelierDayPart.morning;
    if (h >= 12 && h < 15) return AtelierDayPart.noon;
    if (h >= 15 && h < 18) return AtelierDayPart.afternoon;
    if (h >= 18 && h < 22) return AtelierDayPart.evening;
    return AtelierDayPart.night;
  }

  /// أيقونة مقترحة لجزء اليوم (من SardIcons عبر SIcon في المكوّنات).
  String get iconId {
    switch (this) {
      case AtelierDayPart.dawn:
        return 'wb_sunny';
      case AtelierDayPart.morning:
        return 'wb_sunny';
      case AtelierDayPart.noon:
        return 'wb_sunny';
      case AtelierDayPart.afternoon:
        return 'wb_sunny';
      case AtelierDayPart.evening:
        return 'nightlight';
      case AtelierDayPart.night:
        return 'bedtime';
    }
  }
}

/// تحية حسب الوقت: «صباح الخير» في الصباح، «مساء الخير» في المساء…
String atelierGreeting([DateTime? now]) => AtelierDayPart.of(now ?? DateTime.now()).greeting;

/// تحية كاملة مع الاسم: «صباح الخير، محمد».
String atelierGreetingWithName(String name, [DateTime? now]) {
  final g = atelierGreeting(now);
  final n = name.trim();
  return n.isEmpty ? g : '$g، $n';
}

/// سطر قواعدي من الرفيق «حبّار» حسب السياق.
///
/// القواعد: ليلاً يذكّر بالنوم، سلسلة أيام عالية تهنّئ، بلا قراءة
/// اليوم يشجّع، فصل جديد في المتابَعات يخبّر عنه، وإلا سطر عام.
/// الاختيار حتمي (نفس المدخلات تعطي نفس السطر دائماً).
String atelierCompanionLine({
  required String name,
  required int streak,
  required int chaptersToday,
  required int newChapters,
  DateTime? now,
}) {
  final part = AtelierDayPart.of(now ?? DateTime.now());
  if (part == AtelierDayPart.night && chaptersToday == 0) {
    return 'الليل للراحة يا $name… لكن فصلاً واحداً قبل النوم لن يضرّ.';
  }
  if (streak >= 30) return 'ثلاثون يوماً متتالية! أنت أسطورة القراءة يا $name.';
  if (streak >= 14) return 'أسبوعان بلا انقطاع — سلسلتك تشتعل يا $name.';
  if (streak >= 7) return 'أسبوع كامل من القراءة! لا تكسر السلسلة يا $name.';
  if (streak >= 3) return '$streak أيام متتالية… الحكاية تنتظرك.';
  if (newChapters > 0) return 'وصلت $newChapters فصول جديدة من أعمالك المتابَعة!';
  if (chaptersToday == 0) return 'لم تقرأ بعد اليوم… أشمّ رائحة فصل جديد ينتظرك.';
  if (chaptersToday == 1) return 'فصل واحد اليوم — بداية جميلة، واصل.';
  if (chaptersToday >= 5) return '$chaptersToday فصول اليوم! أنت في حالة تدفّق نادرة.';
  return 'يومك جميل يا $name، والحكايات تنتظرك.';
}

/// حكمة قصيرة تُعرض تحت التحية (تتبدل حسب اليوم — قواعدي بحت).
String atelierDailyWisdom([DateTime? now]) {
  const wisdoms = [
    'كل فصل تقرؤه باب جديد تفتحه.',
    'الحكاية الجيدة لا تنتهي؛ بل تسكنك.',
    'اقرأ فصلاً واحداً… والباقي يأتي وحده.',
    'الأبطال لا يولدون في الصفحة الأولى.',
    'بين سطور المانهوا يختبئ عالم كامل.',
    'القراءة رحلة لا تحتاج تذكرة.',
    'اليوم فصل جديد من حكايتك أنت.',
  ];
  final d = now ?? DateTime.now();
  final day = DateTime(d.year, d.month, d.day);
  return wisdoms[day.millisecondsSinceEpoch ~/ 86400000 % wisdoms.length];
}

/// عنوان قسم ذهبي صغير فوق العنوان الرئيسي (مثل «مختارات لك»).
String atelierSectionKicker(String section) => section;

// ═══════════════════════════════════════════════════════════════════════════
//  مكوّنات صغيرة مشتركة
// ═══════════════════════════════════════════════════════════════════════════

/// عنوان قسم Atelier: تسمية علوية صغيرة + عنوان كبير + وصف اختياري
/// + زر إجراء نصي على الطرف.
class AtelierHeading extends StatelessWidget {
  const AtelierHeading({
    super.key,
    required this.title,
    this.kicker,
    this.subtitle,
    this.actionLabel,
    this.onAction,
    this.titleSize = 19,
  });

  final String title;
  final String? kicker;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;
  final double titleSize;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(AtelierSpacing.page, 0, AtelierSpacing.page, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (kicker != null && kicker!.isNotEmpty) ...[
            Text(kicker!, style: AtelierType.overline(context, color: p.gold)),
            const SizedBox(height: 4),
          ],
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(title, style: AtelierType.title(context, size: titleSize)),
              ),
              if (actionLabel != null && onAction != null)
                GestureDetector(
                  onTap: onAction,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(actionLabel!, style: AtelierType.caption(context, color: p.accent)),
                        const SizedBox(width: 2),
                        SIcon(SardIcons.chevron_left_rounded, size: 16, color: p.accent),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          if (subtitle != null && subtitle!.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(subtitle!, style: AtelierType.muted(context)),
          ],
        ],
      ),
    );
  }
}

/// خط فاصل ذهبي رفيع مع نقطة وسطية (يفصل بين أقسام الصفحة).
class AtelierRuler extends StatelessWidget {
  const AtelierRuler({super.key, this.withSeal = true, this.margin = 24});

  final bool withSeal;
  final double margin;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: AtelierSpacing.page, vertical: margin),
      child: Row(
        children: [
          Expanded(child: Container(height: 1, color: p.border)),
          if (withSeal) ...[
            const SizedBox(width: 10),
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: tint(p.gold, 0.7), width: 1.2),
                color: tint(p.gold, 0.1),
              ),
              alignment: Alignment.center,
              child: Text(
                'س',
                style: TextStyle(
                  fontFamily: sardFont,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: p.gold,
                  height: 1,
                ),
              ),
            ),
            const SizedBox(width: 10),
          ],
          Expanded(child: Container(height: 1, color: p.border)),
        ],
      ),
    );
  }
}

/// نقطة فاصلة صغيرة بين عناصر سطر واحد (مثل «•» ملوّنة).
class AtelierDot extends StatelessWidget {
  const AtelierDot({super.key, this.color, this.size = 4});

  final Color? color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color ?? context.pal.textDim,
      ),
    );
  }
}

/// ختم دائري صغير بحرف (ختم الخطّاط) — يُستعمل كشارة أو علامة قسم.
class AtelierSealStamp extends StatelessWidget {
  const AtelierSealStamp({
    super.key,
    this.letter = 'س',
    this.size = 34,
    this.tone = AtelierTone.seal,
    this.onTap,
  });

  final String letter;
  final double size;
  final AtelierTone tone;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final stamp = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: tone.gradient,
        border: Border.all(color: Colors.white.withAlpha(70), width: 1),
        boxShadow: [
          BoxShadow(color: tone.color.withAlpha(60), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      alignment: Alignment.center,
      child: Text(
        letter,
        style: TextStyle(
          fontFamily: sardFont,
          fontSize: size * 0.44,
          fontWeight: FontWeight.w800,
          color: Colors.white,
          height: 1,
        ),
      ),
    );
    if (onTap == null) return stamp;
    return GestureDetector(onTap: onTap, child: stamp);
  }
}

/// شارة ذهبية صغيرة (مثل «حصري» أو «الأكثر قراءة»).
class AtelierGoldBadge extends StatelessWidget {
  const AtelierGoldBadge({super.key, required this.label, this.iconId});

  final String label;
  final String? iconId;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      height: AtelierSpacing.badgeHeight,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: AtelierDecor.badge(p.gold),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (iconId == 'star') ...[
            const SIcon(SardIcons.star_rounded, size: 12, color: Colors.white),
            const SizedBox(width: 3),
          ] else if (iconId == 'fire') ...[
            const SIcon(SardIcons.local_fire_department_rounded, size: 12, color: Colors.white),
            const SizedBox(width: 3),
          ],
          Text(
            label,
            style: AtelierType.caption(context, color: Colors.white, size: 11),
          ),
        ],
      ),
    );
  }
}

/// عدّاد تنازلي نصي: «يتبقى 3 أيام» أو «انتهى».
String atelierCountdownLabel(DateTime? deadline, [DateTime? now]) {
  if (deadline == null) return 'بلا موعد';
  final diff = deadline.difference(now ?? DateTime.now());
  if (diff.isNegative) return 'انتهى';
  if (diff.inDays >= 1) return 'يتبقى ${diff.inDays} ${diff.inDays == 1 ? 'يوم' : 'أيام'}';
  if (diff.inHours >= 1) return 'يتبقى ${diff.inHours} ${diff.inHours == 1 ? 'ساعة' : 'ساعات'}';
  return 'يتبقى ${diff.inMinutes} دقيقة';
}

/// نسبة تقدّم بصيغة عربية: 0.42 → «42%».
String atelierPercent(double fraction) => '${(fraction.clamp(0.0, 1.0) * 100).round()}%';

/// رقم عربي مختصر للمشاهدات (يستعمل [formatCount]).
String atelierViewsLabel(int views) => '${formatCount(views)} مشاهدة';

/// تقييم بصيغة «4.8» مع نجمة.
String atelierRatingLabel(double rating) => rating.toStringAsFixed(1);

/// عدد فصول بصيغة عربية: «128 فصلاً».
String atelierChaptersLabel(int chapters) {
  if (chapters == 0) return 'بلا فصول بعد';
  if (chapters == 1) return 'فصل واحد';
  if (chapters == 2) return 'فصلان';
  if (chapters <= 10) return '$chapters فصول';
  return '$chapters فصلاً';
}

/// سنة العمل مع نوعه: «مانهوا كورية · 2024».
String atelierMetaLabel(Series s) => '${s.type} · ${s.year}';

/// حالة العمل بلونها: مستمر → ذهب، مكتمل → يشب، متوقف → ختم.
AtelierTone atelierStatusTone(String status) {
  if (status.contains('مكتمل')) return AtelierTone.jade;
  if (status.contains('متوقف') || status.contains('ملغ')) return AtelierTone.seal;
  return AtelierTone.gold;
}

/// يولّد بذرة حتمية من نص (لاختيار لون/شكل ثابت لكل عمل).
int atelierSeedOf(String id) => id.codeUnits.fold<int>(7, (a, b) => a * 31 + b) & 0x7fffffff;

/// زاوية دوران خفيفة حتمية لعنصر (لإحساس يدوي غير متكلف).
double atelierTiltOf(String id) {
  final seed = atelierSeedOf(id);
  return ((seed % 7) - 3) * 0.35 * math.pi / 180;
}

/// قائمة تصنيفات مختصرة للعرض (أول 3 فقط).
List<String> atelierTopGenres(Series s, [int max = 3]) => s.genres.take(max).toList();

// ═══════════════════════════════════════════════════════════════════════════
//  شارات ورقائق وصور رمزية ونص متدرج
// ═══════════════════════════════════════════════════════════════════════════

/// رقاقة (Chip) Atelier: نص + أيقونة اختيارية + لون نغمة + حالة مختارة.
class AtelierChip extends StatelessWidget {
  const AtelierChip({
    super.key,
    required this.label,
    this.icon,
    this.tone = AtelierTone.ink,
    this.selected = false,
    this.onTap,
  });

  final String label;
  final SIconData? icon;
  final AtelierTone tone;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final bg = selected ? tone.color : p.surface;
    final fg = selected ? Colors.white : p.text;
    final border = selected ? tone.color : p.border;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: border, width: selected ? 1.4 : p.borderW),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              SIcon(icon!, size: 15, color: selected ? Colors.white : tone.color),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                fontFamily: sardBodyFont,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: fg,
                height: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// صورة رمزية دائرية بحرف (لملف قارئ أو رفيق).
class AtelierAvatar extends StatelessWidget {
  const AtelierAvatar({
    super.key,
    required this.name,
    this.size = 48,
    this.tone,
    this.imageUrl,
  });

  final String name;
  final double size;
  final AtelierTone? tone;
  final String? imageUrl;

  @override
  Widget build(BuildContext context) {
    final t = tone ?? AtelierTone.values[(atelierSeedOf(name) % AtelierTone.values.length)];
    final letter = name.trim().isEmpty ? '؟' : name.trim().substring(0, 1);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: t.gradient,
        border: Border.all(color: Colors.white.withAlpha(90), width: 1.5),
        boxShadow: [
          BoxShadow(color: t.color.withAlpha(60), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      alignment: Alignment.center,
      child: imageUrl == null || imageUrl!.isEmpty
          ? Text(
              letter,
              style: TextStyle(
                fontFamily: sardFont,
                fontSize: size * 0.42,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                height: 1,
              ),
            )
          : ClipOval(
              child: Image.network(
                imageUrl!,
                width: size,
                height: size,
                fit: BoxFit.cover,
                errorBuilder: (context, _, __) => Text(
                  letter,
                  style: TextStyle(
                    fontFamily: sardFont,
                    fontSize: size * 0.42,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    height: 1,
                  ),
                ),
              ),
            ),
    );
  }
}

/// صف شارات صغير (حالة + تصنيف + سنة).
class AtelierBadgeRow extends StatelessWidget {
  const AtelierBadgeRow({super.key, required this.series});

  final Series series;

  @override
  Widget build(BuildContext context) {
    final tone = atelierStatusTone(series.status);
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        _Badge(label: series.status, color: tone.color),
        _Badge(label: series.type, color: context.pal.textDim),
        _Badge(label: '${series.year}', color: context.pal.textDim),
        if (series.isNew) _Badge(label: 'جديد', color: AtelierTone.seal.color),
        for (final g in atelierTopGenres(series, 2)) _Badge(label: g, color: context.pal.gold),
      ],
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.label, required this.color});
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: color.withAlpha(24),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withAlpha(70)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontFamily: sardBodyFont,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
          height: 1.2,
        ),
      ),
    );
  }
}

/// نص بتدرّج ذهبي (لعناوين احتفالية).
class AtelierGradientText extends StatelessWidget {
  const AtelierGradientText({
    super.key,
    required this.text,
    this.style,
    this.colors,
  });

  final String text;
  final TextStyle? style;
  final List<Color>? colors;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final base = style ?? AtelierType.display(context);
    final gradient = LinearGradient(
      colors: colors ?? [p.gold, const Color(0xFFF6D47C), p.gold],
    );
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (bounds) => gradient.createShader(
        Rect.fromLTWH(0, 0, bounds.width, bounds.height),
      ),
      child: Text(text, style: base.copyWith(color: Colors.white)),
    );
  }
}

/// «منذ» عربية: «منذ 3 ساعات»، «أمس»، «منذ أسبوع».
String atelierTimeAgo(DateTime date, [DateTime? now]) {
  final diff = (now ?? DateTime.now()).difference(date);
  if (diff.inSeconds < 60) return 'الآن';
  if (diff.inMinutes < 60) {
    final m = diff.inMinutes;
    return 'منذ $m ${m == 1 ? 'دقيقة' : m == 2 ? 'دقيقتين' : 'دقائق'}';
  }
  if (diff.inHours < 24) {
    final h = diff.inHours;
    return 'منذ $h ${h == 1 ? 'ساعة' : h == 2 ? 'ساعتين' : 'ساعات'}';
  }
  if (diff.inDays == 1) return 'أمس';
  if (diff.inDays < 7) {
    final d = diff.inDays;
    return 'منذ $d ${d == 2 ? 'يومين' : 'أيام'}';
  }
  if (diff.inDays < 30) {
    final w = diff.inDays ~/ 7;
    return 'منذ $w ${w == 1 ? 'أسبوع' : 'أسابيع'}';
  }
  final mo = diff.inDays ~/ 30;
  return 'منذ $mo ${mo == 1 ? 'شهر' : 'أشهر'}';
}

/// صيغة عربية لعدد الفصول: 1 → «فصل»، 2 → «فصلان»، 3-10 → «فصول»،
/// 11+ → «فصلاً».
String atelierPluralChapters(int n) {
  if (n == 0) return 'لا فصول';
  if (n == 1) return 'فصل واحد';
  if (n == 2) return 'فصلان';
  if (n <= 10) return '$n فصول';
  return '$n فصلاً';
}

/// صيغة عربية لعدد الأعمال.
String atelierPluralSeries(int n) {
  if (n == 0) return 'لا أعمال';
  if (n == 1) return 'عمل واحد';
  if (n == 2) return 'عملان';
  if (n <= 10) return '$n أعمال';
  return '$n عملاً';
}

/// صيغة عربية لعدد الدقائق: «45 دقيقة»، «ساعتان»، «3 ساعات».
String atelierPluralMinutes(int minutes) {
  if (minutes <= 0) return 'أقل من دقيقة';
  if (minutes < 60) return '$minutes دقيقة';
  final h = minutes ~/ 60;
  final m = minutes % 60;
  final hLabel = h == 1 ? 'ساعة' : h == 2 ? 'ساعتان' : '$h ساعات';
  if (m == 0) return hLabel;
  return '$hLabel و$m دقيقة';
}

/// تاريخ عربي مختصر: «26 نوفمبر 2026».
String atelierDateLabel(DateTime d) {
  const months = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];
  return '${d.day} ${months[d.month - 1]} ${d.year}';
}

/// يوم الأسبوع عربياً: «الاثنين».
String atelierWeekdayLabel(DateTime d) {
  const days = [
    'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد',
  ];
  return days[d.weekday - 1];
}

/// عنوان قسم ذهبي صغير مع خط جانبي.
class AtelierKicker extends StatelessWidget {
  const AtelierKicker({super.key, required this.label, this.color});

  final String label;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = color ?? p.gold;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 18, height: 2, color: c),
        const SizedBox(width: 8),
        Text(label, style: AtelierType.overline(context, color: c)),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  معاينة الثيم
// ═══════════════════════════════════════════════════════════════════════════

/// صف معاينة ثيم: دائرة ملوّنة + اسم الثيم + علامة الاختيار.
///
/// يُستعمل في منتقي الثيمات (الإعدادات) لعرض لوحات Atelier.
class AtelierThemePreview extends StatelessWidget {
  const AtelierThemePreview({
    super.key,
    required this.palette,
    this.selected = false,
    this.onTap,
  });

  final SardPalette palette;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: palette.bg,
                  border: Border.all(
                    color: selected ? palette.accent : palette.border,
                    width: selected ? 2.4 : 1.2,
                  ),
                  boxShadow: selected
                      ? [BoxShadow(color: tint(palette.accent, 0.35), blurRadius: 14, offset: const Offset(0, 5))]
                      : null,
                ),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: palette.accent)),
                      const SizedBox(width: 4),
                      Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: palette.gold)),
                      const SizedBox(width: 4),
                      Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: palette.surfaceHi)),
                    ],
                  ),
                ),
              ),
              if (selected)
                Positioned(
                  left: -2,
                  bottom: -2,
                  child: Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: palette.accent,
                      border: Border.all(color: p.surface, width: 2),
                    ),
                    alignment: Alignment.center,
                    child: const SIcon(SardIcons.check_rounded, size: 12, color: Colors.white),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: 72,
            child: Text(
              palette.name,
              textAlign: TextAlign.center,
              style: AtelierType.caption(context, color: selected ? p.text : p.textDim, size: 11.5),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (palette.tag.isNotEmpty)
            Text(
              palette.tag,
              style: AtelierType.caption(context, size: 10),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ),
    );
  }
}

/// صف أفقي لمعاينات كل الثيمات المتاحة.
class AtelierThemePreviewRow extends StatelessWidget {
  const AtelierThemePreviewRow({
    super.key,
    required this.selectedId,
    this.onSelect,
  });

  final String selectedId;
  final ValueChanged<String>? onSelect;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 108,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        itemCount: SardThemes.all.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (context, i) {
          final theme = SardThemes.all[i];
          return AtelierThemePreview(
            palette: theme,
            selected: theme.id == selectedId,
            onTap: onSelect == null ? null : () => onSelect!(theme.id),
          );
        },
      ),
    );
  }
}
