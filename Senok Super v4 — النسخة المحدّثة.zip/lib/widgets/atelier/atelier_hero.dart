import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../cover_art.dart';
import '../sard_icons.dart';
import 'atelier_cards.dart';
import 'atelier_motion.dart';
import 'atelier_theme.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// قسم البطل السينمائي — شرائح كبيرة بغلاف العمل، عنوان، وصف قصير،
/// أزرار «اقرأ الآن» و«تابع»، ونقاط تنقّل.
///
/// السلوك:
///   • تقدّم تلقائي كل 6 ثوانٍ، ويتوقف مؤقتاً عندما يغادر التطبيق
///     الواجهة (AppLifecycleState) أو عند لمس المستخدم للشرائح.
///   • تحميل مسبق لأغلفة الشرائح المجاورة (precache) لتفادي الوميض.
///   • يحترم «تقليل الحركة»: بلا تقدّم تلقائي وبلا Parallax.
/// ──────────────────────────────────────────────────────────────────────────

/// عنصر بطل واحد: عمل + سطر تسويقي + شارة + زر.
@immutable
class AtelierHeroItem {
  const AtelierHeroItem({
    required this.series,
    this.tagline = '',
    this.badge = '',
    this.ctaLabel = 'اقرأ الآن',
    this.secondaryLabel = 'تابع لاحقاً',
  });

  final Series series;
  final String tagline;
  final String badge;
  final String ctaLabel;
  final String secondaryLabel;

  /// يبني عناصر بطل من قائمة أعمال: الأول شارة «الأكثر قراءة»،
  /// والثاني «جديد»، والباقي بلا شارة (قواعدي بحت).
  static List<AtelierHeroItem> fromFeatured(List<Series> featured) {
    final items = <AtelierHeroItem>[];
    for (var i = 0; i < featured.length; i++) {
      final s = featured[i];
      final tagline = s.synopsis.isEmpty
          ? (s.genres.isEmpty ? 'حكاية تستحق القراءة.' : 'حكاية ${s.genres.first} لا تُنسى.')
          : (s.synopsis.length > 90 ? '${s.synopsis.substring(0, 90)}…' : s.synopsis);
      items.add(AtelierHeroItem(
        series: s,
        tagline: tagline,
        badge: i == 0
            ? 'الأكثر قراءة'
            : (s.isNew ? 'جديد' : (s.ongoing ? 'مستمر' : 'مكتمل')),
      ));
    }
    return items;
  }
}

/// قسم البطل الكامل (دائري تلقائي + نقاط + محتوى).
class AtelierHeroSection extends StatefulWidget {
  const AtelierHeroSection({
    super.key,
    required this.items,
    this.height = 380,
    this.autoPlay = true,
    this.autoPlayInterval = const Duration(seconds: 6),
    this.onOpen,
    this.onFollow,
    this.scrollController,
  });

  final List<AtelierHeroItem> items;
  final double height;
  final bool autoPlay;
  final Duration autoPlayInterval;
  final void Function(Series)? onOpen;
  final void Function(Series)? onFollow;
  final ScrollController? scrollController;

  @override
  State<AtelierHeroSection> createState() => _AtelierHeroSectionState();
}

class _AtelierHeroSectionState extends State<AtelierHeroSection> with WidgetsBindingObserver {
  late final PageController _page;
  Timer? _timer;
  int _index = 0;
  bool _userHolding = false;
  bool _appActive = true;

  @override
  void initState() {
    super.initState();
    _page = PageController();
    WidgetsBinding.instance.addObserver(this);
    _precacheAround(0);
    _startAutoPlay();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final active = state == AppLifecycleState.resumed;
    if (active == _appActive) return;
    _appActive = active;
    if (active) {
      _startAutoPlay();
    } else {
      _timer?.cancel();
      _timer = null;
    }
  }

  void _startAutoPlay() {
    _timer?.cancel();
    if (!widget.autoPlay || widget.items.length < 2) return;
    if (atelierReducedMotion(context)) return;
    _timer = Timer.periodic(widget.autoPlayInterval, (_) {
      if (!mounted || !_appActive || _userHolding) return;
      final next = (_index + 1) % widget.items.length;
      _page.animateToPage(
        next,
        duration: const Duration(milliseconds: 650),
        curve: Curves.easeOutCubic,
      );
    });
  }

  /// تحميل مسبق لغلاف الشريحة الحالية والمجاورتين.
  void _precacheAround(int index) {
    if (widget.items.isEmpty) return;
    final urls = <String>{};
    for (var d = -1; d <= 1; d++) {
      final s = widget.items[(index + d) % widget.items.length].series;
      if (s.cover != null && s.cover!.isNotEmpty) urls.add(s.cover!);
    }
    for (final url in urls) {
      precacheImage(NetworkImage(url), context).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    _page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.items.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: widget.height,
      child: Stack(
        children: [
          Listener(
            onPointerDown: (_) => _userHolding = true,
            onPointerUp: (_) => _userHolding = false,
            onPointerCancel: (_) => _userHolding = false,
            child: PageView.builder(
              controller: _page,
              itemCount: widget.items.length,
              onPageChanged: (i) {
                setState(() => _index = i);
                _precacheAround(i);
              },
              itemBuilder: (context, i) => AtelierHeroSlide(
                item: widget.items[i],
                onOpen: widget.onOpen,
                onFollow: widget.onFollow,
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 16,
            child: Row(
              children: [
                const SizedBox(width: AtelierSpacing.page),
                AtelierCarouselDots(
                  count: widget.items.length,
                  index: _index,
                  onTap: (i) => _page.animateToPage(
                    i,
                    duration: const Duration(milliseconds: 450),
                    curve: Curves.easeOutCubic,
                  ),
                ),
                const Spacer(),
                Text(
                  '${_index + 1} / ${widget.items.length}',
                  style: AtelierType.caption(context, color: Colors.white.withAlpha(210)),
                ),
                const SizedBox(width: AtelierSpacing.page),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// شريحة بطل واحدة: غلاف يملأ المساحة + تدرّج حبري + محتوى.
class AtelierHeroSlide extends StatelessWidget {
  const AtelierHeroSlide({
    super.key,
    required this.item,
    this.onOpen,
    this.onFollow,
  });

  final AtelierHeroItem item;
  final void Function(Series)? onOpen;
  final void Function(Series)? onFollow;

  @override
  Widget build(BuildContext context) {
    final s = item.series;
    final tone = AtelierTone.forSeries(s);
    return Stack(
      fit: StackFit.expand,
      children: [
        Hero(
          tag: 'hero-${s.id}',
          child: CoverArt(series: s, radius: 0, showTitle: false),
        ),
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withAlpha(40),
                  Colors.black.withAlpha(60),
                  Colors.black.withAlpha(215),
                ],
                stops: const [0.0, 0.45, 1.0],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.centerRight,
                end: Alignment.centerLeft,
                colors: [
                  tone.color.withAlpha(46),
                  Colors.transparent,
                ],
                stops: const [0.0, 0.55],
              ),
            ),
          ),
        ),
        Positioned(
          left: AtelierSpacing.page,
          right: AtelierSpacing.page,
          bottom: 46,
          child: FadeSlide(
            onceKey: 'hero-slide-${s.id}',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (item.badge.isNotEmpty)
                      AtelierGoldBadge(label: item.badge, iconId: 'fire'),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(22),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white.withAlpha(50)),
                      ),
                      child: Text(
                        atelierMetaLabel(s),
                        style: AtelierType.caption(context, color: Colors.white, size: 11),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  s.title,
                  style: const TextStyle(
                    fontFamily: sardFont,
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    height: 1.25,
                    shadows: [Shadow(color: Colors.black54, blurRadius: 10, offset: Offset(0, 2))],
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Text(
                  item.tagline,
                  style: TextStyle(
                    fontFamily: sardBodyFont,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w500,
                    color: Colors.white.withAlpha(225),
                    height: 1.6,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 12),
                _HeroInfoRow(series: s),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _HeroCta(
                      label: item.ctaLabel,
                      icon: SardIcons.play_arrow_rounded,
                      filled: true,
                      onTap: onOpen == null ? null : () => onOpen!(s),
                    ),
                    const SizedBox(width: 10),
                    _HeroCta(
                      label: item.secondaryLabel,
                      icon: SardIcons.bookmark_rounded,
                      filled: false,
                      onTap: onFollow == null ? null : () => onFollow!(s),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// صف معلومات صغير في البطل: تقييم · مشاهدات · فصول.
class _HeroInfoRow extends StatelessWidget {
  const _HeroInfoRow({required this.series});
  final Series series;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _infoDot(context, SardIcons.star_rounded, atelierRatingLabel(series.rating)),
        const SizedBox(width: 12),
        _infoDot(context, SardIcons.visibility_rounded, formatCount(series.views)),
        const SizedBox(width: 12),
        _infoDot(context, SardIcons.menu_book_rounded, atelierChaptersLabel(series.chapters)),
        const SizedBox(width: 12),
        Text(
          series.status,
          style: AtelierType.caption(context, color: Colors.white.withAlpha(210)),
        ),
      ],
    );
  }

  Widget _infoDot(BuildContext context, SIconData icon, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SIcon(icon, size: 14, color: const Color(0xFFFFC94D)),
        const SizedBox(width: 4),
        Text(
          label,
          style: AtelierType.caption(context, color: Colors.white, size: 12),
        ),
      ],
    );
  }
}

/// زر دعوة في البطل (مملوء أبيض أو شفاف بإطار).
class _HeroCta extends StatelessWidget {
  const _HeroCta({required this.label, required this.icon, required this.filled, this.onTap});

  final String label;
  final SIconData icon;
  final bool filled;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final child = Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
      decoration: BoxDecoration(
        color: filled ? Colors.white : Colors.white.withAlpha(18),
        borderRadius: BorderRadius.circular(999),
        border: filled ? null : Border.all(color: Colors.white.withAlpha(90), width: 1.2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(icon, size: 17, color: filled ? const Color(0xFF1C1612) : Colors.white),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontFamily: sardBodyFont,
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
              color: filled ? const Color(0xFF1C1612) : Colors.white,
            ),
          ),
        ],
      ),
    );
    return AtelierPressable(onTap: onTap, child: child);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطل مدمج وبطل عرض وتركيز
// ═══════════════════════════════════════════════════════════════════════════

/// بطل مدمج: شريط عريض بصورة خلفية خفيفة + عنوان + زر واحد.
///
/// يُستعمل داخل الأقسام (مثلاً فوق «رائج هذا الأسبوع»).
class AtelierHeroCompact extends StatelessWidget {
  const AtelierHeroCompact({
    super.key,
    required this.series,
    required this.title,
    this.subtitle = '',
    this.actionLabel = 'تصفّح',
    this.onTap,
    this.height = 150,
  });

  final Series series;
  final String title;
  final String subtitle;
  final String actionLabel;
  final VoidCallback? onTap;
  final double height;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = AtelierTone.forSeries(series);
    return AtelierPressable(
      onTap: onTap,
      child: Container(
        height: height,
        margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          boxShadow: softShadow(p),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              CoverArt(series: series, radius: 0, showTitle: false),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [
                        Colors.black.withAlpha(215),
                        tone.color.withAlpha(70),
                        Colors.black.withAlpha(30),
                      ],
                      stops: const [0.0, 0.55, 1.0],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontFamily: sardFont,
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (subtitle.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontFamily: sardBodyFont,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w500,
                          color: Colors.white.withAlpha(220),
                          height: 1.5,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SIcon(SardIcons.explore_rounded, size: 14, color: tone.dark),
                          const SizedBox(width: 5),
                          Text(
                            actionLabel,
                            style: TextStyle(
                              fontFamily: sardBodyFont,
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                              color: tone.dark,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// بطل عرض مع عدّاد تنازلي: «ينتهي العرض خلال 2 يوم».
class AtelierPromoHero extends StatefulWidget {
  const AtelierPromoHero({
    super.key,
    required this.title,
    required this.subtitle,
    this.deadline,
    this.actionLabel = 'استفد الآن',
    this.onTap,
    this.tone = AtelierTone.gold,
  });

  final String title;
  final String subtitle;
  final DateTime? deadline;
  final String actionLabel;
  final VoidCallback? onTap;
  final AtelierTone tone;

  @override
  State<AtelierPromoHero> createState() => _AtelierPromoHeroState();
}

class _AtelierPromoHeroState extends State<AtelierPromoHero> {
  Timer? _timer;
  String _label = '';

  @override
  void initState() {
    super.initState();
    _tick();
    _timer = Timer.periodic(const Duration(minutes: 1), (_) => _tick());
  }

  void _tick() {
    if (!mounted) return;
    setState(() => _label = atelierCountdownLabel(widget.deadline));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AtelierPressable(
      onTap: widget.onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        decoration: BoxDecoration(
          gradient: widget.tone.gradient,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(color: widget.tone.color.withAlpha(70), blurRadius: 22, offset: const Offset(0, 10)),
          ],
        ),
        child: Stack(
          children: [
            const Positioned.fill(child: AtelierGoldDust(count: 14)),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                              decoration: BoxDecoration(
                                color: Colors.white.withAlpha(26),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SIcon(SardIcons.watch_later_rounded, size: 12, color: Colors.white),
                                  const SizedBox(width: 4),
                                  Text(
                                    _label,
                                    style: const TextStyle(
                                      fontFamily: sardBodyFont,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          widget.title,
                          style: const TextStyle(
                            fontFamily: sardFont,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            height: 1.3,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 5),
                        Text(
                          widget.subtitle,
                          style: TextStyle(
                            fontFamily: sardBodyFont,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: Colors.white.withAlpha(225),
                            height: 1.55,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            widget.actionLabel,
                            style: TextStyle(
                              fontFamily: sardBodyFont,
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: widget.tone.dark,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  AtelierPaintedSeal(size: 64, color: Colors.white.withAlpha(230), letter: 'خ'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// بطاقة تركيز كبيرة: عمل واحد مع اقتباس من ملخصه وزرين.
class AtelierSpotlightCard extends StatelessWidget {
  const AtelierSpotlightCard({
    super.key,
    required this.series,
    this.quote = '',
    this.onOpen,
    this.onFollow,
  });

  final Series series;
  final String quote;
  final void Function(Series)? onOpen;
  final void Function(Series)? onFollow;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = AtelierTone.forSeries(series);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
      decoration: AtelierDecor.card(p, radius: 24),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 190,
            child: Stack(
              fit: StackFit.expand,
              children: [
                CoverArt(series: series, radius: 0, showTitle: false),
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withAlpha(150)],
                        stops: const [0.5, 1.0],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  right: 16,
                  bottom: 12,
                  child: AtelierGoldBadge(label: 'اختيار المحرر', iconId: 'star'),
                ),
                Positioned(
                  left: 16,
                  bottom: 12,
                  child: Text(
                    atelierMetaLabel(series),
                    style: AtelierType.caption(context, color: Colors.white, size: 11.5),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(series.title, style: AtelierType.title(context, size: 20)),
                const SizedBox(height: 6),
                if (quote.isNotEmpty) ...[
                  Text('«$quote»', style: AtelierType.quote(context, size: 14.5), maxLines: 3, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 10),
                ],
                Row(
                  children: [
                    _infoDot(context, SardIcons.star_rounded, atelierRatingLabel(series.rating)),
                    const SizedBox(width: 12),
                    _infoDot(context, SardIcons.visibility_rounded, formatCount(series.views)),
                    const SizedBox(width: 12),
                    _infoDot(context, SardIcons.menu_book_rounded, atelierChaptersLabel(series.chapters)),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: onOpen == null ? null : () => onOpen!(series),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [p.gold, Color.lerp(p.gold, Colors.white, 0.2)!]),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          alignment: Alignment.center,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const SIcon(SardIcons.play_arrow_rounded, size: 16, color: Colors.white),
                              const SizedBox(width: 6),
                              Text('ابدأ القراءة', style: AtelierType.button(context, color: Colors.white)),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: onFollow == null ? null : () => onFollow!(series),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: p.surfaceHi,
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: p.border),
                        ),
                        child: SIcon(SardIcons.bookmark_rounded, size: 19, color: tone.color),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoDot(BuildContext context, SIconData icon, String label) {
    final p = context.pal;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SIcon(icon, size: 14, color: p.gold),
        const SizedBox(width: 4),
        Text(label, style: AtelierType.caption(context, color: p.text, size: 12)),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطل بتبويبات ومنصة ترتيب وترحيب
// ═══════════════════════════════════════════════════════════════════════════

/// بطل بتبويبات: «رائج» / «جديد» / «مكتمل» يبدّل محتوى البطل.
///
/// التبويبات قواعديّة بحتة (تصفية قوائم محلية).
class AtelierHeroTabs extends StatefulWidget {
  const AtelierHeroTabs({
    super.key,
    required this.tabs,
    this.onOpen,
    this.onFollow,
    this.height = 340,
  });

  /// خريطة اسم التبويب ← عناصره.
  final Map<String, List<AtelierHeroItem>> tabs;
  final void Function(Series)? onOpen;
  final void Function(Series)? onFollow;
  final double height;

  @override
  State<AtelierHeroTabs> createState() => _AtelierHeroTabsState();
}

class _AtelierHeroTabsState extends State<AtelierHeroTabs> {
  late String _current;

  @override
  void initState() {
    super.initState();
    _current = widget.tabs.keys.first;
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final items = widget.tabs[_current] ?? const <AtelierHeroItem>[];
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
          child: Row(
            children: [
              for (final entry in widget.tabs.entries)
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: GestureDetector(
                    onTap: () => setState(() => _current = entry.key),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: _current == entry.key ? p.accent : p.surfaceHi,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: _current == entry.key ? p.accent : p.border,
                        ),
                      ),
                      child: Text(
                        '${entry.key} (${entry.value.length})',
                        style: AtelierType.caption(
                          context,
                          color: _current == entry.key ? p.onAccent : p.textDim,
                          size: 12.5,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (items.isEmpty)
          SizedBox(
            height: widget.height,
            child: Center(
              child: Text('لا توجد أعمال في هذا التبويب بعد.', style: AtelierType.muted(context)),
            ),
          )
        else
          AtelierHeroSection(
            items: items,
            height: widget.height,
            onOpen: widget.onOpen,
            onFollow: widget.onFollow,
          ),
      ],
    );
  }
}

/// منصة ترتيب: أول ثلاثة أعمال بأحجام متدرجة (الأول في الوسط وأعلى).
class AtelierPodium extends StatelessWidget {
  const AtelierPodium({
    super.key,
    required this.top,
    this.onTap,
    this.title = 'الأكثر قراءة هذا الأسبوع',
  });

  final List<Series> top;
  final void Function(Series)? onTap;
  final String title;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final shown = top.take(3).toList();
    if (shown.isEmpty) return const SizedBox.shrink();
    // ترتيب العرض: الثاني، الأول، الثالث.
    final order = <int>[];
    if (shown.length >= 2) order.add(1);
    order.add(0);
    if (shown.length >= 3) order.add(2);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
      decoration: AtelierDecor.card(p, radius: 24),
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SIcon(SardIcons.local_fire_department_rounded, size: 18, color: Color(0xFFFFC94D)),
              const SizedBox(width: 6),
              Text(title, style: AtelierType.subtitle(context, size: 15)),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (final idx in order)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: _PodiumSpot(
                    series: shown[idx],
                    rank: idx + 1,
                    big: idx == 0,
                    onTap: onTap,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PodiumSpot extends StatelessWidget {
  const _PodiumSpot({required this.series, required this.rank, required this.big, this.onTap});

  final Series series;
  final int rank;
  final bool big;
  final void Function(Series)? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final w = big ? 104.0 : 84.0;
    final medal = rank == 1
        ? const Color(0xFFFFC94D)
        : rank == 2
            ? const Color(0xFFC0C8D0)
            : const Color(0xFFD89A6A);
    return AtelierPressable(
      onTap: onTap == null ? null : () => onTap!(series),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: SizedBox(
                  width: w,
                  height: w / AtelierSpacing.posterAspect,
                  child: CoverArt(series: series, radius: 0, showTitle: false),
                ),
              ),
              Positioned(
                top: -10,
                right: -6,
                child: Container(
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: medal,
                    border: Border.all(color: p.surface, width: 2),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '$rank',
                    style: const TextStyle(
                      fontFamily: sardFont,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      height: 1,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: w + 16,
            child: Text(
              series.title,
              textAlign: TextAlign.center,
              style: AtelierType.caption(context, color: p.text, size: 11.5),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            formatCount(series.views),
            style: AtelierType.caption(context, size: 10.5),
          ),
        ],
      ),
    );
  }
}

/// لافتة ترحيب ذهبية: تحية + اسم + حكمة اليوم + زر استكشاف.
class AtelierWelcomeBanner extends StatelessWidget {
  const AtelierWelcomeBanner({
    super.key,
    required this.name,
    this.onExplore,
    this.onContinue,
    this.hasContinue = false,
  });

  final String name;
  final VoidCallback? onExplore;
  final VoidCallback? onContinue;
  final bool hasContinue;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            Color.lerp(p.gold, Colors.white, 0.12)!,
            p.gold,
            Color.lerp(p.gold, Colors.black, 0.18)!,
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(color: tint(p.gold, 0.35), blurRadius: 20, offset: const Offset(0, 8)),
        ],
      ),
      child: Stack(
        children: [
          const Positioned.fill(child: AtelierGoldDust(count: 16)),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  atelierGreetingWithName(name),
                  style: const TextStyle(
                    fontFamily: sardFont,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    height: 1.3,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  atelierDailyWisdom(),
                  style: TextStyle(
                    fontFamily: sardBodyFont,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w500,
                    color: Colors.white.withAlpha(230),
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    if (hasContinue)
                      GestureDetector(
                        onTap: onContinue,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            'واصل القراءة',
                            style: TextStyle(
                              fontFamily: sardBodyFont,
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: p.gold,
                            ),
                          ),
                        ),
                      ),
                    if (hasContinue) const SizedBox(width: 10),
                    GestureDetector(
                      onTap: onExplore,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(22),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: Colors.white.withAlpha(70)),
                        ),
                        child: const Text(
                          'اكتشف جديداً',
                          style: TextStyle(
                            fontFamily: sardBodyFont,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطل بحث وشريط تصنيفات
// ═══════════════════════════════════════════════════════════════════════════

/// بطل بحث: عنوان كبير + شريط بحث + اقتراحات سريعة.
///
/// يُستعمل أعلى شاشة البحث أو كقسم في الرئيسية.
class AtelierHeroSearchBar extends StatelessWidget {
  const AtelierHeroSearchBar({
    super.key,
    required this.onSearchTap,
    this.hint = 'ابحث عن مانهوا، مانغا، رواية…',
    this.quickTerms = const ['أكشن', 'رومانسي', 'فانتازيا', 'رعب', 'كوميديا'],
    this.onQuickTerm,
    this.series,
  });

  final VoidCallback onSearchTap;
  final String hint;
  final List<String> quickTerms;
  final ValueChanged<String>? onQuickTerm;
  final Series? series;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [p.surfaceHi, p.surface],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: p.border),
      ),
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('ماذا تريد أن تقرأ اليوم؟', style: AtelierType.title(context, size: 19)),
          const SizedBox(height: 4),
          Text('آلاف الحكايات بانتظارك — اكتب كلمة وابدأ الرحلة.', style: AtelierType.muted(context)),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: onSearchTap,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
              decoration: BoxDecoration(
                color: p.bg,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: p.border),
              ),
              child: Row(
                children: [
                  SIcon(SardIcons.search_rounded, size: 20, color: p.textDim),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(hint, style: AtelierType.muted(context)),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: AtelierDecor.pill(p.accent),
                    child: Text('بحث', style: AtelierType.caption(context, color: p.accent, size: 11.5)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final term in quickTerms)
                AtelierChip(
                  label: term,
                  tone: AtelierTone.values[(term.hashCode & 0x7fffffff) % AtelierTone.values.length],
                  onTap: onQuickTerm == null ? null : () => onQuickTerm!(term),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// شريط تصنيفات كبير بأغلفة (كل تصنيف بطاقة مصغّرة).
class AtelierHeroGenreStrip extends StatelessWidget {
  const AtelierHeroGenreStrip({
    super.key,
    required this.genres,
    this.onGenre,
  });

  /// خريطة التصنيف ← عمل ممثل له (لغلافه).
  final Map<String, Series> genres;
  final ValueChanged<String>? onGenre;

  @override
  Widget build(BuildContext context) {
    if (genres.isEmpty) return const SizedBox.shrink();
    final entries = genres.entries.toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const AtelierHeading(kicker: 'عوالم', title: 'تصفّح حسب التصنيف'),
        SizedBox(
          height: 120,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
            itemCount: entries.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              final entry = entries[i];
              final tone = AtelierTone.forGenres([entry.key]);
              return AtelierPressable(
                onTap: onGenre == null ? null : () => onGenre!(entry.key),
                child: Container(
                  width: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: softShadow(context.pal, strength: 0.8),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        CoverArt(series: entry.value, radius: 0, showTitle: false),
                        Positioned.fill(
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.centerRight,
                                end: Alignment.centerLeft,
                                colors: [tone.color.withAlpha(200), tone.dark.withAlpha(120)],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                entry.key,
                                style: const TextStyle(
                                  fontFamily: sardFont,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                  height: 1.2,
                                ),
                              ),
                              Text(
                                entry.value.title,
                                style: TextStyle(
                                  fontFamily: sardBodyFont,
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white.withAlpha(225),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
