import 'package:flutter/material.dart';

import '../../core/theme/app_themes.dart';
import 'atelier_theme.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// هياكل تحميل متلألئة — تظهر أثناء جلب بيانات الصفحة الرئيسية
/// فتبدو الصفحة حيّة بدل فراغ أبيض أو دوّار تحميل.
///
/// القواعد:
///   • التلألؤ حركة أفقية بطيئة (1.6 ثانية) على تدرّج فاتح.
///   • يُبطل تماماً عند تفعيل «تقليل الحركة» (لون ثابت بدل حركة).
///   • كل هيكل يطابق شكل المحتوى الحقيقي (بطل، صف أغلفة، فصول، شبكة).
/// ──────────────────────────────────────────────────────────────────────────

/// غلاف تلألؤ: يحرّك تدرّجاً فاتحاً عبر طفل ثابت اللون.
class AtelierShimmer extends StatefulWidget {
  const AtelierShimmer({
    super.key,
    required this.child,
    this.duration = const Duration(milliseconds: 1600),
    this.enabled = true,
  });

  final Widget child;
  final Duration duration;
  final bool enabled;

  @override
  State<AtelierShimmer> createState() => _AtelierShimmerState();
}

class _AtelierShimmerState extends State<AtelierShimmer> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration)..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final reduced = MediaQuery.disableAnimationsOf(context);
    if (!widget.enabled || reduced) return widget.child;
    final base = p.surfaceHi;
    final hi = p.isDark
        ? Color.lerp(base, Colors.white, 0.10)!
        : Color.lerp(base, Colors.white, 0.55)!;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) {
        final t = _c.value;
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) => LinearGradient(
            begin: Alignment(-1.6 + 3.2 * t, 0),
            end: Alignment(-0.6 + 3.2 * t, 0),
            colors: [base, hi, base],
            stops: const [0.0, 0.5, 1.0],
          ).createShader(bounds),
          child: child,
        );
      },
      child: widget.child,
    );
  }
}

/// مستطيل تلألؤ واحد (لبنة بناء كل الهياكل).
class AtelierShimmerBox extends StatelessWidget {
  const AtelierShimmerBox({
    super.key,
    this.width,
    this.height = 16,
    this.radius = 8,
    this.color,
  });

  final double? width;
  final double height;
  final double radius;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: color ?? p.surfaceHi,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}

/// سطرا نص تلألؤ (عنوان + سطر ثانوي أقصر).
class AtelierShimmerText extends StatelessWidget {
  const AtelierShimmerText({
    super.key,
    this.titleWidth = 160,
    this.subtitleWidth = 110,
    this.titleHeight = 16,
    this.subtitleHeight = 12,
  });

  final double titleWidth;
  final double subtitleWidth;
  final double titleHeight;
  final double subtitleHeight;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        AtelierShimmerBox(width: titleWidth, height: titleHeight, radius: 6),
        const SizedBox(height: 8),
        AtelierShimmerBox(width: subtitleWidth, height: subtitleHeight, radius: 6),
      ],
    );
  }
}

/// دائرة تلألؤ (لصورة رمزية أو أيقونة).
class AtelierShimmerCircle extends StatelessWidget {
  const AtelierShimmerCircle({super.key, this.size = 44});

  final double size;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: p.surfaceHi),
    );
  }
}

/// هيكل البطل: مستطيل كبير + نصوص أسفله.
class AtelierShimmerHero extends StatelessWidget {
  const AtelierShimmerHero({super.key, this.height = 380});

  final double height;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierShimmer(
      child: SizedBox(
        height: height,
        child: Stack(
          children: [
            Container(color: p.surfaceHi),
            Positioned(
              left: AtelierSpacing.page,
              right: AtelierSpacing.page,
              bottom: 52,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const AtelierShimmerBox(width: 92, height: 22, radius: 999),
                  const SizedBox(height: 12),
                  const AtelierShimmerBox(width: 230, height: 24, radius: 8),
                  const SizedBox(height: 8),
                  const AtelierShimmerBox(width: 180, height: 14, radius: 6),
                  const SizedBox(height: 16),
                  Row(
                    children: const [
                      AtelierShimmerBox(width: 110, height: 40, radius: 999),
                      SizedBox(width: 10),
                      AtelierShimmerBox(width: 110, height: 40, radius: 999),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// هيكل صف أغلفة أفقي (5 بطاقات).
class AtelierShimmerPosterRow extends StatelessWidget {
  const AtelierShimmerPosterRow({super.key, this.count = 5, this.width = 132});

  final int count;
  final double width;

  @override
  Widget build(BuildContext context) {
    return AtelierShimmer(
      child: SizedBox(
        height: width / AtelierSpacing.posterAspect + 52,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
          itemCount: count,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (context, i) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AtelierShimmerBox(
                width: width,
                height: width / AtelierSpacing.posterAspect,
                radius: 16,
              ),
              const SizedBox(height: 8),
              const AtelierShimmerBox(width: 100, height: 13, radius: 6),
              const SizedBox(height: 6),
              const AtelierShimmerBox(width: 70, height: 11, radius: 6),
            ],
          ),
        ),
      ),
    );
  }
}

/// هيكل قائمة فصول (3 صفوف).
class AtelierShimmerChapterList extends StatelessWidget {
  const AtelierShimmerChapterList({super.key, this.count = 3});

  final int count;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierShimmer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        child: Column(
          children: [
            for (var i = 0; i < count; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  height: AtelierSpacing.chapterHeight,
                  decoration: BoxDecoration(
                    color: p.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: p.border),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      const AtelierShimmerBox(width: 46, height: 46, radius: 14),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            AtelierShimmerBox(width: 150, height: 14, radius: 6),
                            SizedBox(height: 8),
                            AtelierShimmerBox(width: 100, height: 11, radius: 6),
                          ],
                        ),
                      ),
                      const AtelierShimmerBox(width: 22, height: 22, radius: 999),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// هيكل شبكة أعمال (عمودان × 3 صفوف).
class AtelierShimmerGrid extends StatelessWidget {
  const AtelierShimmerGrid({super.key, this.count = 6});

  final int count;

  @override
  Widget build(BuildContext context) {
    return AtelierShimmer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        child: GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: 0.62,
          ),
          itemCount: count,
          itemBuilder: (context, i) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Expanded(
                child: AtelierShimmerBox(width: double.infinity, height: double.infinity, radius: 16),
              ),
              const SizedBox(height: 8),
              const AtelierShimmerBox(width: 110, height: 13, radius: 6),
              const SizedBox(height: 6),
              const AtelierShimmerBox(width: 70, height: 11, radius: 6),
            ],
          ),
        ),
      ),
    );
  }
}

/// هيكل بطاقة رفيق (روح + فقاعة).
class AtelierShimmerCompanion extends StatelessWidget {
  const AtelierShimmerCompanion({super.key});

  @override
  Widget build(BuildContext context) {
    return AtelierShimmer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            const AtelierShimmerCircle(size: 74),
            const SizedBox(width: 10),
            Expanded(
              child: Container(
                height: 96,
                decoration: BoxDecoration(
                  color: context.pal.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: context.pal.border),
                ),
                padding: const EdgeInsets.all(14),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AtelierShimmerBox(width: 90, height: 11, radius: 6),
                    SizedBox(height: 8),
                    AtelierShimmerBox(width: 200, height: 13, radius: 6),
                    SizedBox(height: 6),
                    AtelierShimmerBox(width: 140, height: 13, radius: 6),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// هيكل قسم إحصاءات (3 بطاقات صغيرة).
class AtelierShimmerStats extends StatelessWidget {
  const AtelierShimmerStats({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierShimmer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        child: Row(
          children: [
            for (var i = 0; i < 3; i++)
              Expanded(
                child: Container(
                  height: 104,
                  margin: EdgeInsets.only(left: i == 0 ? 0 : 10),
                  decoration: BoxDecoration(
                    color: p.surface,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: p.border),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AtelierShimmerBox(width: 34, height: 34, radius: 11),
                      SizedBox(height: 12),
                      AtelierShimmerBox(width: 56, height: 18, radius: 6),
                      SizedBox(height: 6),
                      AtelierShimmerBox(width: 70, height: 11, radius: 6),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// هيكل صفحة رئيسية كاملة (بطل + رفيق + صف + فصول).
class AtelierShimmerHome extends StatelessWidget {
  const AtelierShimmerHome({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          AtelierShimmerHero(height: 340),
          SizedBox(height: 20),
          AtelierShimmerCompanion(),
          SizedBox(height: 24),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
            child: AtelierShimmerText(titleWidth: 140, subtitleWidth: 90),
          ),
          SizedBox(height: 14),
          AtelierShimmerPosterRow(),
          SizedBox(height: 24),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
            child: AtelierShimmerText(titleWidth: 120, subtitleWidth: 80),
          ),
          SizedBox(height: 14),
          AtelierShimmerChapterList(),
          SizedBox(height: 30),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────────────
//  هياكل إضافية: ملف وتفاصيل وتعليقات
// ──────────────────────────────────────────────────────────────────────────

/// هيكل الملف الشخصي: صورة رمزية + اسم + إحصاءات.
class AtelierShimmerProfile extends StatelessWidget {
  const AtelierShimmerProfile({super.key});

  @override
  Widget build(BuildContext context) {
    return AtelierShimmer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page, vertical: 70),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: const [
                AtelierShimmerCircle(size: 56),
                SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AtelierShimmerBox(width: 130, height: 18, radius: 6),
                    SizedBox(height: 8),
                    AtelierShimmerBox(width: 90, height: 12, radius: 6),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            const AtelierShimmerStats(),
          ],
        ),
      ),
    );
  }
}

/// هيكل صفحة تفاصيل عمل: غلاف كبير + عنوان + أزرار + فصول.
class AtelierShimmerDetails extends StatelessWidget {
  const AtelierShimmerDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return AtelierShimmer(
      child: SingleChildScrollView(
        physics: const NeverScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 300,
              color: context.pal.surfaceHi,
            ),
            Padding(
              padding: const EdgeInsets.all(AtelierSpacing.page),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  AtelierShimmerBox(width: 200, height: 22, radius: 8),
                  SizedBox(height: 10),
                  AtelierShimmerBox(width: 150, height: 13, radius: 6),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      AtelierShimmerBox(width: 120, height: 44, radius: 999),
                      SizedBox(width: 10),
                      AtelierShimmerBox(width: 44, height: 44, radius: 999),
                    ],
                  ),
                  SizedBox(height: 20),
                  AtelierShimmerBox(width: double.infinity, height: 13, radius: 6),
                  SizedBox(height: 8),
                  AtelierShimmerBox(width: double.infinity, height: 13, radius: 6),
                  SizedBox(height: 8),
                  AtelierShimmerBox(width: 180, height: 13, radius: 6),
                ],
              ),
            ),
            const AtelierShimmerChapterList(count: 4),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

/// هيكل قائمة تعليقات (3 تعليقات).
class AtelierShimmerComments extends StatelessWidget {
  const AtelierShimmerComments({super.key, this.count = 3});

  final int count;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierShimmer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
        child: Column(
          children: [
            for (var i = 0; i < count; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Container(
                  decoration: BoxDecoration(
                    color: p.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: p.border),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          AtelierShimmerCircle(size: 36),
                          SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              AtelierShimmerBox(width: 90, height: 12, radius: 6),
                              SizedBox(height: 6),
                              AtelierShimmerBox(width: 60, height: 10, radius: 6),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const AtelierShimmerBox(width: double.infinity, height: 12, radius: 6),
                      const SizedBox(height: 6),
                      const AtelierShimmerBox(width: 220, height: 12, radius: 6),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// هيكل بطاقة إحصاء واحدة (لصفوف إحصاءات مخصصة).
class AtelierShimmerStatCard extends StatelessWidget {
  const AtelierShimmerStatCard({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierShimmer(
      child: Container(
        height: 104,
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: p.border),
        ),
        padding: const EdgeInsets.all(14),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AtelierShimmerBox(width: 34, height: 34, radius: 11),
            SizedBox(height: 12),
            AtelierShimmerBox(width: 56, height: 18, radius: 6),
            SizedBox(height: 6),
            AtelierShimmerBox(width: 70, height: 11, radius: 6),
          ],
        ),
      ),
    );
  }
}

/// هيكل شاشة البحث: شريط بحث + رقائق + نتائج.
class AtelierShimmerSearch extends StatelessWidget {
  const AtelierShimmerSearch({super.key});

  @override
  Widget build(BuildContext context) {
    return AtelierShimmer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page, vertical: 60),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const AtelierShimmerBox(width: double.infinity, height: 48, radius: 999),
            const SizedBox(height: 16),
            Row(
              children: const [
                AtelierShimmerBox(width: 70, height: 34, radius: 999),
                SizedBox(width: 8),
                AtelierShimmerBox(width: 80, height: 34, radius: 999),
                SizedBox(width: 8),
                AtelierShimmerBox(width: 64, height: 34, radius: 999),
              ],
            ),
            const SizedBox(height: 24),
            const AtelierShimmerText(titleWidth: 140, subtitleWidth: 90),
            const SizedBox(height: 14),
            const AtelierShimmerChapterList(count: 4),
          ],
        ),
      ),
    );
  }
}

/// هيكل بطاقة هدف (لأهداف القراءة).
class AtelierShimmerGoal extends StatelessWidget {
  const AtelierShimmerGoal({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AtelierShimmer(
      child: Container(
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: p.border),
        ),
        padding: const EdgeInsets.all(16),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                AtelierShimmerBox(width: 36, height: 36, radius: 12),
                SizedBox(width: 10),
                AtelierShimmerBox(width: 120, height: 14, radius: 6),
              ],
            ),
            SizedBox(height: 14),
            AtelierShimmerBox(width: 90, height: 22, radius: 6),
            SizedBox(height: 8),
            AtelierShimmerBox(width: double.infinity, height: 8, radius: 999),
          ],
        ),
      ),
    );
  }
}
