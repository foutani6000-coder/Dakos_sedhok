import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../core/stamps/stamps.dart';
import '../core/storage/settings.dart';
import '../core/theme/app_themes.dart';
import 'sard_icons.dart';

/// ملصق ختم بتصميم SVG احترافي (assets/stamps/<id>.svg): ملوّن ولامع حين يُنال،
/// ورمادي بقفل وحلقة تقدّم حين لا يزال مقفلاً.
/// لتوليد الملصقات من جديد: `python3 scripts/gen_stamp_svgs.py`.
class StampSeal extends StatelessWidget {
  const StampSeal({
    super.key,
    required this.def,
    required this.unlocked,
    this.size = 84,
    this.progress = 0,
  });

  final StampDef def;
  final bool unlocked;
  final double size;

  /// 0..1 — يظهر كحلقة حول الختم المقفل
  final double progress;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = def.tier.color;
    final ring = !unlocked && progress > 0;
    // نصغّر الملصق قليلاً عند وجود حلقة التقدّم ليبقى لها مكان
    final art = ring ? size * 0.86 : size;
    final asset = 'assets/stamps/${def.id}${unlocked ? '' : '_locked'}.svg';

    Widget seal = SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (ring)
            CustomPaint(
              size: Size.square(size),
              painter: _ProgressRingPainter(
                progress: progress.clamp(0.0, 1.0).toDouble(),
                color: p.accent,
                track: tint(p.textDim, 0.25),
              ),
            ),
          SvgPicture.asset(
            asset,
            width: art,
            height: art,
            // أثناء تحميل الملصق نعرض أيقونة الختم بدل الفراغ
            placeholderBuilder: (_) => SIcon(def.icon, size: art * 0.4, color: unlocked ? c : tint(p.textDim, 0.8)),
          ),
          if (!unlocked)
            PositionedDirectional(
              end: size * 0.04,
              bottom: size * 0.04,
              child: Container(
                width: size * 0.3,
                height: size * 0.3,
                decoration: BoxDecoration(
                  color: p.surface,
                  shape: BoxShape.circle,
                  border: Border.all(color: p.border, width: 1.2),
                ),
                child: Center(child: SIcon(SardIcons.lock_outline, size: size * 0.16, color: p.textDim, animate: false)),
              ),
            ),
        ],
      ),
    );
    if (unlocked) {
      seal = DecoratedBox(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: tint(c, 0.32), blurRadius: size * 0.28)],
        ),
        child: Transform.rotate(angle: -0.08, child: seal),
      );
    }
    return seal;
  }
}

class _ProgressRingPainter extends CustomPainter {
  _ProgressRingPainter({required this.progress, required this.color, required this.track});
  final double progress;
  final Color color;
  final Color track;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final rect = Rect.fromCircle(center: c, radius: size.width / 2 - 2);
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 3;
    canvas.drawCircle(c, rect.width / 2, base..color = track);
    canvas.drawArc(rect, -math.pi / 2, 2 * math.pi * progress, false, base..color = color);
  }

  @override
  bool shouldRepaint(covariant _ProgressRingPainter old) =>
      old.progress != progress || old.color != color || old.track != track;
}

/// يستمع لأختام [SettingsController] الجديدة ويعرض إشعاراً احتفالياً فوق التطبيق كله.
/// يوضع حول محتوى MaterialApp.builder.
class StampToastHost extends StatefulWidget {
  const StampToastHost({super.key, required this.settings, required this.child});
  final SettingsController settings;
  final Widget child;

  @override
  State<StampToastHost> createState() => _StampToastHostState();
}

class _StampToastHostState extends State<StampToastHost> {
  StampDef? _shown;
  bool _visible = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    widget.settings.stampToast.addListener(_onChange);
  }

  @override
  void didUpdateWidget(covariant StampToastHost old) {
    super.didUpdateWidget(old);
    if (old.settings != widget.settings) {
      old.settings.stampToast.removeListener(_onChange);
      widget.settings.stampToast.addListener(_onChange);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.settings.stampToast.removeListener(_onChange);
    super.dispose();
  }

  void _onChange() {
    final d = widget.settings.stampToast.value;
    if (d == null || !mounted) return;
    setState(() {
      _shown = d;
      _visible = true;
    });
    HapticFeedback.mediumImpact();
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 3800), () {
      if (!mounted) return;
      setState(() => _visible = false);
      Future<void>.delayed(const Duration(milliseconds: 450), () {
        if (mounted) widget.settings.dismissStampToast();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = _shown;
    return Stack(
      children: [
        widget.child,
        if (d != null)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: IgnorePointer(
                child: AnimatedSlide(
                  offset: _visible ? Offset.zero : const Offset(0, -1.4),
                  duration: const Duration(milliseconds: 480),
                  curve: _visible ? Curves.easeOutBack : Curves.easeInCubic,
                  child: AnimatedOpacity(
                    opacity: _visible ? 1 : 0,
                    duration: const Duration(milliseconds: 300),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                      child: _StampToastCard(def: d),
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _StampToastCard extends StatelessWidget {
  const _StampToastCard({required this.def});
  final StampDef def;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = def.tier.color;
    return Material(
      type: MaterialType.transparency,
      child: Container(
        padding: const EdgeInsetsDirectional.fromSTEB(12, 10, 18, 10),
        decoration: BoxDecoration(
          color: Color.lerp(p.surface, c, 0.1),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: tint(c, 0.7), width: 1.3),
          boxShadow: [
            BoxShadow(color: tint(c, 0.4), blurRadius: 30, offset: const Offset(0, 10)),
            BoxShadow(color: tint(Colors.black, 0.3), blurRadius: 18, offset: const Offset(0, 6)),
          ],
        ),
        child: Row(
          children: [
            // الختم «ينطبع» بحركة ارتداد
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 2.2, end: 1),
              duration: const Duration(milliseconds: 620),
              curve: Curves.easeOutBack,
              builder: (context, v, child) => Transform.scale(scale: v, child: child),
              child: StampSeal(def: def, unlocked: true, size: 60),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'ختم جديد · ${def.tier.label}',
                    style: context.ts(size: 11, w: FontWeight.w800, color: c),
                  ),
                  const SizedBox(height: 2),
                  Text(def.title, style: context.ds(size: 17, height: 1.2)),
                  const SizedBox(height: 2),
                  Text(
                    def.desc,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: context.ts(size: 11.5, color: p.textDim, height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
