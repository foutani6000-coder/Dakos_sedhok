import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../core/theme/app_themes.dart';
import 'sard_icon_set.dart';

/// معرّف أيقونة SVG (بديل IconData). الأسماء في [SardIcons].
@immutable
class SIconData {
  const SIconData(this.id, {this.mirror = false});
  final String id;

  /// تنعكس في الواجهات من اليمين لليسار (أسهم، تشغيل، إرسال...).
  final bool mirror;

  @override
  bool operator ==(Object other) => other is SIconData && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

/// أيقونة SVG حديثة بتوهّج لوني وحركة خفيفة خاصة بكل أيقونة.
///
/// تُستخدم تماماً مثل [Icon]: الحجم واللون من الوسائط أو من [IconTheme].
/// - [glow]: تعطيل/تفعيل التوهّج لهذه الأيقونة (الافتراضي: حسب السمة).
/// - [animate]: تعطيل الحركة لهذه الأيقونة.
class SIcon extends StatelessWidget {
  const SIcon(
    this.icon, {
    super.key,
    this.size,
    this.color,
    this.glow,
    this.animate = true,
    this.semanticLabel,
  });

  final SIconData? icon;
  final double? size;
  final Color? color;
  final bool? glow;
  final bool animate;
  final String? semanticLabel;

  /// مفاتيح عامة يمكن ربطها بالإعدادات لاحقاً.
  static bool glowEnabled = true;
  static bool animationsEnabled = true;

  @override
  Widget build(BuildContext context) {
    final data = icon;
    final theme = IconTheme.of(context);
    final s = size ?? theme.size ?? 24.0;
    if (data == null) return SizedBox.square(dimension: s);
    final spec = kSardIconSet[data.id];
    if (spec == null) return SizedBox.square(dimension: s);

    var c = color ?? theme.color ?? const Color(0xFFE8E8EE);
    final op = theme.opacity;
    if (op != null && op < 1) c = tint(c, (c.alpha / 255) * op);

    final pal = Theme.of(context).extension<SardPalette>();
    final dark = (pal?.isDark) ?? Theme.of(context).brightness == Brightness.dark;
    final strength = (pal?.glow ?? 0.6).clamp(0.0, 1.0).toDouble();
    final wantGlow = (glow ?? glowEnabled) && s >= 14 && strength > 0;

    Widget art = SvgPicture.string(
      spec.svg,
      width: s,
      height: s,
      theme: SvgTheme(currentColor: c),
    );

    if (wantGlow) {
      final a = (dark ? 0.62 : 0.34) * (0.55 + 0.45 * strength);
      art = SizedBox.square(
        dimension: s,
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            Positioned.fill(
              child: ImageFiltered(
                imageFilter: ui.ImageFilter.blur(sigmaX: s * 0.17, sigmaY: s * 0.17),
                child: SvgPicture.string(
                  spec.svg,
                  width: s,
                  height: s,
                  colorFilter: ColorFilter.mode(tint(spec.glow, a), BlendMode.srcIn),
                ),
              ),
            ),
            art,
          ],
        ),
      );
    }

    if (data.mirror && Directionality.of(context) == TextDirection.rtl) {
      art = Transform.flip(flipX: true, child: art);
    }

    if (animate && animationsEnabled && spec.fx != SIconFx.none && s >= 16) {
      art = _FxIcon(fx: spec.fx, child: art);
    }

    return Semantics(
      label: semanticLabel,
      image: true,
      excludeSemantics: semanticLabel == null,
      child: RepaintBoundary(child: art),
    );
  }
}

class _FxIcon extends StatefulWidget {
  const _FxIcon({required this.fx, required this.child});
  final SIconFx fx;
  final Widget child;

  @override
  State<_FxIcon> createState() => _FxIconState();
}

class _FxIconState extends State<_FxIcon> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  Duration get _dur {
    switch (widget.fx) {
      case SIconFx.pulse:
        return const Duration(milliseconds: 1500);
      case SIconFx.swing:
        return const Duration(milliseconds: 2400);
      case SIconFx.flicker:
        return const Duration(milliseconds: 1100);
      case SIconFx.flash:
        return const Duration(milliseconds: 2600);
      case SIconFx.twinkle:
        return const Duration(milliseconds: 2200);
      case SIconFx.spinSlow:
        return const Duration(seconds: 14);
      case SIconFx.none:
        return const Duration(seconds: 1);
    }
  }

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: _dur)..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  // نبضتان سريعتان ثم راحة (نبض قلب)
  double _beat(double t) {
    double bump(double x, double c, double w) {
      final d = (x - c).abs() / w;
      return d >= 1 ? 0 : (1 - d) * (1 - d);
    }

    return bump(t, 0.12, 0.12) + 0.7 * bump(t, 0.34, 0.12);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) {
        final t = _c.value;
        switch (widget.fx) {
          case SIconFx.pulse:
            return Transform.scale(scale: 1 + 0.16 * _beat(t), child: child);
          case SIconFx.swing:
            // رنين الجرس: اهتزاز في أول 35% ثم سكون
            double ang = 0.0;
            if (t < 0.35) {
              final k = t / 0.35;
              ang = 0.34 * (1 - k) * math.sin(k * 3 * 2 * math.pi);
            }
            return Transform.rotate(angle: ang, alignment: const Alignment(0, -0.7), child: child);
          case SIconFx.flicker:
            final v = 0.5 + 0.5 * math.sin(t * 2 * math.pi);
            final w = 0.5 + 0.5 * math.sin(t * 4 * math.pi + 1.3);
            return Transform(
              alignment: Alignment.bottomCenter,
              transform: Matrix4.diagonal3Values(1 + 0.04 * w, 0.96 + 0.09 * v, 1),
              child: child,
            );
          case SIconFx.flash:
            final f = t < 0.08 ? 1.0 : t < 0.14 ? 0.55 : t < 0.2 ? 1.0 : 0.88;
            return Opacity(opacity: f, child: child);
          case SIconFx.twinkle:
            final tw = 0.5 + 0.5 * math.sin(t * 2 * math.pi);
            return Transform.scale(
              scale: 0.94 + 0.12 * tw,
              child: Transform.rotate(angle: 0.12 * (tw - 0.5), child: child),
            );
          case SIconFx.spinSlow:
            return Transform.rotate(angle: t * 2 * math.pi, child: child);
          case SIconFx.none:
            return child!;
        }
      },
    );
  }
}


/// أسماء الأيقونات (مطابقة لأسماء Material لتسهيل الاستبدال). الاستخدام: SIcon(SardIcons.home_rounded)
abstract final class SardIcons {
  SardIcons._();
  static const arrow_back_rounded = SIconData('arrow_back_rounded', mirror: true);
  static const arrow_forward_rounded = SIconData('arrow_forward_rounded', mirror: true);
  static const chevron_left_rounded = SIconData('chevron_left_rounded', mirror: true);
  static const chevron_right_rounded = SIconData('chevron_right_rounded', mirror: true);
  static const expand_more_rounded = SIconData('expand_more_rounded');
  static const expand_less_rounded = SIconData('expand_less_rounded');
  static const close_rounded = SIconData('close_rounded');
  static const menu_rounded = SIconData('menu_rounded');
  static const check_rounded = SIconData('check_rounded');
  static const done_all_rounded = SIconData('done_all_rounded');
  static const check_circle_rounded = SIconData('check_circle_rounded');
  static const add_circle_outline = SIconData('add_circle_outline');
  static const info_outline_rounded = SIconData('info_outline_rounded');
  static const question_mark_rounded = SIconData('question_mark_rounded');
  static const priority_high_rounded = SIconData('priority_high_rounded');
  static const swap_vert_rounded = SIconData('swap_vert_rounded');
  static const filter_list_rounded = SIconData('filter_list_rounded');
  static const tune_rounded = SIconData('tune_rounded');
  static const refresh_rounded = SIconData('refresh_rounded');
  static const sync_rounded = SIconData('sync_rounded');
  static const history_rounded = SIconData('history_rounded');
  static const search_rounded = SIconData('search_rounded');
  static const manage_search_rounded = SIconData('manage_search_rounded');
  static const play_arrow_rounded = SIconData('play_arrow_rounded', mirror: true);
  static const play_circle_rounded = SIconData('play_circle_rounded');
  static const play_circle_outline_rounded = SIconData('play_circle_outline_rounded');
  static const pause_rounded = SIconData('pause_rounded');
  static const pause_circle_outline_rounded = SIconData('pause_circle_outline_rounded');
  static const skip_next_rounded = SIconData('skip_next_rounded', mirror: true);
  static const skip_previous_rounded = SIconData('skip_previous_rounded', mirror: true);
  static const download_rounded = SIconData('download_rounded');
  static const download_outlined = SIconData('download_outlined');
  static const download_done_rounded = SIconData('download_done_rounded');
  static const menu_book_rounded = SIconData('menu_book_rounded');
  static const auto_stories_rounded = SIconData('auto_stories_rounded');
  static const chrome_reader_mode_rounded = SIconData('chrome_reader_mode_rounded', mirror: true);
  static const bookmark_rounded = SIconData('bookmark_rounded');
  static const bookmark_border_rounded = SIconData('bookmark_border_rounded');
  static const collections_bookmark_rounded = SIconData('collections_bookmark_rounded');
  static const collections_bookmark_outlined = SIconData('collections_bookmark_outlined');
  static const folder_copy_outlined = SIconData('folder_copy_outlined');
  static const playlist_add_rounded = SIconData('playlist_add_rounded', mirror: true);
  static const playlist_add_check_rounded = SIconData('playlist_add_check_rounded', mirror: true);
  static const format_list_bulleted_rounded = SIconData('format_list_bulleted_rounded', mirror: true);
  static const layers_rounded = SIconData('layers_rounded');
  static const category_rounded = SIconData('category_rounded');
  static const calendar_today_rounded = SIconData('calendar_today_rounded');
  static const sell_rounded = SIconData('sell_rounded');
  static const favorite_rounded = SIconData('favorite_rounded');
  static const favorite_border_rounded = SIconData('favorite_border_rounded');
  static const star_rounded = SIconData('star_rounded');
  static const star_border_rounded = SIconData('star_border_rounded');
  static const thumb_up_rounded = SIconData('thumb_up_rounded');
  static const thumb_up_off_alt_rounded = SIconData('thumb_up_off_alt_rounded');
  static const visibility_rounded = SIconData('visibility_rounded');
  static const visibility_outlined = SIconData('visibility_outlined');
  static const visibility_off_outlined = SIconData('visibility_off_outlined');
  static const notifications_none_rounded = SIconData('notifications_none_rounded');
  static const notifications_active_rounded = SIconData('notifications_active_rounded');
  static const campaign_rounded = SIconData('campaign_rounded');
  static const campaign_outlined = SIconData('campaign_outlined');
  static const local_fire_department_rounded = SIconData('local_fire_department_rounded');
  static const bolt_rounded = SIconData('bolt_rounded');
  static const auto_awesome_rounded = SIconData('auto_awesome_rounded');
  static const spa_rounded = SIconData('spa_rounded');
  static const pets_rounded = SIconData('pets_rounded');
  static const emoji_emotions_rounded = SIconData('emoji_emotions_rounded');
  static const explore_rounded = SIconData('explore_rounded');
  static const nightlight_round = SIconData('nightlight_round');
  static const bedtime_rounded = SIconData('bedtime_rounded');
  static const wb_sunny_rounded = SIconData('wb_sunny_rounded');
  static const light_mode_rounded = SIconData('light_mode_rounded');
  static const brightness_high_rounded = SIconData('brightness_high_rounded');
  static const brightness_low_rounded = SIconData('brightness_low_rounded');
  static const brightness_auto_rounded = SIconData('brightness_auto_rounded');
  static const settings_rounded = SIconData('settings_rounded');
  static const data_saver_on_rounded = SIconData('data_saver_on_rounded');
  static const hd_rounded = SIconData('hd_rounded');
  static const signal_cellular_alt_rounded = SIconData('signal_cellular_alt_rounded');
  static const cloud_off_rounded = SIconData('cloud_off_rounded');
  static const screen_lock_portrait_rounded = SIconData('screen_lock_portrait_rounded');
  static const person_rounded = SIconData('person_rounded');
  static const person_outline_rounded = SIconData('person_outline_rounded');
  static const person_outline = SIconData('person_outline');
  static const account_circle_outlined = SIconData('account_circle_outlined');
  static const groups_rounded = SIconData('groups_rounded');
  static const groups_outlined = SIconData('groups_outlined');
  static const forum_rounded = SIconData('forum_rounded');
  static const chat_bubble_rounded = SIconData('chat_bubble_rounded');
  static const chat_bubble_outline_rounded = SIconData('chat_bubble_outline_rounded');
  static const send_rounded = SIconData('send_rounded', mirror: true);
  static const reply_rounded = SIconData('reply_rounded', mirror: true);
  static const share_rounded = SIconData('share_rounded');
  static const edit_rounded = SIconData('edit_rounded');
  static const delete_outline_rounded = SIconData('delete_outline_rounded');
  static const logout_rounded = SIconData('logout_rounded', mirror: true);
  static const lock_outline = SIconData('lock_outline');
  static const mail_outline = SIconData('mail_outline');
  static const verified_user_outlined = SIconData('verified_user_outlined');
  static const shield_rounded = SIconData('shield_rounded');
  static const gavel_rounded = SIconData('gavel_rounded');
  static const copyright_rounded = SIconData('copyright_rounded');
  static const g_mobiledata_rounded = SIconData('g_mobiledata_rounded');
  static const close = SIconData('close');
  static const home_rounded = SIconData('home_rounded');
  static const home_outlined = SIconData('home_outlined');
  static const dynamic_feed_rounded = SIconData('dynamic_feed_rounded');
  static const dynamic_feed_outlined = SIconData('dynamic_feed_outlined');
  static const watch_later_rounded = SIconData('watch_later_rounded');
}