import 'package:flutter/material.dart';

import '../core/theme/app_themes.dart';
import 'fx.dart';
import 'ink_spirit.dart';
import 'sard_icons.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.title, this.subtitle});
  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const InkSpirit(size: 84),
            const SizedBox(height: 14),
            Text(title, textAlign: TextAlign.center, style: context.ds(size: 20)),
            if (subtitle != null) ...[
              const SizedBox(height: 8),
              Text(subtitle!,
                  textAlign: TextAlign.center,
                  style: context.ts(size: 13.5, color: p.textDim, height: 1.7)),
            ],
          ],
        ),
      ),
    );
  }
}

class ErrorState extends StatelessWidget {
  const ErrorState({super.key, required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const InkSpirit(size: 72, mood: InkSpiritMood.concerned),
          const SizedBox(height: 14),
          Text('تعذّر الاتصال بالسيرفر', style: context.ds(size: 19)),
          const SizedBox(height: 6),
          Text('تحقق من الإنترنت أو من API_BASE_URL',
              style: context.ts(size: 13, color: p.textDim)),
          const SizedBox(height: 18),
          Pressable(
            onTap: onRetry,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 12),
              decoration: BoxDecoration(
                color: p.accent,
                borderRadius: BorderRadius.circular(p.r(0.8).clamp(8.0, 24.0).toDouble()),
                boxShadow: p.glow > 0
                    ? [BoxShadow(color: tint(p.accent, 0.4 * p.glow), blurRadius: 16)]
                    : null,
              ),
              child: Text('إعادة المحاولة',
                  style: context.ts(size: 14, w: FontWeight.w700, color: p.onAccent)),
            ),
          ),
        ],
      ),
    );
  }
}

/// زر رئيسي عريض: تدرّج بلون التمييز + وهج + أيقونة داخل قرص
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({super.key, required this.label, required this.icon, required this.onTap});
  final String label;
  final SIconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: onTap,
      child: Container(
        height: 58,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(p.r(1.0).clamp(10.0, 28.0).toDouble()),
          border: p.borderW > 1.2
              ? Border.all(color: tint(p.onAccent, 0.3), width: p.borderW)
              : null,
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Color.lerp(p.accent, Colors.white, 0.1)!,
              p.accent,
              Color.lerp(p.accent, Colors.black, 0.12)!,
            ],
          ),
          boxShadow: [
            BoxShadow(color: tint(p.accent, 0.28), blurRadius: 22, offset: const Offset(0, 9)),
            if (p.glow > 0)
              BoxShadow(color: tint(p.accent, 0.45 * p.glow), blurRadius: 28),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: tint(p.onAccent, 0.18),
                borderRadius: BorderRadius.circular(p.r(0.7).clamp(6.0, 20.0).toDouble()),
              ),
              child: SIcon(icon, color: p.onAccent, size: 24),
            ),
            Expanded(
              child: Text(
                label,
                textAlign: TextAlign.center,
                style: context.ts(size: 16, w: FontWeight.w700, color: p.onAccent),
              ),
            ),
            const SizedBox(width: 40),
          ],
        ),
      ),
    );
  }
}
