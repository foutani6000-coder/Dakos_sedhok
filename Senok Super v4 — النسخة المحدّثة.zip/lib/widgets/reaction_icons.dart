import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../core/data/models.dart';

/// رسومات التفاعلات الخمسة بصيغة SVG (مصمّمة يدوياً، 48×48).
const Map<SardReaction, String> _svgs = {
  // إعجاب: دائرة زرقاء + إبهام أبيض
  SardReaction.like: '''
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
  <defs><linearGradient id="lk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6CC2FF"/><stop offset="1" stop-color="#1769E8"/></linearGradient></defs>
  <circle cx="24" cy="24" r="22" fill="url(#lk)"/>
  <circle cx="24" cy="24" r="21.2" fill="none" stroke="#ffffff" stroke-opacity=".25" stroke-width="1.2"/>
  <rect x="10.5" y="22" width="7.5" height="15" rx="1.8" fill="#fff"/>
  <path d="M21 23.2 L26.2 11.5 C29.4 11.2 31 13.4 30.4 16.6 L29.2 21 H35.6 C37.8 21 39.2 23 38.6 25 L36.2 33.6 C35.7 35.2 34.3 36.4 32.6 36.4 H21 Z" fill="#fff"/>
</svg>''',
  // حب: دائرة وردية + قلب أبيض
  SardReaction.love: '''
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
  <defs><linearGradient id="lv" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF7A9C"/><stop offset="1" stop-color="#E0245E"/></linearGradient></defs>
  <circle cx="24" cy="24" r="22" fill="url(#lv)"/>
  <circle cx="24" cy="24" r="21.2" fill="none" stroke="#ffffff" stroke-opacity=".25" stroke-width="1.2"/>
  <path d="M24 36 C9.5 27 11.5 14.5 19 14.5 C22 14.5 24 16.7 24 19 C24 16.7 26 14.5 29 14.5 C36.5 14.5 38.5 27 24 36 Z" fill="#fff"/>
  <path d="M16.5 19 C17.3 17.6 18.6 17.2 19.6 17.5" fill="none" stroke="#FF9DB7" stroke-width="1.6" stroke-linecap="round"/>
</svg>''',
  // ضحك: وجه أصفر بعينين مقوّستين وفم مفتوح
  SardReaction.laugh: '''
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
  <defs><radialGradient id="lg" cx=".4" cy=".3" r=".85"><stop offset="0" stop-color="#FFEC8F"/><stop offset="1" stop-color="#FFB000"/></radialGradient></defs>
  <circle cx="24" cy="24" r="22" fill="url(#lg)"/>
  <path d="M11.5 19.5 Q16 12.5 20.5 19.5" fill="none" stroke="#5A3A00" stroke-width="2.8" stroke-linecap="round"/>
  <path d="M27.5 19.5 Q32 12.5 36.5 19.5" fill="none" stroke="#5A3A00" stroke-width="2.8" stroke-linecap="round"/>
  <path d="M11 27 H37 Q37 41 24 41 Q11 41 11 27 Z" fill="#5A2300"/>
  <path d="M13.5 27 H34.5 V30.5 H13.5 Z" fill="#fff"/>
  <path d="M17 37 Q24 30.5 31 37 Q24 42 17 37 Z" fill="#FF6B81"/>
  <ellipse cx="10" cy="26" rx="3.2" ry="2" fill="#FF8A5B" fill-opacity=".45"/>
  <ellipse cx="38" cy="26" rx="3.2" ry="2" fill="#FF8A5B" fill-opacity=".45"/>
</svg>''',
  // ذهول: عينان واسعتان وفم دائري وحاجبان مرفوعان
  SardReaction.wow: '''
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
  <defs><radialGradient id="wg" cx=".4" cy=".3" r=".85"><stop offset="0" stop-color="#FFEC8F"/><stop offset="1" stop-color="#FFB000"/></radialGradient></defs>
  <circle cx="24" cy="24" r="22" fill="url(#wg)"/>
  <path d="M9.5 12.5 Q15 8 21 11.5" fill="none" stroke="#5A3A00" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M27 11.5 Q33 8 38.5 12.5" fill="none" stroke="#5A3A00" stroke-width="2.4" stroke-linecap="round"/>
  <circle cx="16" cy="21" r="5" fill="#fff"/><circle cx="32" cy="21" r="5" fill="#fff"/>
  <circle cx="16.4" cy="21.4" r="2.5" fill="#3A2400"/><circle cx="32.4" cy="21.4" r="2.5" fill="#3A2400"/>
  <circle cx="17.3" cy="20.4" r=".9" fill="#fff"/><circle cx="33.3" cy="20.4" r=".9" fill="#fff"/>
  <ellipse cx="24" cy="35" rx="4.6" ry="6" fill="#5A2300"/>
  <ellipse cx="24" cy="37.6" rx="2.6" ry="2.2" fill="#FF6B81"/>
</svg>''',
  // حزن: حاجبان مائلان وفم مقلوب ودمعة زرقاء
  SardReaction.sad: '''
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
  <defs><radialGradient id="sg" cx=".4" cy=".3" r=".85"><stop offset="0" stop-color="#FFEC8F"/><stop offset="1" stop-color="#F2A100"/></radialGradient></defs>
  <circle cx="24" cy="24" r="22" fill="url(#sg)"/>
  <path d="M10.5 17.5 L20 13" fill="none" stroke="#5A3A00" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M37.5 17.5 L28 13" fill="none" stroke="#5A3A00" stroke-width="2.4" stroke-linecap="round"/>
  <circle cx="16.5" cy="22" r="2.7" fill="#3A2400"/><circle cx="31.5" cy="22" r="2.7" fill="#3A2400"/>
  <path d="M16 36 Q24 28.5 32 36" fill="none" stroke="#5A2300" stroke-width="2.8" stroke-linecap="round"/>
  <path d="M33 26 Q38.5 33 33 37.5 Q27.5 33 33 26 Z" fill="#4FC3F7"/>
  <path d="M31.6 31 Q32 34 34 35" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="1.2" stroke-linecap="round"/>
</svg>''',
};

/// لون تمييز كل تفاعل (للنصوص والحدود)
Color reactionColor(SardReaction r) {
  switch (r) {
    case SardReaction.like:
      return const Color(0xFF3B9EFF);
    case SardReaction.love:
      return const Color(0xFFE0457B);
    case SardReaction.laugh:
    case SardReaction.wow:
    case SardReaction.sad:
      return const Color(0xFFF5A524);
  }
}

/// أيقونة تفاعل SVG
class ReactionIcon extends StatelessWidget {
  const ReactionIcon(this.reaction, {super.key, this.size = 28});
  final SardReaction reaction;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SvgPicture.string(_svgs[reaction]!, width: size, height: size);
  }
}

/// أيقونات التفاعلات الأكثر حضوراً متراكبة قليلاً
class ReactionStack extends StatelessWidget {
  const ReactionStack(this.items, {super.key, this.size = 20, this.ringColor});
  final List<SardReaction> items;
  final double size;
  final Color? ringColor;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    final step = size * 0.68;
    final ring = ringColor ?? Theme.of(context).scaffoldBackgroundColor;
    return SizedBox(
      width: size + step * (items.length - 1),
      height: size,
      child: Stack(
        children: [
          for (var i = items.length - 1; i >= 0; i--)
            PositionedDirectional(
              start: step * i,
              child: Container(
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: ring, width: 1.6)),
                child: ReactionIcon(items[i], size: size - 3),
              ),
            ),
        ],
      ),
    );
  }
}

/// شريط اختيار التفاعل الخمسة بحركة «قفزة» عند الظهور
class ReactionPicker extends StatelessWidget {
  const ReactionPicker({super.key, required this.current, required this.onPick});
  final SardReaction? current;
  final ValueChanged<SardReaction> onPick;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        for (var i = 0; i < SardReaction.values.length; i++)
          _Pick(
            reaction: SardReaction.values[i],
            selected: current == SardReaction.values[i],
            delay: i * 45,
            onTap: () => onPick(SardReaction.values[i]),
          ),
      ],
    );
  }
}

class _Pick extends StatelessWidget {
  const _Pick({required this.reaction, required this.selected, required this.delay, required this.onTap});
  final SardReaction reaction;
  final bool selected;
  final int delay;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 380 + delay),
        curve: Curves.elasticOut,
        builder: (c, v, child) => Transform.scale(scale: 0.3 + 0.7 * v, child: child),
        child: AnimatedScale(
          scale: selected ? 1.22 : 1,
          duration: const Duration(milliseconds: 180),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: selected ? reactionColor(reaction) : Colors.transparent, width: 2),
                ),
                child: ReactionIcon(reaction, size: 36),
              ),
              const SizedBox(height: 3),
              Text(reaction.label, style: TextStyle(fontSize: 10, fontWeight: selected ? FontWeight.w800 : FontWeight.w500, color: selected ? reactionColor(reaction) : null)),
            ],
          ),
        ),
      ),
    );
  }
}
