import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/data/models.dart';
import '../core/data/repository.dart';
import '../core/data/social_repository.dart';
import '../core/theme/app_themes.dart';
import '../features/account/user_profile_screen.dart';
import 'fx.dart';
import 'reaction_icons.dart';
import 'sard_icons.dart';
import 'verified_badge.dart';

/// صورة من رابط أو ملف محلي
Widget postImage(String src, {BoxFit fit = BoxFit.cover}) {
  if (src.startsWith('http')) {
    return CachedNetworkImage(
      imageUrl: src,
      fit: fit,
      placeholder: (c, _) => Container(color: tint(Colors.grey, 0.15)),
      errorWidget: (c, _, __) => Container(color: tint(Colors.grey, 0.15), child: const Icon(Icons.broken_image_outlined)),
    );
  }
  return Image.file(File(src), fit: fit, errorBuilder: (c, _, __) => Container(color: tint(Colors.grey, 0.15), child: const Icon(Icons.broken_image_outlined)));
}

/// عرض الصور بملء الشاشة مع تكبير وتمرير
void openImageViewer(BuildContext context, List<String> images, int start) {
  Navigator.of(context).push(PageRouteBuilder<void>(
    opaque: false,
    barrierColor: Colors.black87,
    pageBuilder: (c, a, b) => FadeTransition(
      opacity: a,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: Colors.white, elevation: 0),
        body: PageView.builder(
          controller: PageController(initialPage: start),
          itemCount: images.length,
          itemBuilder: (c, i) => InteractiveViewer(minScale: 1, maxScale: 4, child: Center(child: postImage(images[i], fit: BoxFit.contain))),
        ),
      ),
    ),
  ));
}

class PostImages extends StatelessWidget {
  const PostImages(this.images, {super.key});
  final List<String> images;

  @override
  Widget build(BuildContext context) {
    final n = images.length;
    if (n == 0) return const SizedBox.shrink();
    Widget tile(int i, {double? ratio}) {
      final w = GestureDetector(onTap: () => openImageViewer(context, images, i), child: postImage(images[i]));
      return ratio == null ? w : AspectRatio(aspectRatio: ratio, child: w);
    }

    Widget body;
    if (n == 1) {
      body = tile(0, ratio: 16 / 10);
    } else if (n == 2) {
      body = Row(children: [Expanded(child: tile(0, ratio: 1)), const SizedBox(width: 3), Expanded(child: tile(1, ratio: 1))]);
    } else if (n == 3) {
      body = Column(children: [
        tile(0, ratio: 16 / 9),
        const SizedBox(height: 3),
        Row(children: [Expanded(child: tile(1, ratio: 1.3)), const SizedBox(width: 3), Expanded(child: tile(2, ratio: 1.3))]),
      ]);
    } else {
      body = Column(children: [
        Row(children: [Expanded(child: tile(0, ratio: 1.3)), const SizedBox(width: 3), Expanded(child: tile(1, ratio: 1.3))]),
        const SizedBox(height: 3),
        Row(children: [Expanded(child: tile(2, ratio: 1.3)), const SizedBox(width: 3), Expanded(child: tile(3, ratio: 1.3))]),
      ]);
    }
    return ClipRRect(borderRadius: BorderRadius.circular(16), child: body);
  }
}

/// استفتاء: اضغط خياراً للتصويت، وتظهر النتائج بعد التصويت. اضغطه مجدداً لسحب صوتك.
class PollView extends StatelessWidget {
  const PollView({super.key, required this.poll, required this.onVote});
  final SardPoll poll;
  final ValueChanged<String> onVote;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final voted = poll.myVote != null;
    final total = poll.totalVotes;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: p.bg, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            SIcon(SardIcons.playlist_add_check_rounded, size: 20, color: p.accent),
            const SizedBox(width: 8),
            Expanded(child: Text(poll.question, style: context.ts(size: 14, w: FontWeight.w800, height: 1.5))),
          ]),
          const SizedBox(height: 10),
          for (final o in poll.options)
            Builder(builder: (c) {
              final mine = o.id == poll.myVote;
              final frac = total == 0 ? 0.0 : o.votes / total;
              return Pressable(
                scale: 0.985,
                onTap: () => onVote(o.id),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  height: 44,
                  decoration: BoxDecoration(
                    color: p.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: mine ? p.accent : p.border, width: mine ? 1.6 : 1),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    children: [
                      if (voted)
                        Positioned.fill(
                          child: Align(
                            alignment: AlignmentDirectional.centerStart,
                            child: TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0, end: frac),
                              duration: const Duration(milliseconds: 600),
                              curve: Curves.easeOutCubic,
                              builder: (c, v, _) => FractionallySizedBox(widthFactor: v, child: Container(color: tint(p.accent, mine ? 0.28 : 0.14))),
                            ),
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Row(children: [
                          if (voted && mine) ...[Icon(Icons.check_circle_rounded, size: 18, color: p.accent), const SizedBox(width: 6)],
                          Expanded(child: Text(o.text, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.ts(size: 13, w: mine ? FontWeight.w800 : FontWeight.w600))),
                          if (voted) Text('${(frac * 100).round()}%', style: context.ts(size: 12.5, w: FontWeight.w800, color: mine ? p.accent : p.textDim)),
                        ]),
                      ),
                    ],
                  ),
                ),
              );
            }),
          Text('$total صوت${voted ? ' · اضغط خيارك لسحب صوتك' : ''}', style: context.ts(size: 11, color: p.textDim)),
        ],
      ),
    );
  }
}

/// بطاقة منشور كاملة: كاتب + نص + صور + استفتاء + تفاعلات SVG + تعليقات
class PostCard extends StatefulWidget {
  const PostCard({super.key, required this.post, this.onOpenComments});
  final SardPost post;

  /// null = نحن داخل صفحة التعليقات أصلاً
  final VoidCallback? onOpenComments;

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  late SardPost _post;
  bool _picker = false;

  @override
  void initState() {
    super.initState();
    _post = widget.post;
  }

  @override
  void didUpdateWidget(covariant PostCard old) {
    super.didUpdateWidget(old);
    if (!identical(old.post, widget.post)) _post = widget.post;
  }

  Future<void> _react(SardReaction r) async {
    final old = _post;
    final next = r == old.myReaction ? null : r;
    setState(() {
      _post = old.react(next);
      _picker = false;
    });
    try {
      await context.read<SardRepository>().reactPost(old.id, next);
    } catch (_) {
      if (mounted) setState(() => _post = old);
    }
  }

  Future<void> _vote(String optionId) async {
    final old = _post;
    final poll = old.poll;
    if (poll == null) return;
    final next = optionId == poll.myVote ? null : optionId;
    setState(() => _post = old.copyWith(poll: poll.withVote(next)));
    try {
      await context.read<SardRepository>().votePoll(old.id, next);
    } catch (_) {
      if (mounted) setState(() => _post = old);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final post = _post;
    final mine = post.myReaction;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: p.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: p.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Pressable(
                scale: 0.985,
                onTap: () => openUserProfile(context, id: post.authorId, name: post.author, badge: post.badge),
                child: Row(children: [
                  RingAvatar(name: post.author, badge: post.badge, size: 40),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      NameWithBadge(post.author, post.badge, style: context.ts(size: 14, w: FontWeight.w700)),
                      Text(post.createdAt, style: context.ts(size: 11, color: p.textDim)),
                    ]),
                  ),
                ]),
              ),
            ),
            if (post.tag.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: tint(p.accent, 0.14), borderRadius: BorderRadius.circular(99)),
                child: Text(post.tag, style: context.ts(size: 11, w: FontWeight.w700, color: p.accent)),
              ),
          ]),
          if (post.body.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(post.body, style: context.ts(size: 14, height: 1.7)),
          ],
          if (post.images.isNotEmpty) ...[const SizedBox(height: 12), PostImages(post.images)],
          if (post.poll != null) ...[const SizedBox(height: 12), PollView(poll: post.poll!, onVote: _vote)],
          const SizedBox(height: 12),
          Row(children: [
            ReactionStack(post.topReactions, ringColor: p.surface),
            if (post.likes > 0) ...[const SizedBox(width: 8), Text('${post.likes}', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.textDim))],
            const Spacer(),
            if (post.comments > 0) Text('${post.comments} تعليق', style: context.ts(size: 12, color: p.textDim)),
          ]),
          const SizedBox(height: 8),
          Divider(height: 1, color: p.border),
          AnimatedSize(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutCubic,
            alignment: Alignment.topCenter,
            child: _picker
                ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: ReactionPicker(current: mine, onPick: _react),
                  )
                : const SizedBox(width: double.infinity),
          ),
          const SizedBox(height: 4),
          Row(children: [
            Expanded(
              child: Pressable(
                onTap: () => setState(() => _picker = !_picker),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    if (mine != null) ReactionIcon(mine, size: 24) else SIcon(SardIcons.thumb_up_off_alt_rounded, size: 21, color: p.textDim),
                    const SizedBox(width: 7),
                    Text(mine?.label ?? 'تفاعل', style: context.ts(size: 12.5, w: FontWeight.w700, color: mine != null ? reactionColor(mine) : p.textDim)),
                  ]),
                ),
              ),
            ),
            Expanded(
              child: Pressable(
                onTap: widget.onOpenComments,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SIcon(SardIcons.chat_bubble_outline_rounded, size: 20, color: p.textDim),
                    const SizedBox(width: 7),
                    Text('تعليق', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.textDim)),
                  ]),
                ),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}
