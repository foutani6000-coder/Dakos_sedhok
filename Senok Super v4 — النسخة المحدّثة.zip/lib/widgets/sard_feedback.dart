import 'dart:math' as math;
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme/app_themes.dart';
import 'sard_icons.dart';

/// تفاعل احترافي: أيقونة كبيرة تنبض وتتطاير منها جسيمات، ثم إشعار زجاجي
/// ينزلق من الأعلى («تمت المتابعة»، «أُضيف إلى المفضلة»...).
class SardFeedback {
  SardFeedback._();

  static OverlayEntry? _toast;
  static OverlayEntry? _burst;

  /// نبضة كبيرة + إشعار. [burst] يُعطَّل عند الإزالة (مثلاً إلغاء المتابعة).
  static void celebrate(
    BuildContext context, {
    required SIconData icon,
    required Color color,
    required String title,
    String? subtitle,
    bool burst = true,
  }) {
    if (burst) {
      HapticFeedback.mediumImpact();
      _showBurst(context, icon, color);
    } else {
      HapticFeedback.selectionClick();
    }
    _showToast(context, icon, color, title, subtitle);
  }

  static void _showBurst(BuildContext context, SIconData icon, Color color) {
    final overlay = Overlay.maybeOf(context, rootOverlay: true);
    if (overlay == null) return;
    _burst?.remove();
    late final OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => _BurstView(
        icon: icon,
        color: color,
        onDone: () {
          if (_burst == entry) _burst = null;
          entry.remove();
        },
      ),
    );
    _burst = entry;
    overlay.insert(entry);
  }

  static void _showToast(
    BuildContext context,
    SIconData icon,
    Color color,
    String title,
    String? subtitle,
  ) {
    final overlay = Overlay.maybeOf(context, rootOverlay: true);
    if (overlay == null) return;
    final p = context.pal;
    final titleStyle = context.ts(size: 14.5, w: FontWeight.w800, color: Colors.white);
    final subStyle = context.ts(size: 12, color: const Color(0xCCFFFFFF));
    _toast?.remove();
    late final OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => _ToastView(
        icon: icon,
        color: color,
        title: title,
        subtitle: subtitle,
        titleStyle: titleStyle,
        subStyle: subStyle,
        surface: p.surface,
        onDone: () {
          if (_toast == entry) _toast = null;
          entry.remove();
        },
      ),
    );
    _toast = entry;
    overlay.insert(entry);
  }
}

// ───────── نبضة القلب/العلامة الكبيرة ─────────

class _BurstView extends StatefulWidget {
  const _BurstView({required this.icon, required this.color, required this.onDone});
  final SIconData icon;
  final Color color;
  final VoidCallback onDone;

  @override
  State<_BurstView> createState() => _BurstViewState();
}

class _BurstViewState extends State<_BurstView> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1150))
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) widget.onDone();
      })
      ..forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          // تكبير مرن في أول 45% ثم تلاشي
          final pop = Curves.elasticOut.transform((t / 0.45).clamp(0.0, 1.0));
          final fade = t < 0.6 ? 1.0 : (1 - (t - 0.6) / 0.4).clamp(0.0, 1.0);
          final ring = Curves.easeOutCubic.transform((t / 0.7).clamp(0.0, 1.0));
          return Stack(
            alignment: Alignment.center,
            children: [
              // هالة خلفية ناعمة
              Opacity(
                opacity: fade * 0.9,
                child: Container(
                  width: 260 * (0.4 + ring * 0.6),
                  height: 260 * (0.4 + ring * 0.6),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        tint(widget.color, 0.38 * (1 - ring * 0.6)),
                        tint(widget.color, 0),
                      ],
                    ),
                  ),
                ),
              ),
              // جسيمات متطايرة
              CustomPaint(
                size: const Size(300, 300),
                painter: _ParticlesPainter(progress: ring, fade: fade, color: widget.color),
              ),
              // الأيقونة الكبيرة
              Opacity(
                opacity: fade,
                child: Transform.scale(
                  scale: 0.2 + pop * 0.8,
                  child: SIcon(widget.icon, size: 124, color: widget.color, animate: false),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ParticlesPainter extends CustomPainter {
  _ParticlesPainter({required this.progress, required this.fade, required this.color});
  final double progress;
  final double fade;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    const n = 14;
    for (var i = 0; i < n; i++) {
      final a = (i / n) * math.pi * 2 + (i.isEven ? 0.0 : 0.18);
      final dist = 54 + (i.isEven ? 78 : 56) * progress;
      final r = (i.isEven ? 5.5 : 3.5) * (1 - progress * 0.55);
      final pos = c + Offset(math.cos(a), math.sin(a)) * dist;
      final paint = Paint()
        ..color = tint(i % 3 == 0 ? Colors.white : color, fade * 0.95);
      canvas.drawCircle(pos, r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlesPainter old) =>
      old.progress != progress || old.fade != fade || old.color != color;
}

// ───────── الإشعار الزجاجي ─────────

class _ToastView extends StatefulWidget {
  const _ToastView({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.titleStyle,
    required this.subStyle,
    required this.surface,
    required this.onDone,
  });
  final SIconData icon;
  final Color color;
  final String title;
  final String? subtitle;
  final TextStyle titleStyle;
  final TextStyle subStyle;
  final Color surface;
  final VoidCallback onDone;

  @override
  State<_ToastView> createState() => _ToastViewState();
}

class _ToastViewState extends State<_ToastView> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2900))
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) widget.onDone();
      })
      ..forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Positioned(
      top: top + 12,
      left: 18,
      right: 18,
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, child) {
            final t = _c.value;
            final inT = Curves.easeOutBack.transform((t / 0.14).clamp(0.0, 1.0));
            final outT = t > 0.86 ? ((t - 0.86) / 0.14).clamp(0.0, 1.0) : 0.0;
            final opacity = (inT.clamp(0.0, 1.0)) * (1 - outT);
            final dy = (1 - inT) * -46 + outT * -26;
            return Opacity(
              opacity: opacity,
              child: Transform.translate(offset: Offset(0, dy), child: child),
            );
          },
          child: Material(
            type: MaterialType.transparency,
            child: Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 420),
                    padding: const EdgeInsets.fromLTRB(12, 10, 18, 10),
                    decoration: BoxDecoration(
                      color: Color.alphaBlend(
                        tint(widget.color, 0.16),
                        tint(widget.surface, 0.92),
                      ),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: tint(widget.color, 0.55), width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: tint(widget.color, 0.30),
                          blurRadius: 22,
                          offset: const Offset(0, 6),
                        ),
                        const BoxShadow(color: Color(0x55000000), blurRadius: 14, offset: Offset(0, 6)),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: widget.color,
                            boxShadow: [
                              BoxShadow(color: tint(widget.color, 0.5), blurRadius: 12),
                            ],
                          ),
                          child: Center(
                            child: SIcon(widget.icon, size: 22, color: Colors.white, animate: false),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Flexible(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(widget.title, style: widget.titleStyle, maxLines: 1, overflow: TextOverflow.ellipsis),
                              if (widget.subtitle != null) ...[
                                const SizedBox(height: 2),
                                Text(widget.subtitle!, style: widget.subStyle, maxLines: 1, overflow: TextOverflow.ellipsis),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
