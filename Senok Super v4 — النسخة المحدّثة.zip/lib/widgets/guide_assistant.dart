import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/guide/guide_content.dart';
import '../core/guide/guide_controller.dart';
import '../core/theme/app_themes.dart';
import 'ink_spirit.dart';

const String kAssistantGif = 'assets/assistant/sarda.gif';

/// يغلّف التطبيق كله (يُوضع في MaterialApp.builder) ويرسم المساعدة
/// فوق أي شاشة أو قائمة أو نافذة سفلية.
class GuideOverlay extends StatelessWidget {
  const GuideOverlay({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final c = GuideController.instance;
    return AnimatedBuilder(
      animation: c,
      builder: (context, _) {
        final r = c.current;
        return Stack(
          fit: StackFit.expand,
          children: [
            child,
            if (r != null) _GuideLayer(key: ValueKey<String>(r.id), request: r, step: c.step),
          ],
        );
      },
    );
  }
}

class _GuideLayer extends StatefulWidget {
  const _GuideLayer({super.key, required this.request, required this.step});
  final GuideRequest request;
  final int step;

  @override
  State<_GuideLayer> createState() => _GuideLayerState();
}

class _GuideLayerState extends State<_GuideLayer> with TickerProviderStateMixin {
  late final AnimationController _float = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2400),
  )..repeat(reverse: true);

  late final AnimationController _enter = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 460),
  )..forward();

  @override
  void dispose() {
    _float.dispose();
    _enter.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final mq = MediaQuery.of(context);
    final c = GuideController.instance;
    final req = widget.request;
    final steps = req.entry.steps;
    final step = widget.step.clamp(0, steps.length - 1).toInt();
    final last = step >= steps.length - 1;
    final radius = p.r(1.3).clamp(16.0, 30.0).toDouble();

    final card = AnimatedBuilder(
      animation: _enter,
      builder: (context, child) {
        final t = Curves.easeOutBack.transform(_enter.value.clamp(0.0, 1.0).toDouble());
        return Opacity(
          opacity: Curves.easeOut.transform(_enter.value.clamp(0.0, 1.0).toDouble()),
          child: Transform.translate(offset: Offset(0, (1 - t) * 40), child: child),
        );
      },
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // الفقاعة
          Container(
            constraints: const BoxConstraints(minHeight: 124),
            padding: const EdgeInsetsDirectional.fromSTEB(112, 12, 14, 12),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(color: tint(p.accent, 0.55), width: 1.2),
              boxShadow: [
                ...softShadow(p, strength: 1.4),
                BoxShadow(color: tint(p.accent, 0.22), blurRadius: 24),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '$kAssistantName · ${req.entry.title}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.ds(size: 14, color: p.accent),
                      ),
                    ),
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: c.dismiss,
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Icon(Icons.close_rounded, size: 18, color: p.textDim),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                _Typewriter(
                  key: ValueKey<String>('${req.id}-$step'),
                  text: steps[step],
                  style: context.ts(size: 13, color: p.text, height: 1.65),
                ),
                const SizedBox(height: 10),
                Wrap(
                  alignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  runSpacing: 6,
                  spacing: 8,
                  children: [
                    if (steps.length > 1)
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (var i = 0; i < steps.length; i++)
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 250),
                              margin: const EdgeInsetsDirectional.only(end: 5),
                              width: i == step ? 18 : 7,
                              height: 7,
                              decoration: BoxDecoration(
                                color: i == step ? p.accent : tint(p.textDim, 0.4),
                                borderRadius: BorderRadius.circular(9),
                              ),
                            ),
                        ],
                      ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: c.stopAll,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                            child: Text(
                              'إيقاف المساعدة',
                              style: context.ts(size: 11, color: p.textDim),
                            ),
                          ),
                        ),
                        const SizedBox(width: 4),
                        FilledButton(
                          onPressed: c.next,
                          style: FilledButton.styleFrom(
                            minimumSize: const Size(0, 38),
                            padding: const EdgeInsets.symmetric(horizontal: 18),
                            backgroundColor: p.accent,
                            foregroundColor: p.onAccent,
                          ),
                          child: Text(
                            last ? (req.blocking ? 'فهمت، تابع' : 'فهمت') : 'التالي',
                            style: context.ts(size: 13, w: FontWeight.w700, color: p.onAccent),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          // الشخصية (تطفو بحركة خفيفة فوق حافة الفقاعة)
          PositionedDirectional(
            start: 2,
            bottom: 2,
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _float,
                builder: (context, child) {
                  final t = Curves.easeInOut.transform(_float.value);
                  return Transform.translate(offset: Offset(0, -5 * t), child: child);
                },
                child: Image.asset(
                  kAssistantGif,
                  width: 112,
                  fit: BoxFit.contain,
                  gaplessPlayback: true,
                  filterQuality: FilterQuality.medium,
                  errorBuilder: (_, __, ___) => const Padding(
                    padding: EdgeInsets.all(18),
                    child: LogoMark(size: 64, glow: true),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );

    return Stack(
      fit: StackFit.expand,
      children: [
        if (req.blocking)
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {},
              child: ColoredBox(color: tint(Colors.black, 0.55)),
            ),
          ),
        Positioned(
          left: 12,
          right: 12,
          bottom: mq.padding.bottom + 10 + req.lift,
          child: Material(
            type: MaterialType.transparency,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: card,
            ),
          ),
        ),
      ],
    );
  }
}

/// نص بتأثير الكتابة الحرفية. لمسه يُكمل النص فوراً.
class _Typewriter extends StatefulWidget {
  const _Typewriter({super.key, required this.text, required this.style});
  final String text;
  final TextStyle style;

  @override
  State<_Typewriter> createState() => _TypewriterState();
}

class _TypewriterState extends State<_Typewriter> {
  Timer? _t;
  int _n = 0;
  late int _len = widget.text.characters.length;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (MediaQuery.of(context).disableAnimations) {
        setState(() => _n = _len);
        return;
      }
      _t = Timer.periodic(const Duration(milliseconds: 24), (t) {
        if (!mounted) return t.cancel();
        setState(() => _n = math.min(_n + 1, _len));
        if (_n >= _len) t.cancel();
      });
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final shown = widget.text.characters.take(_n).toString();
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        _t?.cancel();
        setState(() => _n = _len);
      },
      // النص الكامل غير مرئي لحجز الارتفاع فلا تقفز الفقاعة أثناء الكتابة
      child: Stack(
        children: [
          Opacity(opacity: 0, child: Text(widget.text, style: widget.style)),
          Text(shown, style: widget.style),
        ],
      ),
    );
  }
}

/// يعرض شرح شاشة عند فتحها لأول مرة.
class GuideOnEnter extends StatefulWidget {
  const GuideOnEnter({
    super.key,
    required this.id,
    required this.child,
    this.delay = const Duration(milliseconds: 650),
    this.lift = 0,
  });
  final String id;
  final Widget child;
  final Duration delay;
  final double lift;

  @override
  State<GuideOnEnter> createState() => _GuideOnEnterState();
}

class _GuideOnEnterState extends State<GuideOnEnter> {
  @override
  void initState() {
    super.initState();
    if (!GuideController.instance.hasSeen(widget.id)) {
      Future<void>.delayed(widget.delay, () {
        if (!mounted) return;
        // لا نشرح شاشة غُطّيت بشاشة أخرى قبل أن تُعرض
        if (ModalRoute.of(context)?.isCurrent == false) return;
        GuideController.instance.show(widget.id, lift: widget.lift);
      });
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
