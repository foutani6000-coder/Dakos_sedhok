import 'dart:math' as math;

import 'package:flutter/material.dart';

/// نسبة العرض/الارتفاع لصفحة تجريبية
const double kMockPageRatio = 0.72;

/// صفحة مانغا تجريبية بالأبيض والأسود تُرسم محلياً (عند ترك API_BASE_URL فارغاً).
/// الرابط على شكل mock:<seed>:<page>:<total>
class MockPage extends StatelessWidget {
  const MockPage({super.key, required this.src});
  final String src;

  @override
  Widget build(BuildContext context) {
    final parts = src.split(':');
    final seed = int.tryParse(parts.length > 1 ? parts[1] : '') ?? 1;
    final page = int.tryParse(parts.length > 2 ? parts[2] : '') ?? 1;
    final total = int.tryParse(parts.length > 3 ? parts[3] : '') ?? 1;
    return AspectRatio(
      aspectRatio: kMockPageRatio,
      child: CustomPaint(
        painter: _MockPagePainter(seed * 131 + page, page, total),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _MockPagePainter extends CustomPainter {
  _MockPagePainter(this.seed, this.page, this.total);
  final int seed;
  final int page;
  final int total;

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(seed);
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFFF7F7F5));

    // شبكة لوحات (panels) عشوائية
    const m = 14.0;
    final rows = 3 + r.nextInt(2);
    var y = m;
    final usable = size.height - m * 2 - (rows - 1) * m;
    for (var i = 0; i < rows; i++) {
      final h = usable / rows * (0.8 + r.nextDouble() * 0.4);
      final bottom = i == rows - 1 ? size.height - m : math.min(y + h, size.height - m - 40);
      if (bottom - y < 24) break;
      final cols = r.nextBool() ? 1 : 2;
      final w = (size.width - m * 2 - (cols - 1) * m) / cols;
      for (var c = 0; c < cols; c++) {
        final rect = Rect.fromLTRB(m + c * (w + m), y, m + c * (w + m) + w, bottom);
        _panel(canvas, rect, r);
      }
      y = bottom + m;
      if (y > size.height - m - 30) break;
    }

    // رقم الصفحة
    final tp = TextPainter(
      text: TextSpan(
        text: '$page / $total',
        style: const TextStyle(color: Color(0xFF111111), fontSize: 11, fontWeight: FontWeight.w600),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset((size.width - tp.width) / 2, size.height - 12 - tp.height / 2));
  }

  void _panel(Canvas canvas, Rect rect, math.Random r) {
    canvas.save();
    canvas.clipRect(rect);
    final tone = r.nextInt(3);
    canvas.drawRect(
      rect,
      Paint()..color = [const Color(0xFFFFFFFF), const Color(0xFFDADADA), const Color(0xFF1A1A1A)][tone],
    );
    final ink = Paint()
      ..color = tone == 2 ? const Color(0xFFEDEDED) : const Color(0xFF111111)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1;

    // خطوط سرعة
    if (r.nextBool()) {
      final c = rect.center + Offset((r.nextDouble() - .5) * rect.width * .4, (r.nextDouble() - .5) * rect.height * .3);
      for (var i = 0; i < 46; i++) {
        final a = i / 46 * math.pi * 2;
        final r1 = rect.shortestSide * (0.16 + r.nextDouble() * .08);
        final r2 = rect.longestSide * (0.7 + r.nextDouble() * .3);
        canvas.drawLine(c + Offset(math.cos(a), math.sin(a)) * r1, c + Offset(math.cos(a), math.sin(a)) * r2, ink);
      }
    }
    // شخصية مبسّطة: دائرة + كتلة
    final cx = rect.left + rect.width * (0.3 + r.nextDouble() * 0.4);
    final headR = rect.shortestSide * (0.12 + r.nextDouble() * 0.06);
    final cy = rect.top + rect.height * (0.35 + r.nextDouble() * 0.2);
    final fill = Paint()..color = tone == 2 ? const Color(0xFFF2F2F2) : const Color(0xFF0D0D0D);
    canvas.drawCircle(Offset(cx, cy), headR, fill);
    final body = Path()
      ..moveTo(cx - headR * 1.6, rect.bottom)
      ..quadraticBezierTo(cx - headR * 1.2, cy + headR * 1.4, cx, cy + headR * 1.2)
      ..quadraticBezierTo(cx + headR * 1.2, cy + headR * 1.4, cx + headR * 1.6, rect.bottom)
      ..close();
    canvas.drawPath(body, fill);
    // فقاعة كلام
    if (r.nextBool() && rect.width > 90) {
      final b = Rect.fromLTWH(rect.left + 10 + r.nextDouble() * 10, rect.top + 10, rect.width * .42, 26 + r.nextDouble() * 14);
      canvas.drawOval(b, Paint()..color = Colors.white);
      canvas.drawOval(b, Paint()..color = const Color(0xFF111111)..style = PaintingStyle.stroke..strokeWidth = 1.4);
      for (var i = 0; i < 2; i++) {
        canvas.drawLine(Offset(b.left + 14, b.center.dy - 4 + i * 8), Offset(b.right - 14 - r.nextDouble() * 12, b.center.dy - 4 + i * 8),
            Paint()..color = const Color(0xFF555555)..strokeWidth = 2..strokeCap = StrokeCap.round);
      }
    }
    canvas.restore();
    canvas.drawRect(rect, Paint()..color = const Color(0xFF0A0A0A)..style = PaintingStyle.stroke..strokeWidth = 2.2);
  }

  @override
  bool shouldRepaint(covariant _MockPagePainter old) => old.seed != seed;
}
