import 'package:flutter/material.dart';

import '../core/theme/app_themes.dart';
import 'sard_icons.dart';

class NavItem {
  const NavItem(this.icon, this.activeIcon, this.label, this.color);
  final SIconData icon;
  final SIconData activeIcon;
  final String label;

  /// لون الزر (يظهر كخلفية عند التحديد وكلون للأيقونة قبل ذلك)
  final Color color;
}

/// شريط تنقّل عائم مرتبط بحركة الـ PageView نفسها:
/// أثناء سحب الصفحات يتمدّد الزر القادم ويتقلّص السابق تدريجياً مع
/// انتقال اللون بينهما، فلا توجد قفزات بل انزلاق متصل.
class SardNavBar extends StatelessWidget {
  const SardNavBar({
    super.key,
    required this.controller,
    required this.items,
    required this.onTap,
  });

  final PageController controller;
  final List<NavItem> items;
  final ValueChanged<int> onTap;

  double _page() {
    if (controller.hasClients && controller.position.haveDimensions) {
      return controller.page ?? controller.initialPage.toDouble();
    }
    return controller.initialPage.toDouble();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ColoredBox(
      color: p.bg,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: p.glass ? tint(p.surface, 0.82) : p.surface,
              borderRadius: BorderRadius.circular(p.r(1.5).clamp(14.0, 30.0).toDouble()),
              border: Border.all(color: p.border, width: p.borderW),
              boxShadow: [
                BoxShadow(
                  color: tint(Colors.black, p.isDark ? 0.5 : 0.1),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
                if (p.glow > 0)
                  BoxShadow(color: tint(p.accent, 0.18 * p.glow), blurRadius: 22),
              ],
            ),
            child: AnimatedBuilder(
              animation: controller,
              builder: (context, _) {
                final page = _page();
                return Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    for (var i = 0; i < items.length; i++)
                      _NavButton(
                        item: items[i],
                        t: (1 - (page - i).abs()).clamp(0.0, 1.0).toDouble(),
                        onTap: () => onTap(i),
                      ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  const _NavButton({required this.item, required this.t, required this.onTap});
  final NavItem item;

  /// مقدار التحديد من 0 إلى 1 (متصل أثناء السحب)
  final double t;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = item.color;
    final onC = c.computeLuminance() > 0.5 ? const Color(0xFF1A1410) : Colors.white;
    final fg = Color.lerp(tint(c, 0.9), onC, t)!;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        height: 48,
        padding: EdgeInsets.symmetric(horizontal: 10 + 4 * t),
        decoration: BoxDecoration(
          color: Color.lerp(tint(c, 0.12), c, t),
          borderRadius: BorderRadius.circular(p.r(1.2).clamp(10.0, 24.0).toDouble()),
          boxShadow: t > 0.02
              ? [
                  BoxShadow(color: tint(c, 0.42 * t), blurRadius: 14 * t, offset: Offset(0, 4 * t)),
                  if (p.glow > 0) BoxShadow(color: tint(c, 0.35 * p.glow * t), blurRadius: 20 * t),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SIcon(t > 0.5 ? item.activeIcon : item.icon, size: 23, color: fg),
            ClipRect(
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                widthFactor: t,
                child: Opacity(
                  opacity: t,
                  child: Padding(
                    padding: const EdgeInsetsDirectional.only(start: 7),
                    child: Text(
                      item.label,
                      maxLines: 1,
                      softWrap: false,
                      style: context.ts(size: 11.5, w: FontWeight.w800, color: fg),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
