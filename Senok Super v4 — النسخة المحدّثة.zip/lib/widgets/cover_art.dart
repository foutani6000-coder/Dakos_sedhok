import 'dart:math' as math;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../core/data/models.dart';

/// لون مميّز ثابت لكل عمل (يُشتق من رقمه، ويطابق ألوان الغلاف المولَّد).
/// يُستعمل في الوهج المحيط والظلال الملوّنة والتدرّجات.
Color seriesTone(Series s, {double saturation = 0.62, double lightness = 0.5}) {
  final hue = ((s.seed % 360) + 20) % 360;
  return HSLColor.fromAHSL(1, hue.toDouble(), saturation, lightness).toColor();
}

/// غلاف العمل: صورة من السيرفر، أو غلاف فني ملوّن يُولَّد من رقم العمل.
class CoverArt extends StatelessWidget {
  const CoverArt({
    super.key,
    required this.series,
    this.radius = 16,
    this.showTitle = true,
  });

  final Series series;
  final double radius;
  final bool showTitle;

  @override
  Widget build(BuildContext context) {
    final url = series.cover;
    final fallback = _InkCover(series: series, showTitle: showTitle);
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: (url == null || url.isEmpty)
          ? fallback
          : LayoutBuilder(
              builder: (context, constraints) {
                final dpr = MediaQuery.devicePixelRatioOf(context);
                final logicalWidth = constraints.maxWidth.isFinite
                    ? constraints.maxWidth
                    : 240.0;
                final cacheWidth = (logicalWidth * dpr).round().clamp(160, 1200);
                return CachedNetworkImage(
                  imageUrl: url,
                  fit: BoxFit.cover,
                  memCacheWidth: cacheWidth,
                  maxWidthDiskCache: cacheWidth,
                  fadeInDuration: const Duration(milliseconds: 220),
                  fadeOutDuration: const Duration(milliseconds: 100),
                  placeholder: (context, u) => fallback,
                  errorWidget: (context, u, e) => fallback,
                );
              },
            ),
    );
  }
}

class _InkCover extends StatelessWidget {
  const _InkCover({required this.series, required this.showTitle});
  final Series series;
  final bool showTitle;

  @override
  Widget build(BuildContext context) {
    final letter = series.title.isEmpty ? '' : series.title.substring(0, 1);
    return Stack(
      fit: StackFit.expand,
      children: [
        CustomPaint(painter: _InkPainter(series.seed)),
        Center(
          child: Text(
            letter,
            style: TextStyle(
              fontSize: 96,
              fontWeight: FontWeight.w800,
              color: Colors.white.withAlpha(30),
              height: 1,
            ),
          ),
        ),
      ],
    );
  }
}

/// غلاف مولَّد: تدرّج لوني عميق + شمس/قمر + حلقات + شرطات قطرية.
/// كل عمل يأخذ لوناً مختلفاً بحسب رقمه.
class _InkPainter extends CustomPainter {
  _InkPainter(this.seed);
  final int seed;

  @override
  void paint(Canvas canvas, Size size) {
    final r = math.Random(seed);
    final rect = Offset.zero & size;
    final hue = (seed % 360).toDouble();
    final top = HSLColor.fromAHSL(1, hue, 0.55, 0.26 + r.nextDouble() * 0.08).toColor();
    final mid = HSLColor.fromAHSL(1, (hue + 28) % 360, 0.5, 0.16).toColor();
    final bottom = HSLColor.fromAHSL(1, (hue + 50) % 360, 0.45, 0.06).toColor();
    final flip = r.nextBool();

    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: flip ? Alignment.topLeft : Alignment.topRight,
          end: flip ? Alignment.bottomRight : Alignment.bottomLeft,
          colors: [top, mid, bottom],
          stops: const [0, 0.55, 1],
        ).createShader(rect),
    );

    // شمس كبيرة بتدرّج
    final sun = Offset(
      size.width * (0.25 + r.nextDouble() * 0.5),
      size.height * (0.2 + r.nextDouble() * 0.22),
    );
    final sunR = size.shortestSide * (0.2 + r.nextDouble() * 0.12);
    canvas.drawCircle(
      sun,
      sunR,
      Paint()
        ..shader = RadialGradient(
          colors: [
            HSLColor.fromAHSL(0.55, (hue + 20) % 360, 0.9, 0.7).toColor(),
            HSLColor.fromAHSL(0.0, (hue + 20) % 360, 0.9, 0.6).toColor(),
          ],
        ).createShader(Rect.fromCircle(center: sun, radius: sunR * 1.5)),
    );
    canvas.drawCircle(
      sun,
      sunR * 0.7,
      Paint()..color = HSLColor.fromAHSL(0.5, (hue + 15) % 360, 0.85, 0.78).toColor(),
    );

    // حلقات
    for (var i = 0; i < 4; i++) {
      final c = Offset(r.nextDouble() * size.width, r.nextDouble() * size.height);
      final rad = size.shortestSide * (0.15 + r.nextDouble() * 0.5);
      canvas.drawCircle(
        c,
        rad,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1 + r.nextDouble() * 1.4
          ..color = Colors.white.withAlpha(14 + r.nextInt(24)),
      );
    }

    // شرطات سيف قطرية
    for (var i = 0; i < 4; i++) {
      final x = r.nextDouble() * size.width;
      final y = r.nextDouble() * size.height;
      final len = size.shortestSide * (0.4 + r.nextDouble() * 0.6);
      canvas.drawLine(
        Offset(x, y),
        Offset(x + len * 0.55, y - len),
        Paint()
          ..strokeWidth = 1.5 + r.nextDouble() * 2.5
          ..strokeCap = StrokeCap.round
          ..color = Colors.white.withAlpha(16 + r.nextInt(26)),
      );
    }

    // ظلّ سفلي
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.center,
          end: Alignment.bottomCenter,
          colors: [Colors.transparent, Colors.black.withAlpha(150)],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(covariant _InkPainter old) => old.seed != seed;
}
