import 'package:flutter/material.dart';

import '../core/theme/app_themes.dart';
import 'fx.dart';
import 'sard_icons.dart';

/// حبّة معلومة صغيرة (مشاهدات، فصول، تقييم...)
///
/// - [onDark]: زجاجية فوق الصور.
/// - [filled]: حبّة مميّزة (تقييم/جديد) بلون ذهبي، أو بلون [tone] إن حُدّد.
class StatPill extends StatelessWidget {
  const StatPill({
    super.key,
    required this.icon,
    required this.label,
    this.onDark = false,
    this.filled = false,
    this.tone,
  });

  final SIconData icon;
  final String label;
  final bool onDark;
  final bool filled;
  final Color? tone;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final hi = tone ?? p.gold;
    final Color fg;
    final Color bg;
    final Color line;
    if (onDark) {
      fg = Colors.white;
      bg = tint(Colors.black, 0.42);
      line = tint(Colors.white, 0.16);
    } else if (filled) {
      fg = hi;
      bg = tint(hi, 0.14);
      line = tint(hi, 0.28);
    } else {
      fg = p.textDim;
      bg = p.surfaceHi;
      line = Colors.transparent;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: line, width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(icon, size: 13, color: fg),
          const SizedBox(width: 5),
          Text(label, style: context.ts(size: 11.5, w: FontWeight.w600, color: fg)),
        ],
      ),
    );
  }
}

/// وسم الحالة: مستمر / مكتمل — نقطة مضيئة داخل كبسولة زجاجية
class StatusTag extends StatelessWidget {
  const StatusTag({super.key, required this.status, this.onDark = true});
  final String status;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final ongoing = status == 'مستمر';
    final dot = ongoing ? const Color(0xFF3DDC97) : context.pal.gold;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: tint(Colors.black, 0.5),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: tint(Colors.white, 0.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: dot,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: tint(dot, 0.7), blurRadius: 6)],
            ),
          ),
          const SizedBox(width: 6),
          Text(status, style: context.ts(size: 11, w: FontWeight.w600, color: Colors.white)),
        ],
      ),
    );
  }
}

/// زر أيقونة مربّع مدوّر
class RoundIconButton extends StatelessWidget {
  const RoundIconButton({super.key, required this.icon, required this.onTap, this.size = 44});
  final SIconData icon;
  final VoidCallback onTap;
  final double size;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: tint(p.surface, p.glass ? 0.7 : 0.92),
          borderRadius: BorderRadius.circular(
            p.r(size * 0.36 / 20).clamp(size * 0.2, size * 0.5).toDouble(),
          ),
          border: Border.all(color: tint(p.border, 0.7), width: p.borderW),
          boxShadow: softShadow(p, strength: 0.6),
        ),
        child: SIcon(icon, size: size * 0.5, color: p.text),
      ),
    );
  }
}

/// عنوان قسم عصري: عنوان نظيف + رابط «عرض الكل» هادئ
class SectionHeader extends StatelessWidget {
  const SectionHeader({super.key, required this.title, this.action, this.onAction});
  final String title;
  final String? action;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 30, 22, 14),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: p.accent,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: tint(p.accent, 0.5), blurRadius: 8)],
            ),
          ),
          const SizedBox(width: 10),
          Text(title, style: context.ds(size: 20)),
          const Spacer(),
          if (action != null)
            GestureDetector(
              onTap: onAction,
              child: Text(action!,
                  style: context.ts(size: 12.5, w: FontWeight.w600, color: p.accent)),
            ),
        ],
      ),
    );
  }
}
