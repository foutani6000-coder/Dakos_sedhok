import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import '../creator/creator_studio.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// العضوية — باقات مجاني / بلس / عائلي.
/// عرض تجريبي محلي بالكامل: الترقية لا تخصم أي مبلغ حقيقي، والباقة
/// المدفوعة تُفعَّل محلياً لمدة 30 يوماً للتجربة.
/// ──────────────────────────────────────────────────────────────────────────

/// باقة العضوية.
enum MembershipTier {
  free('مجاني', 0, 'قراءة أساسية بلا حدود.'),
  plus('بلس', 19, 'قراءة بلا إعلانات + مزايا احترافية.'),
  family('عائلي', 29, 'كل مزايا بلس + مشاركة مع 5 أفراد.');

  const MembershipTier(this.label, this.monthlyPriceSar, this.tagline);
  final String label;

  /// السعر الشهري بالريال (تجريبي).
  final int monthlyPriceSar;
  final String tagline;

  bool get isPaid => this != MembershipTier.free;

  bool get supportsFamily => this == MembershipTier.family;

  /// عدد أفراد العائلة المسموح بهم (عدا صاحب الحساب).
  int get maxFamilyMembers => this == MembershipTier.family ? 5 : 0;

  /// مزايا الباقة.
  List<String> get features {
    switch (this) {
      case MembershipTier.free:
        return const [
          'قراءة كل الأعمال المجانية',
          'متابعة حتى 10 أعمال',
          'تحميل فصلين للقراءة دون اتصال',
          'تعليقات وتقييمات',
        ];
      case MembershipTier.plus:
        return const [
          'كل مزايا المجاني',
          'بلا إعلانات إطلاقاً',
          'تحميل غير محدود دون اتصال',
          'قراءة مبكرة للفصول الجديدة',
          'ثيمات حصرية وغلاف ذهبي',
          'دعم فني ذو أولوية',
        ];
      case MembershipTier.family:
        return const [
          'كل مزايا بلس',
          'مشاركة مع 5 أفراد من عائلتك',
          'ملف طفل مع تحكم أبوي',
          'تقارير قراءة أسبوعية للعائلة',
        ];
    }
  }
}

SIconData membershipTierIcon(MembershipTier tier) {
  switch (tier) {
    case MembershipTier.free:
      return SardIcons.menu_book_rounded;
    case MembershipTier.plus:
      return SardIcons.star_rounded;
    case MembershipTier.family:
      return SardIcons.groups_rounded;
  }
}

/// حالة العضوية الحالية.
class MembershipState {
  const MembershipState({
    required this.tier,
    this.startedAt,
    this.expiresAt,
    this.autoRenew = false,
    this.familyMembers = const [],
  });

  final MembershipTier tier;
  final DateTime? startedAt;
  final DateTime? expiresAt;

  /// هل يتجدد تلقائياً (تجريبي)؟
  final bool autoRenew;

  /// أسماء أفراد العائلة المشاركين.
  final List<String> familyMembers;

  /// هل الباقة نشطة الآن؟ المجاني نشط دائماً، والمدفوع نشط حتى انتهائه.
  bool get isActive {
    if (!tier.isPaid) return true;
    if (expiresAt == null) return false;
    return expiresAt!.isAfter(DateTime.now());
  }

  /// عدد الأيام المتبقية في الباقة المدفوعة (0 للمجاني).
  int get daysLeft {
    if (!tier.isPaid || expiresAt == null) return 0;
    final d = expiresAt!.difference(DateTime.now()).inDays;
    return d < 0 ? 0 : d;
  }

  MembershipState copyWith({
    MembershipTier? tier,
    DateTime? startedAt,
    DateTime? expiresAt,
    bool? autoRenew,
    List<String>? familyMembers,
  }) {
    return MembershipState(
      tier: tier ?? this.tier,
      startedAt: startedAt ?? this.startedAt,
      expiresAt: expiresAt ?? this.expiresAt,
      autoRenew: autoRenew ?? this.autoRenew,
      familyMembers: familyMembers ?? this.familyMembers,
    );
  }

  /// يلغي تاريخ الانتهاء صراحة (للرجوع إلى المجاني).
  MembershipState asFree() => MembershipState(
        tier: MembershipTier.free,
        familyMembers: const [],
      );

  Map<String, dynamic> toJson() => {
        'tier': tier.name,
        'started_at': startedAt?.millisecondsSinceEpoch,
        'expires_at': expiresAt?.millisecondsSinceEpoch,
        'auto_renew': autoRenew,
        'family_members': familyMembers,
      };

  factory MembershipState.fromJson(Map<String, dynamic> j) {
    MembershipTier tier = MembershipTier.free;
    for (final v in MembershipTier.values) {
      if (v.name == '${j['tier']}') tier = v;
    }
    DateTime? dt(dynamic v) =>
        v == null ? null : DateTime.fromMillisecondsSinceEpoch((v as num).toInt());
    return MembershipState(
      tier: tier,
      startedAt: dt(j['started_at']),
      expiresAt: dt(j['expires_at']),
      autoRenew: j['auto_renew'] == true,
      familyMembers:
          ((j['family_members'] as List?) ?? const []).map((e) => '$e').toList(),
    );
  }

  static const MembershipState free = MembershipState(tier: MembershipTier.free);
}

const String _kMembershipKey = 'membership_v1';

/// مخزن العضوية.
class MembershipStore extends ChangeNotifier {
  MembershipStore(this._p) {
    _read();
  }

  final SharedPreferences _p;
  MembershipState _state = MembershipState.free;

  static MembershipStore? _i;
  static MembershipStore get i => _i!;

  static Future<MembershipStore> load() async {
    final p = await SharedPreferences.getInstance();
    _i ??= MembershipStore(p);
    return _i!;
  }

  static MembershipStore testInstance(SharedPreferences p) =>
      MembershipStore(p);

  MembershipState get state => _state;
  MembershipTier get tier => _state.tier;

  /// هل لديك بلس نشط (بلس أو عائلي)؟
  bool get isPlus => _state.tier.isPaid && _state.isActive;

  /// هل لديك باقة عائلية نشطة؟
  bool get isFamily => _state.tier == MembershipTier.family && _state.isActive;

  bool get canAddFamilyMember =>
      isFamily && _state.familyMembers.length < tier.maxFamilyMembers;

  void _read() {
    try {
      final raw = _p.getString(_kMembershipKey);
      if (raw == null || raw.isEmpty) return;
      _state = MembershipState.fromJson(
        Map<String, dynamic>.from(jsonDecode(raw) as Map),
      );
    } catch (_) {
      _state = MembershipState.free;
    }
  }

  void _save() {
    _p.setString(_kMembershipKey, jsonEncode(_state.toJson()));
  }

  /// ترقية تجريبية إلى باقة مدفوعة لمدة 30 يوماً (بلا خصم حقيقي).
  void upgradeTo(MembershipTier tier, {DateTime? now}) {
    if (!tier.isPaid) {
      downgradeToFree();
      return;
    }
    final today = now ?? DateTime.now();
    _state = MembershipState(
      tier: tier,
      startedAt: today,
      expiresAt: today.add(const Duration(days: 30)),
      autoRenew: true,
      familyMembers: _state.familyMembers,
    );
    _save();
    notifyListeners();
  }

  /// الرجوع إلى الباقة المجانية.
  void downgradeToFree() {
    _state = MembershipState.free;
    _save();
    notifyListeners();
  }

  /// تجديد الباقة المدفوعة 30 يوماً إضافية (تجريبي).
  bool renew({DateTime? now}) {
    if (!_state.tier.isPaid) return false;
    final today = now ?? DateTime.now();
    final base = _state.expiresAt != null && _state.expiresAt!.isAfter(today)
        ? _state.expiresAt!
        : today;
    _state = _state.copyWith(expiresAt: base.add(const Duration(days: 30)));
    _save();
    notifyListeners();
    return true;
  }

  /// تفعيل/إيقاف التجديد التلقائي (تجريبي).
  void setAutoRenew(bool v) {
    if (!_state.tier.isPaid) return;
    _state = _state.copyWith(autoRenew: v);
    _save();
    notifyListeners();
  }

  /// إضافة فرد عائلة. يُعيد رسالة خطأ أو null عند النجاح.
  /// متاح فقط في باقة عائلي النشطة.
  Future<String?> addFamilyMember(String name) async {
    final n = name.trim();
    if (n.isEmpty) return 'اكتب اسم فرد العائلة.';
    if (n.length > 30) return 'الاسم طويل جداً.';
    if (tier != MembershipTier.family || !_state.isActive) {
      return 'المشاركة العائلية متاحة فقط في باقة بلس عائلي النشطة.';
    }
    if (_state.familyMembers.length >= tier.maxFamilyMembers) {
      return 'وصلت إلى الحد الأقصى (${tier.maxFamilyMembers} أفراد).';
    }
    if (_state.familyMembers.contains(n)) return 'هذا الاسم مضاف بالفعل.';
    _state = _state.copyWith(
      familyMembers: [..._state.familyMembers, n],
    );
    _save();
    notifyListeners();
    return null;
  }

  /// إزالة فرد عائلة.
  bool removeFamilyMember(String name) {
    if (!_state.familyMembers.contains(name)) return false;
    _state = _state.copyWith(
      familyMembers:
          _state.familyMembers.where((e) => e != name).toList(),
    );
    _save();
    notifyListeners();
    return true;
  }
}

// ───────── واجهة العضوية ─────────

/// شاشة العضوية والباقات.
class MembershipScreen extends StatelessWidget {
  const MembershipScreen({super.key, required this.store});
  final MembershipStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final state = store.state;
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(title: const Text('العضوية')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              _CurrentPlanCard(store: store),
              const SizedBox(height: 18),
              Text('الباقات', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              for (final t in MembershipTier.values)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _TierCard(
                    tier: t,
                    current: state.tier == t && state.isActive,
                    store: store,
                  ),
                ),
              if (state.tier == MembershipTier.family) ...[
                const SizedBox(height: 6),
                Text('عائلتي', style: context.ds(size: 18)),
                const SizedBox(height: 10),
                _FamilySection(store: store),
              ],
              const SizedBox(height: 18),
              _MembershipFaq(),
              const SizedBox(height: 14),
              Text(
                'تنبيه: الترقية هنا تجريبية محلية ولا تخصم أي مبلغ حقيقي. '
                'الباقة المدفوعة تُفعَّل على جهازك لمدة 30 يوماً للتجربة فقط.',
                style: context.ts(size: 12, color: p.textDim, height: 1.6),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _CurrentPlanCard extends StatelessWidget {
  const _CurrentPlanCard({required this.store});
  final MembershipStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final state = store.state;
    final active = state.isActive;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: state.tier.isPaid ? p.accent : p.surface,
        borderRadius: BorderRadius.circular(p.r(1.1)),
        border: Border.all(
          color: state.tier.isPaid ? p.accent : p.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(
                membershipTierIcon(state.tier),
                size: 22,
                color: state.tier.isPaid ? p.onAccent : p.accent,
              ),
              const SizedBox(width: 8),
              Text(
                'باقتك الحالية',
                style: context.ts(
                  color: state.tier.isPaid ? p.onAccent : p.textDim,
                  w: FontWeight.w700,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: state.tier.isPaid
                      ? tint(Colors.white, 0.2)
                      : tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  active ? 'نشطة' : 'منتهية',
                  style: context.ts(
                    size: 12,
                    w: FontWeight.w800,
                    color: state.tier.isPaid ? p.onAccent : p.accent,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Senok ${state.tier.label}',
            style: context.ds(
              size: 26,
              color: state.tier.isPaid ? p.onAccent : p.text,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            state.tier.tagline,
            style: context.ts(
              color: state.tier.isPaid ? p.onAccent : p.textDim,
            ),
          ),
          if (state.tier.isPaid && state.expiresAt != null) ...[
            const SizedBox(height: 10),
            Text(
              'تنتهي في ${formatSardDate(state.expiresAt!)}'
              ' (${state.daysLeft} يوم متبقٍ)',
              style: context.ts(
                color: state.tier.isPaid ? p.onAccent : p.textDim,
                w: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(
                  'التجديد التلقائي',
                  style: context.ts(color: p.onAccent),
                ),
                const Spacer(),
                Switch(
                  value: state.autoRenew,
                  onChanged: (v) => store.setAutoRenew(v),
                  activeColor: p.onAccent,
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: p.onAccent,
                  side: BorderSide(color: tint(Colors.white, 0.5)),
                ),
                onPressed: () {
                  store.renew();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('جُددت باقتك 30 يوماً (تجريبي).')),
                  );
                },
                child: const Text('تجديد الآن (تجريبي)'),
              ),
            ),
          ],
          if (state.tier.isPaid && !active) ...[
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: p.onAccent,
                  foregroundColor: p.accent,
                ),
                onPressed: () => store.upgradeTo(state.tier),
                child: const Text('إعادة التفعيل (تجريبي)'),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _TierCard extends StatelessWidget {
  const _TierCard({
    required this.tier,
    required this.current,
    required this.store,
  });
  final MembershipTier tier;
  final bool current;
  final MembershipStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final recommended = tier == MembershipTier.plus;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(
          color: current ? p.accent : p.border,
          width: current ? 1.5 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SIcon(membershipTierIcon(tier), size: 21, color: p.accent),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('Senok ${tier.label}', style: context.ds(size: 17)),
                        if (recommended) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: tint(p.gold, 0.18),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              'الأكثر شيوعاً',
                              style: context.ts(
                                size: 11,
                                w: FontWeight.w800,
                                color: p.gold,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    Text(tier.tagline, style: context.ts(size: 12.5, color: p.textDim)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    tier.isPaid ? '${tier.monthlyPriceSar} ر.س' : 'مجاني',
                    style: context.ds(size: 17, color: p.accent),
                  ),
                  if (tier.isPaid)
                    Text('/ شهرياً', style: context.ts(size: 11.5, color: p.textDim)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          for (final f in tier.features)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SIcon(SardIcons.check_rounded, size: 16, color: p.accent),
                  const SizedBox(width: 8),
                  Expanded(child: Text(f, style: context.ts(height: 1.5))),
                ],
              ),
            ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: current
                ? OutlinedButton(
                    onPressed: null,
                    child: const Text('باقتك الحالية'),
                  )
                : FilledButton(
                    onPressed: () => _confirmChange(context, tier),
                    child: Text(
                      tier.isPaid
                          ? 'الترقية إلى ${tier.label} (تجريبي)'
                          : 'الرجوع إلى المجاني',
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  void _confirmChange(BuildContext context, MembershipTier tier) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.pal.surface,
        title: Text('تغيير الباقة إلى ${tier.label}؟'),
        content: Text(
          tier.isPaid
              ? 'سيُفعَّل ${tier.label} على جهازك لمدة 30 يوماً للتجربة، '
                  'ولن يُخصم أي مبلغ حقيقي.'
              : 'ستفقد مزايا الباقة المدفوعة وتعود إلى المجاني.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              store.upgradeTo(tier);
              Navigator.of(ctx).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    tier.isPaid
                        ? 'أصبحت الآن على باقة ${tier.label} (تجريبي).'
                        : 'عُدت إلى الباقة المجانية.',
                  ),
                ),
              );
            },
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
  }
}

class _FamilySection extends StatefulWidget {
  const _FamilySection({required this.store});
  final MembershipStore store;

  @override
  State<_FamilySection> createState() => _FamilySectionState();
}

class _FamilySectionState extends State<_FamilySection> {
  final _name = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final members = widget.store.state.familyMembers;
    final max = widget.store.tier.maxFamilyMembers;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('أفراد العائلة', style: context.ts(w: FontWeight.w800)),
              const Spacer(),
              Text(
                '${members.length}/$max',
                style: context.ts(color: p.textDim),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'شارك باقتك مع عائلتك؛ لكل فرد ملفه وتقدمه الخاص.',
            style: context.ts(size: 12.5, color: p.textDim, height: 1.5),
          ),
          const SizedBox(height: 12),
          if (members.isEmpty)
            Text(
              'لا أفراد بعد. أضف أول فرد من عائلتك.',
              style: context.ts(color: p.textDim),
            )
          else
            for (final m in members)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 17,
                      backgroundColor: tint(p.accent, 0.14),
                      child: SIcon(SardIcons.person_rounded, size: 18, color: p.accent),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(m, style: context.ts(w: FontWeight.w700)),
                    ),
                    IconButton(
                      tooltip: 'إزالة',
                      onPressed: () =>
                          widget.store.removeFamilyMember(m),
                      icon: const SIcon(
                        SardIcons.delete_outline_rounded,
                        size: 19,
                        color: Color(0xFFE5484D),
                      ),
                    ),
                  ],
                ),
              ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _name,
                  maxLength: 30,
                  decoration: InputDecoration(
                    hintText: 'اسم فرد العائلة',
                    counterText: '',
                    filled: true,
                    fillColor: p.surfaceHi,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: p.border),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              FilledButton(
                onPressed: _busy || !widget.store.canAddFamilyMember
                    ? null
                    : _add,
                child: const Text('إضافة'),
              ),
            ],
          ),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!, style: context.ts(color: const Color(0xFFE5484D))),
          ],
          if (!widget.store.canAddFamilyMember)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                'وصلت إلى الحد الأقصى ($max أفراد).',
                style: context.ts(size: 12.5, color: p.textDim),
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _add() async {
    setState(() => _busy = true);
    final err = await widget.store.addFamilyMember(_name.text);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _error = err;
    });
    if (err == null) {
      _name.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أُضيف فرد العائلة.')),
      );
    }
  }
}

class _MembershipFaq extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    const faqs = [
      (
        'هل الترقية تخصم مبلغاً حقيقياً؟',
        'لا. هذه النسخة تجريبية محلية بالكامل؛ الترقية تفعيل وهمي على جهازك فقط.',
      ),
      (
        'ماذا يحدث عند انتهاء الباقة؟',
        'تعود تلقائياً إلى المجاني، وتحتفظ ببياناتك وقوائمك، ويمكنك إعادة التفعيل.',
      ),
      (
        'هل يرى أفراد عائلتي تقدمي؟',
        'لا. لكل فرد ملفه الخاص، ولا يرى أحد تقدم الآخرين.',
      ),
      (
        'هل أستطيع إلغاء التجديد التلقائي؟',
        'نعم، من بطاقة باقتك الحالية في أعلى هذه الشاشة.',
      ),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('أسئلة شائعة', style: context.ds(size: 18)),
        const SizedBox(height: 10),
        for (final (q, a) in faqs)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(p.r(0.9)),
              border: Border.all(color: p.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(q, style: context.ts(w: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(a, style: context.ts(color: p.textDim, height: 1.6)),
              ],
            ),
          ),
      ],
    );
  }
}
