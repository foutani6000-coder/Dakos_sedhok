import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'coins_rewards.dart';
import '../creator/creator_earnings.dart';
import '../creator/creator_studio.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// الإحالات — ادعُ أصدقاءك إلى Senok واكسب عملات عند انضمامهم.
/// رابط الإحالة بنطاق senok.app. كل شيء محلي تجريبي في هذه النسخة.
/// ──────────────────────────────────────────────────────────────────────────

/// نطاق روابط الإحالة.
const String kReferralDomain = 'senok.app';

/// مكافأة الداعي عند انضمام صديق.
const int kReferrerBonus = 50;

/// مكافأة المنضم الجديد عبر رابط إحالة.
const int kInviteeBonus = 30;

/// طول رمز الإحالة.
const int kReferralCodeLength = 6;

/// حالة إحالة.
enum ReferralStatus {
  pending('بانتظار الانضمام', 'أُرسلت الدعوة ولم ينضم الصديق بعد.'),
  joined('انضم', 'انضم الصديق وبدأ القراءة.'),
  active('نشط', 'الصديق قارئ نشط؛ اكتملت المكافأة.');

  const ReferralStatus(this.label, this.description);
  final String label;
  final String description;
}

/// إحالة واحدة (صديق دُعي).
class Referral {
  const Referral({
    required this.code,
    required this.friendName,
    required this.invitedAt,
    required this.status,
    this.joinedAt,
    this.earnedCoins = 0,
  });

  /// رمز الدعوة المرسل للصديق.
  final String code;
  final String friendName;
  final DateTime invitedAt;
  final DateTime? joinedAt;
  final ReferralStatus status;

  /// العملات المكتسبة من هذه الإحالة.
  final int earnedCoins;

  Referral copyWith({
    ReferralStatus? status,
    DateTime? joinedAt,
    int? earnedCoins,
  }) {
    return Referral(
      code: code,
      friendName: friendName,
      invitedAt: invitedAt,
      status: status ?? this.status,
      joinedAt: joinedAt ?? this.joinedAt,
      earnedCoins: earnedCoins ?? this.earnedCoins,
    );
  }

  Map<String, dynamic> toJson() => {
        'code': code,
        'friend_name': friendName,
        'invited_at': invitedAt.millisecondsSinceEpoch,
        'joined_at': joinedAt?.millisecondsSinceEpoch,
        'status': status.name,
        'earned_coins': earnedCoins,
      };

  factory Referral.fromJson(Map<String, dynamic> j) {
    ReferralStatus st = ReferralStatus.pending;
    for (final v in ReferralStatus.values) {
      if (v.name == '${j['status']}') st = v;
    }
    DateTime? dt(dynamic v) =>
        v == null ? null : DateTime.fromMillisecondsSinceEpoch((v as num).toInt());
    return Referral(
      code: '${j['code'] ?? ''}',
      friendName: '${j['friend_name'] ?? 'صديق'}',
      invitedAt: dt(j['invited_at']) ?? DateTime.now(),
      joinedAt: dt(j['joined_at']),
      status: st,
      earnedCoins: (j['earned_coins'] as num?)?.toInt() ?? 0,
    );
  }
}

/// التحقق من رمز إحالة: 6 أحرف/أرقام إنجليزية فقط.
/// يُعيد رسالة خطأ أو null إن كان الرمز صالح الشكل.
String? validateReferralCode(String raw, {String? ownCode}) {
  final code = raw.trim().toUpperCase();
  if (code.isEmpty) return 'اكتب رمز الإحالة.';
  if (code.length != kReferralCodeLength) {
    return 'رمز الإحالة مكوّن من $kReferralCodeLength أحرف.';
  }
  if (!RegExp(r'^[A-Z0-9]+$').hasMatch(code)) {
    return 'الرمز يحتوي أحرفاً إنجليزية وأرقاماً فقط.';
  }
  if (ownCode != null && code == ownCode.toUpperCase()) {
    return 'لا يمكنك استخدام رمزك الخاص.';
  }
  return null;
}

/// يولّد رمز إحالة حتمياً من بذرة نصية (قاعدة ثابتة).
String generateReferralCode(String seed) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var h = seed.codeUnits.fold<int>(7, (a, b) => a * 31 + b);
  final rnd = math.Random(h);
  final buf = StringBuffer();
  for (var i = 0; i < kReferralCodeLength; i++) {
    buf.write(chars[rnd.nextInt(chars.length)]);
  }
  return buf.toString();
}

const String _kReferralsKey = 'referrals_v1';

/// مخزن الإحالات.
class ReferralStore extends ChangeNotifier {
  ReferralStore(this._p, {this.coins}) {
    _read();
  }

  final SharedPreferences _p;

  /// مخزن العملات (اختياري) لإضافة مكافآت الإحالة تلقائياً.
  final SardCoinsStore? coins;

  String _myCode = '';

  /// عدّاد أحادي لتفادي تطابق رموز الدعوات المولّدة في اللحظة نفسها.
  static int _seq = 0;
  List<Referral> _referrals = [];
  String? _usedCode;

  static ReferralStore? _i;
  static ReferralStore get i => _i!;

  static Future<ReferralStore> load({SardCoinsStore? coins}) async {
    final p = await SharedPreferences.getInstance();
    _i ??= ReferralStore(p, coins: coins);
    return _i!;
  }

  static ReferralStore testInstance(SharedPreferences p, {SardCoinsStore? coins}) =>
      ReferralStore(p, coins: coins);

  /// رمز إحالتي.
  String get myCode => _myCode;

  /// رابط إحالتي.
  String get myLink => 'https://$kReferralDomain/r/$_myCode';

  List<Referral> get referrals => List.unmodifiable(_referrals);

  /// الرمز الذي استخدمتُه عند انضمامي (إن وُجد).
  String? get usedCode => _usedCode;

  int get inviteCount => _referrals.length;

  int get joinedCount => _referrals
      .where((e) =>
          e.status == ReferralStatus.joined ||
          e.status == ReferralStatus.active)
      .length;

  int get activeCount =>
      _referrals.where((e) => e.status == ReferralStatus.active).length;

  /// إجمالي عملات الإحالات المكتسبة.
  int get totalEarnedCoins =>
      _referrals.fold<int>(0, (a, e) => a + e.earnedCoins);

  /// نص المشاركة الجاهز.
  String get shareText =>
      'انضم إلى Senok واقرأ آلاف المانهوا والمانغا بالعربية! '
      'استخدم رابطي واحصل على $kInviteeBonus عملة هدية: $myLink';

  void _read() {
    try {
      final raw = _p.getString(_kReferralsKey);
      if (raw == null || raw.isEmpty) {
        _myCode = generateReferralCode(
          'senok_${DateTime.now().millisecondsSinceEpoch}',
        );
        _referrals = _demoReferrals();
        _save();
        return;
      }
      final m = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      _myCode = '${m['my_code'] ?? ''}';
      if (_myCode.isEmpty) {
        _myCode = generateReferralCode(
          'senok_${DateTime.now().millisecondsSinceEpoch}',
        );
      }
      final list = (m['referrals'] as List?) ?? const [];
      _referrals = list
          .whereType<Map>()
          .map((e) => Referral.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      _usedCode = m['used_code'] as String?;
    } catch (_) {
      _myCode = generateReferralCode('senok_fallback');
      _referrals = _demoReferrals();
    }
  }

  void _save() {
    _p.setString(_kReferralsKey, jsonEncode({
      'my_code': _myCode,
      'referrals': _referrals.map((e) => e.toJson()).toList(),
      'used_code': _usedCode,
    }));
  }

  static List<Referral> _demoReferrals() {
    final now = DateTime.now();
    return [
      Referral(
        code: 'A7K2M9',
        friendName: 'سارة',
        invitedAt: now.subtract(const Duration(days: 12)),
        joinedAt: now.subtract(const Duration(days: 11)),
        status: ReferralStatus.active,
        earnedCoins: kReferrerBonus,
      ),
      Referral(
        code: 'Q3P8Z1',
        friendName: 'عمر',
        invitedAt: now.subtract(const Duration(days: 5)),
        joinedAt: now.subtract(const Duration(days: 4)),
        status: ReferralStatus.joined,
        earnedCoins: kReferrerBonus,
      ),
      Referral(
        code: 'T6W4D8',
        friendName: 'ليلى',
        invitedAt: now.subtract(const Duration(days: 1)),
        status: ReferralStatus.pending,
      ),
    ];
  }

  /// يسجّل دعوة صديق جديد (قبل انضمامه).
  Referral inviteFriend(String friendName, {DateTime? at}) {
    final name = friendName.trim().isEmpty ? 'صديق' : friendName.trim();
    final ref = Referral(
      code: generateReferralCode(
        'invite_${DateTime.now().millisecondsSinceEpoch}_${_seq++}_$name',
      ),
      friendName: name,
      invitedAt: at ?? DateTime.now(),
      status: ReferralStatus.pending,
    );
    _referrals.insert(0, ref);
    _save();
    notifyListeners();
    return ref;
  }

  /// يحاكي انضمام صديق عبر دعوة (للتجربة المحلية).
  /// يمنح مكافأة الإحالة ويسجّلها في مخزن العملات إن وُجد.
  bool simulateFriendJoined(String code, {DateTime? at}) {
    final i = _referrals.indexWhere((e) => e.code == code);
    if (i < 0) return false;
    if (_referrals[i].status != ReferralStatus.pending) return false;
    final now = at ?? DateTime.now();
    _referrals[i] = _referrals[i].copyWith(
      status: ReferralStatus.joined,
      joinedAt: now,
      earnedCoins: kReferrerBonus,
    );
    coins?.recordReferralBonus(friendName: _referrals[i].friendName);
    _save();
    notifyListeners();
    return true;
  }

  /// يحاكي تحوّل صديق منضم إلى قارئ نشط.
  bool markActive(String code) {
    final i = _referrals.indexWhere((e) => e.code == code);
    if (i < 0) return false;
    if (_referrals[i].status != ReferralStatus.joined) return false;
    _referrals[i] = _referrals[i].copyWith(status: ReferralStatus.active);
    _save();
    notifyListeners();
    return true;
  }

  /// يستخدم رمز إحالة صديق عند انضمامي. يُعيد رسالة خطأ أو null.
  /// (تجريبي: يمنح مكافأة المنضم الجديد في مخزن العملات إن وُجد.)
  String? applyCode(String raw) {
    final err = validateReferralCode(raw, ownCode: _myCode);
    if (err != null) return err;
    if (_usedCode != null) return 'استخدمت رمز إحالة من قبل.';
    _usedCode = raw.trim().toUpperCase();
    coins?.grantReward(kInviteeBonus, 'مكافأة انضمام عبر إحالة');
    _save();
    notifyListeners();
    return null;
  }

  /// ينسخ رابط الإحالة إلى الحافظة.
  Future<void> copyLink() async {
    await Clipboard.setData(ClipboardData(text: myLink));
  }

  /// «مشاركة» الرابط: لا توجد حزمة مشاركة في المشروع، فيُنسخ نص
  /// المشاركة الكامل إلى الحافظة ليلصقه المستخدم في أي تطبيق.
  Future<void> shareLink() async {
    await Clipboard.setData(ClipboardData(text: shareText));
  }

  void clearDemo() {
    _referrals.clear();
    _save();
    notifyListeners();
  }
}

// ───────── واجهة الإحالات ─────────

/// شاشة الإحالات.
class ReferralsScreen extends StatefulWidget {
  const ReferralsScreen({super.key, required this.store});
  final ReferralStore store;

  @override
  State<ReferralsScreen> createState() => _ReferralsScreenState();
}

class _ReferralsScreenState extends State<ReferralsScreen> {
  final _code = TextEditingController();
  String? _codeError;
  bool _copied = false;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = widget.store;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(title: const Text('ادعُ أصدقاءك')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              _ReferralLinkCard(
                store: store,
                copied: _copied,
                onCopy: () async {
                  await store.copyLink();
                  if (!mounted) return;
                  setState(() => _copied = true);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('نُسخ رابط الإحالة.')),
                  );
                  await Future<void>.delayed(const Duration(seconds: 2));
                  if (mounted) setState(() => _copied = false);
                },
              ),
              const SizedBox(height: 14),
              _ReferralStats(store: store),
              const SizedBox(height: 18),
              Text('كيف تعمل الإحالة؟', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              const _HowItWorks(),
              const SizedBox(height: 18),
              Text('استخدم رمز إحالة', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              _ApplyCodeCard(
                controller: _code,
                error: _codeError,
                usedCode: store.usedCode,
                onApply: () {
                  final err = store.applyCode(_code.text);
                  setState(() => _codeError = err);
                  if (err == null) {
                    _code.clear();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'تم! كسبت $kInviteeBonus عملة هدية انضمام.',
                        ),
                      ),
                    );
                  }
                },
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Text('دعواتي', style: context.ds(size: 18)),
                  const Spacer(),
                  Text(
                    '${store.inviteCount} دعوة',
                    style: context.ts(color: p.textDim),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (store.referrals.isEmpty)
                _ReferralsEmpty()
              else
                for (var i = 0; i < store.referrals.length; i++)
                  Padding(
                    padding: EdgeInsets.only(
                      bottom: i == store.referrals.length - 1 ? 0 : 10,
                    ),
                    child: _ReferralTile(
                      referral: store.referrals[i],
                      store: store,
                    ),
                  ),
              const SizedBox(height: 14),
              Text(
                'الإحالات في هذه النسخة تجريبية ومحفوظة على جهازك فقط؛ '
                'المكافآت عملات محلية بلا قيمة نقدية.',
                style: context.ts(size: 12, color: p.textDim, height: 1.6),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ReferralLinkCard extends StatelessWidget {
  const _ReferralLinkCard({
    required this.store,
    required this.copied,
    required this.onCopy,
  });
  final ReferralStore store;
  final bool copied;
  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: p.accent,
        borderRadius: BorderRadius.circular(p.r(1.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.share_rounded, size: 20, color: p.onAccent),
              const SizedBox(width: 8),
              Text(
                'رابط إحالتك',
                style: context.ts(color: p.onAccent, w: FontWeight.w700),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: tint(Colors.white, 0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'رمزك: ${store.myCode}',
                  style: context.ts(size: 12, w: FontWeight.w800, color: p.onAccent),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: tint(Colors.black, 0.18),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              store.myLink,
              style: context.ts(color: p.onAccent, w: FontWeight.w600),
              textDirection: TextDirection.ltr,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: p.onAccent,
                    foregroundColor: p.accent,
                  ),
                  onPressed: onCopy,
                  icon: SIcon(
                    copied ? SardIcons.check_rounded : SardIcons.format_list_bulleted_rounded,
                    size: 18,
                  ),
                  label: Text(copied ? 'تم النسخ' : 'نسخ الرابط'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: p.onAccent,
                    side: BorderSide(color: tint(Colors.white, 0.5)),
                  ),
                  onPressed: () async {
                    await store.shareLink();
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('نُسخ نص المشاركة، الصقه في أي تطبيق.'),
                      ),
                    );
                  },
                  icon: const SIcon(SardIcons.send_rounded, size: 18),
                  label: const Text('مشاركة'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'صديقك يكسب $kInviteeBonus عملة عند الانضمام، وأنت تكسب '
            '$kReferrerBonus عملة عند انضمامه.',
            style: context.ts(size: 12.5, color: p.onAccent, height: 1.5),
          ),
        ],
      ),
    );
  }
}

class _ReferralStats extends StatelessWidget {
  const _ReferralStats({required this.store});
  final ReferralStore store;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _StatBox(
          label: 'دعوات',
          value: '${store.inviteCount}',
          icon: SardIcons.send_rounded,
        ),
        const SizedBox(width: 10),
        _StatBox(
          label: 'انضموا',
          value: '${store.joinedCount}',
          icon: SardIcons.person_rounded,
        ),
        const SizedBox(width: 10),
        _StatBox(
          label: 'كسبت',
          value: formatCoins(store.totalEarnedCoins),
          icon: SardIcons.star_rounded,
        ),
      ],
    );
  }
}

class _StatBox extends StatelessWidget {
  const _StatBox({
    required this.label,
    required this.value,
    required this.icon,
  });
  final String label;
  final String value;
  final SIconData icon;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border),
        ),
        child: Column(
          children: [
            SIcon(icon, size: 18, color: p.accent),
            const SizedBox(height: 6),
            Text(value, style: context.ds(size: 15)),
            Text(label, style: context.ts(size: 11.5, color: p.textDim)),
          ],
        ),
      ),
    );
  }
}

class _HowItWorks extends StatelessWidget {
  const _HowItWorks();

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    const steps = [
      ('1', 'شارك رابطك مع أصدقائك.'),
      ('2', 'ينضم صديقك عبر الرابط ويكسب 30 عملة هدية.'),
      ('3', 'تكسب أنت 50 عملة فور انضمامه.'),
      ('4', 'تابع دعواتك هنا وشاهد من انضم ومن ما زال بانتظار.'),
    ];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          for (var i = 0; i < steps.length; i++) ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 24,
                  height: 24,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(p.accent, 0.14),
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    steps[i].$1,
                    style: context.ts(size: 12, w: FontWeight.w800, color: p.accent),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(steps[i].$2, style: context.ts(height: 1.5)),
                ),
              ],
            ),
            if (i < steps.length - 1) const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }
}

class _ApplyCodeCard extends StatelessWidget {
  const _ApplyCodeCard({
    required this.controller,
    required this.error,
    required this.usedCode,
    required this.onApply,
  });
  final TextEditingController controller;
  final String? error;
  final String? usedCode;
  final VoidCallback onApply;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (usedCode != null) ...[
            Row(
              children: [
                SIcon(SardIcons.check_circle_rounded, size: 18, color: const Color(0xFF0F9D75)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'استخدمت رمز الإحالة: $usedCode',
                    style: context.ts(w: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'يمكن استخدام رمز واحد فقط عند الانضمام.',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
          ] else ...[
            Text(
              'هل دعاك صديق؟ اكتب رمزه واحصل على $kInviteeBonus عملة.',
              style: context.ts(height: 1.5),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    maxLength: kReferralCodeLength,
                    textCapitalization: TextCapitalization.characters,
                    decoration: InputDecoration(
                      hintText: 'مثال: A7K2M9',
                      counterText: '',
                      filled: true,
                      fillColor: p.surfaceHi,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: p.border),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                FilledButton(
                  onPressed: onApply,
                  child: const Text('تطبيق'),
                ),
              ],
            ),
            if (error != null) ...[
              const SizedBox(height: 8),
              Text(error!, style: context.ts(color: const Color(0xFFE5484D))),
            ],
          ],
        ],
      ),
    );
  }
}

class _ReferralTile extends StatelessWidget {
  const _ReferralTile({required this.referral, required this.store});
  final Referral referral;
  final ReferralStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = referral.status == ReferralStatus.active
        ? const Color(0xFF0F9D75)
        : referral.status == ReferralStatus.joined
            ? p.gold
            : p.textDim;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 19,
            backgroundColor: tint(color, 0.14),
            child: SIcon(SardIcons.person_rounded, size: 19, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(referral.friendName, style: context.ts(w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  'دُعي ${formatSardDate(referral.invitedAt)} · ${referral.status.label}',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          if (referral.earnedCoins > 0)
            Text(
              '+${formatCoins(referral.earnedCoins)}',
              style: context.ts(w: FontWeight.w800, color: const Color(0xFF0F9D75)),
            ),
          if (referral.status == ReferralStatus.pending) ...[
            const SizedBox(width: 8),
            TextButton(
              onPressed: () {
                store.simulateFriendJoined(referral.code);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('محاكاة تجريبية: انضم الصديق وكسبت المكافأة.'),
                  ),
                );
              },
              child: const Text('محاكاة الانضمام'),
            ),
          ],
        ],
      ),
    );
  }
}

class _ReferralsEmpty extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Text(
        'لم تدعُ أحداً بعد. شارك رابطك وابدأ الكسب.',
        textAlign: TextAlign.center,
        style: context.ts(color: p.textDim),
      ),
    );
  }
}
