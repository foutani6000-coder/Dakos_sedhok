import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import '../creator/creator_earnings.dart';
import '../creator/creator_studio.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// العملات والمكافآت — اكسب عملات من القراءة والتفاعل، وأنفقها في المتجر.
/// كل شيء محلي؛ العملات لا قيمة نقدية لها ولا تُشترى بمال حقيقي هنا.
/// ──────────────────────────────────────────────────────────────────────────

/// عملات قراءة فصل واحد.
const int kCoinsPerChapter = 5;

/// الحد اليومي لعملات قراءة الفصول.
const int kDailyChapterCoinsCap = 50;

/// عملات التعليق الواحد (بحد يومي).
const int kCoinsPerComment = 3;
const int kDailyCommentCoinsCap = 15;

/// مكافأة الإحالة الناجحة.
const int kReferralBonusCoins = 50;

/// سلّم تسجيل الدخول اليومي (7 أيام).
const List<int> kCheckInLadder = [10, 15, 20, 25, 30, 40, 50];

/// نوع حركة عملات.
enum CoinTransactionKind {
  chapterRead('قراءة فصل', 'أكملت فصلاً.'),
  dailyCheckIn('تسجيل دخول', 'سجّلت دخولك اليومي.'),
  comment('تعليق', 'علّقت على فصل.'),
  referral('إحالة', 'انضم صديق عبر رابطك.'),
  reward('مكافأة', 'مكافأة من تحدٍّ أو إنجاز.'),
  spend('إنفاق', 'اشتريت من متجر المكافآت.');

  const CoinTransactionKind(this.label, this.description);
  final String label;
  final String description;
}

SIconData coinKindIcon(CoinTransactionKind k) {
  switch (k) {
    case CoinTransactionKind.chapterRead:
      return SardIcons.menu_book_rounded;
    case CoinTransactionKind.dailyCheckIn:
      return SardIcons.calendar_today_rounded;
    case CoinTransactionKind.comment:
      return SardIcons.chat_bubble_rounded;
    case CoinTransactionKind.referral:
      return SardIcons.share_rounded;
    case CoinTransactionKind.reward:
      return SardIcons.auto_awesome_rounded;
    case CoinTransactionKind.spend:
      return SardIcons.sell_rounded;
  }
}

/// حركة عملات واحدة.
class CoinTransaction {
  const CoinTransaction({
    required this.id,
    required this.at,
    required this.amount,
    required this.kind,
    required this.reason,
    this.seriesTitle = '',
  });

  final String id;
  final DateTime at;

  /// موجب = كسب، سالب = إنفاق.
  final int amount;
  final CoinTransactionKind kind;
  final String reason;
  final String seriesTitle;

  bool get isEarn => amount > 0;

  Map<String, dynamic> toJson() => {
        'id': id,
        'at': at.millisecondsSinceEpoch,
        'amount': amount,
        'kind': kind.name,
        'reason': reason,
        'series_title': seriesTitle,
      };

  factory CoinTransaction.fromJson(Map<String, dynamic> j) {
    CoinTransactionKind kind = CoinTransactionKind.reward;
    for (final v in CoinTransactionKind.values) {
      if (v.name == '${j['kind']}') kind = v;
    }
    return CoinTransaction(
      id: '${j['id']}',
      at: DateTime.fromMillisecondsSinceEpoch(
        (j['at'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch,
      ),
      amount: (j['amount'] as num?)?.toInt() ?? 0,
      kind: kind,
      reason: '${j['reason'] ?? ''}',
      seriesTitle: '${j['series_title'] ?? ''}',
    );
  }
}

/// عنصر في متجر المكافآت.
class CoinShopItem {
  const CoinShopItem({
    required this.id,
    required this.title,
    required this.description,
    required this.priceCoins,
    required this.icon,
  });

  final String id;
  final String title;
  final String description;
  final int priceCoins;
  final SIconData icon;
}

/// عناصر متجر المكافآت (تجريبي).
const List<CoinShopItem> kCoinShopItems = [
  CoinShopItem(
    id: 'theme_gold',
    title: 'إطار ذهبي للملف',
    description: 'إطار ذهبي يظهر حول صورتك الرمزية لمدة 30 يوماً.',
    priceCoins: 300,
    icon: SardIcons.star_rounded,
  ),
  CoinShopItem(
    id: 'theme_night',
    title: 'ثيم «ليل ذهبي»',
    description: 'يفتح ثيماً داكناً فاخراً بتفاصيل ذهبية.',
    priceCoins: 500,
    icon: SardIcons.nightlight_round,
  ),
  CoinShopItem(
    id: 'badge_early',
    title: 'شارة «قارئ مبكر»',
    description: 'شارة تظهر بجانب اسمك في التعليقات.',
    priceCoins: 200,
    icon: SardIcons.verified_user_outlined,
  ),
  CoinShopItem(
    id: 'boost_week',
    title: 'تعزيز أسبوعي',
    description: 'ضاعف عملات قراءتك لمدة 7 أيام.',
    priceCoins: 800,
    icon: SardIcons.bolt_rounded,
  ),
  CoinShopItem(
    id: 'chapters_pack',
    title: 'حزمة فصول مبكرة',
    description: 'افتح 3 فصول مبكرة من أي عمل مشارك.',
    priceCoins: 1000,
    icon: SardIcons.menu_book_rounded,
  ),
];

const String _kCoinsKey = 'sard_coins_v1';

/// مخزن العملات. يُربط بالقارئ لاحقاً عبر [recordChapterRead].
class SardCoinsStore extends ChangeNotifier {
  SardCoinsStore(this._p) {
    _read();
  }

  final SharedPreferences _p;
  int _balance = 0;
  List<CoinTransaction> _transactions = [];
  DateTime? _lastCheckIn;
  int _checkInStreak = 0;
  final Map<String, int> _dailyChapterCoins = {};
  final Map<String, int> _dailyCommentCoins = {};
  final Set<String> _ownedShopItems = {};
  bool _boostActive = false;
  DateTime? _boostUntil;

  static SardCoinsStore? _i;
  static SardCoinsStore get i => _i!;

  static Future<SardCoinsStore> load() async {
    final p = await SharedPreferences.getInstance();
    _i ??= SardCoinsStore(p);
    return _i!;
  }

  static SardCoinsStore testInstance(SharedPreferences p) =>
      SardCoinsStore(p);

  int get balance => _balance;
  List<CoinTransaction> get transactions => List.unmodifiable(_transactions);

  int get checkInStreak => _checkInStreak;
  DateTime? get lastCheckIn => _lastCheckIn;

  bool get checkedInToday {
    if (_lastCheckIn == null) return false;
    final now = DateTime.now();
    return _lastCheckIn!.year == now.year &&
        _lastCheckIn!.month == now.month &&
        _lastCheckIn!.day == now.day;
  }

  /// مكافأة تسجيل الدخول التالية حسب السلسلة الحالية.
  int get nextCheckInReward {
    final idx = _checkInStreak.clamp(0, kCheckInLadder.length - 1);
    return kCheckInLadder[idx];
  }

  bool get boostActive {
    if (!_boostActive) return false;
    if (_boostUntil == null) return false;
    return _boostUntil!.isAfter(DateTime.now());
  }

  Set<String> get ownedShopItems => Set.unmodifiable(_ownedShopItems);
  bool owns(String itemId) => _ownedShopItems.contains(itemId);

  static String _dayKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// عملات قراءة الفصول المكتسبة اليوم (للحد اليومي).
  int chapterCoinsToday({DateTime? now}) =>
      _dailyChapterCoins[_dayKey(now ?? DateTime.now())] ?? 0;

  int commentCoinsToday({DateTime? now}) =>
      _dailyCommentCoins[_dayKey(now ?? DateTime.now())] ?? 0;

  void _read() {
    try {
      final raw = _p.getString(_kCoinsKey);
      if (raw == null || raw.isEmpty) {
        _seedWelcome();
        return;
      }
      final m = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      _balance = (m['balance'] as num?)?.toInt() ?? 0;
      final list = (m['transactions'] as List?) ?? const [];
      _transactions = list
          .whereType<Map>()
          .map((e) => CoinTransaction.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      final lc = m['last_check_in'];
      _lastCheckIn = lc == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch((lc as num).toInt());
      _checkInStreak = (m['check_in_streak'] as num?)?.toInt() ?? 0;
      final dcc = m['daily_chapter_coins'];
      if (dcc is Map) {
        dcc.forEach((k, v) => _dailyChapterCoins['$k'] = (v as num).toInt());
      }
      final dco = m['daily_comment_coins'];
      if (dco is Map) {
        dco.forEach((k, v) => _dailyCommentCoins['$k'] = (v as num).toInt());
      }
      final owned = m['owned_shop_items'];
      if (owned is List) {
        _ownedShopItems.addAll(owned.map((e) => '$e'));
      }
      _boostActive = m['boost_active'] == true;
      final bu = m['boost_until'];
      _boostUntil = bu == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch((bu as num).toInt());
    } catch (_) {
      _seedWelcome();
    }
  }

  void _save() {
    _p.setString(_kCoinsKey, jsonEncode({
      'balance': _balance,
      'transactions': _transactions.map((e) => e.toJson()).toList(),
      'last_check_in': _lastCheckIn?.millisecondsSinceEpoch,
      'check_in_streak': _checkInStreak,
      'daily_chapter_coins': _dailyChapterCoins,
      'daily_comment_coins': _dailyCommentCoins,
      'owned_shop_items': _ownedShopItems.toList(),
      'boost_active': _boostActive,
      'boost_until': _boostUntil?.millisecondsSinceEpoch,
    }));
  }

  void _seedWelcome() {
    _balance = 100;
    _transactions = [
      CoinTransaction(
        id: 'welcome',
        at: DateTime.now(),
        amount: 100,
        kind: CoinTransactionKind.reward,
        reason: 'مكافأة ترحيبية',
      ),
    ];
    _save();
  }

  void _add(CoinTransaction t) {
    _transactions.insert(0, t);
    if (_transactions.length > 300) {
      _transactions = _transactions.sublist(0, 300);
    }
    _balance += t.amount;
  }

  /// يُنادى عند إكمال فصل في القارئ. يُعيد العملات المكتسبة (0 عند بلوغ الحد).
  int recordChapterRead({String? seriesId, String? seriesTitle}) {
    final today = _dayKey(DateTime.now());
    final earned = chapterCoinsToday();
    if (earned >= kDailyChapterCoinsCap) return 0;
    var coins = kCoinsPerChapter;
    if (boostActive) coins *= 2;
    final grant = (coins).clamp(0, kDailyChapterCoinsCap - earned);
    if (grant <= 0) return 0;
    _dailyChapterCoins[today] = earned + grant;
    _add(
      CoinTransaction(
        id: 'ch_${DateTime.now().millisecondsSinceEpoch}',
        at: DateTime.now(),
        amount: grant,
        kind: CoinTransactionKind.chapterRead,
        reason: 'أكملت فصلاً',
        seriesTitle: seriesTitle ?? '',
      ),
    );
    _save();
    notifyListeners();
    return grant;
  }

  /// تسجيل الدخول اليومي. يُعيد العملات المكتسبة (0 إن سجّلت اليوم already).
  int recordDailyCheckIn({DateTime? now}) {
    final today = now ?? DateTime.now();
    if (_lastCheckIn != null) {
      final last = _lastCheckIn!;
      final sameDay = last.year == today.year &&
          last.month == today.month &&
          last.day == today.day;
      if (sameDay) return 0;
      final yesterday = today.subtract(const Duration(days: 1));
      final consecutive = last.year == yesterday.year &&
          last.month == yesterday.month &&
          last.day == yesterday.day;
      _checkInStreak = consecutive ? _checkInStreak + 1 : 1;
    } else {
      _checkInStreak = 1;
    }
    final reward = kCheckInLadder[(_checkInStreak - 1)
        .clamp(0, kCheckInLadder.length - 1)];
    _lastCheckIn = today;
    _add(
      CoinTransaction(
        id: 'ci_${today.millisecondsSinceEpoch}',
        at: today,
        amount: reward,
        kind: CoinTransactionKind.dailyCheckIn,
        reason: 'تسجيل دخول — اليوم $_checkInStreak على التوالي',
      ),
    );
    _save();
    notifyListeners();
    return reward;
  }

  /// يُنادى عند نشر تعليق. يُعيد العملات المكتسبة (0 عند بلوغ الحد).
  int recordComment() {
    final today = _dayKey(DateTime.now());
    final earned = commentCoinsToday();
    if (earned >= kDailyCommentCoinsCap) return 0;
    final grant = kCoinsPerComment.clamp(0, kDailyCommentCoinsCap - earned);
    if (grant <= 0) return 0;
    _dailyCommentCoins[today] = earned + grant;
    _add(
      CoinTransaction(
        id: 'cm_${DateTime.now().millisecondsSinceEpoch}',
        at: DateTime.now(),
        amount: grant,
        kind: CoinTransactionKind.comment,
        reason: 'علّقت على فصل',
      ),
    );
    _save();
    notifyListeners();
    return grant;
  }

  /// مكافأة إحالة ناجحة.
  void recordReferralBonus({String friendName = ''}) {
    _add(
      CoinTransaction(
        id: 'rf_${DateTime.now().millisecondsSinceEpoch}',
        at: DateTime.now(),
        amount: kReferralBonusCoins,
        kind: CoinTransactionKind.referral,
        reason: friendName.isEmpty
            ? 'انضم صديق عبر رابطك'
            : 'انضم $friendName عبر رابطك',
      ),
    );
    _save();
    notifyListeners();
  }

  /// مكافأة عامة (تحدٍّ أو إنجاز).
  void grantReward(int coins, String reason) {
    if (coins <= 0) return;
    _add(
      CoinTransaction(
        id: 'rw_${DateTime.now().millisecondsSinceEpoch}',
        at: DateTime.now(),
        amount: coins,
        kind: CoinTransactionKind.reward,
        reason: reason,
      ),
    );
    _save();
    notifyListeners();
  }

  /// إنفاق عملات. يُعيد رسالة خطأ أو null عند النجاح.
  String? spendCoins(int amount, String reason) {
    if (amount <= 0) return 'المبلغ غير صحيح.';
    if (amount > _balance) return 'رصيدك ${formatCoins(_balance)} فقط.';
    _add(
      CoinTransaction(
        id: 'sp_${DateTime.now().millisecondsSinceEpoch}',
        at: DateTime.now(),
        amount: -amount,
        kind: CoinTransactionKind.spend,
        reason: reason,
      ),
    );
    _save();
    notifyListeners();
    return null;
  }

  /// شراء عنصر من المتجر. يُعيد رسالة خطأ أو null عند النجاح.
  String? buyShopItem(CoinShopItem item) {
    if (owns(item.id)) return 'تملك هذا العنصر بالفعل.';
    final err = spendCoins(item.priceCoins, 'شراء: ${item.title}');
    if (err != null) return err;
    _ownedShopItems.add(item.id);
    if (item.id == 'boost_week') {
      _boostActive = true;
      _boostUntil = DateTime.now().add(const Duration(days: 7));
    }
    _save();
    notifyListeners();
    return null;
  }

  /// إجمالي ما كُسب (عملات).
  int get totalEarned => _transactions
      .where((e) => e.isEarn)
      .fold<int>(0, (a, e) => a + e.amount);

  /// إجمالي ما أُنفق (عملات).
  int get totalSpent => _transactions
      .where((e) => !e.isEarn)
      .fold<int>(0, (a, e) => a + (-e.amount));
}

// ───────── واجهة العملات والمكافآت ─────────

/// شاشة العملات والمكافآت.
class CoinsRewardsScreen extends StatelessWidget {
  const CoinsRewardsScreen({super.key, required this.store});
  final SardCoinsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(title: const Text('العملات والمكافآت')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              _CoinsBalanceCard(store: store),
              const SizedBox(height: 14),
              _CheckInCard(store: store),
              const SizedBox(height: 18),
              Text('كيف تكسب العملات؟', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              _EarnRulesCard(store: store),
              const SizedBox(height: 18),
              Text('متجر المكافآت', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              for (final item in kCoinShopItems)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ShopItemTile(item: item, store: store),
                ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Text('سجل الحركات', style: context.ds(size: 18)),
                  const Spacer(),
                  Text(
                    '${store.transactions.length} حركة',
                    style: context.ts(color: p.textDim),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (store.transactions.isEmpty)
                _CoinsEmpty()
              else
                for (var i = 0; i < store.transactions.length && i < 25; i++)
                  Padding(
                    padding: EdgeInsets.only(
                      bottom: i == 24 || i == store.transactions.length - 1
                          ? 0
                          : 10,
                    ),
                    child: _CoinTransactionTile(t: store.transactions[i]),
                  ),
              const SizedBox(height: 14),
              Text(
                'العملات محلية ولا قيمة نقدية لها، ولا تُشترى بمال حقيقي '
                'في هذه النسخة.',
                style: context.ts(size: 12, color: p.textDim, height: 1.6),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _CoinsBalanceCard extends StatelessWidget {
  const _CoinsBalanceCard({required this.store});
  final SardCoinsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: p.accent,
        borderRadius: BorderRadius.circular(p.r(1.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.star_rounded, size: 20, color: p.gold),
              const SizedBox(width: 8),
              Text(
                'رصيدك من العملات',
                style: context.ts(color: p.onAccent, w: FontWeight.w700),
              ),
              const Spacer(),
              if (store.boostActive)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: tint(Colors.white, 0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(SardIcons.bolt_rounded, size: 13, color: p.onAccent),
                      const SizedBox(width: 3),
                      Text(
                        'تعزيز ×2 نشط',
                        style: context.ts(
                          size: 11.5,
                          w: FontWeight.w800,
                          color: p.onAccent,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            formatCoins(store.balance),
            style: context.ds(size: 30, color: p.onAccent),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(
                'كسبت: ${formatCoins(store.totalEarned)}',
                style: context.ts(color: p.onAccent),
              ),
              const SizedBox(width: 16),
              Text(
                'أنفقت: ${formatCoins(store.totalSpent)}',
                style: context.ts(color: p.onAccent),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CheckInCard extends StatelessWidget {
  const _CheckInCard({required this.store});
  final SardCoinsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final done = store.checkedInToday;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('تسجيل الدخول اليومي', style: context.ds(size: 16)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: tint(p.gold, 0.16),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SIcon(SardIcons.local_fire_department_rounded, size: 14, color: p.gold),
                    const SizedBox(width: 3),
                    Text(
                      '${store.checkInStreak} يوم متتالٍ',
                      style: context.ts(size: 12, w: FontWeight.w800, color: p.gold),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              for (var i = 0; i < kCheckInLadder.length; i++)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: i == kCheckInLadder.length - 1 ? 0 : 5,
                    ),
                    child: _CheckInDay(
                      day: i + 1,
                      coins: kCheckInLadder[i],
                      // الأيام المكتملة هي أول streak يوماً؛ واليوم التالي هو يوم اليوم.
                      done: i < store.checkInStreak,
                      today: !done && i == store.checkInStreak,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: done
                  ? null
                  : () {
                      final got = store.recordDailyCheckIn();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            got > 0
                                ? 'سجّلت دخولك وكسبت ${formatCoins(got)}!'
                                : 'سجّلت دخولك اليوم بالفعل.',
                          ),
                        ),
                      );
                    },
              icon: const SIcon(SardIcons.calendar_today_rounded, size: 18),
              label: Text(
                done
                    ? 'سجّلت دخولك اليوم — عُد غداً'
                    : 'سجّل دخولك واكسب ${formatCoins(store.nextCheckInReward)}',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CheckInDay extends StatelessWidget {
  const _CheckInDay({
    required this.day,
    required this.coins,
    required this.done,
    required this.today,
  });
  final int day;
  final int coins;
  final bool done;
  final bool today;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = done
        ? const Color(0xFF0F9D75)
        : today
            ? p.accent
            : p.textDim;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: done
            ? tint(const Color(0xFF0F9D75), 0.12)
            : today
                ? tint(p.accent, 0.12)
                : p.surfaceHi,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: today ? p.accent : Colors.transparent,
        ),
      ),
      child: Column(
        children: [
          Text('يوم $day', style: context.ts(size: 10.5, color: p.textDim)),
          const SizedBox(height: 2),
          SIcon(
            done ? SardIcons.check_circle_rounded : SardIcons.star_rounded,
            size: 15,
            color: color,
          ),
          const SizedBox(height: 2),
          Text(
            '+$coins',
            style: context.ts(size: 11, w: FontWeight.w800, color: color),
          ),
        ],
      ),
    );
  }
}

class _EarnRulesCard extends StatelessWidget {
  const _EarnRulesCard({required this.store});
  final SardCoinsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final rules = <(SIconData, String, String)>[
      (
        SardIcons.menu_book_rounded,
        'قراءة فصل: +$kCoinsPerChapter عملات',
        'حتى ${formatCoins(kDailyChapterCoinsCap)} يومياً '
            '(كسبت اليوم ${formatCoins(store.chapterCoinsToday())}).',
      ),
      (
        SardIcons.calendar_today_rounded,
        'تسجيل دخول يومي: +${kCheckInLadder.first}–${kCheckInLadder.last} عملة',
        'تزيد المكافأة مع توالي الأيام حتى اليوم السابع.',
      ),
      (
        SardIcons.chat_bubble_rounded,
        'تعليق: +$kCoinsPerComment عملات',
        'حتى ${formatCoins(kDailyCommentCoinsCap)} يومياً.',
      ),
      (
        SardIcons.share_rounded,
        'إحالة صديق: +$kReferralBonusCoins عملة',
        'عند انضمام صديق عبر رابط إحالتك.',
      ),
    ];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          for (var i = 0; i < rules.length; i++) ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 36,
                  height: 36,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(p.accent, 0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: SIcon(rules[i].$1, size: 18, color: p.accent),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(rules[i].$2, style: context.ts(w: FontWeight.w700)),
                      const SizedBox(height: 2),
                      Text(
                        rules[i].$3,
                        style: context.ts(size: 12.5, color: p.textDim, height: 1.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (i < rules.length - 1) const SizedBox(height: 12),
          ],
        ],
      ),
    );
  }
}

class _ShopItemTile extends StatelessWidget {
  const _ShopItemTile({required this.item, required this.store});
  final CoinShopItem item;
  final SardCoinsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final owned = store.owns(item.id);
    final afford = store.balance >= item.priceCoins;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.gold, 0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SIcon(item.icon, size: 21, color: p.gold),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.title, style: context.ts(w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  item.description,
                  style: context.ts(size: 12.5, color: p.textDim, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                formatCoins(item.priceCoins),
                style: context.ts(w: FontWeight.w800, color: p.accent),
              ),
              const SizedBox(height: 6),
              SizedBox(
                height: 32,
                child: owned
                    ? Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: tint(const Color(0xFF0F9D75), 0.12),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Text(
                          'تملكه',
                          style: TextStyle(
                            color: Color(0xFF0F9D75),
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                          ),
                        ),
                      )
                    : FilledButton(
                        onPressed: afford
                            ? () {
                                final err = store.buyShopItem(item);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      err ?? 'اشتريت «${item.title}» بنجاح!',
                                    ),
                                  ),
                                );
                              }
                            : null,
                        child: const Text('شراء'),
                      ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CoinTransactionTile extends StatelessWidget {
  const _CoinTransactionTile({required this.t});
  final CoinTransaction t;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(
                t.isEarn ? const Color(0xFF0F9D75) : const Color(0xFFE5484D),
                0.12,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: SIcon(
              coinKindIcon(t.kind),
              size: 18,
              color: t.isEarn
                  ? const Color(0xFF0F9D75)
                  : const Color(0xFFE5484D),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.reason, style: context.ts(w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  '${t.kind.label}'
                  '${t.seriesTitle.isNotEmpty ? ' · ${t.seriesTitle}' : ''}'
                  ' · ${formatSardDate(t.at)}',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          Text(
            '${t.isEarn ? '+' : ''}${formatCoins(t.amount)}',
            style: context.ts(
              w: FontWeight.w800,
              color: t.isEarn
                  ? const Color(0xFF0F9D75)
                  : const Color(0xFFE5484D),
            ),
          ),
        ],
      ),
    );
  }
}

class _CoinsEmpty extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Text(
        'لا حركات بعد. اقرأ فصلاً أو سجّل دخولك لتكسب أول عملاتك.',
        textAlign: TextAlign.center,
        style: context.ts(color: p.textDim),
      ),
    );
  }
}
