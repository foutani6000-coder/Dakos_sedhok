import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/config/app_config.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/ink_spirit.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // حلقات هادئة تتّسع خلف الختم
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: 1),
            duration: const Duration(milliseconds: 1600),
            curve: Curves.easeOutCubic,
            builder: (context, v, _) => CustomPaint(
              painter: _RingsPainter(progress: v, color: p.accent, line: p.text),
            ),
          ),
          Center(
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: 1),
              duration: const Duration(milliseconds: 1100),
              curve: Curves.easeOutBack,
              builder: (context, v, _) => Opacity(
                opacity: v.clamp(0.0, 1.0),
                child: Transform.scale(
                  scale: 0.7 + 0.3 * v,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const LogoMark(size: 104, glow: true),
                      const SizedBox(height: 28),
                      Text(AppConfig.appName, style: context.ds(size: 46, height: 1)),
                      const SizedBox(height: 14),
                      Container(
                        width: 34,
                        height: 3,
                        decoration: BoxDecoration(
                          color: p.accent,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text('احكِ الحكاية.. واقرأها',
                          style: context.ts(size: 14, color: p.textDim)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RingsPainter extends CustomPainter {
  const _RingsPainter({required this.progress, required this.color, required this.line});
  final double progress;
  final Color color;
  final Color line;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2 - 20);
    final maxR = math.max(size.width, size.height) * 0.7;
    // وهج مركزي
    canvas.drawCircle(
      c,
      maxR * 0.5 * progress,
      Paint()
        ..shader = RadialGradient(
          colors: [color.withAlpha(46), color.withAlpha(0)],
        ).createShader(Rect.fromCircle(center: c, radius: maxR * 0.5 * progress + 1)),
    );
    for (var i = 1; i <= 4; i++) {
      final r = maxR * 0.16 * i * progress;
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = line.withAlpha(26 - i * 5),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RingsPainter old) =>
      old.progress != progress || old.color != color || old.line != line;
}
