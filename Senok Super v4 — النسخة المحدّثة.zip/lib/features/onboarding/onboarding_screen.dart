import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/config/app_config.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/ink_spirit.dart';
import '../../widgets/pickers.dart';
import '../../widgets/states.dart';
import '../../widgets/sard_icons.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final s = context.read<SettingsController>();
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(top: 24, bottom: 24),
          children: [
            FadeSlide(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('أهلاً بك في ${AppConfig.appName}',
                              style: context.ds(size: 30, height: 1.3)),
                          const SizedBox(height: 8),
                          Text('خصّص تجربتك في ثوانٍ، ويمكنك تغييرها لاحقاً من الإعدادات.',
                              style: context.ts(size: 14, color: p.textDim, height: 1.7)),
                        ],
                      ),
                    ),
                    const LogoMark(size: 58, glow: true),
                  ],
                ),
              ),
            ),
            const FadeSlide(index: 1, child: _Title('اختر ثيمك')),
            const FadeSlide(index: 2, child: ThemePicker()),
            const FadeSlide(index: 3, child: _Title('توفير البيانات')),
            const FadeSlide(index: 4, child: DataModePicker()),
            const SizedBox(height: 32),
            FadeSlide(
              index: 5,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: PrimaryButton(
                  label: 'ابدأ القراءة',
                  icon: SardIcons.auto_stories_rounded,
                  onTap: s.finishOnboarding,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: TextButton(
                onPressed: s.finishOnboarding,
                child: Text('تخطّي', style: context.ts(size: 14, color: p.textDim)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Title extends StatelessWidget {
  const _Title(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 30, 20, 14),
      child: Row(children: [
        Container(
          width: 5,
          height: 20,
          decoration: BoxDecoration(
            color: context.pal.accent,
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        const SizedBox(width: 10),
        Text(text, style: context.ds(size: 20)),
      ]),
    );
  }
}
