// ──────────────────────────────────────────────────────────────────────────
//  الإعدادات الاحترافية — لوحة تحكم واحدة للأداء والأوفلاين
//  ──────────────────────────────────────────────────────────────────────────
//  تجمع في شاشة واحدة:
//    • التنزيلات v2: إحصاءات + طابور + سياسة الشبكة
//    • التخزين: قياس فعلي + تنظيف + حدود
//    • المزامنة: آخر مزامنة + التعارضات المعلّقة + مزامنة يدوية
//    • النسخ الاحتياطي: تصدير/استيراد + نسخ تلقائي
//    • التذكيرات: تفعيل + وقت + أيام + ساعات هدوء (لافتات داخل التطبيق فقط)
//    • الأداء: وضع البيانات + التحميل المسبق + جودة الصور + حجم الخط
// ──────────────────────────────────────────────────────────────────────────
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/perf/backup_restore.dart';
import '../../core/perf/download_engine_v2.dart';
import '../../core/perf/image_pipeline.dart';
import '../../core/perf/reading_reminders.dart';
import '../../core/perf/storage_manager.dart';
import '../../core/perf/sync_engine.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// شاشة الإعدادات الاحترافية (تُفتح من القائمة الجانبية).
class SettingsProScreen extends StatefulWidget {
  const SettingsProScreen({super.key});

  @override
  State<SettingsProScreen> createState() => _SettingsProScreenState();
}

class _SettingsProScreenState extends State<SettingsProScreen> {
  bool _measuring = false;
  bool _syncing = false;
  bool _exporting = false;
  StorageUsage? _usage;

  @override
  void initState() {
    super.initState();
    // المفردات (محرك التنزيل، المزامنة، النسخ، التذكيرات) ليست مزوَّدة عبر
    // Provider، لذا نستمع لها مباشرة ونعيد البناء عند تغيّرها.
    V2DownloadEngine.i.addListener(_onPerfChanged);
    SyncEngine.i.addListener(_onPerfChanged);
    BackupStore.i.addListener(_onPerfChanged);
    ReminderCenter.i.addListener(_onPerfChanged);
    _boot();
  }

  void _onPerfChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    V2DownloadEngine.i.removeListener(_onPerfChanged);
    SyncEngine.i.removeListener(_onPerfChanged);
    BackupStore.i.removeListener(_onPerfChanged);
    ReminderCenter.i.removeListener(_onPerfChanged);
    super.dispose();
  }

  Future<void> _boot() async {
    await Future.wait([
      V2DownloadEngine.i.load(),
      StorageManager.i.load(),
      SyncEngine.i.load(),
      BackupStore.i.load(),
      ReminderCenter.i.load(),
    ]);
    if (!mounted) return;
    setState(() => _usage = StorageManager.i.lastUsage);
    unawaited(_refreshUsage());
  }

  Future<void> _refreshUsage() async {
    if (_measuring) return;
    setState(() => _measuring = true);
    final usage = await StorageManager.i.measure();
    if (mounted) setState(() {
      _usage = usage;
      _measuring = false;
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final settings = context.watch<SettingsController>();
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('الإعدادات الاحترافية', style: context.ts(size: 18, w: FontWeight.w700)),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: SIcon(SardIcons.arrow_back_rounded, color: p.text),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          _DownloadsCard(onOpenQueue: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const V2DownloadQueueScreen()),
            );
          }),
          const SizedBox(height: 14),
          _StorageCard(
            usage: _usage,
            measuring: _measuring,
            limits: StorageManager.i.limits,
            onMeasure: _refreshUsage,
            onClean: _cleanStorage,
            onLimitsChanged: (limits) async {
              await StorageManager.i.setLimits(limits);
              if (mounted) setState(() {});
            },
          ),
          const SizedBox(height: 14),
          _SyncCard(
            syncing: _syncing,
            onSync: _runSync,
            onOpenConflicts: () => _showConflictsSheet(),
          ),
          const SizedBox(height: 14),
          _BackupCard(
            exporting: _exporting,
            onExport: _exportBackup,
            onImport: _showImportDialog,
          ),
          const SizedBox(height: 14),
          _RemindersCard(
            onChanged: () {
              if (mounted) setState(() {});
            },
          ),
          const SizedBox(height: 14),
          _PerformanceCard(settings: settings),
          const SizedBox(height: 14),
          _DiagnosticsCard(onOpenQueue: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const V2DownloadQueueScreen()),
            );
          }),
          const SizedBox(height: 14),
          const _DataUsageCard(),
          const SizedBox(height: 14),
          _DangerZoneCard(onChanged: () {
            if (mounted) setState(() {});
          }),
          const SizedBox(height: 14),
          _AboutCard(),
          const SizedBox(height: 8),
          Text(
            'التذكيرات لافتات داخل التطبيق فقط — لا إشعارات نظام لأن التطبيق لا يتضمن حزمة إشعارات خارجية.',
            textAlign: TextAlign.center,
            style: context.ts(size: 11.5, color: p.textDim),
          ),
        ],
      ),
    );
  }

  Future<void> _cleanStorage() async {
    final result = await StorageManager.i.cleanAll();
    _snack(result.summary);
    await _refreshUsage();
  }

  Future<void> _runSync() async {
    if (_syncing) return;
    setState(() => _syncing = true);
    final report = await SyncEngine.i.syncNow();
    if (mounted) {
      setState(() => _syncing = false);
      _snack(report.summary);
    }
  }

  Future<void> _exportBackup() async {
    if (_exporting) return;
    setState(() => _exporting = true);
    final package = await BackupStore.i.exportBackup();
    if (!mounted) return;
    setState(() => _exporting = false);
    final encoded = package.encode();
    await showDialog<void>(
      context: context,
      builder: (context) {
        final p = context.pal;
        return AlertDialog(
          title: Text('نسختك الاحتياطية جاهزة', style: context.ts(size: 16, w: FontWeight.w700)),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(BackupStore.describePackage(package), style: context.ts(size: 13, color: p.textDim)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: p.surfaceHi,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: SelectableText(
                    encoded,
                    style: context.ts(size: 11, color: p.textDim),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'انسخ النص واحفظه في مكان آمن. لاستعادته الصق النص في «استيراد نسخة».',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('إغلاق'),
            ),
            FilledButton(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: encoded));
                if (context.mounted) Navigator.of(context).pop();
                _snack('نُسخت النسخة الاحتياطية');
              },
              child: const Text('نسخ النص'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _showImportDialog() async {
    final controller = TextEditingController();
    final passphrase = TextEditingController();
    var busy = false;
    var message = '';
    await showDialog<void>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            final p = context.pal;
            return AlertDialog(
              title: Text('استيراد نسخة احتياطية', style: context.ts(size: 16, w: FontWeight.w700)),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: controller,
                      maxLines: 5,
                      decoration: InputDecoration(
                        hintText: 'الصق نص النسخة هنا (يبدأ بـ SENOKBK1.)',
                        hintStyle: context.ts(size: 12, color: p.textDim),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: passphrase,
                      decoration: InputDecoration(
                        hintText: 'عبارة المرور (إن كانت النسخة محمية)',
                        hintStyle: context.ts(size: 12, color: p.textDim),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                    if (message.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text(message, style: context.ts(size: 12.5, color: p.accent)),
                    ],
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('إلغاء'),
                ),
                FilledButton(
                  onPressed: busy
                      ? null
                      : () async {
                          setDialogState(() => busy = true);
                          final text = controller.text.trim();
                          if (!backupSizeAcceptable(text)) {
                            setDialogState(() {
                              busy = false;
                              message = 'النص كبير جداً (الحدّ 10 م.ب)';
                            });
                            return;
                          }
                          final result = await BackupStore.i.importBackup(
                            text,
                            passphrase: passphrase.text.isEmpty ? null : passphrase.text,
                          );
                          if (!context.mounted) return;
                          Navigator.of(context).pop();
                          _snack(result.summary);
                          if (result.success && result.applied.isNotEmpty) {
                            _snack('${result.summary} — أعد تشغيل التطبيق لتطبيق كل الإعدادات');
                          }
                        },
                  child: const Text('استيراد'),
                ),
              ],
            );
          },
        );
      },
    );
    controller.dispose();
    passphrase.dispose();
  }

  Future<void> _showConflictsSheet() async {
    final conflicts = SyncEngine.i.pendingConflicts;
    if (conflicts.isEmpty) {
      _snack('لا توجد تعارضات معلّقة');
      return;
    }
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        final p = context.pal;
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.6,
          minChildSize: 0.4,
          maxChildSize: 0.9,
          builder: (context, scroll) {
            return Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: ListView(
                controller: scroll,
                children: [
                  Text('تعارضات المزامنة (${conflicts.length})', style: context.ds(size: 18)),
                  const SizedBox(height: 4),
                  Text(
                    'تغيّر التقدّم في جهازين معاً بعد آخر مزامنة — اختر النسخة التي تُبقيها لكل تعارض.',
                    style: context.ts(size: 12.5, color: p.textDim),
                  ),
                  const SizedBox(height: 12),
                  for (final c in conflicts) _ConflictTile(conflict: c),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () async {
                      final n = await SyncEngine.i.resolveAllByMerge();
                      if (context.mounted) Navigator.of(context).pop();
                      _snack('دُمج $n تعارض (الأبعد يفوز)');
                    },
                    child: const Text('دمج الكل تلقائياً'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    if (mounted) setState(() {});
  }
}

/// بطاقة قسم في الإعدادات الاحترافية.
class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.child,
  });

  final SIconData icon;
  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border, width: p.borderW),
        boxShadow: softShadow(p, strength: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(color: tint(p.accent, 0.12), shape: BoxShape.circle),
                child: SIcon(icon, size: 20, color: p.accent),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: context.ts(size: 15, w: FontWeight.w700)),
                    Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

/// صف مفتاح (تبديل) داخل بطاقة.
class _SwitchRow extends StatelessWidget {
  const _SwitchRow({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.ts(size: 13.5, w: FontWeight.w600)),
                Text(subtitle, style: context.ts(size: 11.5, color: p.textDim)),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChanged, activeColor: p.accent),
        ],
      ),
    );
  }
}

/// زر إجراء داخل بطاقة.
class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final SIconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            SIcon(icon, size: 20, color: p.accent),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: context.ts(size: 13.5, w: FontWeight.w600)),
                  Text(subtitle, style: context.ts(size: 11.5, color: p.textDim)),
                ],
              ),
            ),
            SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
          ],
        ),
      ),
    );
  }
}

/// شريط تقدّم مع تسمية.
class _LabeledProgress extends StatelessWidget {
  const _LabeledProgress({required this.label, required this.value, required this.detail});
  final String label;
  final double value;
  final String detail;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(label, style: context.ts(size: 12.5, w: FontWeight.w600))),
            Text(detail, style: context.ts(size: 12, color: p.textDim)),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: value.clamp(0.0, 1.0).toDouble(),
            minHeight: 7,
            backgroundColor: p.border,
            valueColor: AlwaysStoppedAnimation<Color>(p.accent),
          ),
        ),
      ],
    );
  }
}

// ───────── بطاقة التنزيلات ─────────

class _DownloadsCard extends StatelessWidget {
  const _DownloadsCard({required this.onOpenQueue});
  final VoidCallback onOpenQueue;

  @override
  Widget build(BuildContext context) {
    final engine = V2DownloadEngine.i;
    final stats = engine.stats;
    return _SectionCard(
      icon: SardIcons.download_rounded,
      title: 'التنزيلات',
      subtitle: 'محرك v2 — طابور بأولويات واستئناف تلقائي',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _MiniStat(label: 'نشط', value: '${stats.active + stats.queued}'),
              _MiniStat(label: 'مكتمل', value: '${stats.completed}'),
              _MiniStat(label: 'فشل', value: '${stats.failed}'),
              _MiniStat(label: 'اليوم', value: formatBytesAr(stats.todayBytes)),
            ],
          ),
          const SizedBox(height: 10),
          _LabeledProgress(
            label: 'التقدّم الكلي',
            value: stats.overallProgress,
            detail: '${stats.overallPercent}٪',
          ),
          const SizedBox(height: 6),
          _ActionRow(
            icon: SardIcons.download_done_rounded,
            title: 'طابور التنزيلات',
            subtitle: stats.hasActive ? 'تنزيلات جارية — اضغط للمتابعة والإيقاف' : 'لا تنزيلات جارية حالياً',
            onTap: onOpenQueue,
          ),
          _SwitchRow(
            title: 'الاستئناف التلقائي',
            subtitle: 'استئناف التنزيلات عند عودة الشبكة',
            value: engine.autoResume,
            onChanged: (v) => engine.setAutoResume(v),
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Container(
        margin: const EdgeInsets.only(left: 6),
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: p.surfaceHi,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            Text(value, style: context.ds(size: 15, w: FontWeight.w800)),
            Text(label, style: context.ts(size: 11, color: p.textDim)),
          ],
        ),
      ),
    );
  }
}

// ───────── بطاقة التخزين ─────────

class _StorageCard extends StatelessWidget {
  const _StorageCard({
    required this.usage,
    required this.measuring,
    required this.limits,
    required this.onMeasure,
    required this.onClean,
    required this.onLimitsChanged,
  });

  final StorageUsage? usage;
  final bool measuring;
  final StorageLimits limits;
  final VoidCallback onMeasure;
  final VoidCallback onClean;
  final ValueChanged<StorageLimits> onLimitsChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final u = usage;
    final tier = u == null ? StorageTier.healthy : u.tierFor(limits.downloadLimitBytes);
    return _SectionCard(
      icon: SardIcons.layers_rounded,
      title: 'التخزين',
      subtitle: 'قياس فعلي للمساحة وتنظيف آمن',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (u == null)
            Text(measuring ? 'جارٍ القياس…' : 'اضغط «قياس» لعرض الاستخدام الفعلي',
                style: context.ts(size: 12.5, color: p.textDim))
          else ...[
            Row(
              children: [
                Text('الحالة: ${tier.label}', style: context.ts(size: 13, w: FontWeight.w700, color: p.accent)),
                const Spacer(),
                Text(u.totalLabel, style: context.ds(size: 16, w: FontWeight.w800)),
              ],
            ),
            const SizedBox(height: 4),
            Text(tier.hint, style: context.ts(size: 12, color: p.textDim)),
            const SizedBox(height: 10),
            _LabeledProgress(label: 'التنزيلات', value: u.downloadsBytes / (u.totalBytes == 0 ? 1 : u.totalBytes), detail: u.downloadsLabel),
            const SizedBox(height: 8),
            _LabeledProgress(label: 'صور مؤقتة', value: u.imageCacheBytes / (u.totalBytes == 0 ? 1 : u.totalBytes), detail: u.imageCacheLabel),
            const SizedBox(height: 8),
            _LabeledProgress(label: 'ملفات مؤقتة', value: u.tempBytes / (u.totalBytes == 0 ? 1 : u.totalBytes), detail: u.tempLabel),
            const SizedBox(height: 8),
            Text('قابل للتحرير فوراً: ${u.reclaimableLabel} (صور وملفات مؤقتة)',
                style: context.ts(size: 12, color: p.textDim)),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: measuring ? null : onMeasure,
                  icon: SIcon(SardIcons.refresh_rounded, size: 18, color: p.text),
                  label: Text(measuring ? 'جارٍ القياس…' : 'قياس المساحة'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.icon(
                  onPressed: onClean,
                  icon: const SIcon(SardIcons.delete_outline_rounded, size: 18),
                  label: const Text('تنظيف سريع'),
                ),
              ),
            ],
          ),
          _SwitchRow(
            title: 'تنظيف تلقائي لذاكرة الصور',
            subtitle: 'امسح الصور المؤقتة حين تتجاوز ${limits.cacheLimitMB} م.ب',
            value: limits.autoCleanCache,
            onChanged: (v) => onLimitsChanged(limits.copyWith(autoCleanCache: v)),
          ),
        ],
      ),
    );
  }
}

// ───────── بطاقة المزامنة ─────────

class _SyncCard extends StatelessWidget {
  const _SyncCard({required this.syncing, required this.onSync, required this.onOpenConflicts});
  final bool syncing;
  final VoidCallback onSync;
  final VoidCallback onOpenConflicts;

  @override
  Widget build(BuildContext context) {
    final engine = SyncEngine.i;
    final p = context.pal;
    final last = engine.lastSyncAt.millisecondsSinceEpoch == 0
        ? 'لم تتم مزامنة بعد'
        : 'آخر مزامنة: ${_syncAgo(engine.lastSyncAt)}';
    return _SectionCard(
      icon: SardIcons.sync_rounded,
      title: 'المزامنة',
      subtitle: 'تقدّم القراءة عبر الأجهزة',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(last, style: context.ts(size: 13, w: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(
            engine.pendingUploadCount > 0
                ? '${engine.pendingUploadCount} سجل بانتظار الرفع'
                : 'لا سجلات بانتظار الرفع',
            style: context.ts(size: 12, color: p.textDim),
          ),
          if (engine.pendingConflictCount > 0) ...[
            const SizedBox(height: 8),
            InkWell(
              onTap: onOpenConflicts,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    SIcon(SardIcons.priority_high_rounded, size: 18, color: p.accent),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '${engine.pendingConflictCount} تعارض بانتظار قرارك — اضغط لحلّها',
                        style: context.ts(size: 12.5, w: FontWeight.w600, color: p.accent),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: syncing ? null : onSync,
              icon: SIcon(SardIcons.sync_rounded, size: 18, color: p.onAccent),
              label: Text(syncing ? 'جارٍ المزامنة…' : 'مزامنة الآن'),
            ),
          ),
          if (engine.lastReport != null) ...[
            const SizedBox(height: 8),
            Text(engine.lastReport!.summary, style: context.ts(size: 12, color: p.textDim)),
          ],
        ],
      ),
    );
  }

  static String _syncAgo(DateTime at) {
    final diff = DateTime.now().difference(at);
    if (diff.inMinutes < 1) return 'الآن';
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} د';
    if (diff.inHours < 24) return 'منذ ${diff.inHours} س';
    return 'منذ ${diff.inDays} يوم';
  }
}

// ───────── بطاقة النسخ الاحتياطي ─────────

class _BackupCard extends StatelessWidget {
  const _BackupCard({required this.exporting, required this.onExport, required this.onImport});
  final bool exporting;
  final VoidCallback onExport;
  final VoidCallback onImport;

  @override
  Widget build(BuildContext context) {
    final store = BackupStore.i;
    final p = context.pal;
    final last = store.lastBackupAt;
    return _SectionCard(
      icon: SardIcons.shield_rounded,
      title: 'النسخ الاحتياطي',
      subtitle: 'مكتبتك في ملف واحد — بلا خادم',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            last == null
                ? 'لم تنشئ نسخة احتياطية بعد'
                : 'آخر نسخة: ${last.year}/${last.month}/${last.day} — ${last.hour.toString().padLeft(2, '0')}:${last.minute.toString().padLeft(2, '0')}',
            style: context.ts(size: 12.5, color: p.textDim),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: exporting ? null : onExport,
                  icon: const SIcon(SardIcons.share_rounded, size: 18),
                  label: Text(exporting ? 'جارٍ التصدير…' : 'تصدير نسخة'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onImport,
                  icon: SIcon(SardIcons.download_rounded, size: 18, color: p.text),
                  label: const Text('استيراد نسخة'),
                ),
              ),
            ],
          ),
          _SwitchRow(
            title: 'نسخ تلقائي',
            subtitle: 'ذكّرني بنسخة كل ${store.autoIntervalDays} أيام',
            value: store.autoEnabled,
            onChanged: (v) => store.setAutoBackup(v),
          ),
        ],
      ),
    );
  }
}

// ───────── بطاقة التذكيرات ─────────

class _RemindersCard extends StatelessWidget {
  const _RemindersCard({required this.onChanged});
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    final center = ReminderCenter.i;
    final s = center.settings;
    final p = context.pal;
    return _SectionCard(
      icon: SardIcons.notifications_active_rounded,
      title: 'تذكيرات القراءة',
      subtitle: 'لافتات داخل التطبيق فقط — بلا إشعارات نظام',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SwitchRow(
            title: 'تفعيل التذكيرات',
            subtitle: 'تظهر اللافتات عند فتح التطبيق في وقت التذكير',
            value: s.enabled,
            onChanged: (v) async {
              await center.updateSettings(s.copyWith(enabled: v));
              onChanged();
            },
          ),
          _SwitchRow(
            title: 'تذكير المواظبة',
            subtitle: 'ذكّرني حين تقترب سلسلتي من الانقطاع',
            value: s.streakReminders,
            onChanged: (v) async {
              await center.updateSettings(s.copyWith(streakReminders: v));
              onChanged();
            },
          ),
          _SwitchRow(
            title: 'تذكير الفصول الجديدة',
            subtitle: 'لافتة عند صدور فصل في عمل أتابعه',
            value: s.newChapterReminders,
            onChanged: (v) async {
              await center.updateSettings(s.copyWith(newChapterReminders: v));
              onChanged();
            },
          ),
          _SwitchRow(
            title: 'تذكير الهدف اليومي',
            subtitle: 'ذكّرني بالفصول المتبقية على هدفي',
            value: s.goalReminders,
            onChanged: (v) async {
              await center.updateSettings(s.copyWith(goalReminders: v));
              onChanged();
            },
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(child: Text('وقت التذكير اليومي', style: context.ts(size: 13.5, w: FontWeight.w600))),
              _TimeChip(
                label: s.dailyTimeLabel,
                onTap: () async {
                  final picked = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay(hour: s.dailyHour, minute: s.dailyMinute),
                  );
                  if (picked != null) {
                    await center.updateSettings(s.copyWith(dailyHour: picked.hour, dailyMinute: picked.minute));
                    onChanged();
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text('أيام التذكير', style: context.ts(size: 13.5, w: FontWeight.w600)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: List.generate(7, (i) {
              final day = i + 1;
              final selected = s.daysOfWeek.contains(day);
              return ChoiceChip(
                label: Text(arabicWeekdayName(day), style: context.ts(size: 12, w: FontWeight.w600, color: selected ? p.onAccent : p.text)),
                selected: selected,
                selectedColor: p.accent,
                backgroundColor: p.surfaceHi,
                onSelected: (v) async {
                  final days = Set<int>.from(s.daysOfWeek);
                  if (v) {
                    days.add(day);
                  } else if (days.length > 1) {
                    days.remove(day);
                  }
                  await center.updateSettings(s.copyWith(daysOfWeek: days));
                  onChanged();
                },
              );
            }),
          ),
          const SizedBox(height: 8),
          Text(
            'ساعات الهدوء: ${s.quietLabel} — لا لافتات في هذه الساعات. التذكير التالي: ${_nextLabel(center)}',
            style: context.ts(size: 12, color: p.textDim),
          ),
        ],
      ),
    );
  }

  static String _nextLabel(ReminderCenter center) {
    final next = center.nextDailyTime();
    final today = DateTime.now();
    final isToday = next.year == today.year && next.month == today.month && next.day == today.day;
    final time = '${next.hour.toString().padLeft(2, '0')}:${next.minute.toString().padLeft(2, '0')}';
    return isToday ? 'اليوم $time' : '${arabicWeekdayName(next.weekday)} $time';
  }
}

class _TimeChip extends StatelessWidget {
  const _TimeChip({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: tint(p.accent, 0.12),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: tint(p.accent, 0.35)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SIcon(SardIcons.watch_later_rounded, size: 16, color: p.accent),
            const SizedBox(width: 6),
            Text(label, style: context.ts(size: 13, w: FontWeight.w700, color: p.accent)),
          ],
        ),
      ),
    );
  }
}

// ───────── بطاقة الأداء ─────────

class _PerformanceCard extends StatelessWidget {
  const _PerformanceCard({required this.settings});
  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return _SectionCard(
      icon: SardIcons.bolt_rounded,
      title: 'الأداء والبيانات',
      subtitle: 'جودة الصور والتحميل المسبق وحجم الخط',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('وضع البيانات', style: context.ts(size: 13.5, w: FontWeight.w600)),
          const SizedBox(height: 6),
          SegmentedButton<DataMode>(
            segments: const <ButtonSegment<DataMode>>[
              ButtonSegment<DataMode>(value: DataMode.hd, label: Text('جودة عالية')),
              ButtonSegment<DataMode>(value: DataMode.always, label: Text('متوازن')),
              ButtonSegment<DataMode>(value: DataMode.mobile, label: Text('توفير بيانات')),
            ],
            selected: <DataMode>{settings.dataMode},
            onSelectionChanged: (set) {
              if (set.isNotEmpty) settings.setDataMode(set.first);
            },
          ),
          const SizedBox(height: 4),
          Text(
            settings.dataMode == DataMode.mobile
                ? 'صور منخفضة الجودة ولا تحميل مسبق على بيانات الجوال'
                : settings.dataMode == DataMode.hd
                    ? 'أعلى جودة متاحة دائماً'
                    : 'جودة عالية على الواي فاي ومتوسطة على الجوال',
            style: context.ts(size: 12, color: p.textDim),
          ),
          const SizedBox(height: 12),
          Text('التحميل المسبق', style: context.ts(size: 13.5, w: FontWeight.w600)),
          const SizedBox(height: 6),
          SegmentedButton<PrefetchMode>(
            segments: const <ButtonSegment<PrefetchMode>>[
              ButtonSegment<PrefetchMode>(value: PrefetchMode.off, label: Text('إيقاف')),
              ButtonSegment<PrefetchMode>(value: PrefetchMode.wifi, label: Text('واي فاي فقط')),
              ButtonSegment<PrefetchMode>(value: PrefetchMode.always, label: Text('دائماً')),
            ],
            selected: <PrefetchMode>{settings.prefetchMode},
            onSelectionChanged: (set) {
              if (set.isNotEmpty) settings.setPrefetchMode(set.first);
            },
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: Text('حجم الخط', style: context.ts(size: 13.5, w: FontWeight.w600))),
              Text('${(settings.fontScale * 100).round()}٪', style: context.ts(size: 13, w: FontWeight.w700, color: p.accent)),
            ],
          ),
          Slider(
            value: settings.fontScale,
            min: 0.75,
            max: 1.15,
            divisions: 8,
            activeColor: p.accent,
            onChanged: (v) => settings.setFontScale(v),
          ),
          const SizedBox(height: 4),
          ImagePipelineStatusTile(
            stats: SenokImageCache.i.stats,
            onClear: () async {
              await SenokImageCache.i.clearAll();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('مُسحت ذاكرة الصور')),
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

// ───────── بطاقة «حول» ─────────

class _AboutCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _SectionCard(
      icon: SardIcons.info_outline_rounded,
      title: 'حول التطبيق',
      subtitle: 'Senok — حيث تبدأ الحكاية',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _AboutRow(label: 'الإصدار', value: '0.2.0 (2)'),
          _AboutRow(label: 'محرك التنزيل', value: 'v2 — طابور + استئناف'),
          _AboutRow(label: 'المزامنة', value: 'محلية — تُفعَّل عند توفر الخادم'),
          _AboutRow(label: 'التذكيرات', value: 'داخل التطبيق فقط'),
          _AboutRow(label: 'النسخ الاحتياطي', value: 'ملف JSON موقّع — بلا خادم'),
        ],
      ),
    );
  }
}

class _AboutRow extends StatelessWidget {
  const _AboutRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Text(label, style: context.ts(size: 12.5, color: p.textDim)),
          const Spacer(),
          Text(value, style: context.ts(size: 12.5, w: FontWeight.w600)),
        ],
      ),
    );
  }
}

// ───────── بطاقة تعارض واحد ─────────

class _ConflictTile extends StatelessWidget {
  const _ConflictTile({required this.conflict});
  final SyncConflict conflict;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surfaceHi,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(conflict.describe, style: context.ts(size: 13, w: FontWeight.w600)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await SyncEngine.i.resolveConflict(conflict.id, SyncResolution.keepLocal);
                    if (context.mounted) Navigator.of(context).pop();
                  },
                  child: const Text('نسختي'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await SyncEngine.i.resolveConflict(conflict.id, SyncResolution.keepServer);
                    if (context.mounted) Navigator.of(context).pop();
                  },
                  child: const Text('نسخة الخادم'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton(
                  onPressed: () async {
                    await SyncEngine.i.resolveConflict(conflict.id, SyncResolution.merge);
                    if (context.mounted) Navigator.of(context).pop();
                  },
                  child: const Text('دمج'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ───────── شاشة طابور التنزيلات v2 ─────────

/// شاشة طابور التنزيلات v2: تقدّم كل مهمة + إيقاف/استئناف/إلغاء/حذف.
class V2DownloadQueueScreen extends StatefulWidget {
  const V2DownloadQueueScreen({super.key});

  @override
  State<V2DownloadQueueScreen> createState() => _V2DownloadQueueScreenState();
}

class _V2DownloadQueueScreenState extends State<V2DownloadQueueScreen> {
  @override
  void initState() {
    super.initState();
    V2DownloadEngine.i.addListener(_onChanged);
    unawaited(V2DownloadEngine.i.load());
  }

  void _onChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    V2DownloadEngine.i.removeListener(_onChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final engine = V2DownloadEngine.i;
    final jobs = List<V2DownloadJob>.from(engine.jobs)
      ..sort(V2DownloadEngine.compareQueue);
    final stats = engine.stats;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('طابور التنزيلات', style: context.ts(size: 18, w: FontWeight.w700)),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: SIcon(SardIcons.arrow_back_rounded, color: p.text),
        ),
        actions: [
          if (engine.failedJobs.isNotEmpty)
            TextButton(
              onPressed: () => engine.retryAllFailed(),
              child: const Text('إعادة الكل'),
            ),
          if (engine.completedJobs.isNotEmpty)
            TextButton(
              onPressed: () => engine.clearCompleted(),
              child: const Text('مسح المكتمل'),
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: _QueueSummary(stats: stats, policy: engine.policy),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: _PolicyRow(
              policy: engine.policy,
              maxConcurrent: engine.maxConcurrent,
              onPolicyChanged: (v) => engine.setPolicy(v),
              onMaxChanged: (v) => engine.setMaxConcurrent(v),
            ),
          ),
          Expanded(
            child: jobs.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SIcon(SardIcons.download_rounded, size: 44, color: p.textDim),
                        const SizedBox(height: 10),
                        Text('لا توجد تنزيلات', style: context.ts(size: 15, w: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('نزّل فصلاً من صفحة العمل وسيظهر هنا', style: context.ts(size: 12.5, color: p.textDim)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    itemCount: jobs.length,
                    itemBuilder: (context, i) => _JobTile(job: jobs[i]),
                  ),
          ),
        ],
      ),
    );
  }
}

class _QueueSummary extends StatelessWidget {
  const _QueueSummary({required this.stats, required this.policy});
  final V2DownloadStats stats;
  final V2NetworkPolicy policy;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              _MiniStat(label: 'نشط', value: '${stats.active}'),
              _MiniStat(label: 'بانتظار', value: '${stats.queued}'),
              _MiniStat(label: 'مكتمل', value: '${stats.completed}'),
              _MiniStat(label: 'اليوم', value: formatBytesAr(stats.todayBytes)),
            ],
          ),
          const SizedBox(height: 8),
          _LabeledProgress(
            label: 'التقدّم الكلي',
            value: stats.overallProgress,
            detail: '${stats.overallPercent}٪',
          ),
          const SizedBox(height: 6),
          Text('سياسة الشبكة: ${policy.label} — ${policy.hint}', style: context.ts(size: 11.5, color: p.textDim)),
        ],
      ),
    );
  }
}

class _PolicyRow extends StatelessWidget {
  const _PolicyRow({
    required this.policy,
    required this.maxConcurrent,
    required this.onPolicyChanged,
    required this.onMaxChanged,
  });

  final V2NetworkPolicy policy;
  final int maxConcurrent;
  final ValueChanged<V2NetworkPolicy> onPolicyChanged;
  final ValueChanged<int> onMaxChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      children: [
        Expanded(
          child: DropdownButtonFormField<V2NetworkPolicy>(
            initialValue: policy,
            decoration: InputDecoration(
              labelText: 'سياسة الشبكة',
              labelStyle: context.ts(size: 12, color: p.textDim),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            ),
            items: V2NetworkPolicy.values
                .map((e) => DropdownMenuItem<V2NetworkPolicy>(value: e, child: Text(e.label, style: context.ts(size: 13))))
                .toList(),
            onChanged: (v) {
              if (v != null) onPolicyChanged(v);
            },
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: DropdownButtonFormField<int>(
            initialValue: maxConcurrent,
            decoration: InputDecoration(
              labelText: 'تنزيلات متزامنة',
              labelStyle: context.ts(size: 12, color: p.textDim),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            ),
            items: const <int>[1, 2, 3, 4, 5]
                .map((e) => DropdownMenuItem<int>(value: e, child: Text('$e', style: const TextStyle(fontSize: 13))))
                .toList(),
            onChanged: (v) {
              if (v != null) onMaxChanged(v);
            },
          ),
        ),
      ],
    );
  }
}

class _JobTile extends StatelessWidget {
  const _JobTile({required this.job});
  final V2DownloadJob job;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final engine = V2DownloadEngine.i;
    final stateColor = switch (job.state) {
      V2DownloadState.completed => const Color(0xFF0F9D75),
      V2DownloadState.failed => const Color(0xFFE5484D),
      V2DownloadState.downloading => p.accent,
      V2DownloadState.queued => p.textDim,
      V2DownloadState.paused => p.gold,
      V2DownloadState.cancelled => p.textDim,
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(job.displayTitle, style: context.ts(size: 13.5, w: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: tint(stateColor, 0.14), borderRadius: BorderRadius.circular(20)),
                child: Text(job.state.label, style: context.ts(size: 11, w: FontWeight.w700, color: stateColor)),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: job.progress,
              minHeight: 7,
              backgroundColor: p.border,
              valueColor: AlwaysStoppedAnimation<Color>(stateColor),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: Text(
                  job.isComplete
                      ? 'اكتمل · ${formatBytesAr(job.bytesDownloaded)}'
                      : '${job.completedPages}/${job.totalPages} صفحات · ${job.percent}٪ · ${job.etaLabel}',
                  style: context.ts(size: 11.5, color: p.textDim),
                ),
              ),
              Text(job.priority.label, style: context.ts(size: 11.5, w: FontWeight.w600, color: p.textDim)),
            ],
          ),
          if (job.error.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(job.error, style: context.ts(size: 11.5, color: const Color(0xFFE5484D))),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              if (job.canPause)
                _JobButton(icon: SardIcons.pause_rounded, label: 'إيقاف', onTap: () => engine.pause(job.id)),
              if (job.canResume)
                _JobButton(icon: SardIcons.play_arrow_rounded, label: 'استئناف', onTap: () => engine.resume(job.id)),
              if (job.state == V2DownloadState.failed)
                _JobButton(icon: SardIcons.refresh_rounded, label: 'إعادة', onTap: () => engine.retry(job.id)),
              const Spacer(),
              _JobButton(icon: SardIcons.delete_outline_rounded, label: 'حذف', onTap: () => engine.remove(job.id), danger: true),
            ],
          ),
        ],
      ),
    );
  }
}

class _JobButton extends StatelessWidget {
  const _JobButton({required this.icon, required this.label, required this.onTap, this.danger = false});
  final SIconData icon;
  final String label;
  final VoidCallback onTap;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = danger ? const Color(0xFFE5484D) : p.text;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          border: Border.all(color: p.border),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SIcon(icon, size: 15, color: color),
            const SizedBox(width: 4),
            Text(label, style: context.ts(size: 12, w: FontWeight.w600, color: color)),
          ],
        ),
      ),
    );
  }
}

// ───────── بطاقة التشخيص ─────────

class _DiagnosticsCard extends StatelessWidget {
  const _DiagnosticsCard({required this.onOpenQueue});

  final VoidCallback onOpenQueue;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final engine = V2DownloadEngine.i;
    final sync = SyncEngine.i;
    final cache = SenokImageCache.i;
    final stats = engine.stats;
    final health = sync.health();
    return _SectionCard(
      icon: SardIcons.tune_rounded,
      title: 'التشخيص',
      subtitle: 'حالة الأنظمة في لمحة',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _AboutRow(label: 'التنزيلات', value: stats.hasActive ? 'جارية (${stats.active + stats.queued})' : 'متوقفة'),
          _AboutRow(label: 'المزامنة', value: health.statusLabel),
          _AboutRow(label: 'ذاكرة الصور', value: 'إصابات ${cache.stats.hitRateLabel}'),
          _AboutRow(label: 'التذكيرات المعلّقة', value: '${ReminderCenter.i.pending.length}'),
          _AboutRow(label: 'آخر نسخة احتياطية', value: BackupStore.i.lastBackupAt == null ? 'لا يوجد' : 'موجودة'),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: onOpenQueue,
              icon: SIcon(SardIcons.download_rounded, size: 18, color: p.text),
              label: const Text('فتح طابور التنزيلات'),
            ),
          ),
        ],
      ),
    );
  }
}

// ───────── بطاقة استهلاك البيانات ─────────

class _DataUsageCard extends StatefulWidget {
  const _DataUsageCard();

  @override
  State<_DataUsageCard> createState() => _DataUsageCardState();
}

class _DataUsageCardState extends State<_DataUsageCard> {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final engine = V2DownloadEngine.i;
    final used = engine.todayCellularBytes;
    final fraction = engine.cellularUsageFraction;
    final over = engine.cellularLimitReached;
    return _SectionCard(
      icon: SardIcons.signal_cellular_alt_rounded,
      title: 'استهلاك بيانات الجوال',
      subtitle: 'حدّ يومي للتنزيل على بيانات الجوال',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  over ? 'بلغتَ الحدّ اليومي' : 'مستهلك اليوم: ${formatBytesAr(used)}',
                  style: context.ts(size: 13, w: FontWeight.w700, color: over ? const Color(0xFFE5484D) : p.text),
                ),
              ),
              Text('الحدّ: ${engine.cellularLimitMB} م.ب', style: context.ts(size: 12, color: p.textDim)),
            ],
          ),
          const SizedBox(height: 8),
          _LabeledProgress(
            label: 'استهلاك اليوم',
            value: fraction,
            detail: '${(fraction * 100).round()}٪',
          ),
          const SizedBox(height: 8),
          Text(
            'عند بلوغ الحدّ تتوقف التنزيلات على بيانات الجوال تلقائياً حتى الغد (الواي فاي لا يتأثر).',
            style: context.ts(size: 12, color: p.textDim),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: Text('حدّ بيانات الجوال اليومي', style: context.ts(size: 13.5, w: FontWeight.w600))),
              _LimitStepper(
                valueMB: engine.cellularLimitMB,
                onChanged: (mb) async {
                  await engine.setCellularLimitMB(mb);
                  if (mounted) setState(() {});
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LimitStepper extends StatelessWidget {
  const _LimitStepper({required this.valueMB, required this.onChanged});
  final int valueMB;
  final ValueChanged<int> onChanged;

  static const List<int> steps = <int>[50, 100, 200, 500, 1024, 2048];

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final index = steps.indexOf(valueMB);
    final current = index < 0 ? valueMB : steps[index];
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _StepButton(
          icon: SardIcons.chevron_right_rounded,
          enabled: index > 0,
          onTap: () => onChanged(steps[index - 1]),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(color: p.surfaceHi, borderRadius: BorderRadius.circular(8)),
          child: Text('$current م.ب', style: context.ts(size: 13, w: FontWeight.w700)),
        ),
        _StepButton(
          icon: SardIcons.chevron_left_rounded,
          enabled: index >= 0 && index < steps.length - 1,
          onTap: () => onChanged(steps[index + 1]),
        ),
      ],
    );
  }
}

class _StepButton extends StatelessWidget {
  const _StepButton({required this.icon, required this.enabled, required this.onTap});
  final SIconData icon;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return IconButton(
      onPressed: enabled ? onTap : null,
      icon: SIcon(icon, size: 20, color: enabled ? p.text : p.textDim),
      visualDensity: VisualDensity.compact,
    );
  }
}

// ───────── بطاقة منطقة الخطر ─────────

class _DangerZoneCard extends StatelessWidget {
  const _DangerZoneCard({required this.onChanged});
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: tint(const Color(0xFFE5484D), 0.45), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.priority_high_rounded, size: 20, color: const Color(0xFFE5484D)),
              const SizedBox(width: 8),
              Text('منطقة الخطر', style: context.ts(size: 15, w: FontWeight.w700, color: const Color(0xFFE5484D))),
            ],
          ),
          const SizedBox(height: 4),
          Text('إجراءات لا يمكن التراجع عنها — تأكيد مطلوب قبل التنفيذ.', style: context.ts(size: 12, color: p.textDim)),
          const SizedBox(height: 10),
          _ActionRow(
            icon: SardIcons.delete_outline_rounded,
            title: 'حذف كل التنزيلات',
            subtitle: 'يمسح كل الفصول المنزَّلة وملفاتها',
            onTap: () => _confirm(context, 'حذف كل التنزيلات؟', 'سيُحذف كل فصل منزَّل من جهازك.', () async {
              final engine = V2DownloadEngine.i;
              for (final j in List<V2DownloadJob>.from(engine.jobs)) {
                await engine.remove(j.id);
              }
              onChanged();
            }),
          ),
          _ActionRow(
            icon: SardIcons.notifications_none_rounded,
            title: 'مسح كل التذكيرات',
            subtitle: 'يحذف التذكيرات المجدولة والمعلّقة',
            onTap: () => _confirm(context, 'مسح كل التذكيرات؟', 'ستُحذف كل التذكيرات المجدولة.', () async {
              await ReminderCenter.i.resetForTest();
              await ReminderCenter.i.load();
              onChanged();
            }),
          ),
          _ActionRow(
            icon: SardIcons.sync_rounded,
            title: 'إعادة تعيين المزامنة',
            subtitle: 'يمسح السجلات والتعارضات وسجل المزامنة',
            onTap: () => _confirm(context, 'إعادة تعيين المزامنة؟', 'ستُمسح كل سجلات المزامنة والتعارضات.', () async {
              await SyncEngine.i.resetForTest();
              await SyncEngine.i.load();
              onChanged();
            }),
          ),
        ],
      ),
    );
  }

  Future<void> _confirm(BuildContext context, String title, String body, Future<void> Function() onYes) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title, style: context.ts(size: 16, w: FontWeight.w700)),
        content: Text(body, style: context.ts(size: 13)),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE5484D)),
            child: const Text('تأكيد الحذف'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await onYes();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم التنفيذ')));
      }
    }
  }
}
