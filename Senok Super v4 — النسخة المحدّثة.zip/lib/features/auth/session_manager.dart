/// ──────────────────────────────────────────────────────────────────────────
/// مدير الجلسات
///
///  • جلسة واحدة لكل جهاز: معرّف، اسم الجهاز، آخر نشاط، تاريخ الانتهاء
///  • يُخزَّن رمز الجلسة في التخزين الآمن (flutter_secure_storage)
///    وقائمة الجلسات في SharedPreferences
///  • تجديد تلقائي قبل الانتهاء، وتنبيه قبل انتهاء الجلسة الحالية
///  • إلغاء جلسة واحدة أو كل الجلسات الأخرى
///  • سقوط محلي أنيق: حين لا توجد نقاط نهاية /auth/sessions على الخادم،
///    تُدار الجلسة محلياً وتُعلن الواجهة ذلك
/// ──────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:math' show Random;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/account_repository.dart';
import '../../core/data/api_client.dart';
import '../../core/storage/auth_store.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'auth_v2.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  نموذج الجلسة
// ═══════════════════════════════════════════════════════════════════════════

/// نوع الجهاز (يُستنتج من المنصة — بلا أي بصمة جهاز حقيقية).
enum DeviceKind { android, ios, web, windows, macos, linux, unknown }

extension DeviceKindX on DeviceKind {
  String get label => switch (this) {
    DeviceKind.android => 'أندرويد',
    DeviceKind.ios => 'آيفون / آيباد',
    DeviceKind.web => 'متصفح ويب',
    DeviceKind.windows => 'ويندوز',
    DeviceKind.macos => 'ماك',
    DeviceKind.linux => 'لينكس',
    DeviceKind.unknown => 'جهاز غير معروف',
  };

  SIconData get icon => switch (this) {
    DeviceKind.android => SardIcons.settings_rounded,
    DeviceKind.ios => SardIcons.settings_rounded,
    DeviceKind.web => SardIcons.explore_rounded,
    DeviceKind.windows => SardIcons.layers_rounded,
    DeviceKind.macos => SardIcons.layers_rounded,
    DeviceKind.linux => SardIcons.layers_rounded,
    DeviceKind.unknown => SardIcons.question_mark_rounded,
  };
}

/// يستنتج نوع الجهاز من المنصة الحالية.
DeviceKind currentDeviceKind() {
  if (kIsWeb) return DeviceKind.web;
  if (Platform.isAndroid) return DeviceKind.android;
  if (Platform.isIOS) return DeviceKind.ios;
  if (Platform.isWindows) return DeviceKind.windows;
  if (Platform.isMacOS) return DeviceKind.macos;
  if (Platform.isLinux) return DeviceKind.linux;
  return DeviceKind.unknown;
}

/// جلسة دخول واحدة (جهاز واحد).
class SessionInfo {
  const SessionInfo({
    required this.id,
    required this.deviceLabel,
    required this.deviceKind,
    required this.createdAt,
    required this.lastActiveAt,
    required this.expiresAt,
    this.isCurrent = false,
    this.isLocalOnly = false,
    this.ipHint = '',
  });

  final String id;

  /// اسم الجهاز كما يعرضه المستخدم (مثال: «هذا الهاتف»).
  final String deviceLabel;
  final DeviceKind deviceKind;
  final DateTime createdAt;
  final DateTime lastActiveAt;
  final DateTime expiresAt;

  /// هل هذه الجلسة هي جلسة هذا الجهاز؟
  final bool isCurrent;

  /// true حين تُدار الجلسة محلياً فقط (بلا خادم).
  final bool isLocalOnly;

  /// تلميح عن الشبكة (يُملأ من الخادم فقط؛ فارغ محلياً).
  final String ipHint;

  bool get isExpired => DateTime.now().isAfter(expiresAt);

  /// هل تنتهي خلال المدة المعطاة؟
  bool expiresWithin(Duration d) =>
      !isExpired && expiresAt.difference(DateTime.now()) <= d;

  Duration get timeToExpiry => expiresAt.difference(DateTime.now());

  String get expiryLabel {
    if (isExpired) return 'منتهية';
    final d = timeToExpiry;
    if (d.inDays >= 1) return 'تنتهي بعد ${d.inDays} ${d.inDays == 1 ? 'يوم' : 'أيام'}';
    if (d.inHours >= 1) return 'تنتهي بعد ${d.inHours} ساعة';
    if (d.inMinutes >= 1) return 'تنتهي بعد ${d.inMinutes} دقيقة';
    return 'تنتهي خلال أقل من دقيقة';
  }

  String get lastActiveLabel {
    final diff = DateTime.now().difference(lastActiveAt);
    if (diff.inMinutes < 1) return 'نشط الآن';
    if (diff.inMinutes < 60) return 'نشط منذ ${diff.inMinutes} دقيقة';
    if (diff.inHours < 24) return 'نشط منذ ${diff.inHours} ساعة';
    if (diff.inDays < 7) return 'نشط منذ ${diff.inDays} ${diff.inDays == 1 ? 'يوم' : 'أيام'}';
    return 'نشط منذ ${lastActiveAt.year}/${lastActiveAt.month}/${lastActiveAt.day}';
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'device_label': deviceLabel,
    'device_kind': deviceKind.name,
    'created_at': createdAt.toIso8601String(),
    'last_active_at': lastActiveAt.toIso8601String(),
    'expires_at': expiresAt.toIso8601String(),
    'is_current': isCurrent,
    'is_local_only': isLocalOnly,
    'ip_hint': ipHint,
  };

  factory SessionInfo.fromJson(Map<String, dynamic> j) => SessionInfo(
    id: '${j['id']}',
    deviceLabel: '${j['device_label'] ?? j['device'] ?? 'جهاز'}',
    deviceKind: DeviceKind.values.firstWhere(
      (k) => k.name == '${j['device_kind']}',
      orElse: () => DeviceKind.unknown,
    ),
    createdAt: DateTime.tryParse('${j['created_at']}') ?? DateTime.now(),
    lastActiveAt: DateTime.tryParse('${j['last_active_at']}') ?? DateTime.now(),
    expiresAt: DateTime.tryParse('${j['expires_at']}') ??
        DateTime.now().add(const Duration(days: 30)),
    isCurrent: j['is_current'] == true,
    isLocalOnly: j['is_local_only'] == true,
    ipHint: '${j['ip_hint'] ?? ''}',
  );

  SessionInfo copyWith({
    DateTime? lastActiveAt,
    DateTime? expiresAt,
    bool? isCurrent,
    String? deviceLabel,
  }) =>
      SessionInfo(
        id: id,
        deviceLabel: deviceLabel ?? this.deviceLabel,
        deviceKind: deviceKind,
        createdAt: createdAt,
        lastActiveAt: lastActiveAt ?? this.lastActiveAt,
        expiresAt: expiresAt ?? this.expiresAt,
        isCurrent: isCurrent ?? this.isCurrent,
        isLocalOnly: isLocalOnly,
        ipHint: ipHint,
      );
}

/// يولّد معرّف جلسة عشوائياً.
String generateSessionId([Random? random]) {
  final r = random ?? Random.secure();
  final bytes = List<int>.generate(12, (_) => r.nextInt(256));
  return 'sess_${bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join()}';
}

// ═══════════════════════════════════════════════════════════════════════════
//  مدير الجلسات
// ═══════════════════════════════════════════════════════════════════════════

/// مفاتيح التخزين.
class SessionKeys {
  static const String sessions = 'sard_sessions_v2';
  static const String currentId = 'sard_current_session_v2';
  static const String secureToken = 'sard_session_token_v2';
}

/// مدير الجلسات: مفردة (.i) مع load().
///
///  • عند الدخول تُنشأ جلسة حالية مدتها 30 يوماً (قابلة للتجديد)
///  • يجدد الجلسة تلقائياً حين يبقى عليها أقل من 3 أيام
///  • يحاول جلب جلسات الخادم؛ وإن لم توجد نقطة النهاية، يدير الجلسات
///    محلياً ويُعلن ذلك عبر [serverAvailable] = false
class SessionManager extends ChangeNotifier {
  SessionManager._(this._prefs, [this._repo]);
  final SharedPreferences _prefs;
  final AccountRepository? _repo;

  static const _secure = FlutterSecureStorage();

  static SessionManager? _instance;

  static SessionManager get i {
    final inst = _instance;
    if (inst == null) throw StateError('SessionManager.load() must be called first');
    return inst;
  }

  static Future<SessionManager> load([AccountRepository? repo]) async {
    _instance ??= SessionManager._(await SharedPreferences.getInstance(), repo);
    return _instance!;
  }

  static SessionManager fromPrefs(SharedPreferences prefs, [AccountRepository? repo]) {
    _instance = SessionManager._(prefs, repo);
    return _instance!;
  }

  /// مدة الجلسة الافتراضية.
  static const Duration sessionLifetime = Duration(days: 30);

  /// يُجدد تلقائياً حين يبقى أقل من هذه المدة.
  static const Duration autoRefreshThreshold = Duration(days: 3);

  List<SessionInfo> _sessions = [];
  bool _serverAvailable = true;
  bool _busy = false;
  Timer? _timer;

  List<SessionInfo> get sessions => List<SessionInfo>.unmodifiable(_sessions);
  bool get serverAvailable => _serverAvailable;
  bool get busy => _busy;

  SessionInfo? get currentSession {
    final list = _sessions.where((s) => s.isCurrent).toList();
    return list.isEmpty ? null : list.first;
  }

  String? get currentSessionId => _prefs.getString(SessionKeys.currentId);

  bool get hasActiveSession => currentSession != null && !currentSession!.isExpired;

  /// المدة المتبقية للجلسة الحالية (null إن لم توجد جلسة).
  Duration? get timeToExpiry => currentSession?.timeToExpiry;

  /// هل الجلسة الحالية تنتهي قريباً (خلال 3 أيام)؟
  bool get expiringSoon =>
      currentSession != null && currentSession!.expiresWithin(autoRefreshThreshold);

  /// يهيّئ المدير: يقرأ الجلسات المحلية، وينشئ جلسة حالية إن لم توجد،
  /// ويبدأ مؤقت التجديد الدوري.
  Future<void> init() async {
    _readLocal();
    if (currentSession == null) {
      await _createLocalSession();
    } else {
      await _maybeRefresh();
    }
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(hours: 1), (_) => _maybeRefresh());
    notifyListeners();
    await refreshFromServer();
  }

  void _readLocal() {
    final raw = _prefs.getString(SessionKeys.sessions);
    if (raw == null || raw.isEmpty) {
      _sessions = [];
      return;
    }
    try {
      final list = jsonDecode(raw) as List;
      _sessions = list
          .whereType<Map>()
          .map((e) => SessionInfo.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      _sessions = [];
    }
  }

  Future<void> _saveLocal() async {
    await _prefs.setString(
      SessionKeys.sessions,
      jsonEncode(_sessions.map((s) => s.toJson()).toList()),
    );
  }

  Future<SessionInfo> _createLocalSession() async {
    final now = DateTime.now();
    final session = SessionInfo(
      id: generateSessionId(),
      deviceLabel: 'هذا الجهاز (${currentDeviceKind().label})',
      deviceKind: currentDeviceKind(),
      createdAt: now,
      lastActiveAt: now,
      expiresAt: now.add(sessionLifetime),
      isCurrent: true,
      isLocalOnly: !_serverAvailable,
    );
    _sessions = [
      ..._sessions.map((s) => s.copyWith(isCurrent: false)),
      session,
    ];
    await _prefs.setString(SessionKeys.currentId, session.id);
    await _saveLocal();
    return session;
  }

  /// يُنادى عند كل فتح للتطبيق: يحدّث آخر نشاط ويجدد إن اقترب الانتهاء.
  Future<void> touch() async {
    final cur = currentSession;
    if (cur == null) {
      await _createLocalSession();
      notifyListeners();
      return;
    }
    final updated = cur.copyWith(lastActiveAt: DateTime.now());
    _sessions = _sessions.map((s) => s.id == cur.id ? updated : s).toList();
    await _saveLocal();
    await _maybeRefresh();
    notifyListeners();
  }

  /// يجدد الجلسة الحالية إن بقي عليها أقل من 3 أيام.
  Future<bool> _maybeRefresh() async {
    final cur = currentSession;
    if (cur == null || cur.isExpired) return false;
    if (!cur.expiresWithin(autoRefreshThreshold)) return false;
    return refreshSession();
  }

  /// يجدد الجلسة الحالية 30 يوماً جديدة (محلياً + طلب خادم إن توفّر).
  Future<bool> refreshSession() async {
    final cur = currentSession;
    if (cur == null) return false;
    _busy = true;
    notifyListeners();
    try {
      var serverOk = false;
      final repo = _repo;
      if (repo != null) {
        try {
          await repo.api.post('/auth/refresh', body: {'session_id': cur.id});
          serverOk = true;
        } on ApiException catch (e) {
          if (e.failure == ApiFailure.notFound || e.failure == ApiFailure.server) {
            _serverAvailable = false;
          } else {
            rethrow;
          }
        }
      }
      final updated = cur.copyWith(
        expiresAt: DateTime.now().add(sessionLifetime),
        lastActiveAt: DateTime.now(),
      );
      _sessions = _sessions.map((s) => s.id == cur.id ? updated : s).toList();
      await _saveLocal();
      if (serverOk) _serverAvailable = true;
      return true;
    } catch (_) {
      return false;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  /// يجلب جلسات الخادم (إن توفّرت نقطة النهاية) ويدمجها مع المحلية.
  Future<bool> refreshFromServer() async {
    final repo = _repo;
    if (repo == null) {
      _serverAvailable = false;
      return false;
    }
    try {
      final j = await repo.api.get('/auth/sessions');
      final list = j is Map ? j['sessions'] : null;
      if (list is! List) return false;
      final server = list
          .whereType<Map>()
          .map((e) => SessionInfo.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      // نحتفظ بالجلسة المحلية الحالية ونضيف جلسات الخادم الأخرى.
      final local = _sessions.where((s) => s.isCurrent).toList();
      final merged = <SessionInfo>[...local];
      for (final s in server) {
        if (!merged.any((m) => m.id == s.id)) merged.add(s);
      }
      _sessions = merged;
      _serverAvailable = true;
      await _saveLocal();
      notifyListeners();
      return true;
    } on ApiException catch (e) {
      if (e.failure == ApiFailure.notFound || e.failure == ApiFailure.server) {
        _serverAvailable = false;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  /// يلغي جلسة واحدة (لا يمكن إلغاء الجلسة الحالية من هنا).
  Future<bool> revokeSession(String id) async {
    if (id == currentSessionId) return false;
    final repo = _repo;
    if (repo != null && _serverAvailable) {
      try {
        await repo.api.post('/auth/sessions/$id/revoke', body: {});
      } on ApiException {
        // فشل الخادم لا يمنع الإلغاء المحلي.
      } catch (_) {}
    }
    _sessions = _sessions.where((s) => s.id != id).toList();
    await _saveLocal();
    notifyListeners();
    return true;
  }

  /// يلغي كل الجلسات ما عدا الحالية.
  Future<int> revokeAllExceptCurrent() async {
    final others = _sessions.where((s) => !s.isCurrent).toList();
    final repo = _repo;
    if (repo != null && _serverAvailable) {
      for (final s in others) {
        try {
          await repo.api.post('/auth/sessions/${s.id}/revoke', body: {});
        } on ApiException {
          // نكمل مع الباقي.
        } catch (_) {}
      }
    }
    final count = others.length;
    _sessions = _sessions.where((s) => s.isCurrent).toList();
    await _saveLocal();
    notifyListeners();
    return count;
  }

  /// يعيد تسمية جلسة (مثلاً: «هاتف العمل») ليسهل تمييز الأجهزة.
  Future<bool> renameSession(String id, String label) async {
    if (!_sessions.any((s) => s.id == id)) return false;
    _sessions = _sessions
        .map((s) => s.id == id ? s.copyWith(deviceLabel: label) : s)
        .toList();
    await _saveLocal();
    notifyListeners();
    return true;
  }

  /// ينهي الجلسة الحالية نهائياً (يُستعمل عند تسجيل الخروج).
  Future<void> endCurrentSession() async {
    final id = currentSessionId;
    _sessions = _sessions.where((s) => s.id != id).toList();
    await _prefs.remove(SessionKeys.currentId);
    await _saveLocal();
    await _secure.delete(key: SessionKeys.secureToken);
    await AuthStore.clear();
    notifyListeners();
  }

  /// يحفظ رمز الجلسة في التخزين الآمن.
  Future<void> saveSessionToken(String token) =>
      _secure.write(key: SessionKeys.secureToken, value: token);

  Future<String?> readSessionToken() => _secure.read(key: SessionKeys.secureToken);

  /// يقرأ المدير من السياق (للواجهات التي تحتاجه دون تمرير مباشر).
  static SessionManager readFromContext(BuildContext context) =>
      context.read<SessionManager>();

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  واجهات الجلسات
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة إدارة الجلسات: الجلسة الحالية + الجلسات الأخرى + إلغاء الكل.
class SessionsScreen extends StatelessWidget {
  const SessionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final manager = context.watch<SessionManager>();
    final current = manager.currentSession;
    final others = manager.sessions.where((s) => !s.isCurrent).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('الجلسات النشطة')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          if (!manager.serverAvailable)
            const AuthNoticeBanner(
              icon: SardIcons.info_outline_rounded,
              text: 'الخادم لا يوفّر إدارة الجلسات بعد — الجلسات المعروضة محلية على هذا الجهاز فقط.',
            ),
          if (!manager.serverAvailable) const SizedBox(height: 16),
          if (current != null) ...[
            Text('الجلسة الحالية', style: context.ds(size: 17)),
            const SizedBox(height: 8),
            SessionTile(session: current, manager: manager, isCurrent: true),
            const SizedBox(height: 8),
            AuthNoticeBanner(
              icon: SardIcons.info_outline_rounded,
              text: current.expiryLabel,
              color: manager.expiringSoon ? p.gold : const Color(0xFF3FA66A),
            ),
          ],
          if (others.isNotEmpty) ...[
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(child: Text('جلسات أخرى (${others.length})', style: context.ds(size: 17))),
                TextButton(
                  onPressed: manager.busy
                      ? null
                      : () async {
                          final count = await manager.revokeAllExceptCurrent();
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('أُلغيت $count ${count == 1 ? 'جلسة' : 'جلسات'}.')),
                            );
                          }
                        },
                  child: const Text('إلغاء الكل'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            for (final s in others) ...[
              SessionTile(session: s, manager: manager),
              const SizedBox(height: 8),
            ],
          ] else ...[
            const SizedBox(height: 20),
            Text(
              'لا توجد جلسات أخرى. حين تسجّل دخولك من جهاز آخر ستظهر هنا '
              'لتتمكن من إلغائها عن بُعد.',
              style: context.ts(color: p.textDim, size: 13.5, height: 1.6),
            ),
          ],
          const SizedBox(height: 20),
          OutlinedButton.icon(
            onPressed: manager.busy
                ? null
                : () async {
                    final ok = await manager.refreshSession();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            ok ? 'تم تجديد الجلسة الحالية 30 يوماً.' : 'تعذّر التجديد. حاول لاحقاً.',
                          ),
                        ),
                      );
                    }
                  },
            icon: const SIcon(SardIcons.refresh_rounded, size: 18),
            label: const Text('تجديد الجلسة الحالية'),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              side: BorderSide(color: p.border),
            ),
          ),
        ],
      ),
    );
  }
}

/// بطاقة جلسة واحدة.
class SessionTile extends StatelessWidget {
  const SessionTile({super.key, required this.session, required this.manager, this.isCurrent = false});
  final SessionInfo session;
  final SessionManager manager;
  final bool isCurrent;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(
          color: isCurrent ? tint(p.accent, 0.5) : p.border,
          width: p.borderW,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(13),
            ),
            child: SIcon(session.deviceKind.icon, size: 22, color: p.accent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        session.deviceLabel,
                        style: context.ts(w: FontWeight.w700),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (isCurrent)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: tint(p.accent, 0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'الحالية',
                          style: context.ts(size: 11, w: FontWeight.w700, color: p.accent),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  '${session.deviceKind.label} · ${session.lastActiveLabel}',
                  style: context.ts(color: p.textDim, size: 12.5),
                ),
                const SizedBox(height: 2),
                Text(
                  session.isExpired ? 'منتهية' : session.expiryLabel,
                  style: context.ts(
                    color: session.isExpired ? const Color(0xFFE5484D) : p.textDim,
                    size: 12.5,
                  ),
                ),
              ],
            ),
          ),
          if (!isCurrent)
            TextButton(
              onPressed: () async {
                final ok = await manager.revokeSession(session.id);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(ok ? 'أُلغيت الجلسة.' : 'تعذّر إلغاء الجلسة.'),
                    ),
                  );
                }
              },
              child: const Text('إلغاء', style: TextStyle(color: Color(0xFFE5484D))),
            ),
        ],
      ),
    );
  }
}

/// لافتة تنبيه قرب انتهاء الجلسة (تُوضع أعلى الشاشة الرئيسية).
/// تقرأ المدير من السياق عبر context.read كما يقتضي النمط المعتمد.
class SessionExpiryBanner extends StatelessWidget {
  const SessionExpiryBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final manager = context.watch<SessionManager>();
    final current = manager.currentSession;
    if (current == null || !manager.expiringSoon) return const SizedBox.shrink();
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: tint(p.gold, 0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tint(p.gold, 0.4)),
      ),
      child: Row(
        children: [
          const SIcon(SardIcons.info_outline_rounded, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'جلستك ${current.expiryLabel}. جدّدها الآن لتبقى مسجَّلاً.',
              style: context.ts(size: 13, height: 1.4),
            ),
          ),
          TextButton(
            onPressed: () async {
              // التجديد عبر المدير المقروء من السياق.
              final m = SessionManager.readFromContext(context);
              final ok = await m.refreshSession();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(ok ? 'تم تجديد الجلسة.' : 'تعذّر التجديد.'),
                  ),
                );
              }
            },
            child: const Text('تجديد'),
          ),
        ],
      ),
    );
  }
}

/// ملخص الجلسة الحالية (لشاشة الإعدادات).
class SessionSummaryTile extends StatelessWidget {
  const SessionSummaryTile({super.key, this.onTap});
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final manager = context.watch<SessionManager>();
    final current = manager.currentSession;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(p.r(0.9)),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: tint(p.accent, 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const SIcon(SardIcons.shield_rounded, size: 20, color: Color(0xFF3FA66A)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الجلسات النشطة', style: context.ts(w: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(
                    current == null
                        ? 'لا توجد جلسة نشطة'
                        : '${manager.sessions.length} ${manager.sessions.length == 1 ? 'جلسة' : 'جلسات'} · ${current.expiryLabel}',
                    style: context.ts(color: p.textDim, size: 12.5),
                  ),
                ],
              ),
            ),
            const SIcon(SardIcons.chevron_left_rounded, size: 20),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  إعادة تسمية الجلسة
// ═══════════════════════════════════════════════════════════════════════════

/// ورقة إعادة تسمية جلسة (مثلاً: «هاتف العمل» بدل «هذا الجهاز»).
class RenameSessionSheet extends StatefulWidget {
  const RenameSessionSheet({super.key, required this.session, required this.manager});
  final SessionInfo session;
  final SessionManager manager;

  @override
  State<RenameSessionSheet> createState() => _RenameSessionSheetState();
}

class _RenameSessionSheetState extends State<RenameSessionSheet> {
  late final TextEditingController _name =
      TextEditingController(text: widget.session.deviceLabel);

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(2)),
            ),
          ),
          const SizedBox(height: 16),
          Text('تسمية الجلسة', style: context.ds(size: 18)),
          const SizedBox(height: 6),
          Text(
            'اسم واضح يساعدك على تمييز أجهزتك (مثال: هاتف العمل، جهاز المنزل).',
            style: context.ts(color: p.textDim, size: 13, height: 1.5),
          ),
          const SizedBox(height: 14),
          AuthTextField(
            controller: _name,
            label: 'اسم الجهاز',
            hint: 'مثال: هاتف العمل',
            icon: SardIcons.edit_rounded,
            textInputAction: TextInputAction.done,
          ),
          const SizedBox(height: 14),
          AuthPrimaryButton(
            label: 'حفظ الاسم',
            onPressed: () async {
              final label = _name.text.trim();
              if (label.isEmpty || label.length > 40) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('اكتب اسماً بين حرف و40 حرفاً.')),
                );
                return;
              }
              await widget.manager.renameSession(widget.session.id, label);
              if (context.mounted) Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }
}
