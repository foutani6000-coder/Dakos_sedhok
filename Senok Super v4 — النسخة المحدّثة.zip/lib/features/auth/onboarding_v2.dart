/// ──────────────────────────────────────────────────────────────────────────
/// الترحيب v2 — صفحات تعريفية عند أول فتح
///
///  • 5 صفحات: مكتبة ضخمة، قارئ مريح، متابعة بلا إنترنت، مجتمع، خصوصية
///  • كل صفحة: أيقونة + عنوان + وصف + مثال مصغّر مرسوم (بلا صور خارجية)
///  • تخطٍّ في أي وقت، وزر «ابدأ القراءة» في النهاية
///  • يُحفظ الإكمال في SharedPreferences (sard_onboarding_v2_done)
///  • اختيار الثيم المفضل في الصفحة الأخيرة (اختياري)
/// ──────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'auth_v2.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  نموذج الصفحة
// ═══════════════════════════════════════════════════════════════════════════

/// صفحة ترحيب واحدة.
class OnboardingPageData {
  const OnboardingPageData({
    required this.id,
    required this.icon,
    required this.color,
    required this.title,
    required this.body,
    required this.example,
    this.exampleLabel,
  });

  final String id;
  final SIconData icon;
  final Color color;
  final String title;
  final String body;

  /// مثال مصغّر يُعرض أسفل النص (نص قصير يوضّح الفكرة).
  final String example;
  final String? exampleLabel;
}

/// صفحات الترحيب الخمس (ثابتة).
const List<OnboardingPageData> kOnboardingV2Pages = [
  OnboardingPageData(
    id: 'library',
    icon: SardIcons.auto_stories_rounded,
    color: Color(0xFFE63E2A),
    title: 'مكتبة ضخمة بين يديك',
    body: 'آلاف المانهوا والمانغا الكورية والصينية واليابانية، منظمة بأنواعها '
        'وحالاتها وتقييماتها. ابحث، صفِّ، وتابع ما يعجبك بضغطة واحدة.',
    example: '«البداية بعد النهاية» — مانهوا كورية · مستمر · 9.4',
    exampleLabel: 'مثال على عمل في المكتبة',
  ),
  OnboardingPageData(
    id: 'reader',
    icon: SardIcons.chrome_reader_mode_rounded,
    color: Color(0xFF22C7D6),
    title: 'قارئ مريح لعينيك',
    body: 'وضع عمودي للويبتون، وصفحات لليمين أو اليسار للمانغا. تحكّم في '
        'الحجم والسطوع والخلفية، وسيتذكّر التطبيق موضعك في كل فصل.',
    example: 'وضع ليلي · خلفية ورقية · تكبير بإصبعين',
    exampleLabel: 'خيارات القارئ',
  ),
  OnboardingPageData(
    id: 'offline',
    icon: SardIcons.download_rounded,
    color: Color(0xFF3FA66A),
    title: 'اقرأ بلا إنترنت',
    body: 'نزّل الفصول على جهازك واقرأها في الطائرة أو المترو. التطبيق '
        'يحفظ تقدّمك محلياً ويزامنه حين يعود الاتصال.',
    example: '12 فصلاً منزّلاً · جاهزة للقراءة دون اتصال',
    exampleLabel: 'التنزيلات',
  ),
  OnboardingPageData(
    id: 'community',
    icon: SardIcons.groups_rounded,
    color: Color(0xFF5B5BEA),
    title: 'مجتمع يقرأ معك',
    body: 'علّق على الفصول، وقيّم الأعمال، وشارك ترشيحاتك مع القرّاء. '
        'تابع أصدقاءك وشاهد ما يقرؤونه الآن.',
    example: '«الفصل 42 كان مفاجأة!» — 128 إعجاباً',
    exampleLabel: 'تعليق من المجتمع',
  ),
  OnboardingPageData(
    id: 'privacy',
    icon: SardIcons.shield_rounded,
    color: Color(0xFFE9B44C),
    title: 'خصوصيتك أولاً',
    body: 'بياناتك على جهازك أولاً: قفل PIN، وتصدير كامل لبياناتك في أي وقت، '
        'وحذف الحساب نهائياً متى شئت. لا نبيع بياناتك ولا نشاركها.',
    example: 'قفل PIN · تصدير JSON · حذف نهائي',
    exampleLabel: 'أدوات الخصوصية',
  ),
];

// ═══════════════════════════════════════════════════════════════════════════
//  مخزن إكمال الترحيب
// ═══════════════════════════════════════════════════════════════════════════

/// مخزن حالة الترحيب v2.
class OnboardingV2Store {
  OnboardingV2Store._(this._prefs);
  final SharedPreferences _prefs;

  static const String _doneKey = 'sard_onboarding_v2_done';
  static const String _seenPageKey = 'sard_onboarding_v2_last_page';
  static const String _themeKey = 'sard_onboarding_v2_theme';

  static Future<OnboardingV2Store> load() async =>
      OnboardingV2Store._(await SharedPreferences.getInstance());

  bool get done => _prefs.getBool(_doneKey) ?? false;

  /// آخر صفحة وصل إليها المستخدم (للاستئناف).
  int get lastPage => _prefs.getInt(_seenPageKey) ?? 0;

  /// الثيم الذي اختاره في الترحيب (إن وُجد).
  String? get chosenThemeId => _prefs.getString(_themeKey);

  Future<void> markPageSeen(int index) => _prefs.setInt(_seenPageKey, index);

  Future<void> markDone({String? themeId}) async {
    await _prefs.setBool(_doneKey, true);
    if (themeId != null) await _prefs.setString(_themeKey, themeId);
  }

  Future<void> reset() async {
    await _prefs.setBool(_doneKey, false);
    await _prefs.setInt(_seenPageKey, 0);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة الترحيب
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة الترحيب v2: صفحات أفقية مع مؤشر ونقاط، وزر تخطٍّ، واختيار ثيم
/// في الصفحة الأخيرة.
class OnboardingV2Screen extends StatefulWidget {
  const OnboardingV2Screen({
    super.key,
    this.store,
    this.onFinished,
    this.onSkip,
  });

  final OnboardingV2Store? store;
  final VoidCallback? onFinished;
  final VoidCallback? onSkip;

  @override
  State<OnboardingV2Screen> createState() => _OnboardingV2ScreenState();
}

class _OnboardingV2ScreenState extends State<OnboardingV2Screen> {
  final _controller = PageController();
  int _index = 0;
  String? _themeId;

  @override
  void initState() {
    super.initState();
    _index = widget.store?.lastPage.clamp(0, kOnboardingV2Pages.length - 1) ?? 0;
    if (_index > 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _controller.jumpToPage(_index);
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  bool get _isLast => _index == kOnboardingV2Pages.length - 1;

  Future<void> _finish() async {
    await widget.store?.markDone(themeId: _themeId);
    widget.onFinished?.call();
  }

  Future<void> _skip() async {
    await widget.store?.markDone(themeId: _themeId);
    widget.onSkip?.call();
    widget.onFinished?.call();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(
                children: [
                  const Spacer(),
                  TextButton(
                    onPressed: _skip,
                    child: const Text('تخطٍّ'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: kOnboardingV2Pages.length,
                onPageChanged: (i) {
                  setState(() => _index = i);
                  widget.store?.markPageSeen(i);
                },
                itemBuilder: (BuildContext context, int i) =>
                    _OnboardingPageView(page: kOnboardingV2Pages[i]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var i = 0; i < kOnboardingV2Pages.length; i++)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      width: i == _index ? 26 : 8,
                      height: 8,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        color: i == _index ? p.accent : p.border,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                ],
              ),
            ),
            if (_isLast) _themePicker(context, p),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
              child: Row(
                children: [
                  if (!_isLast)
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _controller.nextPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeOut,
                        ),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size.fromHeight(52),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                          side: BorderSide(color: p.border),
                        ),
                        child: const Text('التالي'),
                      ),
                    )
                  else
                    Expanded(
                      child: AuthPrimaryButton(
                        label: 'ابدأ القراءة',
                        icon: SardIcons.auto_stories_rounded,
                        onPressed: _finish,
                      ),
                    ),
                  const SizedBox(width: 12),
                  if (!_isLast)
                    TextButton(
                      onPressed: _skip,
                      child: const Text('تخطٍّ'),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _themePicker(BuildContext context, SardPalette p) {
    // ثيمات سريعة: ورق / حبر / ليل — اختيار اختياري قبل البدء.
    final options = [
      ('paper', 'ورق', const Color(0xFFF5F0E6), const Color(0xFF1C1612)),
      ('graphite', 'حبر', const Color(0xFF14110F), const Color(0xFFF4EEE4)),
      ('obsidian', 'ليل', const Color(0xFF080706), const Color(0xFFF8F3EA)),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 4, 24, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('اختر شكل التطبيق (اختياري)', style: context.ts(w: FontWeight.w700)),
          const SizedBox(height: 8),
          Row(
            children: [
              for (final (id, label, bg, fg) in options)
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _themeId = id),
                    child: Container(
                      height: 52,
                      margin: const EdgeInsetsDirectional.only(end: 8),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: bg,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: _themeId == id ? p.accent : p.border,
                          width: _themeId == id ? 2 : 1,
                        ),
                      ),
                      child: Text(label, style: context.ts(w: FontWeight.w700, color: fg)),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// محتوى صفحة ترحيب واحدة.
class _OnboardingPageView extends StatelessWidget {
  const _OnboardingPageView({required this.page});
  final OnboardingPageData page;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 16, 28, 16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 110,
            height: 110,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(page.color, 0.12),
              borderRadius: BorderRadius.circular(34),
              border: Border.all(color: tint(page.color, 0.3)),
            ),
            child: SIcon(page.icon, size: 54, color: page.color),
          ),
          const SizedBox(height: 28),
          Text(
            page.title,
            style: context.ds(size: 24),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            page.body,
            style: context.ts(color: p.textDim, size: 15, height: 1.8),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 28),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: p.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (page.exampleLabel != null) ...[
                  Text(
                    page.exampleLabel!,
                    style: context.ts(size: 11.5, w: FontWeight.w700, color: p.gold),
                  ),
                  const SizedBox(height: 4),
                ],
                Text(page.example, style: context.ts(size: 13.5, height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة ترحيب مصغّرة (تُستعمل في شاشة «حول التطبيق»)
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة تعريفية واحدة قابلة لإعادة الاستعمال خارج مسار الترحيب.
class OnboardingFeatureCard extends StatelessWidget {
  const OnboardingFeatureCard({super.key, required this.page});
  final OnboardingPageData page;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 46,
            height: 46,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(page.color, 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: SIcon(page.icon, size: 24, color: page.color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(page.title, style: context.ds(size: 15)),
                const SizedBox(height: 3),
                Text(page.body, style: context.ts(color: p.textDim, size: 13, height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة الترحيب العائد (للمستخدمين القدامى)
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة «أهلاً بعودتك» تُعرض بعد الترحيب حين يعود المستخدم بعد غياب،
/// مع تذكير بآخر ما كان يقرؤه (تُمرَّر البيانات من المنادي).
class WelcomeBackCard extends StatelessWidget {
  const WelcomeBackCard({
    super.key,
    required this.userName,
    this.lastSeriesTitle,
    this.lastChapter,
    this.streak = 0,
    this.onContinue,
    this.onExplore,
  });

  final String userName;
  final String? lastSeriesTitle;
  final int? lastChapter;
  final int streak;
  final VoidCallback? onContinue;
  final VoidCallback? onExplore;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border, width: p.borderW),
        boxShadow: softShadow(p, strength: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(p.gold, 0.15),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: SIcon(SardIcons.wb_sunny_rounded, size: 24, color: p.gold),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('أهلاً بعودتك، $userName', style: context.ds(size: 17)),
                    if (streak > 0)
                      Text(
                        'سلسلة قراءتك: $streak ${streak == 1 ? 'يوم' : 'أيام'} متتالية — حافظ عليها!',
                        style: context.ts(color: p.textDim, size: 12.5, height: 1.5),
                      ),
                  ],
                ),
              ),
            ],
          ),
          if (lastSeriesTitle != null) ...[
            const SizedBox(height: 12),
            Text(
              'كنت تقرأ: $lastSeriesTitle${lastChapter != null ? ' — الفصل $lastChapter' : ''}',
              style: context.ts(size: 13.5, height: 1.5),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: AuthPrimaryButton(
                    label: 'متابعة القراءة',
                    icon: SardIcons.auto_stories_rounded,
                    onPressed: onContinue,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: onExplore,
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                      side: BorderSide(color: p.border),
                    ),
                    child: const Text('استكشاف جديد'),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
