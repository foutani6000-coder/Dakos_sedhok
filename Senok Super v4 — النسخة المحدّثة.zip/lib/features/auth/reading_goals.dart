/// ──────────────────────────────────────────────────────────────────────────
/// أهداف القراءة
///
///  • أنواع الأهداف: فصول يومية، دقائق يومية، أعمال شهرية، فصول أسبوعية
///  • كل هدف [SardReadingGoal]: تقدّم يومي، سلسلة أيام، JSON ذهاباً وإياباً
///  • المخزن [SardReadingGoalsStore]: مفردة (.i) مع load()، مفاتيح
///    sard_reading_goals_v2، يحدّث التقدّم تلقائياً من SettingsController
///  • شاشة [SardReadingGoalsScreen]: إنشاء/تعديل/حذف، أشرطة تقدّم،
///    وشارة «هدف اليوم مكتمل»
/// ──────────────────────────────────────────────────────────────────────────

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'auth_v2.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  أنواع الأهداف
// ═══════════════════════════════════════════════════════════════════════════

enum ReadingGoalType {
  dailyChapters('فصول يومية', 'فصل في اليوم'),
  dailyMinutes('دقائق يومية', 'دقيقة في اليوم'),
  weeklyChapters('فصول أسبوعية', 'فصل في الأسبوع'),
  monthlySeries('أعمال شهرية', 'عمل في الشهر');

  const ReadingGoalType(this.label, this.unitLabel);
  final String label;
  final String unitLabel;

  SIconData get icon => switch (this) {
    ReadingGoalType.dailyChapters => SardIcons.auto_stories_rounded,
    ReadingGoalType.dailyMinutes => SardIcons.watch_later_rounded,
    ReadingGoalType.weeklyChapters => SardIcons.calendar_today_rounded,
    ReadingGoalType.monthlySeries => SardIcons.collections_bookmark_rounded,
  };

  Color color(SardPalette p) => switch (this) {
    ReadingGoalType.dailyChapters => p.accent,
    ReadingGoalType.dailyMinutes => const Color(0xFF22C7D6),
    ReadingGoalType.weeklyChapters => const Color(0xFF5B5BEA),
    ReadingGoalType.monthlySeries => p.gold,
  };

  /// الهدف الافتراضي المقترح عند إنشاء هدف جديد من هذا النوع.
  int get suggestedTarget => switch (this) {
    ReadingGoalType.dailyChapters => 3,
    ReadingGoalType.dailyMinutes => 30,
    ReadingGoalType.weeklyChapters => 10,
    ReadingGoalType.monthlySeries => 2,
  };

  /// حدّ الهدف الأقصى المسموح (لمنع أرقام غير واقعية).
  int get maxTarget => switch (this) {
    ReadingGoalType.dailyChapters => 100,
    ReadingGoalType.dailyMinutes => 720,
    ReadingGoalType.weeklyChapters => 300,
    ReadingGoalType.monthlySeries => 30,
  };
}

/// مدة الهدف (يوم/أسبوع/شهر) — تُحسب دورة التقدّم منها.
enum ReadingGoalPeriod { daily, weekly, monthly }

extension ReadingGoalTypePeriod on ReadingGoalType {
  ReadingGoalPeriod get period => switch (this) {
    ReadingGoalType.dailyChapters => ReadingGoalPeriod.daily,
    ReadingGoalType.dailyMinutes => ReadingGoalPeriod.daily,
    ReadingGoalType.weeklyChapters => ReadingGoalPeriod.weekly,
    ReadingGoalType.monthlySeries => ReadingGoalPeriod.monthly,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
//  نموذج الهدف
// ═══════════════════════════════════════════════════════════════════════════

/// هدف قراءة واحد.
class SardReadingGoal {
  const SardReadingGoal({
    required this.id,
    required this.type,
    required this.target,
    required this.createdAt,
    this.progress = 0,
    this.periodStart,
    this.streak = 0,
    this.bestStreak = 0,
    this.completedPeriods = 0,
    this.active = true,
    this.reminderHour,
  });

  final String id;
  final ReadingGoalType type;

  /// الهدف العددي (فصول/دقائق/أعمال حسب النوع).
  final int target;
  final DateTime createdAt;

  /// التقدّم في الدورة الحالية (يوم/أسبوع/شهر).
  final int progress;

  /// بداية الدورة الحالية (يوم/أسبوع/شهر).
  final DateTime? periodStart;

  /// أيام/دورات الإكمال المتتالية.
  final int streak;
  final int bestStreak;

  /// عدد الدورات المكتملة إجمالاً.
  final int completedPeriods;

  /// هل الهدف نشط (أم مؤرشف)؟
  final bool active;

  /// ساعة التذكير اليومي (null = بلا تذكير). 0..23
  final int? reminderHour;

  double get fraction => target <= 0 ? 0 : (progress / target).clamp(0.0, 1.0);
  bool get isComplete => progress >= target;
  int get remaining => (target - progress).clamp(0, 1 << 30);

  /// عنوان افتراضي عربي (يحتوي العدد والوحدة — تُختبر هذه الصيغة).
  String get defaultTitle {
    final n = target;
    return switch (type) {
      ReadingGoalType.dailyChapters => 'اقرأ $n ${n == 1 ? 'فصل' : 'فصول'} كل يوم',
      ReadingGoalType.dailyMinutes => 'اقرأ $n دقيقة كل يوم',
      ReadingGoalType.weeklyChapters => 'اقرأ $n ${n == 1 ? 'فصلاً' : 'فصول'} كل أسبوع',
      ReadingGoalType.monthlySeries => 'أنهِ $n ${n == 1 ? 'عمل' : 'أعمال'} كل شهر',
    };
  }

  String get progressLabel => '$progress / $target ${type.unitLabel}';

  String get streakLabel {
    if (streak <= 0) return 'ابدأ سلسلتك اليوم';
    return '$streak ${streak == 1 ? 'يوم متتالٍ' : 'أيام متتالية'}';
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type.name,
    'target': target,
    'created_at': createdAt.toIso8601String(),
    'progress': progress,
    'period_start': periodStart?.toIso8601String(),
    'streak': streak,
    'best_streak': bestStreak,
    'completed_periods': completedPeriods,
    'active': active,
    'reminder_hour': reminderHour,
  };

  factory SardReadingGoal.fromJson(Map<String, dynamic> j) => SardReadingGoal(
    id: '${j['id']}',
    type: ReadingGoalType.values.firstWhere(
      (t) => t.name == '${j['type']}',
      orElse: () => ReadingGoalType.dailyChapters,
    ),
    target: (j['target'] as num?)?.toInt() ?? 1,
    createdAt: DateTime.tryParse('${j['created_at']}') ?? DateTime.now(),
    progress: (j['progress'] as num?)?.toInt() ?? 0,
    periodStart: j['period_start'] == null ? null : DateTime.tryParse('${j['period_start']}'),
    streak: (j['streak'] as num?)?.toInt() ?? 0,
    bestStreak: (j['best_streak'] as num?)?.toInt() ?? 0,
    completedPeriods: (j['completed_periods'] as num?)?.toInt() ?? 0,
    active: j['active'] != false,
    reminderHour: (j['reminder_hour'] as num?)?.toInt(),
  );

  SardReadingGoal copyWith({
    int? target,
    int? progress,
    DateTime? periodStart,
    int? streak,
    int? bestStreak,
    int? completedPeriods,
    bool? active,
    int? reminderHour,
    bool clearReminder = false,
  }) =>
      SardReadingGoal(
        id: id,
        type: type,
        target: target ?? this.target,
        createdAt: createdAt,
        progress: progress ?? this.progress,
        periodStart: periodStart ?? this.periodStart,
        streak: streak ?? this.streak,
        bestStreak: bestStreak ?? this.bestStreak,
        completedPeriods: completedPeriods ?? this.completedPeriods,
        active: active ?? this.active,
        reminderHour: clearReminder ? null : (reminderHour ?? this.reminderHour),
      );
}

/// يولّد معرّف هدف فريداً.
String generateGoalId() =>
    'goal_${DateTime.now().millisecondsSinceEpoch}_${(1000 + DateTime.now().microsecond % 9000)}';

// ═══════════════════════════════════════════════════════════════════════════
//  المخزن
// ═══════════════════════════════════════════════════════════════════════════

/// مفاتيح التخزين.
class ReadingGoalsKeys {
  static const String goals = 'sard_reading_goals_v2';
  static const String lastDailyReset = 'sard_reading_goals_v2_last_reset';
}

/// مخزن أهداف القراءة: مفردة (.i) مع load().
///
/// يحدّث التقدّم من SettingsController الحقيقي:
///  • فصول يومية/أسبوعية: من readChapters عبر markRead (يُنادى recordChapter)
///  • دقائق يومية: من totalReadingSeconds (تقدير يومي عبر فرق القراءة)
///  • أعمال شهرية: من عدد الأعمال المكتملة (تقدّم محفوظ) — تُسجَّل يدوياً
///    عبر recordSeriesFinished
class SardReadingGoalsStore extends ChangeNotifier {
  SardReadingGoalsStore._(this._prefs);
  final SharedPreferences _prefs;

  static SardReadingGoalsStore? _instance;

  static SardReadingGoalsStore get i {
    final inst = _instance;
    if (inst == null) throw StateError('SardReadingGoalsStore.load() must be called first');
    return inst;
  }

  static Future<SardReadingGoalsStore> load() async {
    _instance ??= SardReadingGoalsStore._(await SharedPreferences.getInstance());
    return _instance!;
  }

  static SardReadingGoalsStore fromPrefs(SharedPreferences prefs) {
    _instance = SardReadingGoalsStore._(prefs);
    return _instance!;
  }

  List<SardReadingGoal> _goals = [];

  List<SardReadingGoal> get goals => List<SardReadingGoal>.unmodifiable(_goals);
  List<SardReadingGoal> get activeGoals => _goals.where((g) => g.active).toList();
  List<SardReadingGoal> get archivedGoals => _goals.where((g) => !g.active).toList();

  /// عدد الأهداف المكتملة في دورتها الحالية.
  int get completedToday => activeGoals.where((g) => g.isComplete).length;

  /// هل كل الأهداف النشطة مكتملة اليوم؟
  bool get allComplete => activeGoals.isNotEmpty && activeGoals.every((g) => g.isComplete);

  /// يهيّئ المخزن: يقرأ الأهداف ويصفّر الدورات المنتهية.
  Future<void> init() async {
    _readLocal();
    _resetExpiredPeriods(DateTime.now());
    await _saveLocal();
    notifyListeners();
  }

  void _readLocal() {
    final raw = _prefs.getString(ReadingGoalsKeys.goals);
    if (raw == null || raw.isEmpty) {
      _goals = [];
      return;
    }
    try {
      final list = jsonDecode(raw) as List;
      _goals = list
          .whereType<Map>()
          .map((e) => SardReadingGoal.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      _goals = [];
    }
  }

  Future<void> _saveLocal() async {
    await _prefs.setString(
      ReadingGoalsKeys.goals,
      jsonEncode(_goals.map((g) => g.toJson()).toList()),
    );
  }

  /// ينشئ هدفاً جديداً.
  Future<SardReadingGoal> addGoal(ReadingGoalType type, int target, {int? reminderHour}) async {
    final goal = SardReadingGoal(
      id: generateGoalId(),
      type: type,
      target: target.clamp(1, type.maxTarget),
      createdAt: DateTime.now(),
      periodStart: _periodStartFor(type, DateTime.now()),
      reminderHour: reminderHour,
    );
    _goals = [..._goals, goal];
    await _saveLocal();
    notifyListeners();
    return goal;
  }

  /// يحدّث هدفاً (الهدف العددي أو التذكير).
  Future<void> updateGoal(String id, {int? target, int? reminderHour, bool clearReminder = false}) async {
    _goals = _goals.map((g) {
      if (g.id != id) return g;
      return g.copyWith(
        target: target?.clamp(1, g.type.maxTarget),
        reminderHour: reminderHour,
        clearReminder: clearReminder,
      );
    }).toList();
    await _saveLocal();
    notifyListeners();
  }

  /// يرشف هدفاً (إيقاف مؤقت دون حذف).
  Future<void> archiveGoal(String id) async {
    _goals = _goals.map((g) => g.id == id ? g.copyWith(active: false) : g).toList();
    await _saveLocal();
    notifyListeners();
  }

  /// يعيد هدفاً مؤرشفاً إلى النشطة.
  Future<void> restoreGoal(String id) async {
    _goals = _goals.map((g) => g.id == id ? g.copyWith(active: true) : g).toList();
    await _saveLocal();
    notifyListeners();
  }

  /// يحذف هدفاً نهائياً.
  Future<void> removeGoal(String id) async {
    _goals = _goals.where((g) => g.id != id).toList();
    await _saveLocal();
    notifyListeners();
  }

  /// يسجّل قراءة فصل (يُنادى بعد markRead في القارئ).
  /// يزيد تقدّم أهداف الفصول اليومية والأسبوعية.
  Future<void> recordChapter({DateTime? at}) async {
    final now = at ?? DateTime.now();
    _resetExpiredPeriods(now);
    var changed = false;
    _goals = _goals.map((g) {
      if (!g.active) return g;
      if (g.type == ReadingGoalType.dailyChapters || g.type == ReadingGoalType.weeklyChapters) {
        changed = true;
        return _withProgress(g, g.progress + 1, now);
      }
      return g;
    }).toList();
    if (changed) {
      await _saveLocal();
      notifyListeners();
    }
  }

  /// يسجّل دقائق قراءة (يُنادى دورياً من القارئ).
  Future<void> recordMinutes(int minutes, {DateTime? at}) async {
    if (minutes <= 0) return;
    final now = at ?? DateTime.now();
    _resetExpiredPeriods(now);
    var changed = false;
    _goals = _goals.map((g) {
      if (!g.active) return g;
      if (g.type == ReadingGoalType.dailyMinutes) {
        changed = true;
        return _withProgress(g, g.progress + minutes, now);
      }
      return g;
    }).toList();
    if (changed) {
      await _saveLocal();
      notifyListeners();
    }
  }

  /// يسجّل إنهاء عمل كامل (يُنادى عند إكمال آخر فصل في عمل).
  Future<void> recordSeriesFinished({DateTime? at}) async {
    final now = at ?? DateTime.now();
    _resetExpiredPeriods(now);
    var changed = false;
    _goals = _goals.map((g) {
      if (!g.active) return g;
      if (g.type == ReadingGoalType.monthlySeries) {
        changed = true;
        return _withProgress(g, g.progress + 1, now);
      }
      return g;
    }).toList();
    if (changed) {
      await _saveLocal();
      notifyListeners();
    }
  }

  /// يزيد التقدّم مع تحديث السلسلة عند الإكمال.
  SardReadingGoal _withProgress(SardReadingGoal g, int newProgress, DateTime now) {
    final wasComplete = g.isComplete;
    final next = g.copyWith(progress: newProgress);
    if (!wasComplete && next.isComplete) {
      return next.copyWith(
        streak: g.streak + 1,
        bestStreak: (g.streak + 1) > g.bestStreak ? g.streak + 1 : g.bestStreak,
        completedPeriods: g.completedPeriods + 1,
      );
    }
    return next;
  }

  /// بداية الدورة لنوع هدف وتاريخ معطيين.
  DateTime _periodStartFor(ReadingGoalType type, DateTime now) {
    switch (type.period) {
      case ReadingGoalPeriod.daily:
        return DateTime(now.year, now.month, now.day);
      case ReadingGoalPeriod.weekly:
        final monday = now.subtract(Duration(days: now.weekday - 1));
        return DateTime(monday.year, monday.month, monday.day);
      case ReadingGoalPeriod.monthly:
        return DateTime(now.year, now.month, 1);
    }
  }

  /// يصفّر تقدّم الدورات المنتهية (يوم/أسبوع/شهر جديد).
  void _resetExpiredPeriods(DateTime now) {
    var changed = false;
    _goals = _goals.map((g) {
      final start = _periodStartFor(g.type, now);
      final currentStart = g.periodStart;
      if (currentStart == null || !_samePeriod(currentStart, start, g.type.period)) {
        changed = true;
        // إن كانت الدورة السابقة غير مكتملة، تنكسر السلسلة.
        final streak = g.isComplete ? g.streak : 0;
        return g.copyWith(progress: 0, periodStart: start, streak: streak);
      }
      return g;
    }).toList();
    if (changed) {
      // الحفظ يتم في المنادي (init/record*) — لا await هنا.
    }
  }

  bool _samePeriod(DateTime a, DateTime b, ReadingGoalPeriod period) {
    switch (period) {
      case ReadingGoalPeriod.daily:
        return a.year == b.year && a.month == b.month && a.day == b.day;
      case ReadingGoalPeriod.weekly:
        final ma = a.subtract(Duration(days: a.weekday - 1));
        final mb = b.subtract(Duration(days: b.weekday - 1));
        return ma.year == mb.year && ma.month == mb.month && ma.day == mb.day;
      case ReadingGoalPeriod.monthly:
        return a.year == b.year && a.month == b.month;
    }
  }

  /// يعيد ضبط كل التقدّم (للاختبارات أو بعد حذف البيانات).
  Future<void> resetAll() async {
    _goals = [];
    await _saveLocal();
    notifyListeners();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة أهداف القراءة
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة أهداف القراءة: قائمة الأهداف النشطة مع أشرطة التقدّم،
/// وإنشاء هدف جديد، وأرشيف الأهداف المتوقفة.
class SardReadingGoalsScreen extends StatelessWidget {
  const SardReadingGoalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<SardReadingGoalsStore>();
    final active = store.activeGoals;
    final archived = store.archivedGoals;
    return Scaffold(
      appBar: AppBar(
        title: const Text('أهداف القراءة'),
        actions: [
          IconButton(
            onPressed: () => showModalBottomSheet<void>(
              context: context,
              isScrollControlled: true,
              backgroundColor: p.surface,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.2))),
              ),
              builder: (_) => const CreateGoalSheet(),
            ),
            icon: const SIcon(SardIcons.add_circle_outline),
            tooltip: 'هدف جديد',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          if (store.allComplete)
            const AuthNoticeBanner(
              icon: SardIcons.check_circle_rounded,
              text: 'رائع! أكملت كل أهدافك النشطة في دورتها الحالية. حافظ على السلسلة غداً.',
              color: Color(0xFF3FA66A),
            ),
          if (store.allComplete) const SizedBox(height: 16),
          if (active.isEmpty) ...[
            _emptyState(context, p),
          ] else ...[
            Text(
              'أهدافك النشطة (${store.completedToday} من ${active.length} مكتملة)',
              style: context.ds(size: 17),
            ),
            const SizedBox(height: 10),
            for (final goal in active) ...[
              ReadingGoalCard(goal: goal),
              const SizedBox(height: 10),
            ],
          ],
          if (archived.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text('أهداف مؤرشفة (${archived.length})', style: context.ds(size: 17)),
            const SizedBox(height: 8),
            for (final goal in archived) ...[
              ReadingGoalCard(goal: goal, archived: true),
              const SizedBox(height: 10),
            ],
          ],
          const SizedBox(height: 8),
          Text(
            'يُحدَّث التقدّم تلقائياً من قراءتك الفعلية: كل فصل تقرؤه يزيد '
            'أهداف الفصول، وكل دقيقة تقضيها في القارئ تزيد هدف الدقائق.',
            style: context.ts(color: p.textDim, size: 12.5, height: 1.6),
          ),
        ],
      ),
    );
  }

  Widget _emptyState(BuildContext context, SardPalette p) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          Container(
            width: 72,
            height: 72,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(24),
            ),
            child: SIcon(SardIcons.local_fire_department_rounded, size: 36, color: p.accent),
          ),
          const SizedBox(height: 12),
          Text('لا أهداف بعد', style: context.ds(size: 18)),
          const SizedBox(height: 6),
          Text(
            'حدّد هدفاً يومياً صغيراً — 3 فصول أو 30 دقيقة — وسيتتبّعه '
            'التطبيق تلقائياً ويحتفل معك بإكماله.',
            style: context.ts(color: p.textDim, size: 13.5, height: 1.6),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 14),
          AuthPrimaryButton(
            label: 'إنشاء أول هدف',
            icon: SardIcons.add_circle_outline,
            onPressed: () {
              final p2 = context.pal;
              showModalBottomSheet<void>(
                context: context,
                isScrollControlled: true,
                backgroundColor: p2.surface,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(p2.r(1.2))),
                ),
                builder: (_) => const CreateGoalSheet(),
              );
            },
          ),
        ],
      ),
    );
  }
}

/// بطاقة هدف واحد: الأيقونة والعنوان وشريط التقدّم والسلسلة والإجراءات.
class ReadingGoalCard extends StatelessWidget {
  const ReadingGoalCard({super.key, required this.goal, this.archived = false});
  final SardReadingGoal goal;
  final bool archived;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.read<SardReadingGoalsStore>();
    final color = goal.type.color(p);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(
          color: goal.isComplete ? tint(const Color(0xFF3FA66A), 0.5) : p.border,
          width: p.borderW,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(color, 0.12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: SIcon(goal.type.icon, size: 22, color: color),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(goal.defaultTitle, style: context.ts(w: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(
                      '${goal.type.label} · ${goal.streakLabel}',
                      style: context.ts(color: p.textDim, size: 12),
                    ),
                  ],
                ),
              ),
              if (goal.isComplete)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: tint(const Color(0xFF3FA66A), 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SIcon(SardIcons.check_circle_rounded, size: 14, color: Color(0xFF3FA66A)),
                      const SizedBox(width: 4),
                      Text('مكتمل', style: context.ts(size: 11.5, w: FontWeight.w700, color: const Color(0xFF3FA66A))),
                    ],
                  ),
                ),
              PopupMenuButton<String>(
                icon: const SIcon(SardIcons.expand_more_rounded, size: 20),
                onSelected: (value) async {
                  if (value == 'archive') {
                    if (archived) {
                      await store.restoreGoal(goal.id);
                    } else {
                      await store.archiveGoal(goal.id);
                    }
                  } else if (value == 'delete') {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('حذف الهدف؟'),
                        content: Text('سيُحذف هدف «${goal.defaultTitle}» نهائياً مع سلسلته.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(false),
                            child: const Text('إلغاء'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(true),
                            child: const Text('حذف', style: TextStyle(color: Color(0xFFE5484D))),
                          ),
                        ],
                      ),
                    );
                    if (ok == true) await store.removeGoal(goal.id);
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(
                    value: 'archive',
                    child: Text(archived ? 'إعادة تنشيط' : 'أرشفة'),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Text('حذف', style: TextStyle(color: Color(0xFFE5484D))),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5),
                  child: LinearProgressIndicator(
                    value: goal.fraction,
                    minHeight: 8,
                    backgroundColor: p.border,
                    color: goal.isComplete ? const Color(0xFF3FA66A) : color,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                goal.progressLabel,
                style: context.ts(size: 12.5, w: FontWeight.w700, color: color),
              ),
            ],
          ),
          if (goal.reminderHour != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const SIcon(SardIcons.notifications_none_rounded, size: 15),
                const SizedBox(width: 6),
                Text(
                  'تذكير يومي عند الساعة ${goal.reminderHour}:00 (لافتة داخل التطبيق)',
                  style: context.ts(color: p.textDim, size: 12),
                ),
              ],
            ),
          ],
          if (goal.bestStreak > 0) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                const SIcon(SardIcons.local_fire_department_rounded, size: 15),
                const SizedBox(width: 6),
                Text(
                  'أفضل سلسلة: ${goal.bestStreak} ${goal.bestStreak == 1 ? 'يوم' : 'أيام'} · '
                  'دورات مكتملة: ${goal.completedPeriods}',
                  style: context.ts(color: p.textDim, size: 12),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ورقة إنشاء هدف جديد
// ═══════════════════════════════════════════════════════════════════════════

/// ورقة إنشاء هدف: اختيار النوع + الهدف العددي (منزلق) + ساعة تذكير اختيارية.
class CreateGoalSheet extends StatefulWidget {
  const CreateGoalSheet({super.key});

  @override
  State<CreateGoalSheet> createState() => _CreateGoalSheetState();
}

class _CreateGoalSheetState extends State<CreateGoalSheet> {
  ReadingGoalType _type = ReadingGoalType.dailyChapters;
  late int _target = _type.suggestedTarget;
  int? _reminderHour;

  void _pickType(ReadingGoalType t) {
    setState(() {
      _type = t;
      _target = t.suggestedTarget;
    });
  }

  Future<void> _save() async {
    final store = context.read<SardReadingGoalsStore>();
    await store.addGoal(_type, _target, reminderHour: _reminderHour);
    if (!mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم إنشاء الهدف. بالتوفيق!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(2)),
            ),
          ),
          const SizedBox(height: 16),
          Text('هدف قراءة جديد', style: context.ds(size: 19)),
          const SizedBox(height: 14),
          Text('نوع الهدف', style: context.ts(w: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final t in ReadingGoalType.values)
                ChoiceChip(
                  label: Text(t.label),
                  selected: _type == t,
                  onSelected: (_) => _pickType(t),
                  selectedColor: tint(t.color(p), 0.18),
                  backgroundColor: p.surface,
                  side: BorderSide(color: _type == t ? t.color(p) : p.border),
                  labelStyle: context.ts(
                    size: 13,
                    w: FontWeight.w700,
                    color: _type == t ? t.color(p) : p.text,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: Text('الهدف: $_target ${_type.unitLabel}', style: context.ts(w: FontWeight.w700)),
              ),
              Text(
                'الحد الأقصى ${_type.maxTarget}',
                style: context.ts(color: p.textDim, size: 12),
              ),
            ],
          ),
          Slider(
            value: _target.toDouble(),
            min: 1,
            max: _type.maxTarget.toDouble(),
            divisions: _type.maxTarget - 1,
            label: '$_target',
            onChanged: (v) => setState(() => _target = v.round()),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: Text(
                  'تذكير يومي (اختياري)',
                  style: context.ts(w: FontWeight.w700),
                ),
              ),
              Switch.adaptive(
                value: _reminderHour != null,
                onChanged: (v) => setState(() => _reminderHour = v ? 20 : null),
                activeColor: p.accent,
              ),
            ],
          ),
          if (_reminderHour != null) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                const Text('الساعة:'),
                const SizedBox(width: 8),
                Expanded(
                  child: Slider(
                    value: _reminderHour!.toDouble(),
                    min: 0,
                    max: 23,
                    divisions: 23,
                    label: '$_reminderHour:00',
                    onChanged: (v) => setState(() => _reminderHour = v.round()),
                  ),
                ),
                Text('$_reminderHour:00', style: context.ts(w: FontWeight.w700)),
              ],
            ),
            Text(
              'التذكير لافتة داخل التطبيق عند فتحه بعد الساعة المحددة (بلا إشعارات نظام).',
              style: context.ts(color: p.textDim, size: 12, height: 1.5),
            ),
          ],
          const SizedBox(height: 16),
          AuthPrimaryButton(
            label: 'إنشاء الهدف',
            icon: SardIcons.check_circle_rounded,
            onPressed: _save,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  التقرير الأسبوعي للأهداف + بطاقة الملخص
// ═══════════════════════════════════════════════════════════════════════════

/// تقرير أسبوعي نصي قابل للمشاركة (عربي، يُبنى من الأهداف الحقيقية).
class GoalsWeeklyReport {
  const GoalsWeeklyReport({
    required this.weekStart,
    required this.goals,
    required this.completedCount,
  });

  final DateTime weekStart;
  final List<SardReadingGoal> goals;
  final int completedCount;

  int get total => goals.length;
  double get completionRate => total == 0 ? 0 : completedCount / total;

  String get headline {
    if (total == 0) return 'لا أهداف هذا الأسبوع.';
    if (completedCount == total) return 'أسبوع مثالي! أكملت كل أهدافك.';
    if (completedCount == 0) return 'أسبوع جديد — ابدأ بهدفك الأول اليوم.';
    return 'أكملت $completedCount من $total أهداف هذا الأسبوع.';
  }

  /// نص المشاركة (للمشاركة مع الأصدقاء).
  String toShareText() {
    final buffer = StringBuffer();
    buffer.writeln('تقريري الأسبوعي في القراءة على Senok');
    buffer.writeln('الأسبوع: ${weekStart.year}/${weekStart.month}/${weekStart.day}');
    buffer.writeln(headline);
    for (final g in goals) {
      buffer.writeln('• ${g.defaultTitle}: ${g.progressLabel}${g.isComplete ? ' ✓' : ''}');
    }
    return buffer.toString().trim();
  }
}

/// يبني التقرير الأسبوعي من مخزن الأهداف.
GoalsWeeklyReport buildWeeklyReport(SardReadingGoalsStore store, {DateTime? now}) {
  final date = now ?? DateTime.now();
  final monday = date.subtract(Duration(days: date.weekday - 1));
  final start = DateTime(monday.year, monday.month, monday.day);
  final goals = store.activeGoals;
  return GoalsWeeklyReport(
    weekStart: start,
    goals: goals,
    completedCount: goals.where((g) => g.isComplete).length,
  );
}

/// بطاقة ملخص الأهداف (للواجهة الرئيسية أو شاشة الملف).
class GoalsSummaryCard extends StatelessWidget {
  const GoalsSummaryCard({super.key, this.onTap});
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<SardReadingGoalsStore>();
    final report = buildWeeklyReport(store);
    final active = store.activeGoals;
    if (active.isEmpty) return const SizedBox.shrink();
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(p.r(0.9)),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: tint(p.accent, 0.12),
                borderRadius: BorderRadius.circular(13),
              ),
              child: SIcon(SardIcons.local_fire_department_rounded, size: 22, color: p.accent),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(report.headline, style: context.ts(w: FontWeight.w700)),
                  const SizedBox(height: 3),
                  Text(
                    '${store.completedToday} من ${active.length} أهداف مكتملة في دورتها',
                    style: context.ts(color: p.textDim, size: 12.5),
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 44,
              height: 44,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: report.completionRate,
                    strokeWidth: 5,
                    color: p.accent,
                    backgroundColor: p.border,
                  ),
                  Text(
                    '${(report.completionRate * 100).round()}٪',
                    style: context.ts(size: 10, w: FontWeight.w800),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
