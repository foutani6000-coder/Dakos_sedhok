/// ──────────────────────────────────────────────────────────────────────────
/// شاشة الأمان — قفل PIN ونقاط الأمان
///
///  • قفل PIN مكوّن من 4–6 أرقام، يُخزَّن مجزّأً بخوارزمية FNV-1a مع ملح
///    عشوائي (لا يُخزَّن الـ PIN نفسه أبداً)
///  • محاولات خاطئة محدودة (5) ثم قفل مؤقت 30 ثانية
///  • «البصمة» في هذا التطبيق تفضيل مخزّن فقط: لا يوجد تحقق بيومتري حقيقي
///    هنا، والواجهة تقول ذلك صراحةً (لا ندّعي ما لا نفعله)
///  • نقاط الأمان [computeSecurityScore]: قواعد شفافة (PIN + بصمة + جلسات)
/// ──────────────────────────────────────────────────────────────────────────

import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'auth_v2.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  تجزئة FNV-1a (64 بت) مع ملح
// ═══════════════════════════════════════════════════════════════════════════

/// تجزئة FNV-1a 64-bit لنص. حتمية وسريعة ومناسبة لقفل محلي خفيف
/// (ليست بديلاً عن bcrypt في الخوادم — القفل هنا حماية جهاز محلية).
String fnv1aHash64(String input) {
  var hash = 0xcbf29ce484222325;
  const prime = 0x100000001b3;
  final bytes = utf8.encode(input);
  for (final b in bytes) {
    hash ^= b;
    hash = (hash * prime) & 0xFFFFFFFFFFFFFFFF;
  }
  return hash.toRadixString(16).padLeft(16, '0');
}

/// تجزئة الـ PIN مع ملحه.
String pinHash(String pin, String salt) => fnv1aHash64('$salt::$pin');

/// يولّد ملحاً عشوائياً (32 حرفاً سداسياً).
String generatePinSalt([Random? random]) {
  final r = random ?? Random.secure();
  final bytes = List<int>.generate(16, (_) => r.nextInt(256));
  return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}

/// هل الـ PIN صالح شكلاً؟ أرقام فقط، 4–6 أرقام.
bool isValidPinFormat(String pin) => RegExp(r'^\d{4,6}$').hasMatch(pin);

/// هل الـ PIN ضعيف بشكل واضح؟ (متسلسل أو مكرر: 1234، 0000، 1111…)
bool isWeakPin(String pin) {
  if (pin.isEmpty) return true;
  if (pin.split('').toSet().length == 1) return true; // كل الأرقام متماثلة
  const sequences = ['0123', '1234', '2345', '3456', '4567', '5678', '6789', '9876', '8765', '4321', '0000'];
  for (final s in sequences) {
    if (pin.contains(s)) return true;
  }
  // تصاعدي/تنازلي كامل مثل 123456 أو 654321
  var ascending = true;
  var descending = true;
  for (var i = 1; i < pin.length; i++) {
    final d = pin.codeUnitAt(i) - pin.codeUnitAt(i - 1);
    if (d != 1) ascending = false;
    if (d != -1) descending = false;
  }
  return ascending || descending;
}

// ═══════════════════════════════════════════════════════════════════════════
//  مخزن الـ PIN
// ═══════════════════════════════════════════════════════════════════════════

/// مفاتيح التخزين (SharedPreferences).
class PinStoreKeys {
  static const String enabled = 'sard_pin_enabled_v2';
  static const String hash = 'sard_pin_hash_v2';
  static const String salt = 'sard_pin_salt_v2';
  static const String length = 'sard_pin_length_v2';
  static const String biometricPref = 'sard_biometric_pref_v2';
  static const String failedAttempts = 'sard_pin_failed_v2';
  static const String lockedUntil = 'sard_pin_locked_until_v2';
  static const String lastUnlock = 'sard_pin_last_unlock_v2';
}

/// مخزن قفل الـ PIN. مفردة (singleton) مع نسخة اختبارية.
class PinStore extends ChangeNotifier {
  PinStore._(this._prefs);
  final SharedPreferences _prefs;

  static PinStore? _instance;

  /// المفردة العامة (تُهيَّأ عند إقلاع التطبيق).
  static PinStore get i {
    final inst = _instance;
    if (inst == null) throw StateError('PinStore.load() must be called first');
    return inst;
  }

  static Future<PinStore> load() async {
    _instance ??= PinStore._(await SharedPreferences.getInstance());
    return _instance!;
  }

  /// نسخة اختبارية متزامنة من نسخة SharedPreferences جاهزة (للاختبارات).
  static PinStore fromPrefs(SharedPreferences prefs) {
    _instance = PinStore._(prefs);
    return _instance!;
  }

  bool get pinEnabled => _prefs.getBool(PinStoreKeys.enabled) ?? false;
  int get pinLength => _prefs.getInt(PinStoreKeys.length) ?? 4;
  String? get _hash => _prefs.getString(PinStoreKeys.hash);
  String? get _salt => _prefs.getString(PinStoreKeys.salt);

  /// تفضيل البصمة المخزّن (تفضيل فقط — لا يوجد تحقق بيومتري حقيقي).
  bool get biometricPreferred => _prefs.getBool(PinStoreKeys.biometricPref) ?? false;

  int get failedAttempts => _prefs.getInt(PinStoreKeys.failedAttempts) ?? 0;

  DateTime? get lockedUntil {
    final ms = _prefs.getInt(PinStoreKeys.lockedUntil);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  bool get isLocked {
    final until = lockedUntil;
    if (until == null) return false;
    return DateTime.now().isBefore(until);
  }

  int get lockRemainingSeconds {
    final until = lockedUntil;
    if (until == null) return 0;
    final s = until.difference(DateTime.now()).inSeconds;
    return s > 0 ? s : 0;
  }

  DateTime? get lastUnlock {
    final ms = _prefs.getInt(PinStoreKeys.lastUnlock);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  /// يفعّل قفلاً جديداً بالـ PIN المعطى (يستبدل أي قفل سابق).
  Future<bool> setPin(String pin) async {
    if (!isValidPinFormat(pin)) return false;
    final salt = generatePinSalt();
    final ok = await _prefs.setString(PinStoreKeys.salt, salt);
    if (!ok) return false;
    await _prefs.setString(PinStoreKeys.hash, pinHash(pin, salt));
    await _prefs.setInt(PinStoreKeys.length, pin.length);
    await _prefs.setBool(PinStoreKeys.enabled, true);
    await _prefs.setInt(PinStoreKeys.failedAttempts, 0);
    await _prefs.remove(PinStoreKeys.lockedUntil);
    notifyListeners();
    return true;
  }

  /// يتحقق من الـ PIN المدخل. يعيد true عند المطابقة.
  Future<bool> verifyPin(String pin) async {
    if (!pinEnabled) return true;
    if (isLocked) return false;
    final hash = _hash;
    final salt = _salt;
    if (hash == null || salt == null) return false;
    final ok = pinHash(pin, salt) == hash;
    if (ok) {
      await _prefs.setInt(PinStoreKeys.failedAttempts, 0);
      await _prefs.remove(PinStoreKeys.lockedUntil);
      await _prefs.setInt(PinStoreKeys.lastUnlock, DateTime.now().millisecondsSinceEpoch);
    } else {
      final n = failedAttempts + 1;
      await _prefs.setInt(PinStoreKeys.failedAttempts, n);
      if (n >= 5) {
        await _prefs.setInt(
          PinStoreKeys.lockedUntil,
          DateTime.now().add(const Duration(seconds: 30)).millisecondsSinceEpoch,
        );
        await _prefs.setInt(PinStoreKeys.failedAttempts, 0);
      }
    }
    notifyListeners();
    return ok;
  }

  /// يغيّر الـ PIN بعد التحقق من القديم.
  Future<bool> changePin(String oldPin, String newPin) async {
    if (!await verifyPin(oldPin)) return false;
    return setPin(newPin);
  }

  /// يعطّل القفل نهائياً (يحذف التجزئة والملح).
  Future<void> disablePin() async {
    await _prefs.setBool(PinStoreKeys.enabled, false);
    await _prefs.remove(PinStoreKeys.hash);
    await _prefs.remove(PinStoreKeys.salt);
    await _prefs.remove(PinStoreKeys.lockedUntil);
    await _prefs.setInt(PinStoreKeys.failedAttempts, 0);
    notifyListeners();
  }

  /// يحفظ تفضيل البصمة (تفضيل عرضي فقط — بلا تحقق حقيقي).
  Future<void> setBiometricPreferred(bool value) async {
    await _prefs.setBool(PinStoreKeys.biometricPref, value);
    notifyListeners();
  }

  /// يعيد ضبط عدّاد المحاولات الفاشلة (بعد فتح ناجح من مكان آخر).
  Future<void> resetFailures() async {
    await _prefs.setInt(PinStoreKeys.failedAttempts, 0);
    await _prefs.remove(PinStoreKeys.lockedUntil);
    notifyListeners();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  نقاط الأمان
// ═══════════════════════════════════════════════════════════════════════════

/// عنصر واحد من عناصر نقاط الأمان.
class SecurityScoreItem {
  const SecurityScoreItem({
    required this.id,
    required this.label,
    required this.met,
    required this.points,
    this.hint,
  });

  final String id;
  final String label;
  final bool met;
  final int points;
  final String? hint;
}

/// نتيجة نقاط الأمان: المجموع من 100 + التفصيل.
class SecurityScore {
  const SecurityScore({required this.total, required this.items});
  final int total;
  final List<SecurityScoreItem> items;

  String get label => switch (total) {
    >= 80 => 'ممتاز',
    >= 60 => 'جيد',
    >= 40 => 'متوسط',
    _ => 'ضعيف',
  };

  Color color(SardPalette p) => switch (total) {
    >= 80 => const Color(0xFF3FA66A),
    >= 60 => const Color(0xFF7BAE4A),
    >= 40 => p.gold,
    _ => const Color(0xFFE5484D),
  };
}

/// يحسب نقاط الأمان قواعدياً من حالة الحساب الحالية.
///
///  • قفل PIN مفعّل: 40 نقطة (30 إن كان الـ PIN ضعيفاً — لا نعرف قوته بعد
///    التجزئة، لذا نمنح 35 افتراضياً ونشرح ذلك)
///  • تفضيل البصمة: 10 نقاط
///  • كلمة مرور قوية (آخر تقييم محفوظ): 25 نقطة
///  • جلسة واحدة نشطة فقط: 15 نقطة
///  • بريد موثّق: 10 نقاط
int computeSecurityScoreValue({
  required bool pinEnabled,
  required bool biometricPreferred,
  required bool strongPassword,
  required int activeSessions,
  required bool emailVerified,
}) {
  var total = 0;
  if (pinEnabled) total += 35;
  if (biometricPreferred) total += 10;
  if (strongPassword) total += 25;
  if (activeSessions <= 1) total += 15;
  if (emailVerified) total += 10;
  return total.clamp(0, 100);
}

/// يبني تفصيل نقاط الأمان لعرضه في الشاشة.
SecurityScore computeSecurityScore({
  required bool pinEnabled,
  required bool biometricPreferred,
  required bool strongPassword,
  required int activeSessions,
  required bool emailVerified,
}) {
  final items = <SecurityScoreItem>[
    SecurityScoreItem(
      id: 'pin',
      label: 'قفل PIN مفعّل',
      met: pinEnabled,
      points: 35,
      hint: pinEnabled ? null : 'فعّل قفل PIN لحماية التطبيق على هذا الجهاز.',
    ),
    SecurityScoreItem(
      id: 'password',
      label: 'كلمة مرور قوية',
      met: strongPassword,
      points: 25,
      hint: strongPassword ? null : 'استخدم 12 حرفاً مع رقم ورمز.',
    ),
    SecurityScoreItem(
      id: 'sessions',
      label: 'جلسة واحدة نشطة',
      met: activeSessions <= 1,
      points: 15,
      hint: activeSessions <= 1 ? null : 'لديك $activeSessions جلسات نشطة — راجعها وأغلق غير المستخدم.',
    ),
    SecurityScoreItem(
      id: 'biometric',
      label: 'تفضيل البصمة مفعّل',
      met: biometricPreferred,
      points: 10,
      hint: 'تفضيل عرضي يُذكّرك باستخدام بصمة جهازك (بلا تحقق حقيقي داخل التطبيق).',
    ),
    SecurityScoreItem(
      id: 'email',
      label: 'البريد موثّق',
      met: emailVerified,
      points: 10,
      hint: emailVerified ? null : 'وثّق بريدك لاستعادة الحساب عند الحاجة.',
    ),
  ];
  final total = items.where((i) => i.met).fold<int>(0, (a, i) => a + i.points).clamp(0, 100);
  return SecurityScore(total: total, items: items);
}

// ═══════════════════════════════════════════════════════════════════════════
//  لوحة أرقام الـ PIN
// ═══════════════════════════════════════════════════════════════════════════

/// لوحة أرقام لإدخال الـ PIN (4–6 أرقام) مع نقاط تقدّم وزر مسح.
class PinPad extends StatefulWidget {
  const PinPad({
    super.key,
    required this.length,
    required this.onCompleted,
    this.enabled = true,
    this.error = false,
  });

  final int length;
  final ValueChanged<String> onCompleted;
  final bool enabled;
  final bool error;

  @override
  State<PinPad> createState() => _PinPadState();
}

class _PinPadState extends State<PinPad> {
  String _value = '';

  void _press(String digit) {
    if (!widget.enabled) return;
    if (_value.length >= widget.length) return;
    HapticFeedback.selectionClick();
    setState(() => _value += digit);
    if (_value.length == widget.length) {
      final v = _value;
      Future.microtask(() {
        widget.onCompleted(v);
        if (mounted) setState(() => _value = '');
      });
    }
  }

  void _backspace() {
    if (!widget.enabled || _value.isEmpty) return;
    setState(() => _value = _value.substring(0, _value.length - 1));
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    Widget keyButton(String label, {VoidCallback? onTap, SIconData? icon}) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(40),
          child: Container(
            width: 72,
            height: 72,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: p.border),
              color: p.surface,
            ),
            child: icon != null
                ? SIcon(icon, size: 26, color: p.text)
                : Text(label, style: context.ds(size: 26)),
          ),
        ),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < widget.length; i++)
              Container(
                width: 16,
                height: 16,
                margin: const EdgeInsets.symmetric(horizontal: 7),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _value.length
                      ? (widget.error ? const Color(0xFFE5484D) : p.accent)
                      : Colors.transparent,
                  border: Border.all(
                    color: widget.error ? const Color(0xFFE5484D) : p.border,
                    width: 1.5,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 28),
        for (final row in const [
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
        ])
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [for (final d in row) keyButton(d, onTap: () => _press(d))],
            ),
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const SizedBox(width: 72, height: 72),
            keyButton('0', onTap: () => _press('0')),
            keyButton('', icon: SardIcons.arrow_back_rounded, onTap: _backspace),
          ],
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة قفل الـ PIN
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة قفل كاملة تُعرض عند فتح التطبيق حين يكون الـ PIN مفعّلاً.
/// تعيد true عند فتح ناجح.
class PinLockScreen extends StatefulWidget {
  const PinLockScreen({super.key, required this.store, this.onUnlocked});
  final PinStore store;
  final VoidCallback? onUnlocked;

  @override
  State<PinLockScreen> createState() => _PinLockScreenState();
}

class _PinLockScreenState extends State<PinLockScreen> {
  bool _error = false;
  String? _message;
  bool _checking = false;

  Future<void> _onCompleted(String pin) async {
    if (_checking) return;
    setState(() => _checking = true);
    final ok = await widget.store.verifyPin(pin);
    if (!mounted) return;
    setState(() => _checking = false);
    if (ok) {
      widget.onUnlocked?.call();
      return;
    }
    final store = widget.store;
    setState(() {
      _error = true;
      if (store.isLocked) {
        _message = 'محاولات خاطئة كثيرة. أعد المحاولة بعد ${store.lockRemainingSeconds} ثانية.';
      } else {
        final left = 5 - store.failedAttempts;
        _message = left > 0
            ? 'رمز غير صحيح. بقيت $left ${left == 1 ? 'محاولة' : 'محاولات'} قبل القفل المؤقت.'
            : 'رمز غير صحيح.';
      }
    });
    Future.delayed(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _error = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = widget.store;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(28, 48, 28, 32),
          child: Column(
            children: [
              Container(
                width: 84,
                height: 84,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: p.border),
                ),
                child: SIcon(SardIcons.screen_lock_portrait_rounded, size: 42, color: p.accent),
              ),
              const SizedBox(height: 18),
              Text('التطبيق مقفل', style: context.ds(size: 23)),
              const SizedBox(height: 6),
              Text(
                'أدخل رمز PIN للمتابعة.',
                style: context.ts(color: p.textDim, size: 14, height: 1.5),
              ),
              const SizedBox(height: 36),
              PinPad(
                length: store.pinLength,
                enabled: !store.isLocked && !_checking,
                error: _error,
                onCompleted: _onCompleted,
              ),
              const SizedBox(height: 20),
              if (_message != null)
                Text(
                  _message!,
                  style: context.ts(color: const Color(0xFFE5484D), size: 13.5, height: 1.5),
                  textAlign: TextAlign.center,
                ),
              if (store.isLocked)
                Text(
                  'القفل المؤقت ينتهي خلال ${store.lockRemainingSeconds} ثانية.',
                  style: context.ts(color: p.textDim, size: 13),
                  textAlign: TextAlign.center,
                ),
              const Spacer(),
              TextButton(
                onPressed: () {
                  showDialog<void>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('نسيت رمز PIN؟'),
                      content: const Text(
                        'رمز PIN محلي على هذا الجهاز فقط ولا يمكن استعادته من الخادم. '
                        'لإزالته ستحتاج إلى مسح بيانات التطبيق من إعدادات جهازك، '
                        'وسيؤدي ذلك إلى حذف مكتبتك المحلية وتقدّمك.',
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(ctx).pop(),
                          child: const Text('فهمت'),
                        ),
                      ],
                    ),
                  );
                },
                child: const Text('نسيت رمز PIN؟'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ورقة تغيير الـ PIN
// ═══════════════════════════════════════════════════════════════════════════

/// ورقة من ثلاث خطوات: القديم → الجديد → تأكيد الجديد.
class ChangePinSheet extends StatefulWidget {
  const ChangePinSheet({super.key, required this.store});
  final PinStore store;

  @override
  State<ChangePinSheet> createState() => _ChangePinSheetState();
}

class _ChangePinSheetState extends State<ChangePinSheet> {
  int _step = 0; // 0 قديم، 1 جديد، 2 تأكيد
  String _newPin = '';
  String? _error;
  bool _busy = false;

  String get _title => switch (_step) {
    0 => 'أدخل رمز PIN الحالي',
    1 => 'اختر رمز PIN جديداً',
    _ => 'أعد إدخال الرمز الجديد',
  };

  Future<void> _onCompleted(String pin) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      if (_step == 0) {
        final ok = await widget.store.verifyPin(pin);
        if (!mounted) return;
        if (ok) {
          setState(() {
            _step = 1;
            _error = null;
          });
        } else {
          setState(() => _error = 'الرمز الحالي غير صحيح.');
        }
        return;
      }
      if (_step == 1) {
        if (!isValidPinFormat(pin)) {
          setState(() => _error = 'الرمز 4–6 أرقام.');
          return;
        }
        if (isWeakPin(pin)) {
          setState(() => _error = 'هذا الرمز سهل التخمين (مثل 1234 أو 0000). اختر غيره.');
          return;
        }
        setState(() {
          _newPin = pin;
          _step = 2;
          _error = null;
        });
        return;
      }
      if (pin != _newPin) {
        setState(() => _error = 'الرمزان غير متطابقين. أعد المحاولة.');
        return;
      }
      final ok = await widget.store.setPin(pin);
      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pop(true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم تغيير رمز PIN بنجاح.')),
        );
      } else {
        setState(() => _error = 'تعذّر حفظ الرمز. حاول مجدداً.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(2)),
            ),
          ),
          const SizedBox(height: 16),
          Text(_title, style: context.ds(size: 18)),
          const SizedBox(height: 4),
          Text(
            _step == 0
                ? 'للتحقق من هويتك قبل التغيير.'
                : 'أرقام فقط، 4–6 أرقام، وتجنّب التسلسلات السهلة.',
            style: context.ts(color: p.textDim, size: 13),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          PinPad(
            length: _step == 0 ? widget.store.pinLength : 4,
            onCompleted: _onCompleted,
            enabled: !_busy,
          ),
          if (_error != null) ...[
            const SizedBox(height: 14),
            Text(_error!, style: context.ts(color: const Color(0xFFE5484D), size: 13.5)),
          ],
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

/// ورقة إعداد PIN لأول مرة (بلا خطوة «القديم»).
class SetupPinSheet extends StatefulWidget {
  const SetupPinSheet({super.key, required this.store});
  final PinStore store;

  @override
  State<SetupPinSheet> createState() => _SetupPinSheetState();
}

class _SetupPinSheetState extends State<SetupPinSheet> {
  int _step = 0; // 0 جديد، 1 تأكيد
  String _first = '';
  String? _error;

  Future<void> _onCompleted(String pin) async {
    if (_step == 0) {
      if (!isValidPinFormat(pin)) {
        setState(() => _error = 'الرمز 4–6 أرقام.');
        return;
      }
      if (isWeakPin(pin)) {
        setState(() => _error = 'هذا الرمز سهل التخمين (مثل 1234 أو 0000). اختر غيره.');
        return;
      }
      setState(() {
        _first = pin;
        _step = 1;
        _error = null;
      });
      return;
    }
    if (pin != _first) {
      setState(() => _error = 'الرمزان غير متطابقين. أعد المحاولة من البداية.');
      _first = '';
      _step = 0;
      return;
    }
    final ok = await widget.store.setPin(pin);
    if (!mounted) return;
    if (ok) {
      Navigator.of(context).pop(true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تفعيل قفل PIN.')),
      );
    } else {
      setState(() => _error = 'تعذّر حفظ الرمز. حاول مجدداً.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(2)),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            _step == 0 ? 'اختر رمز PIN' : 'أعد إدخال الرمز للتأكيد',
            style: context.ds(size: 18),
          ),
          const SizedBox(height: 4),
          const Text('يُخزَّن مجزّأً على جهازك فقط، ولا يُرسل إلى أي خادم.'),
          const SizedBox(height: 20),
          PinPad(length: 4, onCompleted: _onCompleted),
          if (_error != null) ...[
            const SizedBox(height: 14),
            Text(_error!, style: context.ts(color: const Color(0xFFE5484D), size: 13.5)),
          ],
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة الأمان الرئيسية
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة الأمان: نقاط الأمان + قفل PIN + تفضيل البصمة + سجل آخر فتح.
class SecurityScreen extends StatelessWidget {
  const SecurityScreen({super.key, required this.pinStore, this.emailVerified = false, this.strongPassword = false, this.activeSessions = 1});

  final PinStore pinStore;

  /// هل البريد موثّق؟ (يمرّرها المنادي من حالة الحساب)
  final bool emailVerified;

  /// هل آخر كلمة مرور قيّمت قوية؟ (يمرّرها المنادي)
  final bool strongPassword;

  /// عدد الجلسات النشطة (يمرّرها المنادي من مدير الجلسات)
  final int activeSessions;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: pinStore,
      builder: (BuildContext context, Widget? child) {
        final score = computeSecurityScore(
          pinEnabled: pinStore.pinEnabled,
          biometricPreferred: pinStore.biometricPreferred,
          strongPassword: strongPassword,
          activeSessions: activeSessions,
          emailVerified: emailVerified,
        );
        final scoreColor = score.color(p);
        return Scaffold(
          appBar: AppBar(title: const Text('الأمان')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
            children: [
              _scoreCard(context, p, score, scoreColor),
              const SizedBox(height: 16),
              AuthSectionCard(
                icon: SardIcons.screen_lock_portrait_rounded,
                color: p.accent,
                title: 'قفل PIN',
                note: 'يقفل التطبيق برمز من 4–6 أرقام عند فتحه. يُخزَّن مجزّأً (FNV-1a مع ملح) على جهازك فقط.',
                child: Column(
                  children: [
                    _switchRow(
                      context,
                      p,
                      title: 'تفعيل قفل PIN',
                      subtitle: pinStore.pinEnabled
                          ? 'مفعّل — ${pinStore.pinLength} أرقام'
                          : 'غير مفعّل',
                      value: pinStore.pinEnabled,
                      onChanged: (v) async {
                        if (v) {
                          await showModalBottomSheet<bool>(
                            context: context,
                            isScrollControlled: true,
                            backgroundColor: p.surface,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.2))),
                            ),
                            builder: (_) => SetupPinSheet(store: pinStore),
                          );
                        } else {
                          final confirm = await showDialog<bool>(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: const Text('إيقاف قفل PIN؟'),
                              content: const Text('سيصبح التطبيق مفتوحاً لأي شخص يمسك جهازك.'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.of(ctx).pop(false),
                                  child: const Text('إلغاء'),
                                ),
                                TextButton(
                                  onPressed: () => Navigator.of(ctx).pop(true),
                                  child: const Text('إيقاف القفل'),
                                ),
                              ],
                            ),
                          );
                          if (confirm == true) await pinStore.disablePin();
                        }
                      },
                    ),
                    if (pinStore.pinEnabled) ...[
                      const SizedBox(height: 6),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const SIcon(SardIcons.edit_rounded, size: 20),
                        title: Text('تغيير رمز PIN', style: context.ts(w: FontWeight.w600)),
                        trailing: const SIcon(SardIcons.chevron_left_rounded, size: 20),
                        onTap: () => showModalBottomSheet<void>(
                          context: context,
                          isScrollControlled: true,
                          backgroundColor: p.surface,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.2))),
                          ),
                          builder: (_) => ChangePinSheet(store: pinStore),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),
              AuthSectionCard(
                icon: SardIcons.shield_rounded,
                color: const Color(0xFF3FA66A),
                title: 'البصمة',
                note: 'تفضيل مخزّن فقط: هذا الإصدار لا يتحقق بيومترياً داخل التطبيق. '
                    'فعّل التفضيل ليُذكّرك التطبيق باستخدام بصمة جهازك عند فتحه.',
                child: _switchRow(
                  context,
                  p,
                  title: 'تفضيل فتح بالبصمة',
                  subtitle: pinStore.biometricPreferred ? 'مفعّل (تذكير فقط)' : 'غير مفعّل',
                  value: pinStore.biometricPreferred,
                  onChanged: (v) => pinStore.setBiometricPreferred(v),
                ),
              ),
              const SizedBox(height: 16),
              AuthSectionCard(
                icon: SardIcons.history_rounded,
                color: p.gold,
                title: 'آخر نشاط أمني',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _infoLine(
                      context,
                      'آخر فتح ناجح بالقفل',
                      pinStore.lastUnlock == null
                          ? 'لم يُسجَّل بعد'
                          : _formatDateTime(pinStore.lastUnlock!),
                    ),
                    const SizedBox(height: 8),
                    _infoLine(
                      context,
                      'محاولات فاشلة متتالية',
                      '${pinStore.failedAttempts} من 5',
                    ),
                    if (pinStore.isLocked) ...[
                      const SizedBox(height: 8),
                      _infoLine(
                        context,
                        'القفل المؤقت ينتهي خلال',
                        '${pinStore.lockRemainingSeconds} ثانية',
                      ),
                    ],
                    const SizedBox(height: 8),
                    _infoLine(
                      context,
                      'مكان التخزين',
                      'على هذا الجهاز فقط — لا يُرسل PIN أو تجزئته إلى أي خادم.',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              const AuthNoticeBanner(
                icon: SardIcons.info_outline_rounded,
                text: 'إن نسيت رمز PIN فلن نستطيع استعادته لك: الحل الوحيد هو مسح بيانات التطبيق من إعدادات الجهاز (وسيُحذف تقدّمك المحلي). احفظ رمزك في مكان آمن.',
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _scoreCard(BuildContext context, SardPalette p, SecurityScore score, Color scoreColor) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border, width: p.borderW),
        boxShadow: softShadow(p, strength: 0.5),
      ),
      child: Column(
        children: [
          Row(
            children: [
              SizedBox(
                width: 76,
                height: 76,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 76,
                      height: 76,
                      child: CircularProgressIndicator(
                        value: score.total / 100,
                        strokeWidth: 7,
                        color: scoreColor,
                        backgroundColor: p.border,
                      ),
                    ),
                    Text('${score.total}', style: context.ds(size: 22, color: scoreColor)),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('نقاط الأمان', style: context.ds(size: 17)),
                    const SizedBox(height: 2),
                    Text(
                      'مستواك: ${score.label} (${score.total} من 100)',
                      style: context.ts(color: p.textDim, size: 13, height: 1.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 6),
          for (final item in score.items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(
                children: [
                  SIcon(
                    item.met ? SardIcons.check_circle_rounded : SardIcons.info_outline_rounded,
                    size: 18,
                    color: item.met ? const Color(0xFF3FA66A) : p.textDim,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      item.label,
                      style: context.ts(size: 13.5, w: item.met ? FontWeight.w600 : FontWeight.w400),
                    ),
                  ),
                  Text(
                    '+${item.points}',
                    style: context.ts(size: 12.5, w: FontWeight.w700, color: item.met ? const Color(0xFF3FA66A) : p.textDim),
                  ),
                ],
              ),
            ),
          for (final item in score.items)
            if (!item.met && item.hint != null)
              Padding(
                padding: const EdgeInsetsDirectional.only(start: 26, bottom: 2),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(item.hint!, style: context.ts(size: 12, color: p.textDim, height: 1.4)),
                    ),
                  ],
                ),
              ),
        ],
      ),
    );
  }

  Widget _switchRow(
    BuildContext context,
    SardPalette p, {
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: context.ts(w: FontWeight.w600)),
              const SizedBox(height: 2),
              Text(subtitle, style: context.ts(color: p.textDim, size: 12.5)),
            ],
          ),
        ),
        Switch.adaptive(value: value, onChanged: onChanged, activeColor: p.accent),
      ],
    );
  }

  Widget _infoLine(BuildContext context, String label, String value) {
    final p = context.pal;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 150,
          child: Text(label, style: context.ts(color: p.textDim, size: 13)),
        ),
        Expanded(
          child: Text(value, style: context.ts(size: 13, w: FontWeight.w600)),
        ),
      ],
    );
  }

  String _formatDateTime(DateTime d) {
    final now = DateTime.now();
    final diff = now.difference(d);
    if (diff.inMinutes < 1) return 'الآن';
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
    if (diff.inHours < 24) return 'منذ ${diff.inHours} ساعة';
    if (diff.inDays < 7) return 'منذ ${diff.inDays} ${diff.inDays == 1 ? 'يوم' : 'أيام'}';
    return '${d.year}/${d.month}/${d.day}';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  بطاقة فحص أمني سريع
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة فحص سريع: ثلاث خطوات مقترحة حسب حالة الأمان الحالية.
class SecurityChecklistCard extends StatelessWidget {
  const SecurityChecklistCard({
    super.key,
    required this.pinStore,
    this.onSetupPin,
    this.onOpenSessions,
    this.onOpenGoals,
  });

  final PinStore pinStore;
  final VoidCallback? onSetupPin;
  final VoidCallback? onOpenSessions;
  final VoidCallback? onOpenGoals;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: pinStore,
      builder: (BuildContext context, Widget? child) {
        final steps = <({String title, String subtitle, bool done, VoidCallback? action})>[
          (
            title: 'فعّل قفل PIN',
            subtitle: pinStore.pinEnabled ? 'مفعّل — أحسنت' : 'يحمي التطبيق على جهازك',
            done: pinStore.pinEnabled,
            action: pinStore.pinEnabled ? null : onSetupPin,
          ),
          (
            title: 'راجع جلساتك النشطة',
            subtitle: 'تأكد أن كل الجلسات أجهزتك أنت',
            done: false,
            action: onOpenSessions,
          ),
          (
            title: 'أنشئ هدف قراءة',
            subtitle: 'هدف صغير يومي يحفّزك على المواظبة',
            done: false,
            action: onOpenGoals,
          ),
        ];
        if (steps.every((s) => s.done)) return const SizedBox.shrink();
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(0.9)),
            border: Border.all(color: p.border, width: p.borderW),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('خطوات مقترحة لك', style: context.ds(size: 16)),
              const SizedBox(height: 10),
              for (final step in steps)
                if (!step.done)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        const SIcon(SardIcons.check_circle_rounded, size: 18, color: Color(0xFF3FA66A)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(step.title, style: context.ts(w: FontWeight.w700, size: 13.5)),
                              Text(step.subtitle, style: context.ts(color: p.textDim, size: 12)),
                            ],
                          ),
                        ),
                        if (step.action != null)
                          TextButton(
                            onPressed: step.action,
                            child: const Text('فتح'),
                          ),
                      ],
                    ),
                  ),
            ],
          ),
        );
      },
    );
  }
}
