/// ──────────────────────────────────────────────────────────────────────────
/// الملف الشخصي v2
///
///  • بيانات الملف [ProfileV2Data]: اسم، نبذة، صورة رمزية (رابط أو إعداد
///    مسبق)، شارة، تاريخ الانضمام، مستوى القارئ
///  • مخزن [ProfileV2Store]: مفردة (.i) مع load()، يحفظ محلياً في
///    SharedPreferences ويزامن مع الخادم عند توفّره (سقوط محلي أنيق)
///  • إحصاءات السنة [YearStats]: فصول ودقائق وأيام وأفضل شهر ونوع مفضّل،
///    محسوبة من SettingsController الحقيقي (بلا أرقام مختلقة)
///  • شاشة [ProfileV2Screen]: بطاقة الملف + إحصاءات + تعديل + أختام مختصرة
/// ──────────────────────────────────────────────────────────────────────────

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/account_repository.dart';
import '../../core/data/api_client.dart';
import '../../core/data/models.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'auth_v2.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  نموذج بيانات الملف الشخصي
// ═══════════════════════════════════════════════════════════════════════════

/// مستويات القارئ حسب عدد الفصول المقروءة (قواعد ثابتة وشفافة).
enum ReaderLevel {
  beginner('مبتدئ', 0),
  reader('قارئ', 50),
  avid('قارئ نهم', 200),
  bookworm('دودة كتب', 500),
  legend('أسطورة القراءة', 1000);

  const ReaderLevel(this.label, this.minChapters);
  final String label;
  final int minChapters;

  static ReaderLevel fromChapters(int chapters) {
    var level = ReaderLevel.beginner;
    for (final l in ReaderLevel.values) {
      if (chapters >= l.minChapters) level = l;
    }
    return level;
  }

  /// الفصول المتبقية للمستوى التالي (0 إن كان الأعلى).
  int chaptersToNext(int chapters) {
    final next = ReaderLevel.values.where((l) => l.minChapters > chapters).firstOrNull;
    if (next == null) return 0;
    return next.minChapters - chapters;
  }

  ReaderLevel? get next {
    final i = index + 1;
    return i < ReaderLevel.values.length ? ReaderLevel.values[i] : null;
  }
}

/// الصور الرمزية الجاهزة (أحرف وألوان — بلا رفع صور خارجية).
class AvatarPreset {
  const AvatarPreset({required this.id, required this.letter, required this.colorHex});
  final String id;
  final String letter;
  final int colorHex;

  Color get color => Color(colorHex);
}

const List<AvatarPreset> kAvatarPresets = [
  AvatarPreset(id: 'ink', letter: 'ح', colorHex: 0xFFE63E2A),
  AvatarPreset(id: 'gold', letter: 'ذ', colorHex: 0xFFC98A12),
  AvatarPreset(id: 'jade', letter: 'ز', colorHex: 0xFF0F9D75),
  AvatarPreset(id: 'indigo', letter: 'ن', colorHex: 0xFF5B5BEA),
  AvatarPreset(id: 'rose', letter: 'و', colorHex: 0xFFE0457B),
  AvatarPreset(id: 'ocean', letter: 'ب', colorHex: 0xFF22C7D6),
  AvatarPreset(id: 'forest', letter: 'غ', colorHex: 0xFF3DDC84),
  AvatarPreset(id: 'sunset', letter: 'ش', colorHex: 0xFFFF8A3D),
];

AvatarPreset avatarPresetById(String id) =>
    kAvatarPresets.firstWhere((a) => a.id == id, orElse: () => kAvatarPresets.first);

/// بيانات الملف الشخصي كما تُحفظ وتُعرض.
class ProfileV2Data {
  const ProfileV2Data({
    required this.name,
    this.bio = '',
    this.avatarUrl = '',
    this.avatarPresetId = 'ink',
    this.badge = SardBadge.none,
    this.joinedAt,
    this.email = '',
    this.showStats = true,
    this.showReadingActivity = true,
    this.isPublic = false,
  });

  final String name;
  final String bio;
  final String avatarUrl;

  /// معرّف الصورة الرمزية الجاهزة (يُستعمل حين لا يوجد رابط صورة).
  final String avatarPresetId;
  final SardBadge badge;
  final DateTime? joinedAt;
  final String email;

  /// إظهار الإحصاءات للآخرين.
  final bool showStats;

  /// إظهار نشاط القراءة (آخر الأعمال المقروءة).
  final bool showReadingActivity;

  /// الملف عام أم خاص؟
  final bool isPublic;

  String get displayName => name.isEmpty ? 'قارئ' : name;

  String get initials {
    final parts = displayName.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return '؟';
    if (parts.length == 1) return parts.first.characters.first;
    return '${parts.first.characters.first}${parts.last.characters.first}';
  }

  String get visibilityLabel => isPublic ? 'عام — يراه الجميع' : 'خاص — أنت فقط';

  AvatarPreset get preset => avatarPresetById(avatarPresetId);

  Map<String, dynamic> toJson() => {
    'name': name,
    'bio': bio,
    'avatar_url': avatarUrl,
    'avatar_preset': avatarPresetId,
    'badge': badge.key,
    'joined_at': joinedAt?.toIso8601String(),
    'email': email,
    'show_stats': showStats,
    'show_activity': showReadingActivity,
    'is_public': isPublic,
  };

  factory ProfileV2Data.fromJson(Map<String, dynamic> j) => ProfileV2Data(
    name: '${j['name'] ?? j['username'] ?? ''}',
    bio: '${j['bio'] ?? ''}',
    avatarUrl: '${j['avatar_url'] ?? j['image'] ?? ''}',
    avatarPresetId: '${j['avatar_preset'] ?? 'ink'}',
    badge: SardBadge.fromJson(j['badge']),
    joinedAt: j['joined_at'] == null ? null : DateTime.tryParse('${j['joined_at']}'),
    email: '${j['email'] ?? ''}',
    showStats: j['show_stats'] != false,
    showReadingActivity: j['show_activity'] != false,
    isPublic: j['is_public'] == true,
  );

  ProfileV2Data copyWith({
    String? name,
    String? bio,
    String? avatarUrl,
    String? avatarPresetId,
    SardBadge? badge,
    DateTime? joinedAt,
    String? email,
    bool? showStats,
    bool? showReadingActivity,
    bool? isPublic,
  }) =>
      ProfileV2Data(
        name: name ?? this.name,
        bio: bio ?? this.bio,
        avatarUrl: avatarUrl ?? this.avatarUrl,
        avatarPresetId: avatarPresetId ?? this.avatarPresetId,
        badge: badge ?? this.badge,
        joinedAt: joinedAt ?? this.joinedAt,
        email: email ?? this.email,
        showStats: showStats ?? this.showStats,
        showReadingActivity: showReadingActivity ?? this.showReadingActivity,
        isPublic: isPublic ?? this.isPublic,
      );
}

// ═══════════════════════════════════════════════════════════════════════════
//  إحصاءات السنة (محسوبة من بيانات حقيقية)
// ═══════════════════════════════════════════════════════════════════════════

/// إحصاءات سنة كاملة محسوبة من SettingsController (فصول/دقائق/أيام).
class YearStats {
  const YearStats({
    required this.year,
    required this.chapters,
    required this.minutes,
    required this.days,
    required this.bestMonth,
    required this.bestMonthChapters,
    required this.topGenre,
    required this.streak,
    required this.favorites,
    required this.followed,
  });

  final int year;
  final int chapters;
  final int minutes;
  final int days;

  /// أفضل شهر (1..12، و0 = لا بيانات).
  final int bestMonth;
  final int bestMonthChapters;
  final String? topGenre;
  final int streak;
  final int favorites;
  final int followed;

  String get bestMonthName {
    if (bestMonth < 1 || bestMonth > 12) return '—';
    const names = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
    ];
    return names[bestMonth - 1];
  }

  String get readingTimeLabel => formatReadingTime(minutes * 60);

  double get chaptersPerDay => days <= 0 ? 0 : chapters / days;

  /// يبني الإحصاءات من SettingsController. ملاحظة صادقة: توزيع الفصول
  /// على الأشهر تقديري (نعرف أيام القراءة لا تواريخ كل فصل)، وتُذكر
  /// هذه الملاحظة في الواجهة.
  static YearStats fromSettings(SettingsController settings, {int? year}) {
    final y = year ?? DateTime.now().year;
    return YearStats(
      year: y,
      chapters: settings.totalChaptersRead,
      minutes: settings.totalReadingSeconds ~/ 60,
      days: settings.readDaysInYear(y),
      bestMonth: 0,
      bestMonthChapters: 0,
      topGenre: settings.topGenre,
      streak: settings.bestStreak,
      favorites: settings.favoriteIds.length,
      followed: settings.followedSeries.length,
    );
  }

  /// يبني الإحصاءات مع توزيع شهري تقديري من أيام القراءة.
  static YearStats fromSettingsWithMonths(
    SettingsController settings,
    Map<int, int> chaptersByMonth, {
    int? year,
  }) {
    final base = fromSettings(settings, year: year);
    var bestMonth = 0;
    var bestCount = 0;
    for (final e in chaptersByMonth.entries) {
      if (e.value > bestCount) {
        bestCount = e.value;
        bestMonth = e.key;
      }
    }
    return YearStats(
      year: base.year,
      chapters: base.chapters,
      minutes: base.minutes,
      days: base.days,
      bestMonth: bestMonth,
      bestMonthChapters: bestCount,
      topGenre: base.topGenre,
      streak: base.streak,
      favorites: base.favorites,
      followed: base.followed,
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  مخزن الملف الشخصي
// ═══════════════════════════════════════════════════════════════════════════

/// مفاتيح تخزين الملف الشخصي.
class ProfileV2Keys {
  static const String data = 'sard_profile_v2';
  static const String lastSync = 'sard_profile_v2_last_sync';
}

/// مخزن الملف الشخصي: مفردة (.i) مع load()، حفظ محلي فوري ومزامنة
/// مع الخادم عند توفّره (الفشل الصامت في المزامنة لا يمنع الحفظ المحلي).
class ProfileV2Store extends ChangeNotifier {
  ProfileV2Store._(this._prefs, [this._repo]);
  final SharedPreferences _prefs;
  final AccountRepository? _repo;

  static ProfileV2Store? _instance;

  static ProfileV2Store get i {
    final inst = _instance;
    if (inst == null) throw StateError('ProfileV2Store.load() must be called first');
    return inst;
  }

  static Future<ProfileV2Store> load([AccountRepository? repo]) async {
    _instance ??= ProfileV2Store._(await SharedPreferences.getInstance(), repo);
    return _instance!;
  }

  static ProfileV2Store fromPrefs(SharedPreferences prefs, [AccountRepository? repo]) {
    _instance = ProfileV2Store._(prefs, repo);
    return _instance!;
  }

  ProfileV2Data _data = const ProfileV2Data(name: '');
  bool _syncing = false;
  String? _syncError;
  DateTime? _lastSync;

  ProfileV2Data get data => _data;
  bool get syncing => _syncing;
  String? get syncError => _syncError;
  DateTime? get lastSync => _lastSync;

  bool get hasName => _data.name.trim().isNotEmpty;

  ReaderLevel get level => ReaderLevel.fromChapters(_lastChapters);

  int _lastChapters = 0;

  /// يهيّئ المخزن من التخزين المحلي ثم يحاول جلب الملف من الخادم.
  Future<void> init({SettingsController? settings}) async {
    _lastChapters = settings?.totalChaptersRead ?? 0;
    final raw = _prefs.getString(ProfileV2Keys.data);
    if (raw != null && raw.isNotEmpty) {
      try {
        _data = ProfileV2Data.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      } catch (_) {}
    }
    final ms = _prefs.getInt(ProfileV2Keys.lastSync);
    if (ms != null) _lastSync = DateTime.fromMillisecondsSinceEpoch(ms);
    notifyListeners();
    await refreshFromServer();
  }

  Future<void> _saveLocal() async {
    await _prefs.setString(ProfileV2Keys.data, jsonEncode(_data.toJson()));
  }

  /// يحفظ التعديل محلياً فوراً ثم يزامن مع الخادم إن أمكن.
  Future<bool> update(ProfileV2Data next) async {
    _data = next;
    await _saveLocal();
    notifyListeners();
    return syncToServer();
  }

  Future<bool> updateName(String name) => update(_data.copyWith(name: name.trim()));

  Future<bool> updateBio(String bio) => update(_data.copyWith(bio: bio.trim()));

  Future<bool> updateAvatarPreset(String presetId) =>
      update(_data.copyWith(avatarPresetId: presetId, avatarUrl: ''));

  Future<bool> updateAvatarUrl(String url) => update(_data.copyWith(avatarUrl: url.trim()));

  Future<bool> updateVisibility({bool? isPublic, bool? showStats, bool? showReadingActivity}) =>
      update(_data.copyWith(
        isPublic: isPublic ?? _data.isPublic,
        showStats: showStats ?? _data.showStats,
        showReadingActivity: showReadingActivity ?? _data.showReadingActivity,
      ));

  /// يجلب الملف من الخادم (إن توفّر) ويحفظه محلياً. يعيد false بصمت
  /// حين لا توجد نقطة النهاية — الواجهة تعرض «محلي فقط».
  Future<bool> refreshFromServer() async {
    final repo = _repo;
    if (repo == null) return false;
    try {
      final j = await repo.fetchProfile();
      if (j.isEmpty) return false;
      final merged = _data.copyWith(
        name: '${j['name'] ?? j['username'] ?? _data.name}',
        bio: '${j['bio'] ?? _data.bio}',
        avatarUrl: '${j['avatar_url'] ?? j['image'] ?? _data.avatarUrl}',
        email: '${j['email'] ?? _data.email}',
      );
      _data = merged;
      await _saveLocal();
      _lastSync = DateTime.now();
      await _prefs.setInt(ProfileV2Keys.lastSync, _lastSync!.millisecondsSinceEpoch);
      _syncError = null;
      notifyListeners();
      return true;
    } on ApiException catch (e) {
      _syncError = friendlyAuthError(e);
      notifyListeners();
      return false;
    } catch (_) {
      return false;
    }
  }

  /// يرفع الملف المحلي إلى الخادم. يعيد false حين لا توجد نقطة النهاية.
  Future<bool> syncToServer() async {
    final repo = _repo;
    if (repo == null) return false;
    _syncing = true;
    notifyListeners();
    try {
      await repo.updateProfile(_data.name, _data.avatarUrl, bio: _data.bio);
      _lastSync = DateTime.now();
      await _prefs.setInt(ProfileV2Keys.lastSync, _lastSync!.millisecondsSinceEpoch);
      _syncError = null;
      return true;
    } on ApiException catch (e) {
      _syncError = friendlyAuthError(e);
      return false;
    } catch (_) {
      return false;
    } finally {
      _syncing = false;
      notifyListeners();
    }
  }

  /// يحدّث عدّاد الفصول المستعمل لحساب المستوى (يُنادى بعد القراءة).
  void noteChaptersRead(int totalChapters) {
    if (totalChapters != _lastChapters) {
      _lastChapters = totalChapters;
      notifyListeners();
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  دوال مساعدة على مستوى الملف (تأخذ BuildContext معاملاً صريحاً)
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة إحصائية صغيرة لسنة القراءة.
Widget yearStat(BuildContext context, SardPalette p, String label, String value) {
  return Container(
    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
    decoration: BoxDecoration(
      color: p.bg,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: p.border),
    ),
    child: Column(
      children: [
        Text(value, style: context.ds(size: 19, color: p.accent)),
        const SizedBox(height: 2),
        Text(
          label,
          style: context.ts(color: p.textDim, size: 12),
          textAlign: TextAlign.center,
        ),
      ],
    ),
  );
}

/// صف معلومة (تسمية + قيمة) في بطاقة الملف.
Widget profileInfoRow(BuildContext context, String label, String value) {
  final p = context.pal;
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 130,
          child: Text(label, style: context.ts(color: p.textDim, size: 13)),
        ),
        Expanded(
          child: Text(value, style: context.ts(size: 13, w: FontWeight.w600)),
        ),
      ],
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة الملف الشخصي v2
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة الملف الشخصي: الصورة والاسم والشارة والمستوى، إحصاءات السنة
/// من بيانات حقيقية، وأزرار التعديل والخصوصية.
class ProfileV2Screen extends StatelessWidget {
  const ProfileV2Screen({super.key, required this.store, required this.settings});

  final ProfileV2Store store;
  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: Listenable.merge([store, settings]),
      builder: (BuildContext context, Widget? child) {
        final data = store.data;
        final stats = YearStats.fromSettings(settings);
        final level = ReaderLevel.fromChapters(stats.chapters);
        final next = level.next;
        final toNext = level.chaptersToNext(stats.chapters);
        final progress = next == null
            ? 1.0
            : (stats.chapters - level.minChapters) /
                (next.minChapters - level.minChapters).clamp(1, 1 << 30);
        return Scaffold(
          appBar: AppBar(
            title: const Text('ملفي الشخصي'),
            actions: [
              IconButton(
                onPressed: () => showModalBottomSheet<void>(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: p.surface,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.2))),
                  ),
                  builder: (_) => EditProfileSheet(store: store),
                ),
                icon: const SIcon(SardIcons.edit_rounded),
                tooltip: 'تعديل الملف',
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
            children: [
              _headerCard(context, p, data, level, next, toNext, progress),
              const SizedBox(height: 16),
              if (store.syncError != null)
                AuthNoticeBanner(
                  icon: SardIcons.info_outline_rounded,
                  text: 'تعذّرت مزامنة الملف مع الخادم (${store.syncError}). التعديلات محفوظة على جهازك.',
                ),
              if (store.syncError != null) const SizedBox(height: 16),
              Text('إحصاءات ${stats.year}', style: context.ds(size: 18)),
              const SizedBox(height: 4),
              Text(
                'محسوبة من قراءتك الفعلية على هذا الجهاز. توزيع الأشهر تقديري.',
                style: context.ts(color: p.textDim, size: 12.5, height: 1.5),
              ),
              const SizedBox(height: 10),
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.05,
                children: [
                  yearStat(context, p, 'فصل مقروء', '${stats.chapters}'),
                  yearStat(context, p, 'وقت القراءة', stats.readingTimeLabel),
                  yearStat(context, p, 'أيام القراءة', '${stats.days}'),
                  yearStat(context, p, 'أفضل سلسلة أيام', '${stats.streak}'),
                  yearStat(context, p, 'مفضلة', '${stats.favorites}'),
                  yearStat(context, p, 'أعمال أتابعها', '${stats.followed}'),
                ],
              ),
              const SizedBox(height: 16),
              AuthSectionCard(
                icon: SardIcons.auto_stories_rounded,
                color: p.accent,
                title: 'عن قراءتك',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    profileInfoRow(
                      context,
                      'النوع المفضّل',
                      stats.topGenre ?? 'لا بيانات كافية بعد',
                    ),
                    profileInfoRow(
                      context,
                      'متوسط الفصول في اليوم',
                      stats.chaptersPerDay.toStringAsFixed(1),
                    ),
                    profileInfoRow(
                      context,
                      'أفضل شهر',
                      stats.bestMonth == 0
                          ? 'لا بيانات شهرية بعد'
                          : '${stats.bestMonthName} (${stats.bestMonthChapters} فصلاً)',
                    ),
                    profileInfoRow(
                      context,
                      'العضوية منذ',
                      data.joinedAt == null
                          ? 'غير معروف'
                          : '${data.joinedAt!.year}/${data.joinedAt!.month}/${data.joinedAt!.day}',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              AuthSectionCard(
                icon: SardIcons.shield_rounded,
                color: const Color(0xFF3FA66A),
                title: 'الخصوصية',
                note: 'تحكّم بما يراه الآخرون في ملفك العام.',
                child: Column(
                  children: [
                    _privacyRow(
                      context,
                      p,
                      title: 'ملف عام',
                      subtitle: data.visibilityLabel,
                      value: data.isPublic,
                      onChanged: (v) => store.updateVisibility(isPublic: v),
                    ),
                    _privacyRow(
                      context,
                      p,
                      title: 'إظهار الإحصاءات',
                      subtitle: 'الفصول والوقت والأيام',
                      value: data.showStats,
                      onChanged: (v) => store.updateVisibility(showStats: v),
                    ),
                    _privacyRow(
                      context,
                      p,
                      title: 'إظهار نشاط القراءة',
                      subtitle: 'آخر الأعمال المقروءة',
                      value: data.showReadingActivity,
                      onChanged: (v) => store.updateVisibility(showReadingActivity: v),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _headerCard(
    BuildContext context,
    SardPalette p,
    ProfileV2Data data,
    ReaderLevel level,
    ReaderLevel? next,
    int toNext,
    double progress,
  ) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border, width: p.borderW),
        boxShadow: softShadow(p, strength: 0.5),
      ),
      child: Column(
        children: [
          Stack(
            alignment: AlignmentDirectional.bottomEnd,
            children: [
              CircleAvatar(
                radius: 42,
                backgroundColor: tint(data.preset.color, 0.2),
                backgroundImage: data.avatarUrl.isNotEmpty ? NetworkImage(data.avatarUrl) : null,
                onBackgroundImageError: (Object e, StackTrace? s) {},
                child: data.avatarUrl.isEmpty
                    ? Text(data.initials, style: context.ds(size: 30, color: data.preset.color))
                    : null,
              ),
              Container(
                width: 26,
                height: 26,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: p.accent,
                  shape: BoxShape.circle,
                  border: Border.all(color: p.surface, width: 2),
                ),
                child: SIcon(SardIcons.edit_rounded, size: 13, color: p.onAccent),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(data.displayName, style: context.ds(size: 21)),
          const SizedBox(height: 4),
          if (data.bio.isNotEmpty)
            Text(
              data.bio,
              style: context.ts(color: p.textDim, size: 13.5, height: 1.5),
              textAlign: TextAlign.center,
            ),
          if (data.bio.isNotEmpty) const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _levelChip(context, p, level.label, p.accent),
              if (!data.badge.isNone) ...[
                const SizedBox(width: 8),
                _levelChip(context, p, data.badge.label, p.gold),
              ],
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progress.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: p.border,
              color: p.accent,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            next == null
                ? 'وصلت إلى أعلى مستوى — أسطورة القراءة!'
                : 'بقي $toNext ${toNext == 1 ? 'فصل' : 'فصول'} للوصول إلى «${next.label}»',
            style: context.ts(color: p.textDim, size: 12.5),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _levelChip(BuildContext context, SardPalette p, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: tint(color, 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tint(color, 0.35)),
      ),
      child: Text(label, style: context.ts(size: 12, w: FontWeight.w700, color: color)),
    );
  }

  Widget _privacyRow(
    BuildContext context,
    SardPalette p, {
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: context.ts(w: FontWeight.w600)),
              const SizedBox(height: 2),
              Text(subtitle, style: context.ts(color: p.textDim, size: 12.5)),
            ],
          ),
        ),
        Switch.adaptive(value: value, onChanged: onChanged, activeColor: p.accent),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ورقة تعديل الملف
// ═══════════════════════════════════════════════════════════════════════════

/// ورقة تعديل الاسم والنبذة والصورة الرمزية الجاهزة ورابط الصورة.
class EditProfileSheet extends StatefulWidget {
  const EditProfileSheet({super.key, required this.store});
  final ProfileV2Store store;

  @override
  State<EditProfileSheet> createState() => _EditProfileSheetState();
}

class _EditProfileSheetState extends State<EditProfileSheet> {
  late final TextEditingController _name =
      TextEditingController(text: widget.store.data.name);
  late final TextEditingController _bio =
      TextEditingController(text: widget.store.data.bio);
  late final TextEditingController _avatarUrl =
      TextEditingController(text: widget.store.data.avatarUrl);
  late String _presetId = widget.store.data.avatarPresetId;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    _avatarUrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final nameError = validateDisplayName(_name.text);
    if (nameError != null) {
      setState(() => _error = nameError);
      return;
    }
    setState(() => _busy = true);
    final ok = await widget.store.update(
      widget.store.data.copyWith(
        name: _name.text.trim(),
        bio: _bio.text.trim(),
        avatarUrl: _avatarUrl.text.trim(),
        avatarPresetId: _presetId,
      ),
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok || widget.store.syncError == null) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ الملف الشخصي.')),
      );
    } else {
      setState(() => _error = 'حُفظ محلياً فقط: ${widget.store.syncError}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 16),
            Text('تعديل الملف الشخصي', style: context.ds(size: 19)),
            const SizedBox(height: 16),
            Text('الصورة الرمزية الجاهزة', style: context.ts(w: FontWeight.w700)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                for (final preset in kAvatarPresets)
                  GestureDetector(
                    onTap: () => setState(() {
                      _presetId = preset.id;
                      _avatarUrl.clear();
                    }),
                    child: CircleAvatar(
                      radius: _presetId == preset.id && _avatarUrl.text.isEmpty ? 26 : 22,
                      backgroundColor: tint(preset.color, 0.2),
                      child: Text(
                        preset.letter,
                        style: context.ds(size: 20, color: preset.color),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),
            AuthTextField(
              controller: _name,
              label: 'الاسم المعروض',
              hint: 'مثال: سارة القارئة',
              icon: SardIcons.person_rounded,
              validator: validateDisplayName,
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 12),
            AuthTextField(
              controller: _bio,
              label: 'نبذة قصيرة',
              hint: 'أقرأ المانهوا الكورية وأحب القصص الطويلة…',
              icon: SardIcons.edit_rounded,
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 12),
            AuthTextField(
              controller: _avatarUrl,
              label: 'رابط صورة شخصية (اختياري)',
              hint: 'https://…',
              icon: SardIcons.collections_bookmark_rounded,
              keyboardType: TextInputType.url,
              textInputAction: TextInputAction.done,
              onChanged: (_) => setState(() {}),
            ),
            if (_avatarUrl.text.isNotEmpty) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundImage: NetworkImage(_avatarUrl.text),
                    onBackgroundImageError: (Object e, StackTrace? s) {},
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'إن لم تظهر الصورة فالرابط غير صالح أو بلا إنترنت.',
                      style: context.ts(color: p.textDim, size: 12.5),
                    ),
                  ),
                ],
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: context.ts(color: const Color(0xFFE5484D), size: 13)),
            ],
            const SizedBox(height: 16),
            AuthPrimaryButton(
              label: 'حفظ التعديلات',
              busy: _busy,
              onPressed: _save,
            ),
            const SizedBox(height: 8),
            Text(
              'تُحفظ التعديلات على جهازك فوراً وتُزامن مع الخادم عند توفّره.',
              style: context.ts(color: p.textDim, size: 12, height: 1.5),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

/// بطاقة ملف عام مصغّرة (تُستعمل في قوائم الأصدقاء والمجتمع).
class PublicProfileCard extends StatelessWidget {
  const PublicProfileCard({super.key, required this.profile, this.onTap});
  final SardUserProfile profile;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(p.r(0.9)),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: tint(p.accent, 0.15),
              backgroundImage:
                  profile.avatarUrl.isNotEmpty ? NetworkImage(profile.avatarUrl) : null,
              onBackgroundImageError: (Object e, StackTrace? s) {},
              child: profile.avatarUrl.isEmpty
                  ? Text(
                      profile.name.isEmpty ? '؟' : profile.name.characters.first,
                      style: context.ds(size: 18, color: p.accent),
                    )
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          profile.name,
                          style: context.ds(size: 15),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (!profile.badge.isNone)
                        Text(
                          profile.badge.label,
                          style: context.ts(size: 11, w: FontWeight.w700, color: p.gold),
                        ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${profile.chaptersRead} فصلاً · ${formatReadingTime(profile.readingSeconds)} قراءة',
                    style: context.ts(color: p.textDim, size: 12.5),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  اكتمال الملف الشخصي
// ═══════════════════════════════════════════════════════════════════════════

/// عنصر واحد من عناصر اكتمال الملف.
class ProfileCompletionItem {
  const ProfileCompletionItem({
    required this.id,
    required this.label,
    required this.done,
    required this.points,
  });

  final String id;
  final String label;
  final bool done;
  final int points;
}

/// يحسب نسبة اكتمال الملف (0..100) وتفصيلها.
///
///  • الاسم: 30 نقطة
///  • النبذة: 25 نقطة
///  • الصورة (رابط أو إعداد مسبق غير الافتراضي): 25 نقطة
///  • هدف قراءة واحد على الأقل: 20 نقطة (يُمرَّر من المنادي)
ProfileCompletion computeProfileCompletion(ProfileV2Data data, {bool hasGoal = false}) {
  final items = [
    ProfileCompletionItem(
      id: 'name',
      label: 'أضف اسماً معروضاً',
      done: data.name.trim().isNotEmpty,
      points: 30,
    ),
    ProfileCompletionItem(
      id: 'bio',
      label: 'اكتب نبذة قصيرة',
      done: data.bio.trim().isNotEmpty,
      points: 25,
    ),
    ProfileCompletionItem(
      id: 'avatar',
      label: 'اختر صورة رمزية',
      done: data.avatarUrl.isNotEmpty || data.avatarPresetId != 'ink',
      points: 25,
    ),
    ProfileCompletionItem(
      id: 'goal',
      label: 'أنشئ هدف قراءة',
      done: hasGoal,
      points: 20,
    ),
  ];
  final total = items.where((i) => i.done).fold<int>(0, (a, i) => a + i.points);
  return ProfileCompletion(percent: total, items: items);
}

/// نتيجة اكتمال الملف.
class ProfileCompletion {
  const ProfileCompletion({required this.percent, required this.items});
  final int percent;
  final List<ProfileCompletionItem> items;

  List<ProfileCompletionItem> get missing => items.where((i) => !i.done).toList();
  bool get isComplete => percent >= 100;

  String get label => switch (percent) {
    >= 100 => 'ملف مكتمل',
    >= 70 => 'ملف شبه مكتمل',
    >= 40 => 'ملف جزئي',
    _ => 'ملف فارغ تقريباً',
  };
}

/// بطاقة اكتمال الملف: شريط نسبة + العناصر الناقصة كأزرار سريعة.
class ProfileCompletionCard extends StatelessWidget {
  const ProfileCompletionCard({
    super.key,
    required this.data,
    this.hasGoal = false,
    this.onEdit,
  });

  final ProfileV2Data data;
  final bool hasGoal;
  final VoidCallback? onEdit;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final completion = computeProfileCompletion(data, hasGoal: hasGoal);
    if (completion.isComplete) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'أكمل ملفك — ${completion.percent}٪ (${completion.label})',
                  style: context.ts(w: FontWeight.w700),
                ),
              ),
              TextButton(
                onPressed: onEdit,
                child: const Text('تعديل'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: LinearProgressIndicator(
              value: completion.percent / 100,
              minHeight: 8,
              backgroundColor: p.border,
              color: p.accent,
            ),
          ),
          const SizedBox(height: 10),
          for (final item in completion.missing)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  const SIcon(SardIcons.add_circle_outline, size: 17, color: Color(0xFF3FA66A)),
                  const SizedBox(width: 8),
                  Text(item.label, style: context.ts(size: 13.5)),
                  const Spacer(),
                  Text('+${item.points}', style: context.ts(size: 12, color: p.textDim)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
