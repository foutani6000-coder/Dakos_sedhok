/// ──────────────────────────────────────────────────────────────────────────
/// الحساب الاحترافي v2 — منطق الدخول والتسجيل
///
///  • تحقق عربي من البريد وكلمة المرور (قواعدي بالكامل، بلا أي ذكاء اصطناعي)
///  • مقياس قوة كلمة المرور من 0 إلى 4 مع نصائح عربية عملية
///  • رسائل خطأ ودّية بالعربية عبر [friendlyAuthError]
///  • حارس محاولات [AttemptGuard]: قفل مؤقت بعد محاولات فاشلة متتالية
///  • خدمة [AuthV2Service]: دخول/تسجيل/استعادة عبر AccountRepository، مع
///    سقوط محلي أنيق حين لا توجد نقاط نهاية /auth/* على الخادم (وضع تجريبي
///    محلي يُعلن عن نفسه في الواجهة ولا يدّعي اتصالاً بالخادم)
/// ──────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/account_repository.dart';
import '../../core/data/api_client.dart';
import '../../core/storage/auth_store.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  التحقق من البريد وكلمة المرور
// ═══════════════════════════════════════════════════════════════════════════

/// تعبير بريدي عملي: يرفض الفراغات ويشترط @ ونطاقاً بنقطة واحدة على الأقل.
final RegExp _emailPattern = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]{2,}$');

/// هل البريد صالح شكلاً؟ (لا يتحقق من وجود الصندوق، فقط من الصيغة)
bool isValidEmail(String email) => _emailPattern.hasMatch(email.trim());

/// رسالة خطأ عربية للبريد، أو null إن كان صالحاً.
String? validateEmail(String? value) {
  final v = (value ?? '').trim();
  if (v.isEmpty) return 'اكتب بريدك الإلكتروني.';
  if (v.length > 254) return 'البريد طويل جداً.';
  if (!isValidEmail(v)) return 'صيغة البريد غير صحيحة. مثال: name@example.com';
  return null;
}

/// أقل طول مقبول لكلمة المرور.
const int kMinPasswordLength = 8;

/// رسالة خطأ عربية لكلمة المرور، أو null إن كانت مقبولة.
String? validatePassword(String? value, {bool strict = false}) {
  final v = value ?? '';
  if (v.isEmpty) return 'اكتب كلمة المرور.';
  if (v.length < kMinPasswordLength) return 'كلمة المرور 8 أحرف على الأقل.';
  if (v.length > 128) return 'كلمة المرور طويلة جداً (128 حرفاً كحد أقصى).';
  if (strict) {
    if (!RegExp(r'[0-9]').hasMatch(v)) return 'أضف رقماً واحداً على الأقل.';
    if (!RegExp(r'[A-Za-z]').hasMatch(v)) return 'أضف حرفاً واحداً على الأقل.';
  }
  return null;
}

/// هل الاسمان متطابقان؟ (للتسجيل: الاسم المعروض)
String? validateDisplayName(String? value) {
  final v = (value ?? '').trim();
  if (v.isEmpty) return 'اكتب اسماً يُعرض للقرّاء.';
  if (v.length < 2) return 'الاسم قصير جداً (حرفان على الأقل).';
  if (v.length > 40) return 'الاسم طويل جداً (40 حرفاً كحد أقصى).';
  return null;
}

/// رسالة خطأ عربية لتأكيد كلمة المرور.
String? validatePasswordConfirmation(String? value, String password) {
  if ((value ?? '').isEmpty) return 'أعد كتابة كلمة المرور للتأكيد.';
  if (value != password) return 'كلمتا المرور غير متطابقتين.';
  return null;
}

/// هل البريد من نطاق عام معروف؟ (تلميح ودود فقط، وليس قاعدة رفض)
bool isCommonEmailDomain(String email) {
  const domains = {
    'gmail.com', 'outlook.com', 'hotmail.com', 'yahoo.com', 'icloud.com',
    'proton.me', 'protonmail.com', 'live.com', 'msn.com', 'aol.com',
  };
  final at = email.trim().lastIndexOf('@');
  if (at < 0) return false;
  return domains.contains(email.trim().substring(at + 1).toLowerCase());
}

/// اقتراح تصحيح لأخطاء كتابية شائعة في النطاقات (قواعدي: جدول ثابت).
String? suggestEmailFix(String email) {
  const fixes = {
    'gmial.com': 'gmail.com',
    'gamil.com': 'gmail.com',
    'gmai.com': 'gmail.com',
    'hotmal.com': 'hotmail.com',
    'hotmial.com': 'hotmail.com',
    'yaho.com': 'yahoo.com',
    'outlok.com': 'outlook.com',
    'iclod.com': 'icloud.com',
  };
  final at = email.trim().lastIndexOf('@');
  if (at < 0) return null;
  final domain = email.trim().substring(at + 1).toLowerCase();
  final fixed = fixes[domain];
  if (fixed == null) return null;
  return '${email.trim().substring(0, at + 1)}$fixed';
}

// ═══════════════════════════════════════════════════════════════════════════
//  قوة كلمة المرور
// ═══════════════════════════════════════════════════════════════════════════

/// مستوى قوة كلمة المرور: 0 ضعيفة جداً … 4 قوية جداً.
enum PasswordStrength { veryWeak, weak, fair, strong, veryStrong }

extension PasswordStrengthX on PasswordStrength {
  /// 0..4
  int get score => index;

  /// تسمية عربية قصيرة.
  String get label => switch (this) {
    PasswordStrength.veryWeak => 'ضعيفة جداً',
    PasswordStrength.weak => 'ضعيفة',
    PasswordStrength.fair => 'مقبولة',
    PasswordStrength.strong => 'قوية',
    PasswordStrength.veryStrong => 'قوية جداً',
  };

  /// لون المؤشر.
  Color color(SardPalette p) => switch (this) {
    PasswordStrength.veryWeak => const Color(0xFFE5484D),
    PasswordStrength.weak => const Color(0xFFF08C1A),
    PasswordStrength.fair => const Color(0xFFE9B44C),
    PasswordStrength.strong => const Color(0xFF3FA66A),
    PasswordStrength.veryStrong => const Color(0xFF2E9E6B),
  };

  /// نسبة الشريط 0..1
  double get fraction => (index + 1) / 5;
}

/// نتيجة تحليل كلمة المرور: المستوى + نقاط الضعف + اقتراحات.
class PasswordAnalysis {
  const PasswordAnalysis({
    required this.strength,
    required this.length,
    required this.hasLower,
    required this.hasUpper,
    required this.hasDigit,
    required this.hasSymbol,
    required this.hasSequence,
    required this.isCommon,
    required this.suggestions,
  });

  final PasswordStrength strength;
  final int length;
  final bool hasLower;
  final bool hasUpper;
  final bool hasDigit;
  final bool hasSymbol;

  /// تحتوي تسلسلاً سهلاً مثل 123 أو abc أو qwerty
  final bool hasSequence;

  /// من قائمة كلمات المرور الشائعة
  final bool isCommon;
  final List<String> suggestions;
}

/// كلمات مرور شائعة جداً (قائمة قصيرة ثابتة للتحذير فقط).
const List<String> _commonPasswords = [
  '12345678', 'password', '123456789', 'qwerty123', '11111111', '123123123',
  'password1', '1234567890', '00000000', 'aaaaaaaa', 'abc12345', 'admin123',
  'letmein1', 'welcome1', 'monkey12', 'dragon12', 'sunshine1', 'football',
];

/// هل تحتوي كلمة المرور تسلسلاً من ثلاثة أحرف/أرقام متتابعة؟
bool _hasSequence(String v) {
  const seqs = [
    '012', '123', '234', '345', '456', '567', '678', '789', '890',
    'abc', 'bcd', 'cde', 'def', 'xyz', 'qwe', 'asd', 'zxc',
  ];
  final lower = v.toLowerCase();
  for (final s in seqs) {
    if (lower.contains(s)) return true;
  }
  return false;
}

/// يحلّل كلمة المرور قواعدياً ويعيد المستوى والاقتراحات.
PasswordAnalysis evaluatePasswordStrength(String password) {
  final v = password;
  final hasLower = RegExp(r'[a-z]').hasMatch(v);
  final hasUpper = RegExp(r'[A-Z]').hasMatch(v);
  final hasDigit = RegExp(r'[0-9]').hasMatch(v);
  final hasSymbol = RegExp(r'[^A-Za-z0-9]').hasMatch(v);
  final hasSequence = _hasSequence(v);
  final isCommon = _commonPasswords.contains(v.toLowerCase());

  var score = 0;
  if (v.length >= 8) score++;
  if (v.length >= 12) score++;
  if (hasLower && hasUpper) score++;
  if (hasDigit) score++;
  if (hasSymbol) score++;
  if (hasSequence || isCommon) score -= 2;
  if (v.length < 8) score = 0;

  final strength = switch (score.clamp(0, 5)) {
    0 => PasswordStrength.veryWeak,
    1 => PasswordStrength.weak,
    2 => PasswordStrength.fair,
    3 => PasswordStrength.strong,
    _ => PasswordStrength.veryStrong,
  };

  final suggestions = <String>[];
  if (v.length < 12) suggestions.add('اجعلها 12 حرفاً أو أكثر.');
  if (!hasUpper) suggestions.add('أضف حرفاً كبيراً واحداً على الأقل.');
  if (!hasDigit) suggestions.add('أضف رقماً واحداً على الأقل.');
  if (!hasSymbol) suggestions.add('أضف رمزاً مثل ! أو @ أو #.');
  if (hasSequence) suggestions.add('تجنّب التسلسلات السهلة مثل 123 أو abc.');
  if (isCommon) suggestions.add('كلمة المرور هذه شائعة جداً، اختر غيرها.');

  return PasswordAnalysis(
    strength: strength,
    length: v.length,
    hasLower: hasLower,
    hasUpper: hasUpper,
    hasDigit: hasDigit,
    hasSymbol: hasSymbol,
    hasSequence: hasSequence,
    isCommon: isCommon,
    suggestions: suggestions,
  );
}

/// هل كلمة المرور قوية بما يكفي للتسجيل؟ (مقبولة فأعلى)
bool isPasswordStrongEnough(String password) =>
    evaluatePasswordStrength(password).strength.index >= PasswordStrength.fair.index;

// ═══════════════════════════════════════════════════════════════════════════
//  رسائل الخطأ الودّية
// ═══════════════════════════════════════════════════════════════════════════

/// يحوّل أي خطأ (خاصة [ApiException]) إلى رسالة عربية ودّية قابلة للعرض.
///
/// ملاحظة: رسالة 401 هنا سياقها «بيانات دخول غير صحيحة» لأنها تظهر في شاشات
/// الدخول؛ أما انتهاء الجلسة فيُعالج برسالة مختلفة في مدير الجلسات.
String friendlyAuthError(Object e) {
  if (e is ApiException) {
    return switch (e.failure) {
      ApiFailure.offline => 'لا يوجد اتصال بالإنترنت. تحقق من الشبكة وحاول مجدداً.',
      ApiFailure.timeout => 'استغرق الاتصال وقتاً طويلاً. حاول مرة أخرى.',
      ApiFailure.unauthorized => 'بيانات الدخول غير صحيحة. تحقق من البريد وكلمة المرور.',
      ApiFailure.forbidden => 'ليست لديك صلاحية لتنفيذ هذا الإجراء.',
      ApiFailure.notFound => 'لم نعثر على هذا الحساب. تحقق من البريد أو أنشئ حساباً جديداً.',
      ApiFailure.server => 'الخادم يواجه مشكلة مؤقتة. حاول لاحقاً.',
      ApiFailure.invalidResponse => 'وصل رد غير صالح من الخادم. حاول لاحقاً.',
      ApiFailure.unknown => e.message.isEmpty ? 'حدث خطأ غير متوقع. حاول مجدداً.' : e.message,
    };
  }
  if (e is TimeoutException) return 'استغرق الاتصال وقتاً طويلاً. حاول مرة أخرى.';
  if (e is FormatException) return 'وصل رد غير صالح من الخادم. حاول لاحقاً.';
  final text = '$e'.trim();
  if (text.isEmpty || text == 'Instance of \'ApiException\'') {
    return 'حدث خطأ غير متوقع. حاول مجدداً.';
  }
  return text;
}

/// رسالة ودّية لخطأ الشبكة فقط (تُستعمل في الشاشات التي تفرّق بين الأخطاء).
String friendlyNetworkError(Object e) {
  if (e is ApiException && e.failure == ApiFailure.offline) {
    return 'لا يوجد اتصال بالإنترنت. تحقق من الشبكة وحاول مجدداً.';
  }
  return friendlyAuthError(e);
}

// ═══════════════════════════════════════════════════════════════════════════
//  حارس المحاولات
// ═══════════════════════════════════════════════════════════════════════════

/// يحمي الدخول من التخمين: بعد [maxAttempts] محاولات فاشلة متتالية يقفل
/// الدخول لمدة [lockout]، ثم يعيد العدّاد تلقائياً.
class AttemptGuard {
  AttemptGuard({this.maxAttempts = 5, this.lockout = const Duration(minutes: 5)});

  final int maxAttempts;
  final Duration lockout;

  int _failures = 0;
  DateTime? _lockedUntil;

  int get failures => _failures;
  int get remainingAttempts => (maxAttempts - _failures).clamp(0, maxAttempts);

  bool get isLocked {
    final until = _lockedUntil;
    if (until == null) return false;
    if (DateTime.now().isAfter(until)) {
      _lockedUntil = null;
      _failures = 0;
      return false;
    }
    return true;
  }

  /// الثواني المتبقية للقفل (0 إن لم يكن مقفلاً).
  int get remainingSeconds {
    final until = _lockedUntil;
    if (until == null) return 0;
    final d = until.difference(DateTime.now()).inSeconds;
    return d > 0 ? d : 0;
  }

  /// نص عربي لحالة القفل يُعرض للمستخدم.
  String get lockMessage {
    final s = remainingSeconds;
    if (s <= 0) return '';
    final m = (s / 60).ceil();
    return 'محاولات كثيرة فاشلة. أعد المحاولة بعد $m ${m == 1 ? 'دقيقة' : 'دقائق'}.';
  }

  /// تُنادى عند فشل محاولة دخول.
  void recordFailure() {
    _failures++;
    if (_failures >= maxAttempts) {
      _lockedUntil = DateTime.now().add(lockout);
    }
  }

  /// تُنادى عند نجاح الدخول: تصفّر العدّاد والقفل.
  void recordSuccess() {
    _failures = 0;
    _lockedUntil = null;
  }

  /// تصفير يدوي (بعد استعادة كلمة المرور مثلاً).
  void reset() {
    _failures = 0;
    _lockedUntil = null;
  }

  Map<String, dynamic> toJson() => {
    'failures': _failures,
    'locked_until': _lockedUntil?.millisecondsSinceEpoch,
  };

  factory AttemptGuard.fromJson(Map<String, dynamic> j) {
    final g = AttemptGuard();
    g._failures = (j['failures'] as num?)?.toInt() ?? 0;
    final ms = (j['locked_until'] as num?)?.toInt();
    if (ms != null) g._lockedUntil = DateTime.fromMillisecondsSinceEpoch(ms);
    return g;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  نموذج المستخدم المسجَّل
// ═══════════════════════════════════════════════════════════════════════════

/// بيانات المستخدم كما يعرضها التطبيق (مصدرها الخادم أو الملف المحلي).
class AuthUser {
  const AuthUser({
    required this.id,
    required this.name,
    required this.email,
    this.avatarUrl = '',
    this.bio = '',
    this.badge = '',
    this.isLocalDemo = false,
  });

  final String id;
  final String name;
  final String email;
  final String avatarUrl;
  final String bio;

  /// شارة التوثيق النصية كما يرسلها الخادم (purple/blue/yellow أو فارغ).
  final String badge;

  /// true حين تكون الجلسة محلية تجريبية (لا يوجد خادم/حساب حقيقي).
  final bool isLocalDemo;

  String get displayName => name.isEmpty ? 'قارئ' : name;

  String get initials {
    final parts = displayName.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return '؟';
    if (parts.length == 1) return parts.first.characters.first;
    return '${parts.first.characters.first}${parts.last.characters.first}';
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'email': email,
    'avatar_url': avatarUrl,
    'bio': bio,
    'badge': badge,
    'local_demo': isLocalDemo,
  };

  factory AuthUser.fromJson(Map<String, dynamic> j) => AuthUser(
    id: '${j['id'] ?? ''}',
    name: '${j['name'] ?? j['username'] ?? ''}',
    email: '${j['email'] ?? ''}',
    avatarUrl: '${j['avatar_url'] ?? j['image'] ?? ''}',
    bio: '${j['bio'] ?? ''}',
    badge: '${j['badge'] ?? ''}',
    isLocalDemo: j['local_demo'] == true,
  );

  AuthUser copyWith({String? name, String? avatarUrl, String? bio}) => AuthUser(
    id: id,
    name: name ?? this.name,
    email: email,
    avatarUrl: avatarUrl ?? this.avatarUrl,
    bio: bio ?? this.bio,
    badge: badge,
    isLocalDemo: isLocalDemo,
  );
}

/// حالة الدخول الحالية كما يراها التطبيق.
enum AuthState { unknown, signedOut, guest, signedIn, localDemo }

extension AuthStateX on AuthState {
  String get label => switch (this) {
    AuthState.unknown => 'جارٍ التحقق…',
    AuthState.signedOut => 'غير مسجَّل',
    AuthState.guest => 'ضيف',
    AuthState.signedIn => 'مسجَّل',
    AuthState.localDemo => 'وضع تجريبي محلي',
  };
}

// ═══════════════════════════════════════════════════════════════════════════
//  خدمة الدخول — مع سقوط محلي أنيق
// ═══════════════════════════════════════════════════════════════════════════

/// نتيجة عملية دخول/تسجيل.
class AuthResult {
  const AuthResult({required this.user, required this.usedLocalFallback});
  final AuthUser user;

  /// true حين تم الدخول محلياً لأن نقاط نهاية /auth/* غير موجودة على الخادم.
  final bool usedLocalFallback;
}

/// خدمة الدخول v2.
///
/// تحاول أولاً نقاط نهاية الخادم عبر [AccountRepository]؛ وإن ردّ الخادم
/// 404 (نقطة النهاية غير موجودة) أو 500 متكرراً، تسقط إلى جلسة محلية
/// تجريبية تُحفظ في [AuthStore] وتُعلن عن نفسها بوضوح في الواجهة.
/// لا تخترع نجاحاً صامتاً: [AuthResult.usedLocalFallback] يخبر الواجهة.
class AuthV2Service {
  AuthV2Service(this._repo);
  final AccountRepository _repo;

  static const String _localTokenPrefix = 'local-demo-';

  Future<AuthResult> signIn(String email, String password) async {
    try {
      final user = await _repo.signIn(email.trim(), password);
      return AuthResult(
        user: AuthUser.fromJson(user).copyWith(),
        usedLocalFallback: false,
      );
    } on ApiException catch (e) {
      if (_isMissingEndpoint(e)) {
        return AuthResult(user: await _localDemoSession(email), usedLocalFallback: true);
      }
      rethrow;
    }
  }

  Future<AuthResult> signUp(String name, String email, String password) async {
    try {
      final user = await _repo.signUp(name.trim(), email.trim(), password);
      return AuthResult(user: AuthUser.fromJson(user), usedLocalFallback: false);
    } on ApiException catch (e) {
      if (_isMissingEndpoint(e)) {
        return AuthResult(
          user: await _localDemoSession(email, displayName: name.trim()),
          usedLocalFallback: true,
        );
      }
      rethrow;
    }
  }

  /// استعادة كلمة المرور: إن لم توجد نقطة النهاية، نرشد المستخدم لطريقة
  /// محلية (إعادة تعيين PIN أو إنشاء حساب محلي جديد) بدل الفشل الصامت.
  Future<bool> forgotPassword(String email) async {
    try {
      await _repo.forgotPassword(email.trim());
      return true;
    } on ApiException catch (e) {
      if (_isMissingEndpoint(e)) return false;
      rethrow;
    }
  }

  Future<void> signOut() => _repo.signOut();

  Future<bool> get signedIn async => _repo.signedIn;

  Future<AuthUser?> get currentUser async {
    final raw = await AuthStore.userJson();
    if (raw == null || raw.isEmpty) return null;
    try {
      return AuthUser.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
    } catch (_) {
      return null;
    }
  }

  /// نقطة نهاية مفقودة = 404 أو خطأ خادم عام من دون رسالة واضحة.
  bool _isMissingEndpoint(ApiException e) =>
      e.failure == ApiFailure.notFound || e.failure == ApiFailure.server;

  Future<AuthUser> _localDemoSession(String email, {String? displayName}) async {
    final name = (displayName == null || displayName.isEmpty)
        ? email.trim().split('@').first
        : displayName;
    final user = AuthUser(
      id: 'local_${email.trim().hashCode.abs()}',
      name: name,
      email: email.trim(),
      isLocalDemo: true,
    );
    await AuthStore.save(
      '$_localTokenPrefix${DateTime.now().millisecondsSinceEpoch}',
      userJson: jsonEncode(user.toJson()),
    );
    return user;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  مخزن حالة الدخول (ChangeNotifier)
// ═══════════════════════════════════════════════════════════════════════════

/// مخزن الدخول العام. يُوضع في شجرة Provider فوق MaterialApp.
/// يستمع للجلسة ويعيد بناء الواجهات عند تغيّر حالة الدخول.
class AuthV2Store extends ChangeNotifier {
  AuthV2Store(this._service);
  final AuthV2Service _service;

  AuthState _state = AuthState.unknown;
  AuthUser? _user;
  String? _lastError;
  bool _busy = false;

  /// حارس المحاولات الخاص بشاشة الدخول.
  final AttemptGuard guard = AttemptGuard();

  AuthState get state => _state;
  AuthUser? get user => _user;
  String? get lastError => _lastError;
  bool get busy => _busy;
  bool get signedIn => _state == AuthState.signedIn || _state == AuthState.localDemo;
  bool get isLocalDemo => _state == AuthState.localDemo;

  /// يهيّئ الحالة من التخزين الآمن عند الإقلاع.
  Future<void> load() async {
    try {
      final u = await _service.currentUser;
      if (u == null) {
        _state = AuthState.signedOut;
      } else {
        _user = u;
        _state = u.isLocalDemo ? AuthState.localDemo : AuthState.signedIn;
      }
    } catch (_) {
      _state = AuthState.signedOut;
    }
    notifyListeners();
  }

  Future<bool> signIn(String email, String password) async {
    if (guard.isLocked) {
      _lastError = guard.lockMessage;
      notifyListeners();
      return false;
    }
    _busy = true;
    _lastError = null;
    notifyListeners();
    try {
      final r = await _service.signIn(email, password);
      _user = r.user;
      _state = r.usedLocalFallback ? AuthState.localDemo : AuthState.signedIn;
      guard.recordSuccess();
      return true;
    } on ApiException catch (e) {
      guard.recordFailure();
      _lastError = guard.isLocked ? guard.lockMessage : friendlyAuthError(e);
      return false;
    } catch (e) {
      guard.recordFailure();
      _lastError = friendlyAuthError(e);
      return false;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  Future<bool> signUp(String name, String email, String password) async {
    _busy = true;
    _lastError = null;
    notifyListeners();
    try {
      final r = await _service.signUp(name, email, password);
      _user = r.user;
      _state = r.usedLocalFallback ? AuthState.localDemo : AuthState.signedIn;
      return true;
    } on ApiException catch (e) {
      _lastError = friendlyAuthError(e);
      return false;
    } catch (e) {
      _lastError = friendlyAuthError(e);
      return false;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    await _service.signOut();
    _user = null;
    _state = AuthState.signedOut;
    _lastError = null;
    notifyListeners();
  }

  /// يدخل وضع الضيف (بلا حساب) — حدوده في GuestModeController.
  void enterGuest() {
    _user = null;
    _state = AuthState.guest;
    notifyListeners();
  }

  void clearError() {
    _lastError = null;
    notifyListeners();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  أدوات واجهة مشتركة
// ═══════════════════════════════════════════════════════════════════════════

/// بطاقة قسم بعنوان وأيقونة (تُستعمل في كل شاشات الحساب).
class AuthSectionCard extends StatelessWidget {
  const AuthSectionCard({
    super.key,
    required this.icon,
    required this.color,
    required this.title,
    this.note,
    required this.child,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String? note;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border, width: p.borderW),
        boxShadow: softShadow(p, strength: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(color, 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SIcon(icon, size: 20, color: color),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(title, style: context.ds(size: 16)),
              ),
            ],
          ),
          if (note != null) ...[
            const SizedBox(height: 8),
            Text(note!, style: context.ts(color: p.textDim, size: 13, height: 1.5)),
          ],
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

/// شريط قوة كلمة المرور: 5 مقاطع ملوّنة + التسمية + الاقتراح الأول.
class PasswordStrengthBar extends StatelessWidget {
  const PasswordStrengthBar({super.key, required this.password});
  final String password;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (password.isEmpty) return const SizedBox.shrink();
    final a = evaluatePasswordStrength(password);
    final color = a.strength.color(p);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            for (var i = 0; i < 5; i++)
              Expanded(
                child: Container(
                  height: 5,
                  margin: EdgeInsetsDirectional.only(end: i == 4 ? 0 : 4),
                  decoration: BoxDecoration(
                    color: i <= a.strength.index ? color : p.border,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Text('قوة كلمة المرور: ', style: context.ts(size: 12.5, color: p.textDim)),
            Text(a.strength.label, style: context.ts(size: 12.5, w: FontWeight.w700, color: color)),
            if (a.suggestions.isNotEmpty) ...[
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  a.suggestions.first,
                  style: context.ts(size: 12.5, color: p.textDim),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }
}

/// حقل نص موحّد لشاشات الحساب.
class AuthTextField extends StatelessWidget {
  const AuthTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.keyboardType,
    this.obscureText = false,
    this.validator,
    this.suffix,
    this.onChanged,
    this.textInputAction,
    this.onSubmitted,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final SIconData icon;
  final TextInputType? keyboardType;
  final bool obscureText;
  final String? Function(String?)? validator;
  final Widget? suffix;
  final ValueChanged<String>? onChanged;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onSubmitted;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(17),
      borderSide: BorderSide(color: p.border),
    );
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      validator: validator,
      onChanged: onChanged,
      textInputAction: textInputAction,
      onFieldSubmitted: onSubmitted,
      style: context.ts(),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: SIcon(icon),
        suffixIcon: suffix,
        filled: true,
        fillColor: p.surface,
        border: border,
        enabledBorder: border,
        focusedBorder: border.copyWith(borderSide: BorderSide(color: p.accent, width: 1.4)),
        errorBorder: border.copyWith(borderSide: const BorderSide(color: Color(0xFFE5484D))),
      ),
    );
  }
}

/// لافتة تحذير صغيرة (للوضع التجريبي المحلي مثلاً).
class AuthNoticeBanner extends StatelessWidget {
  const AuthNoticeBanner({super.key, required this.icon, required this.text, this.color});
  final SIconData icon;
  final String text;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = color ?? p.gold;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: tint(c, 0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tint(c, 0.35)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SIcon(icon, size: 18, color: c),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text, style: context.ts(size: 13, height: 1.5)),
          ),
        ],
      ),
    );
  }
}

/// زر رئيسي موحّد.
class AuthPrimaryButton extends StatelessWidget {
  const AuthPrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.busy = false,
    this.icon,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool busy;
  final SIconData? icon;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return FilledButton(
      onPressed: busy ? null : onPressed,
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
      ),
      child: busy
          ? SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2.5, color: p.onAccent),
            )
          : Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  SIcon(icon!, size: 20, color: p.onAccent),
                  const SizedBox(width: 8),
                ],
                Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
              ],
            ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة الدخول / التسجيل v2
// ═══════════════════════════════════════════════════════════════════════════

enum AuthV2Mode { login, register }

/// شاشة دخول وتسجيل احترافية: تبويبان (دخول/حساب جديد)، تحقق فوري،
/// مقياس قوة كلمة المرور، حارس محاولات، دخول Google، ودخول كضيف.
class AuthV2Screen extends StatefulWidget {
  const AuthV2Screen({super.key, this.initialMode = AuthV2Mode.login, this.onDone});

  final AuthV2Mode initialMode;

  /// تُنادى بعد نجاح الدخول (لإغلاق الشاشة أو الانتقال).
  final VoidCallback? onDone;

  @override
  State<AuthV2Screen> createState() => _AuthV2ScreenState();
}

class _AuthV2ScreenState extends State<AuthV2Screen> {
  late AuthV2Mode _mode = widget.initialMode;
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _hidePassword = true;
  bool _hideConfirm = true;
  String _passwordLive = '';
  String? _emailHint;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  void _switchMode(AuthV2Mode m) {
    setState(() {
      _mode = m;
      _emailHint = null;
    });
    context.read<AuthV2Store>().clearError();
  }

  Future<void> _submit() async {
    final store = context.read<AuthV2Store>();
    if (store.guard.isLocked) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(store.guard.lockMessage)),
      );
      return;
    }
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final email = _email.text.trim();
    final password = _password.text;
    var ok = false;
    if (_mode == AuthV2Mode.login) {
      ok = await store.signIn(email, password);
    } else {
      ok = await store.signUp(_name.text.trim(), email, password);
    }
    if (!mounted) return;
    if (ok) {
      if (store.isLocalDemo) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم الدخول في الوضع التجريبي المحلي (الخادم لا يوفّر /auth/* بعد).'),
          ),
        );
      }
      widget.onDone?.call();
    } else if (store.lastError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(store.lastError!)),
      );
    }
  }

  void _onEmailChanged(String v) {
    final fix = suggestEmailFix(v);
    setState(() {
      _emailHint = fix == null ? null : 'هل تقصد $fix؟';
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<AuthV2Store>();
    final isLogin = _mode == AuthV2Mode.login;
    return Scaffold(
      appBar: AppBar(
        title: Text(isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'),
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const SIcon(SardIcons.arrow_back_rounded),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                width: 76,
                height: 76,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(color: p.border),
                ),
                child: SIcon(SardIcons.auto_stories_rounded, size: 38, color: p.accent),
              ),
              const SizedBox(height: 14),
              Text(
                isLogin ? 'أهلاً بعودتك' : 'ابدأ حكايتك',
                style: context.ds(size: 24),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 6),
              Text(
                isLogin
                    ? 'سجّل دخولك لمتابعة قراءتك ومكتبتك.'
                    : 'حساب واحد يحفظ تقدّمك على كل أجهزتك.',
                style: context.ts(color: p.textDim, size: 13.5, height: 1.5),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              _ModeTabs(mode: _mode, onChanged: _switchMode),
              const SizedBox(height: 20),
              if (store.isLocalDemo)
                const AuthNoticeBanner(
                  icon: SardIcons.info_outline_rounded,
                  text: 'أنت في الوضع التجريبي المحلي: بياناتك محفوظة على هذا الجهاز فقط حتى يتوفّر الخادم.',
                ),
              if (store.isLocalDemo) const SizedBox(height: 14),
              if (!isLogin) ...[
                AuthTextField(
                  controller: _name,
                  label: 'الاسم المعروض',
                  hint: 'مثال: سارة القارئة',
                  icon: SardIcons.person_rounded,
                  validator: validateDisplayName,
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(height: 12),
              ],
              AuthTextField(
                controller: _email,
                label: 'البريد الإلكتروني',
                hint: 'name@example.com',
                icon: SardIcons.mail_outline,
                keyboardType: TextInputType.emailAddress,
                validator: validateEmail,
                onChanged: _onEmailChanged,
                textInputAction: TextInputAction.next,
              ),
              if (_emailHint != null) ...[
                const SizedBox(height: 6),
                Row(
                  children: [
                    const SIcon(SardIcons.info_outline_rounded, size: 15),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(_emailHint!, style: context.ts(size: 12.5, color: p.gold)),
                    ),
                    TextButton(
                      onPressed: () {
                        final fix = suggestEmailFix(_email.text);
                        if (fix != null) {
                          _email.text = fix;
                          setState(() => _emailHint = null);
                        }
                      },
                      child: const Text('تصحيح'),
                    ),
                  ],
                ),
              ],
              const SizedBox(height: 12),
              AuthTextField(
                controller: _password,
                label: 'كلمة المرور',
                hint: '8 أحرف على الأقل',
                icon: SardIcons.lock_outline,
                obscureText: _hidePassword,
                validator: (v) => validatePassword(v, strict: !isLogin),
                onChanged: (v) => setState(() => _passwordLive = v),
                textInputAction: isLogin ? TextInputAction.done : TextInputAction.next,
                onSubmitted: (_) => isLogin ? _submit() : null,
                suffix: IconButton(
                  onPressed: () => setState(() => _hidePassword = !_hidePassword),
                  icon: SIcon(
                    _hidePassword ? SardIcons.visibility_outlined : SardIcons.visibility_off_outlined,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              if (!isLogin) ...[
                PasswordStrengthBar(password: _passwordLive),
                const SizedBox(height: 12),
                AuthTextField(
                  controller: _confirm,
                  label: 'تأكيد كلمة المرور',
                  hint: 'أعد كتابتها كما هي',
                  icon: SardIcons.lock_outline,
                  obscureText: _hideConfirm,
                  validator: (v) => validatePasswordConfirmation(v, _password.text),
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _submit(),
                  suffix: IconButton(
                    onPressed: () => setState(() => _hideConfirm = !_hideConfirm),
                    icon: SIcon(
                      _hideConfirm ? SardIcons.visibility_outlined : SardIcons.visibility_off_outlined,
                    ),
                  ),
                ),
              ],
              if (isLogin)
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton(
                    onPressed: () => showModalBottomSheet<void>(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: p.surface,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.2))),
                      ),
                      builder: (_) => const ForgotPasswordSheet(),
                    ),
                    child: const Text('نسيت كلمة المرور؟'),
                  ),
                ),
              const SizedBox(height: 8),
              if (store.guard.isLocked)
                AuthNoticeBanner(
                  icon: SardIcons.shield_rounded,
                  text: store.guard.lockMessage,
                  color: const Color(0xFFE5484D),
                ),
              if (store.guard.isLocked) const SizedBox(height: 12),
              if (store.lastError != null && !store.guard.isLocked) ...[
                AuthNoticeBanner(
                  icon: SardIcons.info_outline_rounded,
                  text: store.lastError!,
                  color: const Color(0xFFE5484D),
                ),
                const SizedBox(height: 12),
              ],
              AuthPrimaryButton(
                label: isLogin ? 'تسجيل الدخول' : 'إنشاء الحساب',
                icon: isLogin ? SardIcons.check_circle_rounded : SardIcons.person_rounded,
                busy: store.busy,
                onPressed: _submit,
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: store.busy
                    ? null
                    : () async {
                        final s = context.read<AuthV2Store>();
                        try {
                          await s._service._repo.signInGoogle();
                          await s.load();
                          if (mounted) widget.onDone?.call();
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(friendlyAuthError(e))),
                            );
                          }
                        }
                      },
                icon: const SIcon(SardIcons.g_mobiledata_rounded, size: 26),
                label: const Text('المتابعة باستخدام Google'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                  side: BorderSide(color: p.border),
                ),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () {
                  context.read<AuthV2Store>().enterGuest();
                  widget.onDone?.call();
                },
                child: const Text('المتابعة كضيف (بلا حساب)'),
              ),
              const SizedBox(height: 8),
              Text(
                'بالمتابعة أنت توافق على شروط الاستخدام وسياسة الخصوصية.',
                style: context.ts(color: p.textDim, size: 12, height: 1.5),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// تبويبا الدخول/التسجيل.
class _ModeTabs extends StatelessWidget {
  const _ModeTabs({required this.mode, required this.onChanged});
  final AuthV2Mode mode;
  final ValueChanged<AuthV2Mode> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    Widget tab(AuthV2Mode m, String label) {
      final selected = mode == m;
      return Expanded(
        child: GestureDetector(
          onTap: () => onChanged(m),
          child: Container(
            height: 46,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: selected ? p.accent : Colors.transparent,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Text(
              label,
              style: context.ts(
                size: 14,
                w: FontWeight.w700,
                color: selected ? p.onAccent : p.textDim,
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          tab(AuthV2Mode.login, 'تسجيل الدخول'),
          tab(AuthV2Mode.register, 'حساب جديد'),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  استعادة كلمة المرور
// ═══════════════════════════════════════════════════════════════════════════

/// ورقة استعادة كلمة المرور: بريد + إرسال رابط، مع بديل محلي صادق
/// حين لا توجد نقطة النهاية على الخادم.
class ForgotPasswordSheet extends StatefulWidget {
  const ForgotPasswordSheet({super.key});

  @override
  State<ForgotPasswordSheet> createState() => _ForgotPasswordSheetState();
}

class _ForgotPasswordSheetState extends State<ForgotPasswordSheet> {
  final _email = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _busy = false;
  bool _sent = false;
  bool _endpointMissing = false;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _busy = true);
    try {
      final service = AuthV2Service(AccountRepository(ApiClient()));
      final ok = await service.forgotPassword(_email.text.trim());
      if (!mounted) return;
      setState(() {
        _sent = ok;
        _endpointMissing = !ok;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(friendlyAuthError(e))),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: p.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('استعادة كلمة المرور', style: context.ds(size: 19)),
            const SizedBox(height: 6),
            Text(
              'سنرسل رابط إعادة تعيين إلى بريدك إن كان مسجلاً لدينا.',
              style: context.ts(color: p.textDim, size: 13.5, height: 1.5),
            ),
            const SizedBox(height: 16),
            if (_sent) ...[
              const AuthNoticeBanner(
                icon: SardIcons.check_circle_rounded,
                text: 'أُرسل الرابط. تحقق من بريدك (ومن مجلد الرسائل غير المرغوبة).',
                color: Color(0xFF3FA66A),
              ),
              const SizedBox(height: 12),
              AuthPrimaryButton(
                label: 'تم',
                onPressed: () => Navigator.of(context).pop(),
              ),
            ] else if (_endpointMissing) ...[
              const AuthNoticeBanner(
                icon: SardIcons.info_outline_rounded,
                text: 'الخادم لا يوفّر استعادة كلمة المرور بعد. يمكنك إنشاء حساب محلي جديد من شاشة التسجيل، أو إعادة تعيين قفل PIN من شاشة الأمان.',
              ),
              const SizedBox(height: 12),
              AuthPrimaryButton(
                label: 'فهمت',
                onPressed: () => Navigator.of(context).pop(),
              ),
            ] else ...[
              AuthTextField(
                controller: _email,
                label: 'البريد الإلكتروني',
                hint: 'name@example.com',
                icon: SardIcons.mail_outline,
                keyboardType: TextInputType.emailAddress,
                validator: validateEmail,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _send(),
              ),
              const SizedBox(height: 14),
              AuthPrimaryButton(
                label: 'إرسال رابط الاستعادة',
                icon: SardIcons.send_rounded,
                busy: _busy,
                onPressed: _send,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شارة حالة الدخول (للقائمة الجانبية/الإعدادات)
// ═══════════════════════════════════════════════════════════════════════════

/// شارة صغيرة تعرض حالة الدخول الحالية.
class AuthStateChip extends StatelessWidget {
  const AuthStateChip({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<AuthV2Store>();
    final (label, color, icon) = switch (store.state) {
      AuthState.signedIn => ('مسجَّل', const Color(0xFF3FA66A), SardIcons.check_circle_rounded),
      AuthState.localDemo => ('تجريبي محلي', p.gold, SardIcons.info_outline_rounded),
      AuthState.guest => ('ضيف', p.textDim, SardIcons.person_outline_rounded),
      AuthState.signedOut => ('غير مسجَّل', p.textDim, SardIcons.person_outline_rounded),
      AuthState.unknown => ('جارٍ التحقق…', p.textDim, SardIcons.refresh_rounded),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: tint(color, 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tint(color, 0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(icon, size: 14, color: color),
          const SizedBox(width: 5),
          Text(label, style: context.ts(size: 12, w: FontWeight.w700, color: color)),
        ],
      ),
    );
  }
}

/// ملخص سريع لحالة الحساب يُعرض أعلى شاشة الإعدادات.
class AuthSummaryTile extends StatelessWidget {
  const AuthSummaryTile({super.key, this.onTap});
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<AuthV2Store>();
    final user = store.user;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(p.r(0.9)),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: tint(p.accent, 0.15),
              backgroundImage: user != null && user.avatarUrl.isNotEmpty
                  ? NetworkImage(user.avatarUrl)
                  : null,
              onBackgroundImageError: (Object e, StackTrace? s) {},
              child: user == null || user.avatarUrl.isNotEmpty
                  ? null
                  : Text(user.initials, style: context.ds(size: 17, color: p.accent)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user?.displayName ?? 'زائر',
                    style: context.ds(size: 16),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    user?.email ?? 'سجّل دخولك لحفظ تقدّمك',
                    style: context.ts(color: p.textDim, size: 12.5),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const AuthStateChip(),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  سجل التدقيق المحلي (أحداث الدخول والأمان)
// ═══════════════════════════════════════════════════════════════════════════

/// نوع حدث أمني.
enum AuthAuditKind {
  signInSuccess('تسجيل دخول ناجح'),
  signInFailed('محاولة دخول فاشلة'),
  signUpSuccess('إنشاء حساب'),
  signOut('تسجيل خروج'),
  pinSet('تفعيل قفل PIN'),
  pinChanged('تغيير قفل PIN'),
  pinDisabled('إيقاف قفل PIN'),
  pinUnlockFailed('فتح قفل فاشل'),
  passwordResetRequested('طلب استعادة كلمة المرور'),
  sessionRevoked('إلغاء جلسة'),
  guestEntered('دخول كضيف'),
  accountDeleted('حذف الحساب');

  const AuthAuditKind(this.label);
  final String label;
}

/// حدث واحد في سجل التدقيق.
class AuthAuditEvent {
  const AuthAuditEvent({
    required this.kind,
    required this.at,
    this.detail = '',
  });

  final AuthAuditKind kind;
  final DateTime at;
  final String detail;

  Map<String, dynamic> toJson() => {
    'kind': kind.name,
    'at': at.toIso8601String(),
    'detail': detail,
  };

  factory AuthAuditEvent.fromJson(Map<String, dynamic> j) => AuthAuditEvent(
    kind: AuthAuditKind.values.firstWhere(
      (k) => k.name == '${j['kind']}',
      orElse: () => AuthAuditKind.signInSuccess,
    ),
    at: DateTime.tryParse('${j['at']}') ?? DateTime.now(),
    detail: '${j['detail'] ?? ''}',
  );

  String get timeLabel {
    final now = DateTime.now();
    final diff = now.difference(at);
    if (diff.inMinutes < 1) return 'الآن';
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
    if (diff.inHours < 24) return 'منذ ${diff.inHours} ساعة';
    if (diff.inDays < 7) return 'منذ ${diff.inDays} ${diff.inDays == 1 ? 'يوم' : 'أيام'}';
    return '${at.year}/${at.month}/${at.day}';
  }
}

/// سجل التدقيق المحلي: يحتفظ بآخر 100 حدث في SharedPreferences
/// (على الجهاز فقط — لا يُرسل لأي خادم).
class AuthAuditLog {
  AuthAuditLog._(this._prefs);
  final SharedPreferences _prefs;

  static const String _key = 'sard_auth_audit_v2';
  static const int _maxEvents = 100;

  static Future<AuthAuditLog> load() async =>
      AuthAuditLog._(await SharedPreferences.getInstance());

  static AuthAuditLog fromPrefs(SharedPreferences prefs) => AuthAuditLog._(prefs);

  List<AuthAuditEvent> get events {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) return const [];
    try {
      final list = jsonDecode(raw) as List;
      return list
          .whereType<Map>()
          .map((e) => AuthAuditEvent.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  /// عدد محاولات الدخول الفاشلة في آخر 24 ساعة.
  int get recentFailures {
    final since = DateTime.now().subtract(const Duration(hours: 24));
    return events
        .where((e) => e.kind == AuthAuditKind.signInFailed && e.at.isAfter(since))
        .length;
  }

  Future<void> record(AuthAuditKind kind, {String detail = ''}) async {
    final next = [
      AuthAuditEvent(kind: kind, at: DateTime.now(), detail: detail),
      ...events,
    ].take(_maxEvents).toList();
    await _prefs.setString(
      _key,
      jsonEncode(next.map((e) => e.toJson()).toList()),
    );
  }

  Future<void> clear() async => _prefs.remove(_key);
}

/// شاشة سجل التدقيق (آخر الأحداث الأمنية على هذا الجهاز).
class AuthAuditLogScreen extends StatelessWidget {
  const AuthAuditLogScreen({super.key, required this.log});
  final AuthAuditLog log;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final events = log.events;
    return Scaffold(
      appBar: AppBar(
        title: const Text('سجل النشاط الأمني'),
        actions: [
          IconButton(
            onPressed: events.isEmpty
                ? null
                : () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('مسح السجل؟'),
                        content: const Text('سيُحذف سجل الأحداث الأمنية من هذا الجهاز.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(false),
                            child: const Text('إلغاء'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(true),
                            child: const Text('مسح'),
                          ),
                        ],
                      ),
                    );
                    if (ok == true) {
                      await log.clear();
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('تم مسح السجل.')),
                        );
                      }
                    }
                  },
            icon: const SIcon(SardIcons.delete_outline_rounded),
            tooltip: 'مسح السجل',
          ),
        ],
      ),
      body: events.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SIcon(SardIcons.history_rounded, size: 48),
                    const SizedBox(height: 12),
                    Text('لا أحداث بعد', style: context.ds(size: 18)),
                    const SizedBox(height: 6),
                    Text(
                      'ستظهر هنا محاولات الدخول وتغييرات الأمان على هذا الجهاز.',
                      style: context.ts(color: p.textDim, size: 13.5, height: 1.6),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              itemCount: events.length,
              separatorBuilder: (ctx, idx) => const SizedBox(height: 8),
              itemBuilder: (BuildContext context, int i) {
                final e = events[i];
                final isFailure = e.kind == AuthAuditKind.signInFailed ||
                    e.kind == AuthAuditKind.pinUnlockFailed;
                return Container(
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: p.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: p.border),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: tint(
                            isFailure ? const Color(0xFFE5484D) : const Color(0xFF3FA66A),
                            0.12,
                          ),
                          borderRadius: BorderRadius.circular(11),
                        ),
                        child: SIcon(
                          isFailure ? SardIcons.info_outline_rounded : SardIcons.check_circle_rounded,
                          size: 19,
                          color: isFailure ? const Color(0xFFE5484D) : const Color(0xFF3FA66A),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(e.kind.label, style: context.ts(w: FontWeight.w700)),
                            if (e.detail.isNotEmpty) ...[
                              const SizedBox(height: 2),
                              Text(e.detail, style: context.ts(color: p.textDim, size: 12.5)),
                            ],
                          ],
                        ),
                      ),
                      Text(e.timeLabel, style: context.ts(color: p.textDim, size: 12)),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
