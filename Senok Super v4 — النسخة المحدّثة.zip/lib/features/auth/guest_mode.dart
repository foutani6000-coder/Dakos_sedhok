/// ──────────────────────────────────────────────────────────────────────────
/// وضع الضيف — قراءة بلا حساب مع حدود واضحة
///
///  • حدود الضيف [GuestLimits]: متابعة 10 أعمال كحد أقصى، بلا تعليقات،
///    قائمة واحدة، بلا تنزيلات، بلا مزامنة سحابية
///  • المتحكم [GuestModeController]: مفردة (.i) مع load()، دخول/خروج الضيف،
///    عدّادات الاستخدام، وفحص الحدود قبل كل إجراء محظور
///  • شاشة ترقية [GuestUpgradeSheet] تشرح الفوائد وتدعو لإنشاء حساب
///  • كل قيد يُشرح في الواجهة وقت حدوثه (لا حظر صامت)
/// ──────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'auth_v2.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  حدود الضيف
// ═══════════════════════════════════════════════════════════════════════════

/// حدود وضع الضيف (قواعد ثابتة وشفافة).
class GuestLimits {
  const GuestLimits({
    this.maxFollowed = 10,
    this.maxLists = 1,
    this.commentsAllowed = false,
    this.downloadsAllowed = false,
    this.cloudSyncAllowed = false,
    this.recommendationsAllowed = false,
    this.postsAllowed = false,
    this.maxDailyChapters = 50,
  });

  /// أقصى عدد أعمال يمكن متابعتها.
  final int maxFollowed;

  /// أقصى عدد قوائم شخصية.
  final int maxLists;

  /// التعليق على الفصول.
  final bool commentsAllowed;

  /// تنزيل الفصول للقراءة دون اتصال.
  final bool downloadsAllowed;

  /// مزامنة التقدّم مع الحساب السحابي.
  final bool cloudSyncAllowed;

  /// ترشيح الأعمال للآخرين.
  final bool recommendationsAllowed;

  /// نشر منشورات في المجتمع.
  final bool postsAllowed;

  /// أقصى عدد فصول في اليوم (حماية من الإفراط).
  final int maxDailyChapters;

  static const GuestLimits defaults = GuestLimits();

  Map<String, dynamic> toJson() => {
    'max_followed': maxFollowed,
    'max_lists': maxLists,
    'comments_allowed': commentsAllowed,
    'downloads_allowed': downloadsAllowed,
    'cloud_sync_allowed': cloudSyncAllowed,
    'recommendations_allowed': recommendationsAllowed,
    'posts_allowed': postsAllowed,
    'max_daily_chapters': maxDailyChapters,
  };

  factory GuestLimits.fromJson(Map<String, dynamic> j) => GuestLimits(
    maxFollowed: (j['max_followed'] as num?)?.toInt() ?? 10,
    maxLists: (j['max_lists'] as num?)?.toInt() ?? 1,
    commentsAllowed: j['comments_allowed'] == true,
    downloadsAllowed: j['downloads_allowed'] == true,
    cloudSyncAllowed: j['cloud_sync_allowed'] == true,
    recommendationsAllowed: j['recommendations_allowed'] == true,
    postsAllowed: j['posts_allowed'] == true,
    maxDailyChapters: (j['max_daily_chapters'] as num?)?.toInt() ?? 50,
  );
}

/// عنصر بيانات ضيف واحد (يُعرض في شاشة الضيف).
class GuestDataItem {
  const GuestDataItem({
    required this.label,
    required this.count,
    required this.icon,
    this.hint,
  });

  final String label;
  final int count;
  final SIconData icon;
  final String? hint;
}

/// نتيجة فحص حدّ: مسموح أم محظور + رسالة الشرح.
class GuestLimitCheck {
  const GuestLimitCheck({required this.allowed, required this.message});
  final bool allowed;
  final String message;
}

// ═══════════════════════════════════════════════════════════════════════════
//  متحكم وضع الضيف
// ═══════════════════════════════════════════════════════════════════════════

/// مفاتيح التخزين.
class GuestKeys {
  static const String isGuest = 'sard_guest_mode_v2';
  static const String followedCount = 'sard_guest_followed_v2';
  static const String listsCount = 'sard_guest_lists_v2';
  static const String dayChapters = 'sard_guest_day_chapters_v2';
  static const String dayChaptersDate = 'sard_guest_day_date_v2';
  static const String enteredAt = 'sard_guest_entered_at_v2';
}

/// متحكم وضع الضيف: مفردة (.i) مع load().
class GuestModeController extends ChangeNotifier {
  GuestModeController._(this._prefs, [this.limits = GuestLimits.defaults]);
  final SharedPreferences _prefs;

  /// الحدود المطبّقة (قابلة للتخصيص في الاختبارات).
  final GuestLimits limits;

  static GuestModeController? _instance;

  static GuestModeController get i {
    final inst = _instance;
    if (inst == null) throw StateError('GuestModeController.load() must be called first');
    return inst;
  }

  static Future<GuestModeController> load([GuestLimits? limits]) async {
    _instance ??= GuestModeController._(
      await SharedPreferences.getInstance(),
      limits ?? GuestLimits.defaults,
    );
    return _instance!;
  }

  static GuestModeController fromPrefs(SharedPreferences prefs, [GuestLimits? limits]) {
    _instance = GuestModeController._(prefs, limits ?? GuestLimits.defaults);
    return _instance!;
  }

  bool get isGuest => _prefs.getBool(GuestKeys.isGuest) ?? false;

  DateTime? get enteredAt {
    final ms = _prefs.getInt(GuestKeys.enteredAt);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  int get followedCount => _prefs.getInt(GuestKeys.followedCount) ?? 0;
  int get listsCount => _prefs.getInt(GuestKeys.listsCount) ?? 0;

  /// عدد الفصول المقروءة اليوم (يُصفَّر مع تغيّر التاريخ).
  int get todayChapters {
    final today = _dayKey(DateTime.now());
    if (_prefs.getString(GuestKeys.dayChaptersDate) != today) return 0;
    return _prefs.getInt(GuestKeys.dayChapters) ?? 0;
  }

  static String _dayKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// يدخل وضع الضيف.
  Future<void> enterGuest() async {
    await _prefs.setBool(GuestKeys.isGuest, true);
    await _prefs.setInt(GuestKeys.enteredAt, DateTime.now().millisecondsSinceEpoch);
    notifyListeners();
  }

  /// يخرج من وضع الضيف (عند إنشاء حساب أو تسجيل الدخول).
  Future<void> exitGuest() async {
    await _prefs.setBool(GuestKeys.isGuest, false);
    notifyListeners();
  }

  /// هل يمكن متابعة عمل جديد؟ (العدد الحالي يُمرَّر من مكتبة المستخدم)
  GuestLimitCheck canFollow(int currentFollowed) {
    if (currentFollowed < limits.maxFollowed) {
      return const GuestLimitCheck(allowed: true, message: '');
    }
    return GuestLimitCheck(
      allowed: false,
      message: 'وصلت إلى حد الضيف (${limits.maxFollowed} أعمال). أنشئ حساباً لمتابعة أعمال بلا حدود.',
    );
  }

  /// هل يمكن إنشاء قائمة جديدة؟
  GuestLimitCheck canCreateList(int currentLists) {
    if (currentLists < limits.maxLists) {
      return const GuestLimitCheck(allowed: true, message: '');
    }
    return const GuestLimitCheck(
      allowed: false,
      message: 'الضيف يملك قائمة واحدة فقط. أنشئ حساباً لقوائم بلا حدود.',
    );
  }

  /// هل يمكن التعليق؟
  GuestLimitCheck get canComment => limits.commentsAllowed
      ? const GuestLimitCheck(allowed: true, message: '')
      : const GuestLimitCheck(
          allowed: false,
          message: 'التعليق يتطلب حساباً. أنشئ حساباً مجانياً للمشاركة في النقاش.',
        );

  /// هل يمكن التنزيل؟
  GuestLimitCheck get canDownload => limits.downloadsAllowed
      ? const GuestLimitCheck(allowed: true, message: '')
      : const GuestLimitCheck(
          allowed: false,
          message: 'التنزيل للأعضاء فقط. أنشئ حساباً لتنزيل الفصول وقراءتها دون اتصال.',
        );

  /// هل يمكن النشر في المجتمع؟
  GuestLimitCheck get canPost => limits.postsAllowed
      ? const GuestLimitCheck(allowed: true, message: '')
      : const GuestLimitCheck(
          allowed: false,
          message: 'النشر في المجتمع يتطلب حساباً.',
        );

  /// هل يمكن قراءة فصل آخر اليوم؟ (حد يومي للضيف)
  GuestLimitCheck get canReadAnotherChapter {
    if (todayChapters < limits.maxDailyChapters) {
      return const GuestLimitCheck(allowed: true, message: '');
    }
    return GuestLimitCheck(
      allowed: false,
      message: 'وصلت إلى حد الضيف اليومي (${limits.maxDailyChapters} فصلاً). '
          'أنشئ حساباً لقراءة بلا حدود.',
    );
  }

  /// يسجّل قراءة فصل جديد اليوم (يُنادى بعد markRead).
  Future<void> noteChapterRead() async {
    final today = _dayKey(DateTime.now());
    if (_prefs.getString(GuestKeys.dayChaptersDate) != today) {
      await _prefs.setString(GuestKeys.dayChaptersDate, today);
      await _prefs.setInt(GuestKeys.dayChapters, 1);
    } else {
      await _prefs.setInt(GuestKeys.dayChapters, todayChapters + 1);
    }
    notifyListeners();
  }

  /// يزامن عدّاد المتابَعة مع العدد الحقيقي.
  Future<void> syncFollowedCount(int count) async {
    await _prefs.setInt(GuestKeys.followedCount, count);
    notifyListeners();
  }

  /// عناصر بيانات الضيف لعرضها في الشاشة.
  List<GuestDataItem> dataItems({required int followed, required int lists}) => [
    GuestDataItem(
      label: 'أعمال متابَعة',
      count: followed,
      icon: SardIcons.bookmark_rounded,
      hint: 'الحد: ${limits.maxFollowed}',
    ),
    GuestDataItem(
      label: 'قوائم شخصية',
      count: lists,
      icon: SardIcons.collections_bookmark_rounded,
      hint: 'الحد: ${limits.maxLists}',
    ),
    GuestDataItem(
      label: 'فصول قرأتها اليوم',
      count: todayChapters,
      icon: SardIcons.auto_stories_rounded,
      hint: 'الحد اليومي: ${limits.maxDailyChapters}',
    ),
  ];

  /// ما الذي سيُفقد عند إنشاء حساب؟ لا شيء — بيانات الضيف تُنقل للحساب.
  static const String migrationNote =
      'حين تنشئ حساباً، تنتقل متابَعاتك وقوائمك وتقدّمك كما هي. لا تفقد شيئاً.';
}

// ═══════════════════════════════════════════════════════════════════════════
//  دوال مساعدة على مستوى الملف (تأخذ BuildContext معاملاً صريحاً)
// ═══════════════════════════════════════════════════════════════════════════

/// صف حدّ واحد في شاشة الضيف: العنوان + القيمة + أيقونة محظور/مسموح.
Widget guestLimitTile(
  BuildContext context,
  SardPalette p,
  String title,
  String value,
  bool blocked,
) {
  final color = blocked ? const Color(0xFFE5484D) : const Color(0xFF3FA66A);
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    decoration: BoxDecoration(
      color: p.bg,
      borderRadius: BorderRadius.circular(13),
      border: Border.all(color: p.border),
    ),
    child: Row(
      children: [
        SIcon(
          blocked ? SardIcons.close_rounded : SardIcons.check_circle_rounded,
          size: 20,
          color: color,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(title, style: context.ts(w: FontWeight.w600)),
        ),
        Text(value, style: context.ts(size: 12.5, color: p.textDim)),
      ],
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة وضع الضيف
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة وضع الضيف: ما لك وما عليك، وزر الترقية لإنشاء حساب.
class GuestModeScreen extends StatelessWidget {
  const GuestModeScreen({
    super.key,
    required this.controller,
    this.followed = 0,
    this.lists = 0,
    this.onCreateAccount,
    this.onSignIn,
  });

  final GuestModeController controller;
  final int followed;
  final int lists;
  final VoidCallback? onCreateAccount;
  final VoidCallback? onSignIn;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final limits = controller.limits;
    return Scaffold(
      appBar: AppBar(title: const Text('وضع الضيف')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(p.r(0.9)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Column(
              children: [
                Container(
                  width: 72,
                  height: 72,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(p.accent, 0.12),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: SIcon(SardIcons.person_outline_rounded, size: 36, color: p.accent),
                ),
                const SizedBox(height: 12),
                Text('تتصفح كضيف', style: context.ds(size: 20)),
                const SizedBox(height: 6),
                Text(
                  'يمكنك القراءة والاستكشاف بحرية، مع حدود بسيطة. '
                  'أنشئ حساباً مجانياً لإزالتها كلها — وتنتقل بياناتك كما هي.',
                  style: context.ts(color: p.textDim, size: 13.5, height: 1.6),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text('حدود وضع الضيف', style: context.ds(size: 17)),
          const SizedBox(height: 8),
          guestLimitTile(context, p, 'متابعة الأعمال', '$followed / ${limits.maxFollowed}', followed >= limits.maxFollowed),
          const SizedBox(height: 8),
          guestLimitTile(context, p, 'القوائم الشخصية', '$lists / ${limits.maxLists}', lists >= limits.maxLists),
          const SizedBox(height: 8),
          guestLimitTile(context, p, 'التعليق على الفصول', limits.commentsAllowed ? 'مسموح' : 'محظور', !limits.commentsAllowed),
          const SizedBox(height: 8),
          guestLimitTile(context, p, 'تنزيل الفصول', limits.downloadsAllowed ? 'مسموح' : 'محظور', !limits.downloadsAllowed),
          const SizedBox(height: 8),
          guestLimitTile(context, p, 'المزامنة السحابية', limits.cloudSyncAllowed ? 'مسموح' : 'محظور', !limits.cloudSyncAllowed),
          const SizedBox(height: 8),
          guestLimitTile(context, p, 'النشر في المجتمع', limits.postsAllowed ? 'مسموح' : 'محظور', !limits.postsAllowed),
          const SizedBox(height: 8),
          guestLimitTile(
            context,
            p,
            'فصول اليوم',
            '${controller.todayChapters} / ${limits.maxDailyChapters}',
            controller.todayChapters >= limits.maxDailyChapters,
          ),
          const SizedBox(height: 16),
          AuthSectionCard(
            icon: SardIcons.auto_stories_rounded,
            color: p.accent,
            title: 'بياناتك كضيف',
            child: Column(
              children: [
                for (final item in controller.dataItems(followed: followed, lists: lists))
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        SIcon(item.icon, size: 18, color: p.accent),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(item.label, style: context.ts(w: FontWeight.w600)),
                        ),
                        Text('${item.count}', style: context.ds(size: 16, color: p.accent)),
                        if (item.hint != null) ...[
                          const SizedBox(width: 8),
                          Text(item.hint!, style: context.ts(color: p.textDim, size: 11.5)),
                        ],
                      ],
                    ),
                  ),
                const SizedBox(height: 8),
                Text(
                  GuestModeController.migrationNote,
                  style: context.ts(color: p.textDim, size: 12.5, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          AuthPrimaryButton(
            label: 'إنشاء حساب مجاني',
            icon: SardIcons.person_rounded,
            onPressed: onCreateAccount,
          ),
          const SizedBox(height: 10),
          OutlinedButton(
            onPressed: onSignIn,
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(52),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
              side: BorderSide(color: p.border),
            ),
            child: const Text('لدي حساب — تسجيل الدخول'),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ورقة الترقية (تُعرض عند بلوغ حدّ)
// ═══════════════════════════════════════════════════════════════════════════

/// ورقة ترقية صغيرة تُعرض حين يبلغ الضيف حداً (متابعة/تعليق/تنزيل).
class GuestUpgradeSheet extends StatelessWidget {
  const GuestUpgradeSheet({
    super.key,
    required this.reason,
    this.onCreateAccount,
    this.onSignIn,
  });

  /// سبب العرض (رسالة الحد الذي بلغه المستخدم).
  final String reason;
  final VoidCallback? onCreateAccount;
  final VoidCallback? onSignIn;

  static const List<String> benefits = [
    'متابعة أعمال وقوائم بلا حدود',
    'التعليق والنشر في المجتمع',
    'تنزيل الفصول وقراءتها دون اتصال',
    'مزامنة تقدّمك على كل أجهزتك',
    'أهداف قراءة ويوميات وإحصاءات',
  ];

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(2)),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: 64,
            height: 64,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.gold, 0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: SIcon(SardIcons.star_rounded, size: 32, color: p.gold),
          ),
          const SizedBox(height: 12),
          Text('هذه الميزة للأعضاء', style: context.ds(size: 19), textAlign: TextAlign.center),
          const SizedBox(height: 6),
          Text(reason, style: context.ts(color: p.textDim, size: 13.5, height: 1.6), textAlign: TextAlign.center),
          const SizedBox(height: 14),
          for (final b in benefits)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  const SIcon(SardIcons.check_circle_rounded, size: 18, color: Color(0xFF3FA66A)),
                  const SizedBox(width: 8),
                  Expanded(child: Text(b, style: context.ts(size: 13.5))),
                ],
              ),
            ),
          const SizedBox(height: 16),
          AuthPrimaryButton(
            label: 'إنشاء حساب مجاني',
            icon: SardIcons.person_rounded,
            onPressed: onCreateAccount,
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: onSignIn,
            child: const Text('لدي حساب — تسجيل الدخول'),
          ),
          const SizedBox(height: 4),
          Text(
            GuestModeController.migrationNote,
            style: context.ts(color: p.textDim, size: 12, height: 1.5),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  /// يعرض الورقة من أي مكان (اختصار).
  static Future<void> show(BuildContext context, String reason, {VoidCallback? onCreateAccount, VoidCallback? onSignIn}) {
    final p = context.pal;
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: p.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.2))),
      ),
      builder: (_) => GuestUpgradeSheet(
        reason: reason,
        onCreateAccount: onCreateAccount,
        onSignIn: onSignIn,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ترحيل بيانات الضيف إلى الحساب
// ═══════════════════════════════════════════════════════════════════════════

/// نتيجة ترحيل بيانات الضيف.
class GuestMigrationResult {
  const GuestMigrationResult({
    required this.followedMigrated,
    required this.listsMigrated,
    required this.chaptersTodayMigrated,
    required this.notes,
  });

  final int followedMigrated;
  final int listsMigrated;
  final int chaptersTodayMigrated;
  final List<String> notes;

  int get totalMigrated => followedMigrated + listsMigrated + chaptersTodayMigrated;

  String get summary {
    if (totalMigrated == 0) return 'لا بيانات ضيف لترحيلها.';
    return 'نُقلت $followedMigrated متابَعة و$listsMigrated قائمة و$chaptersTodayMigrated فصلاً من اليوم إلى حسابك.';
  }
}

/// يرحّل بيانات الضيف إلى الحساب الجديد (قواعدي بالكامل):
/// الأعداد تُنسخ كما هي، ثم يُخرج المستخدم من وضع الضيف.
class GuestMigration {
  const GuestMigration._();

  /// يبني نتيجة الترحيل من حالة الضيف الحالية.
  static GuestMigrationResult plan({
    required GuestModeController guest,
    required int followed,
    required int lists,
  }) {
    final notes = <String>[];
    if (followed > 0) notes.add('ستنتقل $followed متابَعة إلى حسابك.');
    if (lists > 0) notes.add('ستنتقل $lists قائمة إلى حسابك.');
    if (guest.todayChapters > 0) {
      notes.add('فصول اليوم (${guest.todayChapters}) ستُحسب ضمن أهدافك.');
    }
    if (notes.isEmpty) notes.add('لا بيانات ضيف محفوظة — ستبدأ بحساب نظيف.');
    return GuestMigrationResult(
      followedMigrated: followed,
      listsMigrated: lists,
      chaptersTodayMigrated: guest.todayChapters,
      notes: notes,
    );
  }

  /// ينفّذ الترحيل: يخرج من وضع الضيف ويعيد النتيجة للعرض.
  static Future<GuestMigrationResult> execute({
    required GuestModeController guest,
    required int followed,
    required int lists,
  }) async {
    final result = plan(guest: guest, followed: followed, lists: lists);
    await guest.exitGuest();
    return result;
  }
}

/// بطاقة ترحيل بيانات الضيف (تُعرض بعد إنشاء الحساب مباشرة).
class GuestMigrationCard extends StatelessWidget {
  const GuestMigrationCard({super.key, required this.result, this.onDone});
  final GuestMigrationResult result;
  final VoidCallback? onDone;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: tint(const Color(0xFF3FA66A), 0.4), width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const SIcon(SardIcons.check_circle_rounded, size: 22, color: Color(0xFF3FA66A)),
              const SizedBox(width: 8),
              Expanded(
                child: Text('تم نقل بياناتك', style: context.ds(size: 16)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(result.summary, style: context.ts(size: 13.5, height: 1.6)),
          const SizedBox(height: 8),
          for (final note in result.notes)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('• ', style: context.ts(w: FontWeight.w700)),
                  Expanded(child: Text(note, style: context.ts(size: 13, height: 1.5))),
                ],
              ),
            ),
          if (onDone != null) ...[
            const SizedBox(height: 12),
            AuthPrimaryButton(label: 'متابعة', onPressed: onDone),
          ],
        ],
      ),
    );
  }
}
