/// ──────────────────────────────────────────────────────────────────────────
/// إجراءات الحساب — تصدير البيانات، تسجيل الخروج، حذف الحساب
///
///  • تصدير نسخة JSON من كل بياناتك المحلية (ملف، قراءة، أهداف، إعدادات)
///    ومشاركتها عبر مشاركة النظام
///  • تسجيل الخروج: يمسح الرمز من التخزين الآمن ويعيدك لشاشة الدخول
///  • حذف الحساب: تأكيد من خطوتين (كتابة كلمة «حذف») ثم مسح محلي كامل،
///    وطلب حذف من الخادم عند توفّر نقطة النهاية (وإلا حذف محلي فقط
///    مع شرح صريح أن الحساب على الخادم قد يبقى حتى يتوفر الحذف)
/// ──────────────────────────────────────────────────────────────────────────

import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/account_repository.dart';
import '../../core/data/api_client.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'auth_v2.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  تصدير البيانات
// ═══════════════════════════════════════════════════════════════════════════

/// حزمة بيانات التصدير (JSON واحد شامل).
class AccountExport {
  const AccountExport({
    required this.appVersion,
    required this.exportedAt,
    required this.profile,
    required this.reading,
    required this.library,
    required this.goals,
    required this.settings,
  });

  final String appVersion;
  final DateTime exportedAt;
  final Map<String, dynamic> profile;
  final Map<String, dynamic> reading;
  final Map<String, dynamic> library;
  final Map<String, dynamic> goals;
  final Map<String, dynamic> settings;

  Map<String, dynamic> toJson() => {
    'app': 'Senok',
    'app_version': appVersion,
    'exported_at': exportedAt.toIso8601String(),
    'profile': profile,
    'reading': reading,
    'library': library,
    'goals': goals,
    'settings': settings,
  };

  String toJsonString() => const JsonEncoder.withIndent('  ').convert(toJson());

  /// عدد العناصر المصدّرة تقريباً (للعرض في الواجهة).
  int get itemCount {
    var n = 0;
    n += (reading['read_chapters'] as Map?)?.length ?? 0;
    n += (library['followed'] as List?)?.length ?? 0;
    n += (library['favorites'] as List?)?.length ?? 0;
    n += (goals['goals'] as List?)?.length ?? 0;
    return n;
  }
}

/// يبني حزمة التصدير من المخازن المحلية الحقيقية.
/// [extraGoalsJson] تُمرَّر من مخزن الأهداف (إن وُجد).
AccountExport buildAccountExport({
  required SettingsController settings,
  required String appVersion,
  Map<String, dynamic> profile = const {},
  List<Map<String, dynamic>> goals = const [],
}) {
  return AccountExport(
    appVersion: appVersion,
    exportedAt: DateTime.now(),
    profile: profile,
    reading: {
      'total_chapters': settings.totalChaptersRead,
      'total_seconds': settings.totalReadingSeconds,
      'progress': settings.exportProgress(),
      'read_chapters': settings.exportReadChapters(),
      'reading_seconds': settings.exportReadingSeconds(),
    },
    library: {
      'followed': settings.followedSeries.toList(),
      'favorites': settings.favoriteIds,
      'read_later': settings.laterIds,
      'recommended': settings.recommendedIds,
      'reading_now': settings.readingIds,
    },
    goals: {'goals': goals},
    settings: {
      'theme': settings.themeId,
      'accent': settings.accentId,
      'font_scale': settings.fontScale,
      'reader_mode': settings.readerMode.name,
      'data_mode': settings.dataMode.name,
    },
  );
}

/// يكتب التصدير ملفاً في مجلد المستندات ويعيد مساره.
Future<String> writeExportFile(AccountExport export) async {
  final dir = await getApplicationDocumentsDirectory();
  final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
  final file = File('${dir.path}/senok-export-$stamp.json');
  await file.writeAsString(export.toJsonString(), encoding: utf8);
  return file.path;
}

/// «مشاركة» بلا حزمة خارجية: ينسخ نص التصدير إلى الحافظة ليلصقه المستخدم
/// أينما شاء (بريد، ملاحظات، تخزين سحابي). الملف نفسه يبقى في مجلد
/// المستندات ويمكن الوصول إليه من مدير الملفات.
Future<void> shareExportFile(String path) async {
  final text = await File(path).readAsString(encoding: utf8);
  await Clipboard.setData(ClipboardData(text: text));
}

/// ينسخ نص التصدير إلى الحافظة (بديل سريع بلا ملف).
Future<void> copyExportToClipboard(AccountExport export) async {
  await Clipboard.setData(ClipboardData(text: export.toJsonString()));
}

// ═══════════════════════════════════════════════════════════════════════════
//  حذف الحساب
// ═══════════════════════════════════════════════════════════════════════════

/// نتيجة طلب حذف الحساب.
enum DeleteAccountOutcome {
  /// حُذف محلياً وعلى الخادم.
  deletedEverywhere,

  /// حُذف محلياً فقط؛ الخادم لا يوفّر نقطة نهاية الحذف بعد.
  deletedLocalOnly,

  /// ألغى المستخدم.
  cancelled,

  /// فشل الحذف المحلي نفسه.
  failed,
}

/// يحذف الحساب: يطلب من الخادم أولاً (إن توفّرت نقطة النهاية)، ثم يمسح
/// كل البيانات المحلية (رمز الدخول + الملف + التقدّم + الإعدادات).
/// لا يحذف شيئاً قبل تأكيد المستخدم الصريح في الواجهة.
Future<DeleteAccountOutcome> deleteAccountEverywhere({
  required AccountRepository repo,
  required AuthV2Store authStore,
}) async {
  var serverDeleted = false;
  try {
    await repo.api.post('/auth/delete-account', body: {});
    serverDeleted = true;
  } on ApiException catch (e) {
    // 404 = نقطة النهاية غير موجودة: نكمل بالحذف المحلي ونبلّغ المستخدم.
    if (e.failure != ApiFailure.notFound && e.failure != ApiFailure.server) {
      return DeleteAccountOutcome.failed;
    }
  } catch (_) {
    return DeleteAccountOutcome.failed;
  }

  try {
    await authStore.signOut();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  } catch (_) {
    return DeleteAccountOutcome.failed;
  }

  return serverDeleted ? DeleteAccountOutcome.deletedEverywhere : DeleteAccountOutcome.deletedLocalOnly;
}

/// ما الذي يُحذف بالضبط؟ (للعرض في نافذة التأكيد)
const List<String> kDeleteAccountItems = [
  'حسابك ورمز دخولك على هذا الجهاز',
  'ملفك الشخصي واسمك ونبذتك',
  'تقدّم القراءة والفصول المقروءة ووقت القراءة',
  'مكتبتك: المتابَعة والمفضلة والقراءة لاحقاً',
  'أهداف القراءة ويومياتك وإعداداتك',
  'قفل PIN وجلساتك النشطة',
];

/// ما الذي لا يُحذف؟ (للعرض بصراحة)
const List<String> kDeleteAccountKeeps = [
  'الفصول التي نزّلتها على جهازك (ملفات التنزيل تبقى في مجلد التنزيلات)',
  'نسخ التصدير التي شاركتها أو حفظتها بنفسك',
];

// ═══════════════════════════════════════════════════════════════════════════
//  تسجيل الخروج
// ═══════════════════════════════════════════════════════════════════════════

/// يسجّل الخروج من كل مكان: الخادم (إن أمكن) + التخزين الآمن المحلي.
Future<bool> signOutEverywhere(AuthV2Store authStore) async {
  try {
    await authStore.signOut();
    return true;
  } catch (_) {
    return false;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شاشة إجراءات الحساب
// ═══════════════════════════════════════════════════════════════════════════

/// شاشة إجراءات الحساب: التصدير، تسجيل الخروج، وحذف الحساب (منطقة الخطر).
class AccountActionsScreen extends StatefulWidget {
  const AccountActionsScreen({
    super.key,
    required this.authStore,
    required this.settings,
    required this.accountRepo,
    this.appVersion = '0.2.0',
    this.onSignedOut,
    this.onAccountDeleted,
  });

  final AuthV2Store authStore;
  final SettingsController settings;
  final AccountRepository accountRepo;
  final String appVersion;
  final VoidCallback? onSignedOut;
  final VoidCallback? onAccountDeleted;

  @override
  State<AccountActionsScreen> createState() => _AccountActionsScreenState();
}

class _AccountActionsScreenState extends State<AccountActionsScreen> {
  bool _exporting = false;
  bool _signingOut = false;
  String? _exportPath;
  int? _exportItems;

  Future<void> _export() async {
    setState(() => _exporting = true);
    try {
      final profile = <String, dynamic>{};
      final user = widget.authStore.user;
      if (user != null) {
        profile['name'] = user.name;
        profile['email'] = user.email;
        profile['bio'] = user.bio;
      }
      final export = buildAccountExport(
        settings: widget.settings,
        appVersion: widget.appVersion,
        profile: profile,
      );
      final path = await writeExportFile(export);
      if (!mounted) return;
      setState(() {
        _exportPath = path;
        _exportItems = export.itemCount;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إنشاء نسخة التصدير.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذّر التصدير: ${friendlyAuthError(e)}')),
      );
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _signOut() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسجيل الخروج؟'),
        content: const Text(
          'سيُمسح رمز دخولك من هذا الجهاز. تقدّمك المحلي يبقى على الجهاز، '
          'لكن مزامنته مع حسابك تتوقف حتى تسجّل دخولك مجدداً.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('تسجيل الخروج'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    setState(() => _signingOut = true);
    final ok = await signOutEverywhere(widget.authStore);
    if (!mounted) return;
    setState(() => _signingOut = false);
    if (ok) {
      widget.onSignedOut?.call();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تسجيل الخروج.')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذّر تسجيل الخروج. حاول مجدداً.')),
      );
    }
  }

  Future<void> _deleteAccount() async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const DeleteAccountDialog(),
    );
    if (confirmed != true || !mounted) return;
    final outcome = await deleteAccountEverywhere(
      repo: widget.accountRepo,
      authStore: widget.authStore,
    );
    if (!mounted) return;
    switch (outcome) {
      case DeleteAccountOutcome.deletedEverywhere:
        widget.onAccountDeleted?.call();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حذف حسابك نهائياً. نتمنى لك التوفيق.')),
        );
      case DeleteAccountOutcome.deletedLocalOnly:
        widget.onAccountDeleted?.call();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'حُذفت بياناتك من هذا الجهاز. الخادم لا يوفّر حذف الحساب بعد — '
              'تواصل مع الدعم لحذف حسابك من الخادم.',
            ),
          ),
        );
      case DeleteAccountOutcome.failed:
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذّر حذف الحساب. حاول مجدداً.')),
        );
      case DeleteAccountOutcome.cancelled:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final user = widget.authStore.user;
    return Scaffold(
      appBar: AppBar(title: const Text('إجراءات الحساب')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          AuthSectionCard(
            icon: SardIcons.download_rounded,
            color: p.accent,
            title: 'تصدير بياناتي',
            note: 'نسخة JSON كاملة من ملفك وقراءتك ومكتبتك وأهدافك وإعداداتك. '
                'تُنشأ على جهازك فقط ولا تُرسل لأي خادم.',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AuthPrimaryButton(
                  label: 'إنشاء نسخة التصدير',
                  icon: SardIcons.download_rounded,
                  busy: _exporting,
                  onPressed: _export,
                ),
                if (_exportPath != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    'أُنشئت النسخة (${_exportItems ?? 0} عنصراً). المسار:',
                    style: context.ts(color: p.textDim, size: 12.5),
                  ),
                  const SizedBox(height: 4),
                  SelectableText(
                    _exportPath!,
                    style: context.ts(size: 12),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            await shareExportFile(_exportPath!);
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('نُسخ نص التصدير إلى الحافظة.')),
                              );
                            }
                          },
                          icon: const SIcon(SardIcons.share_rounded, size: 18),
                          label: const Text('نسخ نص التصدير'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            await Clipboard.setData(ClipboardData(text: _exportPath!));
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('نُسخ المسار.')),
                              );
                            }
                          },
                          icon: const SIcon(SardIcons.collections_bookmark_rounded, size: 18),
                          label: const Text('نسخ المسار'),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          AuthSectionCard(
            icon: SardIcons.logout_rounded,
            color: p.gold,
            title: 'تسجيل الخروج',
            note: user == null
                ? 'أنت غير مسجَّل حالياً.'
                : 'مسجَّل باسم ${user.displayName} (${user.email}).',
            child: AuthPrimaryButton(
              label: 'تسجيل الخروج',
              icon: SardIcons.logout_rounded,
              busy: _signingOut,
              onPressed: user == null ? null : _signOut,
            ),
          ),
          const SizedBox(height: 16),
          _dangerZone(context, p),
        ],
      ),
    );
  }

  Widget _dangerZone(BuildContext context, SardPalette p) {
    const danger = Color(0xFFE5484D);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: tint(danger, 0.06),
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: tint(danger, 0.45), width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(danger, 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const SIcon(SardIcons.delete_outline_rounded, size: 20, color: danger),
              ),
              const SizedBox(width: 10),
              Text('منطقة الخطر', style: context.ds(size: 16, color: danger)),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'حذف الحساب نهائي ولا يمكن التراجع عنه. ننصح بتصدير بياناتك أولاً.',
            style: context.ts(size: 13, height: 1.5),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _deleteAccount,
              style: FilledButton.styleFrom(
                backgroundColor: danger,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(52),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
              ),
              child: const Text('حذف الحساب نهائياً', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  نافذة تأكيد حذف الحساب (خطوتان)
// ═══════════════════════════════════════════════════════════════════════════

/// نافذة تأكيد من خطوتين: قائمة ما سيُحذف، ثم كتابة كلمة «حذف».
class DeleteAccountDialog extends StatefulWidget {
  const DeleteAccountDialog({super.key});

  @override
  State<DeleteAccountDialog> createState() => _DeleteAccountDialogState();
}

class _DeleteAccountDialogState extends State<DeleteAccountDialog> {
  final _confirm = TextEditingController();
  bool _step2 = false;

  @override
  void dispose() {
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AlertDialog(
      title: Text(_step2 ? 'تأكيد أخير' : 'حذف الحساب نهائياً؟'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!_step2) ...[
              const Text('سيُحذف نهائياً:'),
              const SizedBox(height: 8),
              for (final item in kDeleteAccountItems)
                _bullet(context, item),
              const SizedBox(height: 12),
              const Text('لن يُحذف:'),
              const SizedBox(height: 8),
              for (final item in kDeleteAccountKeeps)
                _bullet(context, item),
            ] else ...[
              const Text(
                'للتأكيد، اكتب كلمة «حذف» في الحقل أدناه. '
                'هذا الإجراء نهائي ولا يمكن التراجع عنه.',
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _confirm,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: 'حذف',
                  filled: true,
                  fillColor: p.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: p.border),
                  ),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('إلغاء'),
        ),
        if (!_step2)
          TextButton(
            onPressed: () => setState(() => _step2 = true),
            child: const Text('متابعة الحذف', style: TextStyle(color: Color(0xFFE5484D))),
          )
        else
          TextButton(
            onPressed: _confirm.text.trim() == 'حذف'
                ? () => Navigator.of(context).pop(true)
                : null,
            child: const Text('حذف نهائياً', style: TextStyle(color: Color(0xFFE5484D))),
          ),
      ],
    );
  }

  Widget _bullet(BuildContext context, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('• ', style: context.ts(w: FontWeight.w700)),
          Expanded(child: Text(text, style: context.ts(size: 13, height: 1.5))),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  قابلية نقل البيانات (شرح صيغة التصدير)
// ═══════════════════════════════════════════════════════════════════════════

/// يشرح صيغة ملف التصدير JSON للمستخدم (شفافية كاملة).
class DataPortabilityInfo {
  const DataPortabilityInfo._();

  static const List<({String section, String description})> sections = [
    (
      section: 'profile',
      description: 'اسمك وبريدك ونبذتك وصورتك الرمزية.',
    ),
    (
      section: 'reading',
      description: 'تقدّم القراءة والفصول المقروءة ووقت القراءة الإجمالي.',
    ),
    (
      section: 'library',
      description: 'الأعمال المتابَعة والمفضلة وقوائم القراءة لاحقاً.',
    ),
    (
      section: 'goals',
      description: 'أهداف القراءة وتقدّمها وسلاسل الإكمال.',
    ),
    (
      section: 'settings',
      description: 'الثيم والخط ووضع القارئ ووضع البيانات.',
    ),
  ];

  static const String note =
      'الملف بصيغة JSON القياسية — يمكنك فتحه بأي محرر نصوص أو استيراده '
      'في تطبيقات أخرى تدعم الصيغة. لا يحتوي على كلمات مرور أو رموز دخول.';
}

/// بطاقة شرح قابلية نقل البيانات (تُعرض في شاشة إجراءات الحساب).
class DataPortabilityCard extends StatelessWidget {
  const DataPortabilityCard({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SIcon(SardIcons.folder_copy_outlined, size: 20, color: p.accent),
              ),
              const SizedBox(width: 10),
              Text('ما الذي يحتويه التصدير؟', style: context.ds(size: 16)),
            ],
          ),
          const SizedBox(height: 10),
          for (final s in DataPortabilityInfo.sections)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 74,
                    child: Text(
                      s.section,
                      style: context.ts(size: 12.5, w: FontWeight.w700, color: p.accent),
                    ),
                  ),
                  Expanded(
                    child: Text(s.description, style: context.ts(size: 12.5, height: 1.5)),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 8),
          Text(
            DataPortabilityInfo.note,
            style: context.ts(color: p.textDim, size: 12.5, height: 1.6),
          ),
        ],
      ),
    );
  }
}
