import 'dart:math' as math;

import 'package:flutter/material.dart';

/// شاشة بداية Senok المتحركة — حرف S الذهبي على أزرق منتصف الليل،
/// ذرات ذهب عائمة، واسم Senok يظهر حرفاً حرفاً بخط Cairo العريض،
/// ثم «سينوك» والشعار وشريط تحميل ذهبي. مدتها ~2.8 ثانية ثم تستدعي [onDone].
class SenokSplashScreen extends StatefulWidget {
  const SenokSplashScreen({super.key, required this.onDone});

  final VoidCallback onDone;

  @override
  State<SenokSplashScreen> createState() => _SenokSplashScreenState();
}

class _SenokSplashScreenState extends State<SenokSplashScreen>
    with SingleTickerProviderStateMixin {
  static const _night = Color(0xFF0B1B33);
  static const _gold = Color(0xFFF2C14E);
  static const _goldDeep = Color(0xFFC99B2E);

  late final AnimationController _c;
  late final Animation<double> _bgIn;
  late final Animation<double> _logoIn;
  late final Animation<double> _glow;
  late final Animation<double> _nameIn;
  late final Animation<double> _subIn;
  late final Animation<double> _barIn;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    );
    _bgIn = CurvedAnimation(
      parent: _c,
      curve: const Interval(0.0, 0.25, curve: Curves.easeOut),
    );
    _logoIn = CurvedAnimation(
      parent: _c,
      curve: const Interval(0.12, 0.5, curve: Curves.easeOutBack),
    );
    _glow = CurvedAnimation(
      parent: _c,
      curve: const Interval(0.35, 1.0, curve: Curves.easeInOut),
    );
    _nameIn = CurvedAnimation(
      parent: _c,
      curve: const Interval(0.42, 0.72, curve: Curves.easeOut),
    );
    _subIn = CurvedAnimation(
      parent: _c,
      curve: const Interval(0.62, 0.85, curve: Curves.easeOut),
    );
    _barIn = CurvedAnimation(
      parent: _c,
      curve: const Interval(0.7, 1.0, curve: Curves.easeOut),
    );
    _c.forward();
    Future<void>.delayed(const Duration(milliseconds: 2900), () {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _night,
      body: AnimatedBuilder(
        animation: _c,
        builder: (context, child) {
          final pulse = 0.5 + 0.5 * math.sin(_glow.value * math.pi * 2);
          return Stack(
            fit: StackFit.expand,
            children: [
              // خلفية نظيفة (صورة) مع تعتيم ليلي.
              Opacity(
                opacity: _bgIn.value,
                child: Image.asset(
                  'assets/brand/splash_bg.webp',
                  fit: BoxFit.cover,
                  errorBuilder: (ctx, err, st) => Container(color: _night),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0, -0.25),
                    radius: 1.1,
                    colors: [
                      _night.withAlpha(40),
                      _night.withAlpha(190),
                      _night,
                    ],
                  ),
                ),
              ),
              // ذرات ذهب عائمة.
              Opacity(
                opacity: _bgIn.value,
                child: CustomPaint(
                  painter: _GoldDustPainter(_c.value, _gold),
                ),
              ),
              // المحتوى.
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(flex: 2),
                  // الشعار: الأيقونة تكبر وتتوهج.
                  Transform.scale(
                    scale: 0.7 + 0.3 * _logoIn.value,
                    child: Opacity(
                      opacity: _logoIn.value,
                      child: Container(
                        width: 148,
                        height: 148,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(36),
                          boxShadow: [
                            BoxShadow(
                              color: _gold.withAlpha(
                                (60 + 90 * pulse).round().clamp(0, 255),
                              ),
                              blurRadius: 28 + 22 * pulse,
                              spreadRadius: 2 + 6 * pulse,
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(36),
                          child: Image.asset(
                            'assets/brand/app_icon.webp',
                            fit: BoxFit.cover,
                            errorBuilder: (ctx, err, st) =>
                                Container(color: _night),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  // الاسم حرفاً حرفاً بخط Cairo العريض.
                  _StaggeredName(progress: _nameIn.value),
                  const SizedBox(height: 10),
                  Opacity(
                    opacity: _subIn.value,
                    child: const Text(
                      'سينوك',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.w700,
                        fontSize: 26,
                        color: Colors.white,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Opacity(
                    opacity: _subIn.value,
                    child: Text(
                      'حيث تبدأ الحكاية',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        color: Colors.white.withAlpha(200),
                      ),
                    ),
                  ),
                  const Spacer(flex: 2),
                  // شريط تحميل ذهبي + نص التحضير.
                  Opacity(
                    opacity: _barIn.value,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 64),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: _c.value,
                              minHeight: 4,
                              backgroundColor: Colors.white.withAlpha(40),
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                _gold,
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'جارٍ تحضير حكايتك…',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                              color: _goldDeep.withAlpha(230),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 48),
                ],
              ),
            ],
          );
        },
      ),
    );
  }
}

/// اسم Senok يظهر حرفاً حرفاً (ارتفاع متدرج + تلاشي).
class _StaggeredName extends StatelessWidget {
  const _StaggeredName({required this.progress});

  final double progress;

  static const _letters = ['S', 'e', 'n', 'o', 'k'];

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < _letters.length; i++)
          _Letter(
            letter: _letters[i],
            progress: ((progress * _letters.length) - i)
                .clamp(0.0, 1.0)
                .toDouble(),
          ),
      ],
    );
  }
}

class _Letter extends StatelessWidget {
  const _Letter({required this.letter, required this.progress});

  final String letter;
  final double progress;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: progress,
      child: Transform.translate(
        offset: Offset(0, 14 * (1 - progress)),
        child: Text(
          letter,
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.w800,
            fontSize: 46,
            color: Color(0xFFF2C14E),
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }
}

/// ذرات ذهب عائمة ترتفع ببطء.
class _GoldDustPainter extends CustomPainter {
  _GoldDustPainter(this.progress, this.color);

  final double progress;
  final Color color;

  static final _seeds = List.generate(42, (i) {
    final r = math.Random(i * 7919 + 13);
    return (
      x: r.nextDouble(),
      y: r.nextDouble(),
      s: 1.0 + r.nextDouble() * 2.6,
      p: r.nextDouble(),
    );
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    for (final seed in _seeds) {
      final drift = ((progress * 0.6 + seed.p) % 1.0);
      final x = seed.x * size.width;
      final y = (seed.y - drift * 0.25) * size.height;
      final alpha = (140 * (0.4 + 0.6 * math.sin(drift * math.pi))).round();
      paint.color = color.withAlpha(alpha.clamp(0, 255));
      canvas.drawCircle(Offset(x, y.clamp(0, size.height)), seed.s, paint);
    }
  }

  @override
  bool shouldRepaint(_GoldDustPainter old) => old.progress != progress;
}
