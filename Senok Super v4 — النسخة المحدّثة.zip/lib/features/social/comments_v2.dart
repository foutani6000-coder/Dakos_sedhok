import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// التعليقات v2 — تعليقات الفصول: سلاسل ردود، إعجابات، إبلاغ، ترقيم،
/// حجب الحرق (سبويلر)، وترشيح تلقائي قواعدي للمحتوى المسيء.
///
/// كل البيانات محلية تجريبية في هذه النسخة (تُحفظ في SharedPreferences)
/// وتُستبدل بواجهة السيرفر عند توفّرها. لا توجد أي ميزة ذكاء اصطناعي:
/// كل القواعد صريحة ومكتوبة هنا.
/// ──────────────────────────────────────────────────────────────────────────

/// صياغة زمنية عربية قصيرة: «الآن»، «قبل 5 د»، «قبل 3 س»، «قبل يومين»،
/// ثم تاريخ مختصر. تُستعمل في كل الوحدة الاجتماعية.
String socialTimeAgo(DateTime t, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final d = n.difference(t);
  if (d.isNegative) return 'الآن';
  if (d.inMinutes < 1) return 'الآن';
  if (d.inMinutes < 60) return 'قبل ${d.inMinutes} د';
  if (d.inHours < 24) return 'قبل ${d.inHours} س';
  if (d.inDays == 1) return 'أمس';
  if (d.inDays < 7) return 'قبل ${d.inDays} أيام';
  if (d.inDays < 30) return 'قبل ${d.inDays ~/ 7} أسابيع';
  return '${t.year}/${t.month.toString().padLeft(2, '0')}/${t.day.toString().padLeft(2, '0')}';
}

int _v2Seq = 0;

/// معرّف فريد أحادي الاتجاه (ميكروثانية + عدّاد) لتجنّب التصادم عند النشر السريع.
String _v2Id(String prefix) => '${prefix}_${DateTime.now().microsecondsSinceEpoch}_${_v2Seq++}';

/// الحد الأقصى لطول التعليق الواحد (بالأحرف).
const int kV2CommentMaxLength = 1000;

/// أقل فاصل زمني بين تعليقين متتاليين من المستخدم نفسه (مكافحة الإغراق).
const Duration kV2CommentMinInterval = Duration(seconds: 10);

/// كلمات تُحجب تلقائياً (قائمة قواعديّة صريحة قابلة للتوسعة من الإعدادات).
const List<String> kV2BlockedWords = <String>[
  'سبام',
  'spam',
  'احتيال',
  'رابط مزيف',
];

/// ترتيب عرض التعليقات.
enum V2CommentSort {
  newest('الأحدث', 'الأحدث أولاً'),
  oldest('الأقدم', 'الأقدم أولاً'),
  mostLiked('الأكثر إعجاباً', 'حسب عدد الإعجابات'),
  mostReplied('الأكثر نقاشاً', 'حسب عدد الردود');

  const V2CommentSort(this.label, this.description);
  final String label;
  final String description;
}

/// سبب الإبلاغ عن تعليق.
enum V2ReportReason {
  spam('إغراق أو دعاية', 'محتوى دعائي أو مكرر بلا قيمة'),
  insult('إساءة أو شتيمة', 'كلام جارح أو مهين'),
  spoiler('حرق للأحداث', 'يكشف أحداثاً لم تصل إليها بعد'),
  offTopic('خارج الموضوع', 'لا علاقة له بالفصل أو العمل'),
  other('أخرى', 'سبب آخر');

  const V2ReportReason(this.label, this.description);
  final String label;
  final String description;
}

/// بلاغ واحد عن تعليق.
class V2CommentReport {
  const V2CommentReport({
    required this.commentId,
    required this.reason,
    required this.reportedAt,
    this.note = '',
  });

  final String commentId;
  final V2ReportReason reason;
  final DateTime reportedAt;
  final String note;

  Map<String, dynamic> toJson() => {
        'commentId': commentId,
        'reason': reason.name,
        'reportedAt': reportedAt.toIso8601String(),
        'note': note,
      };

  factory V2CommentReport.fromJson(Map<String, dynamic> j) {
    final r = V2ReportReason.values.firstWhere(
      (e) => e.name == j['reason'],
      orElse: () => V2ReportReason.other,
    );
    return V2CommentReport(
      commentId: '${j['commentId']}',
      reason: r,
      reportedAt: DateTime.tryParse('${j['reportedAt']}') ?? DateTime.now(),
      note: '${j['note'] ?? ''}',
    );
  }
}

/// تعليق واحد (جذر أو رد). الردود تُحفظ داخل [replies] بعمق واحد
/// (الرد على رد يُعرض كإشارة @اسم داخل نص الرد).
class V2Comment {
  const V2Comment({
    required this.id,
    required this.seriesId,
    required this.chapter,
    required this.authorId,
    required this.authorName,
    required this.text,
    required this.createdAt,
    this.badge = SardBadge.none,
    this.likes = 0,
    this.likedByMe = false,
    this.replies = const [],
    this.spoiler = false,
    this.reported = false,
    this.reportCount = 0,
    this.hidden = false,
    this.editedAt,
    this.replyToName,
  });

  final String id;
  final String seriesId;

  /// رقم الفصل (0 = تعليق عام على العمل كله).
  final int chapter;
  final String authorId;
  final String authorName;
  final String text;
  final DateTime createdAt;
  final SardBadge badge;
  final int likes;
  final bool likedByMe;
  final List<V2Comment> replies;
  final bool spoiler;
  final bool reported;
  final int reportCount;
  final bool hidden;
  final DateTime? editedAt;
  final String? replyToName;

  /// التعليق مرئي للقارئ (غير محجوب تلقائياً بكثرة البلاغات).
  bool get visible => !hidden && reportCount < 3;

  /// هل يكشف الحرق؟ يُعرض خلف غطاء حتى يضغط القارئ «عرض».
  bool get hasSpoiler => spoiler;

  int get replyCount => replies.length;

  int get totalLikes => likes + replies.fold<int>(0, (a, r) => a + r.likes);

  V2Comment copyWith({
    String? text,
    int? likes,
    bool? likedByMe,
    List<V2Comment>? replies,
    bool? spoiler,
    bool? reported,
    int? reportCount,
    bool? hidden,
    DateTime? editedAt,
  }) {
    return V2Comment(
      id: id,
      seriesId: seriesId,
      chapter: chapter,
      authorId: authorId,
      authorName: authorName,
      text: text ?? this.text,
      createdAt: createdAt,
      badge: badge,
      likes: likes ?? this.likes,
      likedByMe: likedByMe ?? this.likedByMe,
      replies: replies ?? this.replies,
      spoiler: spoiler ?? this.spoiler,
      reported: reported ?? this.reported,
      reportCount: reportCount ?? this.reportCount,
      hidden: hidden ?? this.hidden,
      editedAt: editedAt ?? this.editedAt,
      replyToName: replyToName,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'seriesId': seriesId,
        'chapter': chapter,
        'authorId': authorId,
        'authorName': authorName,
        'text': text,
        'createdAt': createdAt.toIso8601String(),
        'badge': badge.name,
        'likes': likes,
        'likedByMe': likedByMe,
        'replies': replies.map((r) => r.toJson()).toList(),
        'spoiler': spoiler,
        'reported': reported,
        'reportCount': reportCount,
        'hidden': hidden,
        'editedAt': editedAt?.toIso8601String(),
        'replyToName': replyToName,
      };

  factory V2Comment.fromJson(Map<String, dynamic> j) {
    final badge = SardBadge.values.firstWhere(
      (e) => e.name == j['badge'],
      orElse: () => SardBadge.none,
    );
    return V2Comment(
      id: '${j['id']}',
      seriesId: '${j['seriesId']}',
      chapter: (j['chapter'] as num?)?.toInt() ?? 0,
      authorId: '${j['authorId'] ?? ''}',
      authorName: '${j['authorName'] ?? 'قارئ'}',
      text: '${j['text'] ?? ''}',
      createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
      badge: badge,
      likes: (j['likes'] as num?)?.toInt() ?? 0,
      likedByMe: j['likedByMe'] == true,
      replies: ((j['replies'] as List?) ?? const [])
          .whereType<Map>()
          .map((e) => V2Comment.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      spoiler: j['spoiler'] == true,
      reported: j['reported'] == true,
      reportCount: (j['reportCount'] as num?)?.toInt() ?? 0,
      hidden: j['hidden'] == true,
      editedAt: j['editedAt'] == null ? null : DateTime.tryParse('${j['editedAt']}'),
      replyToName: j['replyToName']?.toString(),
    );
  }
}

/// نتيجة محاولة نشر تعليق (نجاح أو سبب الرفض القواعدي).
class V2CommentResult {
  const V2CommentResult.ok(this.comment) : error = null;
  const V2CommentResult.fail(this.error) : comment = null;

  final V2Comment? comment;
  final String? error;

  bool get ok => comment != null;
}

/// إحصاءات تعليقات عمل أو فصل.
class V2CommentStats {
  const V2CommentStats({
    required this.total,
    required this.replies,
    required this.likes,
    required this.authors,
    required this.spoilerCount,
    required this.reportedCount,
  });

  final int total;
  final int replies;
  final int likes;
  final int authors;
  final int spoilerCount;
  final int reportedCount;

  static const empty = V2CommentStats(
    total: 0,
    replies: 0,
    likes: 0,
    authors: 0,
    spoilerCount: 0,
    reportedCount: 0,
  );
}

/// مخزن التعليقات v2: حفظ محلي، بذرة تجريبية، وكل عمليات التعليقات.
class CommentsV2Store extends ChangeNotifier {
  CommentsV2Store(this._p) {
    _restore();
  }

  static const String _key = 'social_comments_v2';
  static const String _reportsKey = 'social_comments_v2_reports';
  static const String _lastPostKey = 'social_comments_v2_last_post';

  final SharedPreferences _p;
  final List<V2Comment> _comments = <V2Comment>[];
  final List<V2CommentReport> _reports = <V2CommentReport>[];
  DateTime? _lastPostAt;

  /// تحميل المخزن من التخزين المحلي.
  static Future<CommentsV2Store> load() async {
    final p = await SharedPreferences.getInstance();
    return CommentsV2Store(p);
  }

  List<V2Comment> get all => List.unmodifiable(_comments);

  List<V2CommentReport> get reports => List.unmodifiable(_reports);

  void _restore() {
    try {
      final raw = _p.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        _comments
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => V2Comment.fromJson(Map<String, dynamic>.from(e))));
      }
      final rawR = _p.getString(_reportsKey);
      if (rawR != null && rawR.isNotEmpty) {
        final list = jsonDecode(rawR) as List;
        _reports
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => V2CommentReport.fromJson(Map<String, dynamic>.from(e))));
      }
      final last = _p.getString(_lastPostKey);
      _lastPostAt = last == null ? null : DateTime.tryParse(last);
    } catch (_) {
      _comments.clear();
      _reports.clear();
    }
  }

  Future<void> _save() async {
    await _p.setString(_key, jsonEncode(_comments.map((c) => c.toJson()).toList()));
    await _p.setString(_reportsKey, jsonEncode(_reports.map((r) => r.toJson()).toList()));
    if (_lastPostAt != null) {
      await _p.setString(_lastPostKey, _lastPostAt!.toIso8601String());
    }
  }

  /// يملأ بيانات تجريبية عربية عند أول فتح (إن كان المخزن فارغاً).
  /// ملاحظة للمستخدم: البيانات تجريبية محلية وتُستبدل بالسيرفر لاحقاً.
  Future<void> ensureDemo() async {
    if (_comments.isNotEmpty) return;
    final now = DateTime.now();
    final seed = <V2Comment>[
      V2Comment(
        id: 'c_demo_1',
        seriesId: 's1',
        chapter: 12,
        authorId: 'u_ahmed',
        authorName: 'أحمد',
        badge: SardBadge.blue,
        text: 'الفصل كان أسطورياً! رسم المعارك تحسّن كثيراً عن الفصول الأولى، والتفاصيل في الخلفيات مذهلة.',
        createdAt: now.subtract(const Duration(minutes: 42)),
        likes: 128,
        replies: <V2Comment>[
          V2Comment(
            id: 'c_demo_1_r1',
            seriesId: 's1',
            chapter: 12,
            authorId: 'u_sara',
            authorName: 'سارة',
            text: 'أتفق معك تماماً، خصوصاً مشهد البوابة في الصفحة الأخيرة.',
            createdAt: now.subtract(const Duration(minutes: 30)),
            likes: 21,
            replyToName: 'أحمد',
          ),
          V2Comment(
            id: 'c_demo_1_r2',
            seriesId: 's1',
            chapter: 12,
            authorId: 'u_omar',
            authorName: 'عمر',
            text: 'أنا انتظر الفصل القادم بفارغ الصبر، النهاية كانت قوية.',
            createdAt: now.subtract(const Duration(minutes: 18)),
            likes: 9,
            replyToName: 'أحمد',
          ),
        ],
      ),
      V2Comment(
        id: 'c_demo_2',
        seriesId: 's1',
        chapter: 12,
        authorId: 'u_layla',
        authorName: 'ليلى',
        text: 'من يقرأ العمل من الفصل الأول؟ تطور الشخصية الرئيسية يستحق كل هذا الانتظار.',
        createdAt: now.subtract(const Duration(hours: 2)),
        likes: 64,
      ),
      V2Comment(
        id: 'c_demo_3',
        seriesId: 's1',
        chapter: 11,
        authorId: 'u_khalid',
        authorName: 'خالد',
        badge: SardBadge.yellow,
        text: 'ترجمة هذا الفصل ممتازة، المصطلحات ثابتة والأخطاء الإملائية شبه معدومة. شكراً للمترجم.',
        createdAt: now.subtract(const Duration(hours: 5)),
        likes: 45,
        spoiler: true,
      ),
      V2Comment(
        id: 'c_demo_4',
        seriesId: 's2',
        chapter: 0,
        authorId: 'u_noura',
        authorName: 'نورة',
        text: 'بدأت العمل أمس وأنهيت عشرين فصلاً في جلسة واحدة، لا أستطيع التوقف!',
        createdAt: now.subtract(const Duration(hours: 8)),
        likes: 92,
        replies: <V2Comment>[
          V2Comment(
            id: 'c_demo_4_r1',
            seriesId: 's2',
            chapter: 0,
            authorId: 'u_youssef',
            authorName: 'يوسف',
            text: 'نفس ما حصل معي، الفصول الأولى تُدخلك في القصة بسرعة.',
            createdAt: now.subtract(const Duration(hours: 7)),
            likes: 14,
            replyToName: 'نورة',
          ),
        ],
      ),
      V2Comment(
        id: 'c_demo_5',
        seriesId: 's2',
        chapter: 3,
        authorId: 'u_huda',
        authorName: 'هدى',
        text: 'الرسم جميل لكن الإيقاع بطيء قليلاً في البداية، هل يتحسن بعد الفصل العاشر؟',
        createdAt: now.subtract(const Duration(days: 1, hours: 3)),
        likes: 17,
      ),
      V2Comment(
        id: 'c_demo_6',
        seriesId: 's1',
        chapter: 12,
        authorId: 'u_tariq',
        authorName: 'طارق',
        text: 'أفضل لحظة في الفصل: عندما عاد البطل أخيراً إلى قريته. المشهد مؤثر جداً.',
        createdAt: now.subtract(const Duration(days: 1, hours: 6)),
        likes: 38,
        spoiler: true,
      ),
    ];
    _comments.addAll(seed);
    await _save();
    notifyListeners();
  }

  // ───────── استعلامات ─────────

  /// تعليقات عمل معيّن (اختيارياً لفصل معيّن) مرتبة حسب [sort].
  List<V2Comment> forSeries(String seriesId, {int? chapter, V2CommentSort sort = V2CommentSort.newest}) {
    var list = _comments.where((c) => c.seriesId == seriesId).toList();
    if (chapter != null) list = list.where((c) => c.chapter == chapter).toList();
    return _sorted(list, sort);
  }

  List<V2Comment> _sorted(List<V2Comment> list, V2CommentSort sort) {
    final out = List<V2Comment>.from(list);
    switch (sort) {
      case V2CommentSort.newest:
        out.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      case V2CommentSort.oldest:
        out.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      case V2CommentSort.mostLiked:
        out.sort((a, b) => b.totalLikes.compareTo(a.totalLikes));
      case V2CommentSort.mostReplied:
        out.sort((a, b) => b.replyCount.compareTo(a.replyCount));
    }
    return out;
  }

  /// صفحة من التعليقات (ترقيم): [page] تبدأ من 0.
  List<V2Comment> page(String seriesId, int page, {int pageSize = 10, int? chapter, V2CommentSort sort = V2CommentSort.newest}) {
    final list = forSeries(seriesId, chapter: chapter, sort: sort);
    final start = page * pageSize;
    if (start >= list.length) return const [];
    final end = (start + pageSize).clamp(0, list.length);
    return list.sublist(start, end);
  }

  /// عدد صفحات الترقيم لعمل معيّن.
  int pageCount(String seriesId, {int pageSize = 10, int? chapter}) {
    final n = forSeries(seriesId, chapter: chapter).length;
    return (n + pageSize - 1) ~/ pageSize;
  }

  /// بحث نصي داخل تعليقات عمل (اسم الكاتب أو نص التعليق).
  List<V2Comment> search(String seriesId, String query) {
    final q = query.trim();
    if (q.isEmpty) return forSeries(seriesId);
    return _comments
        .where((c) => c.seriesId == seriesId && (c.text.contains(q) || c.authorName.contains(q)))
        .toList();
  }

  /// تعليقات كاتب معيّن (في كل الأعمال).
  List<V2Comment> byAuthor(String authorId) {
    return _comments.where((c) => c.authorId == authorId).toList();
  }

  /// أفضل التعليقات (الأكثر إعجاباً) لعمل معيّن.
  List<V2Comment> topComments(String seriesId, {int limit = 3}) {
    final list = _sorted(forSeries(seriesId), V2CommentSort.mostLiked);
    return list.take(limit).toList();
  }

  /// إحصاءات تعليقات عمل أو فصل.
  V2CommentStats stats(String seriesId, {int? chapter}) {
    final list = forSeries(seriesId, chapter: chapter);
    var replies = 0;
    var likes = 0;
    final authors = <String>{};
    var spoilers = 0;
    var reported = 0;
    for (final c in list) {
      replies += c.replyCount;
      likes += c.totalLikes;
      authors.add(c.authorId);
      if (c.spoiler) spoilers++;
      if (c.reported) reported++;
    }
    return V2CommentStats(
      total: list.length,
      replies: replies,
      likes: likes,
      authors: authors.length,
      spoilerCount: spoilers,
      reportedCount: reported,
    );
  }

  /// عدد التعليقات الظاهرة لعمل معيّن.
  int countFor(String seriesId, {int? chapter}) => forSeries(seriesId, chapter: chapter).length;

  V2Comment? byId(String id) {
    for (final c in _comments) {
      if (c.id == id) return c;
      for (final r in c.replies) {
        if (r.id == id) return r;
      }
    }
    return null;
  }

  // ───────── عمليات ─────────

  /// نشر تعليق جديد مع التحقق القواعدي (طول، إغراق، كلمات محظورة).
  Future<V2CommentResult> add({
    required String seriesId,
    required int chapter,
    required String authorId,
    required String authorName,
    required String text,
    SardBadge badge = SardBadge.none,
    bool spoiler = false,
    DateTime? at,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) return const V2CommentResult.fail('اكتب شيئاً قبل النشر.');
    if (clean.length > kV2CommentMaxLength) {
      return V2CommentResult.fail('التعليق طويل جداً (الحد $kV2CommentMaxLength حرف).');
    }
    if (_lastPostAt != null && DateTime.now().difference(_lastPostAt!) < kV2CommentMinInterval) {
      return const V2CommentResult.fail('تمهّل قليلاً قبل نشر تعليق آخر.');
    }
    final lower = clean.toLowerCase();
    for (final w in kV2BlockedWords) {
      if (lower.contains(w.toLowerCase())) {
        return const V2CommentResult.fail('يحتوي التعليق على محتوى غير مسموح.');
      }
    }
    final now = at ?? DateTime.now();
    final c = V2Comment(
      id: _v2Id('c'),
      seriesId: seriesId,
      chapter: chapter,
      authorId: authorId,
      authorName: authorName,
      text: clean,
      createdAt: now,
      badge: badge,
      spoiler: spoiler,
    );
    _comments.insert(0, c);
    _lastPostAt = now;
    await _save();
    notifyListeners();
    return V2CommentResult.ok(c);
  }

  /// رد على تعليق جذري (الرد على رد يُحوَّل إلى رد على الجذر مع إشارة @).
  Future<V2CommentResult> addReply({
    required String parentId,
    required String authorId,
    required String authorName,
    required String text,
    SardBadge badge = SardBadge.none,
    bool spoiler = false,
    DateTime? at,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) return const V2CommentResult.fail('اكتب شيئاً قبل النشر.');
    if (clean.length > kV2CommentMaxLength) {
      return V2CommentResult.fail('الرد طويل جداً (الحد $kV2CommentMaxLength حرف).');
    }
    final idx = _comments.indexWhere((c) => c.id == parentId);
    if (idx < 0) return const V2CommentResult.fail('تعذّر العثور على التعليق الأصلي.');
    final parent = _comments[idx];
    final now = at ?? DateTime.now();
    final reply = V2Comment(
      id: _v2Id('c'),
      seriesId: parent.seriesId,
      chapter: parent.chapter,
      authorId: authorId,
      authorName: authorName,
      text: clean,
      createdAt: now,
      badge: badge,
      spoiler: spoiler,
      replyToName: parent.authorName,
    );
    _comments[idx] = parent.copyWith(replies: <V2Comment>[...parent.replies, reply]);
    _lastPostAt = now;
    await _save();
    notifyListeners();
    return V2CommentResult.ok(reply);
  }

  /// تبديل الإعجاب على تعليق (جذري أو رد).
  Future<void> toggleLike(String id) async {
    for (var i = 0; i < _comments.length; i++) {
      final c = _comments[i];
      if (c.id == id) {
        _comments[i] = c.copyWith(likes: c.likedByMe ? c.likes - 1 : c.likes + 1, likedByMe: !c.likedByMe);
        await _save();
        notifyListeners();
        return;
      }
      final rIdx = c.replies.indexWhere((r) => r.id == id);
      if (rIdx >= 0) {
        final r = c.replies[rIdx];
        final next = List<V2Comment>.from(c.replies);
        next[rIdx] = r.copyWith(likes: r.likedByMe ? r.likes - 1 : r.likes + 1, likedByMe: !r.likedByMe);
        _comments[i] = c.copyWith(replies: next);
        await _save();
        notifyListeners();
        return;
      }
    }
  }

  /// تعديل نص تعليق من كاتبه (يُسجَّل وقت التعديل).
  Future<bool> edit(String id, String newText, {DateTime? at}) async {
    final clean = newText.trim();
    if (clean.isEmpty || clean.length > kV2CommentMaxLength) return false;
    for (var i = 0; i < _comments.length; i++) {
      final c = _comments[i];
      if (c.id == id) {
        _comments[i] = c.copyWith(text: clean, editedAt: at ?? DateTime.now());
        await _save();
        notifyListeners();
        return true;
      }
      final rIdx = c.replies.indexWhere((r) => r.id == id);
      if (rIdx >= 0) {
        final next = List<V2Comment>.from(c.replies);
        next[rIdx] = c.replies[rIdx].copyWith(text: clean, editedAt: at ?? DateTime.now());
        _comments[i] = c.copyWith(replies: next);
        await _save();
        notifyListeners();
        return true;
      }
    }
    return false;
  }

  /// حذف تعليق (جذري مع ردوده) أو رد واحد.
  Future<bool> delete(String id) async {
    final before = _comments.length;
    _comments.removeWhere((c) => c.id == id);
    if (_comments.length != before) {
      await _save();
      notifyListeners();
      return true;
    }
    for (var i = 0; i < _comments.length; i++) {
      final c = _comments[i];
      final next = c.replies.where((r) => r.id != id).toList();
      if (next.length != c.replies.length) {
        _comments[i] = c.copyWith(replies: next);
        await _save();
        notifyListeners();
        return true;
      }
    }
    return false;
  }

  /// الإبلاغ عن تعليق. عند 3 بلاغات يُحجب تلقائياً حتى مراجعة المشرف.
  Future<void> report(String id, V2ReportReason reason, {String note = ''}) async {
    final now = DateTime.now();
    _reports.add(V2CommentReport(commentId: id, reason: reason, reportedAt: now, note: note));
    for (var i = 0; i < _comments.length; i++) {
      final c = _comments[i];
      if (c.id == id) {
        final count = c.reportCount + 1;
        _comments[i] = c.copyWith(reported: true, reportCount: count, hidden: count >= 3);
        break;
      }
      final rIdx = c.replies.indexWhere((r) => r.id == id);
      if (rIdx >= 0) {
        final next = List<V2Comment>.from(c.replies);
        final r = next[rIdx];
        final count = r.reportCount + 1;
        next[rIdx] = r.copyWith(reported: true, reportCount: count, hidden: count >= 3);
        _comments[i] = c.copyWith(replies: next);
        break;
      }
    }
    await _save();
    notifyListeners();
  }

  /// إلغاء حجب تعليق (للمشرف).
  Future<void> unhide(String id) async {
    for (var i = 0; i < _comments.length; i++) {
      final c = _comments[i];
      if (c.id == id) {
        _comments[i] = c.copyWith(hidden: false, reported: false, reportCount: 0);
        await _save();
        notifyListeners();
        return;
      }
    }
  }

  /// مسح كل التعليقات (لإعادة الضبط من الإعدادات).
  Future<void> clearAll() async {
    _comments.clear();
    _reports.clear();
    await _save();
    notifyListeners();
  }
}

/// ───────── الواجهات ─────────

/// شاشة تعليقات فصل أو عمل: ترتيب، بحث، ترقيم، وصندوق كتابة.
class CommentsV2Screen extends StatefulWidget {
  const CommentsV2Screen({
    super.key,
    required this.store,
    required this.series,
    this.chapter = 0,
    this.myId = 'me',
    this.myName = 'أنا',
    this.myBadge = SardBadge.none,
  });

  final CommentsV2Store store;
  final Series series;
  final int chapter;
  final String myId;
  final String myName;
  final SardBadge myBadge;

  @override
  State<CommentsV2Screen> createState() => _CommentsV2ScreenState();
}

class _CommentsV2ScreenState extends State<CommentsV2Screen> {
  V2CommentSort _sort = V2CommentSort.newest;
  String _query = '';
  int _page = 0;
  static const int _pageSize = 10;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<V2Comment> get _list {
    if (_query.trim().isNotEmpty) return widget.store.search(widget.series.id, _query);
    return widget.store.page(widget.series.id, _page, pageSize: _pageSize, chapter: widget.chapter == 0 ? null : widget.chapter, sort: _sort);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final stats = widget.store.stats(widget.series.id, chapter: widget.chapter == 0 ? null : widget.chapter);
    final pages = widget.store.pageCount(widget.series.id, pageSize: _pageSize, chapter: widget.chapter == 0 ? null : widget.chapter);
    final list = _list;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text(widget.chapter > 0 ? 'تعليقات الفصل ${widget.chapter}' : 'تعليقات «${widget.series.title}»'),
        actions: [
          IconButton(
            onPressed: () => _showSortSheet(context),
            icon: const SIcon(SardIcons.tune_rounded),
            tooltip: 'ترتيب التعليقات',
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          return Column(
            children: [
              _CommentStatsRow(stats: stats),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _query = v),
                  decoration: InputDecoration(
                    hintText: 'ابحث في التعليقات…',
                    prefixIcon: const SIcon(SardIcons.search_rounded, size: 20),
                    suffixIcon: _query.isEmpty
                        ? null
                        : IconButton(
                            onPressed: () => setState(() {
                              _query = '';
                              _searchCtrl.clear();
                            }),
                            icon: const SIcon(SardIcons.close_rounded, size: 18),
                          ),
                    filled: true,
                    fillColor: p.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(p.r(0.8)),
                      borderSide: BorderSide(color: p.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(p.r(0.8)),
                      borderSide: BorderSide(color: p.border),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? _EmptyComments(onWrite: () => _focusComposer(context))
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, i) {
                          final c = list[i];
                          return V2CommentTile(
                            comment: c,
                            store: widget.store,
                            myId: widget.myId,
                            onReply: (parent) => _showComposer(context, parent: parent),
                          );
                        },
                      ),
              ),
              if (_query.isEmpty && pages > 1)
                _Pager(
                  page: _page,
                  pages: pages,
                  onPrev: _page > 0 ? () => setState(() => _page--) : null,
                  onNext: _page < pages - 1 ? () => setState(() => _page++) : null,
                ),
              V2CommentComposer(
                store: widget.store,
                seriesId: widget.series.id,
                chapter: widget.chapter,
                myId: widget.myId,
                myName: widget.myName,
                myBadge: widget.myBadge,
              ),
            ],
          );
        },
      ),
    );
  }

  void _focusComposer(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('اكتب تعليقك في الصندوق بالأسفل.')),
    );
  }

  void _showSortSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => V2CommentSortSheet(
        current: _sort,
        onPick: (s) => setState(() {
          _sort = s;
          _page = 0;
        }),
      ),
    );
  }

  void _showComposer(BuildContext context, {required V2Comment parent}) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
        child: V2CommentComposer(
          store: widget.store,
          seriesId: widget.series.id,
          chapter: widget.chapter,
          myId: widget.myId,
          myName: widget.myName,
          myBadge: widget.myBadge,
          replyTo: parent,
        ),
      ),
    );
  }
}

/// صف إحصاءات صغير أعلى قائمة التعليقات.
class _CommentStatsRow extends StatelessWidget {
  const _CommentStatsRow({required this.stats});
  final V2CommentStats stats;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          _stat(context, SardIcons.chat_bubble_rounded, '${stats.total} تعليق'),
          const SizedBox(width: 12),
          _stat(context, SardIcons.reply_rounded, '${stats.replies} رد'),
          const SizedBox(width: 12),
          _stat(context, SardIcons.favorite_rounded, '${formatCount(stats.likes)} إعجاب'),
          const Spacer(),
          Text(
            '${stats.authors} مشارك',
            style: context.ts(size: 12, color: p.textDim),
          ),
        ],
      ),
    );
  }

  Widget _stat(BuildContext context, SIconData icon, String label) {
    final p = context.pal;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SIcon(icon, size: 15, color: p.accent),
        const SizedBox(width: 4),
        Text(label, style: context.ts(size: 12.5, w: FontWeight.w700)),
      ],
    );
  }
}

/// ترقيم الصفحات: السابق / التالي مع رقم الصفحة الحالية.
class _Pager extends StatelessWidget {
  const _Pager({required this.page, required this.pages, this.onPrev, this.onNext});
  final int page;
  final int pages;
  final VoidCallback? onPrev;
  final VoidCallback? onNext;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          FilledButton.tonalIcon(
            onPressed: onPrev,
            icon: const SIcon(SardIcons.chevron_right_rounded, size: 18),
            label: const Text('السابق'),
          ),
          const SizedBox(width: 12),
          Text('صفحة ${page + 1} من $pages', style: context.ts(size: 13, color: p.textDim)),
          const SizedBox(width: 12),
          FilledButton.tonalIcon(
            onPressed: onNext,
            icon: const SIcon(SardIcons.chevron_left_rounded, size: 18),
            label: const Text('التالي'),
          ),
        ],
      ),
    );
  }
}

/// حالة فارغة عندما لا توجد تعليقات بعد.
class _EmptyComments extends StatelessWidget {
  const _EmptyComments({required this.onWrite});
  final VoidCallback onWrite;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: tint(p.accent, 0.12), shape: BoxShape.circle),
              child: SIcon(SardIcons.chat_bubble_outline_rounded, size: 34, color: p.accent),
            ),
            const SizedBox(height: 16),
            Text('لا تعليقات بعد', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'كن أول من يشارك رأيه في هذا الفصل.',
              style: context.ts(size: 13.5, color: p.textDim),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: onWrite,
              icon: const SIcon(SardIcons.edit_rounded, size: 18),
              label: const Text('اكتب أول تعليق'),
            ),
          ],
        ),
      ),
    );
  }
}

/// ورقة اختيار ترتيب التعليقات.
class V2CommentSortSheet extends StatelessWidget {
  const V2CommentSortSheet({super.key, required this.current, required this.onPick});
  final V2CommentSort current;
  final ValueChanged<V2CommentSort> onPick;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ترتيب التعليقات', style: context.ds(size: 18)),
            const SizedBox(height: 12),
            for (final s in V2CommentSort.values)
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.label, style: context.ts(size: 15, w: FontWeight.w700)),
                subtitle: Text(s.description, style: context.ts(size: 12.5, color: p.textDim)),
                trailing: s == current
                    ? SIcon(SardIcons.check_circle_rounded, color: p.accent)
                    : const SIcon(SardIcons.check_rounded, size: 0, color: Colors.transparent),
                onTap: () {
                  Navigator.of(context).pop();
                  onPick(s);
                },
              ),
          ],
        ),
      ),
    );
  }
}

/// صندوق كتابة تعليق (أو رد) مع مفتاح الحرق وعدّاد الأحرف.
class V2CommentComposer extends StatefulWidget {
  const V2CommentComposer({
    super.key,
    required this.store,
    required this.seriesId,
    required this.chapter,
    required this.myId,
    required this.myName,
    this.myBadge = SardBadge.none,
    this.replyTo,
  });

  final CommentsV2Store store;
  final String seriesId;
  final int chapter;
  final String myId;
  final String myName;
  final SardBadge myBadge;
  final V2Comment? replyTo;

  @override
  State<V2CommentComposer> createState() => _V2CommentComposerState();
}

class _V2CommentComposerState extends State<V2CommentComposer> {
  final TextEditingController _ctrl = TextEditingController();
  bool _spoiler = false;
  bool _busy = false;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final isReply = widget.replyTo != null;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: p.surface,
        border: Border(top: BorderSide(color: p.border)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isReply)
              Row(
                children: [
                  SIcon(SardIcons.reply_rounded, size: 16, color: p.accent),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'رد على ${widget.replyTo!.authorName}',
                      style: context.ts(size: 12.5, color: p.textDim),
                    ),
                  ),
                  InkWell(
                    onTap: () => Navigator.of(context).maybePop(),
                    child: const SIcon(SardIcons.close_rounded, size: 18),
                  ),
                ],
              ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    maxLines: 4,
                    minLines: 1,
                    maxLength: kV2CommentMaxLength,
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      hintText: isReply ? 'اكتب ردك…' : 'شارك رأيك في هذا الفصل…',
                      counterText: '${_ctrl.text.length}/$kV2CommentMaxLength',
                      counterStyle: context.ts(size: 11, color: p.textDim),
                      filled: true,
                      fillColor: p.bg,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(p.r(0.9)),
                        borderSide: BorderSide(color: p.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(p.r(0.9)),
                        borderSide: BorderSide(color: p.border),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: _busy ? null : _submit,
                  style: FilledButton.styleFrom(
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(12),
                    minimumSize: const Size(48, 48),
                  ),
                  child: const SIcon(SardIcons.send_rounded, size: 20),
                ),
              ],
            ),
            Row(
              children: [
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => setState(() => _spoiler = !_spoiler),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SIcon(
                          _spoiler ? SardIcons.visibility_off_outlined : SardIcons.visibility_outlined,
                          size: 16,
                          color: _spoiler ? p.accent : p.textDim,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'يحتوي حرقاً',
                          style: context.ts(size: 12, color: _spoiler ? p.accent : p.textDim, w: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                Text(
                  'التعليقات تجريبية محلية',
                  style: context.ts(size: 11, color: p.textDim),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    if (_ctrl.text.trim().isEmpty) return;
    setState(() => _busy = true);
    final V2CommentResult result;
    if (widget.replyTo != null) {
      result = await widget.store.addReply(
        parentId: widget.replyTo!.id,
        authorId: widget.myId,
        authorName: widget.myName,
        text: _ctrl.text,
        badge: widget.myBadge,
        spoiler: _spoiler,
      );
    } else {
      result = await widget.store.add(
        seriesId: widget.seriesId,
        chapter: widget.chapter,
        authorId: widget.myId,
        authorName: widget.myName,
        text: _ctrl.text,
        badge: widget.myBadge,
        spoiler: _spoiler,
      );
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (result.ok) {
      _ctrl.clear();
      setState(() => _spoiler = false);
      if (widget.replyTo != null) Navigator.of(context).maybePop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم نشر تعليقك.')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.error ?? 'تعذّر النشر.')),
      );
    }
  }
}

/// بطاقة تعليق واحد مع ردوده (مطوية بعد أول ردين) وأزرار التفاعل.
class V2CommentTile extends StatefulWidget {
  const V2CommentTile({
    super.key,
    required this.comment,
    required this.store,
    required this.myId,
    required this.onReply,
  });

  final V2Comment comment;
  final CommentsV2Store store;
  final String myId;
  final ValueChanged<V2Comment> onReply;

  @override
  State<V2CommentTile> createState() => _V2CommentTileState();
}

class _V2CommentTileState extends State<V2CommentTile> {
  bool _showSpoiler = false;
  bool _showAllReplies = false;
  bool _showReplies = true;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = widget.comment;
    final mine = c.authorId == widget.myId;
    final replies = _showAllReplies ? c.replies : c.replies.take(2).toList();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _AuthorAvatar(name: c.authorName, badge: c.badge),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            c.authorName,
                            style: context.ts(size: 13.5, w: FontWeight.w700),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (!c.badge.isNone) ...[
                          const SizedBox(width: 4),
                          _BadgeChip(badge: c.badge),
                        ],
                        if (mine) ...[
                          const SizedBox(width: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                              color: tint(p.gold, 0.18),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text('أنت', style: context.ts(size: 10.5, color: p.gold, w: FontWeight.w700)),
                          ),
                        ],
                      ],
                    ),
                    Text(
                      '${socialTimeAgo(c.createdAt)}${c.editedAt != null ? ' · عُدِّل' : ''}',
                      style: context.ts(size: 11.5, color: p.textDim),
                    ),
                  ],
                ),
              ),
              _CommentMenu(
                comment: c,
                mine: mine,
                store: widget.store,
                onEdit: () => _showEditSheet(context, c),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (!c.visible)
            _HiddenNotice(onAppeal: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('أُرسل التعليق للمراجعة، وسيظهر بعد موافقة المشرف.')),
              );
            })
          else if (c.hasSpoiler && !_showSpoiler)
            _SpoilerCover(
              onShow: () => setState(() => _showSpoiler = true),
            )
          else
            Text(c.text, style: context.ts(size: 14, height: 1.5)),
          const SizedBox(height: 10),
          Row(
            children: [
              _LikeButton(
                liked: c.likedByMe,
                count: c.likes,
                onTap: () => widget.store.toggleLike(c.id),
              ),
              const SizedBox(width: 16),
              InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () => widget.onReply(c),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(SardIcons.reply_rounded, size: 17, color: p.textDim),
                      const SizedBox(width: 4),
                      Text('رد (${c.replyCount})', style: context.ts(size: 12.5, color: p.textDim, w: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              if (c.replyCount > 0)
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => setState(() => _showReplies = !_showReplies),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _showReplies ? 'إخفاء الردود' : 'عرض الردود',
                          style: context.ts(size: 12, color: p.accent, w: FontWeight.w700),
                        ),
                        SIcon(
                          _showReplies ? SardIcons.expand_less_rounded : SardIcons.expand_more_rounded,
                          size: 16,
                          color: p.accent,
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          if (_showReplies && c.replies.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsetsDirectional.only(start: 10),
              decoration: BoxDecoration(
                border: BorderDirectional(
                  start: BorderSide(color: p.border, width: 2),
                ),
              ),
              child: Column(
                children: [
                  for (final r in replies)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _ReplyRow(reply: r, store: widget.store, myId: widget.myId, onReply: widget.onReply),
                    ),
                  if (c.replies.length > 2 && !_showAllReplies)
                    TextButton(
                      onPressed: () => setState(() => _showAllReplies = true),
                      child: Text('عرض كل الردود (${c.replies.length})'),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  void _showEditSheet(BuildContext context, V2Comment c) {
    final ctrl = TextEditingController(text: c.text);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 16,
          bottom: MediaQuery.viewInsetsOf(context).bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('تعديل التعليق', style: context.ds(size: 18)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              maxLines: 5,
              maxLength: kV2CommentMaxLength,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () async {
                  final ok = await widget.store.edit(c.id, ctrl.text);
                  if (context.mounted) {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(ok ? 'تم التعديل.' : 'تعذّر التعديل.')),
                    );
                  }
                },
                child: const Text('حفظ التعديل'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// صف رد واحد داخل سلسلة الردود.
class _ReplyRow extends StatelessWidget {
  const _ReplyRow({required this.reply, required this.store, required this.myId, required this.onReply});
  final V2Comment reply;
  final CommentsV2Store store;
  final String myId;
  final ValueChanged<V2Comment> onReply;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final mine = reply.authorId == myId;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: p.bg,
        borderRadius: BorderRadius.circular(p.r(0.7)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _AuthorAvatar(name: reply.authorName, badge: reply.badge, small: true),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  reply.authorName,
                  style: context.ts(size: 12.5, w: FontWeight.w700),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                socialTimeAgo(reply.createdAt),
                style: context.ts(size: 11, color: p.textDim),
              ),
            ],
          ),
          const SizedBox(height: 6),
          if (reply.replyToName != null)
            Text(
              '@${reply.replyToName}',
              style: context.ts(size: 12, color: p.accent, w: FontWeight.w700),
            ),
          if (!reply.visible)
            const _HiddenNotice()
          else
            Text(reply.text, style: context.ts(size: 13.5, height: 1.5)),
          const SizedBox(height: 6),
          Row(
            children: [
              _LikeButton(
                liked: reply.likedByMe,
                count: reply.likes,
                small: true,
                onTap: () => store.toggleLike(reply.id),
              ),
              const SizedBox(width: 12),
              if (mine)
                InkWell(
                  onTap: () => store.delete(reply.id),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(SardIcons.delete_outline_rounded, size: 15, color: p.textDim),
                      const SizedBox(width: 2),
                      Text('حذف', style: context.ts(size: 11.5, color: p.textDim)),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// زر إعجاب صغير مع العدّاد.
class _LikeButton extends StatelessWidget {
  const _LikeButton({required this.liked, required this.count, required this.onTap, this.small = false});
  final bool liked;
  final int count;
  final VoidCallback onTap;
  final bool small;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SIcon(
              liked ? SardIcons.favorite_rounded : SardIcons.favorite_border_rounded,
              size: small ? 15 : 17,
              color: liked ? const Color(0xFFE5484D) : p.textDim,
            ),
            const SizedBox(width: 4),
            Text(
              formatCount(count),
              style: context.ts(size: small ? 11.5 : 12.5, color: liked ? const Color(0xFFE5484D) : p.textDim, w: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}

/// صورة رمزية دائرية بالحرف الأول من الاسم.
class _AuthorAvatar extends StatelessWidget {
  const _AuthorAvatar({required this.name, required this.badge, this.small = false});
  final String name;
  final SardBadge badge;
  final bool small;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final size = small ? 28.0 : 36.0;
    final color = badge == SardBadge.purple
        ? const Color(0xFF7C4DFF)
        : badge == SardBadge.blue
            ? const Color(0xFF3B9EFF)
            : badge == SardBadge.yellow
                ? p.gold
                : p.accent;
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: tint(color, 0.14),
        shape: BoxShape.circle,
        border: Border.all(color: tint(color, 0.35)),
      ),
      child: Text(
        name.isEmpty ? '؟' : name.characters.first,
        style: context.ds(size: small ? 13 : 16, color: color),
      ),
    );
  }
}

/// شارة توثيق صغيرة بجانب الاسم.
class _BadgeChip extends StatelessWidget {
  const _BadgeChip({required this.badge});
  final SardBadge badge;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = badge == SardBadge.purple
        ? const Color(0xFF7C4DFF)
        : badge == SardBadge.blue
            ? const Color(0xFF3B9EFF)
            : p.gold;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        color: tint(color, 0.14),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(SardIcons.verified_user_outlined, size: 11, color: color),
          const SizedBox(width: 2),
          Text(badge.label, style: context.ts(size: 10, color: color, w: FontWeight.w700)),
        ],
      ),
    );
  }
}

/// غطاء الحرق: يخفي النص حتى يضغط القارئ.
class _SpoilerCover extends StatelessWidget {
  const _SpoilerCover({required this.onShow});
  final VoidCallback onShow;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      borderRadius: BorderRadius.circular(p.r(0.7)),
      onTap: onShow,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        decoration: BoxDecoration(
          color: tint(p.gold, 0.10),
          borderRadius: BorderRadius.circular(p.r(0.7)),
          border: Border.all(color: tint(p.gold, 0.35), style: BorderStyle.solid),
        ),
        child: Row(
          children: [
            SIcon(SardIcons.visibility_off_outlined, size: 18, color: p.gold),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'هذا التعليق يحتوي حرقاً للأحداث — اضغط لعرضه',
                style: context.ts(size: 13, color: p.textDim, w: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// إشعار أن التعليق محجوب لكثرة البلاغات.
class _HiddenNotice extends StatelessWidget {
  const _HiddenNotice({this.onAppeal});
  final VoidCallback? onAppeal;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: tint(const Color(0xFFE5484D), 0.08),
        borderRadius: BorderRadius.circular(p.r(0.7)),
      ),
      child: Row(
        children: [
          const SIcon(SardIcons.shield_rounded, size: 16, color: Color(0xFFE5484D)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'حُجب هذا التعليق بعد بلاغات متعددة وينتظر مراجعة المشرف.',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
          ),
          if (onAppeal != null)
            TextButton(onPressed: onAppeal, child: const Text('اعتراض')),
        ],
      ),
    );
  }
}

/// قائمة خيارات التعليق (تعديل/حذف/إبلاغ).
class _CommentMenu extends StatelessWidget {
  const _CommentMenu({required this.comment, required this.mine, required this.store, required this.onEdit});
  final V2Comment comment;
  final bool mine;
  final CommentsV2Store store;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return PopupMenuButton<String>(
      icon: SIcon(SardIcons.tune_rounded, size: 18, color: p.textDim),
      tooltip: 'خيارات التعليق',
      onSelected: (v) async {
        if (v == 'edit') {
          onEdit();
        } else if (v == 'delete') {
          final ok = await store.delete(comment.id);
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(ok ? 'تم حذف التعليق.' : 'تعذّر الحذف.')),
            );
          }
        } else if (v == 'report') {
          if (context.mounted) _showReportSheet(context);
        }
      },
      itemBuilder: (context) => [
        if (mine)
          const PopupMenuItem(value: 'edit', child: Text('تعديل التعليق')),
        if (mine)
          const PopupMenuItem(value: 'delete', child: Text('حذف التعليق')),
        if (!mine)
          const PopupMenuItem(value: 'report', child: Text('الإبلاغ عن التعليق')),
      ],
    );
  }

  void _showReportSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => V2ReportSheet(
        onPick: (reason) async {
          await store.report(comment.id, reason);
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('شكراً، وصل بلاغك وسيُراجع.')),
            );
          }
        },
      ),
    );
  }
}

/// ورقة اختيار سبب الإبلاغ.
class V2ReportSheet extends StatelessWidget {
  const V2ReportSheet({super.key, required this.onPick});
  final ValueChanged<V2ReportReason> onPick;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('الإبلاغ عن تعليق', style: context.ds(size: 18)),
            const SizedBox(height: 4),
            Text(
              'اختر السبب، وسيُراجع المشرفون البلاغ. التعليق الذي يجمع 3 بلاغات يُحجب تلقائياً.',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
            const SizedBox(height: 12),
            for (final r in V2ReportReason.values)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: SIcon(SardIcons.shield_rounded, size: 20, color: p.accent),
                title: Text(r.label, style: context.ts(size: 14.5, w: FontWeight.w700)),
                subtitle: Text(r.description, style: context.ts(size: 12, color: p.textDim)),
                onTap: () {
                  Navigator.of(context).pop();
                  onPick(r);
                },
              ),
          ],
        ),
      ),
    );
  }
}
