import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/sard_icons.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// بطاقات المشاركة — توليد نصوص وروابط مشاركة (senok://) وبطاقات مرئية
/// قابلة للحفظ: عمل، فصل، اقتباس، إنجاز، وإحصاءات قراءة.
///
/// لا تُرسل البطاقات تلقائياً لأي خدمة: التطبيق يجهّز النص والرابط فقط،
/// والمستخدم يختار أين يشاركها. كل البيانات محلية.
/// ──────────────────────────────────────────────────────────────────────────

int _scSeq = 0;
String _scId() => 'sc_${DateTime.now().microsecondsSinceEpoch}_${_scSeq++}';

/// نوع بطاقة المشاركة.
enum ShareCardKind {
  series('عمل', 'بطاقة تعريف بعمل كامل'),
  chapter('فصل', 'بطاقة فصل أنهيت قراءته'),
  quote('اقتباس', 'بطاقة اقتباس من فصل'),
  achievement('إنجاز', 'بطاقة إنجاز فتحته'),
  stats('إحصاءاتي', 'بطاقة ملخص قراءتي');

  const ShareCardKind(this.label, this.description);
  final String label;
  final String description;
}

/// سمة لونية لبطاقة المشاركة.
enum ShareCardTheme {
  ink('حبر', 'ألوان الهوية: حبر وورق وختم قرمزي'),
  gold('ذهب', 'ذهبي فاخر على أزرق منتصف الليل'),
  night('ليل', 'أسود عميق مع توهج قرمزي'),
  sakura('ساكورا', 'وردي فاتح ناعم'),
  ocean('محيط', 'أزرق بحري هادئ');

  const ShareCardTheme(this.label, this.description);
  final String label;
  final String description;

  Color get background {
    switch (this) {
      case ShareCardTheme.ink:
        return const Color(0xFFF5F0E6);
      case ShareCardTheme.gold:
        return const Color(0xFF0B1B33);
      case ShareCardTheme.night:
        return const Color(0xFF080706);
      case ShareCardTheme.sakura:
        return const Color(0xFFFFF1F4);
      case ShareCardTheme.ocean:
        return const Color(0xFF07161F);
    }
  }

  Color get foreground {
    switch (this) {
      case ShareCardTheme.ink:
        return const Color(0xFF1C1612);
      case ShareCardTheme.gold:
        return const Color(0xFFF8F3EA);
      case ShareCardTheme.night:
        return const Color(0xFFF8F3EA);
      case ShareCardTheme.sakura:
        return const Color(0xFF3A1824);
      case ShareCardTheme.ocean:
        return const Color(0xFFEAF7FB);
    }
  }

  Color get accent {
    switch (this) {
      case ShareCardTheme.ink:
        return const Color(0xFFE63E2A);
      case ShareCardTheme.gold:
        return const Color(0xFFE9B44C);
      case ShareCardTheme.night:
        return const Color(0xFFFF5A3F);
      case ShareCardTheme.sakura:
        return const Color(0xFFE0457B);
      case ShareCardTheme.ocean:
        return const Color(0xFF22C7D6);
    }
  }

  Color get muted {
    switch (this) {
      case ShareCardTheme.ink:
        return const Color(0xFF7B6F62);
      case ShareCardTheme.gold:
        return const Color(0xFF9DB4D0);
      case ShareCardTheme.night:
        return const Color(0xFF8F857A);
      case ShareCardTheme.sakura:
        return const Color(0xFF9A6B7A);
      case ShareCardTheme.ocean:
        return const Color(0xFF86AFC0);
    }
  }
}

/// بيانات بطاقة مشاركة واحدة.
class ShareCardData {
  const ShareCardData({
    required this.id,
    required this.kind,
    required this.theme,
    required this.title,
    required this.createdAt,
    this.seriesId,
    this.seriesTitle,
    this.chapter,
    this.quote,
    this.rating,
    this.achievementTitle,
    this.statLabel,
    this.statValue,
  });

  final String id;
  final ShareCardKind kind;
  final ShareCardTheme theme;
  final String title;
  final DateTime createdAt;
  final String? seriesId;
  final String? seriesTitle;
  final int? chapter;
  final String? quote;
  final int? rating;
  final String? achievementTitle;
  final String? statLabel;
  final String? statValue;

  /// نص المشاركة الجاهز للنسخ (عربي + رابط عميق + وسم).
  String get shareText => ShareTextBuilder.forCard(this);

  /// الرابط العميق للعمل (إن وُجد).
  String? get deepLink => seriesId == null ? null : ShareTextBuilder.seriesLink(seriesId!);

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'theme': theme.name,
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'seriesId': seriesId,
        'seriesTitle': seriesTitle,
        'chapter': chapter,
        'quote': quote,
        'rating': rating,
        'achievementTitle': achievementTitle,
        'statLabel': statLabel,
        'statValue': statValue,
      };

  factory ShareCardData.fromJson(Map<String, dynamic> j) {
    final kind = ShareCardKind.values.firstWhere(
      (e) => e.name == j['kind'],
      orElse: () => ShareCardKind.series,
    );
    final theme = ShareCardTheme.values.firstWhere(
      (e) => e.name == j['theme'],
      orElse: () => ShareCardTheme.ink,
    );
    return ShareCardData(
      id: '${j['id']}',
      kind: kind,
      theme: theme,
      title: '${j['title'] ?? ''}',
      createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
      seriesId: j['seriesId']?.toString(),
      seriesTitle: j['seriesTitle']?.toString(),
      chapter: (j['chapter'] as num?)?.toInt(),
      quote: j['quote']?.toString(),
      rating: (j['rating'] as num?)?.toInt(),
      achievementTitle: j['achievementTitle']?.toString(),
      statLabel: j['statLabel']?.toString(),
      statValue: j['statValue']?.toString(),
    );
  }
}

/// مولّد نصوص وروابط المشاركة (منطق قواعدي بحت).
class ShareTextBuilder {
  ShareTextBuilder._();

  /// رابط عميق لعمل.
  static String seriesLink(String seriesId) => 'senok://series/$seriesId';

  /// رابط عميق لفصل.
  static String chapterLink(String seriesId, int chapter) => 'senok://series/$seriesId/chapter/$chapter';

  /// رابط دائرة قراءة.
  static String circleLink(String inviteCode) => 'senok://circle/$inviteCode';

  /// وسوم المشاركة حسب نوع العمل.
  static List<String> hashtagsFor(Series series) {
    final tags = <String>['سينوك', 'مانهوا'];
    if (series.type.contains('مانغا')) tags.add('مانغا');
    if (series.type.contains('مانهوا')) tags.add('مانهوا_كورية');
    for (final g in series.genres.take(2)) {
      tags.add(g.replaceAll(' ', '_'));
    }
    return tags;
  }

  static String _tagsLine(List<String> tags) => tags.map((t) => '#$t').join(' ');

  /// نص مشاركة عمل.
  static String seriesShareText(Series series) {
    final sb = StringBuffer();
    sb.writeln('أقرأ الآن «${series.title}» على Senok 📖');
    if (series.synopsis.isNotEmpty) {
      final s = series.synopsis.length > 120 ? '${series.synopsis.substring(0, 120)}…' : series.synopsis;
      sb.writeln(s);
    }
    sb.writeln('التقييم: ${series.rating.toStringAsFixed(1)} ⭐ · ${formatCount(series.views)} مشاهدة');
    sb.writeln(seriesLink(series.id));
    sb.write(_tagsLine(hashtagsFor(series)));
    return sb.toString();
  }

  /// نص مشاركة فصل منتهٍ.
  static String chapterShareText(Series series, int chapter) {
    return 'أنهيت الفصل $chapter من «${series.title}» على Senok!\n'
        '${chapterLink(series.id, chapter)}\n'
        '${_tagsLine(hashtagsFor(series))}';
  }

  /// نص مشاركة اقتباس.
  static String quoteShareText(Series series, int chapter, String quote) {
    return '«$quote»\n— من الفصل $chapter، «${series.title}»\n'
        '${seriesLink(series.id)}\n'
        '${_tagsLine(hashtagsFor(series))}';
  }

  /// نص مشاركة إنجاز.
  static String achievementShareText(String achievementTitle, {String? seriesTitle}) {
    final work = seriesTitle == null ? '' : ' في «$seriesTitle»';
    return 'فتحت إنجاز «$achievementTitle»$work على Senok! 🏆\n'
        'حمّل التطبيق وابدأ رحلتك: senok://app\n'
        '#سينوك #إنجازات';
  }

  /// نص مشاركة إحصاءات.
  static String statsShareText({required int chapters, required int minutes, required int streakDays}) {
    return 'ملخص قراءتي على Senok هذا الأسبوع:\n'
        '📖 $chapters فصلاً · ⏱ $minutes دقيقة · 🔥 سلسلة $streakDays يوماً\n'
        '#سينوك #قراءة';
  }

  /// نص مشاركة عام لأي بطاقة.
  static String forCard(ShareCardData card) {
    switch (card.kind) {
      case ShareCardKind.series:
        return 'أقرأ «${card.seriesTitle ?? card.title}» على Senok 📖\n${card.deepLink ?? ''}\n#سينوك';
      case ShareCardKind.chapter:
        return 'أنهيت الفصل ${card.chapter ?? ''} من «${card.seriesTitle ?? ''}» على Senok!\n${card.deepLink ?? ''}\n#سينوك';
      case ShareCardKind.quote:
        return '«${card.quote ?? ''}»\n— من «${card.seriesTitle ?? ''}»\n${card.deepLink ?? ''}\n#سينوك';
      case ShareCardKind.achievement:
        return achievementShareText(card.achievementTitle ?? card.title, seriesTitle: card.seriesTitle);
      case ShareCardKind.stats:
        return 'ملخص قراءتي على Senok: ${card.statLabel ?? ''} ${card.statValue ?? ''}\n#سينوك #قراءة';
    }
  }
}

/// مخزن سجل بطاقات المشاركة (محلي).
class ShareCardsStore extends ChangeNotifier {
  ShareCardsStore(this._p) {
    _restore();
  }

  static const String _key = 'social_share_v2';
  static const int kMaxHistory = 50;

  final SharedPreferences _p;
  final List<ShareCardData> _history = <ShareCardData>[];

  static Future<ShareCardsStore> load() async {
    final p = await SharedPreferences.getInstance();
    return ShareCardsStore(p);
  }

  List<ShareCardData> get history => List.unmodifiable(_history);

  /// عدد البطاقات المشترَكة حسب النوع.
  Map<ShareCardKind, int> get countByKind {
    final map = <ShareCardKind, int>{};
    for (final c in _history) {
      map[c.kind] = (map[c.kind] ?? 0) + 1;
    }
    return map;
  }

  int get totalShared => _history.length;

  void _restore() {
    try {
      final raw = _p.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        _history
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => ShareCardData.fromJson(Map<String, dynamic>.from(e))));
      }
    } catch (_) {
      _history.clear();
    }
  }

  Future<void> _save() async {
    await _p.setString(_key, jsonEncode(_history.map((c) => c.toJson()).toList()));
  }

  /// تسجيل بطاقة مشترَكة (تُحفظ في أعلى السجل، بحد أقصى 50).
  Future<ShareCardData> record(ShareCardData card) async {
    _history.insert(0, card);
    if (_history.length > kMaxHistory) _history.removeRange(kMaxHistory, _history.length);
    await _save();
    notifyListeners();
    return card;
  }

  /// إنشاء بطاقة عمل وتسجيلها.
  Future<ShareCardData> shareSeries(Series series, ShareCardTheme theme) {
    final card = ShareCardData(
      id: _scId(),
      kind: ShareCardKind.series,
      theme: theme,
      title: series.title,
      seriesId: series.id,
      seriesTitle: series.title,
      rating: series.rating.round(),
      createdAt: DateTime.now(),
    );
    return record(card);
  }

  /// إنشاء بطاقة فصل وتسجيلها.
  Future<ShareCardData> shareChapter(Series series, int chapter, ShareCardTheme theme) {
    final card = ShareCardData(
      id: _scId(),
      kind: ShareCardKind.chapter,
      theme: theme,
      title: 'الفصل $chapter',
      seriesId: series.id,
      seriesTitle: series.title,
      chapter: chapter,
      createdAt: DateTime.now(),
    );
    return record(card);
  }

  /// إنشاء بطاقة اقتباس وتسجيلها.
  Future<ShareCardData> shareQuote(Series series, int chapter, String quote, ShareCardTheme theme) {
    final card = ShareCardData(
      id: _scId(),
      kind: ShareCardKind.quote,
      theme: theme,
      title: 'اقتباس',
      seriesId: series.id,
      seriesTitle: series.title,
      chapter: chapter,
      quote: quote,
      createdAt: DateTime.now(),
    );
    return record(card);
  }

  /// إنشاء بطاقة إنجاز وتسجيلها.
  Future<ShareCardData> shareAchievement(String achievementTitle, {String? seriesTitle, ShareCardTheme theme = ShareCardTheme.gold}) {
    final card = ShareCardData(
      id: _scId(),
      kind: ShareCardKind.achievement,
      theme: theme,
      title: achievementTitle,
      seriesTitle: seriesTitle,
      achievementTitle: achievementTitle,
      createdAt: DateTime.now(),
    );
    return record(card);
  }

  /// إنشاء بطاقة إحصاءات وتسجيلها.
  Future<ShareCardData> shareStats({required String label, required String value, ShareCardTheme theme = ShareCardTheme.ink}) {
    final card = ShareCardData(
      id: _scId(),
      kind: ShareCardKind.stats,
      theme: theme,
      title: label,
      statLabel: label,
      statValue: value,
      createdAt: DateTime.now(),
    );
    return record(card);
  }

  Future<bool> delete(String id) async {
    final before = _history.length;
    _history.removeWhere((c) => c.id == id);
    if (_history.length == before) return false;
    await _save();
    notifyListeners();
    return true;
  }

  Future<void> clearAll() async {
    _history.clear();
    await _save();
    notifyListeners();
  }
}

/// ───────── الواجهات ─────────

/// رسّام خلفية البطاقة: إطار ذهبي + ختم دائري + نقاط زخرفية.
class _ShareCardPainter extends CustomPainter {
  const _ShareCardPainter({required this.theme});
  final ShareCardTheme theme;

  @override
  void paint(Canvas canvas, Size size) {
    final accent = theme.accent;
    final borderPaint = Paint()
      ..color = accent.withAlpha(110)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final r = Rect.fromLTWH(10, 10, size.width - 20, size.height - 20);
    canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(18)), borderPaint);

    final sealPaint = Paint()
      ..color = accent.withAlpha(28)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(size.width - 52, size.height - 52), 34, sealPaint);
    final sealRing = Paint()
      ..color = accent.withAlpha(120)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawCircle(Offset(size.width - 52, size.height - 52), 34, sealRing);
    canvas.drawCircle(Offset(size.width - 52, size.height - 52), 26, sealRing);

    final dotPaint = Paint()..color = accent.withAlpha(60);
    for (var i = 0; i < 5; i++) {
      canvas.drawCircle(Offset(28 + i * 14, size.height - 28), 2.2, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _ShareCardPainter old) => old.theme != theme;
}

/// معاينة بطاقة مشاركة مرئية (قابلة للحفظ كصورة من خارج التطبيق لاحقاً).
class ShareCardPreview extends StatelessWidget {
  const ShareCardPreview({super.key, required this.card, this.series, this.width = 320});
  final ShareCardData card;
  final Series? series;
  final double width;

  @override
  Widget build(BuildContext context) {
    final t = card.theme;
    return Container(
      width: width,
      decoration: BoxDecoration(
        color: t.background,
        borderRadius: BorderRadius.circular(20),
      ),
      child: CustomPaint(
        painter: _ShareCardPainter(theme: t),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: t.accent,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      'S',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: t.background),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Senok · سينوك',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: t.foreground),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: t.accent.withAlpha(30),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      card.kind.label,
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: t.accent),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (series != null && card.kind != ShareCardKind.stats) ...[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 74,
                      height: 104,
                      child: CoverArt(series: series!, radius: 10, showTitle: false),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            series!.title,
                            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: t.foreground, height: 1.3),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${series!.type} · ${series!.status} · ${series!.year}',
                            style: TextStyle(fontSize: 11.5, color: t.muted),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Text('⭐', style: TextStyle(fontSize: 13, color: t.accent)),
                              const SizedBox(width: 3),
                              Text(
                                series!.rating.toStringAsFixed(1),
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.foreground),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                '${formatCount(series!.views)} مشاهدة',
                                style: TextStyle(fontSize: 11.5, color: t.muted),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
              if (card.kind == ShareCardKind.chapter) ...[
                const SizedBox(height: 12),
                Text(
                  'أنهيت الفصل ${card.chapter ?? ''}',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: t.foreground),
                ),
              ],
              if (card.kind == ShareCardKind.quote && card.quote != null) ...[
                const SizedBox(height: 12),
                Text(
                  '«${card.quote}»',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: t.foreground, height: 1.6),
                ),
                const SizedBox(height: 6),
                Text(
                  '— الفصل ${card.chapter ?? ''}، «${card.seriesTitle ?? ''}»',
                  style: TextStyle(fontSize: 12, color: t.muted),
                ),
              ],
              if (card.kind == ShareCardKind.achievement) ...[
                const SizedBox(height: 12),
                Text(
                  '🏆 ${card.achievementTitle ?? card.title}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: t.foreground),
                ),
                if (card.seriesTitle != null)
                  Text(
                    'في «${card.seriesTitle}»',
                    style: TextStyle(fontSize: 12, color: t.muted),
                  ),
              ],
              if (card.kind == ShareCardKind.stats) ...[
                const SizedBox(height: 8),
                Text(
                  card.statLabel ?? 'ملخص قراءتي',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: t.muted),
                ),
                const SizedBox(height: 4),
                Text(
                  card.statValue ?? '',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: t.foreground),
                ),
              ],
              const SizedBox(height: 16),
              Divider(color: t.muted.withAlpha(70), height: 1),
              const SizedBox(height: 10),
              Text(
                'حيث تبدأ الحكاية',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.accent),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// شاشة بطاقات المشاركة: إنشاء بطاقة + سجل البطاقات السابقة.
class ShareCardsScreen extends StatefulWidget {
  const ShareCardsScreen({super.key, required this.store, required this.series});
  final ShareCardsStore store;
  final Series series;

  @override
  State<ShareCardsScreen> createState() => _ShareCardsScreenState();
}

class _ShareCardsScreenState extends State<ShareCardsScreen> {
  ShareCardKind _kind = ShareCardKind.series;
  ShareCardTheme _theme = ShareCardTheme.ink;
  final TextEditingController _quoteCtrl = TextEditingController();
  final TextEditingController _chapterCtrl = TextEditingController(text: '1');

  @override
  void dispose() {
    _quoteCtrl.dispose();
    _chapterCtrl.dispose();
    super.dispose();
  }

  ShareCardData get _draft {
    return ShareCardData(
      id: 'draft',
      kind: _kind,
      theme: _theme,
      title: widget.series.title,
      seriesId: widget.series.id,
      seriesTitle: widget.series.title,
      chapter: int.tryParse(_chapterCtrl.text.trim()),
      quote: _quoteCtrl.text.trim().isEmpty ? 'السيف لا يصنع البطل، بل القلب الذي يحمله.' : _quoteCtrl.text.trim(),
      rating: widget.series.rating.round(),
      createdAt: DateTime.now(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: const Text('بطاقات المشاركة')),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              Center(child: ShareCardPreview(card: _draft, series: widget.series)),
              const SizedBox(height: 16),
              Text('نوع البطاقة', style: context.ds(size: 15)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final k in ShareCardKind.values)
                    ChoiceChip(
                      label: Text(k.label),
                      selected: _kind == k,
                      onSelected: (_) => setState(() => _kind = k),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              Text('سمة البطاقة', style: context.ds(size: 15)),
              const SizedBox(height: 8),
              ShareCardThemePicker(
                selected: _theme,
                onSelect: (t) => setState(() => _theme = t),
              ),
              if (_kind == ShareCardKind.chapter) ...[
                const SizedBox(height: 16),
                TextField(
                  controller: _chapterCtrl,
                  keyboardType: TextInputType.number,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    labelText: 'رقم الفصل',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
                  ),
                ),
              ],
              if (_kind == ShareCardKind.quote) ...[
                const SizedBox(height: 16),
                TextField(
                  controller: _quoteCtrl,
                  maxLines: 3,
                  maxLength: 200,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    labelText: 'الاقتباس',
                    hintText: 'اكتب الاقتباس الذي أعجبك…',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () async {
                    final card = await _createCard();
                    if (context.mounted) {
                      _showShareSheet(context, card);
                    }
                  },
                  icon: const SIcon(SardIcons.share_rounded, size: 18),
                  label: const Text('مشاركة البطاقة'),
                ),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  await _createCard();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('حُفظت البطاقة في سجلك.')),
                    );
                  }
                },
                icon: const SIcon(SardIcons.bookmark_rounded, size: 18),
                label: const Text('حفظ في سجلي فقط'),
              ),
              const SizedBox(height: 20),
              ShareStatsRow(store: widget.store),
              const SizedBox(height: 12),
              Text('بطاقاتي السابقة', style: context.ds(size: 15)),
              const SizedBox(height: 8),
              if (widget.store.history.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    'لم تشارك أي بطاقة بعد. جرّب إنشاء بطاقتك الأولى أعلاه.',
                    style: context.ts(size: 13, color: p.textDim),
                  ),
                )
              else
                ShareHistoryList(store: widget.store, series: widget.series),
            ],
          );
        },
      ),
    );
  }

  Future<ShareCardData> _createCard() async {
    switch (_kind) {
      case ShareCardKind.series:
        return widget.store.shareSeries(widget.series, _theme);
      case ShareCardKind.chapter:
        final ch = int.tryParse(_chapterCtrl.text.trim()) ?? 1;
        return widget.store.shareChapter(widget.series, ch, _theme);
      case ShareCardKind.quote:
        final q = _quoteCtrl.text.trim().isEmpty ? 'السيف لا يصنع البطل، بل القلب الذي يحمله.' : _quoteCtrl.text.trim();
        final ch = int.tryParse(_chapterCtrl.text.trim()) ?? 1;
        return widget.store.shareQuote(widget.series, ch, q, _theme);
      case ShareCardKind.achievement:
        return widget.store.shareAchievement('قارئ مثابر', seriesTitle: widget.series.title, theme: _theme);
      case ShareCardKind.stats:
        return widget.store.shareStats(label: 'فصول هذا الأسبوع', value: '12 فصلاً', theme: _theme);
    }
  }

  void _showShareSheet(BuildContext context, ShareCardData card) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => ShareSheet(card: card),
    );
  }
}

/// منتقي سمة البطاقة (دوائر لونية).
class ShareCardThemePicker extends StatelessWidget {
  const ShareCardThemePicker({super.key, required this.selected, required this.onSelect});
  final ShareCardTheme selected;
  final ValueChanged<ShareCardTheme> onSelect;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        for (final t in ShareCardTheme.values)
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => onSelect(t),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: selected == t ? tint(p.accent, 0.12) : p.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: selected == t ? p.accent : p.border, width: selected == t ? 2 : 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: t.background,
                      shape: BoxShape.circle,
                      border: Border.all(color: t.accent, width: 2),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(t.label, style: context.ts(size: 12.5, w: FontWeight.w700)),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

/// ورقة المشاركة: نص جاهز للنسخ + تذكير بأن المشاركة بيد المستخدم.
class ShareSheet extends StatelessWidget {
  const ShareSheet({super.key, required this.card});
  final ShareCardData card;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('مشاركة البطاقة', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'انسخ النص وشاركه حيث تريد — التطبيق لا يرسل شيئاً تلقائياً.',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: p.bg,
                borderRadius: BorderRadius.circular(p.r(0.8)),
                border: Border.all(color: p.border),
              ),
              child: SelectableText(card.shareText, style: context.ts(size: 13.5, height: 1.6)),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () {
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('نُسخ نص المشاركة (انسخه يدوياً من النص أعلاه).')),
                  );
                },
                icon: const SIcon(SardIcons.share_rounded, size: 18),
                label: const Text('تم، سأشاركها بنفسي'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// صف إحصاءات المشاركة: الإجمالي + الأكثر مشاركة.
class ShareStatsRow extends StatelessWidget {
  const ShareStatsRow({super.key, required this.store});
  final ShareCardsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final counts = store.countByKind;
    final top = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          SIcon(SardIcons.share_rounded, size: 20, color: p.accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('شاركت ${store.totalShared} بطاقة حتى الآن', style: context.ts(size: 13.5, w: FontWeight.w700)),
                if (top.isNotEmpty)
                  Text(
                    'الأكثر مشاركة: ${top.first.key.label} (${top.first.value})',
                    style: context.ts(size: 12, color: p.textDim),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// سجل البطاقات السابقة مع حذف كل بطاقة.
class ShareHistoryList extends StatelessWidget {
  const ShareHistoryList({super.key, required this.store, required this.series});
  final ShareCardsStore store;
  final Series series;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      children: [
        for (final c in store.history)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(p.r(0.8)),
              border: Border.all(color: p.border),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(c.theme.accent, 0.14),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    'S',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: c.theme.accent),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${c.kind.label} · ${c.title}',
                        style: context.ts(size: 13.5, w: FontWeight.w700),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        c.theme.label,
                        style: context.ts(size: 11.5, color: p.textDim),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => store.delete(c.id),
                  icon: SIcon(SardIcons.delete_outline_rounded, size: 18, color: p.textDim),
                  tooltip: 'حذف من السجل',
                ),
              ],
            ),
          ),
      ],
    );
  }
}
