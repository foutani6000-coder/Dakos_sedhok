import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'comments_v2.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// نشاط الأصدقاء — خلاصة ما يفعله أصدقاؤك: بدء عمل، إنهاء فصل، تقييم،
/// مراجعة، انضمام لدائرة، فتح إنجاز، مشاركة اقتباس، متابعة عمل.
///
/// كل البيانات محلية تجريبية في هذه النسخة (تُحفظ في SharedPreferences).
/// ──────────────────────────────────────────────────────────────────────────

int _faSeq = 0;
String _faId() => 'fa_${DateTime.now().microsecondsSinceEpoch}_${_faSeq++}';

/// نوع نشاط صديق.
enum FriendActivityKind {
  startedSeries('بدأ عملاً جديداً', 'بدأ قراءة عمل جديد'),
  finishedChapter('أنهى فصلاً', 'أنهى فصلاً من عمل'),
  rated('قيّم عملاً', 'قيّم عملاً بالنجوم'),
  reviewed('كتب مراجعة', 'نشر مراجعة عن عمل'),
  joinedCircle('انضم لدائرة', 'انضم إلى دائرة قراءة'),
  unlockedAchievement('فتح إنجازاً', 'فتح إنجازاً جديداً'),
  sharedQuote('شارك اقتباساً', 'شارك اقتباساً من فصل'),
  followedSeries('تابع عملاً', 'أضاف عملاً إلى قائمة المتابعة');

  const FriendActivityKind(this.label, this.description);
  final String label;
  final String description;

  /// الأيقونة المناسبة لكل نوع (من أيقونات SardIcons الموجودة).
  SIconData get icon {
    switch (this) {
      case FriendActivityKind.startedSeries:
        return SardIcons.auto_stories_rounded;
      case FriendActivityKind.finishedChapter:
        return SardIcons.check_circle_rounded;
      case FriendActivityKind.rated:
        return SardIcons.star_rounded;
      case FriendActivityKind.reviewed:
        return SardIcons.edit_rounded;
      case FriendActivityKind.joinedCircle:
        return SardIcons.groups_rounded;
      case FriendActivityKind.unlockedAchievement:
        return SardIcons.local_fire_department_rounded;
      case FriendActivityKind.sharedQuote:
        return SardIcons.format_list_bulleted_rounded;
      case FriendActivityKind.followedSeries:
        return SardIcons.bookmark_rounded;
    }
  }

  /// لون النوع (للتمييز البصري في الخلاصة).
  Color color(SardPalette p) {
    switch (this) {
      case FriendActivityKind.startedSeries:
        return const Color(0xFF3B9EFF);
      case FriendActivityKind.finishedChapter:
        return const Color(0xFF0F9D75);
      case FriendActivityKind.rated:
        return p.gold;
      case FriendActivityKind.reviewed:
        return const Color(0xFF7C4DFF);
      case FriendActivityKind.joinedCircle:
        return const Color(0xFFE0457B);
      case FriendActivityKind.unlockedAchievement:
        return const Color(0xFFE63E2A);
      case FriendActivityKind.sharedQuote:
        return const Color(0xFF0F9D75);
      case FriendActivityKind.followedSeries:
        return p.accent;
    }
  }
}

/// حدث واحد في خلاصة نشاط الأصدقاء.
class FriendActivity {
  const FriendActivity({
    required this.id,
    required this.friendId,
    required this.friendName,
    required this.kind,
    required this.createdAt,
    this.badge = SardBadge.none,
    this.seriesId,
    this.seriesTitle,
    this.chapter,
    this.rating,
    this.text,
    this.likes = 0,
    this.likedByMe = false,
    this.seen = false,
  });

  final String id;
  final String friendId;
  final String friendName;
  final FriendActivityKind kind;
  final DateTime createdAt;
  final SardBadge badge;
  final String? seriesId;
  final String? seriesTitle;
  final int? chapter;
  final int? rating;
  final String? text;
  final int likes;
  final bool likedByMe;
  final bool seen;

  /// جملة وصفية جاهزة للعرض.
  String get sentence {
    final name = friendName;
    final work = seriesTitle == null ? '' : ' «$seriesTitle»';
    switch (kind) {
      case FriendActivityKind.startedSeries:
        return '$name بدأ قراءة$work';
      case FriendActivityKind.finishedChapter:
        return '$name أنهى الفصل ${chapter ?? ''} من$work';
      case FriendActivityKind.rated:
        return '$name قيّم$work بـ ${rating ?? 5} نجوم';
      case FriendActivityKind.reviewed:
        return '$name كتب مراجعة عن$work';
      case FriendActivityKind.joinedCircle:
        return '$name انضم إلى دائرة قراءة$work';
      case FriendActivityKind.unlockedAchievement:
        return '$name فتح إنجازاً جديداً';
      case FriendActivityKind.sharedQuote:
        return '$name شارك اقتباساً من$work';
      case FriendActivityKind.followedSeries:
        return '$name تابع$work';
    }
  }

  FriendActivity copyWith({int? likes, bool? likedByMe, bool? seen}) {
    return FriendActivity(
      id: id,
      friendId: friendId,
      friendName: friendName,
      kind: kind,
      createdAt: createdAt,
      badge: badge,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      rating: rating,
      text: text,
      likes: likes ?? this.likes,
      likedByMe: likedByMe ?? this.likedByMe,
      seen: seen ?? this.seen,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'friendId': friendId,
        'friendName': friendName,
        'kind': kind.name,
        'createdAt': createdAt.toIso8601String(),
        'badge': badge.name,
        'seriesId': seriesId,
        'seriesTitle': seriesTitle,
        'chapter': chapter,
        'rating': rating,
        'text': text,
        'likes': likes,
        'likedByMe': likedByMe,
        'seen': seen,
      };

  factory FriendActivity.fromJson(Map<String, dynamic> j) {
    final kind = FriendActivityKind.values.firstWhere(
      (e) => e.name == j['kind'],
      orElse: () => FriendActivityKind.startedSeries,
    );
    final badge = SardBadge.values.firstWhere(
      (e) => e.name == j['badge'],
      orElse: () => SardBadge.none,
    );
    return FriendActivity(
      id: '${j['id']}',
      friendId: '${j['friendId']}',
      friendName: '${j['friendName'] ?? 'صديق'}',
      kind: kind,
      createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
      badge: badge,
      seriesId: j['seriesId']?.toString(),
      seriesTitle: j['seriesTitle']?.toString(),
      chapter: (j['chapter'] as num?)?.toInt(),
      rating: (j['rating'] as num?)?.toInt(),
      text: j['text']?.toString(),
      likes: (j['likes'] as num?)?.toInt() ?? 0,
      likedByMe: j['likedByMe'] == true,
      seen: j['seen'] == true,
    );
  }
}

/// صديق في قائمة الأصدقاء (حالة الاتصال وآخر نشاط).
class SocialFriend {
  const SocialFriend({
    required this.id,
    required this.name,
    this.badge = SardBadge.none,
    this.online = false,
    this.currentSeriesTitle,
    this.currentChapter = 0,
    this.chaptersRead = 0,
    this.lastActive,
  });

  final String id;
  final String name;
  final SardBadge badge;
  final bool online;
  final String? currentSeriesTitle;
  final int currentChapter;
  final int chaptersRead;
  final DateTime? lastActive;

  /// وصف الحالة: «متصل الآن» أو «يقرأ ...» أو آخر ظهور.
  String statusLabel({DateTime? now}) {
    if (online) return 'متصل الآن';
    if (currentSeriesTitle != null && currentChapter > 0) {
      return 'يقرأ «$currentSeriesTitle» (ف $currentChapter)';
    }
    if (lastActive != null) return 'آخر ظهور ${socialTimeAgo(lastActive!, now: now)}';
    return 'غير متصل';
  }

  SocialFriend copyWith({bool? online, String? currentSeriesTitle, int? currentChapter, int? chaptersRead, DateTime? lastActive}) {
    return SocialFriend(
      id: id,
      name: name,
      badge: badge,
      online: online ?? this.online,
      currentSeriesTitle: currentSeriesTitle ?? this.currentSeriesTitle,
      currentChapter: currentChapter ?? this.currentChapter,
      chaptersRead: chaptersRead ?? this.chaptersRead,
      lastActive: lastActive ?? this.lastActive,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'badge': badge.name,
        'online': online,
        'currentSeriesTitle': currentSeriesTitle,
        'currentChapter': currentChapter,
        'chaptersRead': chaptersRead,
        'lastActive': lastActive?.toIso8601String(),
      };

  factory SocialFriend.fromJson(Map<String, dynamic> j) {
    final badge = SardBadge.values.firstWhere(
      (e) => e.name == j['badge'],
      orElse: () => SardBadge.none,
    );
    return SocialFriend(
      id: '${j['id']}',
      name: '${j['name'] ?? 'صديق'}',
      badge: badge,
      online: j['online'] == true,
      currentSeriesTitle: j['currentSeriesTitle']?.toString(),
      currentChapter: (j['currentChapter'] as num?)?.toInt() ?? 0,
      chaptersRead: (j['chaptersRead'] as num?)?.toInt() ?? 0,
      lastActive: j['lastActive'] == null ? null : DateTime.tryParse('${j['lastActive']}'),
    );
  }
}

/// مخزن نشاط الأصدقاء: خلاصة + قائمة أصدقاء + بذرة تجريبية.
class FriendsActivityStore extends ChangeNotifier {
  FriendsActivityStore(this._p) {
    _restore();
  }

  static const String _key = 'social_friends_v2';
  static const String _friendsKey = 'social_friends_v2_list';

  final SharedPreferences _p;
  final List<FriendActivity> _feed = <FriendActivity>[];
  final List<SocialFriend> _friends = <SocialFriend>[];

  static Future<FriendsActivityStore> load() async {
    final p = await SharedPreferences.getInstance();
    return FriendsActivityStore(p);
  }

  List<FriendActivity> get feed => List.unmodifiable(_feed);
  List<SocialFriend> get friends => List.unmodifiable(_friends);

  /// عدد الأحداث غير المقروءة (غير المشاهَدة).
  int get unseenCount => _feed.where((a) => !a.seen).length;

  /// الأصدقاء المتصلون الآن.
  List<SocialFriend> get onlineFriends => _friends.where((f) => f.online).toList();

  void _restore() {
    try {
      final raw = _p.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        _feed
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => FriendActivity.fromJson(Map<String, dynamic>.from(e))));
      }
      final rawF = _p.getString(_friendsKey);
      if (rawF != null && rawF.isNotEmpty) {
        final list = jsonDecode(rawF) as List;
        _friends
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => SocialFriend.fromJson(Map<String, dynamic>.from(e))));
      }
    } catch (_) {
      _feed.clear();
      _friends.clear();
    }
  }

  Future<void> _save() async {
    await _p.setString(_key, jsonEncode(_feed.map((a) => a.toJson()).toList()));
    await _p.setString(_friendsKey, jsonEncode(_friends.map((f) => f.toJson()).toList()));
  }

  /// بذرة تجريبية عربية عند أول فتح.
  Future<void> ensureDemo() async {
    if (_feed.isNotEmpty || _friends.isNotEmpty) return;
    final now = DateTime.now();
    _friends.addAll(<SocialFriend>[
      SocialFriend(id: 'u_ahmed', name: 'أحمد', badge: SardBadge.blue, online: true, currentSeriesTitle: 'سيف الفجر', currentChapter: 18, chaptersRead: 342, lastActive: now),
      SocialFriend(id: 'u_sara', name: 'سارة', online: true, currentSeriesTitle: 'زهرة الربيع', currentChapter: 11, chaptersRead: 218, lastActive: now),
      SocialFriend(id: 'u_omar', name: 'عمر', online: false, currentSeriesTitle: 'سيف الفجر', currentChapter: 15, chaptersRead: 187, lastActive: now.subtract(const Duration(hours: 2))),
      SocialFriend(id: 'u_layla', name: 'ليلى', online: true, currentSeriesTitle: 'سيف الفجر', currentChapter: 14, chaptersRead: 156, lastActive: now),
      SocialFriend(id: 'u_khalid', name: 'خالد', badge: SardBadge.yellow, online: false, currentSeriesTitle: 'زهرة الربيع', currentChapter: 8, chaptersRead: 264, lastActive: now.subtract(const Duration(hours: 6))),
      SocialFriend(id: 'u_noura', name: 'نورة', online: false, currentSeriesTitle: 'زهرة الربيع', currentChapter: 11, chaptersRead: 198, lastActive: now.subtract(const Duration(hours: 1))),
      SocialFriend(id: 'u_huda', name: 'هدى', online: false, currentSeriesTitle: 'سيف الفجر', currentChapter: 5, chaptersRead: 96, lastActive: now.subtract(const Duration(days: 1))),
      SocialFriend(id: 'u_youssef', name: 'يوسف', online: true, currentSeriesTitle: 'زهرة الربيع', currentChapter: 8, chaptersRead: 143, lastActive: now),
    ]);
    _feed.addAll(<FriendActivity>[
      FriendActivity(
        id: 'fa_1',
        friendId: 'u_ahmed',
        friendName: 'أحمد',
        badge: SardBadge.blue,
        kind: FriendActivityKind.finishedChapter,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        chapter: 18,
        createdAt: now.subtract(const Duration(minutes: 12)),
        likes: 6,
      ),
      FriendActivity(
        id: 'fa_2',
        friendId: 'u_sara',
        friendName: 'سارة',
        kind: FriendActivityKind.rated,
        seriesId: 's2',
        seriesTitle: 'زهرة الربيع',
        rating: 5,
        createdAt: now.subtract(const Duration(minutes: 35)),
        likes: 11,
      ),
      FriendActivity(
        id: 'fa_3',
        friendId: 'u_omar',
        friendName: 'عمر',
        kind: FriendActivityKind.reviewed,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        text: 'أفضل ما قرأت هذا العام — قصة محكمة ورسم مذهل.',
        createdAt: now.subtract(const Duration(hours: 1, minutes: 10)),
        likes: 23,
      ),
      FriendActivity(
        id: 'fa_4',
        friendId: 'u_layla',
        friendName: 'ليلى',
        kind: FriendActivityKind.joinedCircle,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        text: 'انضمّت إلى دائرة «قرّاء الفجر».',
        createdAt: now.subtract(const Duration(hours: 2)),
        likes: 4,
      ),
      FriendActivity(
        id: 'fa_5',
        friendId: 'u_khalid',
        friendName: 'خالد',
        badge: SardBadge.yellow,
        kind: FriendActivityKind.unlockedAchievement,
        text: 'فتح إنجاز «قارئ الليل» لقراءته 20 فصلاً بعد منتصف الليل.',
        createdAt: now.subtract(const Duration(hours: 4)),
        likes: 18,
      ),
      FriendActivity(
        id: 'fa_6',
        friendId: 'u_noura',
        friendName: 'نورة',
        kind: FriendActivityKind.startedSeries,
        seriesId: 's2',
        seriesTitle: 'زهرة الربيع',
        createdAt: now.subtract(const Duration(hours: 6)),
        likes: 3,
      ),
      FriendActivity(
        id: 'fa_7',
        friendId: 'u_huda',
        friendName: 'هدى',
        kind: FriendActivityKind.sharedQuote,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        text: '«السيف لا يصنع البطل، بل القلب الذي يحمله.»',
        createdAt: now.subtract(const Duration(hours: 9)),
        likes: 31,
      ),
      FriendActivity(
        id: 'fa_8',
        friendId: 'u_youssef',
        friendName: 'يوسف',
        kind: FriendActivityKind.followedSeries,
        seriesId: 's2',
        seriesTitle: 'زهرة الربيع',
        createdAt: now.subtract(const Duration(hours: 12)),
        likes: 2,
      ),
      FriendActivity(
        id: 'fa_9',
        friendId: 'u_ahmed',
        friendName: 'أحمد',
        badge: SardBadge.blue,
        kind: FriendActivityKind.finishedChapter,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        chapter: 17,
        createdAt: now.subtract(const Duration(days: 1, hours: 1)),
        likes: 5,
        seen: true,
      ),
      FriendActivity(
        id: 'fa_10',
        friendId: 'u_sara',
        friendName: 'سارة',
        kind: FriendActivityKind.rated,
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        rating: 4,
        createdAt: now.subtract(const Duration(days: 1, hours: 4)),
        likes: 8,
        seen: true,
      ),
    ]);
    await _save();
    notifyListeners();
  }

  // ───────── استعلامات ─────────

  /// الخلاصة مرتبة من الأحدث، مع ترشيح اختياري بالنوع أو الصديق.
  List<FriendActivity> filtered({FriendActivityKind? kind, String? friendId, bool unseenOnly = false}) {
    var list = List<FriendActivity>.from(_feed);
    if (kind != null) list = list.where((a) => a.kind == kind).toList();
    if (friendId != null) list = list.where((a) => a.friendId == friendId).toList();
    if (unseenOnly) list = list.where((a) => !a.seen).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  /// تجميع الخلاصة حسب اليوم (مفتاح «اليوم»، «أمس»، أو التاريخ).
  Map<String, List<FriendActivity>> groupedByDay({DateTime? now}) {
    final n = now ?? DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final map = <String, List<FriendActivity>>{};
    for (final a in filtered()) {
      final d = DateTime(a.createdAt.year, a.createdAt.month, a.createdAt.day);
      final diff = today.difference(d).inDays;
      final key = diff == 0
          ? 'اليوم'
          : diff == 1
              ? 'أمس'
              : '${a.createdAt.year}/${a.createdAt.month}/${a.createdAt.day}';
      (map[key] ??= <FriendActivity>[]).add(a);
    }
    return map;
  }

  /// نشاط صديق معيّن.
  List<FriendActivity> forFriend(String friendId) => filtered(friendId: friendId);

  SocialFriend? friendById(String id) {
    for (final f in _friends) {
      if (f.id == id) return f;
    }
    return null;
  }

  // ───────── عمليات ─────────

  /// إضافة حدث نشاط جديد (يُستدعى من القارئ والتقييمات والدوائر).
  Future<FriendActivity> record({
    required String friendId,
    required String friendName,
    required FriendActivityKind kind,
    SardBadge badge = SardBadge.none,
    String? seriesId,
    String? seriesTitle,
    int? chapter,
    int? rating,
    String? text,
    DateTime? at,
  }) async {
    final now = at ?? DateTime.now();
    final a = FriendActivity(
      id: _faId(),
      friendId: friendId,
      friendName: friendName,
      kind: kind,
      createdAt: now,
      badge: badge,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      rating: rating,
      text: text,
    );
    _feed.insert(0, a);
    if (_feed.length > 200) _feed.removeRange(200, _feed.length);
    await _save();
    notifyListeners();
    return a;
  }

  /// تبديل الإعجاب على حدث.
  Future<void> toggleLike(String id) async {
    final idx = _feed.indexWhere((a) => a.id == id);
    if (idx < 0) return;
    final a = _feed[idx];
    _feed[idx] = a.copyWith(
      likes: a.likedByMe ? a.likes - 1 : a.likes + 1,
      likedByMe: !a.likedByMe,
    );
    await _save();
    notifyListeners();
  }

  /// تعليم كل الخلاصة كمقروءة.
  Future<void> markAllSeen() async {
    var changed = false;
    for (var i = 0; i < _feed.length; i++) {
      if (!_feed[i].seen) {
        _feed[i] = _feed[i].copyWith(seen: true);
        changed = true;
      }
    }
    if (changed) {
      await _save();
      notifyListeners();
    }
  }

  /// تحديث حالة صديق (اتصال/تقدم).
  Future<void> updateFriend(String id, {bool? online, String? currentSeriesTitle, int? currentChapter, int? chaptersRead}) async {
    final idx = _friends.indexWhere((f) => f.id == id);
    if (idx < 0) return;
    _friends[idx] = _friends[idx].copyWith(
      online: online,
      currentSeriesTitle: currentSeriesTitle,
      currentChapter: currentChapter,
      chaptersRead: chaptersRead,
      lastActive: DateTime.now(),
    );
    await _save();
    notifyListeners();
  }

  Future<void> clearAll() async {
    _feed.clear();
    _friends.clear();
    await _save();
    notifyListeners();
  }
}

/// ───────── الواجهات ─────────

/// شاشة نشاط الأصدقاء: صف أصدقاء + ترشيح + خلاصة مجمّعة بالأيام.
class FriendsActivityScreen extends StatefulWidget {
  const FriendsActivityScreen({super.key, required this.store});
  final FriendsActivityStore store;

  @override
  State<FriendsActivityScreen> createState() => _FriendsActivityScreenState();
}

class _FriendsActivityScreenState extends State<FriendsActivityScreen> {
  FriendActivityKind? _kind;
  String? _friendId;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('نشاط الأصدقاء'),
        actions: [
          TextButton(
            onPressed: () => widget.store.markAllSeen(),
            child: const Text('تعليم الكل كمقروء'),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          final groups = widget.store.groupedByDay();
          final filtered = widget.store.filtered(kind: _kind, friendId: _friendId);
          final showGrouped = _kind == null && _friendId == null;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FriendsRow(
                friends: widget.store.friends,
                selectedId: _friendId,
                onSelect: (id) => setState(() => _friendId = _friendId == id ? null : id),
              ),
              ActivityFilterChips(
                selected: _kind,
                onSelect: (k) => setState(() => _kind = _kind == k ? null : k),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Text(
                  'البيانات تجريبية محلية — تُستبدل بنشاط أصدقائك الحقيقيين عند ربط الحساب.',
                  style: context.ts(size: 11, color: p.textDim),
                ),
              ),
              Expanded(
                child: showGrouped
                    ? _GroupedFeed(groups: groups, store: widget.store)
                    : filtered.isEmpty
                        ? Center(
                            child: Text('لا نشاط مطابق للترشيح.', style: context.ts(size: 14, color: p.textDim)),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                            itemCount: filtered.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 10),
                            itemBuilder: (context, i) => ActivityTile(activity: filtered[i], store: widget.store),
                          ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// خلاصة مجمّعة حسب اليوم مع عناوين أيام.
class _GroupedFeed extends StatelessWidget {
  const _GroupedFeed({required this.groups, required this.store});
  final Map<String, List<FriendActivity>> groups;
  final FriendsActivityStore store;

  @override
  Widget build(BuildContext context) {
    if (groups.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SIcon(SardIcons.dynamic_feed_rounded, size: 44, color: context.pal.textDim),
              const SizedBox(height: 12),
              Text('لا نشاط بعد', style: context.ds(size: 18)),
              const SizedBox(height: 6),
              Text(
                'عندما يقرأ أصدقاؤك أو يقيّمون أعمالاً ستظهر أنشطتهم هنا.',
                style: context.ts(size: 13.5, color: context.pal.textDim),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }
    final keys = groups.keys.toList();
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      itemCount: keys.length,
      itemBuilder: (context, i) {
        final key = keys[i];
        final items = groups[key]!;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(key, style: context.ds(size: 15)),
            ),
            for (final a in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ActivityTile(activity: a, store: store),
              ),
          ],
        );
      },
    );
  }
}

/// صف أصدقاء أفقي: صورة رمزية + حالة اتصال، نقر للترشيح بصاحبها.
class FriendsRow extends StatelessWidget {
  const FriendsRow({super.key, required this.friends, this.selectedId, required this.onSelect});
  final List<SocialFriend> friends;
  final String? selectedId;
  final ValueChanged<String> onSelect;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (friends.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 92,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: friends.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final f = friends[i];
          final selected = selectedId == f.id;
          return InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => onSelect(f.id),
            child: Container(
              width: 66,
              padding: const EdgeInsets.symmetric(vertical: 4),
              decoration: BoxDecoration(
                color: selected ? tint(p.accent, 0.12) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: selected ? p.accent : Colors.transparent),
              ),
              child: Column(
                children: [
                  Stack(
                    children: [
                      FriendAvatar(friend: f, size: 48),
                      if (f.online)
                        PositionedDirectional(
                          bottom: 0,
                          end: 0,
                          child: Container(
                            width: 13,
                            height: 13,
                            decoration: BoxDecoration(
                              color: const Color(0xFF2ECC71),
                              shape: BoxShape.circle,
                              border: Border.all(color: p.bg, width: 2),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    f.name,
                    style: context.ts(size: 11.5, w: FontWeight.w700),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                  Text(
                    f.online ? 'متصل' : 'غير متصل',
                    style: context.ts(size: 10, color: f.online ? const Color(0xFF0F9D75) : p.textDim),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// صورة رمزية دائرية لصديق بالحرف الأول.
class FriendAvatar extends StatelessWidget {
  const FriendAvatar({super.key, required this.friend, this.size = 48});
  final SocialFriend friend;
  final double size;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = friend.badge == SardBadge.purple
        ? const Color(0xFF7C4DFF)
        : friend.badge == SardBadge.blue
            ? const Color(0xFF3B9EFF)
            : friend.badge == SardBadge.yellow
                ? p.gold
                : p.accent;
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: tint(color, 0.14),
        shape: BoxShape.circle,
        border: Border.all(color: tint(color, 0.35)),
      ),
      child: Text(
        friend.name.isEmpty ? '؟' : friend.name.characters.first,
        style: context.ds(size: size * 0.42, color: color),
      ),
    );
  }
}

/// شرائح ترشيح الخلاصة حسب نوع النشاط (null = الكل).
class ActivityFilterChips extends StatelessWidget {
  const ActivityFilterChips({super.key, this.selected, required this.onSelect});
  final FriendActivityKind? selected;
  final ValueChanged<FriendActivityKind?> onSelect;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          _chip(context, label: 'الكل', selected: selected == null, onTap: () => onSelect(null)),
          for (final k in FriendActivityKind.values)
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 6),
              child: _chip(
                context,
                label: k.label,
                icon: k.icon,
                color: k.color(p),
                selected: selected == k,
                onTap: () => onSelect(k),
              ),
            ),
        ],
      ),
    );
  }

  Widget _chip(
    BuildContext context, {
    required String label,
    SIconData? icon,
    Color? color,
    required bool selected,
    required VoidCallback onTap,
  }) {
    final p = context.pal;
    return ActionChip(
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            SIcon(icon, size: 14, color: selected ? p.onAccent : color),
            const SizedBox(width: 4),
          ],
          Text(label),
        ],
      ),
      labelStyle: context.ts(size: 12, color: selected ? p.onAccent : p.text, w: FontWeight.w700),
      backgroundColor: selected ? p.accent : p.surface,
      side: BorderSide(color: selected ? p.accent : p.border),
      onPressed: onTap,
    );
  }
}

/// بطاقة حدث واحد: أيقونة النوع + الجملة + الاقتباس/النص + إعجاب.
class ActivityTile extends StatelessWidget {
  const ActivityTile({super.key, required this.activity, required this.store});
  final FriendActivity activity;
  final FriendsActivityStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final a = activity;
    final color = a.kind.color(p);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: a.seen ? p.surface : tint(p.accent, 0.05),
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: a.seen ? p.border : tint(p.accent, 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(color, 0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SIcon(a.kind.icon, size: 20, color: color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    style: context.ts(size: 13.5, height: 1.45),
                    children: [
                      TextSpan(text: a.friendName, style: const TextStyle(fontWeight: FontWeight.w800)),
                      TextSpan(text: ' ${_verbFor(a)}'),
                    ],
                  ),
                ),
                if (a.text != null && a.text!.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    a.text!,
                    style: context.ts(size: 12.5, color: p.textDim, height: 1.45),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(socialTimeAgo(a.createdAt), style: context.ts(size: 11, color: p.textDim)),
                    const Spacer(),
                    InkWell(
                      borderRadius: BorderRadius.circular(8),
                      onTap: () => store.toggleLike(a.id),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SIcon(
                              a.likedByMe ? SardIcons.favorite_rounded : SardIcons.favorite_border_rounded,
                              size: 15,
                              color: a.likedByMe ? const Color(0xFFE5484D) : p.textDim,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              formatCount(a.likes),
                              style: context.ts(size: 11.5, color: p.textDim, w: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (!a.seen)
            Container(
              width: 8,
              height: 8,
              margin: const EdgeInsets.only(top: 6),
              decoration: BoxDecoration(color: p.accent, shape: BoxShape.circle),
            ),
        ],
      ),
    );
  }

  /// فعل الجملة بدون اسم الصديق (للعرض بخط عريض للاسم).
  String _verbFor(FriendActivity a) {
    final work = a.seriesTitle == null ? '' : ' «${a.seriesTitle}»';
    switch (a.kind) {
      case FriendActivityKind.startedSeries:
        return 'بدأ قراءة$work';
      case FriendActivityKind.finishedChapter:
        return 'أنهى الفصل ${a.chapter ?? ''} من$work';
      case FriendActivityKind.rated:
        return 'قيّم$work بـ ${a.rating ?? 5} نجوم';
      case FriendActivityKind.reviewed:
        return 'كتب مراجعة عن$work';
      case FriendActivityKind.joinedCircle:
        return 'انضم إلى دائرة قراءة$work';
      case FriendActivityKind.unlockedAchievement:
        return 'فتح إنجازاً جديداً';
      case FriendActivityKind.sharedQuote:
        return 'شارك اقتباساً من$work';
      case FriendActivityKind.followedSeries:
        return 'تابع$work';
    }
  }
}

/// ورقة ملف صديق مصغّرة: إحصاءاته وآخر أنشطته.
class FriendProfileSheet extends StatelessWidget {
  const FriendProfileSheet({super.key, required this.friend, required this.store});
  final SocialFriend friend;
  final FriendsActivityStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final activities = store.forFriend(friend.id).take(5).toList();
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                FriendAvatar(friend: friend, size: 56),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(friend.name, style: context.ds(size: 18)),
                      Text(friend.statusLabel(), style: context.ts(size: 12.5, color: p.textDim)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: tint(p.accent, 0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${friend.chaptersRead} فصلاً مقروءاً',
                    style: context.ts(size: 12, color: p.accent, w: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text('آخر أنشطته', style: context.ds(size: 15)),
            const SizedBox(height: 8),
            if (activities.isEmpty)
              Text('لا أنشطة بعد.', style: context.ts(size: 13, color: p.textDim))
            else
              for (final a in activities)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: ActivityTile(activity: a, store: store),
                ),
          ],
        ),
      ),
    );
  }
}
