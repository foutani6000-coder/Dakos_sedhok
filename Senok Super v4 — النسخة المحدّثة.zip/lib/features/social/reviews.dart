import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'comments_v2.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// المراجعات — تقييمات بالنجوم (1–5) مع عنوان ونص وملخص توزيع النجوم.
///
/// كل البيانات محلية تجريبية في هذه النسخة (تُحفظ في SharedPreferences).
/// القواعد صريحة: مراجعة واحدة لكل مستخدم لكل عمل، ويمكن تعديلها.
/// ──────────────────────────────────────────────────────────────────────────

int _reviewSeq = 0;
String _reviewId() => 'r_${DateTime.now().microsecondsSinceEpoch}_${_reviewSeq++}';

/// ترتيب عرض المراجعات.
enum ReviewSort {
  helpful('الأكثر فائدة', 'حسب عدد أصوات «مفيد»'),
  newest('الأحدث', 'الأحدث أولاً'),
  oldest('الأقدم', 'الأقدم أولاً'),
  highest('الأعلى تقييماً', 'خمس نجوم أولاً'),
  lowest('الأقل تقييماً', 'نجمة واحدة أولاً');

  const ReviewSort(this.label, this.description);
  final String label;
  final String description;
}

/// مراجعة واحدة لعمل.
class SeriesReview {
  const SeriesReview({
    required this.id,
    required this.seriesId,
    required this.authorId,
    required this.authorName,
    required this.rating,
    required this.title,
    required this.body,
    required this.createdAt,
    this.badge = SardBadge.none,
    this.helpful = 0,
    this.markedHelpful = false,
    this.containsSpoiler = false,
    this.editedAt,
  }) : assert(rating >= 1 && rating <= 5, 'التقييم من 1 إلى 5');

  final String id;
  final String seriesId;
  final String authorId;
  final String authorName;

  /// التقييم بالنجوم (1–5).
  final int rating;
  final String title;
  final String body;
  final DateTime createdAt;
  final SardBadge badge;
  final int helpful;
  final bool markedHelpful;
  final bool containsSpoiler;
  final DateTime? editedAt;

  /// وصف التقييم بالعربية.
  String get ratingLabel {
    switch (rating) {
      case 5:
        return 'تحفة فنية';
      case 4:
        return 'ممتاز';
      case 3:
        return 'جيد';
      case 2:
        return 'متوسط';
      default:
        return 'ضعيف';
    }
  }

  SeriesReview copyWith({
    int? rating,
    String? title,
    String? body,
    int? helpful,
    bool? markedHelpful,
    bool? containsSpoiler,
    DateTime? editedAt,
  }) {
    return SeriesReview(
      id: id,
      seriesId: seriesId,
      authorId: authorId,
      authorName: authorName,
      rating: rating ?? this.rating,
      title: title ?? this.title,
      body: body ?? this.body,
      createdAt: createdAt,
      badge: badge,
      helpful: helpful ?? this.helpful,
      markedHelpful: markedHelpful ?? this.markedHelpful,
      containsSpoiler: containsSpoiler ?? this.containsSpoiler,
      editedAt: editedAt ?? this.editedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'seriesId': seriesId,
        'authorId': authorId,
        'authorName': authorName,
        'rating': rating,
        'title': title,
        'body': body,
        'createdAt': createdAt.toIso8601String(),
        'badge': badge.name,
        'helpful': helpful,
        'markedHelpful': markedHelpful,
        'containsSpoiler': containsSpoiler,
        'editedAt': editedAt?.toIso8601String(),
      };

  factory SeriesReview.fromJson(Map<String, dynamic> j) {
    final badge = SardBadge.values.firstWhere(
      (e) => e.name == j['badge'],
      orElse: () => SardBadge.none,
    );
    final r = (j['rating'] as num?)?.toInt() ?? 5;
    return SeriesReview(
      id: '${j['id']}',
      seriesId: '${j['seriesId']}',
      authorId: '${j['authorId'] ?? ''}',
      authorName: '${j['authorName'] ?? 'قارئ'}',
      rating: r.clamp(1, 5),
      title: '${j['title'] ?? ''}',
      body: '${j['body'] ?? ''}',
      createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
      badge: badge,
      helpful: (j['helpful'] as num?)?.toInt() ?? 0,
      markedHelpful: j['markedHelpful'] == true,
      containsSpoiler: j['containsSpoiler'] == true,
      editedAt: j['editedAt'] == null ? null : DateTime.tryParse('${j['editedAt']}'),
    );
  }
}

/// ملخص تقييمات عمل: المتوسط والعدد وتوزيع النجوم.
class ReviewSummary {
  const ReviewSummary({
    required this.average,
    required this.count,
    required this.distribution,
    required this.recommendedPercent,
  });

  final double average;
  final int count;

  /// عدد المراجعات لكل نجمة (المفتاح 1–5).
  final Map<int, int> distribution;

  /// نسبة المراجعات 4–5 نجوم.
  final int recommendedPercent;

  static const empty = ReviewSummary(
    average: 0,
    count: 0,
    distribution: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
    recommendedPercent: 0,
  );

  /// نسبة مراجعات نجمة معيّنة (0–1).
  double shareOf(int stars) {
    if (count == 0) return 0;
    return (distribution[stars] ?? 0) / count;
  }

  /// المتوسط بصيغة «4.3».
  String get averageLabel => average == 0 ? '—' : average.toStringAsFixed(1);

  /// وصف المتوسط بالعربية.
  String get verdict {
    if (count == 0) return 'لا تقييمات بعد';
    if (average >= 4.5) return 'تحفة يوصي بها القراء';
    if (average >= 4.0) return 'عمل ممتاز';
    if (average >= 3.5) return 'عمل جيد جداً';
    if (average >= 3.0) return 'عمل جيد';
    if (average >= 2.0) return 'عمل متوسط';
    return 'عمل ضعيف التقييم';
  }

  static ReviewSummary fromReviews(List<SeriesReview> list) {
    if (list.isEmpty) return empty;
    final dist = <int, int>{1: 0, 2: 0, 3: 0, 4: 0, 5: 0};
    var sum = 0;
    var recommended = 0;
    for (final r in list) {
      dist[r.rating] = (dist[r.rating] ?? 0) + 1;
      sum += r.rating;
      if (r.rating >= 4) recommended++;
    }
    return ReviewSummary(
      average: sum / list.length,
      count: list.length,
      distribution: dist,
      recommendedPercent: (recommended * 100 / list.length).round(),
    );
  }
}

/// مخزن المراجعات: حفظ محلي وبذرة تجريبية.
class ReviewsStore extends ChangeNotifier {
  ReviewsStore(this._p) {
    _restore();
  }

  static const String _key = 'social_reviews_v2';

  final SharedPreferences _p;
  final List<SeriesReview> _reviews = <SeriesReview>[];

  static Future<ReviewsStore> load() async {
    final p = await SharedPreferences.getInstance();
    return ReviewsStore(p);
  }

  List<SeriesReview> get all => List.unmodifiable(_reviews);

  void _restore() {
    try {
      final raw = _p.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        _reviews
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => SeriesReview.fromJson(Map<String, dynamic>.from(e))));
      }
    } catch (_) {
      _reviews.clear();
    }
  }

  Future<void> _save() async {
    await _p.setString(_key, jsonEncode(_reviews.map((r) => r.toJson()).toList()));
  }

  /// بذرة تجريبية عربية عند أول فتح.
  Future<void> ensureDemo() async {
    if (_reviews.isNotEmpty) return;
    final now = DateTime.now();
    _reviews.addAll(<SeriesReview>[
      SeriesReview(
        id: 'r_demo_1',
        seriesId: 's1',
        authorId: 'u_ahmed',
        authorName: 'أحمد',
        badge: SardBadge.blue,
        rating: 5,
        title: 'أفضل ما قرأت هذا العام',
        body:
            'قصة محكمة من الفصل الأول، والشخصيات تتطور بشكل منطقي دون استعجال. الرسم في الفصول الأخيرة قفزة نوعية، والمشاهد القتالية واضحة وسهلة المتابعة رغم كثرة التفاصيل.',
        createdAt: now.subtract(const Duration(days: 1, hours: 2)),
        helpful: 214,
      ),
      SeriesReview(
        id: 'r_demo_2',
        seriesId: 's1',
        authorId: 'u_sara',
        authorName: 'سارة',
        rating: 4,
        title: 'ممتاز مع ملاحظة صغيرة',
        body:
            'العمل رائع إجمالاً، لكن بعض الفصول الوسطى بطيئة الإيقاع. البطلة الثانوية تستحق مساحة أكبر، فحواراتها من أجمل ما في العمل.',
        createdAt: now.subtract(const Duration(days: 2, hours: 5)),
        helpful: 96,
      ),
      SeriesReview(
        id: 'r_demo_3',
        seriesId: 's1',
        authorId: 'u_omar',
        authorName: 'عمر',
        rating: 5,
        title: 'يستحق كل دقيقة',
        body: 'بدأته بدافع الفضول وأنهيت 120 فصلاً في أسبوع. النهايات المفتوحة بين الفصول تجعلك لا تستطيع التوقف.',
        createdAt: now.subtract(const Duration(days: 3)),
        helpful: 58,
        containsSpoiler: true,
      ),
      SeriesReview(
        id: 'r_demo_4',
        seriesId: 's1',
        authorId: 'u_layla',
        authorName: 'ليلى',
        rating: 3,
        title: 'جيد لكنه ليس للجميع',
        body: 'الرسم جميل والقصة متماسكة، لكن الكوميديا أحياناً تكسر جدية المشاهد. إن كنت تحب الأعمال الهادئة فقد يعجبك أكثر مني.',
        createdAt: now.subtract(const Duration(days: 4, hours: 7)),
        helpful: 31,
      ),
      SeriesReview(
        id: 'r_demo_5',
        seriesId: 's2',
        authorId: 'u_noura',
        authorName: 'نورة',
        rating: 5,
        title: 'عمل دافئ ومختلف',
        body: 'أجواء العمل هادئة ومريحة، والعلاقات بين الشخصيات مكتوبة بصدق. أنصح به لمن يبحث عن قراءة مريحة بعد يوم طويل.',
        createdAt: now.subtract(const Duration(days: 1, hours: 9)),
        helpful: 77,
      ),
      SeriesReview(
        id: 'r_demo_6',
        seriesId: 's2',
        authorId: 'u_khalid',
        authorName: 'خالد',
        badge: SardBadge.yellow,
        rating: 4,
        title: 'ترجمة نظيفة وقصة لطيفة',
        body: 'كمترجم أعجبني ثبات المصطلحات. القصة بسيطة لكنها صادقة، والفصول القصيرة تجعلها مثالية للقراءة اليومية.',
        createdAt: now.subtract(const Duration(days: 5)),
        helpful: 44,
      ),
    ]);
    await _save();
    notifyListeners();
  }

  // ───────── استعلامات ─────────

  List<SeriesReview> forSeries(String seriesId, {ReviewSort sort = ReviewSort.helpful, int? stars}) {
    var list = _reviews.where((r) => r.seriesId == seriesId).toList();
    if (stars != null) list = list.where((r) => r.rating == stars).toList();
    switch (sort) {
      case ReviewSort.helpful:
        list.sort((a, b) => b.helpful.compareTo(a.helpful));
      case ReviewSort.newest:
        list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      case ReviewSort.oldest:
        list.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      case ReviewSort.highest:
        list.sort((a, b) => b.rating.compareTo(a.rating));
      case ReviewSort.lowest:
        list.sort((a, b) => a.rating.compareTo(b.rating));
    }
    return list;
  }

  ReviewSummary summary(String seriesId) => ReviewSummary.fromReviews(forSeries(seriesId));

  /// مراجعة المستخدم نفسه لعمل معيّن (إن وجدت).
  SeriesReview? myReview(String seriesId, String authorId) {
    for (final r in _reviews) {
      if (r.seriesId == seriesId && r.authorId == authorId) return r;
    }
    return null;
  }

  int countFor(String seriesId) => _reviews.where((r) => r.seriesId == seriesId).length;

  /// متوسط تقييم مستخدم معيّن (لملفه الشخصي).
  double averageByAuthor(String authorId) {
    final list = _reviews.where((r) => r.authorId == authorId).toList();
    if (list.isEmpty) return 0;
    return list.fold<int>(0, (a, r) => a + r.rating) / list.length;
  }

  // ───────── عمليات ─────────

  /// إضافة مراجعة أو تحديث المراجعة السابقة للمستخدم نفسه.
  /// يعيد null عند فشل التحقق، مع رسالة الخطأ في [errorOut].
  Future<SeriesReview?> upsert({
    required String seriesId,
    required String authorId,
    required String authorName,
    required int rating,
    required String title,
    required String body,
    SardBadge badge = SardBadge.none,
    bool containsSpoiler = false,
    DateTime? at,
  }) async {
    if (rating < 1 || rating > 5) return null;
    if (title.trim().isEmpty) return null;
    if (body.trim().length < 20) return null;
    final now = at ?? DateTime.now();
    final existing = myReview(seriesId, authorId);
    if (existing != null) {
      final updated = existing.copyWith(
        rating: rating,
        title: title.trim(),
        body: body.trim(),
        containsSpoiler: containsSpoiler,
        editedAt: now,
      );
      final idx = _reviews.indexOf(existing);
      _reviews[idx] = updated;
      await _save();
      notifyListeners();
      return updated;
    }
    final review = SeriesReview(
      id: _reviewId(),
      seriesId: seriesId,
      authorId: authorId,
      authorName: authorName,
      rating: rating,
      title: title.trim(),
      body: body.trim(),
      createdAt: now,
      badge: badge,
      containsSpoiler: containsSpoiler,
    );
    _reviews.insert(0, review);
    await _save();
    notifyListeners();
    return review;
  }

  /// حذف مراجعة.
  Future<bool> delete(String id) async {
    final before = _reviews.length;
    _reviews.removeWhere((r) => r.id == id);
    if (_reviews.length == before) return false;
    await _save();
    notifyListeners();
    return true;
  }

  /// تبديل «مفيد» على مراجعة.
  Future<void> toggleHelpful(String id) async {
    final idx = _reviews.indexWhere((r) => r.id == id);
    if (idx < 0) return;
    final r = _reviews[idx];
    _reviews[idx] = r.copyWith(
      helpful: r.markedHelpful ? r.helpful - 1 : r.helpful + 1,
      markedHelpful: !r.markedHelpful,
    );
    await _save();
    notifyListeners();
  }

  Future<void> clearAll() async {
    _reviews.clear();
    await _save();
    notifyListeners();
  }
}

/// التحقق القواعدي من حقول المراجعة قبل الحفظ.
String? validateReview({required String title, required String body, required int rating}) {
  if (rating < 1 || rating > 5) return 'اختر تقييماً من نجمة إلى 5 نجوم.';
  if (title.trim().isEmpty) return 'اكتب عنواناً قصيراً للمراجعة.';
  if (title.trim().length > 80) return 'العنوان طويل جداً (الحد 80 حرفاً).';
  if (body.trim().length < 20) return 'اكتب 20 حرفاً على الأقل لتوضيح رأيك.';
  if (body.trim().length > 2000) return 'المراجعة طويلة جداً (الحد 2000 حرف).';
  return null;
}

/// ───────── الواجهات ─────────

/// عرض النجوم: ممتلئة/فارغة حسب القيمة (تدعم الكسور بصرياً بتقريب النصف).
class StarDisplay extends StatelessWidget {
  const StarDisplay({super.key, required this.value, this.size = 18, this.max = 5});
  final double value;
  final double size;
  final int max;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= max; i++)
          SIcon(
            value >= i - 0.25 ? SardIcons.star_rounded : SardIcons.star_border_rounded,
            size: size,
            color: value >= i - 0.25 ? p.gold : p.textDim,
          ),
      ],
    );
  }
}

/// إدخال التقييم بالنجوم (نقر لاختيار 1–5).
class StarRatingInput extends StatelessWidget {
  const StarRatingInput({super.key, required this.value, required this.onChanged, this.size = 34});
  final int value;
  final ValueChanged<int> onChanged;
  final double size;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= 5; i++)
          InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => onChanged(i),
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: SIcon(
                i <= value ? SardIcons.star_rounded : SardIcons.star_border_rounded,
                size: size,
                color: i <= value ? p.gold : p.textDim,
              ),
            ),
          ),
      ],
    );
  }
}

/// شاشة مراجعات عمل: ملخص + ترشيح + قائمة + زر كتابة مراجعة.
class ReviewsScreen extends StatefulWidget {
  const ReviewsScreen({
    super.key,
    required this.store,
    required this.series,
    this.myId = 'me',
    this.myName = 'أنا',
    this.myBadge = SardBadge.none,
  });

  final ReviewsStore store;
  final Series series;
  final String myId;
  final String myName;
  final SardBadge myBadge;

  @override
  State<ReviewsScreen> createState() => _ReviewsScreenState();
}

class _ReviewsScreenState extends State<ReviewsScreen> {
  ReviewSort _sort = ReviewSort.helpful;
  int? _starsFilter;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final summary = widget.store.summary(widget.series.id);
    final mine = widget.store.myReview(widget.series.id, widget.myId);
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('مراجعات «${widget.series.title}»'),
        actions: [
          IconButton(
            onPressed: () => _showSortSheet(context),
            icon: const SIcon(SardIcons.tune_rounded),
            tooltip: 'ترتيب المراجعات',
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          final list = widget.store.forSeries(widget.series.id, sort: _sort, stars: _starsFilter);
          return Column(
            children: [
              ReviewSummaryCard(
                summary: summary,
                selectedStars: _starsFilter,
                onSelectStars: (s) => setState(() => _starsFilter = _starsFilter == s ? null : s),
              ),
              if (mine != null)
                _MyReviewBanner(
                  review: mine,
                  onEdit: () => _showEditor(context, existing: mine),
                  onDelete: () async {
                    await widget.store.delete(mine.id);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم حذف مراجعتك.')),
                      );
                    }
                  },
                ),
              Expanded(
                child: list.isEmpty
                    ? _EmptyReviews(onWrite: () => _showEditor(context))
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, i) => ReviewTile(
                          review: list[i],
                          store: widget.store,
                          myId: widget.myId,
                        ),
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showEditor(context, existing: widget.store.myReview(widget.series.id, widget.myId)),
        icon: const SIcon(SardIcons.edit_rounded, size: 18),
        label: Text(widget.store.myReview(widget.series.id, widget.myId) == null ? 'اكتب مراجعة' : 'عدّل مراجعتك'),
      ),
    );
  }

  void _showSortSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ترتيب المراجعات', style: context.ds(size: 18)),
              const SizedBox(height: 12),
              for (final s in ReviewSort.values)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(s.label, style: context.ts(size: 15, w: FontWeight.w700)),
                  subtitle: Text(s.description, style: context.ts(size: 12.5, color: context.pal.textDim)),
                  trailing: s == _sort
                      ? SIcon(SardIcons.check_circle_rounded, color: context.pal.accent)
                      : const SizedBox(width: 24),
                  onTap: () {
                    Navigator.of(context).pop();
                    setState(() => _sort = s);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditor(BuildContext context, {SeriesReview? existing}) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
        child: ReviewEditorSheet(
          store: widget.store,
          seriesId: widget.series.id,
          myId: widget.myId,
          myName: widget.myName,
          myBadge: widget.myBadge,
          existing: existing,
        ),
      ),
    );
  }
}

/// بطاقة ملخص التقييم: المتوسط الكبير + أشرطة توزيع النجوم القابلة للنقر.
class ReviewSummaryCard extends StatelessWidget {
  const ReviewSummaryCard({super.key, required this.summary, this.selectedStars, required this.onSelectStars});
  final ReviewSummary summary;
  final int? selectedStars;
  final ValueChanged<int> onSelectStars;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
        boxShadow: softShadow(p, strength: 0.5),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Text(summary.averageLabel, style: context.ds(size: 40)),
              StarDisplay(value: summary.average, size: 16),
              const SizedBox(height: 4),
              Text(
                '${summary.count} مراجعة',
                style: context.ts(size: 12, color: p.textDim),
              ),
              Text(
                summary.verdict,
                style: context.ts(size: 11.5, color: p.accent, w: FontWeight.w700),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              children: [
                for (var stars = 5; stars >= 1; stars--)
                  _StarBarRow(
                    stars: stars,
                    count: summary.distribution[stars] ?? 0,
                    share: summary.shareOf(stars),
                    selected: selectedStars == stars,
                    onTap: () => onSelectStars(stars),
                  ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    SIcon(SardIcons.thumb_up_rounded, size: 14, color: p.gold),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        'يوصي به ${summary.recommendedPercent}٪ من القراء',
                        style: context.ts(size: 12, color: p.textDim, w: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// صف شريط توزيع لنجمة معيّنة.
class _StarBarRow extends StatelessWidget {
  const _StarBarRow({required this.stars, required this.count, required this.share, required this.selected, required this.onTap});
  final int stars;
  final int count;
  final double share;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      borderRadius: BorderRadius.circular(6),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Text('$stars', style: context.ts(size: 12, w: FontWeight.w700)),
            const SizedBox(width: 2),
            SIcon(SardIcons.star_rounded, size: 12, color: selected ? p.accent : p.gold),
            const SizedBox(width: 6),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: share,
                  minHeight: 7,
                  backgroundColor: p.surfaceHi,
                  valueColor: AlwaysStoppedAnimation<Color>(selected ? p.accent : p.gold),
                ),
              ),
            ),
            const SizedBox(width: 6),
            SizedBox(
              width: 28,
              child: Text('$count', style: context.ts(size: 11.5, color: p.textDim), textAlign: TextAlign.end),
            ),
          ],
        ),
      ),
    );
  }
}

/// شريط «مراجعتك» أعلى القائمة مع زرّي التعديل والحذف.
class _MyReviewBanner extends StatelessWidget {
  const _MyReviewBanner({required this.review, required this.onEdit, required this.onDelete});
  final SeriesReview review;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: tint(p.gold, 0.10),
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: tint(p.gold, 0.35)),
      ),
      child: Row(
        children: [
          SIcon(SardIcons.star_rounded, size: 18, color: p.gold),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('مراجعتك: ${review.rating} نجوم — ${review.ratingLabel}', style: context.ts(size: 13, w: FontWeight.w700)),
                Text(review.title, style: context.ts(size: 12, color: p.textDim), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          TextButton(onPressed: onEdit, child: const Text('تعديل')),
          TextButton(
            onPressed: onDelete,
            child: Text('حذف', style: context.ts(size: 13, color: const Color(0xFFE5484D))),
          ),
        ],
      ),
    );
  }
}

/// حالة فارغة للمراجعات.
class _EmptyReviews extends StatelessWidget {
  const _EmptyReviews({required this.onWrite});
  final VoidCallback onWrite;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: tint(p.gold, 0.14), shape: BoxShape.circle),
              child: SIcon(SardIcons.star_rounded, size: 34, color: p.gold),
            ),
            const SizedBox(height: 16),
            Text('لا مراجعات بعد', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'كن أول من يقيّم هذا العمل ويشارك رأيه مع القراء.',
              style: context.ts(size: 13.5, color: p.textDim),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: onWrite,
              icon: const SIcon(SardIcons.edit_rounded, size: 18),
              label: const Text('اكتب أول مراجعة'),
            ),
          ],
        ),
      ),
    );
  }
}

/// بطاقة مراجعة واحدة: نجوم + عنوان + نص + زر «مفيد».
class ReviewTile extends StatefulWidget {
  const ReviewTile({super.key, required this.review, required this.store, required this.myId});
  final SeriesReview review;
  final ReviewsStore store;
  final String myId;

  @override
  State<ReviewTile> createState() => _ReviewTileState();
}

class _ReviewTileState extends State<ReviewTile> {
  bool _showSpoiler = false;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final r = widget.review;
    final mine = r.authorId == widget.myId;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.14),
                  shape: BoxShape.circle,
                ),
                child: Text(
                  r.authorName.isEmpty ? '؟' : r.authorName.characters.first,
                  style: context.ds(size: 16, color: p.accent),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.authorName, style: context.ts(size: 13.5, w: FontWeight.w700)),
                    Text(
                      '${socialTimeAgo(r.createdAt)}${r.editedAt != null ? ' · عُدِّلت' : ''}',
                      style: context.ts(size: 11.5, color: p.textDim),
                    ),
                  ],
                ),
              ),
              StarDisplay(value: r.rating.toDouble(), size: 15),
            ],
          ),
          const SizedBox(height: 10),
          Text(r.title, style: context.ds(size: 15.5)),
          const SizedBox(height: 4),
          if (r.containsSpoiler && !_showSpoiler)
            InkWell(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              onTap: () => setState(() => _showSpoiler = true),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                decoration: BoxDecoration(
                  color: tint(p.gold, 0.10),
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                ),
                child: Row(
                  children: [
                    SIcon(SardIcons.visibility_off_outlined, size: 16, color: p.gold),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'هذه المراجعة تحتوي حرقاً — اضغط لعرضها',
                        style: context.ts(size: 12.5, color: p.textDim, w: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            Text(r.body, style: context.ts(size: 13.5, height: 1.55)),
          const SizedBox(height: 10),
          Row(
            children: [
              InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () => widget.store.toggleHelpful(r.id),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(
                        r.markedHelpful ? SardIcons.thumb_up_rounded : SardIcons.thumb_up_off_alt_rounded,
                        size: 16,
                        color: r.markedHelpful ? p.accent : p.textDim,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'مفيد (${formatCount(r.helpful)})',
                        style: context.ts(
                          size: 12.5,
                          color: r.markedHelpful ? p.accent : p.textDim,
                          w: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: tint(p.gold, 0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(r.ratingLabel, style: context.ts(size: 11.5, color: p.gold, w: FontWeight.w700)),
              ),
              if (mine) ...[
                const SizedBox(width: 8),
                Text('مراجعتك', style: context.ts(size: 11.5, color: p.textDim)),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

/// ورقة كتابة/تعديل مراجعة: نجوم + عنوان + نص + مفتاح الحرق.
class ReviewEditorSheet extends StatefulWidget {
  const ReviewEditorSheet({
    super.key,
    required this.store,
    required this.seriesId,
    required this.myId,
    required this.myName,
    this.myBadge = SardBadge.none,
    this.existing,
  });

  final ReviewsStore store;
  final String seriesId;
  final String myId;
  final String myName;
  final SardBadge myBadge;
  final SeriesReview? existing;

  @override
  State<ReviewEditorSheet> createState() => _ReviewEditorSheetState();
}

class _ReviewEditorSheetState extends State<ReviewEditorSheet> {
  late int _rating;
  late final TextEditingController _titleCtrl;
  late final TextEditingController _bodyCtrl;
  late bool _spoiler;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _rating = widget.existing?.rating ?? 5;
    _titleCtrl = TextEditingController(text: widget.existing?.title ?? '');
    _bodyCtrl = TextEditingController(text: widget.existing?.body ?? '');
    _spoiler = widget.existing?.containsSpoiler ?? false;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final temp = SeriesReview(
      id: 'tmp',
      seriesId: widget.seriesId,
      authorId: widget.myId,
      authorName: widget.myName,
      rating: _rating,
      title: '',
      body: '',
      createdAt: DateTime.now(),
    );
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.existing == null ? 'اكتب مراجعتك' : 'عدّل مراجعتك', style: context.ds(size: 18)),
            const SizedBox(height: 14),
            Row(
              children: [
                StarRatingInput(value: _rating, onChanged: (v) => setState(() => _rating = v)),
                const SizedBox(width: 10),
                Text(temp.ratingLabel, style: context.ts(size: 14, color: p.gold, w: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _titleCtrl,
              maxLength: 80,
              decoration: InputDecoration(
                labelText: 'عنوان المراجعة',
                hintText: 'مثال: أفضل ما قرأت هذا العام',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _bodyCtrl,
              maxLines: 5,
              maxLength: 2000,
              decoration: InputDecoration(
                labelText: 'رأيك بالتفصيل (20 حرفاً على الأقل)',
                hintText: 'ما الذي أعجبك؟ وما الذي لم يعجبك؟',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => setState(() => _spoiler = !_spoiler),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SIcon(
                          _spoiler ? SardIcons.visibility_off_outlined : SardIcons.visibility_outlined,
                          size: 16,
                          color: _spoiler ? p.accent : p.textDim,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'تحتوي حرقاً',
                          style: context.ts(size: 12, color: _spoiler ? p.accent : p.textDim, w: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                Text('مراجعة واحدة لكل عمل', style: context.ts(size: 11, color: p.textDim)),
              ],
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _busy ? null : _submit,
                child: Text(widget.existing == null ? 'نشر المراجعة' : 'حفظ التعديل'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final error = validateReview(title: _titleCtrl.text, body: _bodyCtrl.text, rating: _rating);
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
      return;
    }
    setState(() => _busy = true);
    await widget.store.upsert(
      seriesId: widget.seriesId,
      authorId: widget.myId,
      authorName: widget.myName,
      rating: _rating,
      title: _titleCtrl.text,
      body: _bodyCtrl.text,
      badge: widget.myBadge,
      containsSpoiler: _spoiler,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم نشر مراجعتك، شكراً لمشاركتك.')),
    );
  }
}
