import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// الإنجازات — 16 إنجازاً تُفتح بقواعد صريحة من إحصاءات القراءة:
/// فصول، أعمال، سلاسل أيام، تعليقات، مراجعات، دوائر، مشاركات، قراءة ليلية.
///
/// لا ذكاء اصطناعي: كل إنجاز له شرط عددي واضح يُفحص في [AchievementsStore].
/// ──────────────────────────────────────────────────────────────────────────

/// تصنيف الإنجاز.
enum AchievementCategory {
  reading('القراءة', 'إنجازات إتمام الفصول والأعمال'),
  streak('المواظبة', 'إنجازات القراءة اليومية المتتالية'),
  social('المجتمع', 'إنجازات التفاعل مع القراء'),
  explorer('الاستكشاف', 'إنجازات تجربة أنواع وأعمال جديدة'),
  special('خاصة', 'إنجازات بأوقات أو شروط مميزة');

  const AchievementCategory(this.label, this.description);
  final String label;
  final String description;
}

/// ندرة الإنجاز (تحدد لونه ونقاطه).
enum AchievementRarity {
  bronze('برونزي', 10, Color(0xFFB07A3F)),
  silver('فضي', 25, Color(0xFF8A94A6)),
  gold('ذهبي', 50, Color(0xFFE9B44C)),
  diamond('ماسي', 100, Color(0xFF22C7D6));

  const AchievementRarity(this.label, this.points, this.color);
  final String label;
  final int points;
  final Color color;
}

/// تعريف إنجاز واحد: شرطه العددي ونوع الإحصاءة التي يقيسها.
class AchievementDef {
  const AchievementDef({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.rarity,
    required this.metric,
    required this.target,
    required this.icon,
    this.secret = false,
  });

  final String id;
  final String title;
  final String description;
  final AchievementCategory category;
  final AchievementRarity rarity;

  /// اسم الإحصاءة المقيسة (انظر [AchievementStats]).
  final String metric;

  /// القيمة المطلوبة لفتح الإنجاز.
  final int target;
  final SIconData icon;

  /// إنجاز سرّي: لا يظهر وصفه قبل فتحه.
  final bool secret;

  /// نسبة التقدم نحو الإنجاز (0–1) من إحصاءات معيّنة.
  double progressOf(AchievementStats s) {
    final v = s.valueOf(metric);
    if (target <= 0) return 1;
    return (v / target).clamp(0.0, 1.0);
  }

  bool unlockedBy(AchievementStats s) => s.valueOf(metric) >= target;
}

/// الإحصاءات الداخلة في تقييم الإنجازات (تُبنى من مخازن التطبيق).
class AchievementStats {
  const AchievementStats({
    this.chaptersRead = 0,
    this.seriesFinished = 0,
    this.seriesStarted = 0,
    this.comments = 0,
    this.reviews = 0,
    this.shares = 0,
    this.circlesJoined = 0,
    this.streakDays = 0,
    this.nightChapters = 0,
    this.morningChapters = 0,
    this.fiveStarReviews = 0,
    this.genresTried = 0,
    this.likesReceived = 0,
    this.quotesShared = 0,
    this.daysActive = 0,
    this.pagesRead = 0,
  });

  final int chaptersRead;
  final int seriesFinished;
  final int seriesStarted;
  final int comments;
  final int reviews;
  final int shares;
  final int circlesJoined;
  final int streakDays;
  final int nightChapters;
  final int morningChapters;
  final int fiveStarReviews;
  final int genresTried;
  final int likesReceived;
  final int quotesShared;
  final int daysActive;
  final int pagesRead;

  /// قيمة إحصاءة بالاسم (للقواعد العامة في [AchievementDef]).
  int valueOf(String metric) {
    switch (metric) {
      case 'chaptersRead':
        return chaptersRead;
      case 'seriesFinished':
        return seriesFinished;
      case 'seriesStarted':
        return seriesStarted;
      case 'comments':
        return comments;
      case 'reviews':
        return reviews;
      case 'shares':
        return shares;
      case 'circlesJoined':
        return circlesJoined;
      case 'streakDays':
        return streakDays;
      case 'nightChapters':
        return nightChapters;
      case 'morningChapters':
        return morningChapters;
      case 'fiveStarReviews':
        return fiveStarReviews;
      case 'genresTried':
        return genresTried;
      case 'likesReceived':
        return likesReceived;
      case 'quotesShared':
        return quotesShared;
      case 'daysActive':
        return daysActive;
      case 'pagesRead':
        return pagesRead;
      default:
        return 0;
    }
  }

  AchievementStats copyWith({
    int? chaptersRead,
    int? seriesFinished,
    int? seriesStarted,
    int? comments,
    int? reviews,
    int? shares,
    int? circlesJoined,
    int? streakDays,
    int? nightChapters,
    int? morningChapters,
    int? fiveStarReviews,
    int? genresTried,
    int? likesReceived,
    int? quotesShared,
    int? daysActive,
    int? pagesRead,
  }) {
    return AchievementStats(
      chaptersRead: chaptersRead ?? this.chaptersRead,
      seriesFinished: seriesFinished ?? this.seriesFinished,
      seriesStarted: seriesStarted ?? this.seriesStarted,
      comments: comments ?? this.comments,
      reviews: reviews ?? this.reviews,
      shares: shares ?? this.shares,
      circlesJoined: circlesJoined ?? this.circlesJoined,
      streakDays: streakDays ?? this.streakDays,
      nightChapters: nightChapters ?? this.nightChapters,
      morningChapters: morningChapters ?? this.morningChapters,
      fiveStarReviews: fiveStarReviews ?? this.fiveStarReviews,
      genresTried: genresTried ?? this.genresTried,
      likesReceived: likesReceived ?? this.likesReceived,
      quotesShared: quotesShared ?? this.quotesShared,
      daysActive: daysActive ?? this.daysActive,
      pagesRead: pagesRead ?? this.pagesRead,
    );
  }
}

/// الإنجازات الـ16 الرسمية للتطبيق.
const List<AchievementDef> kAchievements = <AchievementDef>[
  AchievementDef(
    id: 'first_chapter',
    title: 'أول خطوة',
    description: 'اقرأ أول فصل في رحلتك مع Senok.',
    category: AchievementCategory.reading,
    rarity: AchievementRarity.bronze,
    metric: 'chaptersRead',
    target: 1,
    icon: SardIcons.menu_book_rounded,
  ),
  AchievementDef(
    id: 'ten_chapters',
    title: 'قارئ ناشئ',
    description: 'اقرأ 10 فصول.',
    category: AchievementCategory.reading,
    rarity: AchievementRarity.bronze,
    metric: 'chaptersRead',
    target: 10,
    icon: SardIcons.auto_stories_rounded,
  ),
  AchievementDef(
    id: 'hundred_chapters',
    title: 'دودة كتب',
    description: 'اقرأ 100 فصل.',
    category: AchievementCategory.reading,
    rarity: AchievementRarity.silver,
    metric: 'chaptersRead',
    target: 100,
    icon: SardIcons.collections_bookmark_rounded,
  ),
  AchievementDef(
    id: 'thousand_chapters',
    title: 'أسطورة القراءة',
    description: 'اقرأ 1000 فصل — إنجاز لا يصل إليه إلا القليل.',
    category: AchievementCategory.reading,
    rarity: AchievementRarity.diamond,
    metric: 'chaptersRead',
    target: 1000,
    icon: SardIcons.local_fire_department_rounded,
  ),
  AchievementDef(
    id: 'first_series',
    title: 'أول عمل مُنهى',
    description: 'أنهِ قراءة عمل كامل حتى آخر فصل.',
    category: AchievementCategory.reading,
    rarity: AchievementRarity.silver,
    metric: 'seriesFinished',
    target: 1,
    icon: SardIcons.check_circle_rounded,
  ),
  AchievementDef(
    id: 'five_series',
    title: 'جامع الأعمال',
    description: 'أنهِ 5 أعمال كاملة.',
    category: AchievementCategory.reading,
    rarity: AchievementRarity.gold,
    metric: 'seriesFinished',
    target: 5,
    icon: SardIcons.star_rounded,
  ),
  AchievementDef(
    id: 'seven_streak',
    title: 'أسبوع من القراءة',
    description: 'اقرأ 7 أيام متتالية دون انقطاع.',
    category: AchievementCategory.streak,
    rarity: AchievementRarity.silver,
    metric: 'streakDays',
    target: 7,
    icon: SardIcons.calendar_today_rounded,
  ),
  AchievementDef(
    id: 'thirty_streak',
    title: 'شهر من المواظبة',
    description: 'اقرأ 30 يوماً متتالياً — عادة راسخة.',
    category: AchievementCategory.streak,
    rarity: AchievementRarity.diamond,
    metric: 'streakDays',
    target: 30,
    icon: SardIcons.bolt_rounded,
  ),
  AchievementDef(
    id: 'first_comment',
    title: 'صوتك مسموع',
    description: 'اكتب أول تعليق لك على فصل.',
    category: AchievementCategory.social,
    rarity: AchievementRarity.bronze,
    metric: 'comments',
    target: 1,
    icon: SardIcons.chat_bubble_rounded,
  ),
  AchievementDef(
    id: 'ten_comments',
    title: 'ناقد المجتمع',
    description: 'اكتب 10 تعليقات.',
    category: AchievementCategory.social,
    rarity: AchievementRarity.silver,
    metric: 'comments',
    target: 10,
    icon: SardIcons.forum_rounded,
  ),
  AchievementDef(
    id: 'first_review',
    title: 'أول مراجعة',
    description: 'انشر أول مراجعة عن عمل.',
    category: AchievementCategory.social,
    rarity: AchievementRarity.bronze,
    metric: 'reviews',
    target: 1,
    icon: SardIcons.edit_rounded,
  ),
  AchievementDef(
    id: 'five_star_fan',
    title: 'عاشق التحف',
    description: 'قيّم 5 أعمال بخمس نجوم.',
    category: AchievementCategory.social,
    rarity: AchievementRarity.gold,
    metric: 'fiveStarReviews',
    target: 5,
    icon: SardIcons.favorite_rounded,
  ),
  AchievementDef(
    id: 'circle_join',
    title: 'روح الفريق',
    description: 'انضم إلى أول دائرة قراءة.',
    category: AchievementCategory.social,
    rarity: AchievementRarity.bronze,
    metric: 'circlesJoined',
    target: 1,
    icon: SardIcons.groups_rounded,
  ),
  AchievementDef(
    id: 'genre_explorer',
    title: 'مستكشف الأنواع',
    description: 'جرّب القراءة في 5 تصنيفات مختلفة.',
    category: AchievementCategory.explorer,
    rarity: AchievementRarity.silver,
    metric: 'genresTried',
    target: 5,
    icon: SardIcons.explore_rounded,
  ),
  AchievementDef(
    id: 'night_owl',
    title: 'بومة الليل',
    description: 'اقرأ 20 فصلاً بعد منتصف الليل.',
    category: AchievementCategory.special,
    rarity: AchievementRarity.gold,
    metric: 'nightChapters',
    target: 20,
    icon: SardIcons.nightlight_round,
    secret: true,
  ),
  AchievementDef(
    id: 'early_bird',
    title: 'طائر الصباح',
    description: 'اقرأ 10 فصول قبل السابعة صباحاً.',
    category: AchievementCategory.special,
    rarity: AchievementRarity.gold,
    metric: 'morningChapters',
    target: 10,
    icon: SardIcons.wb_sunny_rounded,
    secret: true,
  ),
];

/// تقدّم إنجاز واحد (محفوظ محلياً).
class AchievementProgress {
  const AchievementProgress({
    required this.defId,
    this.unlocked = false,
    this.unlockedAt,
    this.shown = false,
  });

  final String defId;
  final bool unlocked;
  final DateTime? unlockedAt;

  /// هل عُرض إشعار فتح الإنجاز للمستخدم؟
  final bool shown;

  AchievementProgress copyWith({bool? unlocked, DateTime? unlockedAt, bool? shown}) {
    return AchievementProgress(
      defId: defId,
      unlocked: unlocked ?? this.unlocked,
      unlockedAt: unlockedAt ?? this.unlockedAt,
      shown: shown ?? this.shown,
    );
  }

  Map<String, dynamic> toJson() => {
        'defId': defId,
        'unlocked': unlocked,
        'unlockedAt': unlockedAt?.toIso8601String(),
        'shown': shown,
      };

  factory AchievementProgress.fromJson(Map<String, dynamic> j) {
    return AchievementProgress(
      defId: '${j['defId']}',
      unlocked: j['unlocked'] == true,
      unlockedAt: j['unlockedAt'] == null ? null : DateTime.tryParse('${j['unlockedAt']}'),
      shown: j['shown'] == true,
    );
  }
}

/// مخزن الإنجازات: تقييم قواعدي للإحصاءات + حفظ حالات الفتح.
class AchievementsStore extends ChangeNotifier {
  AchievementsStore(this._p) {
    _restore();
  }

  static const String _key = 'social_achievements_v2';

  final SharedPreferences _p;
  final Map<String, AchievementProgress> _progress = <String, AchievementProgress>{};

  static Future<AchievementsStore> load() async {
    final p = await SharedPreferences.getInstance();
    return AchievementsStore(p);
  }

  /// حالة إنجاز معيّن (غير مفتوح افتراضياً).
  AchievementProgress progressFor(String defId) {
    return _progress[defId] ?? AchievementProgress(defId: defId);
  }

  List<AchievementDef> get unlockedDefs {
    return kAchievements.where((d) => progressFor(d.id).unlocked).toList();
  }

  List<AchievementDef> get lockedDefs {
    return kAchievements.where((d) => !progressFor(d.id).unlocked).toList();
  }

  int get unlockedCount => unlockedDefs.length;

  /// مجموع نقاط الإنجازات المفتوحة.
  int get totalPoints {
    var sum = 0;
    for (final d in unlockedDefs) {
      sum += d.rarity.points;
    }
    return sum;
  }

  /// الإنجازات التي فُتحت ولم يُعرض إشعارها بعد.
  List<AchievementDef> get pendingToasts {
    return kAchievements
        .where((d) {
          final pr = progressFor(d.id);
          return pr.unlocked && !pr.shown;
        })
        .toList();
  }

  /// أقرب الإنجازات للفتح (أعلى نسبة تقدم، غير مفتوحة).
  List<AchievementDef> nextAchievements(AchievementStats stats, {int limit = 3}) {
    final locked = lockedDefs.toList();
    locked.sort((a, b) => b.progressOf(stats).compareTo(a.progressOf(stats)));
    return locked.take(limit).toList();
  }

  /// تقييم الإحصاءات وفتح ما استحق. يعيد الإنجازات التي فُتحت الآن.
  Future<List<AchievementDef>> evaluate(AchievementStats stats, {DateTime? at}) async {
    final now = at ?? DateTime.now();
    final newly = <AchievementDef>[];
    var changed = false;
    for (final def in kAchievements) {
      final pr = progressFor(def.id);
      if (!pr.unlocked && def.unlockedBy(stats)) {
        _progress[def.id] = AchievementProgress(defId: def.id, unlocked: true, unlockedAt: now, shown: false);
        newly.add(def);
        changed = true;
      }
    }
    if (changed) {
      await _save();
      notifyListeners();
    }
    return newly;
  }

  /// تعليم إنجاز كمُعرض (بعد ظهور إشعاره).
  Future<void> markShown(String defId) async {
    final pr = progressFor(defId);
    if (!pr.unlocked || pr.shown) return;
    _progress[defId] = pr.copyWith(shown: true);
    await _save();
    notifyListeners();
  }

  /// تعليم كل الإشعارات المعلّقة كمُعرضة.
  Future<void> markAllShown() async {
    var changed = false;
    for (final d in kAchievements) {
      final pr = progressFor(d.id);
      if (pr.unlocked && !pr.shown) {
        _progress[d.id] = pr.copyWith(shown: true);
        changed = true;
      }
    }
    if (changed) {
      await _save();
      notifyListeners();
    }
  }

  void _restore() {
    try {
      final raw = _p.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        for (final item in list.whereType<Map>()) {
          final pr = AchievementProgress.fromJson(Map<String, dynamic>.from(item));
          _progress[pr.defId] = pr;
        }
      }
    } catch (_) {
      _progress.clear();
    }
  }

  Future<void> _save() async {
    await _p.setString(_key, jsonEncode(_progress.values.map((e) => e.toJson()).toList()));
  }

  Future<void> clearAll() async {
    _progress.clear();
    await _save();
    notifyListeners();
  }
}

/// ───────── الواجهات ─────────

/// شاشة الإنجازات: ملخص النقاط + أقرب إنجاز + شبكة الإنجازات حسب التصنيف.
class AchievementsScreen extends StatefulWidget {
  const AchievementsScreen({super.key, required this.store, required this.stats});
  final AchievementsStore store;
  final AchievementStats stats;

  @override
  State<AchievementsScreen> createState() => _AchievementsScreenState();
}

class _AchievementsScreenState extends State<AchievementsScreen> {
  AchievementCategory? _category;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final next = widget.store.nextAchievements(widget.stats, limit: 3);
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: const Text('إنجازاتي')),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          final unlocked = widget.store.unlockedDefs;
          final locked = widget.store.lockedDefs;
          final shown = _category == null
              ? kAchievements
              : kAchievements.where((d) => d.category == _category).toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              _PointsSummary(
                unlocked: unlocked.length,
                total: kAchievements.length,
                points: widget.store.totalPoints,
              ),
              const SizedBox(height: 16),
              if (next.isNotEmpty) ...[
                Text('أقرب إنجاز للفتح', style: context.ds(size: 16)),
                const SizedBox(height: 8),
                for (final d in next)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: AchievementTile(
                      def: d,
                      progress: widget.store.progressFor(d.id),
                      stats: widget.stats,
                      onTap: () => _showDetail(context, d),
                    ),
                  ),
                const SizedBox(height: 8),
              ],
              Text('كل الإنجازات', style: context.ds(size: 16)),
              const SizedBox(height: 8),
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _categoryChip(context, null, 'الكل'),
                    for (final c in AchievementCategory.values)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(start: 6),
                        child: _categoryChip(context, c, c.label),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.92,
                ),
                itemCount: shown.length,
                itemBuilder: (context, i) {
                  final d = shown[i];
                  return AchievementTile(
                    def: d,
                    progress: widget.store.progressFor(d.id),
                    stats: widget.stats,
                    compact: true,
                    onTap: () => _showDetail(context, d),
                  );
                },
              ),
              const SizedBox(height: 12),
              Text(
                'الإنجازات تُحفظ محلياً وتُفتح تلقائياً عند استيفاء شروطها.',
                style: context.ts(size: 11.5, color: p.textDim),
                textAlign: TextAlign.center,
              ),
              if (locked.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: tint(p.gold, 0.10),
                      borderRadius: BorderRadius.circular(p.r(0.9)),
                    ),
                    child: Text(
                      'فتحت كل الإنجازات! أنت أسطورة قراءة حقيقية. 🏆',
                      style: context.ts(size: 13.5, color: p.gold, w: FontWeight.w700),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _categoryChip(BuildContext context, AchievementCategory? c, String label) {
    final p = context.pal;
    final selected = _category == c;
    return ActionChip(
      label: Text(label),
      labelStyle: context.ts(size: 12, color: selected ? p.onAccent : p.text, w: FontWeight.w700),
      backgroundColor: selected ? p.accent : p.surface,
      side: BorderSide(color: selected ? p.accent : p.border),
      onPressed: () => setState(() => _category = c),
    );
  }

  void _showDetail(BuildContext context, AchievementDef def) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => AchievementDetailSheet(
        def: def,
        progress: widget.store.progressFor(def.id),
        stats: widget.stats,
      ),
    );
  }
}

/// ملخص النقاط: عدد المفتوح + النقاط + شريط التقدم الكلي.
class _PointsSummary extends StatelessWidget {
  const _PointsSummary({required this.unlocked, required this.total, required this.points});
  final int unlocked;
  final int total;
  final int points;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final ratio = total == 0 ? 0.0 : unlocked / total;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
        boxShadow: softShadow(p, strength: 0.5),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.gold, 0.14),
              shape: BoxShape.circle,
            ),
            child: SIcon(SardIcons.star_rounded, size: 28, color: p.gold),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'فتحت $unlocked من $total إنجازاً',
                  style: context.ds(size: 16),
                ),
                const SizedBox(height: 2),
                Text(
                  '$points نقطة إنجاز',
                  style: context.ts(size: 13, color: p.gold, w: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: ratio,
                    minHeight: 7,
                    backgroundColor: p.surfaceHi,
                    valueColor: AlwaysStoppedAnimation<Color>(p.gold),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            '${(ratio * 100).round()}٪',
            style: context.ds(size: 18, color: p.gold),
          ),
        ],
      ),
    );
  }
}

/// بطاقة إنجاز واحد (مدمجة للشبكة أو كاملة لقائمة «الأقرب»).
class AchievementTile extends StatelessWidget {
  const AchievementTile({
    super.key,
    required this.def,
    required this.progress,
    required this.stats,
    this.compact = false,
    required this.onTap,
  });

  final AchievementDef def;
  final AchievementProgress progress;
  final AchievementStats stats;
  final bool compact;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final unlocked = progress.unlocked;
    final ratio = def.progressOf(stats);
    final color = unlocked ? def.rarity.color : p.textDim;
    final hidden = def.secret && !unlocked;
    return InkWell(
      borderRadius: BorderRadius.circular(p.r(0.9)),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: unlocked ? tint(def.rarity.color, 0.08) : p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(
            color: unlocked ? tint(def.rarity.color, 0.45) : p.border,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(color, 0.14),
                    shape: BoxShape.circle,
                  ),
                  child: SIcon(
                    hidden ? SardIcons.question_mark_rounded : def.icon,
                    size: 22,
                    color: color,
                  ),
                ),
                const Spacer(),
                AchievementRarityBadge(rarity: def.rarity, locked: !unlocked),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              hidden ? 'إنجاز سرّي' : def.title,
              style: context.ds(size: compact ? 14.5 : 16, color: unlocked ? null : p.textDim),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              hidden ? 'أكمل شرطاً خفياً لاكتشافه.' : def.description,
              style: context.ts(size: 12, color: p.textDim, height: 1.4),
              maxLines: compact ? 2 : 3,
              overflow: TextOverflow.ellipsis,
            ),
            const Spacer(),
            if (unlocked)
              Row(
                children: [
                  SIcon(SardIcons.check_circle_rounded, size: 15, color: def.rarity.color),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      progress.unlockedAt == null ? 'مفتوح' : 'فُتح ${progress.unlockedAt!.year}/${progress.unlockedAt!.month}/${progress.unlockedAt!.day}',
                      style: context.ts(size: 11.5, color: def.rarity.color, w: FontWeight.w700),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              )
            else
              AchievementProgressBar(
                ratio: ratio,
                current: stats.valueOf(def.metric),
                target: def.target,
                color: def.rarity.color,
              ),
          ],
        ),
      ),
    );
  }
}

/// شارة ندرة الإنجاز (لون + نقاط).
class AchievementRarityBadge extends StatelessWidget {
  const AchievementRarityBadge({super.key, required this.rarity, this.locked = false});
  final AchievementRarity rarity;
  final bool locked;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = locked ? p.textDim : rarity.color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: tint(color, 0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        '${rarity.label} · ${rarity.points} ن',
        style: context.ts(size: 10.5, color: color, w: FontWeight.w800),
      ),
    );
  }
}

/// شريط تقدم إنجاز: نسبة + «القيمة الحالية / الهدف».
class AchievementProgressBar extends StatelessWidget {
  const AchievementProgressBar({super.key, required this.ratio, required this.current, required this.target, required this.color});
  final double ratio;
  final int current;
  final int target;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: ratio,
                  minHeight: 6,
                  backgroundColor: p.surfaceHi,
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                ),
              ),
            ),
            const SizedBox(width: 6),
            Text(
              '$current/$target',
              style: context.ts(size: 11, color: p.textDim, w: FontWeight.w700),
            ),
          ],
        ),
      ],
    );
  }
}

/// ورقة تفاصيل إنجاز: الوصف الكامل + الشرط + التقدم + زر المشاركة.
class AchievementDetailSheet extends StatelessWidget {
  const AchievementDetailSheet({super.key, required this.def, required this.progress, required this.stats});
  final AchievementDef def;
  final AchievementProgress progress;
  final AchievementStats stats;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final unlocked = progress.unlocked;
    final hidden = def.secret && !unlocked;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(unlocked ? def.rarity.color : p.textDim, 0.14),
                    shape: BoxShape.circle,
                  ),
                  child: SIcon(
                    hidden ? SardIcons.question_mark_rounded : def.icon,
                    size: 28,
                    color: unlocked ? def.rarity.color : p.textDim,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(hidden ? 'إنجاز سرّي' : def.title, style: context.ds(size: 19)),
                      const SizedBox(height: 2),
                      Text(
                        '${def.category.label} · ${def.rarity.label} · ${def.rarity.points} نقطة',
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                    ],
                  ),
                ),
                AchievementRarityBadge(rarity: def.rarity, locked: !unlocked),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              hidden ? 'هذا الإنجاز سرّي، وسيظهر وصفه بعد فتحه.' : def.description,
              style: context.ts(size: 14, height: 1.55),
            ),
            const SizedBox(height: 14),
            if (unlocked)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: tint(def.rarity.color, 0.10),
                  borderRadius: BorderRadius.circular(p.r(0.8)),
                ),
                child: Row(
                  children: [
                    SIcon(SardIcons.check_circle_rounded, size: 18, color: def.rarity.color),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        progress.unlockedAt == null
                            ? 'إنجاز مفتوح — أحسنت!'
                            : 'فُتح في ${progress.unlockedAt!.year}/${progress.unlockedAt!.month}/${progress.unlockedAt!.day} — أحسنت!',
                        style: context.ts(size: 13, color: def.rarity.color, w: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              )
            else
              AchievementProgressBar(
                ratio: def.progressOf(stats),
                current: stats.valueOf(def.metric),
                target: def.target,
                color: def.rarity.color,
              ),
            if (!hidden) ...[
              const SizedBox(height: 8),
              Text(
                'الشرط: ${def.target} ${def.metric == 'chaptersRead' ? 'فصلاً' : def.metric == 'streakDays' ? 'يوماً متتالياً' : def.metric == 'seriesFinished' ? 'عملاً مُنهى' : def.metric == 'comments' ? 'تعليقاً' : def.metric == 'reviews' ? 'مراجعة' : def.metric == 'fiveStarReviews' ? 'تقييماً بخمس نجوم' : def.metric == 'circlesJoined' ? 'دائرة' : def.metric == 'genresTried' ? 'تصنيفات' : def.metric == 'nightChapters' ? 'فصلاً ليلياً' : 'فصلاً صباحياً'}',
                style: context.ts(size: 12.5, color: p.textDim),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// إشعار احتفالي بفتح إنجاز (يُعرض كـ SnackBar مخصص من الشاشة المضيفة).
class AchievementUnlockToast extends StatelessWidget {
  const AchievementUnlockToast({super.key, required this.def});
  final AchievementDef def;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: tint(def.rarity.color, 0.5)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(def.rarity.color, 0.16),
              shape: BoxShape.circle,
            ),
            child: SIcon(def.icon, size: 22, color: def.rarity.color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('فتحت إنجازاً جديداً!', style: context.ts(size: 12, color: p.textDim, w: FontWeight.w700)),
                Text(def.title, style: context.ds(size: 15)),
                Text(
                  '${def.rarity.label} · +${def.rarity.points} نقطة',
                  style: context.ts(size: 11.5, color: def.rarity.color, w: FontWeight.w700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
