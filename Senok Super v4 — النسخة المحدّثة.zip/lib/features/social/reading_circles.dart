import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'comments_v2.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// دوائر القراءة — مجموعات قراءة جماعية حول عمل واحد: إنشاء، انضمام،
/// نقاش، تقدم جماعي، وترتيب الأعضاء. كود دعوة قواعدي من 6 أحرف.
///
/// كل البيانات محلية تجريبية في هذه النسخة (تُحفظ في SharedPreferences).
/// ──────────────────────────────────────────────────────────────────────────

int _circleSeq = 0;
String _circleId(String prefix) => '${prefix}_${DateTime.now().microsecondsSinceEpoch}_${_circleSeq++}';

/// دور العضو داخل الدائرة.
enum CircleRole {
  owner('مؤسس الدائرة', 'ينشئ الدائرة ويدير أعضاءها'),
  moderator('مشرف', 'يساعد في إدارة النقاش والأعضاء'),
  member('عضو', 'يقرأ ويشارك في النقاش');

  const CircleRole(this.label, this.description);
  final String label;
  final String description;
}

/// عضو في دائرة قراءة.
class CircleMember {
  const CircleMember({
    required this.userId,
    required this.name,
    required this.joinedAt,
    this.badge = SardBadge.none,
    this.role = CircleRole.member,
    this.currentChapter = 0,
    this.online = false,
  });

  final String userId;
  final String name;
  final DateTime joinedAt;
  final SardBadge badge;
  final CircleRole role;
  final int currentChapter;
  final bool online;

  /// نسبة تقدم العضو نحو هدف الدائرة (0–1).
  double progressTo(int target) {
    if (target <= 0) return 0;
    return (currentChapter / target).clamp(0.0, 1.0);
  }

  CircleMember copyWith({int? currentChapter, bool? online, CircleRole? role}) {
    return CircleMember(
      userId: userId,
      name: name,
      joinedAt: joinedAt,
      badge: badge,
      role: role ?? this.role,
      currentChapter: currentChapter ?? this.currentChapter,
      online: online ?? this.online,
    );
  }

  Map<String, dynamic> toJson() => {
        'userId': userId,
        'name': name,
        'joinedAt': joinedAt.toIso8601String(),
        'badge': badge.name,
        'role': role.name,
        'currentChapter': currentChapter,
        'online': online,
      };

  factory CircleMember.fromJson(Map<String, dynamic> j) {
    final badge = SardBadge.values.firstWhere(
      (e) => e.name == j['badge'],
      orElse: () => SardBadge.none,
    );
    final role = CircleRole.values.firstWhere(
      (e) => e.name == j['role'],
      orElse: () => CircleRole.member,
    );
    return CircleMember(
      userId: '${j['userId']}',
      name: '${j['name'] ?? 'قارئ'}',
      joinedAt: DateTime.tryParse('${j['joinedAt']}') ?? DateTime.now(),
      badge: badge,
      role: role,
      currentChapter: (j['currentChapter'] as num?)?.toInt() ?? 0,
      online: j['online'] == true,
    );
  }
}

/// نوع رسالة داخل نقاش الدائرة.
enum CircleMessageType {
  text('رسالة', 'رسالة نصية عادية'),
  progress('تقدّم', 'تحديث تلقائي عن تقدم القراءة'),
  system('نظام', 'حدث في الدائرة: انضمام أو مغادرة');

  const CircleMessageType(this.label, this.description);
  final String label;
  final String description;
}

/// رسالة في نقاش دائرة.
class CircleMessage {
  const CircleMessage({
    required this.id,
    required this.circleId,
    required this.authorId,
    required this.authorName,
    required this.text,
    required this.createdAt,
    this.type = CircleMessageType.text,
    this.badge = SardBadge.none,
  });

  final String id;
  final String circleId;
  final String authorId;
  final String authorName;
  final String text;
  final DateTime createdAt;
  final CircleMessageType type;
  final SardBadge badge;

  Map<String, dynamic> toJson() => {
        'id': id,
        'circleId': circleId,
        'authorId': authorId,
        'authorName': authorName,
        'text': text,
        'createdAt': createdAt.toIso8601String(),
        'type': type.name,
        'badge': badge.name,
      };

  factory CircleMessage.fromJson(Map<String, dynamic> j) {
    final type = CircleMessageType.values.firstWhere(
      (e) => e.name == j['type'],
      orElse: () => CircleMessageType.text,
    );
    final badge = SardBadge.values.firstWhere(
      (e) => e.name == j['badge'],
      orElse: () => SardBadge.none,
    );
    return CircleMessage(
      id: '${j['id']}',
      circleId: '${j['circleId']}',
      authorId: '${j['authorId'] ?? ''}',
      authorName: '${j['authorName'] ?? 'قارئ'}',
      text: '${j['text'] ?? ''}',
      createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
      type: type,
      badge: badge,
    );
  }
}

/// دائرة قراءة جماعية حول عمل واحد.
class ReadingCircle {
  const ReadingCircle({
    required this.id,
    required this.name,
    required this.seriesId,
    required this.seriesTitle,
    required this.ownerId,
    required this.ownerName,
    required this.createdAt,
    this.description = '',
    this.members = const [],
    this.maxMembers = 20,
    this.isPublic = true,
    this.currentChapter = 0,
    this.targetChapter = 0,
    this.deadline,
    this.inviteCode = '',
    this.tags = const [],
    this.colorIndex = 0,
  });

  final String id;
  final String name;
  final String seriesId;
  final String seriesTitle;
  final String ownerId;
  final String ownerName;
  final DateTime createdAt;
  final String description;
  final List<CircleMember> members;
  final int maxMembers;
  final bool isPublic;
  final int currentChapter;
  final int targetChapter;
  final DateTime? deadline;
  final String inviteCode;
  final List<String> tags;
  final int colorIndex;

  int get memberCount => members.length;
  bool get isFull => memberCount >= maxMembers;
  bool get hasGoal => targetChapter > 0;

  /// متوسط تقدم الأعضاء نحو الهدف (0–1).
  double get averageProgress {
    if (!hasGoal || members.isEmpty) return 0;
    final sum = members.fold<int>(0, (a, m) => a + m.currentChapter);
    return (sum / members.length / targetChapter).clamp(0.0, 1.0);
  }

  /// الأعضاء مرتبون حسب التقدم (الأكثر تقدماً أولاً).
  List<CircleMember> get leaderboard {
    final list = List<CircleMember>.from(members);
    list.sort((a, b) => b.currentChapter.compareTo(a.currentChapter));
    return list;
  }

  /// هل انتهت مهلة الهدف؟
  bool get deadlinePassed => deadline != null && DateTime.now().isAfter(deadline!);

  /// عدد الأيام المتبقية على المهلة (null = بلا مهلة).
  int? get daysLeft {
    if (deadline == null) return null;
    return deadline!.difference(DateTime.now()).inDays;
  }

  bool isMember(String userId) => members.any((m) => m.userId == userId);

  CircleMember? member(String userId) {
    for (final m in members) {
      if (m.userId == userId) return m;
    }
    return null;
  }

  ReadingCircle copyWith({
    String? name,
    String? ownerId,
    String? description,
    List<CircleMember>? members,
    int? maxMembers,
    bool? isPublic,
    int? currentChapter,
    int? targetChapter,
    DateTime? deadline,
    List<String>? tags,
  }) {
    return ReadingCircle(
      id: id,
      name: name ?? this.name,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      ownerId: ownerId ?? this.ownerId,
      ownerName: ownerName,
      createdAt: createdAt,
      description: description ?? this.description,
      members: members ?? this.members,
      maxMembers: maxMembers ?? this.maxMembers,
      isPublic: isPublic ?? this.isPublic,
      currentChapter: currentChapter ?? this.currentChapter,
      targetChapter: targetChapter ?? this.targetChapter,
      deadline: deadline ?? this.deadline,
      inviteCode: inviteCode,
      tags: tags ?? this.tags,
      colorIndex: colorIndex,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'seriesId': seriesId,
        'seriesTitle': seriesTitle,
        'ownerId': ownerId,
        'ownerName': ownerName,
        'createdAt': createdAt.toIso8601String(),
        'description': description,
        'members': members.map((m) => m.toJson()).toList(),
        'maxMembers': maxMembers,
        'isPublic': isPublic,
        'currentChapter': currentChapter,
        'targetChapter': targetChapter,
        'deadline': deadline?.toIso8601String(),
        'inviteCode': inviteCode,
        'tags': tags,
        'colorIndex': colorIndex,
      };

  factory ReadingCircle.fromJson(Map<String, dynamic> j) {
    return ReadingCircle(
      id: '${j['id']}',
      name: '${j['name'] ?? 'دائرة قراءة'}',
      seriesId: '${j['seriesId']}',
      seriesTitle: '${j['seriesTitle'] ?? ''}',
      ownerId: '${j['ownerId'] ?? ''}',
      ownerName: '${j['ownerName'] ?? 'قارئ'}',
      createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
      description: '${j['description'] ?? ''}',
      members: ((j['members'] as List?) ?? const [])
          .whereType<Map>()
          .map((e) => CircleMember.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      maxMembers: (j['maxMembers'] as num?)?.toInt() ?? 20,
      isPublic: j['isPublic'] != false,
      currentChapter: (j['currentChapter'] as num?)?.toInt() ?? 0,
      targetChapter: (j['targetChapter'] as num?)?.toInt() ?? 0,
      deadline: j['deadline'] == null ? null : DateTime.tryParse('${j['deadline']}'),
      inviteCode: '${j['inviteCode'] ?? ''}',
      tags: ((j['tags'] as List?) ?? const []).map((e) => '$e').toList(),
      colorIndex: (j['colorIndex'] as num?)?.toInt() ?? 0,
    );
  }
}

/// ألوان الدوائر (تدوير قواعدي حسب رقم الدائرة).
const List<int> kCircleColors = <int>[
  0xFFE63E2A,
  0xFF3B9EFF,
  0xFF0F9D75,
  0xFF7C4DFF,
  0xFFE8A33D,
  0xFFE0457B,
];

Color circleColor(int index) => Color(kCircleColors[index % kCircleColors.length]);

/// توليد كود دعوة من 6 أحرف (أحرف وأرقام واضحة بلا التباس).
String generateInviteCode({math.Random? random}) {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  final r = random ?? math.Random();
  final buf = StringBuffer();
  for (var i = 0; i < 6; i++) {
    buf.write(chars[r.nextInt(chars.length)]);
  }
  return buf.toString();
}

/// التحقق القواعدي من بيانات دائرة جديدة.
String? validateCircle({required String name, required int maxMembers, required int targetChapter, required int seriesChapters}) {
  if (name.trim().isEmpty) return 'اكتب اسماً للدائرة.';
  if (name.trim().length > 40) return 'الاسم طويل جداً (الحد 40 حرفاً).';
  if (maxMembers < 2 || maxMembers > 50) return 'عدد الأعضاء من 2 إلى 50.';
  if (targetChapter < 0) return 'هدف الفصول غير صحيح.';
  if (seriesChapters > 0 && targetChapter > seriesChapters) {
    return 'الهدف يتجاوز عدد فصول العمل ($seriesChapters).';
  }
  return null;
}

/// مخزن دوائر القراءة: حفظ محلي وبذرة تجريبية ونقاش.
class ReadingCirclesStore extends ChangeNotifier {
  ReadingCirclesStore(this._p) {
    _restore();
  }

  static const String _key = 'social_circles_v2';
  static const String _messagesKey = 'social_circles_v2_messages';

  final SharedPreferences _p;
  final List<ReadingCircle> _circles = <ReadingCircle>[];
  final List<CircleMessage> _messages = <CircleMessage>[];

  static Future<ReadingCirclesStore> load() async {
    final p = await SharedPreferences.getInstance();
    return ReadingCirclesStore(p);
  }

  List<ReadingCircle> get all => List.unmodifiable(_circles);

  void _restore() {
    try {
      final raw = _p.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        _circles
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => ReadingCircle.fromJson(Map<String, dynamic>.from(e))));
      }
      final rawM = _p.getString(_messagesKey);
      if (rawM != null && rawM.isNotEmpty) {
        final list = jsonDecode(rawM) as List;
        _messages
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => CircleMessage.fromJson(Map<String, dynamic>.from(e))));
      }
    } catch (_) {
      _circles.clear();
      _messages.clear();
    }
  }

  Future<void> _save() async {
    await _p.setString(_key, jsonEncode(_circles.map((c) => c.toJson()).toList()));
    await _p.setString(_messagesKey, jsonEncode(_messages.map((m) => m.toJson()).toList()));
  }

  /// بذرة تجريبية عربية عند أول فتح.
  Future<void> ensureDemo() async {
    if (_circles.isNotEmpty) return;
    final now = DateTime.now();
    final c1 = ReadingCircle(
      id: 'circle_demo_1',
      name: 'قرّاء الفجر',
      seriesId: 's1',
      seriesTitle: 'سيف الفجر',
      ownerId: 'u_ahmed',
      ownerName: 'أحمد',
      createdAt: now.subtract(const Duration(days: 12)),
      description: 'نقرأ فصلين كل يوم ونناقش الأحداث معاً دون حرق للمتأخرين. مرحباً بالجميع!',
      maxMembers: 20,
      isPublic: true,
      targetChapter: 30,
      deadline: now.add(const Duration(days: 9)),
      inviteCode: 'FAJR12',
      tags: const ['أكشن', 'مغامرة'],
      colorIndex: 0,
      members: <CircleMember>[
        CircleMember(userId: 'u_ahmed', name: 'أحمد', joinedAt: now.subtract(const Duration(days: 12)), badge: SardBadge.blue, role: CircleRole.owner, currentChapter: 18, online: true),
        CircleMember(userId: 'u_sara', name: 'سارة', joinedAt: now.subtract(const Duration(days: 11)), currentChapter: 17, online: true),
        CircleMember(userId: 'u_omar', name: 'عمر', joinedAt: now.subtract(const Duration(days: 10)), currentChapter: 15),
        CircleMember(userId: 'u_layla', name: 'ليلى', joinedAt: now.subtract(const Duration(days: 8)), currentChapter: 14, online: true),
        CircleMember(userId: 'u_khalid', name: 'خالد', joinedAt: now.subtract(const Duration(days: 5)), badge: SardBadge.yellow, currentChapter: 12),
        CircleMember(userId: 'u_noura', name: 'نورة', joinedAt: now.subtract(const Duration(days: 3)), currentChapter: 9),
      ],
    );
    final c2 = ReadingCircle(
      id: 'circle_demo_2',
      name: 'نادي الرومانسية الهادئة',
      seriesId: 's2',
      seriesTitle: 'زهرة الربيع',
      ownerId: 'u_noura',
      ownerName: 'نورة',
      createdAt: now.subtract(const Duration(days: 20)),
      description: 'دائرة هادئة لقراءة الأعمال الرومانسية ببطء، فصل واحد كل يومين مع نقاش مسائي.',
      maxMembers: 12,
      isPublic: true,
      targetChapter: 20,
      deadline: now.add(const Duration(days: 18)),
      inviteCode: 'WARD34',
      tags: const ['رومانسي', 'شريحة حياة'],
      colorIndex: 5,
      members: <CircleMember>[
        CircleMember(userId: 'u_noura', name: 'نورة', joinedAt: now.subtract(const Duration(days: 20)), role: CircleRole.owner, currentChapter: 11, online: true),
        CircleMember(userId: 'u_huda', name: 'هدى', joinedAt: now.subtract(const Duration(days: 18)), currentChapter: 11),
        CircleMember(userId: 'u_youssef', name: 'يوسف', joinedAt: now.subtract(const Duration(days: 15)), currentChapter: 8),
        CircleMember(userId: 'u_sara', name: 'سارة', joinedAt: now.subtract(const Duration(days: 9)), currentChapter: 7, online: true),
      ],
    );
    final c3 = ReadingCircle(
      id: 'circle_demo_3',
      name: 'فرقة الليل',
      seriesId: 's1',
      seriesTitle: 'سيف الفجر',
      ownerId: 'u_tariq',
      ownerName: 'طارق',
      createdAt: now.subtract(const Duration(days: 4)),
      description: 'دائرة صغيرة خاصة لأصدقاء يقرؤون ليلاً. الدخول بكود الدعوة فقط.',
      maxMembers: 8,
      isPublic: false,
      targetChapter: 15,
      inviteCode: 'LAYL56',
      tags: const ['ليلي', 'أصدقاء'],
      colorIndex: 3,
      members: <CircleMember>[
        CircleMember(userId: 'u_tariq', name: 'طارق', joinedAt: now.subtract(const Duration(days: 4)), role: CircleRole.owner, currentChapter: 6, online: true),
        CircleMember(userId: 'u_ahmed', name: 'أحمد', joinedAt: now.subtract(const Duration(days: 3)), badge: SardBadge.blue, currentChapter: 5),
      ],
    );
    _circles.addAll(<ReadingCircle>[c1, c2, c3]);
    _messages.addAll(<CircleMessage>[
      CircleMessage(
        id: 'm_demo_1',
        circleId: 'circle_demo_1',
        authorId: 'u_sara',
        authorName: 'سارة',
        text: 'الفصل 17 كان قوياً جداً! من توقّع أن يعود الحارس القديم؟',
        createdAt: now.subtract(const Duration(hours: 2)),
      ),
      CircleMessage(
        id: 'm_demo_2',
        circleId: 'circle_demo_1',
        authorId: 'u_ahmed',
        authorName: 'أحمد',
        text: 'أرجو عدم حرق ما بعد الفصل 17، ما زال بعض الأعضاء في الفصل 12.',
        createdAt: now.subtract(const Duration(hours: 1, minutes: 40)),
        badge: SardBadge.blue,
      ),
      CircleMessage(
        id: 'm_demo_3',
        circleId: 'circle_demo_1',
        authorId: 'system',
        authorName: 'النظام',
        text: 'انضمّت نورة إلى الدائرة.',
        createdAt: now.subtract(const Duration(days: 3)),
        type: CircleMessageType.system,
      ),
      CircleMessage(
        id: 'm_demo_4',
        circleId: 'circle_demo_2',
        authorId: 'u_noura',
        authorName: 'نورة',
        text: 'موعد النقاش المسائي اليوم الساعة 9، لا تتأخروا.',
        createdAt: now.subtract(const Duration(hours: 5)),
      ),
      CircleMessage(
        id: 'm_demo_5',
        circleId: 'circle_demo_2',
        authorId: 'u_huda',
        authorName: 'هدى',
        text: 'الفصل 11 مؤثر جداً، بكيت في النهاية.',
        createdAt: now.subtract(const Duration(hours: 3)),
      ),
    ]);
    await _save();
    notifyListeners();
  }

  // ───────── استعلامات ─────────

  ReadingCircle? byId(String id) {
    for (final c in _circles) {
      if (c.id == id) return c;
    }
    return null;
  }

  ReadingCircle? byInviteCode(String code) {
    final clean = code.trim().toUpperCase();
    for (final c in _circles) {
      if (c.inviteCode.toUpperCase() == clean) return c;
    }
    return null;
  }

  /// الدوائر العامة (قابلة للاكتشاف).
  List<ReadingCircle> get publicCircles => _circles.where((c) => c.isPublic).toList();

  /// دوائر المستخدم (عضو فيها).
  List<ReadingCircle> myCircles(String userId) => _circles.where((c) => c.isMember(userId)).toList();

  /// دوائر عمل معيّن.
  List<ReadingCircle> forSeries(String seriesId) => _circles.where((c) => c.seriesId == seriesId).toList();

  /// بحث بالاسم أو العمل أو الوسوم.
  List<ReadingCircle> search(String query) {
    final q = query.trim();
    if (q.isEmpty) return publicCircles;
    return _circles
        .where((c) =>
            c.isPublic &&
            (c.name.contains(q) || c.seriesTitle.contains(q) || c.tags.any((t) => t.contains(q))))
        .toList();
  }

  /// رسائل نقاش دائرة مرتبة زمنياً.
  List<CircleMessage> messages(String circleId) {
    final list = _messages.where((m) => m.circleId == circleId).toList();
    list.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    return list;
  }

  int messageCount(String circleId) => _messages.where((m) => m.circleId == circleId).length;

  // ───────── عمليات ─────────

  /// إنشاء دائرة جديدة (المُنشئ يصبح المالك والعضو الأول).
  Future<ReadingCircle?> create({
    required String name,
    required String seriesId,
    required String seriesTitle,
    required String ownerId,
    required String ownerName,
    String description = '',
    int maxMembers = 20,
    bool isPublic = true,
    int targetChapter = 0,
    DateTime? deadline,
    List<String> tags = const [],
    DateTime? at,
  }) async {
    final now = at ?? DateTime.now();
    final code = generateInviteCode();
    final circle = ReadingCircle(
      id: _circleId('circle'),
      name: name.trim(),
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      ownerId: ownerId,
      ownerName: ownerName,
      createdAt: now,
      description: description.trim(),
      maxMembers: maxMembers,
      isPublic: isPublic,
      targetChapter: targetChapter,
      deadline: deadline,
      inviteCode: code,
      tags: tags,
      colorIndex: _circles.length % kCircleColors.length,
      members: <CircleMember>[
        CircleMember(
          userId: ownerId,
          name: ownerName,
          joinedAt: now,
          role: CircleRole.owner,
          currentChapter: 0,
        ),
      ],
    );
    _circles.insert(0, circle);
    _messages.add(CircleMessage(
      id: _circleId('m'),
      circleId: circle.id,
      authorId: 'system',
      authorName: 'النظام',
      text: 'أُنشئت الدائرة «${circle.name}».',
      createdAt: now,
      type: CircleMessageType.system,
    ));
    await _save();
    notifyListeners();
    return circle;
  }

  /// الانضمام إلى دائرة (عامة أو بكود دعوة). يعيد رسالة خطأ أو null عند النجاح.
  Future<String?> join(String circleId, String userId, String userName, {SardBadge badge = SardBadge.none, String? inviteCode}) async {
    final idx = _circles.indexWhere((c) => c.id == circleId);
    if (idx < 0) return 'الدائرة غير موجودة.';
    final circle = _circles[idx];
    if (circle.isMember(userId)) return 'أنت عضو في هذه الدائرة بالفعل.';
    if (circle.isFull) return 'الدائرة ممتلئة.';
    if (!circle.isPublic) {
      if (inviteCode == null || inviteCode.trim().toUpperCase() != circle.inviteCode.toUpperCase()) {
        return 'هذه دائرة خاصة، أدخل كود الدعوة الصحيح.';
      }
    }
    final now = DateTime.now();
    final next = List<CircleMember>.from(circle.members)
      ..add(CircleMember(userId: userId, name: userName, joinedAt: now, badge: badge));
    _circles[idx] = circle.copyWith(members: next);
    _messages.add(CircleMessage(
      id: _circleId('m'),
      circleId: circle.id,
      authorId: 'system',
      authorName: 'النظام',
      text: 'انضمّ $userName إلى الدائرة.',
      createdAt: now,
      type: CircleMessageType.system,
    ));
    await _save();
    notifyListeners();
    return null;
  }

  /// مغادرة دائرة (المالك لا يغادر إلا بنقل الملكية لأقدم عضو).
  Future<String?> leave(String circleId, String userId) async {
    final idx = _circles.indexWhere((c) => c.id == circleId);
    if (idx < 0) return 'الدائرة غير موجودة.';
    final circle = _circles[idx];
    final member = circle.member(userId);
    if (member == null) return 'أنت لست عضواً في هذه الدائرة.';
    if (member.role == CircleRole.owner) {
      final others = circle.members.where((m) => m.userId != userId).toList();
      if (others.isEmpty) {
        _circles.removeAt(idx);
        await _save();
        notifyListeners();
        return null;
      }
      final next = others.map((m) {
        if (m.userId == others.first.userId) return m.copyWith(role: CircleRole.owner);
        return m;
      }).toList();
      _circles[idx] = circle.copyWith(members: next, ownerId: others.first.userId);
      await _save();
      notifyListeners();
      return null;
    }
    final next = circle.members.where((m) => m.userId != userId).toList();
    _circles[idx] = circle.copyWith(members: next);
    await _save();
    notifyListeners();
    return null;
  }

  /// تحديث تقدم عضو (الفصل الذي وصل إليه) مع رسالة تقدم تلقائية كل 5 فصول.
  Future<void> updateProgress(String circleId, String userId, int chapter, {String? userName}) async {
    final idx = _circles.indexWhere((c) => c.id == circleId);
    if (idx < 0) return;
    final circle = _circles[idx];
    final member = circle.member(userId);
    if (member == null) return;
    if (chapter <= member.currentChapter) return;
    final next = circle.members
        .map((m) => m.userId == userId ? m.copyWith(currentChapter: chapter) : m)
        .toList();
    _circles[idx] = circle.copyWith(members: next, currentChapter: math.max(circle.currentChapter, chapter));
    if (chapter % 5 == 0) {
      final now = DateTime.now();
      _messages.add(CircleMessage(
        id: _circleId('m'),
        circleId: circle.id,
        authorId: 'system',
        authorName: 'النظام',
        text: 'وصل ${userName ?? member.name} إلى الفصل $chapter.',
        createdAt: now,
        type: CircleMessageType.progress,
      ));
    }
    await _save();
    notifyListeners();
  }

  /// نشر رسالة في نقاش الدائرة.
  Future<CircleMessage?> postMessage({
    required String circleId,
    required String authorId,
    required String authorName,
    required String text,
    SardBadge badge = SardBadge.none,
    DateTime? at,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 500) return null;
    final circle = byId(circleId);
    if (circle == null || !circle.isMember(authorId)) return null;
    final now = at ?? DateTime.now();
    final msg = CircleMessage(
      id: _circleId('m'),
      circleId: circleId,
      authorId: authorId,
      authorName: authorName,
      text: clean,
      createdAt: now,
      badge: badge,
    );
    _messages.add(msg);
    await _save();
    notifyListeners();
    return msg;
  }

  /// ترقية عضو إلى مشرف (للمالك فقط).
  Future<bool> promote(String circleId, String ownerId, String userId) async {
    final idx = _circles.indexWhere((c) => c.id == circleId);
    if (idx < 0) return false;
    final circle = _circles[idx];
    if (circle.ownerId != ownerId) return false;
    final next = circle.members
        .map((m) => m.userId == userId && m.role == CircleRole.member ? m.copyWith(role: CircleRole.moderator) : m)
        .toList();
    _circles[idx] = circle.copyWith(members: next);
    await _save();
    notifyListeners();
    return true;
  }

  /// طرد عضو (للمالك والمشرفين، وليس المالك نفسه).
  Future<bool> kick(String circleId, String byUserId, String userId) async {
    final idx = _circles.indexWhere((c) => c.id == circleId);
    if (idx < 0) return false;
    final circle = _circles[idx];
    final by = circle.member(byUserId);
    final target = circle.member(userId);
    if (by == null || target == null) return false;
    if (target.role == CircleRole.owner) return false;
    if (by.role == CircleRole.member) return false;
    if (by.role == CircleRole.moderator && target.role == CircleRole.moderator) return false;
    final next = circle.members.where((m) => m.userId != userId).toList();
    _circles[idx] = circle.copyWith(members: next);
    await _save();
    notifyListeners();
    return true;
  }

  Future<void> clearAll() async {
    _circles.clear();
    _messages.clear();
    await _save();
    notifyListeners();
  }
}

/// ───────── الواجهات ─────────

/// شاشة الدوائر: تبويبات (دوائري / اكتشف) + بحث + إنشاء.
class ReadingCirclesScreen extends StatefulWidget {
  const ReadingCirclesScreen({
    super.key,
    required this.store,
    this.myId = 'me',
    this.myName = 'أنا',
    this.myBadge = SardBadge.none,
  });

  final ReadingCirclesStore store;
  final String myId;
  final String myName;
  final SardBadge myBadge;

  @override
  State<ReadingCirclesScreen> createState() => _ReadingCirclesScreenState();
}

class _ReadingCirclesScreenState extends State<ReadingCirclesScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  String _query = '';
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('دوائر القراءة'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const [
            Tab(text: 'دوائري'),
            Tab(text: 'اكتشف'),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => _showJoinSheet(context),
            icon: const SIcon(SardIcons.groups_rounded),
            tooltip: 'الانضمام بكود دعوة',
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          final mine = widget.store.myCircles(widget.myId);
          final discovered = widget.store.search(_query);
          return TabBarView(
            controller: _tabs,
            children: [
              mine.isEmpty
                  ? _EmptyCircles(onCreate: () => _showCreateSheet(context), onDiscover: () => _tabs.animateTo(1))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: mine.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, i) => CircleCard(
                        circle: mine[i],
                        store: widget.store,
                        myId: widget.myId,
                        onOpen: () => _openDetail(context, mine[i]),
                      ),
                    ),
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                    child: TextField(
                      controller: _searchCtrl,
                      onChanged: (v) => setState(() => _query = v),
                      decoration: InputDecoration(
                        hintText: 'ابحث عن دائرة أو عمل أو وسم…',
                        prefixIcon: const SIcon(SardIcons.search_rounded, size: 20),
                        filled: true,
                        fillColor: p.surface,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(p.r(0.8)),
                          borderSide: BorderSide(color: p.border),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(p.r(0.8)),
                          borderSide: BorderSide(color: p.border),
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      ),
                    ),
                  ),
                  Expanded(
                    child: discovered.isEmpty
                        ? Center(
                            child: Text(
                              'لا توجد دوائر مطابقة.',
                              style: context.ts(size: 14, color: p.textDim),
                            ),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.all(16),
                            itemCount: discovered.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 12),
                            itemBuilder: (context, i) => CircleCard(
                              circle: discovered[i],
                              store: widget.store,
                              myId: widget.myId,
                              onOpen: () => _openDetail(context, discovered[i]),
                            ),
                          ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateSheet(context),
        icon: const SIcon(SardIcons.add_circle_outline, size: 20),
        label: const Text('إنشاء دائرة'),
      ),
    );
  }

  void _openDetail(BuildContext context, ReadingCircle circle) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => CircleDetailScreen(
          store: widget.store,
          circleId: circle.id,
          myId: widget.myId,
          myName: widget.myName,
          myBadge: widget.myBadge,
        ),
      ),
    );
  }

  void _showCreateSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
        child: CircleCreateSheet(
          store: widget.store,
          myId: widget.myId,
          myName: widget.myName,
        ),
      ),
    );
  }

  void _showJoinSheet(BuildContext context) {
    final ctrl = TextEditingController();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 16,
          bottom: MediaQuery.viewInsetsOf(context).bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('الانضمام بكود دعوة', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'الدوائر الخاصة لا تظهر في الاكتشاف، أدخل كود الدعوة المكوّن من 6 أحرف.',
              style: context.ts(size: 12.5, color: context.pal.textDim),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: ctrl,
              maxLength: 6,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(
                labelText: 'كود الدعوة',
                hintText: 'مثال: FAJR12',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(context.pal.r(0.8))),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () async {
                  final circle = widget.store.byInviteCode(ctrl.text);
                  if (circle == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('الكود غير صحيح.')),
                    );
                    return;
                  }
                  final error = await widget.store.join(circle.id, widget.myId, widget.myName, badge: widget.myBadge);
                  if (context.mounted) {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(error ?? 'انضممت إلى «${circle.name}».')),
                    );
                  }
                },
                child: const Text('انضمام'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// حالة فارغة لتبويب «دوائري».
class _EmptyCircles extends StatelessWidget {
  const _EmptyCircles({required this.onCreate, required this.onDiscover});
  final VoidCallback onCreate;
  final VoidCallback onDiscover;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: tint(p.accent, 0.12), shape: BoxShape.circle),
              child: SIcon(SardIcons.groups_rounded, size: 34, color: p.accent),
            ),
            const SizedBox(height: 16),
            Text('لست عضواً في أي دائرة بعد', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'أنشئ دائرتك الخاصة أو انضم إلى دائرة موجودة واقرأ مع أصدقائك.',
              style: context.ts(size: 13.5, color: p.textDim),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: onCreate,
              icon: const SIcon(SardIcons.add_circle_outline, size: 18),
              label: const Text('إنشاء دائرة'),
            ),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: onDiscover, child: const Text('اكتشف الدوائر')),
          ],
        ),
      ),
    );
  }
}

/// بطاقة دائرة: اسم، عمل، أعضاء، تقدم، وسوم.
class CircleCard extends StatelessWidget {
  const CircleCard({super.key, required this.circle, required this.store, required this.myId, required this.onOpen});
  final ReadingCircle circle;
  final ReadingCirclesStore store;
  final String myId;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = circleColor(circle.colorIndex);
    final joined = circle.isMember(myId);
    return InkWell(
      borderRadius: BorderRadius.circular(p.r(1)),
      onTap: onOpen,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(1)),
          border: Border.all(color: p.border),
          boxShadow: softShadow(p, strength: 0.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(color, 0.14),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: SIcon(SardIcons.groups_rounded, size: 24, color: color),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(circle.name, style: context.ds(size: 16)),
                      Text(
                        '«${circle.seriesTitle}» · المؤسس ${circle.ownerName}',
                        style: context.ts(size: 12, color: p.textDim),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                if (!circle.isPublic)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      color: tint(p.textDim, 0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SIcon(SardIcons.lock_outline, size: 12, color: p.textDim),
                        const SizedBox(width: 3),
                        Text('خاصة', style: context.ts(size: 11, color: p.textDim, w: FontWeight.w700)),
                      ],
                    ),
                  ),
              ],
            ),
            if (circle.description.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(circle.description, style: context.ts(size: 13, height: 1.45), maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                SIcon(SardIcons.person_rounded, size: 15, color: p.textDim),
                const SizedBox(width: 4),
                Text('${circle.memberCount}/${circle.maxMembers} عضو', style: context.ts(size: 12.5, color: p.textDim)),
                const SizedBox(width: 12),
                SIcon(SardIcons.chat_bubble_rounded, size: 15, color: p.textDim),
                const SizedBox(width: 4),
                Text('${store.messageCount(circle.id)} رسالة', style: context.ts(size: 12.5, color: p.textDim)),
                const Spacer(),
                if (joined)
                  Text('عضو', style: context.ts(size: 12, color: p.accent, w: FontWeight.w700))
                else if (!circle.isFull)
                  Text('متاحة للانضمام', style: context.ts(size: 12, color: p.gold, w: FontWeight.w700))
                else
                  Text('ممتلئة', style: context.ts(size: 12, color: const Color(0xFFE5484D), w: FontWeight.w700)),
              ],
            ),
            if (circle.hasGoal) ...[
              const SizedBox(height: 10),
              CircleProgressBar(progress: circle.averageProgress, target: circle.targetChapter, color: color),
            ],
            if (circle.tags.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final t in circle.tags)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: p.surfaceHi,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(t, style: context.ts(size: 11.5, color: p.textDim, w: FontWeight.w700)),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// شريط تقدم جماعي نحو هدف الفصول.
class CircleProgressBar extends StatelessWidget {
  const CircleProgressBar({super.key, required this.progress, required this.target, required this.color});
  final double progress;
  final int target;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('تقدم الدائرة نحو الفصل $target', style: context.ts(size: 12, color: p.textDim, w: FontWeight.w700)),
            const Spacer(),
            Text('${(progress * 100).round()}٪', style: context.ts(size: 12, color: color, w: FontWeight.w800)),
          ],
        ),
        const SizedBox(height: 5),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 7,
            backgroundColor: p.surfaceHi,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}

/// ورقة إنشاء دائرة جديدة.
class CircleCreateSheet extends StatefulWidget {
  const CircleCreateSheet({super.key, required this.store, required this.myId, required this.myName});
  final ReadingCirclesStore store;
  final String myId;
  final String myName;

  @override
  State<CircleCreateSheet> createState() => _CircleCreateSheetState();
}

class _CircleCreateSheetState extends State<CircleCreateSheet> {
  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _seriesCtrl = TextEditingController(text: 'سيف الفجر');
  final _targetCtrl = TextEditingController(text: '30');
  int _maxMembers = 20;
  bool _isPublic = true;
  bool _busy = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    _seriesCtrl.dispose();
    _targetCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('إنشاء دائرة قراءة', style: context.ds(size: 18)),
            const SizedBox(height: 14),
            TextField(
              controller: _nameCtrl,
              maxLength: 40,
              decoration: InputDecoration(
                labelText: 'اسم الدائرة',
                hintText: 'مثال: قرّاء الفجر',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _seriesCtrl,
              decoration: InputDecoration(
                labelText: 'العمل الذي تدور حوله الدائرة',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descCtrl,
              maxLines: 2,
              maxLength: 200,
              decoration: InputDecoration(
                labelText: 'وصف قصير (اختياري)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _targetCtrl,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'هدف الفصول',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: _maxMembers,
                    decoration: InputDecoration(
                      labelText: 'أقصى الأعضاء',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(p.r(0.8))),
                    ),
                    items: const [5, 10, 20, 30, 50]
                        .map((n) => DropdownMenuItem<int>(value: n, child: Text('$n')))
                        .toList(),
                    onChanged: (v) => setState(() => _maxMembers = v ?? 20),
                  ),
                ),
              ],
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('دائرة عامة', style: context.ts(size: 14, w: FontWeight.w700)),
              subtitle: Text(
                _isPublic ? 'تظهر في الاكتشاف ويمكن لأي قارئ الانضمام.' : 'خاصة: الدخول بكود الدعوة فقط.',
                style: context.ts(size: 12, color: p.textDim),
              ),
              value: _isPublic,
              onChanged: (v) => setState(() => _isPublic = v),
            ),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _busy ? null : _submit,
                child: const Text('إنشاء الدائرة'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final target = int.tryParse(_targetCtrl.text.trim()) ?? 0;
    final error = validateCircle(
      name: _nameCtrl.text,
      maxMembers: _maxMembers,
      targetChapter: target,
      seriesChapters: 0,
    );
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
      return;
    }
    setState(() => _busy = true);
    final circle = await widget.store.create(
      name: _nameCtrl.text,
      seriesId: 's1',
      seriesTitle: _seriesCtrl.text.trim().isEmpty ? 'عمل' : _seriesCtrl.text.trim(),
      ownerId: widget.myId,
      ownerName: widget.myName,
      description: _descCtrl.text,
      maxMembers: _maxMembers,
      isPublic: _isPublic,
      targetChapter: target,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(circle == null ? 'تعذّر إنشاء الدائرة.' : 'أُنشئت الدائرة، كود الدعوة: ${circle.inviteCode}')),
    );
  }
}

/// شاشة تفاصيل الدائرة: نقاش + ترتيب الأعضاء + كود الدعوة + مغادرة.
class CircleDetailScreen extends StatefulWidget {
  const CircleDetailScreen({
    super.key,
    required this.store,
    required this.circleId,
    required this.myId,
    required this.myName,
    this.myBadge = SardBadge.none,
  });

  final ReadingCirclesStore store;
  final String circleId;
  final String myId;
  final String myName;
  final SardBadge myBadge;

  @override
  State<CircleDetailScreen> createState() => _CircleDetailScreenState();
}

class _CircleDetailScreenState extends State<CircleDetailScreen> {
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scroll = ScrollController();
  int _tab = 0;

  @override
  void dispose() {
    _msgCtrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: widget.store,
      builder: (context, _) {
        final circle = widget.store.byId(widget.circleId);
        if (circle == null) {
          return Scaffold(
            backgroundColor: p.bg,
            appBar: AppBar(title: const Text('الدائرة')),
            body: Center(
              child: Text('الدائرة غير موجودة (ربما حُذفت).', style: context.ts(size: 14, color: p.textDim)),
            ),
          );
        }
        final joined = circle.isMember(widget.myId);
        final messages = widget.store.messages(circle.id);
        final color = circleColor(circle.colorIndex);
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            title: Text(circle.name),
            actions: [
              IconButton(
                onPressed: () => _showInviteCard(context, circle),
                icon: const SIcon(SardIcons.share_rounded),
                tooltip: 'دعوة أصدقاء',
              ),
              if (joined)
                PopupMenuButton<String>(
                  icon: SIcon(SardIcons.tune_rounded, color: p.text),
                  onSelected: (v) async {
                    if (v == 'leave') {
                      final error = await widget.store.leave(circle.id, widget.myId);
                      if (context.mounted) {
                        if (error == null) {
                          Navigator.of(context).pop();
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('غادرت الدائرة.')),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
                        }
                      }
                    }
                  },
                  itemBuilder: (context) => const [
                    PopupMenuItem(value: 'leave', child: Text('مغادرة الدائرة')),
                  ],
                ),
            ],
          ),
          body: Column(
            children: [
              Container(
                margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(p.r(1)),
                  border: Border.all(color: p.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '«${circle.seriesTitle}»',
                            style: context.ds(size: 15.5),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (circle.daysLeft != null)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: tint(p.gold, 0.12),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              circle.daysLeft! >= 0 ? 'متبقٍ ${circle.daysLeft} يوم' : 'انتهت المهلة',
                              style: context.ts(size: 11.5, color: p.gold, w: FontWeight.w700),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    CircleProgressBar(progress: circle.averageProgress, target: circle.targetChapter, color: color),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        SIcon(SardIcons.person_rounded, size: 15, color: p.textDim),
                        const SizedBox(width: 4),
                        Text('${circle.memberCount}/${circle.maxMembers} عضو', style: context.ts(size: 12.5, color: p.textDim)),
                        const SizedBox(width: 12),
                        SIcon(SardIcons.calendar_today_rounded, size: 15, color: p.textDim),
                        const SizedBox(width: 4),
                        Text('أُنشئت ${socialTimeAgo(circle.createdAt)}', style: context.ts(size: 12.5, color: p.textDim)),
                      ],
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: _DetailTab(
                      label: 'النقاش (${messages.length})',
                      selected: _tab == 0,
                      onTap: () => setState(() => _tab = 0),
                    ),
                  ),
                  Expanded(
                    child: _DetailTab(
                      label: 'الترتيب (${circle.memberCount})',
                      selected: _tab == 1,
                      onTap: () => setState(() => _tab = 1),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Expanded(
                child: _tab == 0
                    ? CircleChatView(
                        messages: messages,
                        scroll: _scroll,
                        myId: widget.myId,
                        joined: joined,
                      )
                    : CircleLeaderboard(
                        circle: circle,
                        myId: widget.myId,
                        onPromote: (m) async {
                          final ok = await widget.store.promote(circle.id, widget.myId, m.userId);
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(ok ? 'أصبح ${m.name} مشرفاً.' : 'لا تملك الصلاحية.')),
                            );
                          }
                        },
                      ),
              ),
              if (joined)
                _CircleComposer(
                  ctrl: _msgCtrl,
                  onSend: () async {
                    final msg = await widget.store.postMessage(
                      circleId: circle.id,
                      authorId: widget.myId,
                      authorName: widget.myName,
                      text: _msgCtrl.text,
                      badge: widget.myBadge,
                    );
                    if (msg != null) {
                      _msgCtrl.clear();
                      _scrollToBottom();
                    }
                  },
                  onProgress: (chapter) async {
                    await widget.store.updateProgress(circle.id, widget.myId, chapter, userName: widget.myName);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('حدّثت تقدمك إلى الفصل $chapter.')),
                      );
                    }
                  },
                  myChapter: circle.member(widget.myId)?.currentChapter ?? 0,
                )
              else
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: circle.isFull
                          ? null
                          : () async {
                              final error = await widget.store.join(circle.id, widget.myId, widget.myName, badge: widget.myBadge);
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(error ?? 'انضممت إلى الدائرة، أهلاً بك!')),
                                );
                              }
                            },
                      icon: const SIcon(SardIcons.groups_rounded, size: 18),
                      label: Text(circle.isFull ? 'الدائرة ممتلئة' : 'انضم إلى الدائرة'),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  void _showInviteCard(BuildContext context, ReadingCircle circle) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => CircleInviteCard(circle: circle),
    );
  }
}

/// تبويب صغير داخل تفاصيل الدائرة.
class _DetailTab extends StatelessWidget {
  const _DetailTab({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: selected ? p.accent : p.border, width: selected ? 2.5 : 1)),
        ),
        child: Text(
          label,
          style: context.ts(size: 13.5, color: selected ? p.accent : p.textDim, w: FontWeight.w700),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

/// عرض نقاش الدائرة: رسائل نصية + رسائل نظام.
class CircleChatView extends StatelessWidget {
  const CircleChatView({super.key, required this.messages, required this.scroll, required this.myId, required this.joined});
  final List<CircleMessage> messages;
  final ScrollController scroll;
  final String myId;
  final bool joined;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (messages.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            joined ? 'النقاش فارغ بعد، ابدأ الحديث!' : 'انضم إلى الدائرة لقراءة النقاش والمشاركة فيه.',
            style: context.ts(size: 14, color: p.textDim),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    return ListView.builder(
      controller: scroll,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      itemCount: messages.length,
      itemBuilder: (context, i) {
        final m = messages[i];
        if (m.type != CircleMessageType.text) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: p.surfaceHi,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(m.text, style: context.ts(size: 11.5, color: p.textDim)),
              ),
            ),
          );
        }
        final mine = m.authorId == myId;
        return Align(
          alignment: mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
          child: Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * 0.78),
            margin: const EdgeInsets.symmetric(vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: mine ? tint(p.accent, 0.16) : p.surface,
              borderRadius: BorderRadius.circular(p.r(0.8)),
              border: Border.all(color: mine ? tint(p.accent, 0.3) : p.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (!mine)
                  Text(m.authorName, style: context.ts(size: 11.5, color: p.accent, w: FontWeight.w700)),
                Text(m.text, style: context.ts(size: 13.5, height: 1.45)),
                const SizedBox(height: 2),
                Text(
                  socialTimeAgo(m.createdAt),
                  style: context.ts(size: 10.5, color: p.textDim),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// ترتيب الأعضاء حسب التقدم مع شارات المراكز.
class CircleLeaderboard extends StatelessWidget {
  const CircleLeaderboard({super.key, required this.circle, required this.myId, required this.onPromote});
  final ReadingCircle circle;
  final String myId;
  final ValueChanged<CircleMember> onPromote;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final board = circle.leaderboard;
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      itemCount: board.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final m = board[i];
        final mine = m.userId == myId;
        final isOwner = circle.ownerId == m.userId;
        final medal = i == 0
            ? '🥇'
            : i == 1
                ? '🥈'
                : i == 2
                    ? '🥉'
                    : '${i + 1}';
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: mine ? tint(p.accent, 0.08) : p.surface,
            borderRadius: BorderRadius.circular(p.r(0.8)),
            border: Border.all(color: mine ? tint(p.accent, 0.3) : p.border),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 30,
                child: Text(medal, style: context.ds(size: i < 3 ? 18 : 14), textAlign: TextAlign.center),
              ),
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(circleColor(circle.colorIndex), 0.14),
                  shape: BoxShape.circle,
                ),
                child: Text(
                  m.name.isEmpty ? '؟' : m.name.characters.first,
                  style: context.ds(size: 15, color: circleColor(circle.colorIndex)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            m.name,
                            style: context.ts(size: 13.5, w: FontWeight.w700),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (m.role != CircleRole.member) ...[
                          const SizedBox(width: 4),
                          Text(
                            m.role.label,
                            style: context.ts(size: 11, color: p.gold, w: FontWeight.w700),
                          ),
                        ],
                        if (m.online) ...[
                          const SizedBox(width: 6),
                          Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFF2ECC71), shape: BoxShape.circle)),
                        ],
                      ],
                    ),
                    const SizedBox(height: 3),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: m.progressTo(circle.targetChapter),
                        minHeight: 5,
                        backgroundColor: p.surfaceHi,
                        valueColor: AlwaysStoppedAnimation<Color>(circleColor(circle.colorIndex)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('الفصل ${m.currentChapter}', style: context.ts(size: 12.5, w: FontWeight.w800)),
                  if (circle.hasGoal)
                    Text(
                      '${(m.progressTo(circle.targetChapter) * 100).round()}٪',
                      style: context.ts(size: 11, color: p.textDim),
                    ),
                ],
              ),
              if (isOwner && !mine && m.role == CircleRole.member)
                IconButton(
                  onPressed: () => onPromote(m),
                  icon: SIcon(SardIcons.shield_rounded, size: 18, color: p.gold),
                  tooltip: 'ترقية إلى مشرف',
                ),
            ],
          ),
        );
      },
    );
  }
}

/// بطاقة دعوة: كود الدائرة وشرح مشاركته.
class CircleInviteCard extends StatelessWidget {
  const CircleInviteCard({super.key, required this.circle});
  final ReadingCircle circle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('دعوة إلى «${circle.name}»', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'شارك هذا الكود مع أصدقائك لينضموا إلى الدائرة من زر «الانضمام بكود دعوة».',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: tint(circleColor(circle.colorIndex), 0.10),
                borderRadius: BorderRadius.circular(p.r(0.9)),
                border: Border.all(color: tint(circleColor(circle.colorIndex), 0.35), style: BorderStyle.solid),
              ),
              child: Text(
                circle.inviteCode,
                style: context.ds(size: 30, color: circleColor(circle.colorIndex)),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'العمل: «${circle.seriesTitle}» · الأعضاء ${circle.memberCount}/${circle.maxMembers}',
              style: context.ts(size: 12, color: p.textDim),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

/// صندوق كتابة رسالة في النقاش + تحديث التقدم.
class _CircleComposer extends StatelessWidget {
  const _CircleComposer({required this.ctrl, required this.onSend, required this.onProgress, required this.myChapter});
  final TextEditingController ctrl;
  final VoidCallback onSend;
  final ValueChanged<int> onProgress;
  final int myChapter;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: p.surface,
        border: Border(top: BorderSide(color: p.border)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                SIcon(SardIcons.menu_book_rounded, size: 16, color: p.textDim),
                const SizedBox(width: 6),
                Text('وصلت إلى الفصل $myChapter', style: context.ts(size: 12.5, color: p.textDim)),
                const Spacer(),
                TextButton(
                  onPressed: () => _showProgressPicker(context),
                  child: const Text('تحديث تقدمي'),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: ctrl,
                    maxLines: 3,
                    minLines: 1,
                    maxLength: 500,
                    decoration: InputDecoration(
                      hintText: 'اكتب رسالة للدائرة…',
                      counterText: '',
                      filled: true,
                      fillColor: p.bg,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(p.r(0.9)),
                        borderSide: BorderSide(color: p.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(p.r(0.9)),
                        borderSide: BorderSide(color: p.border),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: onSend,
                  style: FilledButton.styleFrom(
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(12),
                    minimumSize: const Size(48, 48),
                  ),
                  child: const SIcon(SardIcons.send_rounded, size: 20),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showProgressPicker(BuildContext context) {
    final ctrl = TextEditingController(text: '${myChapter + 1}');
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تحديث تقدمي في القراءة'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'رقم الفصل الذي وصلت إليه'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final v = int.tryParse(ctrl.text.trim()) ?? myChapter;
              Navigator.of(context).pop();
              if (v > myChapter) onProgress(v);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}
