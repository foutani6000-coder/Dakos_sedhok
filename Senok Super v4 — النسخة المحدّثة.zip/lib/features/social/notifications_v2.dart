import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'comments_v2.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// مركز الإشعارات v2 — أنواع متعددة، قراءة/غير مقروء، ترشيح، تجميع بالأيام،
/// إعدادات تفعيل لكل نوع، وحذف بالسحب. إشعارات محلية فقط في هذه النسخة
/// (لا إشعارات دفع خارجية): تُولَّد من أحداث التطبيق نفسه.
///
/// قواعد صريحة: الإشعار له نوع وأولوية، ويُحفظ محلياً بحد 200 إشعار.
/// ──────────────────────────────────────────────────────────────────────────

int _nSeq = 0;
String _nId() => 'n_${DateTime.now().microsecondsSinceEpoch}_${_nSeq++}';

/// نوع الإشعار.
enum NotificationKind {
  newChapter('فصل جديد', 'صدر فصل جديد في عمل تتابعه'),
  reply('رد على تعليقك', 'ردّ أحدهم على تعليقك'),
  like('إعجاب', 'أعجب أحدهم بتعليقك أو مراجعتك'),
  mention('إشارة', 'ذكرك أحدهم في تعليق'),
  circle('دائرة قراءة', 'نشاط في إحدى دوائرك'),
  achievement('إنجاز', 'فتحت إنجازاً جديداً'),
  system('النظام', 'رسائل النظام والتحديثات'),
  reminder('تذكير', 'تذكير بمواصلة القراءة'),
  friend('صديق', 'نشاط صديق أو طلب صداقة'),
  review('مراجعة', 'مراجعة جديدة عن عمل تتابعه');

  const NotificationKind(this.label, this.description);
  final String label;
  final String description;

  SIconData get icon {
    switch (this) {
      case NotificationKind.newChapter:
        return SardIcons.auto_stories_rounded;
      case NotificationKind.reply:
        return SardIcons.reply_rounded;
      case NotificationKind.like:
        return SardIcons.favorite_rounded;
      case NotificationKind.mention:
        return SardIcons.chat_bubble_rounded;
      case NotificationKind.circle:
        return SardIcons.groups_rounded;
      case NotificationKind.achievement:
        return SardIcons.star_rounded;
      case NotificationKind.system:
        return SardIcons.campaign_rounded;
      case NotificationKind.reminder:
        return SardIcons.watch_later_rounded;
      case NotificationKind.friend:
        return SardIcons.person_rounded;
      case NotificationKind.review:
        return SardIcons.edit_rounded;
    }
  }

  Color color(SardPalette p) {
    switch (this) {
      case NotificationKind.newChapter:
        return const Color(0xFF3B9EFF);
      case NotificationKind.reply:
        return const Color(0xFF7C4DFF);
      case NotificationKind.like:
        return const Color(0xFFE5484D);
      case NotificationKind.mention:
        return const Color(0xFF0F9D75);
      case NotificationKind.circle:
        return const Color(0xFFE0457B);
      case NotificationKind.achievement:
        return p.gold;
      case NotificationKind.system:
        return p.textDim;
      case NotificationKind.reminder:
        return const Color(0xFFE8A33D);
      case NotificationKind.friend:
        return const Color(0xFF22C7D6);
      case NotificationKind.review:
        return p.accent;
    }
  }
}

/// إشعار واحد.
class V2Notification {
  const V2Notification({
    required this.id,
    required this.kind,
    required this.title,
    required this.body,
    required this.createdAt,
    this.seriesId,
    this.seriesTitle,
    this.chapter,
    this.read = false,
    this.actionLabel,
    this.payload = '',
  });

  final String id;
  final NotificationKind kind;
  final String title;
  final String body;
  final DateTime createdAt;
  final String? seriesId;
  final String? seriesTitle;
  final int? chapter;
  final bool read;

  /// نص زر الإجراء (مثال: «اقرأ الآن») — null = بلا إجراء.
  final String? actionLabel;
  final String payload;

  /// الإشعار مهم (فصل جديد أو إنجاز أو رد) ويستحق شارة بارزة.
  bool get isImportant =>
      kind == NotificationKind.newChapter ||
      kind == NotificationKind.achievement ||
      kind == NotificationKind.reply;

  V2Notification copyWith({bool? read}) {
    return V2Notification(
      id: id,
      kind: kind,
      title: title,
      body: body,
      createdAt: createdAt,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      read: read ?? this.read,
      actionLabel: actionLabel,
      payload: payload,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'title': title,
        'body': body,
        'createdAt': createdAt.toIso8601String(),
        'seriesId': seriesId,
        'seriesTitle': seriesTitle,
        'chapter': chapter,
        'read': read,
        'actionLabel': actionLabel,
        'payload': payload,
      };

  factory V2Notification.fromJson(Map<String, dynamic> j) {
    final kind = NotificationKind.values.firstWhere(
      (e) => e.name == j['kind'],
      orElse: () => NotificationKind.system,
    );
    return V2Notification(
      id: '${j['id']}',
      kind: kind,
      title: '${j['title'] ?? ''}',
      body: '${j['body'] ?? ''}',
      createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
      seriesId: j['seriesId']?.toString(),
      seriesTitle: j['seriesTitle']?.toString(),
      chapter: (j['chapter'] as num?)?.toInt(),
      read: j['read'] == true,
      actionLabel: j['actionLabel']?.toString(),
      payload: '${j['payload'] ?? ''}',
    );
  }
}

/// إعدادات الإشعارات: تفعيل/تعطيل لكل نوع.
class NotificationSettings {
  const NotificationSettings({Map<NotificationKind, bool>? enabled})
      : enabled = enabled ?? const {};

  /// خريطة التفعيل (غياب النوع = مفعّل افتراضياً).
  final Map<NotificationKind, bool> enabled;

  bool isEnabled(NotificationKind kind) => enabled[kind] ?? true;

  NotificationSettings copyWith({NotificationKind? kind, bool? value}) {
    if (kind == null) return this;
    final next = Map<NotificationKind, bool>.from(enabled);
    next[kind] = value ?? true;
    return NotificationSettings(enabled: next);
  }

  Map<String, dynamic> toJson() => {
        for (final e in enabled.entries) e.key.name: e.value,
      };

  factory NotificationSettings.fromJson(Map<String, dynamic> j) {
    final map = <NotificationKind, bool>{};
    for (final k in NotificationKind.values) {
      if (j[k.name] is bool) map[k] = j[k.name] as bool;
    }
    return NotificationSettings(enabled: map);
  }
}

/// مخزن الإشعارات v2: حفظ محلي وبذرة تجريبية.
class NotificationsV2Store extends ChangeNotifier {
  NotificationsV2Store(this._p) {
    _restore();
  }

  static const String _key = 'social_notifications_v2';
  static const String _settingsKey = 'social_notifications_v2_settings';
  static const int kMaxNotifications = 200;

  final SharedPreferences _p;
  final List<V2Notification> _items = <V2Notification>[];
  NotificationSettings _settings = const NotificationSettings();

  static Future<NotificationsV2Store> load() async {
    final p = await SharedPreferences.getInstance();
    return NotificationsV2Store(p);
  }

  List<V2Notification> get all => List.unmodifiable(_items);

  NotificationSettings get settings => _settings;

  /// عدد غير المقروءة.
  int get unreadCount => _items.where((n) => !n.read).length;

  /// عدد غير المقروءة لنوع معيّن.
  int unreadFor(NotificationKind kind) => _items.where((n) => !n.read && n.kind == kind).length;

  void _restore() {
    try {
      final raw = _p.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final list = jsonDecode(raw) as List;
        _items
          ..clear()
          ..addAll(list.whereType<Map>().map((e) => V2Notification.fromJson(Map<String, dynamic>.from(e))));
      }
      final rawS = _p.getString(_settingsKey);
      if (rawS != null && rawS.isNotEmpty) {
        _settings = NotificationSettings.fromJson(Map<String, dynamic>.from(jsonDecode(rawS) as Map));
      }
    } catch (_) {
      _items.clear();
      _settings = const NotificationSettings();
    }
  }

  Future<void> _save() async {
    await _p.setString(_key, jsonEncode(_items.map((n) => n.toJson()).toList()));
    await _p.setString(_settingsKey, jsonEncode(_settings.toJson()));
  }

  /// بذرة تجريبية عربية عند أول فتح.
  Future<void> ensureDemo() async {
    if (_items.isNotEmpty) return;
    final now = DateTime.now();
    _items.addAll(<V2Notification>[
      V2Notification(
        id: 'n_demo_1',
        kind: NotificationKind.newChapter,
        title: 'فصل جديد: «سيف الفجر»',
        body: 'صدر الفصل 13 من «سيف الفجر» — تابع القراءة من حيث توقفت.',
        createdAt: now.subtract(const Duration(minutes: 8)),
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        chapter: 13,
        actionLabel: 'اقرأ الآن',
      ),
      V2Notification(
        id: 'n_demo_2',
        kind: NotificationKind.reply,
        title: 'سارة ردّت على تعليقك',
        body: '«أتفق معك تماماً، خصوصاً مشهد البوابة في الصفحة الأخيرة.»',
        createdAt: now.subtract(const Duration(minutes: 26)),
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        chapter: 12,
        actionLabel: 'عرض الرد',
      ),
      V2Notification(
        id: 'n_demo_3',
        kind: NotificationKind.achievement,
        title: 'فتحت إنجاز «قارئ ناشئ»!',
        body: 'قرأت 10 فصول — +25 نقطة إنجاز. واصل التقدم!',
        createdAt: now.subtract(const Duration(hours: 1)),
        actionLabel: 'عرض الإنجازات',
      ),
      V2Notification(
        id: 'n_demo_4',
        kind: NotificationKind.like,
        title: 'أعجب عمر بمراجعتك',
        body: 'أعجب عمر بمراجعتك عن «سيف الفجر».',
        createdAt: now.subtract(const Duration(hours: 2)),
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
      ),
      V2Notification(
        id: 'n_demo_5',
        kind: NotificationKind.circle,
        title: 'رسالة جديدة في «قرّاء الفجر»',
        body: 'سارة: الفصل 17 كان قوياً جداً! من توقّع أن يعود الحارس القديم؟',
        createdAt: now.subtract(const Duration(hours: 3)),
        seriesId: 's1',
        seriesTitle: 'سيف الفجر',
        actionLabel: 'فتح الدائرة',
      ),
      V2Notification(
        id: 'n_demo_6',
        kind: NotificationKind.reminder,
        title: 'حان وقت القراءة 📖',
        body: 'لم تقرأ اليوم بعد — فصل واحد يحافظ على سلسلتك.',
        createdAt: now.subtract(const Duration(hours: 5)),
      ),
      V2Notification(
        id: 'n_demo_7',
        kind: NotificationKind.newChapter,
        title: 'فصل جديد: «زهرة الربيع»',
        body: 'صدر الفصل 12 من «زهرة الربيع».',
        createdAt: now.subtract(const Duration(hours: 8)),
        seriesId: 's2',
        seriesTitle: 'زهرة الربيع',
        chapter: 12,
        actionLabel: 'اقرأ الآن',
        read: true,
      ),
      V2Notification(
        id: 'n_demo_8',
        kind: NotificationKind.friend,
        title: 'نورة بدأت قراءة «زهرة الربيع»',
        body: 'صديقتك نورة بدأت عملاً جديداً قد يعجبك.',
        createdAt: now.subtract(const Duration(days: 1)),
        seriesId: 's2',
        seriesTitle: 'زهرة الربيع',
        read: true,
      ),
      V2Notification(
        id: 'n_demo_9',
        kind: NotificationKind.system,
        title: 'مرحباً بك في Senok',
        body: 'أهلاً بك في النسخة الجديدة — جرّب دوائر القراءة والإنجازات من القائمة الجانبية.',
        createdAt: now.subtract(const Duration(days: 1, hours: 2)),
        read: true,
      ),
    ]);
    await _save();
    notifyListeners();
  }

  // ───────── استعلامات ─────────

  /// القائمة مرتبة من الأحدث، مع ترشيح اختياري.
  List<V2Notification> filtered({NotificationKind? kind, bool unreadOnly = false, String? query}) {
    var list = List<V2Notification>.from(_items);
    if (kind != null) list = list.where((n) => n.kind == kind).toList();
    if (unreadOnly) list = list.where((n) => !n.read).toList();
    if (query != null && query.trim().isNotEmpty) {
      final q = query.trim();
      list = list.where((n) => n.title.contains(q) || n.body.contains(q)).toList();
    }
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  /// تجميع حسب اليوم («اليوم»، «أمس»، أو التاريخ).
  Map<String, List<V2Notification>> groupedByDay({NotificationKind? kind, bool unreadOnly = false, DateTime? now}) {
    final n = now ?? DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final map = <String, List<V2Notification>>{};
    for (final item in filtered(kind: kind, unreadOnly: unreadOnly)) {
      final d = DateTime(item.createdAt.year, item.createdAt.month, item.createdAt.day);
      final diff = today.difference(d).inDays;
      final key = diff == 0
          ? 'اليوم'
          : diff == 1
              ? 'أمس'
              : '${item.createdAt.year}/${item.createdAt.month}/${item.createdAt.day}';
      (map[key] ??= <V2Notification>[]).add(item);
    }
    return map;
  }

  // ───────── عمليات ─────────

  /// إضافة إشعار (يُتجاهل إن كان نوعه معطّلاً في الإعدادات).
  Future<V2Notification?> add({
    required NotificationKind kind,
    required String title,
    required String body,
    String? seriesId,
    String? seriesTitle,
    int? chapter,
    String? actionLabel,
    String payload = '',
    DateTime? at,
  }) async {
    if (!_settings.isEnabled(kind)) return null;
    final now = at ?? DateTime.now();
    final n = V2Notification(
      id: _nId(),
      kind: kind,
      title: title,
      body: body,
      createdAt: now,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      actionLabel: actionLabel,
      payload: payload,
    );
    _items.insert(0, n);
    if (_items.length > kMaxNotifications) _items.removeRange(kMaxNotifications, _items.length);
    await _save();
    notifyListeners();
    return n;
  }

  /// تعليم إشعار كمقروء.
  Future<void> markRead(String id) async {
    final idx = _items.indexWhere((n) => n.id == id);
    if (idx < 0 || _items[idx].read) return;
    _items[idx] = _items[idx].copyWith(read: true);
    await _save();
    notifyListeners();
  }

  /// تعليم الكل كمقروء.
  Future<void> markAllRead() async {
    var changed = false;
    for (var i = 0; i < _items.length; i++) {
      if (!_items[i].read) {
        _items[i] = _items[i].copyWith(read: true);
        changed = true;
      }
    }
    if (changed) {
      await _save();
      notifyListeners();
    }
  }

  /// حذف إشعار واحد.
  Future<bool> delete(String id) async {
    final before = _items.length;
    _items.removeWhere((n) => n.id == id);
    if (_items.length == before) return false;
    await _save();
    notifyListeners();
    return true;
  }

  /// مسح كل المقروءة (إبقاء غير المقروءة).
  Future<void> clearRead() async {
    _items.removeWhere((n) => n.read);
    await _save();
    notifyListeners();
  }

  /// مسح الكل.
  Future<void> clearAll() async {
    _items.clear();
    await _save();
    notifyListeners();
  }

  /// تبديل تفعيل نوع إشعارات.
  Future<void> setKindEnabled(NotificationKind kind, bool value) async {
    _settings = _settings.copyWith(kind: kind, value: value);
    await _save();
    notifyListeners();
  }
}

/// ───────── الواجهات ─────────

/// شاشة مركز الإشعارات: تبويب الكل/غير المقروء + ترشيح بالنوع + بحث + سحب للحذف.
class NotificationsV2Screen extends StatefulWidget {
  const NotificationsV2Screen({super.key, required this.store});
  final NotificationsV2Store store;

  @override
  State<NotificationsV2Screen> createState() => _NotificationsV2ScreenState();
}

class _NotificationsV2ScreenState extends State<NotificationsV2Screen> {
  bool _unreadOnly = false;
  NotificationKind? _kind;
  String _query = '';
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('الإشعارات'),
        actions: [
          IconButton(
            onPressed: () => _showSettingsSheet(context),
            icon: const SIcon(SardIcons.settings_rounded),
            tooltip: 'إعدادات الإشعارات',
          ),
          PopupMenuButton<String>(
            icon: SIcon(SardIcons.tune_rounded, color: p.text),
            onSelected: (v) async {
              if (v == 'read_all') {
                await widget.store.markAllRead();
              } else if (v == 'clear_read') {
                await widget.store.clearRead();
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تم مسح الإشعارات المقروءة.')),
                  );
                }
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'read_all', child: Text('تعليم الكل كمقروء')),
              PopupMenuItem(value: 'clear_read', child: Text('مسح المقروءة')),
            ],
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          final groups = widget.store.groupedByDay(kind: _kind, unreadOnly: _unreadOnly);
          final total = widget.store.filtered(kind: _kind, unreadOnly: _unreadOnly, query: _query).length;
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: SegmentedButton<bool>(
                        segments: const [
                          ButtonSegment<bool>(value: false, label: Text('الكل')),
                          ButtonSegment<bool>(value: true, label: Text('غير المقروء')),
                        ],
                        selected: {_unreadOnly},
                        onSelectionChanged: (s) => setState(() => _unreadOnly = s.first),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: widget.store.unreadCount > 0 ? tint(p.accent, 0.12) : p.surface,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: p.border),
                      ),
                      child: Text(
                        '${widget.store.unreadCount} غير مقروء',
                        style: context.ts(size: 12.5, color: p.accent, w: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _query = v),
                  decoration: InputDecoration(
                    hintText: 'ابحث في الإشعارات…',
                    prefixIcon: const SIcon(SardIcons.search_rounded, size: 20),
                    filled: true,
                    fillColor: p.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(p.r(0.8)),
                      borderSide: BorderSide(color: p.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(p.r(0.8)),
                      borderSide: BorderSide(color: p.border),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                ),
              ),
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _kindChip(context, null, 'كل الأنواع'),
                    for (final k in NotificationKind.values)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(start: 6),
                        child: _kindChip(context, k, k.label, count: widget.store.unreadFor(k)),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: total == 0
                    ? _EmptyNotifications(unreadOnly: _unreadOnly)
                    : _GroupedNotifications(groups: groups, store: widget.store, query: _query),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _kindChip(BuildContext context, NotificationKind? kind, String label, {int count = 0}) {
    final p = context.pal;
    final selected = _kind == kind;
    return ActionChip(
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label),
          if (count > 0) ...[
            const SizedBox(width: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
              decoration: BoxDecoration(
                color: selected ? p.onAccent : tint(p.accent, 0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '$count',
                style: context.ts(size: 10.5, color: selected ? p.accent : p.accent, w: FontWeight.w800),
              ),
            ),
          ],
        ],
      ),
      labelStyle: context.ts(size: 12, color: selected ? p.onAccent : p.text, w: FontWeight.w700),
      backgroundColor: selected ? p.accent : p.surface,
      side: BorderSide(color: selected ? p.accent : p.border),
      onPressed: () => setState(() => _kind = kind),
    );
  }

  void _showSettingsSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(context.pal.r(1.2))),
      ),
      builder: (context) => NotificationSettingsSheet(store: widget.store),
    );
  }
}

/// قائمة الإشعارات مجمّعة بالأيام مع الحذف بالسحب.
class _GroupedNotifications extends StatelessWidget {
  const _GroupedNotifications({required this.groups, required this.store, required this.query});
  final Map<String, List<V2Notification>> groups;
  final NotificationsV2Store store;
  final String query;

  @override
  Widget build(BuildContext context) {
    final keys = groups.keys.toList();
    final list = query.trim().isEmpty
        ? null
        : store.filtered(query: query);
    if (list != null) {
      return ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
        itemCount: list.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) => _DismissableTile(notification: list[i], store: store),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      itemCount: keys.length,
      itemBuilder: (context, i) {
        final key = keys[i];
        final items = groups[key]!;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(key, style: context.ds(size: 15)),
            ),
            for (final n in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: _DismissableTile(notification: n, store: store),
              ),
          ],
        );
      },
    );
  }
}

/// بطاقة إشعار قابلة للحذف بالسحب، والنقر يعلّمها كمقروءة.
class _DismissableTile extends StatelessWidget {
  const _DismissableTile({required this.notification, required this.store});
  final V2Notification notification;
  final NotificationsV2Store store;

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: ValueKey(notification.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: AlignmentDirectional.centerEnd,
        padding: const EdgeInsetsDirectional.only(end: 16),
        decoration: BoxDecoration(
          color: const Color(0xFFE5484D),
          borderRadius: BorderRadius.circular(12),
        ),
        child: const SIcon(SardIcons.delete_outline_rounded, color: Colors.white),
      ),
      onDismissed: (_) => store.delete(notification.id),
      child: V2NotificationTile(
        notification: notification,
        onTap: () => store.markRead(notification.id),
      ),
    );
  }
}

/// بطاقة إشعار واحدة: أيقونة النوع + العنوان + النص + زر الإجراء.
class V2NotificationTile extends StatelessWidget {
  const V2NotificationTile({super.key, required this.notification, this.onTap});
  final V2Notification notification;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final n = notification;
    final color = n.kind.color(p);
    return InkWell(
      borderRadius: BorderRadius.circular(p.r(0.9)),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: n.read ? p.surface : tint(p.accent, 0.05),
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: n.read ? p.border : tint(p.accent, 0.3)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: tint(color, 0.14),
                borderRadius: BorderRadius.circular(12),
              ),
              child: SIcon(n.kind.icon, size: 20, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          n.title,
                          style: context.ts(size: 13.5, w: FontWeight.w800),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (!n.read)
                        Container(
                          width: 8,
                          height: 8,
                          margin: const EdgeInsetsDirectional.only(start: 6),
                          decoration: BoxDecoration(color: p.accent, shape: BoxShape.circle),
                        ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    n.body,
                    style: context.ts(size: 12.5, color: p.textDim, height: 1.45),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text(socialTimeAgo(n.createdAt), style: context.ts(size: 11, color: p.textDim)),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: tint(color, 0.12),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(n.kind.label, style: context.ts(size: 10.5, color: color, w: FontWeight.w700)),
                      ),
                      const Spacer(),
                      if (n.actionLabel != null)
                        Text(
                          n.actionLabel!,
                          style: context.ts(size: 12, color: p.accent, w: FontWeight.w700),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// حالة فارغة لمركز الإشعارات.
class _EmptyNotifications extends StatelessWidget {
  const _EmptyNotifications({required this.unreadOnly});
  final bool unreadOnly;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: tint(p.accent, 0.12), shape: BoxShape.circle),
              child: SIcon(
                unreadOnly ? SardIcons.notifications_none_rounded : SardIcons.notifications_active_rounded,
                size: 34,
                color: p.accent,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              unreadOnly ? 'لا إشعارات غير مقروءة' : 'لا إشعارات بعد',
              style: context.ds(size: 18),
            ),
            const SizedBox(height: 6),
            Text(
              unreadOnly
                  ? 'أنت مطّلع على كل جديد، أحسنت!'
                  : 'عند صدور فصل جديد أو رد على تعليقك ستظهر الإشعارات هنا.',
              style: context.ts(size: 13.5, color: p.textDim),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

/// ورقة إعدادات الإشعارات: تفعيل/تعطيل لكل نوع.
class NotificationSettingsSheet extends StatelessWidget {
  const NotificationSettingsSheet({super.key, required this.store});
  final NotificationsV2Store store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('إعدادات الإشعارات', style: context.ds(size: 18)),
                const SizedBox(height: 4),
                Text(
                  'اختر أنواع الإشعارات التي تريد استلامها. الإشعارات محلية فقط في هذه النسخة.',
                  style: context.ts(size: 12.5, color: p.textDim),
                ),
                const SizedBox(height: 12),
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      for (final kind in NotificationKind.values)
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Row(
                            children: [
                              SIcon(kind.icon, size: 18, color: kind.color(p)),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(kind.label, style: context.ts(size: 14, w: FontWeight.w700)),
                              ),
                            ],
                          ),
                          subtitle: Text(kind.description, style: context.ts(size: 12, color: p.textDim)),
                          value: store.settings.isEnabled(kind),
                          onChanged: (v) => store.setKindEnabled(kind, v),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// شارة عدد غير المقروءة (لشريط التنقل أو الأيقونة).
class UnreadBadge extends StatelessWidget {
  const UnreadBadge({super.key, required this.count, this.child});
  final int count;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    final badge = count <= 0
        ? const SizedBox.shrink()
        : Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: const Color(0xFFE5484D),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              count > 99 ? '99+' : '$count',
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white),
            ),
          );
    if (child == null) return badge;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        child!,
        if (count > 0)
          PositionedDirectional(top: -6, end: -6, child: badge),
      ],
    );
  }
}
