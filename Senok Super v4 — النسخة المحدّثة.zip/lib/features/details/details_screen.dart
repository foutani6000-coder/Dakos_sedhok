import 'dart:math' as math;
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/guide/guide_controller.dart';
import '../../core/data/download_manager.dart';
import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/fx.dart';
import '../../widgets/pills.dart';
import '../../widgets/routes.dart';
import '../../widgets/sard_feedback.dart';
import '../home/catalog_screen.dart';
import '../reader/reader_screen.dart';
import 'comments_panel.dart';
import '../../widgets/sard_icons.dart';

// ───────── ألوان وظيفية ثابتة للأزرار ─────────
const Color _kBlue = Color(0xFF3B9EFF);
const Color _kGreen = Color(0xFF2FCB7A);
const Color _kAmber = Color(0xFFF5A524);
const Color _kPink = Color(0xFFE0457B);

enum _ChFilter { all, unread, downloaded }

// ───────── مساعدات الشكل (تتبع الثيم) ─────────

/// نصف قطر مقيَّد حتى لا تتشوه العناصر الصغيرة في الثيمات المستديرة
double _rad(SardPalette p, double f, [double max = 34]) => math.min(p.r(f), max);

/// سطح البطاقة: زجاجي شفاف في الثيمات الزجاجية
Color _surf(SardPalette p, [double a = 0.72]) => p.glass ? tint(p.surface, a) : p.surface;

/// توهّج حول العنصر المميّز (يظهر فقط في الثيمات ذات glow)
List<BoxShadow> _glow(SardPalette p, Color c, {double extra = 0}) {
  final g = p.glow + extra;
  if (g <= 0) return const <BoxShadow>[];
  return <BoxShadow>[
    BoxShadow(
      color: tint(c, 0.45 * g),
      blurRadius: 10 + 18 * g,
      spreadRadius: -2,
    ),
  ];
}

BoxDecoration _cardDeco(SardPalette p, {double r = 1.0, Color? tone, bool active = false, Color? fill}) {
  final t = tone ?? p.accent;
  return BoxDecoration(
    color: fill ?? _surf(p),
    borderRadius: BorderRadius.circular(_rad(p, r)),
    border: Border.all(color: active ? tint(t, 0.75) : p.border, width: p.borderW),
    boxShadow: active ? _glow(p, t) : const <BoxShadow>[],
  );
}

class DetailsScreen extends StatefulWidget {
  const DetailsScreen({super.key, required this.series, this.heroTag});
  final Series series;
  final String? heroTag;

  @override
  State<DetailsScreen> createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  static const List<String> _tabLabels = ['التفاصيل', 'الفصول', 'التعليقات'];
  static const List<SIconData> _tabIcons = [
    SardIcons.info_outline_rounded,
    SardIcons.menu_book_rounded,
    SardIcons.forum_rounded,
  ];

  final ScrollController _outer = ScrollController();
  final PageController _pager = PageController();
  final ValueNotifier<double> _pos = ValueNotifier<double>(0);

  bool _fav = false;
  bool _follow = false;
  bool _listed = false;
  bool _rated = false;
  bool _recommended = false;
  int _myRating = 0;
  bool _ratingBusy = false;
  bool _newestFirst = true;
  _ChFilter _filter = _ChFilter.all;
  final Set<int> _downloadedNums = <int>{};

  late Future<List<Chapter>> _chapters;
  late Future<List<Series>> _related;
  List<Chapter>? _loaded;
  Object? _chError;

  @override
  void initState() {
    super.initState();
    final st = context.read<SettingsController>();
    _follow = st.isFollowing(widget.series.id);
    _fav = st.isFavorite(widget.series.id);
    _listed = st.isReadLater(widget.series.id);
    _recommended = st.isRecommended(widget.series.id);
    st.cacheSeries(widget.series); // لعرضه في رفوف القائمة الجانبية
    _startChapters();
    _related = context.read<SardRepository>().related(widget.series);
    _pager.addListener(_onPage);
  }

  @override
  void dispose() {
    _pager.removeListener(_onPage);
    _pager.dispose();
    _outer.dispose();
    _pos.dispose();
    super.dispose();
  }

  void _onPage() {
    if (!_pager.hasClients) return;
    if (!_pager.position.haveDimensions) return;
    _pos.value = _pager.page ?? 0;
  }

  void _goTo(int i) {
    if (!_pager.hasClients) return;
    _pager.animateToPage(
      i,
      duration: const Duration(milliseconds: 360),
      curve: Curves.easeOutCubic,
    );
  }

  void _startChapters() {
    _chError = null;
    _loaded = null;
    final f = context.read<SardRepository>().chapters(widget.series);
    _chapters = f;
    f.then((l) {
      if (mounted && identical(_chapters, f)) setState(() => _loaded = l);
    }).catchError((Object e) {
      if (mounted && identical(_chapters, f)) setState(() => _chError = e);
    });
  }

  // ───────── التنزيل ─────────

  Future<void> _downloadChapter(Chapter c) async {
    try {
      final pages = await context.read<SardRepository>().pages(widget.series.id, c.number);
      await DownloadManager.instance.enqueue(
        seriesId: widget.series.id,
        title: widget.series.title,
        cover: widget.series.cover,
        chapter: c.number,
        pages: pages,
      );
      if (!mounted) return;
      setState(() => _downloadedNums.add(c.number));
      _toast('بدأ تنزيل الفصل ${c.number}. يمكنك متابعة التقدم من صفحة التحميلات.');
    } catch (e) {
      if (mounted) _toast('تعذّر بدء التنزيل: $e');
    }
  }

  Future<void> _chooseDownload() async {
    List<Chapter> list;
    try {
      list = await _chapters;
    } catch (_) {
      if (mounted) _toast('تعذّر تحميل قائمة الفصول');
      return;
    }
    if (!mounted || list.isEmpty) {
      if (mounted) _toast('لا توجد فصول متاحة للتنزيل');
      return;
    }
    final sorted = [...list]..sort((a, b) => b.number.compareTo(a.number));
    final selected = await showModalBottomSheet<Chapter>(
      context: context,
      backgroundColor: context.pal.surface,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(_rad(context.pal, 1.3, 32))),
      ),
      builder: (ctx) {
        final p = ctx.pal;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                      color: p.border,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                _SectionTitle(label: 'اختر الفصل للتنزيل', tone: _kGreen),
                const SizedBox(height: 12),
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: sorted.length,
                    itemBuilder: (c, i) {
                      final ch = sorted[i];
                      final done = _downloadedNums.contains(ch.number);
                      return Pressable(
                        onTap: () => Navigator.pop(ctx, ch),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          decoration: _cardDeco(p, r: 0.7, tone: _kGreen, active: done),
                          child: Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: tint(_kGreen, 0.16),
                                  borderRadius: BorderRadius.circular(_rad(p, 0.5, 14)),
                                ),
                                child: Text('${ch.number}', style: c.ds(size: 17, color: _kGreen)),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      ch.title,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: c.ts(size: 14, w: FontWeight.w600),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'الفصل ${ch.number} · ${ch.pages} صفحة',
                                      style: c.ts(size: 11, color: p.textDim),
                                    ),
                                  ],
                                ),
                              ),
                              SIcon(
                                done ? SardIcons.download_done_rounded : SardIcons.download_rounded,
                                color: _kGreen,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
    if (selected == null || !mounted) return;
    await _downloadChapter(selected);
  }

  void _toast(String m) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  // ───────── القراءة ─────────

  /// أول فصل متاح (غالباً 1)
  int get _firstNumber {
    final l = _loaded;
    if (l == null || l.isEmpty) return 1;
    return l.map((c) => c.number).reduce(math.min);
  }

  ReadProgress? get _progress => context.read<SettingsController>().progressOf(widget.series.id);

  /// أين يكمل القارئ: نفس الصفحة، أو أول الفصل التالي إن أنهى الفصل
  ({int chapter, int page})? _resumePoint() {
    final prog = _progress;
    if (prog == null) return null;
    final l = _loaded;
    if (prog.page >= prog.total && l != null) {
      final later = l.map((c) => c.number).where((n) => n > prog.chapter).toList()..sort();
      if (later.isNotEmpty) return (chapter: later.first, page: 1);
    }
    return (chapter: prog.chapter, page: prog.page);
  }

  Future<void> _open(int number, {int page = 1}) async {
    final List<Chapter> list;
    try {
      list = await _chapters;
    } catch (_) {
      if (mounted) _toast('تعذّر تحميل الفصول');
      return;
    }
    if (!mounted) return;
    if (list.isEmpty) {
      _toast('لا توجد فصول بعد');
      return;
    }
    await Navigator.of(context).push(
      sardRoute(
        ReaderScreen(
          series: widget.series,
          chapters: list,
          initialChapter: number,
          initialPage: page,
        ),
      ),
    );
    // عند العودة: حدّث بطاقة «تابع القراءة» وعلامات المقروء
    if (mounted) setState(() {});
  }

  void _startReading() {
    final rp = _resumePoint();
    if (rp == null) {
      _open(_firstNumber);
    } else {
      _open(rp.chapter, page: rp.page);
    }
  }

  // ───────── التقييم (نافذة التقييم والإرسال) ─────────

  Future<void> _showRating() async {
    int value = _myRating == 0 ? 8 : _myRating;
    final chosen = await showDialog<int>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, update) {
          final p = d.pal;
          return AlertDialog(
            backgroundColor: p.surface,
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(_rad(p, 1.2, 32)),
              side: BorderSide(color: p.border, width: p.borderW),
            ),
            title: Text('قيّم هذا العمل', style: d.ts(size: 18, w: FontWeight.w800)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SIcon(SardIcons.star_rounded, color: _kPink, size: 30),
                    const SizedBox(width: 8),
                    Text('$value / 10', style: d.ds(size: 30, color: _kPink)),
                  ],
                ),
                SliderTheme(
                  data: SliderTheme.of(d).copyWith(
                    activeTrackColor: _kPink,
                    thumbColor: _kPink,
                    overlayColor: tint(_kPink, 0.14),
                  ),
                  child: Slider(
                    value: value.toDouble(),
                    min: 1,
                    max: 10,
                    divisions: 9,
                    label: '$value',
                    onChanged: (v) => update(() => value = v.round()),
                  ),
                ),
                Text('تقييمك يساعد القراء الآخرين', style: d.ts(size: 12, color: p.textDim)),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(d),
                child: Text('إلغاء', style: d.ts(size: 14, w: FontWeight.w600, color: p.textDim)),
              ),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: _kPink, foregroundColor: Colors.white),
                onPressed: () => Navigator.pop(d, value),
                child: const Text('إرسال التقييم'),
              ),
            ],
          );
        },
      ),
    );
    if (chosen == null || !mounted) return;
    final repo = context.read<SardRepository>();
    setState(() => _ratingBusy = true);
    try {
      await repo.rateSeries(widget.series.id, chosen);
      if (mounted) {
        setState(() {
          _myRating = chosen;
          _rated = true;
        });
        _toast('تم إرسال تقييمك: $chosen/10');
      }
    } catch (e) {
      if (mounted) _toast('تعذّر إرسال التقييم: $e');
    } finally {
      if (mounted) setState(() => _ratingBusy = false);
    }
  }

  // ───────── البناء الرئيسي ─────────

  @override
  Widget build(BuildContext context) {
    final s = widget.series;
    final top = MediaQuery.paddingOf(context).top;
    final bottom = MediaQuery.paddingOf(context).bottom;
    final heroH = 396.0 + top;
    return Scaffold(
      body: NestedScrollView(
        controller: _outer,
        headerSliverBuilder: (ctx, innerScrolled) => <Widget>[
          SliverToBoxAdapter(child: _hero(ctx, s, heroH, top)),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: FadeSlide(child: _continueCard(ctx, s)),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 20, 8, 0),
              child: FadeSlide(index: 1, child: _actions(ctx)),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 14),
              child: FadeSlide(index: 2, child: _stats(ctx, s)),
            ),
          ),
          SliverOverlapAbsorber(
            handle: NestedScrollView.sliverOverlapAbsorberHandleFor(ctx),
            sliver: SliverPersistentHeader(
              pinned: true,
              delegate: _TabsDelegate(
                extent: top + 58,
                child: _TabsBar(
                  pos: _pos,
                  outer: _outer,
                  threshold: heroH,
                  top: top,
                  labels: _tabLabels,
                  icons: _tabIcons,
                  onTap: _goTo,
                  onBack: () => Navigator.of(context).pop(),
                ),
              ),
            ),
          ),
        ],
        body: PageView(
          controller: _pager,
          children: [
            _scrollPage('details', _detailsSlivers(context, s), bottom),
            _scrollPage('chapters', _chaptersSlivers(context), bottom),
            _scrollPage('comments', _commentsSlivers(context, s), bottom),
          ],
        ),
      ),
    );
  }

  /// صفحة تبويب بتمريرها العمودي الخاص (منسّق مع تمرير الصفحة)
  Widget _scrollPage(String key, List<Widget> slivers, double bottomInset) {
    return Builder(
      builder: (ctx) => CustomScrollView(
        key: PageStorageKey<String>(key),
        slivers: <Widget>[
          SliverOverlapInjector(handle: NestedScrollView.sliverOverlapAbsorberHandleFor(ctx)),
          ...slivers,
          SliverToBoxAdapter(child: SizedBox(height: 36 + bottomInset)),
        ],
      ),
    );
  }

  // ───────── القسم العلوي (Hero) ─────────

  Widget _hero(BuildContext context, Series s, double heroH, double top) {
    final p = context.pal;
    final coverR = _rad(p, 0.9, 28);
    final cover = widget.heroTag == null
        ? CoverArt(series: s, radius: coverR)
        : Hero(tag: widget.heroTag!, child: CoverArt(series: s, radius: coverR));
    return SizedBox(
      height: heroH,
      child: Stack(
        children: [
          Positioned.fill(
            child: RepaintBoundary(
              child: ClipRect(
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                  child: Transform.scale(
                    scale: 1.35,
                    child: CoverArt(series: s, radius: 0, showTitle: false),
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    tint(p.accent, 0.46),
                    tint(p.bg, 0.5),
                    tint(p.bg, 0.9),
                    p.bg,
                  ],
                  stops: const [0, 0.45, 0.82, 1],
                ),
              ),
            ),
          ),
          PositionedDirectional(
            top: top + 10,
            start: 16,
            end: 16,
            child: Row(
              children: [
                _GlassBtn(
                  icon: SardIcons.arrow_back_rounded,
                  onTap: () => Navigator.of(context).pop(),
                ),
                const Spacer(),
                _GlassBtn(
                  icon: SardIcons.share_rounded,
                  onTap: () => _toast('المشاركة قريباً'),
                ),
                const SizedBox(width: 10),
                _GlassBtn(
                  icon: _fav ? SardIcons.favorite_rounded : SardIcons.favorite_border_rounded,
                  active: _fav,
                  activeColor: _kPink,
                  onTap: () {
                    setState(() => _fav = !_fav);
                    context.read<SettingsController>().setFavorite(widget.series, _fav);
                    SardFeedback.celebrate(
                      context,
                      icon: _fav ? SardIcons.favorite_rounded : SardIcons.favorite_border_rounded,
                      color: _kPink,
                      title: _fav ? 'أُضيف إلى المفضلة' : 'أُزيل من المفضلة',
                      subtitle: widget.series.title,
                      burst: _fav,
                    );
                  },
                ),
              ],
            ),
          ),
          PositionedDirectional(
            start: 16,
            end: 16,
            bottom: 14,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  width: 136,
                  height: 196,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(coverR),
                    border: Border.all(color: tint(p.accent, 0.7), width: p.borderW + 0.4),
                    boxShadow: [
                      BoxShadow(
                        color: tint(p.accent, 0.28 + 0.3 * p.glow),
                        blurRadius: 28 + 16 * p.glow,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: cover,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          StatusTag(status: s.status),
                          _GlassPill(icon: SardIcons.auto_stories_rounded, label: s.type),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        s.title,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: context.ds(size: 24, height: 1.3),
                      ),
                      if (s.genres.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          s.genres.take(3).join(' · '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: context.ts(size: 12.5, color: p.textDim),
                        ),
                      ],
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          StatPill(
                            icon: SardIcons.visibility_rounded,
                            label: formatCount(s.views),
                            onDark: true,
                          ),
                          StatPill(
                            icon: SardIcons.menu_book_rounded,
                            label: '${s.chapters} فصل',
                            onDark: true,
                          ),
                          if (s.rating > 0)
                            StatPill(
                              icon: SardIcons.star_rounded,
                              label: s.rating.toStringAsFixed(1),
                              filled: true,
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ───────── بطاقة «تابع القراءة» ─────────

  Widget _continueCard(BuildContext context, Series s) {
    final p = context.pal;
    final rp = _resumePoint();
    final prog = _progress;
    var fraction = 0.0;
    if (prog != null && s.chapters > 0) {
      fraction = ((prog.chapter - 1 + prog.fraction) / s.chapters).clamp(0.0, 1.0).toDouble();
    }
    final String title;
    final String sub;
    if (rp == null) {
      title = 'ابدأ القراءة';
      sub = 'ابتدئ من الفصل $_firstNumber';
    } else {
      title = 'تابع القراءة · فصل ${rp.chapter}';
      sub = rp.page > 1 ? 'أكمل من الصفحة ${rp.page}' : 'من بداية الفصل';
    }
    final r = _rad(p, 1.2, 34);
    return Pressable(
      onTap: () => GuideController.instance.run('btn.start_reading', _startReading),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _surf(p),
          borderRadius: BorderRadius.circular(r),
          border: Border.all(color: tint(p.accent, 0.6), width: p.borderW),
          gradient: LinearGradient(
            begin: AlignmentDirectional.centerStart,
            end: AlignmentDirectional.centerEnd,
            colors: [tint(p.accent, 0.26), tint(p.accent, 0.05)],
          ),
          boxShadow: [
            BoxShadow(
              color: tint(p.accent, 0.18 + 0.3 * p.glow),
              blurRadius: 22 + 12 * p.glow,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            SizedBox(
              width: 66,
              height: 66,
              child: TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: fraction),
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeOutCubic,
                builder: (ctx, v, _) => CustomPaint(
                  painter: _RingPainter(
                    value: v,
                    color: p.accent,
                    track: tint(p.accent, 0.2),
                    stroke: 6,
                  ),
                  child: Center(
                    child: rp == null
                        ? SIcon(SardIcons.auto_stories_rounded, color: p.accent, size: 26)
                        : Text('${(v * 100).round()}%', style: ctx.ds(size: 15, color: p.accent)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.ts(size: 16, w: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(sub, style: context.ts(size: 12.5, color: p.textDim)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: p.accent,
                shape: BoxShape.circle,
                boxShadow: _glow(p, p.accent, extra: 0.2),
              ),
              child: SIcon(SardIcons.play_arrow_rounded, color: p.onAccent, size: 28),
            ),
          ],
        ),
      ),
    );
  }

  // ───────── شريط الإجراءات ─────────

  Widget _actions(BuildContext context) {
    final p = context.pal;
    return Row(
      children: [
        Expanded(
          child: _ActionCircle(
            icon: SardIcons.bookmark_border_rounded,
            activeIcon: SardIcons.bookmark_rounded,
            label: 'متابعة',
            color: _kBlue,
            active: _follow,
            onTap: () => GuideController.instance.run('btn.follow', () {
              setState(() => _follow = !_follow);
              context.read<SettingsController>().setFollowing(widget.series.id, _follow);
              SardFeedback.celebrate(
                context,
                icon: _follow ? SardIcons.bookmark_rounded : SardIcons.bookmark_border_rounded,
                color: _kBlue,
                title: _follow ? 'تمت المتابعة بنجاح' : 'تم إلغاء المتابعة',
                subtitle: _follow ? 'ستصلك إشعارات الفصول الجديدة من ${widget.series.title}' : widget.series.title,
                burst: _follow,
              );
            }),
          ),
        ),
        Expanded(
          child: _ActionCircle(
            icon: SardIcons.playlist_add_rounded,
            activeIcon: SardIcons.playlist_add_check_rounded,
            label: 'لاحقاً',
            color: _kAmber,
            active: _listed,
            onTap: () => GuideController.instance.run('btn.later', () {
              setState(() => _listed = !_listed);
              context.read<SettingsController>().setReadLater(widget.series, _listed);
              _toast(_listed ? 'أُضيف إلى القراءة لاحقاً' : 'أُزيل من القراءة لاحقاً');
            }),
          ),
        ),
        Expanded(
          child: _ActionCircle(
            icon: SardIcons.star_border_rounded,
            activeIcon: SardIcons.star_rounded,
            label: _myRating > 0 ? '$_myRating/10' : 'تقييم',
            color: _kPink,
            active: _rated,
            busy: _ratingBusy,
            onTap: () => GuideController.instance.run('btn.rate', _showRating),
          ),
        ),
        Expanded(
          child: _ActionCircle(
            icon: SardIcons.campaign_outlined,
            activeIcon: SardIcons.campaign_rounded,
            label: 'أوصي',
            color: p.accent,
            active: _recommended,
            onTap: () => GuideController.instance.run('btn.recommend', () {
              setState(() => _recommended = !_recommended);
              context.read<SettingsController>().setRecommended(widget.series, _recommended);
              _toast(_recommended ? 'أُضيف إلى توصياتك في ملفك الشخصي' : 'أُلغيت التوصية');
            }),
          ),
        ),
        Expanded(
          child: _ActionCircle(
            icon: SardIcons.download_rounded,
            activeIcon: SardIcons.download_done_rounded,
            label: 'تنزيل',
            color: _kGreen,
            active: _downloadedNums.isNotEmpty,
            onTap: () => GuideController.instance.run('btn.download', _chooseDownload),
          ),
        ),
      ],
    );
  }

  // ───────── بلاطات الإحصاء ─────────

  Widget _stats(BuildContext context, Series s) {
    final big = context.ds(size: 22);
    return Row(
      children: [
        Expanded(
          child: _StatTile(
            icon: SardIcons.visibility_rounded,
            tone: _kBlue,
            label: 'المشاهدات',
            value: CountUp(value: s.views, style: big),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _StatTile(
            icon: SardIcons.menu_book_rounded,
            tone: _kGreen,
            label: 'الفصول',
            value: Text('${s.chapters}', style: big),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _StatTile(
            icon: SardIcons.star_rounded,
            tone: _kAmber,
            label: 'التقييم',
            value: Text(s.rating > 0 ? s.rating.toStringAsFixed(1) : '—', style: big),
          ),
        ),
      ],
    );
  }

  // ───────── تبويب التفاصيل ─────────

  List<Widget> _detailsSlivers(BuildContext context, Series s) {
    final p = context.pal;
    final tones = <Color>[p.accent, _kBlue, _kGreen, _kAmber, _kPink];
    return <Widget>[
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _SectionTitle(label: 'الملخص', tone: p.accent),
              const SizedBox(height: 12),
              _Synopsis(text: s.synopsis, tone: p.accent),
              const SizedBox(height: 26),
              _SectionTitle(label: 'معلومات العمل', tone: _kBlue),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _InfoTile(
                      icon: SardIcons.calendar_today_rounded,
                      tone: _kAmber,
                      label: 'السنة',
                      value: '${s.year}',
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _InfoTile(
                      icon: SardIcons.category_rounded,
                      tone: _kBlue,
                      label: 'النوع',
                      value: s.type,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _InfoTile(
                      icon: s.ongoing ? SardIcons.bolt_rounded : SardIcons.check_circle_rounded,
                      tone: s.ongoing ? _kGreen : p.gold,
                      label: 'الحالة',
                      value: s.status,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 26),
              _SectionTitle(label: 'الأنواع', tone: _kAmber),
              const SizedBox(height: 12),
              if (s.genres.isEmpty)
                Text('لا توجد أنواع محددة بعد.', style: context.ts(size: 13, color: p.textDim))
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (var i = 0; i < s.genres.length; i++)
                      _GenreChip(
                        label: s.genres[i],
                        tone: tones[i % tones.length],
                        onTap: () {
                          final g = s.genres[i];
                          Navigator.push(context, sardRoute(CatalogScreen(title: g, genre: g)));
                        },
                      ),
                  ],
                ),
              const SizedBox(height: 26),
              _SectionTitle(label: 'أعمال مشابهة', tone: _kGreen),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
      SliverToBoxAdapter(child: _relatedBlock(context)),
    ];
  }

  Widget _relatedBlock(BuildContext context) {
    final p = context.pal;
    return FutureBuilder<List<Series>>(
      future: _related,
      builder: (ctx, snap) {
        if (snap.hasError) {
          return _Notice(
            icon: SardIcons.cloud_off_rounded,
            tone: _kPink,
            title: 'تعذّر تحميل الاقتراحات',
            subtitle: 'تحقق من الاتصال ثم حاول مجدداً.',
            actionLabel: 'إعادة المحاولة',
            onAction: () => setState(() {
              _related = context.read<SardRepository>().related(widget.series);
            }),
          );
        }
        if (!snap.hasData) {
          return SizedBox(
            height: 272,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: 3,
              separatorBuilder: (_, i) => const SizedBox(width: 12),
              itemBuilder: (_, i) => const SizedBox(
                width: 140,
                child: Skeleton(height: 200, radius: 18),
              ),
            ),
          );
        }
        final items = snap.data!;
        if (items.isEmpty) {
          return _Notice(
            icon: SardIcons.layers_rounded,
            tone: p.textDim,
            title: 'لا توجد أعمال مشابهة بعد',
            subtitle: 'سنعرض هنا اقتراحات حين تتوفر.',
          );
        }
        return SizedBox(
          height: 272,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: items.length,
            separatorBuilder: (_, i) => const SizedBox(width: 12),
            itemBuilder: (c, i) => PosterCard(
              series: items[i],
              heroTag: 'related-${items[i].id}',
              onTap: () => Navigator.push(
                c,
                sardRoute(DetailsScreen(series: items[i], heroTag: 'related-${items[i].id}')),
              ),
            ),
          ),
        );
      },
    );
  }

  // ───────── تبويب الفصول ─────────

  bool _passes(Chapter c, Set<int> readSet) {
    switch (_filter) {
      case _ChFilter.all:
        return true;
      case _ChFilter.unread:
        return !readSet.contains(c.number);
      case _ChFilter.downloaded:
        return _downloadedNums.contains(c.number);
    }
  }

  List<Widget> _chaptersSlivers(BuildContext context) {
    final p = context.pal;
    final settings = context.read<SettingsController>();
    final readSet = settings.readChapters(widget.series.id);
    final prog = settings.progressOf(widget.series.id);
    final all = _loaded;

    List<Chapter> shown = <Chapter>[];
    if (all != null) {
      shown = all.where((c) => _passes(c, readSet)).toList();
      shown.sort((a, b) => _newestFirst ? b.number.compareTo(a.number) : a.number.compareTo(b.number));
    }

    final Widget body;
    if (_chError != null) {
      body = SliverToBoxAdapter(
        child: _Notice(
          icon: SardIcons.cloud_off_rounded,
          tone: _kPink,
          title: 'تعذّر تحميل الفصول',
          subtitle: 'السبب: ${_chError.toString()}',
          actionLabel: 'إعادة المحاولة',
          onAction: () => setState(_startChapters),
        ),
      );
    } else if (all == null) {
      body = SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (var i = 0; i < 5; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Skeleton(height: 82, radius: _rad(p, 0.9)),
                ),
            ],
          ),
        ),
      );
    } else if (all.isEmpty) {
      body = const SliverToBoxAdapter(
        child: _Notice(
          icon: SardIcons.menu_book_rounded,
          tone: _kBlue,
          title: 'لا توجد فصول بعد',
          subtitle: 'ستظهر الفصول هنا فور نشرها.',
        ),
      );
    } else if (shown.isEmpty) {
      body = SliverToBoxAdapter(
        child: _Notice(
          icon: SardIcons.filter_list_rounded,
          tone: _kAmber,
          title: _filter == _ChFilter.downloaded ? 'لا توجد فصول محمّلة' : 'لا توجد فصول غير مقروءة',
          subtitle: 'جرّب تغيير التصفية لعرض بقية الفصول.',
          actionLabel: 'عرض الكل',
          onAction: () => setState(() => _filter = _ChFilter.all),
        ),
      );
    } else {
      body = SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        sliver: SliverList(
          delegate: SliverChildBuilderDelegate(
            (c, i) {
              final ch = shown[i];
              final pg = (prog != null &&
                      prog.chapter == ch.number &&
                      prog.page > 1 &&
                      prog.page < prog.total)
                  ? prog.page
                  : 1;
              final double? inProgress = (prog != null && prog.chapter == ch.number && pg > 1)
                  ? prog.fraction
                  : null;
              return _ChapterCard(
                key: ValueKey<int>(ch.number),
                chapter: ch,
                read: readSet.contains(ch.number),
                downloaded: _downloadedNums.contains(ch.number),
                inProgress: inProgress,
                onTap: () => GuideController.instance.run('btn.chapter', () => _open(ch.number, page: pg)),
                onDownload: () => _downloadChapter(ch),
              );
            },
            childCount: shown.length,
          ),
        ),
      );
    }

    return <Widget>[
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: _SectionTitle(
                      label: all == null ? 'الفصول' : '${shown.length} فصل',
                      tone: _kBlue,
                    ),
                  ),
                  _MiniPill(
                    icon: SardIcons.swap_vert_rounded,
                    label: _newestFirst ? 'الأحدث' : 'الأقدم',
                    tone: _kBlue,
                    onTap: () => GuideController.instance.run(
                      'btn.chapter_sort',
                      () => setState(() => _newestFirst = !_newestFirst),
                    ),
                  ),
                  const SizedBox(width: 8),
                  _MiniPill(
                    icon: SardIcons.download_rounded,
                    label: 'تنزيل',
                    tone: _kGreen,
                    filled: true,
                    onTap: () => GuideController.instance.run('btn.download', _chooseDownload),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _FilterChipBtn(
                    label: 'الكل',
                    tone: _kBlue,
                    selected: _filter == _ChFilter.all,
                    onTap: () => GuideController.instance.run('btn.chapter_filter', () => setState(() => _filter = _ChFilter.all)),
                  ),
                  _FilterChipBtn(
                    label: 'غير مقروء',
                    tone: _kAmber,
                    selected: _filter == _ChFilter.unread,
                    onTap: () => GuideController.instance.run('btn.chapter_filter', () => setState(() => _filter = _ChFilter.unread)),
                  ),
                  _FilterChipBtn(
                    label: 'محمّل',
                    tone: _kGreen,
                    selected: _filter == _ChFilter.downloaded,
                    onTap: () => GuideController.instance.run('btn.chapter_filter', () => setState(() => _filter = _ChFilter.downloaded)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      body,
    ];
  }

  // ───────── تبويب التعليقات ─────────

  List<Widget> _commentsSlivers(BuildContext context, Series s) {
    return <Widget>[
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: CommentsPanel(seriesId: s.id, tone: _kGreen),
        ),
      ),
    ];
  }
}

// ═════════════════ مكوّنات مساعدة خاصة بالصفحة ═════════════════

class _TabsDelegate extends SliverPersistentHeaderDelegate {
  _TabsDelegate({required this.extent, required this.child});
  final double extent;
  final Widget child;

  @override
  double get minExtent => extent;

  @override
  double get maxExtent => extent;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) => child;

  @override
  bool shouldRebuild(covariant _TabsDelegate oldDelegate) => true;
}

/// شريط التبويبات: مؤشر منزلق بلون يتدرّج بين ألوان التبويبات
class _TabsBar extends StatelessWidget {
  const _TabsBar({
    required this.pos,
    required this.outer,
    required this.threshold,
    required this.top,
    required this.labels,
    required this.icons,
    required this.onTap,
    required this.onBack,
  });

  final ValueNotifier<double> pos;
  final ScrollController outer;
  final double threshold;
  final double top;
  final List<String> labels;
  final List<SIconData> icons;
  final ValueChanged<int> onTap;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final cols = <Color>[p.accent, _kBlue, _kGreen];
    final trackR = _rad(p, 1.0, 23);
    final indR = math.max(trackR - 3, 6.0);
    return Container(
      color: p.bg,
      padding: EdgeInsets.fromLTRB(16, top + 6, 16, 6),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: outer,
            builder: (c, _) {
              final shown = outer.hasClients && outer.position.pixels > threshold;
              return AnimatedSize(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                child: shown
                    ? Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8),
                        child: Pressable(
                          onTap: onBack,
                          child: Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: _surf(p),
                              shape: BoxShape.circle,
                              border: Border.all(color: p.border, width: p.borderW),
                            ),
                            child: SIcon(SardIcons.arrow_back_rounded, color: p.text, size: 22),
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              );
            },
          ),
          Expanded(
            child: Container(
              height: 46,
              decoration: BoxDecoration(
                color: _surf(p),
                borderRadius: BorderRadius.circular(trackR),
                border: Border.all(color: p.border, width: p.borderW),
              ),
              child: LayoutBuilder(
                builder: (c, box) {
                  final itemW = math.max((box.maxWidth - 8) / labels.length, 1.0);
                  return ValueListenableBuilder<double>(
                    valueListenable: pos,
                    builder: (ctx, v, _) {
                      final maxI = labels.length - 1;
                      final i = v.floor().clamp(0, maxI).toInt();
                      final j = (i + 1).clamp(0, maxI).toInt();
                      final t = (v - i).clamp(0.0, 1.0).toDouble();
                      final ic = Color.lerp(cols[i], cols[j], t) ?? cols[i];
                      return Stack(
                        children: [
                          PositionedDirectional(
                            start: 4 + math.max(0.0, math.min(v, maxI.toDouble())) * itemW,
                            top: 4,
                            bottom: 4,
                            width: itemW,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                color: tint(ic, 0.18),
                                borderRadius: BorderRadius.circular(indR),
                                border: Border.all(color: tint(ic, 0.7), width: p.borderW),
                                boxShadow: _glow(p, ic),
                              ),
                            ),
                          ),
                          Positioned.fill(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              child: Row(
                                children: [
                                  for (var k = 0; k < labels.length; k++)
                                    Expanded(
                                      child: Pressable(
                                        onTap: () => onTap(k),
                                        scale: 0.94,
                                        child: Builder(
                                          builder: (cc) {
                                            final near = (1 - (v - k).abs()).clamp(0.0, 1.0).toDouble();
                                            final col = Color.lerp(p.textDim, cols[k], near) ?? p.textDim;
                                            return Center(
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  SIcon(icons[k], size: 16, color: col),
                                                  const SizedBox(width: 6),
                                                  Text(
                                                    labels[k],
                                                    style: cc.ts(size: 12.5, w: FontWeight.w700, color: col),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter({
    required this.value,
    required this.color,
    required this.track,
    required this.stroke,
  });

  final double value;
  final Color color;
  final Color track;
  final double stroke;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(
      stroke / 2,
      stroke / 2,
      size.width - stroke,
      size.height - stroke,
    );
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..color = track;
    canvas.drawArc(rect, 0, math.pi * 2, false, base);
    if (value <= 0) return;
    final fg = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..color = color;
    canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * value.clamp(0.0, 1.0), false, fg);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) =>
      old.value != value || old.color != color || old.track != track || old.stroke != stroke;
}

/// زر زجاجي فوق الغلاف
class _GlassBtn extends StatelessWidget {
  const _GlassBtn({
    required this.icon,
    required this.onTap,
    this.active = false,
    this.activeColor,
  });

  final SIconData icon;
  final VoidCallback onTap;
  final bool active;
  final Color? activeColor;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = activeColor ?? p.accent;
    final r = _rad(p, 0.7, 22);
    return Pressable(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(r),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutCubic,
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: active ? tint(tone, 0.82) : tint(Colors.black, 0.32),
              borderRadius: BorderRadius.circular(r),
              border: Border.all(
                color: active ? tint(tone, 0.95) : tint(Colors.white, 0.22),
                width: p.borderW,
              ),
            ),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
              child: SIcon(icon, key: ValueKey<SIconData>(icon), size: 22, color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}

class _GlassPill extends StatelessWidget {
  const _GlassPill({required this.icon, required this.label});
  final SIconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: tint(Colors.black, 0.5),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: tint(Colors.white, 0.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(icon, size: 12, color: Colors.white),
          const SizedBox(width: 5),
          Text(label, style: context.ts(size: 11, w: FontWeight.w600, color: Colors.white)),
        ],
      ),
    );
  }
}

class _ActionCircle extends StatelessWidget {
  const _ActionCircle({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.color,
    required this.active,
    required this.onTap,
    this.busy = false,
  });

  final SIconData icon;
  final SIconData activeIcon;
  final String label;
  final Color color;
  final bool active;
  final bool busy;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: busy ? null : onTap,
      child: Column(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutCubic,
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active ? color : tint(color, 0.14),
              border: Border.all(color: active ? color : tint(color, 0.45), width: p.borderW),
              boxShadow: active ? _glow(p, color, extra: 0.35) : const <BoxShadow>[],
            ),
            child: Center(
              child: busy
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2.2, color: color),
                    )
                  : AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                      child: SIcon(
                        active ? activeIcon : icon,
                        key: ValueKey<bool>(active),
                        size: 24,
                        color: active ? Colors.white : color,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: context.ts(
              size: 11.5,
              w: FontWeight.w600,
              color: active ? p.text : p.textDim,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.icon,
    required this.tone,
    required this.label,
    required this.value,
  });

  final SIconData icon;
  final Color tone;
  final String label;
  final Widget value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        color: tint(tone, p.isDark ? 0.13 : 0.1),
        borderRadius: BorderRadius.circular(_rad(p, 0.9)),
        border: Border.all(color: tint(tone, 0.42), width: p.borderW),
        boxShadow: _glow(p, tone),
      ),
      child: Column(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(color: tint(tone, 0.22), shape: BoxShape.circle),
            child: SIcon(icon, size: 19, color: tone),
          ),
          const SizedBox(height: 8),
          value,
          const SizedBox(height: 2),
          Text(label, style: context.ts(size: 11.5, color: p.textDim)),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.label, required this.tone});
  final String label;
  final Color tone;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 5,
          height: 22,
          decoration: BoxDecoration(
            color: tone,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 10),
        Text(label, style: context.ds(size: 19)),
      ],
    );
  }
}

/// الملخص مع «عرض المزيد»
class _Synopsis extends StatefulWidget {
  const _Synopsis({required this.text, required this.tone});
  final String text;
  final Color tone;

  @override
  State<_Synopsis> createState() => _SynopsisState();
}

class _SynopsisState extends State<_Synopsis> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final empty = widget.text.trim().isEmpty;
    final long = widget.text.length > 170;
    final expanded = _open || !long;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardDeco(p, tone: widget.tone),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AnimatedSize(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutCubic,
            alignment: Alignment.topCenter,
            child: Text(
              empty ? 'لا يوجد وصف بعد.' : widget.text,
              maxLines: expanded ? null : 4,
              overflow: expanded ? TextOverflow.visible : TextOverflow.ellipsis,
              style: context.ts(size: 14.5, color: p.textDim, height: 1.95),
            ),
          ),
          if (long)
            Pressable(
              onTap: () => setState(() => _open = !_open),
              child: Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _open ? 'عرض أقل' : 'عرض المزيد',
                      style: context.ts(size: 13, w: FontWeight.w700, color: widget.tone),
                    ),
                    const SizedBox(width: 4),
                    SIcon(
                      _open ? SardIcons.expand_less_rounded : SardIcons.expand_more_rounded,
                      size: 20,
                      color: widget.tone,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.icon,
    required this.tone,
    required this.label,
    required this.value,
  });

  final SIconData icon;
  final Color tone;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: _cardDeco(p, r: 0.8, tone: tone),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: tint(tone, 0.18),
              borderRadius: BorderRadius.circular(_rad(p, 0.45, 12)),
            ),
            child: SIcon(icon, size: 17, color: tone),
          ),
          const SizedBox(height: 10),
          Text(label, style: context.ts(size: 11.5, color: p.textDim)),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: context.ts(size: 13.5, w: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _GenreChip extends StatelessWidget {
  const _GenreChip({required this.label, required this.tone, required this.onTap});
  final String label;
  final Color tone;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: tint(tone, 0.14),
          borderRadius: BorderRadius.circular(_rad(p, 0.6, 20)),
          border: Border.all(color: tint(tone, 0.5), width: p.borderW),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SIcon(SardIcons.sell_rounded, size: 14, color: tone),
            const SizedBox(width: 6),
            Text(label, style: context.ts(size: 12.5, w: FontWeight.w700, color: tone)),
          ],
        ),
      ),
    );
  }
}

class _MiniPill extends StatelessWidget {
  const _MiniPill({
    required this.icon,
    required this.label,
    required this.tone,
    required this.onTap,
    this.filled = false,
  });

  final SIconData icon;
  final String label;
  final Color tone;
  final bool filled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final fg = filled ? Colors.white : tone;
    return Pressable(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: filled ? tone : tint(tone, 0.13),
          borderRadius: BorderRadius.circular(_rad(p, 0.6, 20)),
          border: Border.all(color: filled ? tone : tint(tone, 0.45), width: p.borderW),
          boxShadow: filled ? _glow(p, tone) : const <BoxShadow>[],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SIcon(icon, size: 16, color: fg),
            const SizedBox(width: 5),
            Text(label, style: context.ts(size: 12, w: FontWeight.w700, color: fg)),
          ],
        ),
      ),
    );
  }
}

class _FilterChipBtn extends StatelessWidget {
  const _FilterChipBtn({
    required this.label,
    required this.tone,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final Color tone;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? tint(tone, 0.2) : _surf(p),
          borderRadius: BorderRadius.circular(_rad(p, 0.7, 22)),
          border: Border.all(color: selected ? tone : p.border, width: p.borderW),
          boxShadow: selected ? _glow(p, tone) : const <BoxShadow>[],
        ),
        child: Text(
          label,
          style: context.ts(
            size: 12.5,
            w: FontWeight.w700,
            color: selected ? tone : p.textDim,
          ),
        ),
      ),
    );
  }
}

class _ChapterCard extends StatelessWidget {
  const _ChapterCard({
    super.key,
    required this.chapter,
    required this.read,
    required this.downloaded,
    required this.onTap,
    required this.onDownload,
    this.inProgress,
  });

  final Chapter chapter;
  final bool read;
  final bool downloaded;
  final double? inProgress;
  final VoidCallback onTap;
  final VoidCallback onDownload;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = chapter;
    final badgeTone = read ? _kGreen : _kBlue;
    final resuming = inProgress != null;
    return Pressable(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
        decoration: _cardDeco(p, r: 0.9, tone: p.accent, active: resuming),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(badgeTone, 0.15),
                    borderRadius: BorderRadius.circular(_rad(p, 0.6, 18)),
                    border: Border.all(color: tint(badgeTone, 0.4), width: p.borderW),
                  ),
                  child: read
                      ? SIcon(SardIcons.done_all_rounded, color: badgeTone, size: 24)
                      : Text('${c.number}', style: context.ds(size: 21, color: badgeTone)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        c.title.isEmpty ? 'الفصل ${c.number}' : c.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.ts(
                          size: 14.5,
                          w: FontWeight.w700,
                          color: read ? p.textDim : p.text,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            'الفصل ${c.number}',
                            style: context.ts(size: 11.5, color: p.textDim),
                          ),
                          Text('  ·  ', style: context.ts(size: 11.5, color: p.textDim)),
                          Flexible(
                            child: Text(
                              c.date,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: context.ts(size: 11.5, color: p.textDim),
                            ),
                          ),
                          Text('  ·  ', style: context.ts(size: 11.5, color: p.textDim)),
                          Text('${c.pages} صفحة', style: context.ts(size: 11.5, color: p.textDim)),
                        ],
                      ),
                      if (c.isNew || read || downloaded) ...[
                        const SizedBox(height: 6),
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: [
                            if (c.isNew) _Tag(label: 'جديد', icon: SardIcons.bolt_rounded, tone: _kPink, solid: true),
                            if (read) _Tag(label: 'مقروء', icon: SardIcons.check_rounded, tone: _kGreen),
                            if (downloaded) _Tag(label: 'محمّل', icon: SardIcons.download_done_rounded, tone: _kAmber),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Pressable(
                  onTap: onDownload,
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: tint(_kGreen, downloaded ? 0.9 : 0.14),
                      shape: BoxShape.circle,
                      border: Border.all(color: tint(_kGreen, 0.5), width: p.borderW),
                    ),
                    child: SIcon(
                      downloaded ? SardIcons.download_done_rounded : SardIcons.download_rounded,
                      size: 19,
                      color: downloaded ? Colors.white : _kGreen,
                    ),
                  ),
                ),
              ],
            ),
            if (resuming) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: (inProgress ?? 0).clamp(0.0, 1.0).toDouble(),
                  minHeight: 4,
                  color: p.accent,
                  backgroundColor: tint(p.accent, 0.18),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag({required this.label, required this.icon, required this.tone, this.solid = false});
  final String label;
  final SIconData icon;
  final Color tone;
  final bool solid;

  @override
  Widget build(BuildContext context) {
    final fg = solid ? Colors.white : tone;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: solid ? tone : tint(tone, 0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(icon, size: 11, color: fg),
          const SizedBox(width: 3),
          Text(label, style: context.ts(size: 10.5, w: FontWeight.w700, color: fg)),
        ],
      ),
    );
  }
}

/// حالة فراغ / خطأ بتصميم موحّد
class _Notice extends StatelessWidget {
  const _Notice({
    required this.icon,
    required this.tone,
    required this.title,
    this.subtitle,
    this.actionLabel,
    this.onAction,
  });

  final SIconData icon;
  final Color tone;
  final String title;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 26),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: tint(tone, 0.14),
              shape: BoxShape.circle,
              border: Border.all(color: tint(tone, 0.4), width: p.borderW),
            ),
            child: SIcon(icon, size: 32, color: tone),
          ),
          const SizedBox(height: 14),
          Text(title, textAlign: TextAlign.center, style: context.ds(size: 18)),
          if (subtitle != null) ...[
            const SizedBox(height: 6),
            Text(
              subtitle!,
              textAlign: TextAlign.center,
              style: context.ts(size: 13, color: p.textDim, height: 1.7),
            ),
          ],
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: 16),
            _MiniPill(icon: SardIcons.refresh_rounded, label: actionLabel!, tone: tone, filled: true, onTap: onAction!),
          ],
        ],
      ),
    );
  }
}
