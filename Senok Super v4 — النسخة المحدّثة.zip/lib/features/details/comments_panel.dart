import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/verified_badge.dart';
import '../account/user_profile_screen.dart';

const Color _cBlue = Color(0xFF3B9EFF);
const Color _cGreen = Color(0xFF2FCB7A);
const Color _cAmber = Color(0xFFF5A524);
const Color _cPink = Color(0xFFE0457B);

double _cRad(SardPalette p, double f, [double max = 30]) => math.min(p.r(f), max);

Color _cSurf(SardPalette p) => p.glass ? tint(p.surface, 0.72) : p.surface;

List<BoxShadow> _cGlow(SardPalette p, Color c) {
  if (p.glow <= 0) return const <BoxShadow>[];
  return <BoxShadow>[
    BoxShadow(color: tint(c, 0.4 * p.glow), blurRadius: 10 + 16 * p.glow, spreadRadius: -2),
  ];
}

/// لوحة التعليقات: تتبع الثيم (زوايا/إطارات/توهّج/زجاج) ولونها المميّز [tone].
class CommentsPanel extends StatefulWidget {
  const CommentsPanel({super.key, required this.seriesId, this.tone});
  final String seriesId;

  /// لون اللوحة (الافتراضي: لون تمييز الثيم)
  final Color? tone;

  @override
  State<CommentsPanel> createState() => _CommentsPanelState();
}

class _CommentsPanelState extends State<CommentsPanel> {
  final TextEditingController _controller = TextEditingController();
  late Future<List<SardComment>> _future;
  String? _replyTo;
  String? _replyAuthor;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _future = context.read<SardRepository>().comments(widget.seriesId);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    final f = context.read<SardRepository>().comments(widget.seriesId);
    setState(() => _future = f);
    try {
      await f;
    } catch (_) {
      // يعرض FutureBuilder حالة الخطأ
    }
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _sending) return;
    final repo = context.read<SardRepository>();
    setState(() => _sending = true);
    try {
      await repo.addComment(widget.seriesId, text, parentId: _replyTo);
      if (!mounted) return;
      _controller.clear();
      setState(() {
        _replyTo = null;
        _replyAuthor = null;
      });
      await _refresh();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر إرسال التعليق: $e')));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _like(SardComment c) async {
    final repo = context.read<SardRepository>();
    try {
      await repo.likeComment(widget.seriesId, c.id);
    } catch (_) {
      return;
    }
    if (mounted) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = widget.tone ?? p.accent;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 5,
                height: 22,
                decoration: BoxDecoration(color: tone, borderRadius: BorderRadius.circular(4)),
              ),
              const SizedBox(width: 10),
              Text('النقاش', style: context.ds(size: 19)),
              const Spacer(),
              Pressable(
                onTap: _refresh,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: tint(tone, 0.14),
                    shape: BoxShape.circle,
                    border: Border.all(color: tint(tone, 0.45), width: p.borderW),
                  ),
                  child: SIcon(SardIcons.refresh_rounded, size: 20, color: tone),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _composer(context, tone),
          const SizedBox(height: 18),
          FutureBuilder<List<SardComment>>(
            future: _future,
            builder: (context, snap) {
              if (snap.hasError) {
                return _state(
                  context,
                  icon: SardIcons.cloud_off_rounded,
                  tone: _cPink,
                  title: 'تعذّر تحميل التعليقات',
                  subtitle: 'تحقق من اتصال السيرفر ثم حاول مجدداً.',
                  action: 'إعادة المحاولة',
                  onAction: _refresh,
                );
              }
              if (!snap.hasData) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (var i = 0; i < 3; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Skeleton(height: 96, radius: _cRad(p, 0.9)),
                      ),
                  ],
                );
              }
              final items = snap.data!;
              if (items.isEmpty) {
                return _state(
                  context,
                  icon: SardIcons.forum_rounded,
                  tone: tone,
                  title: 'لا توجد تعليقات بعد',
                  subtitle: 'كن أول من يشارك رأيه!',
                );
              }
              final roots = items.where((e) => e.parentId == null).toList();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  for (final c in roots) _comment(context, c, items, tone),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _composer(BuildContext context, Color tone) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 10, 10),
      decoration: BoxDecoration(
        color: _cSurf(p),
        borderRadius: BorderRadius.circular(_cRad(p, 1.0)),
        border: Border.all(color: _replyTo != null ? tint(tone, 0.7) : p.border, width: p.borderW),
        boxShadow: _replyTo != null ? _cGlow(p, tone) : const <BoxShadow>[],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (_replyTo != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  SIcon(SardIcons.reply_rounded, size: 16, color: tone),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'رد على ${_replyAuthor ?? 'تعليق'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: context.ts(size: 12, w: FontWeight.w700, color: tone),
                    ),
                  ),
                  Pressable(
                    onTap: () => setState(() {
                      _replyTo = null;
                      _replyAuthor = null;
                    }),
                    child: SIcon(SardIcons.close_rounded, size: 18, color: p.textDim),
                  ),
                ],
              ),
            ),
          TextField(
            controller: _controller,
            minLines: 2,
            maxLines: 5,
            style: context.ts(size: 14),
            decoration: InputDecoration(
              isCollapsed: true,
              border: InputBorder.none,
              hintText: _replyTo == null ? 'اكتب تعليقك حول هذا العمل…' : 'اكتب ردك…',
              hintStyle: context.ts(size: 14, color: p.textDim),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: Pressable(
              onTap: _sending ? null : _send,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                decoration: BoxDecoration(
                  color: tone,
                  borderRadius: BorderRadius.circular(_cRad(p, 0.7, 22)),
                  boxShadow: _cGlow(p, tone),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (_sending)
                      const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    else
                      const SIcon(SardIcons.send_rounded, size: 16, color: Colors.white),
                    const SizedBox(width: 6),
                    Text(
                      _sending ? 'جارٍ الإرسال' : 'إرسال',
                      style: context.ts(size: 13, w: FontWeight.w700, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _state(
    BuildContext context, {
    required SIconData icon,
    required Color tone,
    required String title,
    required String subtitle,
    String? action,
    VoidCallback? onAction,
  }) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 22),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: tint(tone, 0.14),
              shape: BoxShape.circle,
              border: Border.all(color: tint(tone, 0.4), width: p.borderW),
            ),
            child: SIcon(icon, size: 32, color: tone),
          ),
          const SizedBox(height: 14),
          Text(title, textAlign: TextAlign.center, style: context.ds(size: 18)),
          const SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: context.ts(size: 13, color: p.textDim, height: 1.7),
          ),
          if (action != null && onAction != null) ...[
            const SizedBox(height: 16),
            Pressable(
              onTap: onAction,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                decoration: BoxDecoration(
                  color: tone,
                  borderRadius: BorderRadius.circular(_cRad(p, 0.7, 22)),
                ),
                child: Text(
                  action,
                  style: context.ts(size: 13, w: FontWeight.w700, color: Colors.white),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _avatarTone(SardPalette p, String author) {
    final tones = <Color>[p.accent, _cBlue, _cGreen, _cAmber, _cPink];
    final sum = author.codeUnits.fold<int>(0, (a, b) => a + b);
    return tones[sum % tones.length];
  }

  String _initial(String author) {
    final t = author.trim();
    if (t.isEmpty) return '؟';
    return String.fromCharCode(t.runes.first);
  }

  Widget _comment(BuildContext context, SardComment c, List<SardComment> all, Color tone) {
    final p = context.pal;
    final avatar = _avatarTone(p, c.author);
    final replies = all.where((e) => e.parentId == c.id).toList();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cSurf(p),
        borderRadius: BorderRadius.circular(_cRad(p, 0.9)),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Pressable(
            scale: 0.985,
            onTap: () => openUserProfile(context, id: c.authorId, name: c.author, badge: c.badge),
            child: Row(
              children: [
                c.badge.isNone
                    ? Container(
                        width: 36,
                        height: 36,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: tint(avatar, 0.2),
                          shape: BoxShape.circle,
                          border: Border.all(color: tint(avatar, 0.6), width: p.borderW),
                        ),
                        child: Text(_initial(c.author), style: context.ds(size: 16, color: avatar)),
                      )
                    : RingAvatar(name: c.author, badge: c.badge, size: 36),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      NameWithBadge(c.author, c.badge, badgeSize: 15, style: context.ts(size: 13.5, w: FontWeight.w700)),
                      if (c.createdAt.isNotEmpty)
                        Text(c.createdAt, style: context.ts(size: 10.5, color: p.textDim)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(c.text, style: context.ts(size: 13.5, height: 1.7)),
          const SizedBox(height: 10),
          Row(
            children: [
              Pressable(
                onTap: () => _like(c),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: tint(_cPink, c.liked ? 0.2 : 0.1),
                    borderRadius: BorderRadius.circular(_cRad(p, 0.5, 16)),
                    border: Border.all(color: tint(_cPink, c.liked ? 0.7 : 0.3), width: p.borderW),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(
                        c.liked ? SardIcons.thumb_up_rounded : SardIcons.thumb_up_off_alt_rounded,
                        size: 15,
                        color: _cPink,
                      ),
                      const SizedBox(width: 5),
                      Text(
                        '${c.likes}',
                        style: context.ts(size: 11.5, w: FontWeight.w700, color: _cPink),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Pressable(
                onTap: () => setState(() {
                  _replyTo = c.id;
                  _replyAuthor = c.author;
                }),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: tint(tone, 0.12),
                    borderRadius: BorderRadius.circular(_cRad(p, 0.5, 16)),
                    border: Border.all(color: tint(tone, 0.35), width: p.borderW),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(SardIcons.reply_rounded, size: 15, color: tone),
                      const SizedBox(width: 5),
                      Text('رد', style: context.ts(size: 11.5, w: FontWeight.w700, color: tone)),
                    ],
                  ),
                ),
              ),
              if (replies.isNotEmpty) ...[
                const Spacer(),
                Text('${replies.length} ردود', style: context.ts(size: 11, color: p.textDim)),
              ],
            ],
          ),
          for (final r in replies)
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 14, top: 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(_cRad(p, 0.5, 16)),
                child: Container(
                  color: tint(_avatarTone(p, r.author), 0.08),
                  child: IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(width: 3, color: _avatarTone(p, r.author)),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(12, 8, 10, 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  r.author,
                                  style: context.ts(
                                    size: 11.5,
                                    w: FontWeight.w700,
                                    color: _avatarTone(p, r.author),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(r.text, style: context.ts(size: 12.5, height: 1.6)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
