import 'dart:async';

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/search_filters.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/fx.dart';
import '../../widgets/pickers.dart';
import '../../widgets/pills.dart';
import '../../widgets/routes.dart';
import '../../widgets/states.dart';
import '../details/details_screen.dart';
import '../../widgets/sard_icons.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({
    super.key,
    this.standalone = false,
    this.initialFilters = SearchFilters.none,
    this.openFiltersOnStart = false,
  });

  /// true عند فتحها من أيقونة البحث في الرئيسية (تظهر زر رجوع)
  final bool standalone;

  /// فلاتر جاهزة (تأتي من بطاقات «اكتشف بدقة» في الرئيسية)
  final SearchFilters initialFilters;

  /// فتح نافذة الفلاتر مباشرة
  final bool openFiltersOnStart;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _ctl = TextEditingController();
  Timer? _debounce;
  late SearchFilters _f;
  late Future<List<Series>> _future;

  static const _sorts = [
    ('new', 'الأحدث'),
    ('views', 'الأكثر مشاهدة'),
    ('rating', 'الأعلى تقييماً'),
    ('chapters', 'الأكثر فصولاً'),
    ('chapters_asc', 'الأقل فصولاً'),
    ('year', 'الأحدث إصداراً'),
  ];

  @override
  void initState() {
    super.initState();
    _f = widget.initialFilters;
    _future = _query();
    if (widget.openFiltersOnStart) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _showAdvanced();
      });
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctl.dispose();
    super.dispose();
  }

  Future<List<Series>> _query() =>
      context.read<SardRepository>().searchFiltered(_ctl.text.trim(), _f);

  void _run() => setState(() => _future = _query());

  void _setFilters(SearchFilters f) {
    _f = f;
    _run();
  }

  void _onChanged(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), _run);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final active = _f.activeCount;
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
              child: Row(
                children: [
                  if (widget.standalone) ...[
                    RoundIconButton(
                      icon: SardIcons.arrow_back_rounded,
                      onTap: () => Navigator.of(context).pop(),
                    ),
                    const SizedBox(width: 14),
                  ],
                  Text('البحث', style: context.ds(size: 30)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: p.glass ? tint(p.surface, 0.78) : p.surface,
                        borderRadius: BorderRadius.circular(p.r(1.1).clamp(10.0, 30.0).toDouble()),
                        border: Border.all(color: p.border, width: p.borderW),
                        boxShadow: p.glow > 0
                            ? [BoxShadow(color: tint(p.accent, 0.14 * p.glow), blurRadius: 14)]
                            : null,
                      ),
                      child: TextField(
                        controller: _ctl,
                        onChanged: _onChanged,
                        onSubmitted: (_) => _run(),
                        textInputAction: TextInputAction.search,
                        style: context.ts(size: 15, w: FontWeight.w500),
                        decoration: InputDecoration(
                          hintText: 'ابحث عن مانهوا أو مانغا...',
                          hintStyle: context.ts(size: 15, color: p.textDim),
                          prefixIcon: SIcon(SardIcons.search_rounded, color: p.text),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(vertical: 18),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _filterButton(p, active),
                ],
              ),
            ),
            // الأنواع: اختيار متعدد سريع
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  SardChip(
                    label: 'الكل',
                    selected: _f.types.isEmpty,
                    onTap: () => _setFilters(_f.copyWith(types: <String>{})),
                  ),
                  for (final t in SearchFilters.typeOptions) ...[
                    const SizedBox(width: 8),
                    SardChip(
                      label: t,
                      selected: _f.types.contains(t),
                      onTap: () {
                        final next = {..._f.types};
                        if (!next.remove(t)) next.add(t);
                        _setFilters(_f.copyWith(types: next));
                      },
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 10),
            // الترتيب
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _sorts.length,
                separatorBuilder: (context, i) => const SizedBox(width: 8),
                itemBuilder: (context, i) => SardChip(
                  label: _sorts[i].$2,
                  selected: _f.sort == _sorts[i].$1,
                  onTap: () => _setFilters(_f.copyWith(sort: _sorts[i].$1)),
                ),
              ),
            ),
            if (active > 0) _activeStrip(p),
            const SizedBox(height: 12),
            Expanded(
              child: FutureBuilder<List<Series>>(
                future: _future,
                builder: (context, snap) {
                  if (snap.hasError) return ErrorState(onRetry: _run);
                  if (!snap.hasData) {
                    return ListView(
                      physics: const NeverScrollableScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      children: [
                        for (var i = 0; i < 5; i++)
                          const Padding(
                            padding: EdgeInsets.only(bottom: 12),
                            child: Skeleton(height: 108, radius: 22),
                          ),
                      ],
                    );
                  }
                  final list = snap.data!;
                  if (list.isEmpty) {
                    return EmptyState(
                      title: 'لا توجد نتائج',
                      subtitle: active > 0
                          ? 'جرّب تخفيف بعض الفلاتر أو مسحها.'
                          : 'جرّب كلمة أخرى.',
                    );
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.only(bottom: 24),
                    itemCount: list.length + 1,
                    itemBuilder: (context, i) {
                      if (i == 0) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(22, 0, 22, 10),
                          child: Text(
                            '${list.length} نتيجة',
                            style: context.ts(size: 12.5, color: p.textDim, w: FontWeight.w600),
                          ),
                        );
                      }
                      final s = list[i - 1];
                      return FadeSlide(
                        index: i - 1,
                        child: SeriesTile(
                          series: s,
                          heroTag: 'search-${s.id}',
                          onTap: () => Navigator.of(context)
                              .push(sardRoute(DetailsScreen(series: s, heroTag: 'search-${s.id}'))),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filterButton(SardPalette p, int active) {
    return Pressable(
      onTap: _showAdvanced,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: active > 0 ? p.accent : (p.glass ? tint(p.surface, 0.78) : p.surface),
              borderRadius: BorderRadius.circular(p.r(1.1).clamp(10.0, 30.0).toDouble()),
              border: Border.all(color: active > 0 ? p.accent : p.border, width: p.borderW),
            ),
            child: Center(
              child: SIcon(
                SardIcons.tune_rounded,
                color: active > 0 ? p.onAccent : p.text,
                size: 24,
              ),
            ),
          ),
          if (active > 0)
            PositionedDirectional(
              top: -5,
              end: -5,
              child: Container(
                constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                padding: const EdgeInsets.symmetric(horizontal: 5),
                decoration: BoxDecoration(
                  color: p.gold,
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: p.bg, width: 2),
                ),
                child: Center(
                  child: Text(
                    '$active',
                    style: context.ts(size: 11, w: FontWeight.w800, color: Colors.black),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// شرائح الفلاتر المفعّلة: اضغط لإزالة واحد، أو «مسح الكل».
  Widget _activeStrip(SardPalette p) {
    final chips = _f.activeChips();
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: SizedBox(
        height: 36,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          children: [
            for (final c in chips) ...[
              Pressable(
                onTap: () => _setFilters(c.$2),
                child: Container(
                  padding: const EdgeInsetsDirectional.fromSTEB(8, 0, 12, 0),
                  decoration: BoxDecoration(
                    color: tint(p.accent, 0.14),
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(color: tint(p.accent, 0.6)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(SardIcons.close_rounded, size: 15, color: p.accent),
                      const SizedBox(width: 5),
                      Text(c.$1, style: context.ts(size: 12.5, w: FontWeight.w700, color: p.accent)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ],
            Pressable(
              onTap: () => _setFilters(SearchFilters.none.copyWith(sort: _f.sort)),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                alignment: Alignment.center,
                child: Text('مسح الكل', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.textDim)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showAdvanced() async {
    final pal = context.pal;
    final result = await showModalBottomSheet<SearchFilters>(
      context: context,
      isScrollControlled: true,
      backgroundColor: pal.glass ? tint(pal.surface, 0.96) : pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(pal.r(1.4).clamp(16.0, 32.0).toDouble())),
        side: BorderSide(color: pal.border, width: pal.borderW),
      ),
      builder: (sheet) => FractionallySizedBox(
        heightFactor: 0.93,
        child: _FiltersSheet(initial: _f),
      ),
    );
    if (result != null && mounted) _setFilters(result);
  }
}

// ───────── نافذة الفلاتر المتقدمة ─────────

const int _kChapMax = 300;
const int _kYearMin = 2015;
const int _kYearMax = 2026;

class _FiltersSheet extends StatefulWidget {
  const _FiltersSheet({required this.initial});
  final SearchFilters initial;

  @override
  State<_FiltersSheet> createState() => _FiltersSheetState();
}

class _FiltersSheetState extends State<_FiltersSheet> {
  late Set<String> _types;
  late Set<String> _statuses;
  late Set<String> _genres;
  late Set<String> _exclude;
  late bool _matchAll;
  late RangeValues _chapters;
  late RangeValues _years;
  late double _rating;
  late int _views;
  late bool _onlyNew;
  late String _sort;

  static const _chapterPresets = [
    ('قصيرة · حتى 30', 0, 30),
    ('متوسطة · 30–100', 30, 100),
    ('طويلة · 100–200', 100, 200),
    ('ملحمية · +200', 200, _kChapMax),
  ];
  static const _ratings = [0.0, 7.0, 8.0, 8.5, 9.0];
  static const _viewsOptions = [
    (0, 'الكل'),
    (100000, '100 ألف+'),
    (500000, '500 ألف+'),
    (1000000, '1 م+'),
  ];

  @override
  void initState() {
    super.initState();
    final f = widget.initial;
    _types = {...f.types};
    _statuses = {...f.statuses};
    _genres = {...f.genres};
    _exclude = {...f.exclude};
    _matchAll = f.matchAllGenres;
    _chapters = RangeValues(
      (f.chaptersMin ?? 0).clamp(0, _kChapMax).toDouble(),
      (f.chaptersMax ?? _kChapMax).clamp(0, _kChapMax).toDouble(),
    );
    _years = RangeValues(
      (f.yearFrom ?? _kYearMin).clamp(_kYearMin, _kYearMax).toDouble(),
      (f.yearTo ?? _kYearMax).clamp(_kYearMin, _kYearMax).toDouble(),
    );
    _rating = f.minRating;
    _views = f.minViews;
    _onlyNew = f.onlyNew;
    _sort = f.sort;
  }

  SearchFilters _build() => SearchFilters(
        types: _types,
        statuses: _statuses,
        genres: _genres,
        exclude: _exclude,
        matchAllGenres: _matchAll,
        chaptersMin: _chapters.start <= 0 ? null : _chapters.start.round(),
        chaptersMax: _chapters.end >= _kChapMax ? null : _chapters.end.round(),
        minRating: _rating,
        minViews: _views,
        yearFrom: _years.start <= _kYearMin ? null : _years.start.round(),
        yearTo: _years.end >= _kYearMax ? null : _years.end.round(),
        onlyNew: _onlyNew,
        sort: _sort,
      );

  void _reset() {
    setState(() {
      _types = {};
      _statuses = {};
      _genres = {};
      _exclude = {};
      _matchAll = true;
      _chapters = const RangeValues(0, _kChapMax * 1.0);
      _years = const RangeValues(_kYearMin * 1.0, _kYearMax * 1.0);
      _rating = 0;
      _views = 0;
      _onlyNew = false;
    });
  }

  void _toggle(Set<String> set, String v) {
    setState(() {
      if (!set.remove(v)) set.add(v);
    });
  }

  String get _chaptersLabel {
    final a = _chapters.start.round();
    final b = _chapters.end.round();
    if (a == 0 && b >= _kChapMax) return 'أي عدد';
    if (b >= _kChapMax) return '$a فصل أو أكثر';
    if (a == 0) return 'حتى $b فصل';
    return 'من $a إلى $b فصل';
  }

  String get _yearsLabel {
    final a = _years.start.round();
    final b = _years.end.round();
    if (a <= _kYearMin && b >= _kYearMax) return 'أي سنة';
    return '$a – $b';
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    final count = _build().activeCount;
    return Column(
      children: [
        const SizedBox(height: 10),
        Container(
          width: 42,
          height: 4,
          decoration: BoxDecoration(color: tint(p.textDim, 0.4), borderRadius: BorderRadius.circular(4)),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 12, 6),
          child: Row(
            children: [
              Expanded(
                child: Text('الفلاتر المتقدمة', style: context.ts(size: 21, w: FontWeight.w800)),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: SIcon(SardIcons.close_rounded, color: p.textDim),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + bottomInset),
            children: [
              _title(context, 'نوع العمل'),
              _chipWrap(SearchFilters.typeOptions, _types),
              _title(context, 'الحالة'),
              _chipWrap(SearchFilters.statusOptions, _statuses),
              _title(context, 'عدد الفصول', trailing: _chaptersLabel),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final pr in _chapterPresets)
                    SardChip(
                      label: pr.$1,
                      selected: _chapters.start.round() == pr.$2 && _chapters.end.round() == pr.$3,
                      onTap: () => setState(() => _chapters = RangeValues(pr.$2.toDouble(), pr.$3.toDouble())),
                    ),
                ],
              ),
              _slider(
                context,
                child: RangeSlider(
                  values: _chapters,
                  min: 0,
                  max: _kChapMax.toDouble(),
                  divisions: _kChapMax ~/ 5,
                  onChanged: (v) => setState(() => _chapters = v),
                ),
                startLabel: '0',
                endLabel: '$_kChapMax+',
              ),
              _title(context, 'التقييم الأدنى'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final r in _ratings)
                    SardChip(
                      label: r == 0 ? 'الكل' : '${r.toString()}+ ★',
                      selected: _rating == r,
                      onTap: () => setState(() => _rating = r),
                    ),
                ],
              ),
              _title(context, 'عدد المشاهدات'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final v in _viewsOptions)
                    SardChip(
                      label: v.$2,
                      selected: _views == v.$1,
                      onTap: () => setState(() => _views = v.$1),
                    ),
                ],
              ),
              _title(context, 'سنة الإصدار', trailing: _yearsLabel),
              _slider(
                context,
                child: RangeSlider(
                  values: _years,
                  min: _kYearMin.toDouble(),
                  max: _kYearMax.toDouble(),
                  divisions: _kYearMax - _kYearMin,
                  onChanged: (v) => setState(() => _years = v),
                ),
                startLabel: '$_kYearMin',
                endLabel: '$_kYearMax',
              ),
              _title(context, 'التصنيفات المطلوبة'),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      _matchAll ? 'يجب أن يحوي العمل كل التصنيفات المختارة' : 'يكفي أن يحوي أي تصنيف مختار',
                      style: context.ts(size: 12, color: p.textDim),
                    ),
                  ),
                  SardChip(
                    label: _matchAll ? 'الكل' : 'أي منها',
                    selected: true,
                    onTap: () => setState(() => _matchAll = !_matchAll),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final g in SearchFilters.genreOptions)
                    SardChip(
                      label: g,
                      selected: _genres.contains(g),
                      onTap: () => setState(() {
                        if (!_genres.remove(g)) {
                          _genres.add(g);
                          _exclude.remove(g);
                        }
                      }),
                    ),
                ],
              ),
              _title(context, 'استبعاد تصنيفات'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final g in SearchFilters.genreOptions)
                    SardChip(
                      label: g,
                      selected: _exclude.contains(g),
                      onTap: () => setState(() {
                        if (!_exclude.remove(g)) {
                          _exclude.add(g);
                          _genres.remove(g);
                        }
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 18),
              Container(
                decoration: BoxDecoration(
                  color: p.glass ? tint(p.surface, 0.7) : p.surfaceHi,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: p.border),
                ),
                child: SwitchListTile(
                  value: _onlyNew,
                  onChanged: (v) => setState(() => _onlyNew = v),
                  activeColor: p.accent,
                  title: Text('الأعمال الجديدة فقط', style: context.ts(size: 14, w: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.fromLTRB(20, 12, 20, 14 + MediaQuery.of(context).padding.bottom),
          decoration: BoxDecoration(border: Border(top: BorderSide(color: tint(p.border, 0.6)))),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _reset,
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                  child: const Text('إعادة ضبط'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: FilledButton(
                  onPressed: () => Navigator.pop(context, _build()),
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                  child: Text(count > 0 ? 'تطبيق ($count)' : 'تطبيق الفلاتر'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _title(BuildContext context, String t, {String? trailing}) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 10),
      child: Row(
        children: [
          Expanded(child: Text(t, style: context.ts(size: 15, w: FontWeight.w800))),
          if (trailing != null)
            Text(trailing, style: context.ts(size: 12.5, w: FontWeight.w700, color: p.accent)),
        ],
      ),
    );
  }

  Widget _chipWrap(List<String> items, Set<String> selected) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final v in items)
          SardChip(label: v, selected: selected.contains(v), onTap: () => _toggle(selected, v)),
      ],
    );
  }

  Widget _slider(BuildContext context, {required Widget child, required String startLabel, required String endLabel}) {
    final p = context.pal;
    return Column(
      children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: p.accent,
            inactiveTrackColor: tint(p.textDim, 0.25),
            thumbColor: p.accent,
            overlayColor: tint(p.accent, 0.18),
            rangeThumbShape: const RoundRangeSliderThumbShape(enabledThumbRadius: 9),
            trackHeight: 4,
          ),
          child: child,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(startLabel, style: context.ts(size: 11, color: p.textDim)),
              Text(endLabel, style: context.ts(size: 11, color: p.textDim)),
            ],
          ),
        ),
      ],
    );
  }
}
