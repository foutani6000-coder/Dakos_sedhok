import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/stamps/stamps.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/stamp_seal.dart';

/// أختامي: كل إنجازاتك في مكان واحد، مع الشعلة اليومية وتقدّم الأختام المقفلة.
class StampsScreen extends StatelessWidget {
  const StampsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final settings = context.watch<SettingsController>();
    final stats = settings.stampStats;
    final unlocked = settings.unlockedStamps;
    final total = kStamps.length;
    final owned = kStamps.where((d) => unlocked.containsKey(d.id)).length;

    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: const Text('أختامي')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 36),
        children: [
          FadeSlide(child: _SummaryCard(owned: owned, total: total, unlocked: unlocked)),
          const SizedBox(height: 14),
          FadeSlide(index: 1, child: _StreakCard(settings: settings)),
          for (final g in StampGroup.values) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(2, 28, 2, 14),
              child: Row(
                children: [
                  Container(
                    width: 5,
                    height: 20,
                    decoration: BoxDecoration(
                      color: p.accent,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(g.label, style: context.ds(size: 18)),
                  const Spacer(),
                  Text(
                    '${kStamps.where((d) => d.group == g && unlocked.containsKey(d.id)).length}'
                    ' / ${kStamps.where((d) => d.group == g).length}',
                    style: context.ts(size: 12, w: FontWeight.w700, color: p.textDim),
                  ),
                ],
              ),
            ),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              mainAxisSpacing: 16,
              crossAxisSpacing: 8,
              childAspectRatio: 0.66,
              children: [
                for (final d in kStamps.where((d) => d.group == g))
                  _StampCell(
                    def: d,
                    value: d.value(stats),
                    unlockedAt: unlocked[d.id],
                    onTap: () => _showDetail(context, d, d.value(stats), unlocked[d.id]),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  static String _date(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';
  }

  void _showDetail(BuildContext context, StampDef d, int value, int? at) {
    final p = context.pal;
    final c = d.tier.color;
    final got = at != null;
    final frac = (value / d.target).clamp(0.0, 1.0).toDouble();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: p.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.6).clamp(18.0, 34.0).toDouble())),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 14, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4)),
              ),
              const SizedBox(height: 22),
              TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 1.6, end: 1),
                duration: const Duration(milliseconds: 520),
                curve: Curves.easeOutBack,
                builder: (context, v, child) => Transform.scale(scale: v, child: child),
                child: StampSeal(def: d, unlocked: got, size: 124, progress: frac),
              ),
              const SizedBox(height: 16),
              Text(d.title, style: ctx.ds(size: 22)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: tint(c, 0.16),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(color: tint(c, 0.5)),
                ),
                child: Text(d.tier.label, style: ctx.ts(size: 11.5, w: FontWeight.w800, color: c)),
              ),
              const SizedBox(height: 14),
              Text(
                d.desc,
                textAlign: TextAlign.center,
                style: ctx.ts(size: 13.5, color: p.textDim, height: 1.6),
              ),
              const SizedBox(height: 18),
              if (at != null)
                Text(
                  'نلتَه في ${_date(at)}',
                  style: ctx.ts(size: 12.5, w: FontWeight.w700, color: c),
                )
              else ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: LinearProgressIndicator(
                    value: frac,
                    minHeight: 8,
                    color: p.accent,
                    backgroundColor: tint(p.border, 0.8),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '$value / ${d.target} ${d.unit}',
                  style: ctx.ts(size: 12.5, w: FontWeight.w700, color: p.textDim),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _StampCell extends StatelessWidget {
  const _StampCell({
    required this.def,
    required this.value,
    required this.unlockedAt,
    required this.onTap,
  });

  final StampDef def;
  final int value;
  final int? unlockedAt;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final got = unlockedAt != null;
    final frac = (value / def.target).clamp(0.0, 1.0).toDouble();
    return Pressable(
      onTap: onTap,
      scale: 0.94,
      child: Column(
        children: [
          StampSeal(def: def, unlocked: got, size: 80, progress: frac),
          const SizedBox(height: 8),
          Text(
            def.title,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: context.ts(
              size: 12,
              w: FontWeight.w700,
              color: got ? p.text : p.textDim,
              height: 1.3,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            got ? def.tier.label : '${value.clamp(0, def.target)}/${def.target}',
            style: context.ts(
              size: 10.5,
              w: FontWeight.w700,
              color: got ? def.tier.color : tint(p.textDim, 0.8),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.owned, required this.total, required this.unlocked});
  final int owned;
  final int total;
  final Map<String, int> unlocked;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    int count(StampTier t) =>
        kStamps.where((d) => d.tier == t && unlocked.containsKey(d.id)).length;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(p.r(1.4).clamp(16.0, 32.0).toDouble()),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [tint(p.accent, 0.3), tint(p.surface, 0.95)],
        ),
        border: Border.all(color: tint(p.gold, 0.5)),
        boxShadow: [BoxShadow(color: tint(p.accent, 0.22), blurRadius: 24, offset: const Offset(0, 10))],
      ),
      child: Row(
        children: [
          SizedBox(
            width: 82,
            height: 82,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 82,
                  height: 82,
                  child: CircularProgressIndicator(
                    value: total == 0 ? 0 : owned / total,
                    strokeWidth: 6,
                    strokeCap: StrokeCap.round,
                    backgroundColor: tint(p.border, 0.8),
                    color: p.gold,
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('$owned', style: context.ds(size: 26, height: 1)),
                    Text('من $total', style: context.ts(size: 10.5, color: p.textDim)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('مجموعة أختامك', style: context.ds(size: 17)),
                const SizedBox(height: 4),
                Text(
                  owned == total ? 'اكتملت المجموعة. أنت أسطورة!' : 'كل فصل تقرؤه ينقلك لختم جديد.',
                  style: context.ts(size: 11.5, color: p.textDim, height: 1.5),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final t in StampTier.values)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                        decoration: BoxDecoration(
                          color: tint(t.color, 0.15),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          '${t.label} ${count(t)}',
                          style: context.ts(size: 10.5, w: FontWeight.w800, color: t.color),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// بطاقة الشعلة: أيام متتالية + آخر 7 أيام.
class _StreakCard extends StatelessWidget {
  const _StreakCard({required this.settings});
  final SettingsController settings;

  static const _days = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح']; // الاثنين..الأحد

  static String _daysLabel(int n) {
    if (n == 1) return 'يوم واحد';
    if (n == 2) return 'يومان';
    if (n <= 10) return '$n أيام';
    return '$n يوماً';
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final streak = settings.streak;
    final today = DateTime.now();
    final week = [for (var i = 6; i >= 0; i--) DateTime(today.year, today.month, today.day - i)];
    const flame = Color(0xFFFF8A3D);
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      decoration: BoxDecoration(
        color: p.glass ? tint(p.surface, 0.78) : p.surface,
        borderRadius: BorderRadius.circular(p.r(1.2).clamp(14.0, 28.0).toDouble()),
        border: Border.all(color: tint(p.border, 0.65), width: p.borderW),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: tint(flame, streak > 0 ? 0.2 : 0.08),
                  boxShadow: streak > 0 ? [BoxShadow(color: tint(flame, 0.4), blurRadius: 16)] : null,
                ),
                child: SIcon(
                  SardIcons.local_fire_department_rounded,
                  size: 26,
                  color: streak > 0 ? flame : p.textDim,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      streak == 0 ? 'ابدأ شعلتك اليوم' : '${_daysLabel(streak)} متتالية',
                      style: context.ds(size: 16),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'أطول سلسلة لك: ${_daysLabel(settings.bestStreak)}',
                      style: context.ts(size: 11.5, color: p.textDim),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (final d in week)
                Column(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: settings.readOnDay(d) ? flame : p.surfaceHi,
                        border: Border.all(
                          color: (d.day == today.day && d.month == today.month)
                              ? p.accent
                              : Colors.transparent,
                          width: 1.6,
                        ),
                      ),
                      child: settings.readOnDay(d)
                          ? const SIcon(SardIcons.check_rounded, size: 18, color: Colors.white, animate: false)
                          : null,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      _days[d.weekday - 1],
                      style: context.ts(size: 10.5, w: FontWeight.w700, color: p.textDim),
                    ),
                  ],
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// معاينة مصغّرة للأختام تُوضع في الملف الشخصي.
class StampsPreview extends StatelessWidget {
  const StampsPreview({super.key, required this.settings, required this.onOpen});
  final SettingsController settings;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final unlocked = settings.unlockedStamps;
    final latest = unlocked.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final defs = latest.map((e) => stampById(e.key)).whereType<StampDef>().take(5).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('أختامي', style: context.ds(size: 18)),
            const SizedBox(width: 8),
            Text(
              '${unlocked.length} / ${kStamps.length}',
              style: context.ts(size: 12, w: FontWeight.w700, color: p.textDim),
            ),
            const Spacer(),
            Pressable(
              onTap: onOpen,
              child: Container(
                padding: const EdgeInsetsDirectional.fromSTEB(12, 6, 6, 6),
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(99),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('عرض الكل', style: context.ts(size: 12, w: FontWeight.w700, color: p.accent)),
                    SIcon(SardIcons.chevron_left_rounded, size: 17, color: p.accent),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (defs.isEmpty)
          Pressable(
            onTap: onOpen,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: p.border),
              ),
              child: Text(
                'لم تنل ختماً بعد. أنهِ فصلاً واحداً لتحصل على «الختم الأول».',
                style: context.ts(size: 12.5, color: p.textDim, height: 1.6),
              ),
            ),
          )
        else
          SizedBox(
            height: 112,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: defs.length,
              separatorBuilder: (context, i) => const SizedBox(width: 12),
              itemBuilder: (context, i) => Pressable(
                onTap: onOpen,
                child: SizedBox(
                  width: 84,
                  child: Column(
                    children: [
                      StampSeal(def: defs[i], unlocked: true, size: 72),
                      const SizedBox(height: 6),
                      Text(
                        defs[i].title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.ts(size: 11, w: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
