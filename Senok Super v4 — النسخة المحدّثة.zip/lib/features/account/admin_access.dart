import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../../core/config/app_config.dart';
import 'local_admin_server.dart';

class AdminLoginException implements Exception {
  AdminLoginException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// يتحقق من بيانات الأدمن على الخادم ثم يفتح لوحة الأدمن في المتصفح وهو مسجَّل دخوله.
/// يُستدعى من شاشة تسجيل الدخول العادية عندما يكتب المستخدم اسم الأدمن بدل البريد.
Future<void> openAdminPanel(String username, String password) async {
  if (AppConfig.useMock) {
    if (username != 'admin' || password != 'admin123') {
      throw AdminLoginException('الوضع التجريبي: المستخدم admin وكلمة المرور admin123');
    }
    String url;
    try {
      url = await LocalAdminServer.start();
    } catch (_) {
      throw AdminLoginException('تعذّر تشغيل لوحة الأدمن المحلية.');
    }
    final opened = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!opened) throw AdminLoginException('تعذّر فتح المتصفح.');
    return;
  }
  try {
    final r = await http
        .post(
          Uri.parse('${AppConfig.apiBaseUrl}/admin/login'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'username': username, 'password': password}),
        )
        .timeout(const Duration(seconds: 15));
    final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    if (r.statusCode != 200) throw AdminLoginException((j['error'] ?? 'تعذّر الدخول').toString());
    final ok = await launchUrl(
      Uri.parse('${AppConfig.apiBaseUrl}/admin#tk=${j['token']}'),
      mode: LaunchMode.externalApplication,
    );
    if (!ok) throw AdminLoginException('تعذّر فتح المتصفح.');
  } on AdminLoginException {
    rethrow;
  } catch (_) {
    throw AdminLoginException('تعذّر الاتصال بالخادم. تأكد أنه يعمل وأن الرابط صحيح.');
  }
}
