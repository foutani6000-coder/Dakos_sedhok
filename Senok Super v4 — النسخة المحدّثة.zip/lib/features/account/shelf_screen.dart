import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/fx.dart';
import '../../widgets/pills.dart';
import '../../widgets/routes.dart';
import '../details/details_screen.dart';
import '../../widgets/sard_icons.dart';

/// أنواع الرفوف الثلاثة
enum ShelfKind { favorites, reading, later }

class _Meta {
  const _Meta(this.title, this.icon, this.color, this.emptyTitle, this.emptyHint);
  final String title;
  final SIconData icon;
  final Color color;
  final String emptyTitle;
  final String emptyHint;
}

/// لكل رف لونه الخاص
const Map<ShelfKind, _Meta> _metas = {
  ShelfKind.favorites: _Meta(
    'المفضلة',
    SardIcons.favorite_rounded,
    Color(0xFFE0457B),
    'لا توجد أعمال مفضلة',
    'اضغط على القلب في صفحة أي عمل لإضافته هنا',
  ),
  ShelfKind.reading: _Meta(
    'أقرؤها حالياً',
    SardIcons.auto_stories_rounded,
    Color(0xFF3B9EFF),
    'لا توجد أعمال قيد القراءة',
    'ابدأ بقراءة أي فصل وسيظهر العمل هنا مع تقدّمك',
  ),
  ShelfKind.later: _Meta(
    'القراءة لاحقاً',
    SardIcons.watch_later_rounded,
    Color(0xFFF5A524),
    'قائمة القراءة لاحقاً فارغة',
    'اضغط «لاحقاً» في صفحة العمل لحفظه لوقت آخر',
  ),
};

/// الرفوف: ثلاث تبويبات ملوّنة (المفضلة / أقرؤها حالياً / القراءة لاحقاً)
/// مع تنقّل بالسحب بين التبويبات.
class ShelfScreen extends StatefulWidget {
  const ShelfScreen({super.key, this.initial = ShelfKind.favorites});
  final ShelfKind initial;

  @override
  State<ShelfScreen> createState() => _ShelfScreenState();
}

class _ShelfScreenState extends State<ShelfScreen> {
  late final PageController _pc;
  late int _index;

  @override
  void initState() {
    super.initState();
    _index = widget.initial.index;
    _pc = PageController(initialPage: _index);
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  static List<Series> itemsOf(SettingsController st, ShelfKind kind) {
    final ids = switch (kind) {
      ShelfKind.favorites => st.favoriteIds,
      ShelfKind.reading => st.readingIds,
      ShelfKind.later => st.laterIds,
    };
    final out = <Series>[];
    for (final id in ids) {
      final s = st.cachedSeries(id);
      if (s != null) out.add(s);
    }
    return out;
  }

  void _go(int i) {
    setState(() => _index = i);
    _pc.animateToPage(i, duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final st = context.watch<SettingsController>();
    final kinds = ShelfKind.values;
    final active = _metas[kinds[_index]]!.color;
    return Scaffold(
      backgroundColor: p.bg,
      body: Stack(
        children: [
          // توهّج لوني خلف الصفحة يتبدّل مع التبويب
          Positioned(
            top: -120,
            left: 0,
            right: 0,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              height: 320,
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  radius: 0.9,
                  colors: [tint(active, 0.28), tint(active, 0)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                  child: Row(
                    children: [
                      RoundIconButton(
                        icon: SardIcons.arrow_back_rounded,
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      const SizedBox(width: 14),
                      Text('رفّي', style: context.ds(size: 28)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _tabs(context, st),
                const SizedBox(height: 8),
                Expanded(
                  child: PageView(
                    controller: _pc,
                    onPageChanged: (i) => setState(() => _index = i),
                    physics: const BouncingScrollPhysics(),
                    children: [
                      for (final k in kinds) _ShelfList(kind: k, items: itemsOf(st, k)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabs(BuildContext context, SettingsController st) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          for (final k in ShelfKind.values)
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(left: k == ShelfKind.later ? 0 : 8),
                child: _tab(context, k, itemsOf(st, k).length, _index == k.index, p),
              ),
            ),
        ],
      ),
    );
  }

  Widget _tab(BuildContext context, ShelfKind k, int count, bool sel, SardPalette p) {
    final m = _metas[k]!;
    return Pressable(
      onTap: () => _go(k.index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
        decoration: BoxDecoration(
          color: sel ? tint(m.color, 0.2) : p.surface,
          borderRadius: BorderRadius.circular(p.r(0.85)),
          border: Border.all(color: sel ? m.color : p.border, width: sel ? 1.6 : p.borderW),
          boxShadow: sel && p.glow > 0
              ? [BoxShadow(color: tint(m.color, 0.35 * p.glow), blurRadius: 14)]
              : null,
        ),
        child: Column(
          children: [
            SIcon(m.icon, size: 22, color: sel ? m.color : p.textDim),
            const SizedBox(height: 6),
            Text(
              m.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.ts(size: 11.5, w: FontWeight.w700, color: sel ? p.text : p.textDim),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
              decoration: BoxDecoration(
                color: sel ? m.color : p.surfaceHi,
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(
                '$count',
                style: context.ts(
                  size: 11,
                  w: FontWeight.w800,
                  color: sel ? Colors.white : p.textDim,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ShelfList extends StatelessWidget {
  const _ShelfList({required this.kind, required this.items});
  final ShelfKind kind;
  final List<Series> items;

  @override
  Widget build(BuildContext context) {
    final m = _metas[kind]!;
    final p = context.pal;
    if (items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 92,
                height: 92,
                decoration: BoxDecoration(
                  color: tint(m.color, 0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: tint(m.color, 0.5)),
                ),
                child: SIcon(m.icon, size: 40, color: m.color),
              ),
              const SizedBox(height: 18),
              Text(m.emptyTitle, style: context.ds(size: 20)),
              const SizedBox(height: 8),
              Text(
                m.emptyHint,
                textAlign: TextAlign.center,
                style: context.ts(size: 13, color: p.textDim, height: 1.6),
              ),
            ],
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
      itemCount: items.length,
      itemBuilder: (context, i) => FadeSlide(
        index: i < 6 ? i : 6,
        dy: 12,
        child: _ShelfCard(kind: kind, series: items[i]),
      ),
    );
  }
}

class _ShelfCard extends StatelessWidget {
  const _ShelfCard({required this.kind, required this.series});
  final ShelfKind kind;
  final Series series;

  void _remove(BuildContext context) {
    final st = context.read<SettingsController>();
    switch (kind) {
      case ShelfKind.favorites:
        st.setFavorite(series, false);
      case ShelfKind.later:
        st.setReadLater(series, false);
      case ShelfKind.reading:
        st.removeProgress(series.id);
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('أُزيل «${series.title}» من الرف')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final m = _metas[kind]!;
    final st = context.watch<SettingsController>();
    final pr = kind == ShelfKind.reading ? st.progressOf(series.id) : null;
    final radius = p.r(1.1).clamp(10.0, 30.0).toDouble();
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Pressable(
        scale: 0.98,
        onTap: () => Navigator.push(
          context,
          sardRoute(DetailsScreen(series: series, heroTag: 'shelf-${kind.name}-${series.id}')),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: p.glass ? tint(p.surface, 0.7) : p.surface,
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: tint(m.color, 0.35), width: p.borderW),
          ),
          clipBehavior: Clip.antiAlias,
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // شريط لوني جانبي بلون الرف
                Container(width: 5, color: m.color),
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: SizedBox(
                    width: 64,
                    height: 92,
                    child: Hero(
                      tag: 'shelf-${kind.name}-${series.id}',
                      child: CoverArt(series: series, radius: radius * 0.5),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          series.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: context.ts(size: 15, w: FontWeight.w700),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          series.genres.isEmpty ? series.type : series.genres.take(2).join(' · '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: context.ts(size: 12, color: p.textDim),
                        ),
                        const SizedBox(height: 10),
                        if (pr != null) ...[
                          Text(
                            'الفصل ${pr.chapter} · صفحة ${pr.page}/${pr.total}',
                            style: context.ts(size: 11.5, w: FontWeight.w600, color: m.color),
                          ),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(99),
                            child: LinearProgressIndicator(
                              value: pr.fraction,
                              minHeight: 6,
                              color: m.color,
                              backgroundColor: tint(m.color, 0.18),
                            ),
                          ),
                        ] else
                          Row(
                            children: [
                              SIcon(SardIcons.menu_book_rounded, size: 14, color: p.textDim),
                              const SizedBox(width: 4),
                              Text('${series.chapters} فصل',
                                  style: context.ts(size: 11.5, w: FontWeight.w500, color: p.textDim)),
                              const SizedBox(width: 12),
                              SIcon(SardIcons.visibility_rounded, size: 14, color: p.textDim),
                              const SizedBox(width: 4),
                              Text(formatCount(series.views),
                                  style: context.ts(size: 11.5, w: FontWeight.w500, color: p.textDim)),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'إزالة',
                  onPressed: () => _remove(context),
                  icon: SIcon(SardIcons.close_rounded, color: p.textDim, size: 20),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
