import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/stamps/stamps.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';

/// لقطة من حصيلة القارئ تُعرض في بطاقة «سنتي في القراءة».
class YearSummary {
  const YearSummary({
    required this.year,
    required this.chapters,
    required this.minutes,
    required this.daysThisYear,
    required this.bestStreak,
    required this.started,
    required this.bestDayChapters,
    required this.stamps,
    required this.stampsTotal,
    this.topGenre,
    this.topTitle,
  });

  final int year;
  final int chapters;
  final int minutes;
  final int daysThisYear;
  final int bestStreak;
  final int started;
  final int bestDayChapters;
  final int stamps;
  final int stampsTotal;
  final String? topGenre;
  final String? topTitle;

  factory YearSummary.of(SettingsController s, {int? year}) {
    final y = year ?? DateTime.now().year;
    final st = s.stampStats;
    String? title;
    for (final id in s.topReadIds) {
      if (s.readingSecondsOf(id) > 0 || s.readChapters(id).isNotEmpty) {
        title = s.cachedSeries(id)?.title;
        break;
      }
    }
    return YearSummary(
      year: y,
      chapters: st.chapters,
      minutes: st.minutes,
      daysThisYear: s.readDaysInYear(y),
      bestStreak: st.streak,
      started: st.started,
      bestDayChapters: st.bestDayChapters,
      stamps: s.unlockedStamps.length,
      stampsTotal: kStamps.length,
      topGenre: s.topGenre,
      topTitle: title,
    );
  }

  bool get isEmpty => chapters == 0 && minutes == 0;

  /// لقب بسيط حسب عدد الفصول
  String get level {
    if (chapters >= 500) return 'خازن الحكايات';
    if (chapters >= 200) return 'قارئ نهِم';
    if (chapters >= 50) return 'قارئ نشِط';
    if (chapters >= 10) return 'قارئ منتظم';
    return 'في أول الطريق';
  }

  String get hoursLabel => readingHoursLabel(minutes * 60);

  /// نص قابل للنسخ والمشاركة
  String toShareText() {
    final b = StringBuffer()
      ..writeln('سنتي في القراءة على «Senok» $year')
      ..writeln('اللقب: $level')
      ..writeln('• $chapters فصل مقروء')
      ..writeln('• $hoursLabel ساعة داخل القارئ')
      ..writeln('• $daysThisYear يوم قراءة هذه السنة')
      ..writeln('• أطول سلسلة: $bestStreak يوم')
      ..writeln('• $started عمل بدأته')
      ..writeln('• $stamps من $stampsTotal ختماً');
    if (topGenre != null) b.writeln('• نوعي المفضل: $topGenre');
    if (topTitle != null) b.writeln('• أكثر عمل قضيت وقتي فيه: $topTitle');
    return b.toString().trim();
  }
}

/// «سنتي في القراءة»: بطاقة إحصاءات جميلة يمكن نسخ ملخصها ومشاركته.
class YearCardScreen extends StatelessWidget {
  const YearCardScreen({super.key});

  Future<void> _copy(BuildContext context, YearSummary d) async {
    await Clipboard.setData(ClipboardData(text: d.toShareText()));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم نسخ الملخص. الصقه حيث تشاء')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final settings = context.watch<SettingsController>();
    final d = YearSummary.of(settings);
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: const Text('سنتي في القراءة')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 36),
        children: [
          FadeSlide(child: _YearCard(data: d)),
          const SizedBox(height: 16),
          FadeSlide(
            index: 1,
            child: FilledButton.icon(
              onPressed: () => _copy(context, d),
              icon: SIcon(SardIcons.share_rounded, size: 18, color: p.onAccent),
              label: const Text('نسخ الملخص ومشاركته'),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'الفصول والساعات تراكمية منذ بدايتك على Senok، وأيام القراءة تخص هذه السنة.',
            textAlign: TextAlign.center,
            style: context.ts(size: 11.5, color: p.textDim, height: 1.6),
          ),
        ],
      ),
    );
  }
}

class _YearCard extends StatelessWidget {
  const _YearCard({required this.data});
  final YearSummary data;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final d = data;
    const blue = Color(0xFF3B9EFF);
    const amber = Color(0xFFF5A524);
    const flame = Color(0xFFFF8A3D);
    const green = Color(0xFF2FCB7A);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(p.r(1.4).clamp(18.0, 32.0).toDouble()),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [tint(p.accent, 0.34), tint(p.surface, 0.96)],
        ),
        border: Border.all(color: tint(p.gold, 0.5)),
        boxShadow: [BoxShadow(color: tint(p.accent, 0.22), blurRadius: 26, offset: const Offset(0, 12))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('Senok', style: context.ts(size: 13, w: FontWeight.w800, color: p.gold)),
              const Spacer(),
              Text('${d.year}', style: context.ds(size: 30, height: 1)),
            ],
          ),
          const SizedBox(height: 10),
          Text('سنتي في القراءة', style: context.ds(size: 24)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: tint(p.gold, 0.18),
              borderRadius: BorderRadius.circular(99),
              border: Border.all(color: tint(p.gold, 0.55)),
            ),
            child: Text(d.level, style: context.ts(size: 12, w: FontWeight.w800, color: p.gold)),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: _Tile(value: '${d.chapters}', label: 'فصل مقروء', icon: SardIcons.menu_book_rounded, color: blue)),
              const SizedBox(width: 10),
              Expanded(child: _Tile(value: d.hoursLabel, label: 'ساعة قراءة', icon: SardIcons.history_rounded, color: amber)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _Tile(value: '${d.daysThisYear}', label: 'يوم قراءة', icon: SardIcons.calendar_today_rounded, color: green)),
              const SizedBox(width: 10),
              Expanded(child: _Tile(value: '${d.bestStreak}', label: 'أطول سلسلة', icon: SardIcons.local_fire_department_rounded, color: flame)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _Tile(value: '${d.started}', label: 'عمل بدأته', icon: SardIcons.explore_rounded, color: blue)),
              const SizedBox(width: 10),
              Expanded(child: _Tile(value: '${d.stamps}/${d.stampsTotal}', label: 'ختماً', icon: SardIcons.auto_awesome_rounded, color: p.gold)),
            ],
          ),
          if (d.topGenre != null) ...[
            const SizedBox(height: 16),
            _Line(label: 'نوعك المفضل', value: d.topGenre!),
          ],
          if (d.topTitle != null) ...[
            const SizedBox(height: 8),
            _Line(label: 'أكثر عمل قضيت وقتك فيه', value: d.topTitle!),
          ],
          if (d.isEmpty) ...[
            const SizedBox(height: 16),
            Text(
              'ابدأ بقراءة فصل واحد لتمتلئ بطاقتك.',
              style: context.ts(size: 12.5, color: p.textDim, height: 1.6),
            ),
          ],
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.value, required this.label, required this.icon, required this.color});
  final String value;
  final String label;
  final SIconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: tint(p.surface, 0.7),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: tint(color, 0.35)),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(shape: BoxShape.circle, color: tint(color, 0.16)),
            child: SIcon(icon, size: 18, color: color, animate: false),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.ds(size: 19, height: 1.1)),
                const SizedBox(height: 2),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: context.ts(size: 10.5, color: p.textDim),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Line extends StatelessWidget {
  const _Line({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      children: [
        Text('$label:', style: context.ts(size: 12, color: p.textDim)),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: context.ts(size: 13, w: FontWeight.w800),
          ),
        ),
      ],
    );
  }
}
