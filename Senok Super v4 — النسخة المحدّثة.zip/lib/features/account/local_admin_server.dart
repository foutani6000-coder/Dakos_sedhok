import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;

/// يقدّم لوحة الأدمن التجريبية (assets/admin_demo.html) على عنوان محلي داخل الهاتف
/// فقط، لتُفتح في المتصفح دون أي خادم خارجي. بيانات اللوحة تُحفظ في المتصفح.
class LocalAdminServer {
  LocalAdminServer._();

  static HttpServer? _server;
  static List<int>? _bytes;

  static Future<String> start() async {
    _bytes ??= utf8.encode(await rootBundle.loadString('assets/admin_demo.html'));
    if (_server == null) {
      HttpServer s;
      try {
        s = await HttpServer.bind(InternetAddress.loopbackIPv4, 8787);
      } catch (_) {
        s = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      }
      _server = s;
      s.listen((HttpRequest req) {
        req.response
          ..statusCode = HttpStatus.ok
          ..headers.set(HttpHeaders.contentTypeHeader, 'text/html; charset=utf-8')
          ..add(_bytes!);
        req.response.close();
      });
    }
    return 'http://127.0.0.1:${_server!.port}/admin';
  }
}
