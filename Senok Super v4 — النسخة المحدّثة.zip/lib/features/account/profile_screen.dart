import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data/account_repository.dart';
import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/storage/auth_store.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/routes.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/verified_badge.dart';
import '../details/details_screen.dart';
import 'stamps_screen.dart';
import 'year_card_screen.dart';
import 'user_profile_screen.dart';

/// ملفي الشخصي: تعديل الاسم والصورة والنبذة + إحصاءات القراءة (فصول وساعات) + توصياتي.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late Future<Map<String, dynamic>> _future;
  bool _logged = false;

  AccountRepository get _repo => AccountRepository(context.read<SardRepository>().api);

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final token = await AuthStore.token();
    _logged = token != null && token.isNotEmpty && token != 'local-profile';
    if (!_logged) return _repo.profile;
    try {
      return await _repo.fetchProfile();
    } catch (_) {
      return _repo.profile;
    }
  }

  Future<void> _edit(Map<String, dynamic> current) async {
    final settings = context.read<SettingsController>();
    final name = TextEditingController(text: '${current['name'] ?? ''}');
    final avatar = TextEditingController(text: '${current['avatar_url'] ?? current['image'] ?? ''}');
    final bio = TextEditingController(text: '${current['bio'] ?? settings.profileBio}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('تعديل الملف الشخصي'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
            const SizedBox(height: 8),
            TextField(controller: avatar, decoration: const InputDecoration(labelText: 'رابط الصورة (اختياري)')),
            const SizedBox(height: 8),
            TextField(controller: bio, minLines: 2, maxLines: 4, maxLength: 160, decoration: const InputDecoration(labelText: 'نبذة عنك')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final n = name.text.trim();
    final a = avatar.text.trim();
    final b = bio.text.trim();
    String? warn;
    if (_logged) {
      try {
        await _repo.updateProfile(n, a, bio: b);
      } catch (e) {
        warn = 'حُفظ على جهازك فقط، تعذّرت المزامنة: $e';
      }
    }
    await _repo.saveProfileLocally(n, a, bio: b);
    settings.setProfileBio(b);
    if (!mounted) return;
    setState(() => _future = _load());
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(warn ?? 'تم حفظ ملفك الشخصي')));
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final settings = context.watch<SettingsController>();
    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final u = snap.data ?? {};
          final name = '${u['name'] ?? u['username'] ?? 'قارئ Senok'}';
          final avatar = '${u['avatar_url'] ?? u['image'] ?? ''}';
          final bio = '${u['bio'] ?? ''}'.isNotEmpty ? '${u['bio']}' : settings.profileBio;
          final badge = SardBadge.fromJson(u['badge'] ?? u['verified']);
          final top = settings.topReadIds.where((id) => settings.readingSecondsOf(id) > 0 || settings.readChapters(id).isNotEmpty).take(5).toList();
          final recs = settings.recommendedIds.map(settings.cachedSeries).whereType<Series>().toList();

          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(color: badge.isNone ? p.border : tint(badgeColor(badge), 0.5)),
                ),
                child: Column(children: [
                  RingAvatar(
                    name: name,
                    badge: badge,
                    size: 92,
                    image: avatar.startsWith('http') ? CachedNetworkImageProvider(avatar, maxWidth: 240, maxHeight: 240) : null,
                  ),
                  const SizedBox(height: 12),
                  NameWithBadge(name, badge, center: true, badgeSize: 20, style: context.ts(size: 21, w: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(_logged ? 'حساب متصل' : 'ملف محلي', style: context.ts(size: 12, color: p.textDim)),
                  if (!badge.isNone) ...[const SizedBox(height: 8), BadgeChip(badge)],
                  if (bio.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(bio, textAlign: TextAlign.center, style: context.ts(size: 13, color: p.textDim, height: 1.7)),
                  ],
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: () => _edit(u),
                    icon: const SIcon(SardIcons.edit_rounded),
                    label: const Text('تعديل الملف الشخصي'),
                  ),
                  TextButton(
                    onPressed: () => showBadgeInfo(context, current: badge),
                    child: const Text('ما معنى ألوان التوثيق؟'),
                  ),
                ]),
              ),
              const SizedBox(height: 18),
              Text('إحصاءات القراءة', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: ProfileStatTile(label: 'فصل شاهدته', value: '${settings.totalChaptersRead}', icon: SardIcons.menu_book_rounded, tone: const Color(0xFF3B9EFF))),
                const SizedBox(width: 10),
                Expanded(child: ProfileStatTile(label: 'ساعة قراءة', value: readingHoursLabel(settings.totalReadingSeconds), icon: SardIcons.history_rounded, tone: const Color(0xFFF5A524))),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: ProfileStatTile(label: 'أعمال متابَعة', value: '${settings.followedSeries.length}', icon: SardIcons.bookmark_rounded, tone: const Color(0xFF9B5CFF))),
                const SizedBox(width: 10),
                Expanded(child: ProfileStatTile(label: 'أعمال بدأتها', value: '${settings.exportProgress().length}', icon: SardIcons.auto_stories_rounded, tone: const Color(0xFF2FCB7A))),
              ]),
              const SizedBox(height: 6),
              Text('الإجمالي: ${formatReadingTime(settings.totalReadingSeconds)} داخل القارئ', style: context.ts(size: 11.5, color: p.textDim)),
              const SizedBox(height: 22),
              StampsPreview(
                settings: settings,
                onOpen: () => Navigator.push(context, sardRoute(const StampsScreen())),
              ),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: () => Navigator.push(context, sardRoute(const YearCardScreen())),
                icon: const SIcon(SardIcons.calendar_today_rounded, size: 18),
                label: const Text('سنتي في القراءة'),
              ),
              if (top.isNotEmpty) ...[
                const SizedBox(height: 22),
                Text('أكثر ما قضيت وقتك فيه', style: context.ds(size: 18)),
                const SizedBox(height: 10),
                for (final id in top)
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: p.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.border)),
                    child: Row(children: [
                      Expanded(
                        child: Text(settings.cachedSeries(id)?.title ?? 'عمل #$id', maxLines: 1, overflow: TextOverflow.ellipsis, style: context.ts(size: 13.5, w: FontWeight.w700)),
                      ),
                      Text('${settings.readChapters(id).length} فصل · ${formatReadingTime(settings.readingSecondsOf(id))}', style: context.ts(size: 11.5, color: p.textDim)),
                    ]),
                  ),
              ],
              const SizedBox(height: 22),
              Text('توصياتي للمانهوات', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              if (recs.isEmpty)
                Text('لم توصِ بأي عمل بعد. افتح صفحة أي عمل واضغط «أوصي به» ليظهر هنا في ملفك للجميع.', style: context.ts(size: 12.5, color: p.textDim, height: 1.7))
              else
                SizedBox(
                  height: 240,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: recs.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (c, i) => PosterCard(
                      series: recs[i],
                      width: 130,
                      onTap: () => Navigator.push(c, sardRoute(DetailsScreen(series: recs[i]))),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
