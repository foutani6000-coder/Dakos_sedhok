import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import '../../core/data/account_repository.dart';
import '../../core/data/repository.dart';
import '../../core/storage/auth_store.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/routes.dart';
import '../details/details_screen.dart';
import 'auth_screen.dart';
import '../../widgets/sard_icons.dart';

class LibraryScreen extends StatefulWidget { const LibraryScreen({super.key}); @override State<LibraryScreen> createState()=>_LibraryScreenState(); }
class _LibraryScreenState extends State<LibraryScreen> {
  late Future<Map<String,dynamic>> _future;
  AccountRepository get _repo=>AccountRepository(context.read<SardRepository>().api);
  Future<Map<String,dynamic>> _load() async { final t=await AuthStore.token(); if(t==null)return <String,dynamic>{}; return _repo.library(); }
  @override void initState(){super.initState();_future=_load();}
  Future<void> _refresh() async { setState(()=>_future=_load()); }
  @override Widget build(BuildContext context){final p=context.pal; final settings=context.watch<SettingsController>();
    return Scaffold(appBar:AppBar(title:const Text('مكتبتي'),actions:[IconButton(onPressed:_refresh,icon:const SIcon(SardIcons.refresh_rounded))]),body:FutureBuilder<Map<String,dynamic>>(future:_future,builder:(context,s){
      if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
      final logged=AuthStore.token();
      return FutureBuilder<String?>(future:logged,builder:(context,auth){if(auth.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
        final data=LibraryData.fromJson(s.data??{}); final followed=data.followed;
        return ListView(padding:const EdgeInsets.fromLTRB(18,8,18,30),children:[
          Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:p.surface,borderRadius:BorderRadius.circular(24),border:Border.all(color:p.border)),child:Row(children:[Container(width:52,height:52,decoration:BoxDecoration(color:p.surfaceHi,borderRadius:BorderRadius.circular(18)),child:SIcon(auth.data==null?SardIcons.person_outline:SardIcons.verified_user_outlined,color:p.accent)),const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(auth.data==null?'مكتبتك معك دائماً':'الحساب متصل',style:context.ts(size:16,w:FontWeight.w700)),Text(auth.data==null?'سجّل الدخول لمزامنة أعمالك':'مزامنة المكتبة وسجل القراءة',style:context.ts(size:12,color:p.textDim))])),if(auth.data==null)TextButton(onPressed:()async{await Navigator.push(context,sardRoute(const AuthScreen()));if(mounted)_refresh();},child:const Text('دخول'))else IconButton(onPressed:()async{await _repo.signOut();if(mounted)_refresh();},icon:const SIcon(SardIcons.logout_rounded))]),),
          const SizedBox(height:22),_heading(context,'الأعمال المتابَعة',SardIcons.bookmark_rounded,'${followed.length}'),
          if(followed.isEmpty) _empty(context,'لا توجد أعمال متابَعة على الحساب حالياً') else ...followed.map((e)=>Padding(padding:const EdgeInsets.only(bottom:10),child:SeriesTile(series:e,onTap:()=>Navigator.push(context,sardRoute(DetailsScreen(series:e)))))),
          const SizedBox(height:16),_heading(context,'قوائم القراءة',SardIcons.collections_bookmark_rounded,'${data.lists.length}'),
          Row(children:[Expanded(child:Text('أنشئ قوائم خاصة أو عامة لتنظيم أعمالك',style:context.ts(size:12,color:p.textDim))),IconButton(onPressed:auth.data==null?null:()=>_newList(context),icon:const SIcon(SardIcons.add_circle_outline))]),
          if(data.lists.isEmpty)_empty(context,auth.data==null?'سجّل الدخول لإنشاء قوائم ومزامنتها':'لا توجد قوائم بعد') else ...data.lists.map((l)=>ListTile(leading:const SIcon(SardIcons.folder_copy_outlined),title:Text('${l['name']??'قائمة'}'),subtitle:Text(l['is_public']==true?'عامة':'خاصة'),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),tileColor:p.surface)),
          const SizedBox(height:16),_heading(context,'سجل القراءة',SardIcons.history_rounded,'${data.history.length}'),
          if(data.history.isEmpty)_empty(context,'سيظهر سجل القراءة هنا بعد مزامنته مع حسابك') else ...data.history.map((h)=>ListTile(leading:const SIcon(SardIcons.menu_book_rounded),title:Text('${h['title']??'عمل'}'),subtitle:Text('الفصل ${h['chapter']??'—'} · الصفحة ${h['page']??'—'}'))),
          const SizedBox(height:12),if(auth.data!=null)OutlinedButton.icon(onPressed:()async{try{await _repo.syncLibrary(settings);if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تمت مزامنة التقدم والمفضلة')));_refresh();}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}},icon:const SIcon(SardIcons.sync_rounded),label:const Text('مزامنة مكتبتي')),
        ]);
      });
    }));
  }
  Widget _heading(BuildContext c,String title,SIconData icon,String count){return Padding(padding:const EdgeInsets.only(bottom:9),child:Row(children:[SIcon(icon,size:19),const SizedBox(width:8),Text(title,style:c.ts(size:17,w:FontWeight.w800)),const Spacer(),Text(count,style:c.ts(size:12,color:c.pal.textDim))]));}
  Widget _empty(BuildContext c,String t){return Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:c.pal.surface,borderRadius:BorderRadius.circular(18)),child:Text(t,textAlign:TextAlign.center,style:c.ts(size:12,color:c.pal.textDim)));}
  Future<void> _newList(BuildContext c)async{
    final ctrl=TextEditingController(); bool isPublic=false;
    final ok=await showDialog<bool>(context:c,builder:(d)=>StatefulBuilder(builder:(d,setDialog)=>AlertDialog(
      title:const Text('قائمة جديدة'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:ctrl,decoration:const InputDecoration(hintText:'اسم القائمة')),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('قائمة عامة'),subtitle:const Text('يمكن للآخرين الاطلاع عليها'),value:isPublic,onChanged:(v)=>setDialog(()=>isPublic=v)),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('إنشاء'))],
    )));
    if(ok==true&&ctrl.text.trim().isNotEmpty){try{await _repo.createList(ctrl.text.trim(),isPublic:isPublic);if(mounted)_refresh();}catch(e){if(mounted)ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(e.toString())));}}
    ctrl.dispose();
  }
}
