import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/social_repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/routes.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/states.dart';
import '../../widgets/verified_badge.dart';
import '../details/details_screen.dart';
import 'profile_screen.dart';

/// يفتح بروفايل مستخدم من أي مكان (منشور، تعليق، محادثة).
void openUserProfile(
  BuildContext context, {
  required String id,
  required String name,
  SardBadge badge = SardBadge.none,
}) {
  if (id.isEmpty) {
    // «أنت» = حسابي أنا
    if (name == 'أنت') Navigator.push(context, sardRoute(const ProfileScreen()));
    return;
  }
  Navigator.push(context, sardRoute(UserProfileScreen(userId: id, name: name, badge: badge)));
}

/// بطاقة رقم (فصول مقروءة، ساعات...)
class ProfileStatTile extends StatelessWidget {
  const ProfileStatTile({super.key, required this.label, required this.value, required this.icon, this.tone});
  final String label, value;
  final SIconData icon;
  final Color? tone;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = tone ?? p.accent;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(color: tint(c, 0.14), shape: BoxShape.circle),
            child: SIcon(icon, size: 20, color: c),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: context.ts(size: 17, w: FontWeight.w800)),
                Text(label, style: context.ts(size: 11, color: p.textDim)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// شارة صغيرة باسم نوع التوثيق
class BadgeChip extends StatelessWidget {
  const BadgeChip(this.badge, {super.key});
  final SardBadge badge;

  @override
  Widget build(BuildContext context) {
    if (badge.isNone) return const SizedBox.shrink();
    final c = badgeColor(badge);
    return GestureDetector(
      onTap: () => showBadgeInfo(context, current: badge),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: tint(c, 0.14),
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: tint(c, 0.5)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.verified_rounded, size: 14, color: c),
            const SizedBox(width: 4),
            Text(badge.label, style: context.ts(size: 11.5, w: FontWeight.w700, color: c)),
          ],
        ),
      ),
    );
  }
}

/// الملف الشخصي العام لأي قارئ: توثيقه، فصوله، ساعاته، توصياته ومنشوراته.
class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key, required this.userId, required this.name, this.badge = SardBadge.none});
  final String userId;
  final String name;
  final SardBadge badge;

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  late Future<SardUserProfile> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<SardRepository>().userProfile(widget.userId);
  }

  void _reload() => setState(() => _future = context.read<SardRepository>().userProfile(widget.userId));

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي')),
      body: FutureBuilder<SardUserProfile>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return ListView(children: [
              const SizedBox(height: 80),
              const EmptyState(title: 'تعذّر تحميل الملف الشخصي', subtitle: 'تأكد من الاتصال وأن المسار GET /users/{id} متوفر.'),
              Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
            ]);
          }
          final u = snap.data!;
          final name = u.name == 'قارئ' && widget.name.isNotEmpty ? widget.name : u.name;
          final badge = u.badge.isNone ? widget.badge : u.badge;
          final hasImg = u.avatarUrl.startsWith('http');
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(color: badge.isNone ? p.border : tint(badgeColor(badge), 0.5)),
                ),
                child: Column(
                  children: [
                    RingAvatar(
                      name: name,
                      badge: badge,
                      size: 92,
                      image: hasImg ? CachedNetworkImageProvider(u.avatarUrl, maxWidth: 240, maxHeight: 240) : null,
                    ),
                    const SizedBox(height: 12),
                    NameWithBadge(name, badge, center: true, badgeSize: 20, style: context.ts(size: 21, w: FontWeight.w800)),
                    if (!badge.isNone) ...[const SizedBox(height: 8), BadgeChip(badge)],
                    if (u.bio.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(u.bio, textAlign: TextAlign.center, style: context.ts(size: 13, color: p.textDim, height: 1.7)),
                    ],
                    if (u.joined.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text('عضو ${u.joined}', style: context.ts(size: 11.5, color: p.textDim)),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: ProfileStatTile(label: 'فصل قرأه', value: formatCount(u.chaptersRead), icon: SardIcons.menu_book_rounded, tone: const Color(0xFF3B9EFF))),
                const SizedBox(width: 10),
                Expanded(child: ProfileStatTile(label: 'ساعة قراءة', value: readingHoursLabel(u.readingSeconds), icon: SardIcons.history_rounded, tone: const Color(0xFFF5A524))),
              ]),
              const SizedBox(height: 22),
              Text('توصياته للمانهوات', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              if (u.recommendations.isEmpty)
                Text('لم يوصِ بأي عمل بعد.', style: context.ts(size: 12.5, color: p.textDim))
              else
                SizedBox(
                  height: 280,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: u.recommendations.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (c, i) {
                      final r = u.recommendations[i];
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          PosterCard(
                            series: r.series,
                            width: 130,
                            onTap: () => Navigator.push(c, sardRoute(DetailsScreen(series: r.series))),
                          ),
                          if (r.note.isNotEmpty)
                            SizedBox(
                              width: 130,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: Text(r.note, maxLines: 2, overflow: TextOverflow.ellipsis, style: context.ts(size: 11, color: p.textDim, height: 1.5)),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                ),
              const SizedBox(height: 22),
              Text('توصياته ومنشوراته', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              if (u.posts.isEmpty)
                Text('لا توجد منشورات بعد.', style: context.ts(size: 12.5, color: p.textDim))
              else
                for (final post in u.posts)
                  Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: p.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: p.border)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          if (post.tag.isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                              decoration: BoxDecoration(color: tint(p.accent, 0.14), borderRadius: BorderRadius.circular(99)),
                              child: Text(post.tag, style: context.ts(size: 10.5, w: FontWeight.w700, color: p.accent)),
                            ),
                          const Spacer(),
                          Text(post.createdAt, style: context.ts(size: 10.5, color: p.textDim)),
                        ]),
                        const SizedBox(height: 8),
                        Text(post.body, style: context.ts(size: 13.5, height: 1.7)),
                        const SizedBox(height: 8),
                        Row(children: [
                          SIcon(SardIcons.favorite_border_rounded, size: 17, color: p.textDim),
                          const SizedBox(width: 4),
                          Text('${post.likes}', style: context.ts(size: 11.5, color: p.textDim)),
                          const SizedBox(width: 14),
                          SIcon(SardIcons.chat_bubble_outline_rounded, size: 16, color: p.textDim),
                          const SizedBox(width: 4),
                          Text('${post.comments}', style: context.ts(size: 11.5, color: p.textDim)),
                        ]),
                      ],
                    ),
                  ),
            ],
          );
        },
      ),
    );
  }
}
