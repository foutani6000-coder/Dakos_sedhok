import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import '../../core/data/account_repository.dart';
import '../../core/data/repository.dart';
import '../../core/theme/app_themes.dart';
import 'admin_access.dart';
import '../../widgets/sard_icons.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, this.startRegister = false});
  final bool startRegister;
  @override State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false, _busy = false, _hide = true;

  @override
  void initState() {
    super.initState();
    _register = widget.startRegister;
  }

  Future<void> _run(Future<void> Function(AccountRepository) action) async {
    if (_busy) return;
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await action(AccountRepository(context.read<SardRepository>().api));
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل الدخول بنجاح')));
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _forgot() async {
    if (_email.text.trim().isEmpty || !_email.text.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل بريدك الإلكتروني أولاً'))); return;
    }
    setState(() => _busy = true);
    try {
      await AccountRepository(context.read<SardRepository>().api).forgotPassword(_email.text.trim());
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('إذا كان البريد مسجلاً فستصلك رسالة استعادة')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  @override void dispose() { _name.dispose(); _email.dispose(); _password.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(appBar: AppBar(title: Text(_register ? 'إنشاء حساب' : 'تسجيل الدخول')),
      body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460), child: Form(key: _form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(width: 76,height: 76,alignment: Alignment.center,decoration: BoxDecoration(color:p.surface,borderRadius:BorderRadius.circular(26),border:Border.all(color:p.border)),child: SIcon(SardIcons.auto_stories_rounded,size:38,color:p.accent)),
        const SizedBox(height: 22), Text(_register ? 'انضم إلى Senok' : 'مرحباً بعودتك',textAlign:TextAlign.center,style:context.ts(size:27,w:FontWeight.w800)),
        const SizedBox(height: 8), Text('احتفظ بمكتبتك وتقدّمك أينما قرأت',textAlign:TextAlign.center,style:context.ts(size:13,color:p.textDim)),
        const SizedBox(height: 28),
        if (_register) _field(context,_name,'الاسم','أدخل اسمك',SardIcons.person_outline,validator:(v)=>v==null||v.trim().length<2?'أدخل اسماً صحيحاً':null),
        _field(context,_email,_register?'البريد الإلكتروني':'البريد الإلكتروني أو اسم الأدمن',_register?'name@example.com':'name@example.com / admin',SardIcons.mail_outline,keyboard:TextInputType.emailAddress,validator:(v)=>v==null||v.trim().isEmpty||(_register&&!v.contains('@'))?'أدخل بريداً صحيحاً':null),
        TextFormField(controller:_password, obscureText:_hide, style:context.ts(), validator:(v)=>v==null||v.isEmpty||(_register&&v.length<8)?'كلمة المرور 8 أحرف على الأقل':null, decoration:InputDecoration(labelText:'كلمة المرور',prefixIcon:const SIcon(SardIcons.lock_outline),suffixIcon:IconButton(onPressed:()=>setState(()=>_hide=!_hide),icon:SIcon(_hide?SardIcons.visibility_outlined:SardIcons.visibility_off_outlined)),filled:true,fillColor:p.surface,border:OutlineInputBorder(borderRadius:BorderRadius.circular(17),borderSide:BorderSide(color:p.border)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(17),borderSide:BorderSide(color:p.border)))),
        if (!_register) Align(alignment:Alignment.centerLeft,child:TextButton(onPressed:_busy?null:_forgot,child:const Text('نسيت كلمة المرور؟'))),
        const SizedBox(height:12), FilledButton(onPressed:_busy?null:()=>_run((r) async { if(_register){await r.signUp(_name.text.trim(),_email.text.trim(),_password.text);}else if(!_email.text.contains('@')){await openAdminPanel(_email.text.trim(),_password.text);}else{await r.signIn(_email.text.trim(),_password.text);} }),style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(54),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17))),child:_busy?const SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2)):Text(_register?'إنشاء الحساب':'دخول')),
        const SizedBox(height:12), OutlinedButton.icon(onPressed:_busy?null:()=>_run((r) async {await r.signInGoogle();}),icon:const SIcon(SardIcons.g_mobiledata_rounded,size:28),label:const Text('المتابعة باستخدام Google'),style:OutlinedButton.styleFrom(minimumSize:const Size.fromHeight(52),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17)),side:BorderSide(color:p.border))),
        const SizedBox(height:18),TextButton(onPressed:_busy?null:()=>setState(()=>_register=!_register),child:Text(_register?'لديك حساب؟ تسجيل الدخول':'ليس لديك حساب؟ إنشاء حساب جديد')),
      ])))))));
  }
  Widget _field(BuildContext c,TextEditingController controller,String label,String hint,SIconData icon,{TextInputType? keyboard,String? Function(String?)? validator}) { final p=c.pal; return Padding(padding:const EdgeInsets.only(bottom:14),child:TextFormField(controller:controller,keyboardType:keyboard,validator:validator,style:c.ts(),decoration:InputDecoration(labelText:label,hintText:hint,prefixIcon:SIcon(icon),filled:true,fillColor:p.surface,border:OutlineInputBorder(borderRadius:BorderRadius.circular(17),borderSide:BorderSide(color:p.border)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(17),borderSide:BorderSide(color:p.border))))); }
}
