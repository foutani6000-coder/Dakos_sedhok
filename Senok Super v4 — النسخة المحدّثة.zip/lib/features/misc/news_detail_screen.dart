
import 'package:flutter/material.dart';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';
import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/states.dart';
import '../../widgets/sard_icons.dart';

class NewsDetailScreen extends StatefulWidget {
  const NewsDetailScreen({super.key,required this.news});
  final SardNews news;
  @override State<NewsDetailScreen> createState()=>_NewsDetailScreenState();
}
class _NewsDetailScreenState extends State<NewsDetailScreen>{
  late Future<SardNews> _future;
  @override void initState(){super.initState();_future=context.read<SardRepository>().newsDetail(widget.news.id);}
  @override Widget build(BuildContext context) {
    final p=context.pal;
    return Scaffold(backgroundColor:p.bg,appBar:AppBar(title:Text('خبر المجتمع',style:context.ts(size:18,w:FontWeight.w700))),
      body:FutureBuilder<SardNews>(future:_future,builder:(context,snap){
        if(snap.hasError)return const EmptyState(title:'تعذّر تحميل تفاصيل الخبر');
        if(!snap.hasData)return const Center(child:CircularProgressIndicator());
        final news=snap.data!;
        return ListView(padding:const EdgeInsets.all(20),children:[
          Container(height:190,decoration:BoxDecoration(color:p.surfaceHi,borderRadius:BorderRadius.circular(24)),child:news.image==null?SIcon(SardIcons.campaign_rounded,size:64,color:p.accent):ClipRRect(borderRadius:BorderRadius.circular(24),child:CachedNetworkImage(imageUrl:news.image!,fit:BoxFit.cover,memCacheWidth:900,maxWidthDiskCache:1200,fadeInDuration:const Duration(milliseconds:220),placeholder:(_,__)=>SIcon(SardIcons.campaign_rounded,size:64,color:p.accent),errorWidget:(_,__,___)=>SIcon(SardIcons.campaign_rounded,size:64,color:p.accent)))),
          const SizedBox(height:18),Text(news.category,style:context.ts(size:12,w:FontWeight.w600,color:p.accent)),
          const SizedBox(height:8),Text(news.title,style:context.ts(size:25,w:FontWeight.w800,height:1.35)),
          const SizedBox(height:8),Text(news.createdAt,style:context.ts(size:12,color:p.textDim)),
          const SizedBox(height:22),Text(news.body,style:context.ts(size:15,color:p.text,height:1.9)),
        ]);
      }));
  }
}
