import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/social_repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/routes.dart';
import '../../widgets/states.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/verified_badge.dart';
import '../account/user_profile_screen.dart';

const _avatarColors = [
  Color(0xFF3B9EFF),
  Color(0xFF2FCB7A),
  Color(0xFFA463F2),
  Color(0xFFF5A524),
  Color(0xFFE0457B),
  Color(0xFF22C7D6),
];

Color _colorFor(String name) => _avatarColors[name.codeUnits.fold<int>(0, (a, b) => a + b) % _avatarColors.length];

class _Avatar extends StatelessWidget {
  const _Avatar(this.name, {this.size = 50, this.badge = SardBadge.none});
  final String name;
  final double size;
  final SardBadge badge;

  @override
  Widget build(BuildContext context) {
    final c = _colorFor(name);
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: tint(c, 0.18),
        shape: BoxShape.circle,
        border: badge.isNone ? Border.all(color: tint(c, 0.5), width: 1.4) : Border.all(color: badgeColor(badge), width: 2.2),
      ),
      child: Text(name.characters.first, style: context.ds(size: size * 0.44, color: c)),
    );
  }
}

/// قائمة المحادثات
class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  late Future<List<SardChat>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<SardRepository>().chats();
  }

  Future<void> _refresh() async {
    setState(() => _future = context.read<SardRepository>().chats());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: Text('المحادثات', style: context.ts(size: 18, w: FontWeight.w700))),
      body: FutureBuilder<List<SardChat>>(
        future: _future,
        builder: (context, snap) {
          if (snap.hasError) return const EmptyState(title: 'تعذّر تحميل المحادثات', subtitle: 'تأكد من اتصالك بالسيرفر وأن المسار GET /chats متوفر.');
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final items = snap.data!;
          if (items.isEmpty) return const EmptyState(title: 'لا توجد محادثات', subtitle: 'ستظهر هنا محادثاتك مع القرّاء الآخرين.');
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
              itemCount: items.length,
              itemBuilder: (context, i) {
                final c = items[i];
                return FadeSlide(
                  index: i,
                  child: Pressable(
                    scale: 0.98,
                    onTap: () => Navigator.push(context, sardRoute(ChatScreen(chat: c))).then((_) => _refresh()),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: p.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: p.border)),
                      child: Row(
                        children: [
                          Pressable(
                            onTap: () => openUserProfile(context, id: c.userId, name: c.name, badge: c.badge),
                            child: _Avatar(c.name, badge: c.badge),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                NameWithBadge(c.name, c.badge, style: context.ts(size: 14.5, w: FontWeight.w700)),
                                const SizedBox(height: 3),
                                Text(c.lastMessage, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.ts(size: 12, color: p.textDim)),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(c.time, style: context.ts(size: 10.5, color: p.textDim)),
                              const SizedBox(height: 6),
                              if (c.unread > 0)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(color: p.accent, borderRadius: BorderRadius.circular(99)),
                                  child: Text('${c.unread}', style: context.ts(size: 11, w: FontWeight.w800, color: p.onAccent)),
                                )
                              else
                                const SizedBox(height: 18),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

/// محادثة واحدة
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chat});
  final SardChat chat;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  List<SardChatMessage> _messages = [];
  bool _loading = true, _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final m = await context.read<SardRepository>().chatMessages(widget.chat.id);
      if (mounted) setState(() => _messages = m);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذّر تحميل الرسائل')));
    } finally {
      if (mounted) setState(() => _loading = false);
      _toBottom();
    }
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 260), curve: Curves.easeOutCubic);
      }
    });
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final m = await context.read<SardRepository>().sendMessage(widget.chat.id, text);
      _input.clear();
      if (mounted) setState(() => _messages = [..._messages, m]);
      _toBottom();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        titleSpacing: 0,
        title: Pressable(
          onTap: () => openUserProfile(context, id: widget.chat.userId, name: widget.chat.name, badge: widget.chat.badge),
          child: Row(children: [
            _Avatar(widget.chat.name, size: 36, badge: widget.chat.badge),
            const SizedBox(width: 10),
            Flexible(child: NameWithBadge(widget.chat.name, widget.chat.badge, style: context.ts(size: 16, w: FontWeight.w700))),
          ]),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _messages.isEmpty
                    ? const EmptyState(title: 'ابدأ المحادثة', subtitle: 'اكتب رسالتك الأولى بالأسفل.')
                    : ListView.builder(
                        controller: _scroll,
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                        itemCount: _messages.length,
                        itemBuilder: (context, i) => _bubble(context, _messages[i]),
                      ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _input,
                      minLines: 1,
                      maxLines: 4,
                      style: context.ts(),
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: InputDecoration(
                        hintText: 'اكتب رسالة...',
                        filled: true,
                        fillColor: p.surface,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: BorderSide(color: p.border)),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: BorderSide(color: p.border)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Pressable(
                    onTap: _send,
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(color: p.accent, shape: BoxShape.circle),
                      child: _sending
                          ? Padding(padding: const EdgeInsets.all(14), child: CircularProgressIndicator(strokeWidth: 2, color: p.onAccent))
                          : SIcon(SardIcons.send_rounded, color: p.onAccent, size: 22),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bubble(BuildContext context, SardChatMessage m) {
    final p = context.pal;
    final mine = m.mine;
    return Align(
      // رسائلي على اليمين (بداية الاتجاه في RTL)
      alignment: mine ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.76),
        decoration: BoxDecoration(
          color: mine ? p.accent : p.surface,
          borderRadius: BorderRadius.circular(18),
          border: mine ? null : Border.all(color: p.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(m.text, style: context.ts(size: 13.5, color: mine ? p.onAccent : p.text, height: 1.5)),
            const SizedBox(height: 3),
            Text(m.time, style: context.ts(size: 10, color: mine ? tint(p.onAccent, 0.7) : p.textDim)),
          ],
        ),
      ),
    );
  }
}
