
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import '../../core/data/repository.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/states.dart';
import '../../widgets/sard_icons.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override State<NotificationsScreen> createState()=>_NotificationsScreenState();
}
class _NotificationsScreenState extends State<NotificationsScreen>{
  late Future _future;
  @override void initState(){super.initState();_future=_load();}
  Future _load()=>context.read<SardRepository>().notifications(context.read<SettingsController>().followedSeries.toList());
  Future<void> _refresh() async { setState(()=>_future=_load()); await _future; }
  @override Widget build(BuildContext context){
    final p=context.pal;
    return Scaffold(backgroundColor:p.bg,appBar:AppBar(title:Text('الإشعارات',style:context.ts(size:18,w:FontWeight.w700))),
      body:FutureBuilder(future:_future,builder:(context,snap){
        if(snap.hasError)return const EmptyState(title:'تعذّر تحميل الإشعارات',subtitle:'تحقق من اتصالك بالسيرفر وحاول مجدداً.');
        if(!snap.hasData)return const Center(child:CircularProgressIndicator());
        final items=snap.data!;
        if(items.isEmpty)return const EmptyState(title:'لا توجد إشعارات جديدة',subtitle:'ستظهر هنا تنبيهات الفصول الجديدة للأعمال التي تتابعها.');
        return RefreshIndicator(onRefresh:_refresh,child:ListView.builder(padding:const EdgeInsets.all(18),itemCount:items.length,itemBuilder:(c,i){
          final n=items[i];
          return Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:p.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:p.border)),
            child:Row(children:[SIcon(SardIcons.notifications_active_rounded,color:n.read?p.textDim:p.accent),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(n.title,style:context.ts(size:14,w:FontWeight.w700)),if(n.body.isNotEmpty)Text(n.body,style:context.ts(size:12,color:p.textDim)),Text(n.createdAt,style:context.ts(size:10,color:p.textDim))]))]));
        }));
      }));
  }
}
