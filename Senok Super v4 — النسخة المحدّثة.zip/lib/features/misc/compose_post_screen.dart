import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/social_repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// شاشة إنشاء منشور: نص + حتى 4 صور + استفتاء (2–5 خيارات) + وسم.
/// تُرجع true عند النشر بنجاح.
class ComposePostScreen extends StatefulWidget {
  const ComposePostScreen({super.key});
  @override
  State<ComposePostScreen> createState() => _ComposePostScreenState();
}

class _ComposePostScreenState extends State<ComposePostScreen> {
  static const _tags = ['توصية', 'نقاش', 'ترشيح', 'ترجمة'];
  static const _maxImages = 4;

  final _body = TextEditingController();
  final _question = TextEditingController();
  final List<TextEditingController> _opts = [TextEditingController(), TextEditingController()];
  final List<String> _images = [];
  final List<TextEditingController> _trash = []; // تُتلف مع الشاشة لتجنّب استعمال متحكم متلف
  String _tag = '';
  bool _poll = false;
  bool _busy = false;

  @override
  void dispose() {
    _body.dispose();
    _question.dispose();
    for (final c in [..._opts, ..._trash]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickImages() async {
    final room = _maxImages - _images.length;
    if (room <= 0) return;
    try {
      final files = await ImagePicker().pickMultiImage(maxWidth: 1600, imageQuality: 82);
      if (files.isEmpty) return;
      setState(() => _images.addAll(files.take(room).map((f) => f.path)));
    } catch (e) {
      _toast('تعذّر فتح المعرض: $e');
    }
  }

  void _toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  SardPoll? _buildPoll() {
    if (!_poll) return null;
    final q = _question.text.trim();
    final texts = _opts.map((c) => c.text.trim()).where((t) => t.isNotEmpty).toList();
    if (q.isEmpty || texts.length < 2) return null;
    return SardPoll(
      question: q,
      options: [for (var i = 0; i < texts.length; i++) SardPollOption(id: 'o${i + 1}', text: texts[i])],
    );
  }

  Future<void> _publish() async {
    if (_busy) return;
    final text = _body.text.trim();
    final poll = _buildPoll();
    if (_poll && poll == null) {
      _toast('الاستفتاء يحتاج سؤالاً وخيارين على الأقل');
      return;
    }
    if (text.isEmpty && _images.isEmpty && poll == null) {
      _toast('اكتب شيئاً أو أضف صورة أو استفتاء');
      return;
    }
    final repo = context.read<SardRepository>();
    setState(() => _busy = true);
    try {
      await repo.addPost(text, tag: _tag, images: List.of(_images), poll: poll);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        _toast('تعذّر النشر: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('منشور جديد'),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 12),
            child: FilledButton(
              onPressed: _busy ? null : _publish,
              child: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('نشر'),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        children: [
          Wrap(
            spacing: 8,
            children: [
              for (final t in _tags)
                ChoiceChip(
                  label: Text(t),
                  selected: _tag == t,
                  onSelected: (v) => setState(() => _tag = v ? t : ''),
                ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _body,
            minLines: 4,
            maxLines: 10,
            maxLength: 800,
            style: context.ts(),
            decoration: InputDecoration(
              hintText: 'شارك فكرة أو ترشيحاً مع المجتمع...',
              filled: true,
              fillColor: p.surface,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: p.border)),
            ),
          ),
          if (_images.isNotEmpty) ...[
            const SizedBox(height: 8),
            SizedBox(
              height: 96,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _images.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (c, i) => Stack(children: [
                  ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(File(_images[i]), width: 96, height: 96, fit: BoxFit.cover)),
                  PositionedDirectional(
                    top: 4,
                    end: 4,
                    child: GestureDetector(
                      onTap: () => setState(() => _images.removeAt(i)),
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                        child: const Icon(Icons.close_rounded, size: 15, color: Colors.white),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          ],
          if (_poll) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: p.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: p.border)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    SIcon(SardIcons.playlist_add_check_rounded, size: 20, color: p.accent),
                    const SizedBox(width: 8),
                    Text('استفتاء', style: context.ds(size: 16)),
                    const Spacer(),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => setState(() => _poll = false),
                      icon: const Icon(Icons.close_rounded, size: 20),
                    ),
                  ]),
                  TextField(controller: _question, maxLength: 120, decoration: const InputDecoration(labelText: 'سؤال الاستفتاء')),
                  for (var i = 0; i < _opts.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Row(children: [
                        Expanded(child: TextField(controller: _opts[i], maxLength: 60, decoration: InputDecoration(labelText: 'الخيار ${i + 1}', counterText: ''))),
                        if (_opts.length > 2)
                          IconButton(
                            onPressed: () => setState(() => _trash.add(_opts.removeAt(i))),
                            icon: const Icon(Icons.remove_circle_outline_rounded, size: 22),
                          ),
                      ]),
                    ),
                  if (_opts.length < 5)
                    TextButton.icon(
                      onPressed: () => setState(() => _opts.add(TextEditingController())),
                      icon: const Icon(Icons.add_rounded),
                      label: const Text('إضافة خيار'),
                    ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 14),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _images.length >= _maxImages ? null : _pickImages,
                icon: const Icon(Icons.image_outlined),
                label: Text('صور (${_images.length}/$_maxImages)'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _poll ? null : () => setState(() => _poll = true),
                icon: const Icon(Icons.poll_outlined),
                label: const Text('استفتاء'),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}
