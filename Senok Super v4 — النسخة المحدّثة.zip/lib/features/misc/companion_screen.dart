import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/ink_spirit.dart';
import '../../widgets/pills.dart';
import '../../widgets/sard_icons.dart';

/// «رفيقي»: ختم Senok المتحرك — غيّر اسمه وحالته.
class CompanionScreen extends StatefulWidget {
  const CompanionScreen({super.key});

  @override
  State<CompanionScreen> createState() => _CompanionScreenState();
}

class _CompanionScreenState extends State<CompanionScreen> {
  late final TextEditingController _name;

  static const _moods = [
    (InkSpiritMood.calm, 'هادئ', SardIcons.spa_rounded),
    (InkSpiritMood.happy, 'سعيد', SardIcons.favorite_rounded),
    (InkSpiritMood.curious, 'فضولي', SardIcons.question_mark_rounded),
    (InkSpiritMood.excited, 'متحمّس', SardIcons.auto_awesome_rounded),
    (InkSpiritMood.sleepy, 'نعسان', SardIcons.bedtime_rounded),
  ];

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: context.read<SettingsController>().companionName);
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final s = context.watch<SettingsController>();
    final mood = s.companionMood.clamp(0, _moods.length - 1).toInt();
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: Text('رفيقي', style: context.ts(size: 18, w: FontWeight.w700))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(child: InkSpirit(size: 120, mood: _moods[mood].$1)),
          const SizedBox(height: 8),
          Center(child: Text(s.companionName, style: context.ds(size: 28))),
          const SizedBox(height: 22),
          TextField(
            controller: _name,
            maxLength: 16,
            style: context.ts(),
            onSubmitted: s.setCompanionName,
            decoration: InputDecoration(
              labelText: 'اسم رفيقك',
              filled: true,
              fillColor: p.surface,
              suffixIcon: IconButton(
                icon: SIcon(SardIcons.check_rounded, color: p.accent),
                onPressed: () {
                  FocusScope.of(context).unfocus();
                  s.setCompanionName(_name.text);
                },
              ),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(17), borderSide: BorderSide(color: p.border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(17), borderSide: BorderSide(color: p.border)),
            ),
          ),
          const SectionHeader(title: 'حالته'),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (var i = 0; i < _moods.length; i++)
                ChoiceChip(
                  selected: i == mood,
                  onSelected: (_) => s.setCompanionMood(i),
                  avatar: SIcon(_moods[i].$3, size: 18, color: i == mood ? p.onAccent : p.textDim),
                  label: Text(_moods[i].$2),
                  labelStyle: context.ts(size: 13, w: FontWeight.w700, color: i == mood ? p.onAccent : p.text),
                  selectedColor: p.accent,
                  backgroundColor: p.surface,
                  side: BorderSide(color: p.border),
                  showCheckmark: false,
                ),
            ],
          ),
        ],
      ),
    );
  }
}
