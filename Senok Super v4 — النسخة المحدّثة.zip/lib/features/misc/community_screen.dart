
import 'package:flutter/material.dart';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';
import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/pills.dart';
import '../../widgets/routes.dart';
import '../../widgets/side_menu.dart';
import '../../widgets/states.dart';
import 'news_detail_screen.dart';
import 'notifications_screen.dart';
import '../../widgets/sard_icons.dart';

class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});
  @override State<CommunityScreen> createState()=>_CommunityScreenState();
}
class _CommunityScreenState extends State<CommunityScreen>{
  late Future<List<SardNews>> _news;
  @override void initState(){super.initState();_news=context.read<SardRepository>().news();}
  Future<void> _refresh() async { setState(()=>_news=context.read<SardRepository>().news()); await _news; }
  @override Widget build(BuildContext context){
    final p=context.pal;
    return SafeArea(bottom:false,child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(20,14,20,10),child:Row(children:[
        const MenuButton(),const SizedBox(width:12),
        Text('المجتمع',style:context.ds(size:30)),const Spacer(),
        IconButton(tooltip:'الإشعارات',onPressed:()=>Navigator.push(context,sardRoute(const NotificationsScreen())),icon:SIcon(SardIcons.notifications_none_rounded,color:p.text,size:26)),
      ])),
      Expanded(child:RefreshIndicator(onRefresh:_refresh,child:FutureBuilder<List<SardNews>>(future:_news,builder:(context,snap){
        if(snap.hasError)return ListView(children:[const SizedBox(height:100),const EmptyState(title:'تعذّر تحميل أخبار المجتمع',subtitle:'تأكد من إعداد API_BASE_URL وأن السيرفر يوفّر المسار GET /news.'),Center(child:TextButton(onPressed:()=>setState(()=>_news=context.read<SardRepository>().news()),child:const Text('إعادة المحاولة')))]);
        if(!snap.hasData)return ListView(children:[const SizedBox(height:120),const Center(child:CircularProgressIndicator())]);
        final items=snap.data!;
        if(items.isEmpty)return ListView(children:[const SizedBox(height:100),const EmptyState(title:'لا توجد أخبار حالياً',subtitle:'ستظهر إعلانات وتحديثات التطبيق هنا عند نشرها على السيرفر.')]);
        return ListView(padding:const EdgeInsets.only(bottom:28),children:[
          const SectionHeader(title:'أخبار المجتمع'),
          for(var i=0;i<items.length;i++) _newsCard(context,items[i],i),
        ]);
      }))),
    ]));
  }
  Widget _newsCard(BuildContext context,SardNews n,int i){
    final p=context.pal;
    return FadeSlide(index:i,child:Pressable(onTap:()=>Navigator.push(context,sardRoute(NewsDetailScreen(news:n))),child:Container(
      margin:const EdgeInsets.fromLTRB(20,0,20,12),padding:const EdgeInsets.all(16),
      decoration:BoxDecoration(color:p.surface,borderRadius:BorderRadius.circular(22),border:Border.all(color:p.border)),
      child:Row(children:[
        Container(width:58,height:58,decoration:BoxDecoration(color:p.surfaceHi,borderRadius:BorderRadius.circular(16)),child:n.image==null?SIcon(SardIcons.campaign_rounded,color:p.accent,size:26):ClipRRect(borderRadius:BorderRadius.circular(16),child:CachedNetworkImage(imageUrl:n.image!,fit:BoxFit.cover,memCacheWidth:180,maxWidthDiskCache:360,fadeInDuration:const Duration(milliseconds:180),placeholder:(_,__)=>SIcon(SardIcons.campaign_rounded,color:p.accent),errorWidget:(_,__,___)=>SIcon(SardIcons.campaign_rounded,color:p.accent)))),
        const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(n.title,maxLines:2,overflow:TextOverflow.ellipsis,style:context.ts(size:15,w:FontWeight.w700,height:1.4)),
          const SizedBox(height:5),Text('${n.category} · ${n.createdAt}',style:context.ts(size:11,color:p.textDim)),
          const SizedBox(height:5),Text(n.body,maxLines:2,overflow:TextOverflow.ellipsis,style:context.ts(size:12,color:p.textDim)),
        ])),SIcon(SardIcons.chevron_left_rounded,color:p.textDim),
      ]),
    )));
  }
}
