import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/social_repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/post_card.dart';
import '../../widgets/routes.dart';
import '../../widgets/side_menu.dart';
import '../../widgets/states.dart';
import '../../widgets/pills.dart';
import '../../widgets/sard_icons.dart';
import 'compose_post_screen.dart';
import 'post_detail_screen.dart';

/// صفحة المنشورات: نص وصور واستفتاءات، مع 5 تفاعلات SVG وتعليقات.
class PostsScreen extends StatefulWidget {
  const PostsScreen({super.key});

  @override
  State<PostsScreen> createState() => _PostsScreenState();
}

class _PostsScreenState extends State<PostsScreen> {
  late Future<List<SardPost>> _future;
  List<SardPost> _items = [];

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<SardPost>> _load() async {
    final l = await context.read<SardRepository>().posts();
    if (mounted) setState(() => _items = l);
    return l;
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    try {
      await _future;
    } catch (_) {}
  }

  Future<void> _compose() async {
    final ok = await Navigator.push<bool>(context, sardRoute<bool>(const ComposePostScreen()));
    if (ok == true) _refresh();
  }

  void _openComments(SardPost post) {
    Navigator.push(context, sardRoute(PostDetailScreen(post: post))).then((_) {
      if (mounted) _refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 10),
            child: Row(
              children: [
                const MenuButton(),
                const SizedBox(width: 12),
                Text('المنشورات', style: context.ds(size: 30)),
                const Spacer(),
                RoundIconButton(icon: SardIcons.edit_rounded, onTap: _compose),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder<List<SardPost>>(
              future: _future,
              builder: (context, snap) {
                if (snap.hasError && _items.isEmpty) {
                  return ListView(children: const [
                    SizedBox(height: 100),
                    EmptyState(title: 'تعذّر تحميل المنشورات', subtitle: 'تأكد من اتصالك بالسيرفر وأن المسار GET /posts متوفر.'),
                  ]);
                }
                if (!snap.hasData && _items.isEmpty) return const Center(child: CircularProgressIndicator());
                if (_items.isEmpty) {
                  return ListView(children: const [
                    SizedBox(height: 100),
                    EmptyState(title: 'لا توجد منشورات بعد', subtitle: 'كن أول من ينشر في المجتمع.'),
                  ]);
                }
                return RefreshIndicator(
                  onRefresh: _refresh,
                  child: ListView.builder(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
                    itemCount: _items.length,
                    itemBuilder: (context, i) => FadeSlide(
                      index: i,
                      child: PostCard(
                        key: ValueKey(_items[i].id),
                        post: _items[i],
                        onOpenComments: () => _openComments(_items[i]),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
