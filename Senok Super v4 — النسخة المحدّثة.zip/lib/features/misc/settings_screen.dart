import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/config/app_config.dart';
import '../../core/guide/guide_content.dart';
import '../../core/guide/guide_controller.dart';
import '../../core/storage/settings.dart';
import '../../widgets/guide_assistant.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/pickers.dart';
import '../../widgets/pills.dart';
import '../../widgets/routes.dart';
import '../account/auth_screen.dart';
import '../account/library_screen.dart';
import '../account/profile_screen.dart';
import '../account/stamps_screen.dart';
import '../account/year_card_screen.dart';
import '../../widgets/sard_icons.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, this.standalone = false});

  /// true عند فتحها من القائمة الجانبية (مع شريط علوي وزر رجوع)
  final bool standalone;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final server = AppConfig.useMock ? 'وضع تجريبي (بدون سيرفر)' : AppConfig.apiBaseUrl;
    final body = SafeArea(
      top: !standalone,
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 28),
        children: [
          if (!standalone)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
              child: Text('الإعدادات', style: context.ds(size: 30)),
            ),
          const SectionHeader(title: 'الحساب والمكتبة'),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Column(children: [
            _action(context, 'تسجيل الدخول / إنشاء حساب', SardIcons.person_outline_rounded, () => Navigator.push(context, sardRoute(const AuthScreen()))),
            _action(context, 'مكتبتي وسجل القراءة', SardIcons.collections_bookmark_outlined, () => Navigator.push(context, sardRoute(const LibraryScreen()))),
            _action(context, 'الملف الشخصي والإحصاءات', SardIcons.account_circle_outlined, () => Navigator.push(context, sardRoute(const ProfileScreen()))),
            _action(context, 'أختامي وإنجازاتي', SardIcons.auto_awesome_rounded, () => Navigator.push(context, sardRoute(const StampsScreen()))),
            _action(context, 'سنتي في القراءة', SardIcons.calendar_today_rounded, () => Navigator.push(context, sardRoute(const YearCardScreen()))),
          ])),
          const SectionHeader(title: 'المظهر'),
          const ThemePicker(),
          const AccentTonePicker(),
          const _FontScaleSetting(),
          const _PrefetchSetting(),
          const SizedBox(height: 14),
          const SectionHeader(title: 'توفير البيانات'),
          const DataModePicker(),
          const SectionHeader(title: 'المساعدة الذكية'),
          const _GuideSettings(),
          const SectionHeader(title: 'حول التطبيق'),
          _row(context, 'الإصدار', AppConfig.version),
          InkWell(onTap: () => _editServer(context), child: _row(context, 'السيرفر (اضغط للتعديل)', server)),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
            child: Text(
              'اضغط على «السيرفر» لتغيير الرابط دون إعادة بناء التطبيق، ثم أغلق التطبيق وافتحه من جديد.',
              style: context.ts(size: 12, color: p.textDim),
            ),
          ),
        ],
      ),
    );
    if (!standalone) return body;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: Text('الإعدادات', style: context.ts(size: 18, w: FontWeight.w700))),
      body: body,
    );
  }

  Future<void> _editServer(BuildContext context) async {
    final c = TextEditingController(text: AppConfig.apiBaseUrl);
    final r = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('رابط الخادم'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: c,
              autofocus: true,
              keyboardType: TextInputType.url,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(hintText: 'http://192.168.1.5:3000'),
            ),
            const SizedBox(height: 10),
            const Text(
              'محاكي أندرويد: http://10.0.2.2:3000\nهاتف حقيقي: عنوان حاسوبك على نفس شبكة الواي فاي (وأطفئ VPN).',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, '__reset__'), child: const Text('الافتراضي')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
    if (r == null || !context.mounted) return;
    final v = r == '__reset__' ? '' : r;
    if (v.isNotEmpty && !RegExp(r'^https?://').hasMatch(v)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يجب أن يبدأ الرابط بـ http:// أو https://')));
      return;
    }
    await AppConfig.saveOverride(v);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الحفظ. أغلق التطبيق وافتحه من جديد ليُطبَّق.')));
    }
  }

  Widget _action(BuildContext context, String label, SIconData icon, VoidCallback onTap) {
    final p = context.pal;
    final r = p.r(0.9).clamp(8.0, 26.0).toDouble();
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Material(
        color: p.glass ? tint(p.surface, 0.78) : p.surface,
        borderRadius: BorderRadius.circular(r),
        child: ListTile(
          leading: SIcon(icon),
          title: Text(label, style: context.ts(size: 13, w: FontWeight.w600)),
          trailing: const SIcon(SardIcons.chevron_left_rounded),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(r),
            side: BorderSide(color: p.border, width: p.borderW),
          ),
          onTap: onTap,
        ),
      ),
    );
  }

  Widget _row(BuildContext context, String k, String v) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: p.glass ? tint(p.surface, 0.78) : p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0).clamp(10.0, 28.0).toDouble()),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Row(
        children: [
          Text(k, style: context.ts(size: 14, w: FontWeight.w600)),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              v,
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              style: context.ts(size: 13, color: p.textDim),
            ),
          ),
        ],
      ),
    );
  }
}


/// إعدادات المساعدة الذكية: تشغيل/إيقاف + إعادة كل الشروحات من البداية.
class _GuideSettings extends StatelessWidget {
  const _GuideSettings();

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final r = p.r(0.9).clamp(8.0, 26.0).toDouble();
    return ListenableBuilder(
      listenable: GuideController.instance,
      builder: (context, _) {
        final g = GuideController.instance;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Material(
            color: p.glass ? tint(p.surface, 0.78) : p.surface,
            borderRadius: BorderRadius.circular(r),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Column(
                children: [
                  SwitchListTile(
                    value: g.enabled,
                    onChanged: g.setEnabled,
                    secondary: ClipOval(
                      child: Image.asset(
                        kAssistantGif,
                        width: 44,
                        height: 44,
                        fit: BoxFit.cover,
                        alignment: Alignment.topCenter,
                        errorBuilder: (_, __, ___) => const SizedBox(width: 44, height: 44),
                      ),
                    ),
                    title: Text('$kAssistantName · المساعدة الذكية', style: context.ts(size: 13, w: FontWeight.w600)),
                    subtitle: Text(
                      'تشرح لك كل قسم وزر عند أول استخدام',
                      style: context.ts(size: 11.5, color: p.textDim),
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.replay_rounded),
                    title: Text('إعادة كل الشروحات من البداية', style: context.ts(size: 13, w: FontWeight.w600)),
                    subtitle: Text(
                      'شاهدتَ ${g.seenCount} من ${g.totalCount} شرحاً',
                      style: context.ts(size: 11.5, color: p.textDim),
                    ),
                    onTap: () {
                      g.resetAll();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تمت إعادة الشروحات، ستظهر من جديد عند أول استخدام.')),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}


/// حجم الخط في التطبيق: ثلاثة مستويات مع معاينة فورية.
class _FontScaleSetting extends StatelessWidget {
  const _FontScaleSetting();

  static const _levels = <(String, double)>[
    ('صغير', 0.8),
    ('متوسط', 0.88),
    ('كبير', 1.0),
  ];

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final settings = context.watch<SettingsController>();
    final cur = settings.fontScale;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.glass ? tint(p.surface, 0.78) : p.surface,
          borderRadius: BorderRadius.circular(p.r(1.1).clamp(10.0, 28.0).toDouble()),
          border: Border.all(color: tint(p.border, 0.65), width: p.borderW),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('حجم الخط', style: context.ts(size: 14, w: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(
              'حكاية قصيرة لمعاينة الحجم الحالي.',
              style: context.ts(size: 12, color: p.textDim),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                for (final level in _levels) ...[
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => settings.setFontScale(level.$2),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        height: 42,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: (cur - level.$2).abs() < 0.015 ? tint(p.accent, 0.16) : p.surfaceHi,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: (cur - level.$2).abs() < 0.015 ? p.accent : Colors.transparent,
                            width: 1.2,
                          ),
                        ),
                        child: Text(
                          level.$1,
                          style: context.ts(
                            size: 13,
                            w: FontWeight.w700,
                            color: (cur - level.$2).abs() < 0.015 ? p.accent : p.text,
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (level != _levels.last) const SizedBox(width: 8),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}


/// التحميل المسبق الذكي: يحمّل الصفحات القادمة والفصل التالي قبل وصولك إليها.
class _PrefetchSetting extends StatelessWidget {
  const _PrefetchSetting();

  static const _levels = <(String, PrefetchMode)>[
    ('إيقاف', PrefetchMode.off),
    ('واي فاي فقط', PrefetchMode.wifi),
    ('دائماً', PrefetchMode.always),
  ];

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final settings = context.watch<SettingsController>();
    final cur = settings.prefetchMode;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.glass ? tint(p.surface, 0.78) : p.surface,
          borderRadius: BorderRadius.circular(p.r(1.1).clamp(10.0, 28.0).toDouble()),
          border: Border.all(color: tint(p.border, 0.65), width: p.borderW),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('تحميل مسبق ذكي', style: context.ts(size: 14, w: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(
              'يحمّل صفحات الفصل التالي مبكراً أثناء قراءتك فلا تنتظر. «واي فاي فقط» يوفّر باقة الجوال.',
              style: context.ts(size: 12, color: p.textDim, height: 1.5),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                for (final level in _levels) ...[
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => settings.setPrefetchMode(level.$2),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        height: 42,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: cur == level.$2 ? tint(p.accent, 0.16) : p.surfaceHi,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: cur == level.$2 ? p.accent : Colors.transparent,
                            width: 1.2,
                          ),
                        ),
                        child: Text(
                          level.$1,
                          style: context.ts(
                            size: 12.5,
                            w: FontWeight.w700,
                            color: cur == level.$2 ? p.accent : p.text,
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (level != _levels.last) const SizedBox(width: 8),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
