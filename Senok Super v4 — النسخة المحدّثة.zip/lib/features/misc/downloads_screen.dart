
import 'package:flutter/material.dart';


import '../../core/data/download_manager.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/states.dart';
import '../../widgets/sard_icons.dart';

class DownloadsScreen extends StatefulWidget {
  const DownloadsScreen({super.key});
  @override
  State<DownloadsScreen> createState()=>_DownloadsScreenState();
}
class _DownloadsScreenState extends State<DownloadsScreen> {
  @override
  void initState(){super.initState(); DownloadManager.instance.init();}
  @override
  Widget build(BuildContext context) {
    final p=context.pal;
    return SafeArea(bottom:false,child:AnimatedBuilder(
      animation:DownloadManager.instance,
      builder:(context,_) {
        final tasks=DownloadManager.instance.tasks;
        return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Padding(padding:const EdgeInsets.fromLTRB(20,14,20,14),child:Row(children:[
            Text('التحميلات',style:context.ds(size:30)),
            const Spacer(),
            if(tasks.isNotEmpty) Pressable(onTap:()=>_confirmClear(context),child:Text('مسح الكل',style:context.ts(size:13,w:FontWeight.w600,color:p.textDim))),
          ])),
          if(tasks.isNotEmpty) Padding(padding:const EdgeInsets.fromLTRB(20,0,20,12),child:Row(children:[
            _count(context,'${tasks.where((e)=>e.isComplete).length}','مكتمل'),
            const SizedBox(width:10),_count(context,'${tasks.where((e)=>e.status==DownloadStatus.downloading).length}','قيد التنزيل'),
            const SizedBox(width:10),_count(context,'${tasks.length}','الإجمالي'),
          ])),
          Expanded(child:tasks.isEmpty
            ? const EmptyState(title:'لا توجد فصول محمّلة',subtitle:'افتح تفاصيل أي عمل واضغط «تنزيل» لحفظ فصوله وقراءتها دون إنترنت.')
            : ListView.builder(padding:const EdgeInsets.fromLTRB(20,4,20,30),itemCount:tasks.length,itemBuilder:(context,i){
              final t=tasks[i];
              return FadeSlide(index:i,child:Container(
                margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(16),
                decoration:BoxDecoration(color:p.surface,borderRadius:BorderRadius.circular(22),border:Border.all(color:p.border)),
                child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Row(children:[
                    Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                      Text(t.seriesTitle,maxLines:1,overflow:TextOverflow.ellipsis,style:context.ts(size:15,w:FontWeight.w700)),
                      const SizedBox(height:4),
                      Text('الفصل ${t.chapter} · ${_status(t.status)}',style:context.ts(size:12,color:p.textDim)),
                    ])),
                    IconButton(tooltip:'حذف',onPressed:()=>DownloadManager.instance.delete(t.id),icon:SIcon(SardIcons.delete_outline_rounded,color:p.textDim)),
                  ]),
                  const SizedBox(height:12),
                  ClipRRect(borderRadius:BorderRadius.circular(8),child:LinearProgressIndicator(value:t.progress,minHeight:7,backgroundColor:p.border,color:p.accent)),
                  const SizedBox(height:7),
                  Row(children:[
                    Expanded(child:Text('${t.completedPages} / ${t.urls.length} صفحة · ${(t.progress*100).round()}%',style:context.ts(size:11.5,color:p.textDim))),
                    if(t.status==DownloadStatus.downloading) IconButton(onPressed:()=>DownloadManager.instance.pause(t.id),icon:const SIcon(SardIcons.pause_circle_outline_rounded))
                    else if(!t.isComplete) IconButton(onPressed:()=>DownloadManager.instance.resume(t.id),icon:const SIcon(SardIcons.play_circle_outline_rounded)),
                    if(t.isComplete) SIcon(SardIcons.check_circle_rounded,color:p.accent),
                  ]),
                  if(t.error.isNotEmpty) Text(t.error,maxLines:2,overflow:TextOverflow.ellipsis,style:context.ts(size:11,color:p.textDim)),
                ]),
              ));
            })),
        ]);
      },
    ));
  }
  Widget _count(BuildContext c,String n,String label){final p=c.pal;return Expanded(child:Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:p.surface,borderRadius:BorderRadius.circular(14)),child:Column(children:[Text(n,style:c.ts(size:17,w:FontWeight.w800)),Text(label,style:c.ts(size:10,color:p.textDim))])));}
  String _status(DownloadStatus s)=>switch(s){DownloadStatus.queued=>'في الانتظار',DownloadStatus.downloading=>'جارٍ التنزيل',DownloadStatus.paused=>'متوقف مؤقتاً',DownloadStatus.completed=>'مكتمل',DownloadStatus.failed=>'فشل التنزيل'};
  Future<void> _confirmClear(BuildContext context) async {
    final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
      title:const Text('مسح جميع التنزيلات؟'),content:const Text('سيتم حذف الملفات المحفوظة من الجهاز.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('مسح'))]));
    if(yes==true) await DownloadManager.instance.clearAll();
  }
}
