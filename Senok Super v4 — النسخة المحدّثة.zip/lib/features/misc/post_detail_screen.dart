import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/social_repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/post_card.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/verified_badge.dart';
import '../account/user_profile_screen.dart';

/// المنشور كاملاً مع التعليقات وإمكانية الرد.
class PostDetailScreen extends StatefulWidget {
  const PostDetailScreen({super.key, required this.post});
  final SardPost post;
  @override
  State<PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<PostDetailScreen> {
  final _ctrl = TextEditingController();
  late Future<List<SardComment>> _future;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _future = context.read<SardRepository>().postComments(widget.post.id);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _reload() => setState(() => _future = context.read<SardRepository>().postComments(widget.post.id));

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;
    final repo = context.read<SardRepository>();
    setState(() => _sending = true);
    try {
      await repo.addPostComment(widget.post.id, text);
      if (!mounted) return;
      _ctrl.clear();
      FocusScope.of(context).unfocus();
      _reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر إرسال التعليق: $e')));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: const Text('المنشور')),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              children: [
                PostCard(post: widget.post),
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 6, 4, 10),
                  child: Text('التعليقات', style: context.ds(size: 18)),
                ),
                FutureBuilder<List<SardComment>>(
                  future: _future,
                  builder: (context, snap) {
                    if (snap.hasError) {
                      return Padding(
                        padding: const EdgeInsets.all(20),
                        child: Center(child: TextButton(onPressed: _reload, child: const Text('تعذّر تحميل التعليقات، أعد المحاولة'))),
                      );
                    }
                    if (!snap.hasData) return const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator()));
                    final items = snap.data!;
                    if (items.isEmpty) {
                      return Padding(
                        padding: const EdgeInsets.all(24),
                        child: Center(child: Text('كن أول من يعلّق', style: context.ts(size: 13, color: p.textDim))),
                      );
                    }
                    return Column(children: [for (final c in items) _tile(context, c)]);
                  },
                ),
              ],
            ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: EdgeInsets.fromLTRB(14, 8, 14, 8),
              decoration: BoxDecoration(color: p.surface, border: Border(top: BorderSide(color: p.border))),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    minLines: 1,
                    maxLines: 4,
                    style: context.ts(),
                    decoration: InputDecoration(
                      hintText: 'اكتب تعليقاً...',
                      filled: true,
                      fillColor: p.bg,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide(color: p.border)),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide(color: p.border)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Pressable(
                  onTap: _send,
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(color: p.accent, shape: BoxShape.circle),
                    child: _sending
                        ? const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : SIcon(SardIcons.send_rounded, size: 20, color: p.onAccent),
                  ),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, SardComment c) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: p.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Pressable(
            scale: 0.985,
            onTap: () => openUserProfile(context, id: c.authorId, name: c.author, badge: c.badge),
            child: Row(children: [
              RingAvatar(name: c.author, badge: c.badge, size: 34),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  NameWithBadge(c.author, c.badge, badgeSize: 15, style: context.ts(size: 13.5, w: FontWeight.w700)),
                  if (c.createdAt.isNotEmpty) Text(c.createdAt, style: context.ts(size: 10.5, color: p.textDim)),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 8),
          Text(c.text, style: context.ts(size: 13.5, height: 1.7)),
        ],
      ),
    );
  }
}
