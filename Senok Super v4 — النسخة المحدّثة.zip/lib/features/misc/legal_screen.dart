import 'package:flutter/material.dart';

import '../../core/config/app_config.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';

/// صفحة نصّية للقوانين. النصوص هنا مبدئية — استبدلها بنصوصك القانونية المعتمدة.
class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.title, required this.icon, required this.sections});
  final String title;
  final SIconData icon;
  final List<(String, String)> sections;

  factory LegalScreen.privacy() => LegalScreen(
        title: 'سياسة الخصوصية',
        icon: SardIcons.shield_rounded,
        sections: [
          ('البيانات التي نجمعها', 'نحفظ على جهازك تقدّم القراءة والمفضلة وإعدادات المظهر. وعند إنشاء حساب نحفظ الاسم والبريد الإلكتروني لمزامنة مكتبتك.'),
          ('كيف نستخدمها', 'تُستخدم البيانات لتحسين تجربتك ومزامنة مكتبتك بين أجهزتك فقط، ولا نبيعها لأي طرف ثالث.'),
          ('التحكم ببياناتك', 'يمكنك تسجيل الخروج في أي وقت أو طلب حذف حسابك وبياناتك من خلال التواصل معنا.'),
        ],
      );

  factory LegalScreen.terms() => LegalScreen(
        title: 'شروط الاستخدام',
        icon: SardIcons.gavel_rounded,
        sections: [
          ('قبول الشروط', 'باستخدامك ${AppConfig.appName} فإنك توافق على هذه الشروط.'),
          ('الاستخدام المسموح', 'التطبيق للقراءة الشخصية. يُمنع نسخ المحتوى أو إعادة نشره أو استخدام التطبيق لأي نشاط مخالف للقانون.'),
          ('المحتوى المنشور', 'أنت مسؤول عمّا تنشره في المنشورات والمحادثات، ويحق لنا حذف أي محتوى مسيء أو مخالف.'),
        ],
      );

  factory LegalScreen.copyright() => LegalScreen(
        title: 'حقوق النشر والإبلاغ',
        icon: SardIcons.copyright_rounded,
        sections: [
          ('حقوق النشر', 'نحترم حقوق أصحاب الأعمال. جميع الأعمال تعود ملكيتها لأصحابها ودور النشر.'),
          ('الإبلاغ عن مخالفة', 'إن كنت تعتقد أن محتوى ما ينتهك حقوقك، راسلنا مع رابط العمل وإثبات الملكية وسنراجع الطلب بأسرع وقت.'),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: Text(title, style: context.ts(size: 18, w: FontWeight.w700))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
        children: [
          Center(
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: tint(p.accent, 0.14), borderRadius: BorderRadius.circular(24)),
              child: SIcon(icon, color: p.accent, size: 34),
            ),
          ),
          const SizedBox(height: 18),
          for (var i = 0; i < sections.length; i++)
            FadeSlide(
              index: i,
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: p.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: p.border)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(sections[i].$1, style: context.ts(size: 15, w: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text(sections[i].$2, style: context.ts(size: 13, color: p.textDim, height: 1.7)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
