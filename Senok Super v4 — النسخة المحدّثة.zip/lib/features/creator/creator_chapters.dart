import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'creator_studio.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// فصول الناشر — إدارة فصول كل عمل: إنشاء، ترتيب، جدولة، نشر.
/// الفصول محفوظة محلياً (SharedPreferences) ومربوطة بإرسال الاستوديو.
/// ──────────────────────────────────────────────────────────────────────────

/// حالة فصل الناشر.
enum CreatorChapterStatus {
  draft('مسودة', 'لم يُنشر بعد.'),
  scheduled('مجدول', 'سيُنشر تلقائياً في موعده.'),
  published('منشور', 'يظهر للقراء.');

  const CreatorChapterStatus(this.label, this.description);
  final String label;
  final String description;
}

Color creatorChapterStatusColor(SardPalette p, CreatorChapterStatus s) {
  switch (s) {
    case CreatorChapterStatus.draft:
      return p.textDim;
    case CreatorChapterStatus.scheduled:
      return p.gold;
    case CreatorChapterStatus.published:
      return const Color(0xFF0F9D75);
  }
}

/// فصل واحد من عمل الناشر.
class CreatorChapter {
  const CreatorChapter({
    required this.id,
    required this.submissionId,
    required this.number,
    required this.title,
    required this.pageCount,
    required this.status,
    required this.createdAt,
    this.publishAt,
    this.publishedAt,
    this.views = 0,
    this.isDemo = false,
  });

  final String id;
  final String submissionId;

  /// رقم الفصل داخل العمل (1، 2، 3...)
  final int number;
  final String title;
  final int pageCount;
  final CreatorChapterStatus status;
  final DateTime createdAt;

  /// موعد النشر المجدول (لحالة scheduled فقط)
  final DateTime? publishAt;
  final DateTime? publishedAt;
  final int views;
  final bool isDemo;

  bool get isPublished => status == CreatorChapterStatus.published;

  /// هل حان موعد نشر فصل مجدول؟
  bool get scheduleDue {
    if (status != CreatorChapterStatus.scheduled) return false;
    if (publishAt == null) return false;
    return !publishAt!.isAfter(DateTime.now());
  }

  String get displayTitle =>
      title.trim().isEmpty ? 'الفصل $number' : 'الفصل $number: ${title.trim()}';

  CreatorChapter copyWith({
    int? number,
    String? title,
    int? pageCount,
    CreatorChapterStatus? status,
    DateTime? publishAt,
    DateTime? publishedAt,
    int? views,
  }) {
    return CreatorChapter(
      id: id,
      submissionId: submissionId,
      number: number ?? this.number,
      title: title ?? this.title,
      pageCount: pageCount ?? this.pageCount,
      status: status ?? this.status,
      createdAt: createdAt,
      publishAt: publishAt ?? this.publishAt,
      publishedAt: publishedAt ?? this.publishedAt,
      views: views ?? this.views,
      isDemo: isDemo,
    );
  }

  /// يلغي الجدولة صراحة (لأن copyWith لا يميّز null عن «بلا تغيير»).
  CreatorChapter withoutSchedule() => CreatorChapter(
        id: id,
        submissionId: submissionId,
        number: number,
        title: title,
        pageCount: pageCount,
        status: status,
        createdAt: createdAt,
        publishedAt: publishedAt,
        views: views,
        isDemo: isDemo,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'submission_id': submissionId,
        'number': number,
        'title': title,
        'page_count': pageCount,
        'status': status.name,
        'created_at': createdAt.millisecondsSinceEpoch,
        'publish_at': publishAt?.millisecondsSinceEpoch,
        'published_at': publishedAt?.millisecondsSinceEpoch,
        'views': views,
        'is_demo': isDemo,
      };

  factory CreatorChapter.fromJson(Map<String, dynamic> j) {
    CreatorChapterStatus st = CreatorChapterStatus.draft;
    final raw = '${j['status'] ?? 'draft'}';
    for (final v in CreatorChapterStatus.values) {
      if (v.name == raw) st = v;
    }
    DateTime? dt(dynamic v) =>
        v == null ? null : DateTime.fromMillisecondsSinceEpoch((v as num).toInt());
    return CreatorChapter(
      id: '${j['id']}',
      submissionId: '${j['submission_id'] ?? ''}',
      number: (j['number'] as num?)?.toInt() ?? 1,
      title: '${j['title'] ?? ''}',
      pageCount: (j['page_count'] as num?)?.toInt() ?? 0,
      status: st,
      createdAt: dt(j['created_at']) ?? DateTime.now(),
      publishAt: dt(j['publish_at']),
      publishedAt: dt(j['published_at']),
      views: (j['views'] as num?)?.toInt() ?? 0,
      isDemo: j['is_demo'] == true,
    );
  }
}

/// نتيجة التحقق من فصل: null = صالح.
String? validateCreatorChapter({
  required int number,
  required String title,
  required int pageCount,
}) {
  if (number < 1) return 'رقم الفصل يجب أن يكون 1 أو أكثر.';
  if (number > 10000) return 'رقم الفصل كبير جداً.';
  if (title.trim().length > 120) return 'عنوان الفصل طويل جداً (120 حرفاً كحد أقصى).';
  if (pageCount < 0) return 'عدد الصفحات لا يمكن أن يكون سالباً.';
  if (pageCount > 500) return 'عدد الصفحات كبير جداً (500 صفحة كحد أقصى).';
  return null;
}

const String _kChaptersKey = 'creator_chapters_v1';

/// مخزن فصول الناشر.
class CreatorChapterStore extends ChangeNotifier {
  CreatorChapterStore(this._p) {
    _read();
  }

  final SharedPreferences _p;
  List<CreatorChapter> _items = [];

  /// عدّاد أحادي لتفادي تطابق المعرّفات المولّدة في الميلي ثانية نفسها.
  static int _seq = 0;

  static CreatorChapterStore? _i;
  static CreatorChapterStore get i => _i!;

  static Future<CreatorChapterStore> load() async {
    final p = await SharedPreferences.getInstance();
    _i ??= CreatorChapterStore(p);
    return _i!;
  }

  static CreatorChapterStore testInstance(SharedPreferences p) =>
      CreatorChapterStore(p);

  List<CreatorChapter> get chapters => List.unmodifiable(_items);

  List<CreatorChapter> ofSubmission(String submissionId) {
    final list = _items.where((e) => e.submissionId == submissionId).toList();
    list.sort((a, b) => a.number.compareTo(b.number));
    return list;
  }

  CreatorChapter? byId(String id) {
    for (final e in _items) {
      if (e.id == id) return e;
    }
    return null;
  }

  /// رقم الفصل التالي المقترح لعمل ما.
  int nextNumber(String submissionId) {
    final list = ofSubmission(submissionId);
    if (list.isEmpty) return 1;
    return list.map((e) => e.number).reduce((a, b) => a > b ? a : b) + 1;
  }

  int get publishedCount =>
      _items.where((e) => e.isPublished).length;

  int get scheduledCount =>
      _items.where((e) => e.status == CreatorChapterStatus.scheduled).length;

  int get draftCount =>
      _items.where((e) => e.status == CreatorChapterStatus.draft).length;

  int totalViewsOf(String submissionId) =>
      ofSubmission(submissionId).fold<int>(0, (a, e) => a + e.views);

  void _read() {
    try {
      final raw = _p.getString(_kChaptersKey);
      if (raw == null || raw.isEmpty) {
        _items = _demoChapters();
        _save();
        return;
      }
      final list = jsonDecode(raw) as List;
      _items = list
          .whereType<Map>()
          .map((e) => CreatorChapter.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      _items = _demoChapters();
    }
  }

  void _save() {
    _p.setString(
      _kChaptersKey,
      jsonEncode(_items.map((e) => e.toJson()).toList()),
    );
  }

  static List<CreatorChapter> _demoChapters() {
    final now = DateTime.now();
    return [
      for (var n = 1; n <= 14; n++)
        CreatorChapter(
          id: 'demo_ch_$n',
          submissionId: 'demo_1',
          number: n,
          title: n == 1 ? 'الاستيقاظ' : n == 2 ? 'الختم المكسور' : '',
          pageCount: 38 + (n % 5) * 4,
          status: CreatorChapterStatus.published,
          createdAt: now.subtract(Duration(days: 12 - n)),
          publishedAt: now.subtract(Duration(days: 12 - n)),
          views: 4200 - n * 180,
          isDemo: true,
        ),
      CreatorChapter(
        id: 'demo_ch_15',
        submissionId: 'demo_1',
        number: 15,
        title: 'طريق الرماد',
        pageCount: 44,
        status: CreatorChapterStatus.scheduled,
        createdAt: now.subtract(const Duration(days: 1)),
        publishAt: now.add(const Duration(days: 2)),
        isDemo: true,
      ),
      for (var n = 1; n <= 3; n++)
        CreatorChapter(
          id: 'demo2_ch_$n',
          submissionId: 'demo_2',
          number: n,
          title: '',
          pageCount: 30 + n * 3,
          status: CreatorChapterStatus.draft,
          createdAt: now.subtract(Duration(days: 4 - n)),
          isDemo: true,
        ),
    ];
  }

  /// يضيف فصلاً جديداً إلى عمل. يُعيد الفصل أو null إن فشل التحقق.
  CreatorChapter? addChapter({
    required String submissionId,
    required int number,
    String title = '',
    int pageCount = 0,
  }) {
    final err = validateCreatorChapter(
      number: number,
      title: title,
      pageCount: pageCount,
    );
    if (err != null) return null;
    if (ofSubmission(submissionId).any((e) => e.number == number)) {
      return null; // رقم مكرر
    }
    final ch = CreatorChapter(
      id: 'ch_${DateTime.now().millisecondsSinceEpoch}_${_seq++}',
      submissionId: submissionId,
      number: number,
      title: title.trim(),
      pageCount: pageCount,
      status: CreatorChapterStatus.draft,
      createdAt: DateTime.now(),
    );
    _items.add(ch);
    _save();
    notifyListeners();
    return ch;
  }

  bool updateChapter(
    String id, {
    int? number,
    String? title,
    int? pageCount,
  }) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    final cur = _items[i];
    if (cur.isPublished) return false; // الفصل المنشور لا يُعدَّل رقمه وعنوانه هنا
    final next = cur.copyWith(
      number: number,
      title: title?.trim(),
      pageCount: pageCount,
    );
    final err = validateCreatorChapter(
      number: next.number,
      title: next.title,
      pageCount: next.pageCount,
    );
    if (err != null) return false;
    if (number != null &&
        number != cur.number &&
        ofSubmission(cur.submissionId).any((e) => e.number == number)) {
      return false;
    }
    _items[i] = next;
    _save();
    notifyListeners();
    return true;
  }

  /// يحذف فصلاً (المسودات والمجدولة فقط).
  bool deleteChapter(String id) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    if (_items[i].isPublished) return false;
    _items.removeAt(i);
    _save();
    notifyListeners();
    return true;
  }

  /// ينشر فصلاً فوراً.
  bool publishChapter(String id, {DateTime? at}) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    final cur = _items[i];
    if (cur.isPublished) return false;
    _items[i] = cur
        .withoutSchedule()
        .copyWith(
          status: CreatorChapterStatus.published,
          publishedAt: at ?? DateTime.now(),
        );
    _save();
    notifyListeners();
    return true;
  }

  /// يجدول فصلاً للنشر في موعد.
  bool scheduleChapter(String id, DateTime at) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    final cur = _items[i];
    if (cur.isPublished) return false;
    if (at.isBefore(DateTime.now())) return false;
    _items[i] = cur.copyWith(
      status: CreatorChapterStatus.scheduled,
      publishAt: at,
    );
    _save();
    notifyListeners();
    return true;
  }

  /// يلغي جدولة فصل ويعيده مسودة.
  bool unscheduleChapter(String id) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    if (_items[i].status != CreatorChapterStatus.scheduled) return false;
    _items[i] = _items[i]
        .withoutSchedule()
        .copyWith(status: CreatorChapterStatus.draft);
    _save();
    notifyListeners();
    return true;
  }

  /// ينشر كل الفصول المجدولة التي حان موعدها. يُنادى عند فتح الاستوديو.
  int publishDue() {
    var n = 0;
    for (var i = 0; i < _items.length; i++) {
      if (_items[i].scheduleDue) {
        _items[i] = _items[i].withoutSchedule().copyWith(
              status: CreatorChapterStatus.published,
              publishedAt: DateTime.now(),
            );
        n++;
      }
    }
    if (n > 0) {
      _save();
      notifyListeners();
    }
    return n;
  }

  /// يعيد ترقيم فصول عمل (بعد حذف فصل من المنتصف مثلاً).
  /// يعيد الترقيم 1..N حسب الترتيب الحالي.
  bool renumber(String submissionId) {
    final list = ofSubmission(submissionId);
    var changed = false;
    for (var i = 0; i < list.length; i++) {
      final want = i + 1;
      if (list[i].number != want) {
        final idx = _items.indexWhere((e) => e.id == list[i].id);
        _items[idx] = _items[idx].copyWith(number: want);
        changed = true;
      }
    }
    if (changed) {
      _save();
      notifyListeners();
    }
    return changed;
  }

  /// يضيف مشاهدات تجريبية لفصل (محاكاة محلية).
  bool addViews(String id, int views) {
    if (views <= 0) return false;
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    _items[i] = _items[i].copyWith(views: _items[i].views + views);
    _save();
    notifyListeners();
    return true;
  }

  void clearDemo() {
    _items.removeWhere((e) => e.isDemo);
    _save();
    notifyListeners();
  }
}

// ───────── واجهة فصول الناشر ─────────

/// شاشة فصول عمل واحد في الاستوديو.
class CreatorChaptersScreen extends StatelessWidget {
  const CreatorChaptersScreen({
    super.key,
    required this.submission,
    required this.store,
  });
  final CreatorSubmission submission;
  final CreatorChapterStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final chapters = store.ofSubmission(submission.id);
        final published = chapters.where((e) => e.isPublished).length;
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            title: Text(submission.title),
          ),
          body: chapters.isEmpty
              ? _ChaptersEmpty(onAdd: () => _openForm(context, null))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  children: [
                    _ChaptersSummary(
                      total: chapters.length,
                      published: published,
                      scheduled: chapters
                          .where((e) =>
                              e.status == CreatorChapterStatus.scheduled)
                          .length,
                      views: chapters.fold<int>(0, (a, e) => a + e.views),
                    ),
                    const SizedBox(height: 12),
                    for (var i = 0; i < chapters.length; i++)
                      Padding(
                        padding: EdgeInsets.only(
                          bottom: i == chapters.length - 1 ? 0 : 10,
                        ),
                        child: _ChapterTile(
                          chapter: chapters[i],
                          store: store,
                          onEdit: () => _openForm(context, chapters[i]),
                        ),
                      ),
                    const SizedBox(height: 16),
                    OutlinedButton.icon(
                      onPressed: () => _confirmRenumber(context),
                      icon: const SIcon(SardIcons.format_list_bulleted_rounded, size: 18),
                      label: const Text('إعادة ترقيم الفصول 1..N'),
                    ),
                  ],
                ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openForm(context, null),
            backgroundColor: p.accent,
            foregroundColor: p.onAccent,
            icon: const SIcon(SardIcons.add_circle_outline),
            label: const Text('فصل جديد'),
          ),
        );
      },
    );
  }

  Future<void> _openForm(BuildContext context, CreatorChapter? existing) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(context.pal.r(1.2)),
        ),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
        ),
        child: _ChapterFormSheet(
          submission: submission,
          store: store,
          existing: existing,
        ),
      ),
    );
  }

  void _confirmRenumber(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.pal.surface,
        title: const Text('إعادة ترقيم الفصول'),
        content: const Text(
          'ستُعاد أرقام الفصول لتصبح 1، 2، 3... حسب ترتيبها الحالي. '
          'الفصول المنشورة تحتفظ بحالتها.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              store.renumber(submission.id);
              Navigator.of(ctx).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('أُعيد ترقيم الفصول.')),
              );
            },
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
  }
}

class _ChaptersSummary extends StatelessWidget {
  const _ChaptersSummary({
    required this.total,
    required this.published,
    required this.scheduled,
    required this.views,
  });
  final int total;
  final int published;
  final int scheduled;
  final int views;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          _SummaryCell('الفصول', '$total'),
          _SummaryCell('منشورة', '$published'),
          _SummaryCell('مجدولة', '$scheduled'),
          _SummaryCell('المشاهدات', formatCount(views)),
        ],
      ),
    );
  }
}

class _SummaryCell extends StatelessWidget {
  const _SummaryCell(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Column(
        children: [
          Text(value, style: context.ds(size: 16)),
          const SizedBox(height: 2),
          Text(label, style: context.ts(size: 12, color: p.textDim)),
        ],
      ),
    );
  }
}

class _ChapterTile extends StatelessWidget {
  const _ChapterTile({
    required this.chapter,
    required this.store,
    required this.onEdit,
  });
  final CreatorChapter chapter;
  final CreatorChapterStore store;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = creatorChapterStatusColor(p, chapter.status);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${chapter.number}',
                  style: context.ds(size: 16, color: p.accent),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(chapter.displayTitle, style: context.ts(w: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(
                      '${chapter.pageCount} صفحة'
                      '${chapter.status == CreatorChapterStatus.scheduled && chapter.publishAt != null ? ' · يُنشر ${formatSardDate(chapter.publishAt!)}' : ''}'
                      '${chapter.isPublished && chapter.publishedAt != null ? ' · نُشر ${formatSardDate(chapter.publishedAt!)}' : ''}',
                      style: context.ts(size: 12, color: p.textDim),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: tint(color, 0.14),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  chapter.status.label,
                  style: context.ts(size: 11.5, w: FontWeight.w800, color: color),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              SIcon(SardIcons.visibility_rounded, size: 14, color: p.textDim),
              const SizedBox(width: 4),
              Text(
                formatCount(chapter.views),
                style: context.ts(size: 12, color: p.textDim),
              ),
              const Spacer(),
              if (!chapter.isPublished)
                TextButton.icon(
                  onPressed: onEdit,
                  icon: const SIcon(SardIcons.edit_rounded, size: 15),
                  label: const Text('تعديل'),
                ),
              if (chapter.status == CreatorChapterStatus.draft)
                FilledButton(
                  onPressed: () {
                    store.publishChapter(chapter.id);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('نُشر الفصل.')),
                    );
                  },
                  child: const Text('نشر'),
                ),
              if (chapter.status == CreatorChapterStatus.scheduled)
                OutlinedButton(
                  onPressed: () {
                    store.unscheduleChapter(chapter.id);
                  },
                  child: const Text('إلغاء الجدولة'),
                ),
              if (!chapter.isPublished)
                IconButton(
                  tooltip: 'حذف الفصل',
                  onPressed: () => _confirmDelete(context),
                  icon: const SIcon(
                    SardIcons.delete_outline_rounded,
                    size: 20,
                    color: Color(0xFFE5484D),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.pal.surface,
        title: Text('حذف ${chapter.displayTitle}؟'),
        content: const Text('لا يمكن التراجع عن حذف فصل غير منشور.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              store.deleteChapter(chapter.id);
              Navigator.of(ctx).pop();
            },
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }
}

class _ChaptersEmpty extends StatelessWidget {
  const _ChaptersEmpty({required this.onAdd});
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 64),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: tint(p.accent, 0.10),
                shape: BoxShape.circle,
              ),
              child: SIcon(SardIcons.format_list_bulleted_rounded, size: 38, color: p.accent),
            ),
            const SizedBox(height: 16),
            Text('لا فصول بعد', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'أضف الفصل الأول لعملك، ثم انشره أو جدوله لموعد لاحق.',
              textAlign: TextAlign.center,
              style: context.ts(color: p.textDim, height: 1.6),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: onAdd,
              icon: const SIcon(SardIcons.add_circle_outline),
              label: const Text('إضافة فصل'),
            ),
          ],
        ),
      ),
    );
  }
}

/// ورقة إضافة/تعديل فصل.
class _ChapterFormSheet extends StatefulWidget {
  const _ChapterFormSheet({
    required this.submission,
    required this.store,
    this.existing,
  });
  final CreatorSubmission submission;
  final CreatorChapterStore store;
  final CreatorChapter? existing;

  @override
  State<_ChapterFormSheet> createState() => _ChapterFormSheetState();
}

class _ChapterFormSheetState extends State<_ChapterFormSheet> {
  late final TextEditingController _number;
  late final TextEditingController _title;
  late final TextEditingController _pages;
  String? _error;
  bool _schedule = false;
  DateTime _publishAt = DateTime.now().add(const Duration(days: 1));

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _number = TextEditingController(
      text: '${e?.number ?? widget.store.nextNumber(widget.submission.id)}',
    );
    _title = TextEditingController(text: e?.title ?? '');
    _pages = TextEditingController(text: '${e?.pageCount ?? 0}');
    _schedule = e?.status == CreatorChapterStatus.scheduled;
    _publishAt = e?.publishAt ?? DateTime.now().add(const Duration(days: 1));
  }

  @override
  void dispose() {
    _number.dispose();
    _title.dispose();
    _pages.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final editing = widget.existing != null;
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.4,
      maxChildSize: 0.9,
      expand: false,
      builder: (ctx, scroll) {
        return SingleChildScrollView(
          controller: scroll,
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: p.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                editing ? 'تعديل الفصل' : 'فصل جديد',
                style: context.ds(size: 20),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('رقم الفصل', style: context.ts(w: FontWeight.w700)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: _number,
                          keyboardType: TextInputType.number,
                          decoration: _dec(p, '1'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('عدد الصفحات', style: context.ts(w: FontWeight.w700)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: _pages,
                          keyboardType: TextInputType.number,
                          decoration: _dec(p, '0'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text('عنوان الفصل (اختياري)', style: context.ts(w: FontWeight.w700)),
              const SizedBox(height: 6),
              TextField(
                controller: _title,
                maxLength: 120,
                decoration: _dec(p, 'مثال: الاستيقاظ'),
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                value: _schedule,
                onChanged: (v) => setState(() => _schedule = v),
                title: Text('جدولة النشر', style: context.ts(w: FontWeight.w700)),
                subtitle: Text(
                  'يُنشر الفصل تلقائياً في الموعد المحدد.',
                  style: context.ts(size: 12.5, color: p.textDim),
                ),
                contentPadding: EdgeInsets.zero,
                activeColor: p.accent,
              ),
              if (_schedule)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: SIcon(SardIcons.calendar_today_rounded, color: p.accent),
                  title: Text(
                    formatSardDateTime(_publishAt),
                    style: context.ts(w: FontWeight.w700),
                  ),
                  trailing: TextButton(
                    onPressed: _pickDate,
                    child: const Text('تغيير الموعد'),
                  ),
                ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: context.ts(color: const Color(0xFFE5484D))),
              ],
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _save,
                  child: Text(editing ? 'حفظ التعديلات' : 'إضافة الفصل'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  InputDecoration _dec(SardPalette p, String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: context.ts(color: p.textDim),
      filled: true,
      fillColor: p.surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.accent, width: 1.5),
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _publishAt,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_publishAt),
    );
    if (!mounted) return;
    setState(() {
      _publishAt = DateTime(
        picked.year,
        picked.month,
        picked.day,
        time?.hour ?? 12,
        time?.minute ?? 0,
      );
    });
  }

  void _save() {
    final number = int.tryParse(_number.text.trim()) ?? 0;
    final pages = int.tryParse(_pages.text.trim()) ?? 0;
    final err = validateCreatorChapter(
      number: number,
      title: _title.text,
      pageCount: pages,
    );
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    final existing = widget.existing;
    if (existing == null) {
      final ch = widget.store.addChapter(
        submissionId: widget.submission.id,
        number: number,
        title: _title.text,
        pageCount: pages,
      );
      if (ch == null) {
        setState(() => _error = 'رقم الفصل مكرر، اختر رقماً آخر.');
        return;
      }
      if (_schedule) {
        if (_publishAt.isBefore(DateTime.now())) {
          setState(() => _error = 'موعد النشر يجب أن يكون في المستقبل.');
          return;
        }
        widget.store.scheduleChapter(ch.id, _publishAt);
      }
    } else {
      final ok = widget.store.updateChapter(
        existing.id,
        number: number,
        title: _title.text,
        pageCount: pages,
      );
      if (!ok) {
        setState(() => _error = 'تعذّر حفظ التعديلات (رقم مكرر؟).');
        return;
      }
      if (_schedule) {
        widget.store.scheduleChapter(existing.id, _publishAt);
      } else if (existing.status == CreatorChapterStatus.scheduled) {
        widget.store.unscheduleChapter(existing.id);
      }
    }
    if (!mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('حُفظ الفصل.')),
    );
  }
}
