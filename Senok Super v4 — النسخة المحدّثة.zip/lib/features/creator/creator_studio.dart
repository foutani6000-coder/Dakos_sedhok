import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// استوديو الناشر — إرسال الأعمال ومتابعة حالتها حتى النشر.
/// كل البيانات محلية (SharedPreferences) في هذه المرحلة؛ لا يوجد خادم
/// ناشرين بعد، والواجهة تشرح ذلك صراحة.
/// ──────────────────────────────────────────────────────────────────────────

/// تنسيق عربي قصير للتاريخ: 26 نوفمبر 2026
String formatSardDate(DateTime d) {
  const months = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];
  return '${d.day} ${months[d.month - 1]} ${d.year}';
}

/// تنسيق التاريخ مع الوقت: 26 نوفمبر 2026 — 14:30
String formatSardDateTime(DateTime d) {
  final h = d.hour.toString().padLeft(2, '0');
  final m = d.minute.toString().padLeft(2, '0');
  return '${formatSardDate(d)} — $h:$m';
}

/// حالة إرسال عمل جديد. الترتيب هو ترتيب خطوات المسار الطبيعي.
enum CreatorSubmissionStatus {
  draft('مسودة', 'لم تُرسل بعد، يمكنك تعديلها بحرية.'),
  underReview('قيد المراجعة', 'أرسلتها إلى فريق Senok، وسنرد خلال 3 أيام عمل.'),
  changesRequested('طُلب تعديل', 'طلب فريق المراجعة تعديلات قبل القبول.'),
  approved('مقبول', 'قُبل عملك، وهو جاهز للنشر.'),
  published('منشور', 'عملك منشور ويظهر للقراء.'),
  rejected('مرفوض', 'لم يُقبل العمل هذه المرة، ويمكنك إعادة الإرسال بعد التعديل.');

  const CreatorSubmissionStatus(this.label, this.description);
  final String label;
  final String description;

  /// هل يظهر العمل للقراء؟
  bool get visibleToReaders => this == CreatorSubmissionStatus.published;

  /// هل ما زال بالإمكان تعديل بيانات الإرسال؟
  bool get editable =>
      this == CreatorSubmissionStatus.draft ||
      this == CreatorSubmissionStatus.changesRequested ||
      this == CreatorSubmissionStatus.rejected;

  /// هل وصل الإرسال إلى نهايته (نشر أو رفض)؟
  bool get terminal =>
      this == CreatorSubmissionStatus.published ||
      this == CreatorSubmissionStatus.rejected;

  /// خطوات المسار الكامل بالترتيب (للخط الزمني).
  static const List<CreatorSubmissionStatus> pipeline = [
    draft,
    underReview,
    approved,
    published,
  ];
}

/// لون الحالة من لوحة الثيم النشطة.
Color creatorStatusColor(SardPalette p, CreatorSubmissionStatus s) {
  switch (s) {
    case CreatorSubmissionStatus.draft:
      return p.textDim;
    case CreatorSubmissionStatus.underReview:
      return p.gold;
    case CreatorSubmissionStatus.changesRequested:
      return const Color(0xFFF0A21A);
    case CreatorSubmissionStatus.approved:
      return const Color(0xFF0F9D75);
    case CreatorSubmissionStatus.published:
      return p.accent;
    case CreatorSubmissionStatus.rejected:
      return const Color(0xFFE5484D);
  }
}

/// أيقونة الحالة.
SIconData creatorStatusIcon(CreatorSubmissionStatus s) {
  switch (s) {
    case CreatorSubmissionStatus.draft:
      return SardIcons.edit_rounded;
    case CreatorSubmissionStatus.underReview:
      return SardIcons.watch_later_rounded;
    case CreatorSubmissionStatus.changesRequested:
      return SardIcons.refresh_rounded;
    case CreatorSubmissionStatus.approved:
      return SardIcons.check_circle_rounded;
    case CreatorSubmissionStatus.published:
      return SardIcons.visibility_rounded;
    case CreatorSubmissionStatus.rejected:
      return SardIcons.close_rounded;
  }
}

// ───────── نموذج الإرسال ─────────

/// إرسال عمل جديد إلى فريق Senok.
class CreatorSubmission {
  const CreatorSubmission({
    required this.id,
    required this.title,
    required this.type,
    required this.genres,
    required this.synopsis,
    required this.coverUrl,
    required this.createdAt,
    required this.status,
    this.submittedAt,
    this.reviewedAt,
    this.reviewNote = '',
    this.chaptersCount = 0,
    this.views = 0,
    this.rating = 0,
    this.isDemo = false,
  });

  final String id;
  final String title;

  /// نوع العمل: مانهوا كورية / مانغا يابانية / مانهوا صينية / ويبتون
  final String type;
  final List<String> genres;
  final String synopsis;

  /// رابط الغلاف (اختياري)
  final String coverUrl;
  final DateTime createdAt;
  final DateTime? submittedAt;
  final DateTime? reviewedAt;

  /// ملاحظة فريق المراجعة (سبب طلب التعديل أو الرفض)
  final String reviewNote;
  final CreatorSubmissionStatus status;
  final int chaptersCount;
  final int views;
  final double rating;

  /// هل هذا الإرسال مثال تجريبي مولّد محلياً؟
  final bool isDemo;

  CreatorSubmission copyWith({
    String? title,
    String? type,
    List<String>? genres,
    String? synopsis,
    String? coverUrl,
    DateTime? submittedAt,
    DateTime? reviewedAt,
    String? reviewNote,
    CreatorSubmissionStatus? status,
    int? chaptersCount,
    int? views,
    double? rating,
  }) {
    return CreatorSubmission(
      id: id,
      title: title ?? this.title,
      type: type ?? this.type,
      genres: genres ?? this.genres,
      synopsis: synopsis ?? this.synopsis,
      coverUrl: coverUrl ?? this.coverUrl,
      createdAt: createdAt,
      status: status ?? this.status,
      submittedAt: submittedAt ?? this.submittedAt,
      reviewedAt: reviewedAt ?? this.reviewedAt,
      reviewNote: reviewNote ?? this.reviewNote,
      chaptersCount: chaptersCount ?? this.chaptersCount,
      views: views ?? this.views,
      rating: rating ?? this.rating,
      isDemo: isDemo,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'type': type,
        'genres': genres,
        'synopsis': synopsis,
        'cover_url': coverUrl,
        'created_at': createdAt.millisecondsSinceEpoch,
        'submitted_at': submittedAt?.millisecondsSinceEpoch,
        'reviewed_at': reviewedAt?.millisecondsSinceEpoch,
        'review_note': reviewNote,
        'status': status.name,
        'chapters_count': chaptersCount,
        'views': views,
        'rating': rating,
        'is_demo': isDemo,
      };

  factory CreatorSubmission.fromJson(Map<String, dynamic> j) {
    CreatorSubmissionStatus st = CreatorSubmissionStatus.draft;
    final raw = '${j['status'] ?? 'draft'}';
    for (final v in CreatorSubmissionStatus.values) {
      if (v.name == raw) st = v;
    }
    DateTime? dt(dynamic v) =>
        v == null ? null : DateTime.fromMillisecondsSinceEpoch((v as num).toInt());
    return CreatorSubmission(
      id: '${j['id']}',
      title: '${j['title'] ?? ''}',
      type: '${j['type'] ?? 'مانهوا كورية'}',
      genres: ((j['genres'] as List?) ?? const []).map((e) => '$e').toList(),
      synopsis: '${j['synopsis'] ?? ''}',
      coverUrl: '${j['cover_url'] ?? ''}',
      createdAt: dt(j['created_at']) ?? DateTime.now(),
      submittedAt: dt(j['submitted_at']),
      reviewedAt: dt(j['reviewed_at']),
      reviewNote: '${j['review_note'] ?? ''}',
      status: st,
      chaptersCount: (j['chapters_count'] as num?)?.toInt() ?? 0,
      views: (j['views'] as num?)?.toInt() ?? 0,
      rating: (j['rating'] as num?)?.toDouble() ?? 0,
      isDemo: j['is_demo'] == true,
    );
  }

  /// التحويل إلى عمل [Series] بعد النشر (يظهر في المكتبة).
  Series toSeries() => Series(
        id: 'creator_$id',
        title: title,
        cover: coverUrl.isEmpty ? null : coverUrl,
        type: type,
        status: 'مستمر',
        chapters: chaptersCount,
        rating: rating,
        views: views,
        genres: genres,
        synopsis: synopsis,
        isNew: true,
        year: DateTime.now().year,
      );
}

/// أنواع الأعمال المتاحة للنشر.
const List<String> kCreatorWorkTypes = [
  'مانهوا كورية',
  'مانغا يابانية',
  'مانهوا صينية',
  'ويبتون',
  'كوميك عربي',
];

/// التصنيفات المتاحة للنشر (اختر حتى 4).
const List<String> kCreatorGenres = [
  'أكشن', 'مغامرة', 'رومانسي', 'فانتازيا', 'خيال علمي', 'دراما',
  'كوميديا', 'رعب', 'غموض', 'تاريخي', 'رياضي', 'مدرسي',
  'خارق', 'نفسي', 'حربي', 'طبخ',
];

/// نتيجة التحقق من نموذج الإرسال: null = صالح، وإلا رسالة الخطأ الأولى.
String? validateSubmission({
  required String title,
  required String synopsis,
  required List<String> genres,
  required String type,
}) {
  final t = title.trim();
  if (t.isEmpty) return 'اكتب عنوان العمل.';
  if (t.length < 2) return 'العنوان قصير جداً.';
  if (t.length > 80) return 'العنوان طويل جداً (80 حرفاً كحد أقصى).';
  if (!kCreatorWorkTypes.contains(type)) return 'اختر نوع العمل.';
  if (genres.isEmpty) return 'اختر تصنيفاً واحداً على الأقل.';
  if (genres.length > 4) return 'اختر 4 تصنيفات كحد أقصى.';
  final s = synopsis.trim();
  if (s.isEmpty) return 'اكتب ملخصاً قصيراً عن العمل.';
  if (s.length < 30) return 'الملخص قصير جداً (30 حرفاً على الأقل).';
  if (s.length > 2000) return 'الملخص طويل جداً (2000 حرف كحد أقصى).';
  return null;
}

// ───────── مخزن الاستوديو ─────────

const String _kSubmissionsKey = 'creator_submissions_v1';

/// مخزن إرسالات الناشر. يُحمَّل عبر [CreatorStudioStore.load] ويُوفَّر
/// عبر ChangeNotifierProvider.value في الشاشات.
class CreatorStudioStore extends ChangeNotifier {
  CreatorStudioStore(this._p) {
    _read();
  }

  final SharedPreferences _p;
  List<CreatorSubmission> _items = [];

  /// عدّاد أحادي لتفادي تطابق المعرّفات المولّدة في الميلي ثانية نفسها.
  static int _seq = 0;

  static CreatorStudioStore? _i;

  /// النسخة المشتركة (تُنشأ في main عبر [load]).
  static CreatorStudioStore get i => _i!;

  static Future<CreatorStudioStore> load() async {
    final p = await SharedPreferences.getInstance();
    _i ??= CreatorStudioStore(p);
    return _i!;
  }

  /// للاختبارات: نسخة جديدة على تفضيلات وهمية.
  static CreatorStudioStore testInstance(SharedPreferences p) =>
      CreatorStudioStore(p);

  List<CreatorSubmission> get submissions => List.unmodifiable(_items);

  List<CreatorSubmission> byStatus(CreatorSubmissionStatus s) =>
      _items.where((e) => e.status == s).toList();

  CreatorSubmission? byId(String id) {
    for (final e in _items) {
      if (e.id == id) return e;
    }
    return null;
  }

  int get totalSubmissions => _items.length;
  int get publishedCount => byStatus(CreatorSubmissionStatus.published).length;
  int get pendingCount => byStatus(CreatorSubmissionStatus.underReview).length +
      byStatus(CreatorSubmissionStatus.changesRequested).length;
  int get totalViews => _items.fold<int>(0, (a, e) => a + e.views);
  int get totalChapters =>
      _items.fold<int>(0, (a, e) => a + e.chaptersCount);

  double get averageRating {
    final rated = _items.where((e) => e.rating > 0).toList();
    if (rated.isEmpty) return 0;
    return rated.fold<double>(0, (a, e) => a + e.rating) / rated.length;
  }

  /// خريطة عدد الإرسالات لكل حالة (للوحة التحكم).
  Map<CreatorSubmissionStatus, int> get statusCounts {
    final m = <CreatorSubmissionStatus, int>{
      for (final s in CreatorSubmissionStatus.values) s: 0,
    };
    for (final e in _items) {
      m[e.status] = (m[e.status] ?? 0) + 1;
    }
    return m;
  }

  void _read() {
    try {
      final raw = _p.getString(_kSubmissionsKey);
      if (raw == null || raw.isEmpty) {
        _items = _demoSubmissions();
        _save();
        return;
      }
      final list = jsonDecode(raw) as List;
      _items = list
          .whereType<Map>()
          .map((e) => CreatorSubmission.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      _items = _demoSubmissions();
    }
  }

  void _save() {
    _p.setString(
      _kSubmissionsKey,
      jsonEncode(_items.map((e) => e.toJson()).toList()),
    );
  }

  /// أمثلة تجريبية محلية حتى يرى الناشر الجديد شكل الاستوديو.
  static List<CreatorSubmission> _demoSubmissions() {
    final now = DateTime.now();
    return [
      CreatorSubmission(
        id: 'demo_1',
        title: 'سيف الفجر',
        type: 'مانهوا كورية',
        genres: const ['أكشن', 'فانتازيا'],
        synopsis:
            'في مملكة ابتلعها الظلام، يستيقظ فارس منسي يحمل سيفاً لا ينكسر، '
            'ليقود آخر كتائب النور في معركة لا ترحم.',
        coverUrl: '',
        createdAt: now.subtract(const Duration(days: 12)),
        submittedAt: now.subtract(const Duration(days: 11)),
        reviewedAt: now.subtract(const Duration(days: 9)),
        status: CreatorSubmissionStatus.published,
        chaptersCount: 14,
        views: 48200,
        rating: 4.6,
        isDemo: true,
      ),
      CreatorSubmission(
        id: 'demo_2',
        title: 'مقهى منتصف الليل',
        type: 'مانغا يابانية',
        genres: const ['دراما', 'رومانسي'],
        synopsis:
            'مقهى صغير لا يفتح إلا بعد منتصف الليل، وزبائنه أشخاص يحملون '
            'أمنية واحدة أخيرة قبل أن يغلق بابه إلى الأبد.',
        coverUrl: '',
        createdAt: now.subtract(const Duration(days: 4)),
        submittedAt: now.subtract(const Duration(days: 3)),
        status: CreatorSubmissionStatus.underReview,
        chaptersCount: 3,
        isDemo: true,
      ),
      CreatorSubmission(
        id: 'demo_3',
        title: 'طباخ الأرواح',
        type: 'مانهوا صينية',
        genres: const ['كوميديا', 'خارق'],
        synopsis:
            'شاب يرث مطعماً غامضاً يطبخ أطباقاً تعيد للأرواح ذكرياتها '
            'المفقودة، بشرط أن يدفع الزبون بذكرى من حياته.',
        coverUrl: '',
        createdAt: now.subtract(const Duration(days: 6)),
        submittedAt: now.subtract(const Duration(days: 5)),
        reviewedAt: now.subtract(const Duration(days: 2)),
        reviewNote: 'الفكرة جميلة، لكن نحتاج صفحات أوضح في الفصل الأول '
            'وإعادة رسم المشهد الافتتاحي بإضاءة أقوى.',
        status: CreatorSubmissionStatus.changesRequested,
        chaptersCount: 2,
        isDemo: true,
      ),
    ];
  }

  /// ينشئ مسودة جديدة ويعيدها. يُعيد null إن فشل التحقق.
  CreatorSubmission? createDraft({
    required String title,
    required String type,
    required List<String> genres,
    required String synopsis,
    String coverUrl = '',
  }) {
    final err = validateSubmission(
      title: title,
      synopsis: synopsis,
      genres: genres,
      type: type,
    );
    if (err != null) return null;
    final item = CreatorSubmission(
      id: 'sub_${DateTime.now().millisecondsSinceEpoch}_${_seq++}',
      title: title.trim(),
      type: type,
      genres: List<String>.from(genres),
      synopsis: synopsis.trim(),
      coverUrl: coverUrl.trim(),
      createdAt: DateTime.now(),
      status: CreatorSubmissionStatus.draft,
    );
    _items.insert(0, item);
    _save();
    notifyListeners();
    return item;
  }

  /// يعدّل مسودة (أو إرسالاً طُلب تعديله / مرفوضاً).
  bool updateDraft(
    String id, {
    String? title,
    String? type,
    List<String>? genres,
    String? synopsis,
    String? coverUrl,
  }) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    final cur = _items[i];
    if (!cur.status.editable) return false;
    final next = cur.copyWith(
      title: title?.trim(),
      type: type,
      genres: genres == null ? null : List<String>.from(genres),
      synopsis: synopsis?.trim(),
      coverUrl: coverUrl?.trim(),
    );
    final err = validateSubmission(
      title: next.title,
      synopsis: next.synopsis,
      genres: next.genres,
      type: next.type,
    );
    if (err != null) return false;
    // إن كان طُلب تعديله، يعود إلى مسودة بعد التعديل ليعيد الناشر إرساله.
    _items[i] = next.status == CreatorSubmissionStatus.changesRequested ||
            next.status == CreatorSubmissionStatus.rejected
        ? next.copyWith(status: CreatorSubmissionStatus.draft)
        : next;
    _save();
    notifyListeners();
    return true;
  }

  /// يرسل مسودة إلى المراجعة.
  bool sendForReview(String id, {DateTime? at}) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    final cur = _items[i];
    if (cur.status != CreatorSubmissionStatus.draft) return false;
    _items[i] = cur.copyWith(
      status: CreatorSubmissionStatus.underReview,
      submittedAt: at ?? DateTime.now(),
    );
    _save();
    notifyListeners();
    return true;
  }

  /// يسحب إرسالاً قيد المراجعة إلى مسودة.
  bool withdraw(String id) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    if (_items[i].status != CreatorSubmissionStatus.underReview) return false;
    _items[i] = _items[i].copyWith(status: CreatorSubmissionStatus.draft);
    _save();
    notifyListeners();
    return true;
  }

  /// يحذف إرسالاً (المسودات والمرفوضات فقط).
  bool delete(String id) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    final s = _items[i].status;
    if (s != CreatorSubmissionStatus.draft &&
        s != CreatorSubmissionStatus.rejected) {
      return false;
    }
    _items.removeAt(i);
    _save();
    notifyListeners();
    return true;
  }

  /// يحاكي قرار فريق المراجعة (للتجربة المحلية فقط).
  /// في الإنتاج يأتي القرار من الخادم.
  bool simulateReview(
    String id,
    CreatorSubmissionStatus decision, {
    String note = '',
    DateTime? at,
  }) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    final cur = _items[i];
    if (cur.status != CreatorSubmissionStatus.underReview) return false;
    if (decision != CreatorSubmissionStatus.approved &&
        decision != CreatorSubmissionStatus.changesRequested &&
        decision != CreatorSubmissionStatus.rejected) {
      return false;
    }
    _items[i] = cur.copyWith(
      status: decision,
      reviewedAt: at ?? DateTime.now(),
      reviewNote: note,
    );
    _save();
    notifyListeners();
    return true;
  }

  /// ينشر عملاً مقبولاً.
  bool publish(String id, {DateTime? at}) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    if (_items[i].status != CreatorSubmissionStatus.approved) return false;
    _items[i] = _items[i].copyWith(
      status: CreatorSubmissionStatus.published,
      reviewedAt: _items[i].reviewedAt ?? at ?? DateTime.now(),
    );
    _save();
    notifyListeners();
    return true;
  }

  /// يحدّث إحصاءات عمل منشور (مشاهدات/فصول/تقييم) — يُنادى من التحليلات.
  bool updateStats(
    String id, {
    int? views,
    int? chaptersCount,
    double? rating,
  }) {
    final i = _items.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    _items[i] = _items[i].copyWith(
      views: views,
      chaptersCount: chaptersCount,
      rating: rating,
    );
    _save();
    notifyListeners();
    return true;
  }

  /// يمسح كل الأمثلة التجريبية.
  void clearDemo() {
    _items.removeWhere((e) => e.isDemo);
    _save();
    notifyListeners();
  }

  /// سطر التاريخ المناسب لخطوة معيّنة في الخط الزمني.
  /// يغطي كل حالات [CreatorSubmissionStatus] بلا استثناء.
  String dateForStep(CreatorSubmission item, CreatorSubmissionStatus step) {
    switch (step) {
      case CreatorSubmissionStatus.draft:
        return 'أُنشئ ${formatSardDate(item.createdAt)}';
      case CreatorSubmissionStatus.underReview:
        return item.submittedAt == null
            ? 'بانتظار الإرسال'
            : 'أُرسل ${formatSardDate(item.submittedAt!)}';
      case CreatorSubmissionStatus.changesRequested:
        return item.reviewedAt == null
            ? 'بانتظار قرار الفريق'
            : 'طُلب تعديل ${formatSardDate(item.reviewedAt!)}';
      case CreatorSubmissionStatus.rejected:
        return item.reviewedAt == null
            ? 'بانتظار قرار الفريق'
            : 'رُفض ${formatSardDate(item.reviewedAt!)}';
      case CreatorSubmissionStatus.approved:
        return item.reviewedAt == null
            ? 'بانتظار قرار الفريق'
            : 'رُوجع ${formatSardDate(item.reviewedAt!)}';
      case CreatorSubmissionStatus.published:
        return item.status.visibleToReaders && item.reviewedAt != null
            ? 'نُشر ${formatSardDate(item.reviewedAt!)}'
            : 'لم يُنشر بعد';
    }
  }

  /// هل وصل الإرسال إلى هذه الخطوة أو تجاوزها؟
  bool reachedStep(CreatorSubmission item, CreatorSubmissionStatus step) {
    const order = CreatorSubmissionStatus.pipeline;
    final cur = item.status;
    if (cur == CreatorSubmissionStatus.rejected ||
        cur == CreatorSubmissionStatus.changesRequested) {
      // في المسار الجانبي: وصل إلى المراجعة فقط.
      return step == CreatorSubmissionStatus.draft ||
          step == CreatorSubmissionStatus.underReview;
    }
    final ci = order.indexOf(cur);
    final si = order.indexOf(step);
    return si <= ci;
  }
}

// ───────── واجهة الاستوديو ─────────

/// شاشة استوديو الناشر الرئيسية.
class CreatorStudioScreen extends StatefulWidget {
  const CreatorStudioScreen({super.key, required this.store});
  final CreatorStudioStore store;

  @override
  State<CreatorStudioScreen> createState() => _CreatorStudioScreenState();
}

class _CreatorStudioScreenState extends State<CreatorStudioScreen> {
  CreatorSubmissionStatus? _filter;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = widget.store;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final counts = store.statusCounts;
        final items = _filter == null
            ? store.submissions
            : store.byStatus(_filter!);
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            title: const Text('استوديو الناشر'),
            actions: [
              IconButton(
                tooltip: 'مساعدة',
                onPressed: () => _showHelp(context),
                icon: const SIcon(SardIcons.question_mark_rounded),
              ),
            ],
          ),
          body: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _DemoNoteCard(store: store),
                      const SizedBox(height: 14),
                      Text('نظرة عامة', style: context.ds(size: 18)),
                      const SizedBox(height: 10),
                      _OverviewGrid(store: store),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Text('أعمالي', style: context.ds(size: 18)),
                          const Spacer(),
                          Text(
                            '${store.totalSubmissions} عمل',
                            style: context.ts(color: p.textDim),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _StatusFilterRow(
                        counts: counts,
                        selected: _filter,
                        onSelect: (s) => setState(() => _filter = s),
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
                ),
              ),
              if (items.isEmpty)
                SliverToBoxAdapter(
                  child: _EmptySubmissions(
                    filtered: _filter != null,
                    onCreate: () => _openForm(context, store, null),
                  ),
                )
              else
                SliverList.builder(
                  itemCount: items.length,
                  itemBuilder: (context, i) {
                    final item = items[i];
                    return Padding(
                      padding: EdgeInsets.fromLTRB(
                        16,
                        0,
                        16,
                        i == items.length - 1 ? 24 : 10,
                      ),
                      child: _SubmissionCard(
                        item: item,
                        store: store,
                        onEdit: () => _openForm(context, store, item),
                        onOpen: () => _showDetail(context, store, item),
                      ),
                    );
                  },
                ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openForm(context, store, null),
            backgroundColor: p.accent,
            foregroundColor: p.onAccent,
            icon: const SIcon(SardIcons.add_circle_outline),
            label: const Text('عمل جديد'),
          ),
        );
      },
    );
  }

  Future<void> _openForm(
    BuildContext context,
    CreatorStudioStore store,
    CreatorSubmission? existing,
  ) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(context.pal.r(1.2)),
        ),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
        ),
        child: CreatorSubmissionForm(store: store, existing: existing),
      ),
    );
  }

  void _showDetail(
    BuildContext context,
    CreatorStudioStore store,
    CreatorSubmission item,
  ) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(context.pal.r(1.2)),
        ),
      ),
      builder: (ctx) => _SubmissionDetailSheet(item: item, store: store),
    );
  }

  void _showHelp(BuildContext context) {
    final p = context.pal;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.surface,
        title: Text('كيف يعمل الاستوديو؟', style: context.ds(size: 18)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _helpLine(p, '1', 'أنشئ عملاً جديداً كمسودة واملأ بياناته.'),
            _helpLine(p, '2', 'أرسله للمراجعة؛ يرد الفريق خلال 3 أيام عمل.'),
            _helpLine(p, '3', 'إن طُلب تعديل، عدّل وأعد الإرسال.'),
            _helpLine(p, '4', 'بعد القبول انشر عملك وتابع تحليلاته وأرباحه.'),
            const SizedBox(height: 10),
            Text(
              'ملاحظة: هذه النسخة تجريبية محلية؛ قرارات المراجعة الحالية '
              'محاكاة للتجربة فقط، ولا توجد مدفوعات حقيقية.',
              style: context.ts(size: 12.5, color: p.textDim, height: 1.6),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('فهمت'),
          ),
        ],
      ),
    );
  }

  Widget _helpLine(SardPalette p, String n, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 22,
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.14),
              shape: BoxShape.circle,
            ),
            child: Text(n, style: context.ts(size: 12, w: FontWeight.w800, color: p.accent)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(text, style: context.ts(height: 1.5)),
          ),
        ],
      ),
    );
  }
}

/// بطاقة تنبيه بأن الاستوديو تجريبي محلي.
class _DemoNoteCard extends StatelessWidget {
  const _DemoNoteCard({required this.store});
  final CreatorStudioStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tint(p.gold, 0.12),
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: tint(p.gold, 0.35)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SIcon(SardIcons.info_outline_rounded, size: 20, color: p.gold),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'وضع تجريبي محلي',
                  style: context.ts(w: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                Text(
                  'إرسالاتك محفوظة على جهازك فقط، وقرارات المراجعة محاكاة '
                  'للتجربة. لا توجد مدفوعات حقيقية في هذه النسخة.',
                  style: context.ts(size: 12.5, color: p.textDim, height: 1.5),
                ),
                if (store.submissions.any((e) => e.isDemo))
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                      onPressed: () => store.clearDemo(),
                      child: const Text('مسح الأمثلة التجريبية'),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// شبكة إحصاءات الاستوديو.
class _OverviewGrid extends StatelessWidget {
  const _OverviewGrid({required this.store});
  final CreatorStudioStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final cells = <(String, String, SIconData, Color)>[
      ('أعمالي', '${store.totalSubmissions}', SardIcons.menu_book_rounded, p.accent),
      ('منشورة', '${store.publishedCount}', SardIcons.visibility_rounded, const Color(0xFF0F9D75)),
      ('بانتظار المراجعة', '${store.pendingCount}', SardIcons.watch_later_rounded, p.gold),
      ('مشاهدات', formatCount(store.totalViews), SardIcons.visibility_rounded, p.accent),
      ('فصول', '${store.totalChapters}', SardIcons.format_list_bulleted_rounded, p.accent),
      ('متوسط التقييم', store.averageRating > 0 ? store.averageRating.toStringAsFixed(1) : '—', SardIcons.star_rounded, p.gold),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.25,
      ),
      itemCount: cells.length,
      itemBuilder: (context, i) {
        final (label, value, icon, color) = cells[i];
        return Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(0.8)),
            border: Border.all(color: p.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SIcon(icon, size: 18, color: color),
              const Spacer(),
              Text(value, style: context.ds(size: 17)),
              Text(label, style: context.ts(size: 11.5, color: p.textDim)),
            ],
          ),
        );
      },
    );
  }
}

/// صف تصفية حسب الحالة.
class _StatusFilterRow extends StatelessWidget {
  const _StatusFilterRow({
    required this.counts,
    required this.selected,
    required this.onSelect,
  });
  final Map<CreatorSubmissionStatus, int> counts;
  final CreatorSubmissionStatus? selected;
  final ValueChanged<CreatorSubmissionStatus?> onSelect;

  @override
  Widget build(BuildContext context) {
    final chips = <Widget>[
      _FilterChip(
        label: 'الكل',
        count: counts.values.fold<int>(0, (a, b) => a + b),
        active: selected == null,
        onTap: () => onSelect(null),
      ),
    ];
    for (final s in CreatorSubmissionStatus.values) {
      chips.add(
        _FilterChip(
          label: s.label,
          count: counts[s] ?? 0,
          active: selected == s,
          onTap: () => onSelect(s),
        ),
      );
    }
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: chips),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.count,
    required this.active,
    required this.onTap,
  });
  final String label;
  final int count;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: ChoiceChip(
        label: Text('$label ($count)'),
        selected: active,
        onSelected: (_) => onTap(),
        selectedColor: p.accent,
        labelStyle: context.ts(
          size: 12.5,
          w: FontWeight.w700,
          color: active ? p.onAccent : p.text,
        ),
        backgroundColor: p.surface,
        side: BorderSide(color: active ? p.accent : p.border),
        showCheckmark: false,
      ),
    );
  }
}

/// بطاقة إرسال واحد.
class _SubmissionCard extends StatelessWidget {
  const _SubmissionCard({
    required this.item,
    required this.store,
    required this.onEdit,
    required this.onOpen,
  });
  final CreatorSubmission item;
  final CreatorStudioStore store;
  final VoidCallback onEdit;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = creatorStatusColor(p, item.status);
    return InkWell(
      onTap: onOpen,
      borderRadius: BorderRadius.circular(p.r(0.9)),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 46,
                  height: 62,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: tint(color, 0.14),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: SIcon(SardIcons.menu_book_rounded, size: 24, color: color),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: context.ds(size: 16)),
                      const SizedBox(height: 2),
                      Text(
                        '${item.type} · ${item.genres.join('، ')}',
                        style: context.ts(size: 12.5, color: p.textDim),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'أُنشئ ${formatSardDate(item.createdAt)}',
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                    ],
                  ),
                ),
                _StatusChip(status: item.status),
              ],
            ),
            if (item.reviewNote.isNotEmpty &&
                (item.status == CreatorSubmissionStatus.changesRequested ||
                    item.status == CreatorSubmissionStatus.rejected)) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: tint(const Color(0xFFF0A21A), 0.10),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'ملاحظة الفريق: ${item.reviewNote}',
                  style: context.ts(size: 12.5, height: 1.5),
                ),
              ),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                _MiniStat(SardIcons.format_list_bulleted_rounded, '${item.chaptersCount} فصل'),
                _MiniStat(SardIcons.visibility_rounded, formatCount(item.views)),
                if (item.rating > 0)
                  _MiniStat(SardIcons.star_rounded, item.rating.toStringAsFixed(1)),
                const Spacer(),
                if (item.status.editable)
                  TextButton.icon(
                    onPressed: onEdit,
                    icon: const SIcon(SardIcons.edit_rounded, size: 16),
                    label: const Text('تعديل'),
                  ),
                if (item.status == CreatorSubmissionStatus.draft)
                  FilledButton(
                    onPressed: () {
                      store.sendForReview(item.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('أُرسل العمل إلى المراجعة.')),
                      );
                    },
                    child: const Text('إرسال للمراجعة'),
                  ),
                if (item.status == CreatorSubmissionStatus.approved)
                  FilledButton(
                    onPressed: () {
                      store.publish(item.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('نُشر عملك بنجاح. تهانينا!')),
                      );
                    },
                    child: const Text('نشر الآن'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat(this.icon, this.label);
  final SIconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(left: 12),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(icon, size: 15, color: p.textDim),
          const SizedBox(width: 4),
          Text(label, style: context.ts(size: 12, color: p.textDim)),
        ],
      ),
    );
  }
}

/// شارة الحالة.
class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.status});
  final CreatorSubmissionStatus status;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = creatorStatusColor(p, status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: tint(color, 0.14),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(creatorStatusIcon(status), size: 14, color: color),
          const SizedBox(width: 4),
          Text(status.label, style: context.ts(size: 12, w: FontWeight.w800, color: color)),
        ],
      ),
    );
  }
}

/// حالة فارغة (لا أعمال).
class _EmptySubmissions extends StatelessWidget {
  const _EmptySubmissions({required this.filtered, required this.onCreate});
  final bool filtered;
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
      child: Column(
        children: [
          Container(
            width: 84,
            height: 84,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.10),
              shape: BoxShape.circle,
            ),
            child: SIcon(SardIcons.auto_stories_rounded, size: 38, color: p.accent),
          ),
          const SizedBox(height: 16),
          Text(
            filtered ? 'لا أعمال بهذه الحالة' : 'ابدأ رحلتك كناشر',
            style: context.ds(size: 18),
          ),
          const SizedBox(height: 6),
          Text(
            filtered
                ? 'جرّب تصفية أخرى أو أرسل عملاً جديداً.'
                : 'أرسل عملك الأول إلى فريق Senok، وسنساعدك على الوصول إلى آلاف القراء.',
            textAlign: TextAlign.center,
            style: context.ts(color: p.textDim, height: 1.6),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: onCreate,
            icon: const SIcon(SardIcons.add_circle_outline),
            label: const Text('إرسال عمل جديد'),
          ),
        ],
      ),
    );
  }
}

/// ورقة تفاصيل الإرسال مع الخط الزمني.
class _SubmissionDetailSheet extends StatelessWidget {
  const _SubmissionDetailSheet({required this.item, required this.store});
  final CreatorSubmission item;
  final CreatorStudioStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      minChildSize: 0.4,
      maxChildSize: 0.95,
      expand: false,
      builder: (ctx, scroll) {
        return SingleChildScrollView(
          controller: scroll,
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: p.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Text(item.title, style: context.ds(size: 20)),
                  ),
                  _StatusChip(status: item.status),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                '${item.type} · ${item.genres.join('، ')}',
                style: context.ts(color: p.textDim),
              ),
              const SizedBox(height: 12),
              Text(item.synopsis, style: context.ts(height: 1.7)),
              const SizedBox(height: 16),
              Text(item.status.description, style: context.ts(color: p.textDim, height: 1.6)),
              if (item.reviewNote.isNotEmpty) ...[
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: tint(const Color(0xFFF0A21A), 0.10),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ملاحظة فريق المراجعة', style: context.ts(w: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text(item.reviewNote, style: context.ts(height: 1.6)),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Text('مسار الإرسال', style: context.ds(size: 17)),
              const SizedBox(height: 12),
              _StepTimeline(item: item, store: store),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _DetailStat('الفصول', '${item.chaptersCount}'),
                  ),
                  Expanded(
                    child: _DetailStat('المشاهدات', formatCount(item.views)),
                  ),
                  Expanded(
                    child: _DetailStat(
                      'التقييم',
                      item.rating > 0 ? item.rating.toStringAsFixed(1) : '—',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              if (item.status == CreatorSubmissionStatus.underReview)
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      store.withdraw(item.id);
                      Navigator.of(context).pop();
                    },
                    child: const Text('سحب الإرسال إلى مسودة'),
                  ),
                ),
              if (item.status == CreatorSubmissionStatus.draft ||
                  item.status == CreatorSubmissionStatus.rejected)
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      store.sendForReview(item.id);
                      Navigator.of(context).pop();
                    },
                    child: const Text('إرسال للمراجعة'),
                  ),
                ),
              if (item.status == CreatorSubmissionStatus.approved)
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      store.publish(item.id);
                      Navigator.of(context).pop();
                    },
                    child: const Text('نشر الآن'),
                  ),
                ),
              if (item.isDemo)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    'هذا مثال تجريبي مولّد محلياً.',
                    textAlign: TextAlign.center,
                    style: context.ts(size: 12, color: p.textDim),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _DetailStat extends StatelessWidget {
  const _DetailStat(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          Text(value, style: context.ds(size: 16)),
          const SizedBox(height: 2),
          Text(label, style: context.ts(size: 12, color: p.textDim)),
        ],
      ),
    );
  }
}

/// الخط الزمني لحالة الإرسال.
class _StepTimeline extends StatelessWidget {
  const _StepTimeline({required this.item, required this.store});
  final CreatorSubmission item;
  final CreatorStudioStore store;

  @override
  Widget build(BuildContext context) {
    final steps = CreatorSubmissionStatus.pipeline;
    final side = item.status == CreatorSubmissionStatus.rejected ||
        item.status == CreatorSubmissionStatus.changesRequested;
    return Column(
      children: [
        for (var i = 0; i < steps.length; i++) ...[
          _StepRow(
            step: steps[i],
            reached: store.reachedStep(item, steps[i]),
            current: item.status == steps[i],
            dateLabel: store.dateForStep(item, steps[i]),
            isLast: i == steps.length - 1,
          ),
        ],
        if (side)
          _StepRow(
            step: item.status,
            reached: true,
            current: true,
            dateLabel: store.dateForStep(item, item.status),
            isLast: true,
          ),
      ],
    );
  }
}

class _StepRow extends StatelessWidget {
  const _StepRow({
    required this.step,
    required this.reached,
    required this.current,
    required this.dateLabel,
    required this.isLast,
  });
  final CreatorSubmissionStatus step;
  final bool reached;
  final bool current;
  final String dateLabel;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = reached ? creatorStatusColor(p, step) : p.textDim;
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 30,
                height: 30,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: reached ? tint(color, 0.16) : p.surfaceHi,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: reached ? color : p.border,
                    width: current ? 2 : 1,
                  ),
                ),
                child: SIcon(creatorStatusIcon(step), size: 15, color: color),
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 2,
                    color: reached ? tint(color, 0.4) : p.border,
                  ),
                ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: isLast ? 0 : 18, top: 3),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    step.label,
                    style: context.ts(
                      w: current ? FontWeight.w800 : FontWeight.w600,
                      color: reached ? p.text : p.textDim,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(dateLabel, style: context.ts(size: 12, color: p.textDim)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ───────── نموذج إرسال عمل جديد ─────────

/// نموذج إرسال عمل: عنوان + نوع + تصنيفات + ملخص + رابط غلاف.
/// يحفظ كمسودة أولاً، ثم يُرسل للمراجعة (أو يُنشر مباشرة حسب الدور).
class CreatorSubmissionForm extends StatefulWidget {
  const CreatorSubmissionForm({
    super.key,
    required this.store,
    this.existing,
  });
  final CreatorStudioStore store;
  final CreatorSubmission? existing;

  @override
  State<CreatorSubmissionForm> createState() => _CreatorSubmissionFormState();
}

class _CreatorSubmissionFormState extends State<CreatorSubmissionForm> {
  late final TextEditingController _title;
  late final TextEditingController _synopsis;
  late final TextEditingController _cover;
  late String _type;
  late Set<String> _genres;
  String? _error;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _title = TextEditingController(text: e?.title ?? '');
    _synopsis = TextEditingController(text: e?.synopsis ?? '');
    _cover = TextEditingController(text: e?.coverUrl ?? '');
    _type = e?.type ?? kCreatorWorkTypes.first;
    _genres = e == null ? <String>{} : Set<String>.from(e.genres);
  }

  @override
  void dispose() {
    _title.dispose();
    _synopsis.dispose();
    _cover.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final editing = widget.existing != null;
    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (ctx, scroll) {
        return SingleChildScrollView(
          controller: scroll,
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: p.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                editing ? 'تعديل العمل' : 'إرسال عمل جديد',
                style: context.ds(size: 20),
              ),
              const SizedBox(height: 4),
              Text(
                'املأ البيانات بدقة؛ تُراجعها إدارة Senok قبل النشر.',
                style: context.ts(color: p.textDim),
              ),
              const SizedBox(height: 18),
              Text('عنوان العمل', style: context.ts(w: FontWeight.w700)),
              const SizedBox(height: 6),
              TextField(
                controller: _title,
                maxLength: 80,
                decoration: _decoration(p, 'مثال: سيف الفجر'),
              ),
              const SizedBox(height: 14),
              Text('نوع العمل', style: context.ts(w: FontWeight.w700)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: kCreatorWorkTypes.map((t) {
                  final active = _type == t;
                  return ChoiceChip(
                    label: Text(t),
                    selected: active,
                    onSelected: (_) => setState(() => _type = t),
                    selectedColor: p.accent,
                    labelStyle: context.ts(
                      size: 13,
                      w: FontWeight.w700,
                      color: active ? p.onAccent : p.text,
                    ),
                    backgroundColor: p.surface,
                    side: BorderSide(color: active ? p.accent : p.border),
                    showCheckmark: false,
                  );
                }).toList(),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Text('التصنيفات', style: context.ts(w: FontWeight.w700)),
                  const SizedBox(width: 6),
                  Text(
                    '(${_genres.length}/4)',
                    style: context.ts(size: 12, color: p.textDim),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: kCreatorGenres.map((g) {
                  final active = _genres.contains(g);
                  return FilterChip(
                    label: Text(g),
                    selected: active,
                    onSelected: (v) {
                      setState(() {
                        if (v) {
                          if (_genres.length < 4) _genres.add(g);
                        } else {
                          _genres.remove(g);
                        }
                      });
                    },
                    selectedColor: tint(p.accent, 0.2),
                    checkmarkColor: p.accent,
                    labelStyle: context.ts(
                      size: 13,
                      w: active ? FontWeight.w700 : FontWeight.w500,
                      color: active ? p.accent : p.text,
                    ),
                    backgroundColor: p.surface,
                    side: BorderSide(color: active ? p.accent : p.border),
                  );
                }).toList(),
              ),
              const SizedBox(height: 14),
              Text('ملخص العمل', style: context.ts(w: FontWeight.w700)),
              const SizedBox(height: 6),
              TextField(
                controller: _synopsis,
                maxLines: 5,
                minLines: 3,
                maxLength: 2000,
                decoration: _decoration(
                  p,
                  'اكتب ملخصاً مشوقاً (30 حرفاً على الأقل) يعرّف القراء بعالم عملك وأبطاله...',
                ),
              ),
              const SizedBox(height: 14),
              Text('رابط الغلاف (اختياري)', style: context.ts(w: FontWeight.w700)),
              const SizedBox(height: 6),
              TextField(
                controller: _cover,
                keyboardType: TextInputType.url,
                decoration: _decoration(p, 'https://...'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: tint(const Color(0xFFE5484D), 0.10),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      const SIcon(
                        SardIcons.priority_high_rounded,
                        size: 16,
                        color: Color(0xFFE5484D),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _error!,
                          style: context.ts(
                            size: 13,
                            color: const Color(0xFFE5484D),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _saving ? null : _saveDraft,
                      child: Text(editing ? 'حفظ التعديلات' : 'حفظ كمسودة'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: _saving ? null : _saveAndSend,
                      child: Text(editing ? 'حفظ وإعادة الإرسال' : 'حفظ وإرسال للمراجعة'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  InputDecoration _decoration(SardPalette p, String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: context.ts(color: p.textDim),
      filled: true,
      fillColor: p.surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.accent, width: 1.5),
      ),
    );
  }

  void _saveDraft() {
    setState(() => _saving = true);
    final err = validateSubmission(
      title: _title.text,
      synopsis: _synopsis.text,
      genres: _genres.toList(),
      type: _type,
    );
    if (err != null) {
      setState(() {
        _error = err;
        _saving = false;
      });
      return;
    }
    final ok = _persist();
    setState(() => _saving = false);
    if (!mounted) return;
    if (ok) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('حُفظ العمل كمسودة.')),
      );
    }
  }

  void _saveAndSend() {
    setState(() => _saving = true);
    final err = validateSubmission(
      title: _title.text,
      synopsis: _synopsis.text,
      genres: _genres.toList(),
      type: _type,
    );
    if (err != null) {
      setState(() {
        _error = err;
        _saving = false;
      });
      return;
    }
    final existing = widget.existing;
    String? id;
    if (existing == null) {
      final created = widget.store.createDraft(
        title: _title.text,
        type: _type,
        genres: _genres.toList(),
        synopsis: _synopsis.text,
        coverUrl: _cover.text,
      );
      id = created?.id;
    } else {
      final ok = widget.store.updateDraft(
        existing.id,
        title: _title.text,
        type: _type,
        genres: _genres.toList(),
        synopsis: _synopsis.text,
        coverUrl: _cover.text,
      );
      id = ok ? existing.id : null;
    }
    var sent = false;
    if (id != null) sent = widget.store.sendForReview(id);
    setState(() => _saving = false);
    if (!mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          sent ? 'أُرسل العمل إلى المراجعة. بالتوفيق!' : 'حُفظ العمل، وتعذّر إرساله الآن.',
        ),
      ),
    );
  }

  bool _persist() {
    final existing = widget.existing;
    if (existing == null) {
      return widget.store.createDraft(
            title: _title.text,
            type: _type,
            genres: _genres.toList(),
            synopsis: _synopsis.text,
            coverUrl: _cover.text,
          ) !=
          null;
    }
    return widget.store.updateDraft(
      existing.id,
      title: _title.text,
      type: _type,
      genres: _genres.toList(),
      synopsis: _synopsis.text,
      coverUrl: _cover.text,
    );
  }
}
