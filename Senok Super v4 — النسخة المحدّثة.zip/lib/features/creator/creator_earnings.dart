import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'creator_studio.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// أرباح الناشر — عملات مكتسبة من المشاهدات والإكراميات والاشتراكات.
/// عرض تجريبي محلي بالكامل: لا مدفوعات حقيقية، ولا تحويلات بنكية.
/// سعر الصرف التجريبي: 100 عملة = 1 ريال.
/// ──────────────────────────────────────────────────────────────────────────

/// سعر صرف تجريبي: كم ريالاً تساوي العملة الواحدة.
const double kCoinToSarRate = 0.01;

/// أقل عدد عملات لطلب سحب تجريبي.
const int kMinPayoutCoins = 5000;

/// مصدر ربح.
enum CreatorEarningSource {
  views('مشاهدات', 'أرباح من قراءة فصولك.'),
  tips('إكراميات', 'دعم مباشر من القراء.'),
  subscription('اشتراكات', 'حصتك من اشتراكات بلس.'),
  bonus('مكافآت', 'مكافآت المنصة والتحديات.');

  const CreatorEarningSource(this.label, this.description);
  final String label;
  final String description;
}

SIconData creatorEarningSourceIcon(CreatorEarningSource s) {
  switch (s) {
    case CreatorEarningSource.views:
      return SardIcons.visibility_rounded;
    case CreatorEarningSource.tips:
      return SardIcons.favorite_rounded;
    case CreatorEarningSource.subscription:
      return SardIcons.star_rounded;
    case CreatorEarningSource.bonus:
      return SardIcons.auto_awesome_rounded;
  }
}

/// حالة مبلغ مكتسب.
enum CreatorEarningStatus {
  pending('معلّق', 'سيتوفر بعد 7 أيام من اكتسابه.'),
  available('متاح', 'يمكن سحبه ضمن طلب سحب.'),
  paid('مدفوع', 'أُدرج في طلب سحب سابق.');

  const CreatorEarningStatus(this.label, this.description);
  final String label;
  final String description;
}

/// مبلغ مكتسب واحد.
class CreatorEarning {
  const CreatorEarning({
    required this.id,
    required this.date,
    required this.source,
    required this.amountCoins,
    required this.status,
    this.seriesId = '',
    this.seriesTitle = '',
    this.note = '',
  });

  final String id;
  final DateTime date;
  final CreatorEarningSource source;

  /// عدد العملات
  final int amountCoins;
  final CreatorEarningStatus status;
  final String seriesId;
  final String seriesTitle;
  final String note;

  double get amountSar => amountCoins * kCoinToSarRate;

  CreatorEarning copyWith({CreatorEarningStatus? status}) => CreatorEarning(
        id: id,
        date: date,
        source: source,
        amountCoins: amountCoins,
        status: status ?? this.status,
        seriesId: seriesId,
        seriesTitle: seriesTitle,
        note: note,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.millisecondsSinceEpoch,
        'source': source.name,
        'amount_coins': amountCoins,
        'status': status.name,
        'series_id': seriesId,
        'series_title': seriesTitle,
        'note': note,
      };

  factory CreatorEarning.fromJson(Map<String, dynamic> j) {
    CreatorEarningSource src = CreatorEarningSource.views;
    for (final v in CreatorEarningSource.values) {
      if (v.name == '${j['source']}') src = v;
    }
    CreatorEarningStatus st = CreatorEarningStatus.available;
    for (final v in CreatorEarningStatus.values) {
      if (v.name == '${j['status']}') st = v;
    }
    return CreatorEarning(
      id: '${j['id']}',
      date: DateTime.fromMillisecondsSinceEpoch(
        (j['date'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch,
      ),
      source: src,
      amountCoins: (j['amount_coins'] as num?)?.toInt() ?? 0,
      status: st,
      seriesId: '${j['series_id'] ?? ''}',
      seriesTitle: '${j['series_title'] ?? ''}',
      note: '${j['note'] ?? ''}',
    );
  }
}

/// حالة طلب سحب.
enum CreatorPayoutStatus {
  requested('قيد المعالجة', 'طلبك قيد المراجعة التجريبية.'),
  completed('مكتمل', 'اكتمل السحب التجريبي.'),
  rejected('مرفوض', 'رُفض الطلب التجريبي.');

  const CreatorPayoutStatus(this.label, this.description);
  final String label;
  final String description;
}

/// طلب سحب (تجريبي).
class CreatorPayout {
  const CreatorPayout({
    required this.id,
    required this.requestedAt,
    required this.amountCoins,
    required this.method,
    required this.status,
    this.note = '',
  });

  final String id;
  final DateTime requestedAt;
  final int amountCoins;

  /// طريقة الاستلام التجريبية: «تحويل بنكي تجريبي» / «محفظة تجريبية»
  final String method;
  final CreatorPayoutStatus status;
  final String note;

  double get amountSar => amountCoins * kCoinToSarRate;

  CreatorPayout copyWith({CreatorPayoutStatus? status, String? note}) =>
      CreatorPayout(
        id: id,
        requestedAt: requestedAt,
        amountCoins: amountCoins,
        method: method,
        status: status ?? this.status,
        note: note ?? this.note,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'requested_at': requestedAt.millisecondsSinceEpoch,
        'amount_coins': amountCoins,
        'method': method,
        'status': status.name,
        'note': note,
      };

  factory CreatorPayout.fromJson(Map<String, dynamic> j) {
    CreatorPayoutStatus st = CreatorPayoutStatus.requested;
    for (final v in CreatorPayoutStatus.values) {
      if (v.name == '${j['status']}') st = v;
    }
    return CreatorPayout(
      id: '${j['id']}',
      requestedAt: DateTime.fromMillisecondsSinceEpoch(
        (j['requested_at'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
      ),
      amountCoins: (j['amount_coins'] as num?)?.toInt() ?? 0,
      method: '${j['method'] ?? ''}',
      status: st,
      note: '${j['note'] ?? ''}',
    );
  }
}

/// طرق السحب التجريبية المتاحة.
const List<String> kPayoutMethods = [
  'تحويل بنكي تجريبي',
  'محفظة رقمية تجريبية',
  'رصيد متجر تجريبي',
];

/// تنسيق العملات: 12500 -> "12,500 عملة"
String formatCoins(int coins) {
  final s = coins.abs().toString();
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
    buf.write(s[i]);
  }
  final sign = coins < 0 ? '-' : '';
  return '$sign${buf} عملة';
}

/// تنسيق مبلغ بالريال: 12.5 -> "12.50 ر.س"
String formatSar(double v) => '${v.toStringAsFixed(2)} ر.س';

const String _kEarningsKey = 'creator_earnings_v1';
const String _kPayoutsKey = 'creator_payouts_v1';

/// مخزن أرباح الناشر.
class CreatorEarningsStore extends ChangeNotifier {
  CreatorEarningsStore(this._p) {
    _read();
  }

  final SharedPreferences _p;
  List<CreatorEarning> _earnings = [];

  /// عدّاد أحادي لتفادي تطابق المعرّفات المولّدة في الميلي ثانية نفسها.
  static int _seq = 0;
  List<CreatorPayout> _payouts = [];

  static CreatorEarningsStore? _i;
  static CreatorEarningsStore get i => _i!;

  static Future<CreatorEarningsStore> load() async {
    final p = await SharedPreferences.getInstance();
    _i ??= CreatorEarningsStore(p);
    return _i!;
  }

  static CreatorEarningsStore testInstance(SharedPreferences p) =>
      CreatorEarningsStore(p);

  List<CreatorEarning> get earnings => List.unmodifiable(_earnings);
  List<CreatorPayout> get payouts => List.unmodifiable(_payouts);

  /// الرصيد المتاح للسحب (عملات).
  int get availableCoins => _earnings
      .where((e) => e.status == CreatorEarningStatus.available)
      .fold<int>(0, (a, e) => a + e.amountCoins);

  /// المعلّق (عملات).
  int get pendingCoins => _earnings
      .where((e) => e.status == CreatorEarningStatus.pending)
      .fold<int>(0, (a, e) => a + e.amountCoins);

  /// إجمالي ما سُحب (عملات).
  int get paidCoins => _payouts
      .where((e) => e.status != CreatorPayoutStatus.rejected)
      .fold<int>(0, (a, e) => a + e.amountCoins);

  /// إجمالي ما كُسب (عملات).
  int get totalEarnedCoins =>
      _earnings.fold<int>(0, (a, e) => a + e.amountCoins);

  double get availableSar => availableCoins * kCoinToSarRate;
  double get totalEarnedSar => totalEarnedCoins * kCoinToSarRate;

  /// أرباح حسب المصدر (عملات).
  Map<CreatorEarningSource, int> get earningsBySource {
    final m = <CreatorEarningSource, int>{
      for (final s in CreatorEarningSource.values) s: 0,
    };
    for (final e in _earnings) {
      m[e.source] = (m[e.source] ?? 0) + e.amountCoins;
    }
    return m;
  }

  /// أرباح آخر 6 أشهر (عملات) — لأعمدة الرسم البياني.
  List<(String, int)> monthlyEarnings({DateTime? now}) {
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
    ];
    final today = now ?? DateTime.now();
    final out = <(String, int)>[];
    for (var i = 5; i >= 0; i--) {
      final m = DateTime(today.year, today.month - i, 1);
      final label = months[m.month - 1];
      var sum = 0;
      for (final e in _earnings) {
        if (e.date.year == m.year && e.date.month == m.month) {
          sum += e.amountCoins;
        }
      }
      out.add((label, sum));
    }
    return out;
  }

  /// أرباح عمل واحد (عملات).
  int earningsOfSeries(String seriesId) => _earnings
      .where((e) => e.seriesId == seriesId)
      .fold<int>(0, (a, e) => a + e.amountCoins);

  bool get canRequestPayout => availableCoins >= kMinPayoutCoins;

  void _read() {
    try {
      final raw = _p.getString(_kEarningsKey);
      if (raw == null || raw.isEmpty) {
        _earnings = _demoEarnings();
        _payouts = _demoPayouts();
        _save();
        return;
      }
      final list = jsonDecode(raw) as List;
      _earnings = list
          .whereType<Map>()
          .map((e) => CreatorEarning.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      final rawP = _p.getString(_kPayoutsKey);
      if (rawP != null && rawP.isNotEmpty) {
        final listP = jsonDecode(rawP) as List;
        _payouts = listP
            .whereType<Map>()
            .map((e) => CreatorPayout.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {
      _earnings = _demoEarnings();
      _payouts = _demoPayouts();
    }
  }

  void _save() {
    _p.setString(
      _kEarningsKey,
      jsonEncode(_earnings.map((e) => e.toJson()).toList()),
    );
    _p.setString(
      _kPayoutsKey,
      jsonEncode(_payouts.map((e) => e.toJson()).toList()),
    );
  }

  static List<CreatorEarning> _demoEarnings() {
    final now = DateTime.now();
    final rnd = math.Random(42);
    final out = <CreatorEarning>[];
    // 6 أشهر من الأرباح اليومية/الأسبوعية التجريبية.
    for (var i = 0; i < 42; i++) {
      final day = now.subtract(Duration(days: i * 4 + rnd.nextInt(3)));
      final src = CreatorEarningSource.values[rnd.nextInt(4)];
      final coins = 120 + rnd.nextInt(900);
      out.add(
        CreatorEarning(
          id: 'earn_$i',
          date: day,
          source: src,
          amountCoins: coins,
          status: i < 3
              ? CreatorEarningStatus.pending
              : CreatorEarningStatus.available,
          seriesId: i.isEven ? 'demo_1' : 'demo_2',
          seriesTitle: i.isEven ? 'سيف الفجر' : 'مقهى منتصف الليل',
          note: src == CreatorEarningSource.tips
              ? 'إكرامية من قارئ'
              : '',
        ),
      );
    }
    out.sort((a, b) => b.date.compareTo(a.date));
    return out;
  }

  static List<CreatorPayout> _demoPayouts() {
    final now = DateTime.now();
    return [
      CreatorPayout(
        id: 'pay_1',
        requestedAt: now.subtract(const Duration(days: 40)),
        amountCoins: 8000,
        method: 'تحويل بنكي تجريبي',
        status: CreatorPayoutStatus.completed,
      ),
      CreatorPayout(
        id: 'pay_2',
        requestedAt: now.subtract(const Duration(days: 9)),
        amountCoins: 5000,
        method: 'محفظة رقمية تجريبية',
        status: CreatorPayoutStatus.requested,
      ),
    ];
  }

  /// يضيف ربحاً جديداً (مثلاً عند تسجيل مشاهدات جديدة).
  void addEarning(CreatorEarning e) {
    _earnings.insert(0, e);
    _save();
    notifyListeners();
  }

  /// يحوّل المعلّق الذي تجاوز 7 أيام إلى متاح.
  int releasePending({DateTime? now}) {
    final today = now ?? DateTime.now();
    var n = 0;
    for (var i = 0; i < _earnings.length; i++) {
      final e = _earnings[i];
      if (e.status == CreatorEarningStatus.pending &&
          today.difference(e.date).inDays >= 7) {
        _earnings[i] = e.copyWith(status: CreatorEarningStatus.available);
        n++;
      }
    }
    if (n > 0) {
      _save();
      notifyListeners();
    }
    return n;
  }

  /// يطلب سحباً تجريبياً. يُعيد رسالة خطأ أو null عند النجاح.
  String? requestPayout({required int amountCoins, required String method}) {
    if (!kPayoutMethods.contains(method)) return 'اختر طريقة استلام.';
    if (amountCoins < kMinPayoutCoins) {
      return 'الحد الأدنى للسحب ${formatCoins(kMinPayoutCoins)}.';
    }
    if (amountCoins > availableCoins) {
      return 'رصيدك المتاح ${formatCoins(availableCoins)} فقط.';
    }
    if (amountCoins % 100 != 0) {
      return 'اطلب مبلغاً من مضاعفات 100 عملة.';
    }
    // نعلّم أقدم الأرباح المتاحة كمدفوعة حتى تغطي المبلغ.
    var rest = amountCoins;
    final sorted = List<CreatorEarning>.from(_earnings)
      ..sort((a, b) => a.date.compareTo(b.date));
    for (final e in sorted) {
      if (rest <= 0) break;
      if (e.status != CreatorEarningStatus.available) continue;
      final idx = _earnings.indexWhere((x) => x.id == e.id);
      if (e.amountCoins <= rest) {
        _earnings[idx] = e.copyWith(status: CreatorEarningStatus.paid);
        rest -= e.amountCoins;
      } else {
        // نقسم المبلغ: جزء مدفوع وجزء متبقٍ متاح.
        _earnings[idx] = e.copyWith(status: CreatorEarningStatus.paid);
        _earnings.add(
          CreatorEarning(
            id: 'earn_split_${DateTime.now().millisecondsSinceEpoch}_${_seq++}',
            date: e.date,
            source: e.source,
            amountCoins: e.amountCoins - rest,
            status: CreatorEarningStatus.available,
            seriesId: e.seriesId,
            seriesTitle: e.seriesTitle,
            note: 'متبقٍ من سحب جزئي',
          ),
        );
        rest = 0;
      }
    }
    _payouts.insert(
      0,
      CreatorPayout(
        id: 'pay_${DateTime.now().millisecondsSinceEpoch}_${_seq++}',
        requestedAt: DateTime.now(),
        amountCoins: amountCoins,
        method: method,
        status: CreatorPayoutStatus.requested,
        note: 'طلب تجريبي — لن يصل أي مبلغ حقيقي.',
      ),
    );
    _save();
    notifyListeners();
    return null;
  }

  /// يحاكي اكتمال أقدم طلب سحب معلّق (للتجربة).
  bool simulatePayoutComplete(String id) {
    final i = _payouts.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    if (_payouts[i].status != CreatorPayoutStatus.requested) return false;
    _payouts[i] =
        _payouts[i].copyWith(status: CreatorPayoutStatus.completed);
    _save();
    notifyListeners();
    return true;
  }

  void clearDemo() {
    _earnings.clear();
    _payouts.clear();
    _save();
    notifyListeners();
  }
}

// ───────── واجهة الأرباح ─────────

/// شاشة أرباح الناشر.
class CreatorEarningsScreen extends StatefulWidget {
  const CreatorEarningsScreen({super.key, required this.store});
  final CreatorEarningsStore store;

  @override
  State<CreatorEarningsScreen> createState() => _CreatorEarningsScreenState();
}

class _CreatorEarningsScreenState extends State<CreatorEarningsScreen> {
  @override
  void initState() {
    super.initState();
    widget.store.releasePending();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = widget.store;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final monthly = store.monthlyEarnings();
        final bySource = store.earningsBySource;
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(title: const Text('أرباح الناشر')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              _BalanceCard(store: store),
              const SizedBox(height: 14),
              _MonthlyChart(monthly: monthly),
              const SizedBox(height: 14),
              Text('الأرباح حسب المصدر', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              for (final s in CreatorEarningSource.values)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _SourceRow(
                    source: s,
                    coins: bySource[s] ?? 0,
                    total: store.totalEarnedCoins,
                  ),
                ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Text('سجل الأرباح', style: context.ds(size: 18)),
                  const Spacer(),
                  Text(
                    '${store.earnings.length} عملية',
                    style: context.ts(color: p.textDim),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (store.earnings.isEmpty)
                _EarningsEmpty()
              else
                for (var i = 0; i < store.earnings.length && i < 20; i++)
                  Padding(
                    padding: EdgeInsets.only(
                      bottom: i == 19 || i == store.earnings.length - 1 ? 0 : 10,
                    ),
                    child: _EarningTile(earning: store.earnings[i]),
                  ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Text('طلبات السحب', style: context.ds(size: 18)),
                  const Spacer(),
                  Text(
                    '${store.payouts.length} طلب',
                    style: context.ts(color: p.textDim),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (store.payouts.isEmpty)
                const _EarningsEmpty2()
              else
                for (var i = 0; i < store.payouts.length; i++)
                  Padding(
                    padding: EdgeInsets.only(
                      bottom: i == store.payouts.length - 1 ? 0 : 10,
                    ),
                    child: _PayoutTile(payout: store.payouts[i]),
                  ),
              const SizedBox(height: 14),
              Text(
                'تنبيه: كل الأرقام هنا تجريبية ومحفوظة على جهازك فقط. '
                'لا توجد مدفوعات حقيقية في هذه النسخة، وسعر الصرف '
                '(100 عملة = 1 ريال) توضيحي فقط.',
                style: context.ts(size: 12, color: p.textDim, height: 1.6),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.store});
  final CreatorEarningsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: p.accent,
        borderRadius: BorderRadius.circular(p.r(1.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.sell_rounded, size: 20, color: p.onAccent),
              const SizedBox(width: 8),
              Text(
                'رصيدك المتاح',
                style: context.ts(color: p.onAccent, w: FontWeight.w700),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: tint(Colors.white, 0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'تجريبي',
                  style: context.ts(size: 12, w: FontWeight.w800, color: p.onAccent),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            formatCoins(store.availableCoins),
            style: context.ds(size: 30, color: p.onAccent),
          ),
          Text(
            '≈ ${formatSar(store.availableSar)}',
            style: context.ts(color: p.onAccent, w: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _BalanceMini(
                label: 'معلّق',
                value: formatCoins(store.pendingCoins),
                color: p.onAccent,
              ),
              const SizedBox(width: 18),
              _BalanceMini(
                label: 'إجمالي الكسب',
                value: formatCoins(store.totalEarnedCoins),
                color: p.onAccent,
              ),
              const SizedBox(width: 18),
              _BalanceMini(
                label: 'سُحب',
                value: formatCoins(store.paidCoins),
                color: p.onAccent,
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: p.onAccent,
                foregroundColor: p.accent,
              ),
              onPressed: store.canRequestPayout
                  ? () => _openPayoutSheet(context, store)
                  : null,
              child: Text(
                store.canRequestPayout
                    ? 'طلب سحب تجريبي'
                    : 'الحد الأدنى للسحب ${formatCoins(kMinPayoutCoins)}',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _openPayoutSheet(BuildContext context, CreatorEarningsStore store) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(context.pal.r(1.2)),
        ),
      ),
      builder: (ctx) => _PayoutSheet(store: store),
    );
  }
}

class _BalanceMini extends StatelessWidget {
  const _BalanceMini({
    required this.label,
    required this.value,
    required this.color,
  });
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: context.ts(w: FontWeight.w800, color: color)),
        Text(label, style: context.ts(size: 12, color: color)),
      ],
    );
  }
}

/// ورقة طلب سحب تجريبي.
class _PayoutSheet extends StatefulWidget {
  const _PayoutSheet({required this.store});
  final CreatorEarningsStore store;

  @override
  State<_PayoutSheet> createState() => _PayoutSheetState();
}

class _PayoutSheetState extends State<_PayoutSheet> {
  late String _method;
  late final TextEditingController _amount;
  String? _error;

  @override
  void initState() {
    super.initState();
    _method = kPayoutMethods.first;
    _amount = TextEditingController(
      text: '${widget.store.availableCoins}',
    );
  }

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final amount = int.tryParse(_amount.text.trim()) ?? 0;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 28,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: p.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text('طلب سحب تجريبي', style: context.ds(size: 20)),
          const SizedBox(height: 4),
          Text(
            'المتاح: ${formatCoins(widget.store.availableCoins)} '
            '(≈ ${formatSar(widget.store.availableSar)})',
            style: context.ts(color: p.textDim),
          ),
          const SizedBox(height: 16),
          Text('طريقة الاستلام', style: context.ts(w: FontWeight.w700)),
          const SizedBox(height: 6),
          ...kPayoutMethods.map(
            (m) => RadioListTile<String>(
              value: m,
              groupValue: _method,
              onChanged: (v) => setState(() => _method = v!),
              title: Text(m, style: context.ts()),
              contentPadding: EdgeInsets.zero,
              activeColor: p.accent,
            ),
          ),
          const SizedBox(height: 8),
          Text('المبلغ (عملات)', style: context.ts(w: FontWeight.w700)),
          const SizedBox(height: 6),
          TextField(
            controller: _amount,
            keyboardType: TextInputType.number,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'مثال: 5000',
              filled: true,
              fillColor: p.surface,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: p.border),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '≈ ${formatSar(amount * kCoinToSarRate)} · من مضاعفات 100 عملة',
            style: context.ts(size: 12.5, color: p.textDim),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: context.ts(color: const Color(0xFFE5484D))),
          ],
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () {
                final err = widget.store.requestPayout(
                  amountCoins: amount,
                  method: _method,
                );
                if (err != null) {
                  setState(() => _error = err);
                  return;
                }
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('أُرسل طلب السحب التجريبي. لن يصل أي مبلغ حقيقي.'),
                  ),
                );
              },
              child: const Text('تأكيد الطلب التجريبي'),
            ),
          ),
        ],
      ),
    );
  }
}

class _MonthlyChart extends StatelessWidget {
  const _MonthlyChart({required this.monthly});
  final List<(String, int)> monthly;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final max = monthly.map((e) => e.$2).fold<int>(0, (a, b) => a > b ? a : b);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('أرباح آخر 6 أشهر', style: context.ds(size: 16)),
          const SizedBox(height: 12),
          SizedBox(
            height: 120,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: monthly.map((m) {
                final h = max == 0 ? 4.0 : (m.$2 / max * 84).clamp(4.0, 84.0);
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          formatCount(m.$2),
                          style: context.ts(size: 9.5, color: p.textDim),
                        ),
                        const SizedBox(height: 3),
                        Container(
                          height: h,
                          decoration: BoxDecoration(
                            color: tint(p.accent, 0.75),
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(m.$1, style: context.ts(size: 10, color: p.textDim)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _SourceRow extends StatelessWidget {
  const _SourceRow({
    required this.source,
    required this.coins,
    required this.total,
  });
  final CreatorEarningSource source;
  final int coins;
  final int total;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final share = total == 0 ? 0.0 : coins / total;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: SIcon(creatorEarningSourceIcon(source), size: 19, color: p.accent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(source.label, style: context.ts(w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(source.description, style: context.ts(size: 12, color: p.textDim)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(formatCoins(coins), style: context.ts(w: FontWeight.w800)),
              Text(
                '${(share * 100).toStringAsFixed(0)}٪',
                style: context.ts(size: 12, color: p.textDim),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _EarningTile extends StatelessWidget {
  const _EarningTile({required this.earning});
  final CreatorEarning earning;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final positive = earning.amountCoins >= 0;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: SIcon(
              creatorEarningSourceIcon(earning.source),
              size: 19,
              color: p.accent,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  earning.seriesTitle.isEmpty
                      ? earning.source.label
                      : '${earning.source.label} · ${earning.seriesTitle}',
                  style: context.ts(w: FontWeight.w700),
                ),
                const SizedBox(height: 2),
                Text(
                  '${formatSardDate(earning.date)} · ${earning.status.label}'
                  '${earning.note.isNotEmpty ? ' · ${earning.note}' : ''}',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          Text(
            '+${formatCoins(earning.amountCoins)}',
            style: context.ts(
              w: FontWeight.w800,
              color: positive ? const Color(0xFF0F9D75) : const Color(0xFFE5484D),
            ),
          ),
        ],
      ),
    );
  }
}

class _PayoutTile extends StatelessWidget {
  const _PayoutTile({required this.payout});
  final CreatorPayout payout;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = payout.status == CreatorPayoutStatus.completed
        ? const Color(0xFF0F9D75)
        : payout.status == CreatorPayoutStatus.rejected
            ? const Color(0xFFE5484D)
            : p.gold;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          SIcon(SardIcons.sell_rounded, size: 20, color: color),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${formatCoins(payout.amountCoins)} · ${payout.method}',
                  style: context.ts(w: FontWeight.w700),
                ),
                const SizedBox(height: 2),
                Text(
                  '${formatSardDate(payout.requestedAt)} · ${payout.status.label}',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          Text(
            formatSar(payout.amountSar),
            style: context.ts(w: FontWeight.w700, color: color),
          ),
        ],
      ),
    );
  }
}

class _EarningsEmpty extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Text(
        'لا أرباح بعد. انشر عملاً وستبدأ الأرباح بالظهور هنا.',
        textAlign: TextAlign.center,
        style: context.ts(color: p.textDim),
      ),
    );
  }
}

class _EarningsEmpty2 extends StatelessWidget {
  const _EarningsEmpty2();

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Text(
        'لا طلبات سحب بعد.',
        textAlign: TextAlign.center,
        style: context.ts(color: p.textDim),
      ),
    );
  }
}
