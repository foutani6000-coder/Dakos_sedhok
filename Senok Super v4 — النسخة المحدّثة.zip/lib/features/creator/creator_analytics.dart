import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'creator_chapters.dart';
import 'creator_studio.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// تحليلات الناشر — مشاهدات، نمو، أفضل الأعمال والفصول.
/// الأرقام اليومية مولّدة محلياً بقاعدة حتمية (بذرة من التاريخ) لأغراض
/// العرض التجريبي؛ عند ربط الخادم تُستبدل ببيانات حقيقية.
/// ──────────────────────────────────────────────────────────────────────────

/// مشاهدات يوم واحد.
class CreatorDailyViews {
  const CreatorDailyViews({required this.date, required this.views});
  final DateTime date;
  final int views;

  String get dayLabel => '${date.day}/${date.month}';
}

/// ملخص تحليلات فترة.
class CreatorPeriodSummary {
  const CreatorPeriodSummary({
    required this.days,
    required this.totalViews,
    required this.averageDaily,
    required this.bestDay,
    required this.bestDayViews,
    required this.growthPercent,
  });
  final int days;
  final int totalViews;
  final double averageDaily;
  final DateTime? bestDay;
  final int bestDayViews;

  /// نسبة النمو مقارنة بالفترة السابقة المماثلة.
  final double growthPercent;
}

/// توزيع التقييمات (1..5 نجوم).
class CreatorRatingBreakdown {
  const CreatorRatingBreakdown({required this.counts});
  final Map<int, int> counts;

  int get total => counts.values.fold<int>(0, (a, b) => a + b);

  double share(int stars) {
    if (total == 0) return 0;
    return (counts[stars] ?? 0) / total;
  }
}

/// مخزن التحليلات: حسابات قواعديّة بحتة من بيانات الاستوديو والفصول.
class CreatorAnalyticsStore extends ChangeNotifier {
  CreatorAnalyticsStore({
    required this.studio,
    required this.chapters,
  });

  final CreatorStudioStore studio;
  final CreatorChapterStore chapters;

  /// مشاهدات يومية حتمية لعمل واحد: بذرة من معرّف العمل والتاريخ.
  /// قاعدة: أساس ثابت + ذروة نهاية أسبوع + تذبذب حتمي.
  static int demoViewsFor(String seriesId, DateTime day) {
    final seed = seriesId.codeUnits.fold<int>(7, (a, b) => a * 31 + b);
    final d = DateTime(day.year, day.month, day.day);
    final daySeed = seed + d.millisecondsSinceEpoch ~/ 86400000;
    final rnd = math.Random(daySeed);
    final base = 60 + (seed % 240);
    final weekend = d.weekday >= 5 ? 1.45 : 1.0;
    final wave = 1 + 0.35 * math.sin(d.day / 3.0);
    return ((base * weekend * wave) + rnd.nextInt(90)).round();
  }

  /// مشاهدات يومية لكل أعمال الناشر (مجموع الأعمال المنشورة).
  List<CreatorDailyViews> viewsLastNDays(int n, {DateTime? now}) {
    final today = now ?? DateTime.now();
    final published = studio.byStatus(CreatorSubmissionStatus.published);
    final out = <CreatorDailyViews>[];
    for (var i = n - 1; i >= 0; i--) {
      final day = DateTime(today.year, today.month, today.day - i);
      var v = 0;
      for (final s in published) {
        v += demoViewsFor(s.id, day);
      }
      out.add(CreatorDailyViews(date: day, views: v));
    }
    return out;
  }

  /// مشاهدات يومية لعمل واحد.
  List<CreatorDailyViews> viewsForSeries(String seriesId, int n, {DateTime? now}) {
    final today = now ?? DateTime.now();
    return List<CreatorDailyViews>.generate(n, (k) {
      final day = DateTime(today.year, today.month, today.day - (n - 1 - k));
      return CreatorDailyViews(date: day, views: demoViewsFor(seriesId, day));
    });
  }

  /// ملخص فترة (7 أو 30 أو 90 يوماً).
  CreatorPeriodSummary summary(int days, {DateTime? now}) {
    final today = now ?? DateTime.now();
    final cur = viewsLastNDays(days, now: today);
    final total = cur.fold<int>(0, (a, e) => a + e.views);
    CreatorDailyViews? best;
    for (final e in cur) {
      if (best == null || e.views > best.views) best = e;
    }
    // الفترة السابقة المماثلة لحساب النمو.
    var prev = 0;
    for (var i = days; i < days * 2; i++) {
      final day = DateTime(today.year, today.month, today.day - i);
      for (final s in studio.byStatus(CreatorSubmissionStatus.published)) {
        prev += demoViewsFor(s.id, day);
      }
    }
    final growth = prev == 0
        ? (total > 0 ? 100.0 : 0.0)
        : ((total - prev) / prev * 100);
    return CreatorPeriodSummary(
      days: days,
      totalViews: total,
      averageDaily: days == 0 ? 0 : total / days,
      bestDay: best?.date,
      bestDayViews: best?.views ?? 0,
      growthPercent: growth,
    );
  }

  /// الأعمال مرتّبة بالمشاهدات (الأكثر أولاً).
  List<CreatorSubmission> topSeries({int limit = 5}) {
    final list = List<CreatorSubmission>.from(studio.submissions);
    list.sort((a, b) => b.views.compareTo(a.views));
    return list.take(limit).toList();
  }

  /// الفصول مرتّبة بالمشاهدات (الأكثر أولاً).
  List<CreatorChapter> topChapters({int limit = 5}) {
    final list = List<CreatorChapter>.from(chapters.chapters);
    list.sort((a, b) => b.views.compareTo(a.views));
    return list.take(limit).toList();
  }

  /// نسبة القراء العائدين (قاعدة تجريبية: من متوسط المشاهدات اليومية
  /// وعدد الفصول المنشورة).
  double get returningReadersRate {
    final published = studio.byStatus(CreatorSubmissionStatus.published);
    if (published.isEmpty) return 0;
    final ch = chapters.publishedCount;
    final rate = 0.32 + (ch * 0.012).clamp(0.0, 0.28);
    return rate.clamp(0.0, 0.85);
  }

  /// متوسط التقييم لكل الأعمال المنشورة.
  double get averageRating => studio.averageRating;

  /// توزيع تقييمات تجريبي حتمي من متوسط التقييم.
  CreatorRatingBreakdown ratingBreakdown() {
    final avg = averageRating;
    final total = 120 + studio.totalViews ~/ 400;
    // توزيع طبيعي مبسّط حول المتوسط.
    final weights = <int, double>{};
    for (var s = 1; s <= 5; s++) {
      final d = (s - avg).abs();
      weights[s] = math.exp(-d * d / 1.6);
    }
    final wSum = weights.values.fold<double>(0, (a, b) => a + b);
    final counts = <int, int>{};
    var assigned = 0;
    for (var s = 1; s <= 5; s++) {
      final c = s == 5
          ? total - assigned
          : (total * weights[s]! / wSum).round();
      counts[s] = c;
      assigned += c;
    }
    return CreatorRatingBreakdown(counts: counts);
  }

  /// أفضل يوم نشر (اليوم الذي يحقق أعلى متوسط مشاهدات في الأسبوع).
  String get bestWeekday {
    const names = [
      'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس',
      'الجمعة', 'السبت', 'الأحد',
    ];
    final sums = List<int>.filled(7, 0);
    final counts = List<int>.filled(7, 0);
    for (var i = 0; i < 28; i++) {
      final day = DateTime.now().subtract(Duration(days: i));
      var v = 0;
      for (final s in studio.byStatus(CreatorSubmissionStatus.published)) {
        v += demoViewsFor(s.id, day);
      }
      sums[day.weekday - 1] += v;
      counts[day.weekday - 1]++;
    }
    var best = 0;
    for (var i = 1; i < 7; i++) {
      final a = counts[i] == 0 ? 0 : sums[i] / counts[i];
      final b = counts[best] == 0 ? 0 : sums[best] / counts[best];
      if (a > b) best = i;
    }
    return names[best];
  }

  /// نصيحة قواعديّة بناءً على البيانات (ليست ذكاءً اصطناعياً).
  String get tip {
    final s = summary(30);
    if (studio.publishedCount == 0) {
      return 'انشر عملك الأول لتبدأ رؤية التحليلات هنا.';
    }
    if (s.growthPercent > 10) {
      return 'نمو ممتاز (${s.growthPercent.toStringAsFixed(0)}٪)! '
          'حافظ على وتيرة النشر الحالية.';
    }
    if (s.growthPercent < -10) {
      return 'تراجعت المشاهدات ${(-s.growthPercent).toStringAsFixed(0)}٪. '
          'جرّب النشر يوم ${bestWeekday}، وهو أفضل أيامك.';
    }
    if (returningReadersRate < 0.4) {
      return 'نسبة العائدين ${(returningReadersRate * 100).toStringAsFixed(0)}٪. '
          'فصول أقصر وأكثر انتظاماً تساعد على عودة القراء.';
    }
    return 'أداء مستقر. جرّب إضافة فصل جديد هذا الأسبوع لرفع المشاهدات.';
  }
}

// ───────── واجهة التحليلات ─────────

/// شاشة تحليلات الناشر.
class CreatorAnalyticsScreen extends StatefulWidget {
  const CreatorAnalyticsScreen({super.key, required this.store});
  final CreatorAnalyticsStore store;

  @override
  State<CreatorAnalyticsScreen> createState() => _CreatorAnalyticsScreenState();
}

class _CreatorAnalyticsScreenState extends State<CreatorAnalyticsScreen> {
  int _days = 30;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = widget.store;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final summary = store.summary(_days);
        final daily = store.viewsLastNDays(_days);
        final top = store.topSeries();
        final topCh = store.topChapters();
        final breakdown = store.ratingBreakdown();
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(title: const Text('تحليلات الناشر')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              _PeriodSelector(
                days: _days,
                onSelect: (d) => setState(() => _days = d),
              ),
              const SizedBox(height: 14),
              _SummaryCards(summary: summary, store: store),
              const SizedBox(height: 14),
              _ChartCard(
                title: 'المشاهدات اليومية',
                subtitle: 'آخر $_days يوماً',
                child: _ViewsBarChart(daily: daily),
              ),
              const SizedBox(height: 14),
              _ChartCard(
                title: 'منحنى المشاهدات',
                subtitle: 'اتجاه الفترة',
                child: _ViewsLineChart(daily: daily),
              ),
              const SizedBox(height: 14),
              _TipCard(tip: store.tip),
              const SizedBox(height: 18),
              Text('أفضل الأعمال', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              if (top.isEmpty)
                _EmptyAnalytics(text: 'لا أعمال منشورة بعد.')
              else
                for (var i = 0; i < top.length; i++)
                  Padding(
                    padding: EdgeInsets.only(bottom: i == top.length - 1 ? 0 : 10),
                    child: _TopSeriesTile(rank: i + 1, item: top[i], store: store),
                  ),
              const SizedBox(height: 18),
              Text('أفضل الفصول', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              if (topCh.isEmpty)
                _EmptyAnalytics(text: 'لا فصول بعد.')
              else
                for (var i = 0; i < topCh.length; i++)
                  Padding(
                    padding: EdgeInsets.only(bottom: i == topCh.length - 1 ? 0 : 10),
                    child: _TopChapterTile(rank: i + 1, chapter: topCh[i]),
                  ),
              const SizedBox(height: 18),
              Text('توزيع التقييمات', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              _RatingBreakdownCard(breakdown: breakdown),
              const SizedBox(height: 14),
              Text(
                'الأرقام اليومية في هذه النسخة تجريبية ومولّدة محلياً '
                'بقواعد ثابتة؛ عند ربط الخادم ستُعرض بيانات حقيقية.',
                style: context.ts(size: 12, color: p.textDim, height: 1.6),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PeriodSelector extends StatelessWidget {
  const _PeriodSelector({required this.days, required this.onSelect});
  final int days;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [7, 30, 90].map((d) {
          final active = days == d;
          return Expanded(
            child: GestureDetector(
              onTap: () => onSelect(d),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 9),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: active ? p.accent : Colors.transparent,
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                ),
                child: Text(
                  d == 7 ? '7 أيام' : d == 30 ? '30 يوماً' : '90 يوماً',
                  style: context.ts(
                    w: FontWeight.w700,
                    color: active ? p.onAccent : p.text,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _SummaryCards extends StatelessWidget {
  const _SummaryCards({required this.summary, required this.store});
  final CreatorPeriodSummary summary;
  final CreatorAnalyticsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final growth = summary.growthPercent;
    final up = growth >= 0;
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.9,
      children: [
        _StatCell(
          label: 'مشاهدات الفترة',
          value: formatCount(summary.totalViews),
          icon: SardIcons.visibility_rounded,
          color: p.accent,
        ),
        _StatCell(
          label: 'متوسط يومي',
          value: formatCount(summary.averageDaily.round()),
          icon: SardIcons.calendar_today_rounded,
          color: p.gold,
        ),
        _StatCell(
          label: 'النمو',
          value: '${up ? '+' : ''}${growth.toStringAsFixed(0)}٪',
          icon: up ? SardIcons.expand_less_rounded : SardIcons.expand_more_rounded,
          color: up ? const Color(0xFF0F9D75) : const Color(0xFFE5484D),
        ),
        _StatCell(
          label: 'قراء عائدون',
          value: '${(store.returningReadersRate * 100).toStringAsFixed(0)}٪',
          icon: SardIcons.groups_rounded,
          color: p.accent,
        ),
      ],
    );
  }
}

class _StatCell extends StatelessWidget {
  const _StatCell({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });
  final String label;
  final String value;
  final SIconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(icon, size: 17, color: color),
              const SizedBox(width: 6),
              Text(label, style: context.ts(size: 12, color: p.textDim)),
            ],
          ),
          const Spacer(),
          Text(value, style: context.ds(size: 19)),
        ],
      ),
    );
  }
}

class _ChartCard extends StatelessWidget {
  const _ChartCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });
  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: context.ds(size: 16)),
          const SizedBox(height: 2),
          Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

/// رسم بياني شريطي بسيط للمشاهدات اليومية.
class _ViewsBarChart extends StatelessWidget {
  const _ViewsBarChart({required this.daily});
  final List<CreatorDailyViews> daily;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (daily.isEmpty) return const SizedBox(height: 120);
    final max = daily.map((e) => e.views).reduce((a, b) => a > b ? a : b);
    // نعرض شريطاً واحداً كل عدة أيام إن كانت الفترة طويلة.
    final step = daily.length > 30 ? 3 : daily.length > 14 ? 2 : 1;
    final shown = <CreatorDailyViews>[];
    for (var i = 0; i < daily.length; i += step) {
      shown.add(daily[i]);
    }
    return SizedBox(
      height: 130,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: shown.map((d) {
          final h = max == 0 ? 4.0 : (d.views / max * 100).clamp(4.0, 100.0);
          final isBest = d.views == max;
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    d.views >= 1000 ? formatCount(d.views) : '${d.views}',
                    style: context.ts(
                      size: 9,
                      color: isBest ? p.accent : p.textDim,
                      w: isBest ? FontWeight.w800 : FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Container(
                    height: h,
                    decoration: BoxDecoration(
                      color: isBest ? p.accent : tint(p.accent, 0.45),
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(d.dayLabel, style: context.ts(size: 9, color: p.textDim)),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

/// منحنى المشاهدات (رسم مخصص).
class _ViewsLineChart extends StatelessWidget {
  const _ViewsLineChart({required this.daily});
  final List<CreatorDailyViews> daily;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SizedBox(
      height: 120,
      width: double.infinity,
      child: CustomPaint(
        painter: _LineChartPainter(
          values: daily.map((e) => e.views.toDouble()).toList(),
          lineColor: p.accent,
          fillColor: tint(p.accent, 0.15),
          gridColor: p.border,
        ),
      ),
    );
  }
}

class _LineChartPainter extends CustomPainter {
  _LineChartPainter({
    required this.values,
    required this.lineColor,
    required this.fillColor,
    required this.gridColor,
  });
  final List<double> values;
  final Color lineColor;
  final Color fillColor;
  final Color gridColor;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty) return;
    final max = values.reduce(math.max);
    final min = values.reduce(math.min);
    final range = (max - min).abs() < 1 ? 1.0 : max - min;
    final pad = 8.0;
    final w = size.width - pad * 2;
    final h = size.height - pad * 2;

    // خطوط الشبكة الأفقية
    final gridPaint = Paint()
      ..color = gridColor
      ..strokeWidth = 1;
    for (var i = 0; i <= 3; i++) {
      final y = pad + h * i / 3;
      canvas.drawLine(Offset(pad, y), Offset(pad + w, y), gridPaint);
    }

    Offset point(int i) {
      final x = pad + (values.length == 1 ? w / 2 : w * i / (values.length - 1));
      final y = pad + h * (1 - (values[i] - min) / range);
      return Offset(x, y);
    }

    // تعبئة تحت المنحنى
    final fillPath = Path()..moveTo(point(0).dx, pad + h);
    for (var i = 0; i < values.length; i++) {
      fillPath.lineTo(point(i).dx, point(i).dy);
    }
    fillPath.lineTo(point(values.length - 1).dx, pad + h);
    fillPath.close();
    canvas.drawPath(fillPath, Paint()..color = fillColor);

    // المنحنى
    final linePaint = Paint()
      ..color = lineColor
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()..moveTo(point(0).dx, point(0).dy);
    for (var i = 1; i < values.length; i++) {
      path.lineTo(point(i).dx, point(i).dy);
    }
    canvas.drawPath(path, linePaint);

    // نقطة الذروة
    var best = 0;
    for (var i = 1; i < values.length; i++) {
      if (values[i] > values[best]) best = i;
    }
    canvas.drawCircle(
      point(best),
      4.5,
      Paint()..color = lineColor,
    );
    canvas.drawCircle(
      point(best),
      4.5,
      Paint()
        ..color = Colors.white
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  @override
  bool shouldRepaint(covariant _LineChartPainter old) =>
      old.values != values || old.lineColor != lineColor;
}

class _TipCard extends StatelessWidget {
  const _TipCard({required this.tip});
  final String tip;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tint(p.accent, 0.10),
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: tint(p.accent, 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SIcon(SardIcons.auto_awesome_rounded, size: 20, color: p.accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('نصيحة من بياناتك', style: context.ts(w: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(tip, style: context.ts(height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyAnalytics extends StatelessWidget {
  const _EmptyAnalytics({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: context.ts(color: p.textDim),
      ),
    );
  }
}

class _TopSeriesTile extends StatelessWidget {
  const _TopSeriesTile({
    required this.rank,
    required this.item,
    required this.store,
  });
  final int rank;
  final CreatorSubmission item;
  final CreatorAnalyticsStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final last30 = store.viewsForSeries(item.id, 30);
    final total30 = last30.fold<int>(0, (a, e) => a + e.views);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: rank == 1 ? tint(p.gold, 0.2) : p.surfaceHi,
              shape: BoxShape.circle,
            ),
            child: Text(
              '$rank',
              style: context.ds(
                size: 14,
                color: rank == 1 ? p.gold : p.textDim,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.title, style: context.ts(w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  '${item.chaptersCount} فصل · ${formatCount(total30)} مشاهدة آخر 30 يوماً',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SIcon(SardIcons.star_rounded, size: 14, color: p.gold),
                  const SizedBox(width: 3),
                  Text(
                    item.rating > 0 ? item.rating.toStringAsFixed(1) : '—',
                    style: context.ts(w: FontWeight.w700),
                  ),
                ],
              ),
              Text(
                formatCount(item.views),
                style: context.ts(size: 12, color: p.textDim),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TopChapterTile extends StatelessWidget {
  const _TopChapterTile({required this.rank, required this.chapter});
  final int rank;
  final CreatorChapter chapter;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Text('$rank', style: context.ds(size: 15, color: p.textDim)),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              chapter.displayTitle,
              style: context.ts(w: FontWeight.w700),
            ),
          ),
          SIcon(SardIcons.visibility_rounded, size: 15, color: p.textDim),
          const SizedBox(width: 4),
          Text(formatCount(chapter.views), style: context.ts(color: p.textDim)),
        ],
      ),
    );
  }
}

class _RatingBreakdownCard extends StatelessWidget {
  const _RatingBreakdownCard({required this.breakdown});
  final CreatorRatingBreakdown breakdown;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          for (var s = 5; s >= 1; s--) ...[
            Row(
              children: [
                Text('$s', style: context.ts(w: FontWeight.w700)),
                const SizedBox(width: 4),
                SIcon(SardIcons.star_rounded, size: 14, color: p.gold),
                const SizedBox(width: 10),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: breakdown.share(s),
                      minHeight: 8,
                      backgroundColor: p.surfaceHi,
                      valueColor: AlwaysStoppedAnimation<Color>(p.gold),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 44,
                  child: Text(
                    '${(breakdown.share(s) * 100).toStringAsFixed(0)}٪',
                    textAlign: TextAlign.left,
                    style: context.ts(size: 12, color: p.textDim),
                  ),
                ),
              ],
            ),
            if (s > 1) const SizedBox(height: 8),
          ],
          const SizedBox(height: 8),
          Text(
            'إجمالي التقييمات: ${formatCount(breakdown.total)}',
            style: context.ts(size: 12, color: p.textDim),
          ),
        ],
      ),
    );
  }
}
