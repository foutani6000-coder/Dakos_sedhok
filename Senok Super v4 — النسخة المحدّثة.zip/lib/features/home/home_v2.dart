import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/ink_spirit.dart';
import '../../widgets/routes.dart';
import '../../widgets/sard_icons.dart';
import '../details/details_screen.dart';
import '../search/search_screen.dart';
import '../../widgets/atelier/atelier_cards.dart';
import '../../widgets/atelier/atelier_empty.dart';
import '../../widgets/atelier/atelier_hero.dart';
import '../../widgets/atelier/atelier_motion.dart';
import '../../widgets/atelier/atelier_shimmer.dart';
import '../../widgets/atelier/atelier_theme.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// الرئيسية الجديدة v2 — «Atelier»:
///
///   • تحية حسب الوقت + اسم القارئ، وشارة ذهبية ترويجية.
///   • رفيق «حبّار» مع فقاعة كلام قواعديّة تتبدل حسب سياق القراءة.
///   • قسم بطل سينمائي (تقدّم تلقائي يتوقف في الخلفية).
///   • صف اقتراحات، وشبكة أحدث الفصول، وإحصاءات، ومنصة ترتيب.
///   • شريط تنقل سفلي بزر عائم مركزي (اقرأ الآن).
///
/// تتجاوز لقطة المنافس التقليدية (تحية + بطل + اقتراحات) بإضافة:
/// الرفيق الناطق، بطاقة «واصل القراءة»، الإحصاءات الحية من
/// [SettingsController]، منصة الترتيب، وبطاقة الاقتباس.
///
/// البيانات من [SardRepository.home] (الخادم أو البيانات التجريبية
/// حسب الإعدادات)، والإحصاءات من [SettingsController] المحلي.
/// ──────────────────────────────────────────────────────────────────────────

/// تبويبات الرئيسية v2 (البحث يُفتح من الرأس، لا تبويب له).
enum _HomeTab { home, library, community, profile }

/// الشاشة الرئيسية الجديدة.
class HomeV2Screen extends StatefulWidget {
  const HomeV2Screen({super.key});

  @override
  State<HomeV2Screen> createState() => _HomeV2ScreenState();
}

class _HomeV2ScreenState extends State<HomeV2Screen> {
  late Future<HomeData> _future;
  final ScrollController _scroll = ScrollController();
  final ValueNotifier<Color?> _tone = ValueNotifier<Color?>(null);
  _HomeTab _tab = _HomeTab.home;
  bool _offline = false;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<HomeData> _load() async {
    try {
      final data = await context.read<SardRepository>().home();
      if (mounted) setState(() => _offline = false);
      return data;
    } catch (_) {
      if (mounted) setState(() => _offline = true);
      rethrow;
    }
  }

  @override
  void dispose() {
    _scroll.dispose();
    _tone.dispose();
    super.dispose();
  }

  void _reload() => setState(() => _future = _load());

  void _open(Series s, [String? tag]) {
    Navigator.of(context).push(sardRoute(DetailsScreen(series: s, heroTag: tag)));
  }

  void _openSearch() {
    Navigator.of(context).push(sardRoute(const SearchScreen()));
  }

  void _follow(Series s) {
    final settings = context.read<SettingsController>();
    final following = settings.isFollowing(s.id);
    settings.setFollowing(s.id, !following);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(following
            ? 'ألغيت متابعة «${s.title}»'
            : 'تابعت «${s.title}» — ستصلك فصوله الجديدة'),
      ),
    );
  }

  /// سلسلة المتابعة الحالية: أول عمل في «الأحدث» سبق أن بدأه القارئ.
  Series? _continueSeries(HomeData data, SettingsController settings) {
    final reading = settings.readingIds.toSet();
    for (final s in data.latest) {
      if (reading.contains(s.id)) return s;
    }
    for (final s in data.suggestions) {
      if (reading.contains(s.id)) return s;
    }
    return null;
  }

  /// مزاج الرفيق من الإعدادات (0 = هادئ…).
  InkSpiritMood _companionMood(SettingsController settings) {
    final values = InkSpiritMood.values;
    final i = settings.companionMood.clamp(0, values.length - 1);
    return values[i];
  }

  /// سطر الرفيق من سياق القراءة الحقيقي.
  String _companionLine(HomeData data, SettingsController settings) {
    final newChapters = data.latest.where((s) => s.isNew).length;
    final chaptersToday = settings.totalChaptersRead;
    return atelierCompanionLine(
      name: 'قارئنا',
      streak: settings.streak,
      chaptersToday: chaptersToday > 99 ? 99 : chaptersToday,
      newChapters: newChapters,
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      extendBody: true,
      body: ValueListenableBuilder<Color?>(
        valueListenable: _tone,
        builder: (context, tone, _) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 600),
            decoration: BoxDecoration(
              gradient: tone == null
                  ? null
                  : LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [tone.withAlpha(26), p.bg, p.bg],
                      stops: const [0.0, 0.35, 1.0],
                    ),
            ),
            child: _tab == _HomeTab.home ? _buildHome() : _buildTab(),
          );
        },
      ),
      bottomNavigationBar: AtelierBottomNavBar(
        current: _tab,
        onSelect: (t) => setState(() => _tab = t),
        onFab: _onFab,
      ),
      floatingActionButton: AtelierCenterFab(onTap: _onFab),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  /// زر العائم المركزي: يفتح أول عمل يُتابع قراءته، أو أول مقترح.
  void _onFab() {
    _future.then((data) {
      if (!mounted) return;
      final settings = context.read<SettingsController>();
      final next = _continueSeries(data, settings) ??
          (data.suggestions.isNotEmpty ? data.suggestions.first : null) ??
          (data.featured.isNotEmpty ? data.featured.first : null);
      if (next != null) _open(next, 'fab-${next.id}');
    });
  }

  Widget _buildHome() {
    return FutureBuilder<HomeData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const AtelierShimmerHome();
        }
        if (snap.hasError || !snap.hasData) {
          return ListView(
            controller: _scroll,
            children: [
              const SizedBox(height: 80),
              AtelierEmptyError(onRetry: _reload),
            ],
          );
        }
        final data = snap.data!;
        final settings = context.watch<SettingsController>();
        return RefreshIndicator(
          onRefresh: () async => _reload(),
          color: context.pal.accent,
          child: CustomScrollView(
            controller: _scroll,
            slivers: [
              SliverToBoxAdapter(child: _GreetingHeader(settings: settings, onSearch: _openSearch, offline: _offline)),
              SliverToBoxAdapter(
                child: AtelierCompanionCard(
                  line: _companionLine(data, settings),
                  mood: _companionMood(settings),
                  onAction: _openSearch,
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 22)),
              if (_continueSeries(data, settings) != null)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
                    child: FadeSlide(
                      onceKey: 'continue-card',
                      child: AtelierContinueCard(
                        series: _continueSeries(data, settings)!,
                        chapter: 3,
                        progress: 0.42,
                        totalPages: 28,
                        currentPage: 12,
                        onTap: () => _open(_continueSeries(data, settings)!),
                      ),
                    ),
                  ),
                ),
              if (_continueSeries(data, settings) != null)
                const SliverToBoxAdapter(child: SizedBox(height: 22)),
              SliverToBoxAdapter(
                child: FadeSlide(
                  onceKey: 'hero-section',
                  child: AtelierHeroSection(
                    items: AtelierHeroItem.fromFeatured(data.featured),
                    height: 380,
                    onOpen: (s) => _open(s, 'hero-${s.id}'),
                    onFollow: _follow,
                  ),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 26)),
              SliverToBoxAdapter(child: _StatsRow(settings: settings)),
              SliverToBoxAdapter(
                child: _QuickActions(
                  onSearch: _openSearch,
                  onLibrary: () => setState(() => _tab = _HomeTab.library),
                  onCommunity: () => setState(() => _tab = _HomeTab.community),
                  onProfile: () => setState(() => _tab = _HomeTab.profile),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 8)),
              SliverToBoxAdapter(
                child: AtelierHeading(
                  kicker: 'مختارات لك',
                  title: 'اقتراحات تناسب ذوقك',
                  subtitle: 'بناءً على تصنيفاتك المفضلة وقراءاتك الأخيرة.',
                  actionLabel: 'عرض الكل',
                  onAction: _openSearch,
                ),
              ),
              SliverToBoxAdapter(
                child: FadeSlide(
                  onceKey: 'suggestions-row',
                  child: SizedBox(
                    height: 252,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
                      itemCount: data.suggestions.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, i) {
                        final s = data.suggestions[i];
                        return AtelierSeriesCard(
                          series: s,
                          onTap: () => _open(s, 'sug-${s.id}'),
                        );
                      },
                    ),
                  ),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 8)),
              const SliverToBoxAdapter(child: AtelierRuler()),
              SliverToBoxAdapter(
                child: AtelierHeading(
                  kicker: 'وصل حديثاً',
                  title: 'أحدث الفصول',
                  subtitle: 'فصول جديدة من أعمالك المتابَعة والمشهورة.',
                  actionLabel: 'المزيد',
                  onAction: _openSearch,
                ),
              ),
              SliverToBoxAdapter(child: _LatestChapters(data: data, onOpen: _open)),
              const SliverToBoxAdapter(child: SizedBox(height: 8)),
              SliverToBoxAdapter(
                child: FadeSlide(
                  onceKey: 'podium',
                  child: AtelierPodium(
                    top: data.popular,
                    onTap: (s) => _open(s, 'pod-${s.id}'),
                  ),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
              if (data.popular.isNotEmpty)
                SliverToBoxAdapter(
                  child: FadeSlide(
                    onceKey: 'spotlight',
                    child: AtelierSpotlightCard(
                      series: data.popular.first,
                      quote: data.popular.first.synopsis.isEmpty
                          ? 'حكاية تبدأ بصفحة… وتنتهي في قلبك.'
                          : data.popular.first.synopsis,
                      onOpen: (s) => _open(s, 'spot-${s.id}'),
                      onFollow: _follow,
                    ),
                  ),
                ),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
              SliverToBoxAdapter(
                child: AtelierPromoCard(
                  title: 'Senok Plus — بلا إعلانات',
                  subtitle: 'قراءة بلا حدود، تنزيلات غير محدودة، وأختام حصرية لملفك.',
                  badge: 'عرض الإطلاق',
                  onTap: _openSearch,
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
              SliverToBoxAdapter(child: _GenresStrip(data: data, onGenre: (_) => _openSearch())),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
              SliverToBoxAdapter(
                child: FadeSlide(
                  onceKey: 'streak-card',
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
                    child: AtelierStreakCard(
                      streak: settings.streak,
                      bestStreak: settings.bestStreak,
                    ),
                  ),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
              SliverToBoxAdapter(
                child: FadeSlide(
                  onceKey: 'week-strip',
                  child: _WeekStripSection(streak: settings.streak),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 32)),
              const SliverToBoxAdapter(child: _HomeFooter()),
              const SliverToBoxAdapter(child: SizedBox(height: 120)),
            ],
          ),
        );
      },
    );
  }
  /// التبويبات غير الرئيسية: مكتبة، مجتمع، حسابي.
  Widget _buildTab() {
    switch (_tab) {
      case _HomeTab.library:
        return _LibraryTab(onOpen: _open, onExplore: _openSearch, onReload: _reload);
      case _HomeTab.community:
        return ListView(
          children: [
            const SizedBox(height: 90),
            AtelierEmptyFriends(onInvite: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('شارك رابط الدعوة مع أصدقائك قريباً')),
              );
            }),
          ],
        );
      case _HomeTab.profile:
        return _ProfileTab(settings: context.watch<SettingsController>());
      case _HomeTab.home:
        return _buildHome();
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  رأس التحية
// ═══════════════════════════════════════════════════════════════════════════

/// رأس الصفحة: تحية حسب الوقت + شارة ذهبية + زر بحث وإشعارات.
class _GreetingHeader extends StatelessWidget {
  const _GreetingHeader({required this.settings, required this.onSearch, required this.offline});

  final SettingsController settings;
  final VoidCallback onSearch;
  final bool offline;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final part = AtelierDayPart.of(DateTime.now());
    return Padding(
      padding: const EdgeInsets.fromLTRB(AtelierSpacing.page, 54, AtelierSpacing.page, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        SIcon(
                          part == AtelierDayPart.night || part == AtelierDayPart.evening
                              ? SardIcons.nightlight_round
                              : SardIcons.wb_sunny_rounded,
                          size: 17,
                          color: p.gold,
                        ),
                        const SizedBox(width: 6),
                        Text(part.greeting, style: AtelierType.overline(context, color: p.gold)),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: AtelierDecor.badge(p.gold),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const SIcon(SardIcons.local_fire_department_rounded, size: 11, color: Colors.white),
                              const SizedBox(width: 3),
                              Text(
                                'سلسلة ${settings.streak} يوم',
                                style: const TextStyle(
                                  fontFamily: sardBodyFont,
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'أهلاً بك في Senok',
                      style: AtelierType.display(context, size: 26),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'حيث تبدأ الحكاية — ${settings.totalChaptersRead} فصلاً قرأتها حتى الآن.',
                      style: AtelierType.muted(context),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              _HeaderIconButton(
                icon: SardIcons.search_rounded,
                tooltip: 'بحث',
                onTap: onSearch,
              ),
              const SizedBox(width: 8),
              _HeaderIconButton(
                icon: SardIcons.notifications_none_rounded,
                tooltip: 'الإشعارات',
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('لا إشعارات جديدة — كل شيء مقروء')),
                  );
                },
              ),
            ],
          ),
          if (offline) ...[
            const SizedBox(height: 12),
            AtelierOfflineStrip(onDownloads: onSearch),
          ],
          const SizedBox(height: 14),
          GestureDetector(
            onTap: onSearch,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: AtelierDecor.card(p, radius: 999),
              child: Row(
                children: [
                  SIcon(SardIcons.search_rounded, size: 19, color: p.textDim),
                  const SizedBox(width: 10),
                  Text('ابحث عن مانهوا، مانغا، رواية…', style: AtelierType.muted(context)),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: AtelierDecor.pill(p.gold),
                    child: Text('جديد', style: AtelierType.caption(context, color: p.gold, size: 10.5)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

/// زر أيقونة دائري في الرأس.
class _HeaderIconButton extends StatelessWidget {
  const _HeaderIconButton({required this.icon, required this.tooltip, this.onTap});

  final SIconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: p.surface,
            shape: BoxShape.circle,
            border: Border.all(color: p.border),
            boxShadow: softShadow(p, strength: 0.6),
          ),
          alignment: Alignment.center,
          child: SIcon(icon, size: 21, color: p.text),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  صف الإحصاءات
// ═══════════════════════════════════════════════════════════════════════════

/// صف إحصاءات حي: فصول مقروءة، دقائق قراءة، سلسلة أيام.
class _StatsRow extends StatelessWidget {
  const _StatsRow({required this.settings});

  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    final minutes = settings.totalReadingSeconds ~/ 60;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
      child: Row(
        children: [
          Expanded(
            child: AtelierStatCard(
              value: settings.totalChaptersRead,
              label: 'فصلاً قرأت',
              icon: SardIcons.menu_book_rounded,
              tone: AtelierTone.gold,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: AtelierStatCard(
              value: minutes,
              label: 'دقيقة قراءة',
              icon: SardIcons.watch_later_rounded,
              tone: AtelierTone.indigo,
              compact: minutes >= 1000,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: AtelierStatCard(
              value: settings.streak,
              label: 'يوم متتالٍ',
              icon: SardIcons.local_fire_department_rounded,
              tone: AtelierTone.seal,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  أحدث الفصول (شبكة)
// ═══════════════════════════════════════════════════════════════════════════

/// شبكة أحدث الفصول: بطاقتا فصل في كل صف.
class _LatestChapters extends StatelessWidget {
  const _LatestChapters({required this.data, required this.onOpen});

  final HomeData data;
  final void Function(Series, [String?]) onOpen;

  @override
  Widget build(BuildContext context) {
    final items = data.latest.take(6).toList();
    if (items.isEmpty) {
      return const AtelierEmptyToday();
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.7,
        ),
        itemCount: items.length,
        itemBuilder: (context, i) {
          final s = items[i];
          return FadeSlide(
            onceKey: 'latest-$i',
            delay: Duration(milliseconds: 60 * i),
            child: AtelierChapterCard(
              series: s,
              chapter: s.chapters,
              date: s.isNew ? 'اليوم' : 'أمس',
              isNew: s.isNew,
              onTap: () => onOpen(s, 'latest-${s.id}'),
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شريط التصنيفات
// ═══════════════════════════════════════════════════════════════════════════

/// شريط تصنيفات أفقي مشتق من أعمال الصفحة.
class _GenresStrip extends StatelessWidget {
  const _GenresStrip({required this.data, required this.onGenre});

  final HomeData data;
  final void Function(String) onGenre;

  @override
  Widget build(BuildContext context) {
    final counts = <String, int>{};
    for (final s in [...data.suggestions, ...data.popular, ...data.latest]) {
      for (final g in s.genres) {
        counts[g] = (counts[g] ?? 0) + 1;
      }
    }
    final genres = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final top = genres.take(8).toList();
    if (top.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const AtelierHeading(
          kicker: 'تصفّح حسب المزاج',
          title: 'تصنيفات تحبها',
        ),
        SizedBox(
          height: 64,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
            itemCount: top.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final entry = top[i];
              final tones = AtelierTone.values;
              final tone = tones[(entry.key.hashCode & 0x7fffffff) % tones.length];
              return AtelierGenreCard(
                genre: entry.key,
                count: entry.value,
                tone: tone,
                onTap: () => onGenre(entry.key),
              );
            },
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  تبويب المكتبة
// ═══════════════════════════════════════════════════════════════════════════

/// تبويب المكتبة: أعمال متابَعة من الإعدادات (مطابقة مع بيانات الصفحة)،
/// أو حالة فراغ أنيقة.
class _LibraryTab extends StatelessWidget {
  const _LibraryTab({required this.onOpen, required this.onExplore, required this.onReload});

  final void Function(Series, [String?]) onOpen;
  final VoidCallback onExplore;
  final VoidCallback onReload;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<HomeData>(
      future: context.read<SardRepository>().home(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const AtelierShimmerHome();
        }
        if (snap.hasError || !snap.hasData) {
          return ListView(
            children: [const SizedBox(height: 80), AtelierEmptyError(onRetry: onReload)],
          );
        }
        final settings = context.watch<SettingsController>();
        final followed = settings.followedSeries;
        final all = [...snap.data!.featured, ...snap.data!.suggestions, ...snap.data!.latest, ...snap.data!.popular];
        final seen = <String>{};
        final mine = <Series>[];
        for (final s in all) {
          if (followed.contains(s.id) && seen.add(s.id)) mine.add(s);
        }
        if (mine.isEmpty) {
          return ListView(
            children: [
              const SizedBox(height: 90),
              AtelierEmptyLibrary(onExplore: onExplore),
            ],
          );
        }
        return RefreshIndicator(
          onRefresh: () async => onReload(),
          color: context.pal.accent,
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(
              AtelierSpacing.page, 70, AtelierSpacing.page, 120,
            ),
            itemCount: mine.length + 1,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              if (i == 0) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text('مكتبتك · ${mine.length} ${mine.length == 1 ? 'عمل' : 'أعمال'}', style: AtelierType.title(context, size: 20)),
                );
              }
              final s = mine[i - 1];
              return AtelierSeriesRowCard(
                series: s,
                showProgress: settings.readingIds.contains(s.id),
                progress: 0.42,
                onTap: () => onOpen(s, 'lib-${s.id}'),
              );
            },
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  تبويب الحساب
// ═══════════════════════════════════════════════════════════════════════════

/// تبويب الحساب: إحصاءاتك، سلسلة أيامك، وإنجازاتك.
class _ProfileTab extends StatelessWidget {
  const _ProfileTab({required this.settings});

  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final minutes = settings.totalReadingSeconds ~/ 60;
    return ListView(
      padding: const EdgeInsets.fromLTRB(0, 70, 0, 120),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
          child: Row(
            children: [
              AtelierPaintedSeal(size: 56, color: p.gold, letter: 'ق'),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('ملفي في Senok', style: AtelierType.title(context, size: 20)),
                    const SizedBox(height: 3),
                    Text(
                      settings.topGenre == null
                          ? 'قارئ شغوف بالحكايات'
                          : 'أكثر ما تقرأ: ${settings.topGenre}',
                      style: AtelierType.muted(context),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        _StatsRow(settings: settings),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
          child: AtelierStreakCard(streak: settings.streak, bestStreak: settings.bestStreak),
        ),
        const SizedBox(height: 20),
        const AtelierHeading(kicker: 'إنجازاتك', title: 'أختامك'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              AtelierAchievementChip(label: 'أول فصل', unlocked: settings.totalChaptersRead >= 1),
              AtelierAchievementChip(label: '5 فصول', unlocked: settings.totalChaptersRead >= 5),
              AtelierAchievementChip(label: '20 فصلاً', unlocked: settings.totalChaptersRead >= 20),
              AtelierAchievementChip(label: '100 فصل', unlocked: settings.totalChaptersRead >= 100),
              AtelierAchievementChip(label: 'سلسلة 3 أيام', unlocked: settings.streak >= 3),
              AtelierAchievementChip(label: 'سلسلة 7 أيام', unlocked: settings.streak >= 7),
              AtelierAchievementChip(label: 'سلسلة 30 يوماً', unlocked: settings.streak >= 30),
              AtelierAchievementChip(label: 'ساعة قراءة', unlocked: minutes >= 60),
              AtelierAchievementChip(label: '5 ساعات', unlocked: minutes >= 300),
              AtelierAchievementChip(label: 'متابع وفيّ', unlocked: settings.followedSeries.length >= 3),
            ],
          ),
        ),
        const SizedBox(height: 20),
        AtelierSectionCard(
          title: 'عن Senok',
          subtitle: 'حيث تبدأ الحكاية — مانهوا ومانغا وروايات مصوّرة.',
          icon: SardIcons.menu_book_rounded,
          tone: AtelierTone.gold,
          child: Text(
            'نسخة Atelier الجديدة: رئيسية أرقى، رفيق ناطق، وبطل سينمائي. '
            'قراءتك تُحفظ محلياً، وإحصاءاتك لك وحدك.',
            style: AtelierType.body(context, size: 13.5),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  شريط التنقل السفلي بزر عائم مركزي
// ═══════════════════════════════════════════════════════════════════════════

/// شريط تنقل سفلي بخمسة تبويبات وزر عائم ذهبي في المنتصف (اقرأ الآن).
///
/// الزر المركزي مرفوع فوق الشريط (شق دائري)، ويفتح أول عمل يُتابع
/// قراءته القارئ أو أول مقترح.
class AtelierBottomNavBar extends StatelessWidget {
  const AtelierBottomNavBar({
    super.key,
    required this.current,
    required this.onSelect,
    required this.onFab,
  });

  final _HomeTab current;
  final ValueChanged<_HomeTab> onSelect;
  final VoidCallback onFab;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return BottomAppBar(
      color: p.surface,
      elevation: 0,
      height: 68,
      padding: EdgeInsets.zero,
      shape: const CircularNotchedRectangle(),
      notchMargin: 8,
      child: Row(
        children: [
          _NavItem(
            icon: SardIcons.home_rounded,
            label: 'الرئيسية',
            active: current == _HomeTab.home,
            onTap: () => onSelect(_HomeTab.home),
          ),
          _NavItem(
            icon: SardIcons.collections_bookmark_rounded,
            label: 'مكتبتي',
            active: current == _HomeTab.library,
            onTap: () => onSelect(_HomeTab.library),
          ),
          const Spacer(),
          _NavItem(
            icon: SardIcons.groups_rounded,
            label: 'المجتمع',
            active: current == _HomeTab.community,
            onTap: () => onSelect(_HomeTab.community),
          ),
          _NavItem(
            icon: SardIcons.person_rounded,
            label: 'حسابي',
            active: current == _HomeTab.profile,
            onTap: () => onSelect(_HomeTab.profile),
          ),
        ],
      ),
    );
  }
}

/// عنصر تبويب واحد في الشريط السفلي.
class _NavItem extends StatelessWidget {
  const _NavItem({required this.icon, required this.label, required this.active, required this.onTap});

  final SIconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = active ? p.accent : p.textDim;
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SIcon(icon, size: 23, color: color),
            const SizedBox(height: 3),
            Text(
              label,
              style: AtelierType.caption(context, color: color, size: 10.5),
            ),
            const SizedBox(height: 2),
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: active ? 18 : 0,
              height: 3,
              decoration: BoxDecoration(
                color: p.accent,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// الزر العائم المركزي الذهبي (يُركَّب فوق الشريط عبر Scaffold.floatingActionButton).
///
/// يُستعمل مع [AtelierBottomNavBar] عبر `floatingActionButtonLocation:
/// FloatingActionButtonLocation.centerDocked` في الشاشة المضيفة.
/// ملاحظة: [HomeV2Screen] يستعمل الشريط مباشرةً ويستدعي [onFab] من
/// زر منفصل؛ هذا الويدجت جاهز للشاشات التي تريد زراً عائماً حقيقياً.
class AtelierCenterFab extends StatelessWidget {
  const AtelierCenterFab({super.key, required this.onTap, this.tooltip = 'اقرأ الآن'});

  final VoidCallback onTap;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: AtelierGlowPulse(
          color: p.gold,
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [p.gold, Color.lerp(p.gold, Colors.white, 0.25)!],
              ),
              border: Border.all(color: Colors.white.withAlpha(120), width: 2),
              boxShadow: [
                BoxShadow(color: tint(p.gold, 0.45), blurRadius: 18, offset: const Offset(0, 6)),
              ],
            ),
            alignment: Alignment.center,
            child: const SIcon(SardIcons.play_arrow_rounded, size: 28, color: Colors.white),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  إجراءات سريعة وشريط أسبوع وتذييل
// ═══════════════════════════════════════════════════════════════════════════

/// صف إجراءات سريعة: 4 اختصارات دائرية تحت الإحصاءات.
class _QuickActions extends StatelessWidget {
  const _QuickActions({
    required this.onSearch,
    required this.onLibrary,
    required this.onCommunity,
    required this.onProfile,
  });

  final VoidCallback onSearch;
  final VoidCallback onLibrary;
  final VoidCallback onCommunity;
  final VoidCallback onProfile;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final actions = <({SIconData icon, String label, AtelierTone tone, VoidCallback onTap})>[
      (icon: SardIcons.search_rounded, label: 'بحث', tone: AtelierTone.indigo, onTap: onSearch),
      (icon: SardIcons.collections_bookmark_rounded, label: 'مكتبتي', tone: AtelierTone.gold, onTap: onLibrary),
      (icon: SardIcons.groups_rounded, label: 'المجتمع', tone: AtelierTone.rose, onTap: onCommunity),
      (icon: SardIcons.person_rounded, label: 'حسابي', tone: AtelierTone.jade, onTap: onProfile),
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AtelierSpacing.page, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          for (final a in actions)
            GestureDetector(
              onTap: a.onTap,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: a.tone.color.withAlpha(24),
                      shape: BoxShape.circle,
                      border: Border.all(color: a.tone.color.withAlpha(70)),
                    ),
                    alignment: Alignment.center,
                    child: SIcon(a.icon, size: 24, color: a.tone.color),
                  ),
                  const SizedBox(height: 7),
                  Text(a.label, style: AtelierType.caption(context, color: p.text)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// شريط أيام الأسبوع: الأيام المقروءة من سلسلتك الحالية.
///
/// تُحسب الأيام المقروءة قواعدياً من طول السلسلة: آخر [streak] يوماً
/// قبل اليوم تُعلَّم كمقروءة (تقريب صادق يُذكر في الواجهة).
class _WeekStripSection extends StatelessWidget {
  const _WeekStripSection({required this.streak});

  final int streak;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final read = <int>{};
    for (var d = 0; d < streak && d < 7; d++) {
      final day = now.subtract(Duration(days: d));
      read.add(day.weekday);
    }
    return AtelierSectionCard(
      title: 'أسبوعك في القراءة',
      subtitle: streak > 0
          ? 'قرأت $streak ${streak == 1 ? 'يوم' : 'أيام'} متتالية — واصل!'
          : 'لم تبدأ سلسلتك بعد — اليوم يوم جيد للبداية.',
      icon: SardIcons.calendar_today_rounded,
      tone: AtelierTone.jade,
      child: AtelierWeekStrip(readDays: read),
    );
  }
}

/// تذييل الصفحة: ختم Senok + سطر ختامي.
class _HomeFooter extends StatelessWidget {
  const _HomeFooter();

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      children: [
        const AtelierSealStamp(letter: 'س', size: 44, tone: AtelierTone.gold),
        const SizedBox(height: 12),
        Text('Senok — حيث تبدأ الحكاية', style: AtelierType.subtitle(context, size: 14)),
        const SizedBox(height: 4),
        Text(
          'مانهوا · مانغا · روايات مصوّرة',
          style: AtelierType.caption(context),
        ),
        const SizedBox(height: 8),
        Text(
          'نسخة Atelier الجديدة',
          style: AtelierType.caption(context, color: p.textDim, size: 11),
        ),
      ],
    );
  }
}
