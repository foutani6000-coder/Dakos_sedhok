import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/fx.dart';
import '../../widgets/pills.dart';
import '../../widgets/sard_icons.dart';

/// «الأضواء» — كاروسيل Coverflow ثلاثي الأبعاد:
///  • بطاقات تميل نحو المركز بمنظور حقيقي مع لمعة زجاجية تنزلق فوقها.
///  • خلفية ضبابية من غلاف العمل الحالي تتبدّل بنعومة.
///  • لوحة معلومات (عنوان، أنواع، نبذة، زر) تتبدّل بتلاشٍ وانزلاق.
///  • تشغيل تلقائي بمؤشّر تقدّم داخل النقطة النشطة، ويتوقف عند لمس المستخدم.
///  • [onFocus] يُبلغ الصفحة الرئيسية بالعمل الحالي لتلوّن الوهج المحيط به.
class HeroCarousel extends StatefulWidget {
  const HeroCarousel({
    super.key,
    required this.items,
    required this.onTap,
    this.onFocus,
  });

  final List<Series> items;
  final ValueChanged<Series> onTap;
  final ValueChanged<Series>? onFocus;

  @override
  State<HeroCarousel> createState() => _HeroCarouselState();
}

class _HeroCarouselState extends State<HeroCarousel> with SingleTickerProviderStateMixin {
  late final PageController _pc = PageController(viewportFraction: 0.7);
  late final AnimationController _auto = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 7),
  )..addStatusListener((status) {
      if (status == AnimationStatus.completed) _advance();
    });

  int _cur = 0;
  bool _dragging = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _announce());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final reduce = MediaQuery.of(context).disableAnimations;
    if (reduce || widget.items.length < 2) {
      _auto.stop();
    } else if (!_auto.isAnimating && !_dragging) {
      _auto.forward(from: _auto.value);
    }
  }

  @override
  void didUpdateWidget(covariant HeroCarousel old) {
    super.didUpdateWidget(old);
    if (_cur >= widget.items.length) _cur = 0;
  }

  @override
  void dispose() {
    _auto.dispose();
    _pc.dispose();
    super.dispose();
  }

  void _announce() {
    if (!mounted || widget.items.isEmpty) return;
    widget.onFocus?.call(widget.items[_cur.clamp(0, widget.items.length - 1)]);
  }

  void _advance() {
    if (!mounted || !_pc.hasClients || widget.items.length < 2) return;
    _goTo((_cur + 1) % widget.items.length);
  }

  void _goTo(int i) {
    if (!_pc.hasClients) return;
    _pc.animateToPage(
      i,
      duration: const Duration(milliseconds: 750),
      curve: Curves.easeInOutCubic,
    );
  }

  double get _pageValue => _pc.hasClients ? (_pc.page ?? _cur.toDouble()) : _cur.toDouble();

  bool _onScroll(ScrollNotification n) {
    if (n.depth != 0) return false;
    if (n is ScrollStartNotification && n.dragDetails != null) {
      _dragging = true;
      _auto.stop();
    } else if (n is ScrollEndNotification && _dragging) {
      _dragging = false;
      if (widget.items.length > 1) _auto.forward(from: 0);
    }
    return false;
  }

  void _onPageChanged(int i) {
    setState(() => _cur = i);
    widget.onFocus?.call(widget.items[i]);
    if (!_dragging && widget.items.length > 1) _auto.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.items;
    if (items.isEmpty) return const SizedBox.shrink();
    final n = items.length;
    final cur = _cur.clamp(0, n - 1);
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final w = MediaQuery.sizeOf(context).width;
    final cardW = w * 0.7 - 16;
    final pageH = (cardW / 0.7 + 40).clamp(300.0, 470.0).toDouble();

    return Stack(
      children: [
        Positioned.fill(
          child: IgnorePointer(
            child: RepaintBoundary(child: _Backdrop(series: items[cur])),
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: pageH,
              child: NotificationListener<ScrollNotification>(
                onNotification: _onScroll,
                child: PageView.builder(
                  controller: _pc,
                  itemCount: n,
                  clipBehavior: Clip.none,
                  allowImplicitScrolling: true,
                  onPageChanged: _onPageChanged,
                  itemBuilder: (context, i) => AnimatedBuilder(
                    animation: _pc,
                    builder: (context, _) => RepaintBoundary(
                      child: _HeroCard(
                        series: items[i],
                        index: i,
                        delta: _pageValue - i,
                        rtl: rtl,
                        onTap: () => i == _cur ? widget.onTap(items[i]) : _goTo(i),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 4),
            _info(items[cur]),
            const SizedBox(height: 10),
            _indicator(context, n, cur),
          ],
        ),
      ],
    );
  }

  Widget _info(Series s) {
    return AnimatedSize(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      alignment: Alignment.topCenter,
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 450),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeIn,
        layoutBuilder: (current, previous) => Stack(
          alignment: Alignment.topCenter,
          children: [...previous, if (current != null) current],
        ),
        transitionBuilder: (child, anim) => FadeTransition(
          opacity: anim,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(anim),
            child: child,
          ),
        ),
        child: _HeroInfo(key: ValueKey(s.id), series: s, onTap: () => widget.onTap(s)),
      ),
    );
  }

  Widget _indicator(BuildContext context, int n, int cur) {
    final p = context.pal;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (var i = 0; i < n; i++)
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => _goTo(i),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 8),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 380),
                curve: Curves.easeOutCubic,
                width: i == cur ? 34 : 8,
                height: 6,
                decoration: BoxDecoration(
                  color: tint(p.text, 0.18),
                  borderRadius: BorderRadius.circular(99),
                ),
                child: i == cur
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: AnimatedBuilder(
                          animation: _auto,
                          builder: (context, _) => Align(
                            alignment: AlignmentDirectional.centerStart,
                            child: FractionallySizedBox(
                              widthFactor: _auto.value.clamp(0.08, 1.0).toDouble(),
                              heightFactor: 1,
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  color: p.accent,
                                  boxShadow: p.glow > 0
                                      ? [BoxShadow(color: tint(p.accent, 0.6 * p.glow), blurRadius: 8)]
                                      : null,
                                ),
                              ),
                            ),
                          ),
                        ),
                      )
                    : null,
              ),
            ),
          ),
      ],
    );
  }
}

/// خلفية ضبابية من غلاف العمل الحالي، تذوب في لون الصفحة من أعلى وأسفل.
class _Backdrop extends StatelessWidget {
  const _Backdrop({required this.series});
  final Series series;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 800),
      child: SizedBox.expand(
        key: ValueKey(series.id),
        child: Stack(
          fit: StackFit.expand,
          children: [
            ClipRect(
              child: Opacity(
                opacity: p.isDark ? 0.5 : 0.38,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
                  child: Transform.scale(
                    scale: 1.4,
                    child: CoverArt(series: series, radius: 0, showTitle: false),
                  ),
                ),
              ),
            ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [p.bg, tint(p.bg, 0), tint(p.bg, 0), p.bg],
                  stops: const [0, 0.24, 0.6, 1],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// بطاقة الغلاف: دوران ثلاثي الأبعاد + تصغير + لمعة + بارالاكس داخلي.
class _HeroCard extends StatelessWidget {
  const _HeroCard({
    required this.series,
    required this.index,
    required this.delta,
    required this.rtl,
    required this.onTap,
  });

  final Series series;
  final int index;
  final double delta;
  final bool rtl;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final d = delta.clamp(-2.0, 2.0).toDouble();
    final a = d.abs().clamp(0.0, 1.0).toDouble(); // 0 = في المركز، 1 = جار
    final sign = rtl ? -1.0 : 1.0;
    final rad = p.r(1.5).clamp(16.0, 34.0).toDouble();
    final outline = TextStyle(
      fontFamily: sardFont,
      fontSize: 58,
      fontWeight: FontWeight.w800,
      height: 1,
      foreground: Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.3
        ..color = tint(Colors.white, 0.55),
    );
    final matrix = Matrix4.identity()
      ..setEntry(3, 2, 0.0011)
      ..rotateY(d * 0.52 * sign);

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 20),
        child: Transform(
          alignment: Alignment.center,
          transform: matrix,
          child: Transform.scale(
            scale: 1 - a * 0.12,
            child: AspectRatio(
              aspectRatio: 0.7,
              child: Pressable(
                onTap: onTap,
                scale: 0.98,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(rad),
                    boxShadow: [
                      BoxShadow(
                        color: tint(Colors.black, (p.isDark ? 0.55 : 0.22) * (1 - a * 0.6)),
                        blurRadius: 30,
                        offset: const Offset(0, 16),
                      ),
                      if (p.glow > 0)
                        BoxShadow(color: tint(p.accent, 0.34 * p.glow * (1 - a)), blurRadius: 30),
                    ],
                  ),
                  foregroundDecoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(rad),
                    border: Border.all(
                      color: Color.lerp(tint(p.accent, 0.7), tint(Colors.white, 0.1), a)!,
                      width: p.borderW,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(rad),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Transform.translate(
                          offset: Offset(-d * 34 * sign, 0),
                          child: Transform.scale(
                            scale: 1.22,
                            child: CoverArt(series: series, radius: 0, showTitle: false),
                          ),
                        ),
                        DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                tint(Colors.black, 0.3),
                                Colors.transparent,
                                tint(Colors.black, 0.68),
                              ],
                              stops: const [0, 0.42, 1],
                            ),
                          ),
                        ),
                        // لمعة زجاجية تنزلق مع حركة السحب
                        IgnorePointer(
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment(-1.3 - d * sign * 0.9, -1),
                                end: Alignment(1.3 - d * sign * 0.9, 1),
                                colors: [
                                  tint(Colors.white, 0),
                                  tint(Colors.white, 0.17),
                                  tint(Colors.white, 0),
                                ],
                                stops: const [0.34, 0.5, 0.66],
                              ),
                            ),
                          ),
                        ),
                        PositionedDirectional(
                          top: 10,
                          start: 16,
                          child: Text((index + 1).toString().padLeft(2, '0'), style: outline),
                        ),
                        PositionedDirectional(
                          top: 16,
                          end: 14,
                          child: StatusTag(status: series.status),
                        ),
                        PositionedDirectional(
                          bottom: 12,
                          start: 12,
                          end: 12,
                          child: Wrap(
                            spacing: 6,
                            runSpacing: 6,
                            children: [
                              if (series.rating > 0)
                                StatPill(
                                  icon: SardIcons.star_rounded,
                                  label: series.rating.toStringAsFixed(1),
                                  onDark: true,
                                ),
                              StatPill(
                                icon: SardIcons.menu_book_rounded,
                                label: '${series.chapters} فصل',
                                onDark: true,
                              ),
                            ],
                          ),
                        ),
                        // تعتيم تدريجي للبطاقات الجانبية
                        IgnorePointer(
                          child: ColoredBox(color: tint(Colors.black, a * 0.42)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// لوحة معلومات العمل الحالي أسفل الكاروسيل.
class _HeroInfo extends StatelessWidget {
  const _HeroInfo({super.key, required this.series, required this.onTap});
  final Series series;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final genres = series.genres.take(3).toList();
    return SizedBox(
      width: double.infinity,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(28, 8, 28, 0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              series.title,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: context.ds(size: 23, height: 1.3),
            ),
            if (genres.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final g in genres)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 4),
                      decoration: BoxDecoration(
                        color: tint(p.accent, 0.13),
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(color: tint(p.accent, 0.3), width: 0.8),
                      ),
                      child: Text(
                        g,
                        style: context.ts(size: 11.5, w: FontWeight.w600, color: p.accent),
                      ),
                    ),
                ],
              ),
            ],
            if (series.synopsis.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(
                series.synopsis,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: context.ts(size: 12.5, color: p.textDim, height: 1.55),
              ),
            ],
            const SizedBox(height: 16),
            Pressable(
              onTap: onTap,
              scale: 0.95,
              child: Container(
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 26),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: AlignmentDirectional.centerStart,
                    end: AlignmentDirectional.centerEnd,
                    colors: [p.accent, Color.lerp(p.accent, p.gold, 0.4)!],
                  ),
                  borderRadius: BorderRadius.circular(99),
                  boxShadow: [
                    BoxShadow(
                      color: tint(p.accent, 0.5),
                      blurRadius: 18,
                      offset: const Offset(0, 7),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SIcon(SardIcons.play_arrow_rounded, color: p.onAccent, size: 24),
                    const SizedBox(width: 6),
                    Text(
                      'ابدأ القراءة',
                      style: context.ts(size: 14.5, w: FontWeight.w800, color: p.onAccent),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
