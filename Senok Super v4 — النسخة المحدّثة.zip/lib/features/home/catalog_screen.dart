import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../widgets/cards.dart';
import '../../widgets/fx.dart';
import '../../widgets/routes.dart';
import '../../widgets/states.dart';
import '../details/details_screen.dart';

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key, required this.title, this.section, this.genre});

  final String title;
  final String? section;
  final String? genre;

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  final ScrollController _scroll = ScrollController();
  final List<Series> _items = [];
  int _page = 1;
  bool _loading = false;
  bool _more = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _load();
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 500) {
      _load();
    }
  }

  Future<void> _load({bool reset = false}) async {
    if (_loading || (!_more && !reset)) return;
    if (reset) {
      _page = 1;
      _more = true;
      _items.clear();
      _error = null;
    }
    setState(() => _loading = true);
    try {
      final repo = context.read<SardRepository>();
      final batch = widget.genre != null
          ? await repo.category(widget.genre!, page: _page)
          : await repo.section(widget.section ?? 'popular', page: _page);
      if (!mounted) return;
      setState(() {
        _items.addAll(batch);
        _page++;
        _more = batch.length >= 20;
        _error = null;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loading = false;
        _more = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: _items.isEmpty && _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null && _items.isEmpty
              ? ErrorState(onRetry: () => _load(reset: true))
              : RefreshIndicator(
                  onRefresh: () => _load(reset: true),
                  child: ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
                    itemCount: _items.length + (_loading || _more ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index >= _items.length) {
                        return const Padding(
                          padding: EdgeInsets.all(20),
                          child: Center(child: CircularProgressIndicator()),
                        );
                      }
                      final series = _items[index];
                      final tag = 'catalog-${widget.genre ?? widget.section ?? 'all'}-${series.id}';
                      return FadeSlide(
                        index: index,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: SeriesTile(
                            series: series,
                            heroTag: tag,
                            onTap: () => Navigator.push(
                              context,
                              sardRoute(DetailsScreen(series: series, heroTag: tag)),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
