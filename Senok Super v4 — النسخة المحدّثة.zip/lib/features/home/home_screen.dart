import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/config/app_config.dart';
import '../../core/data/models.dart';
import '../../core/guide/guide_controller.dart';
import '../../core/data/repository.dart';
import '../../core/theme/app_themes.dart';
import '../../core/storage/settings.dart';
import '../../widgets/cards.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/discover_banner.dart';
import '../../widgets/fx.dart';
import '../../widgets/ink_spirit.dart';
import '../../widgets/pills.dart';
import '../../widgets/routes.dart';
import '../../widgets/side_menu.dart';
import '../../widgets/states.dart';
import '../account/stamps_screen.dart';
import '../details/details_screen.dart';
import '../search/search_screen.dart';
import 'catalog_screen.dart';
import 'hero_carousel.dart';
import '../../widgets/sard_icons.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<HomeData> _future;
  final ScrollController _scroll = ScrollController();

  /// لون العمل المعروض حالياً في الأضواء؛ يلوّن الوهج المحيط بالصفحة.
  final ValueNotifier<Color?> _tone = ValueNotifier<Color?>(null);

  @override
  void initState() {
    super.initState();
    _future = context.read<SardRepository>().home();
  }

  @override
  void dispose() {
    _scroll.dispose();
    _tone.dispose();
    super.dispose();
  }

  void _reload() {
    setState(() => _future = context.read<SardRepository>().home());
  }

  void _open(Series s, [String? tag]) {
    Navigator.of(context).push(sardRoute(DetailsScreen(series: s, heroTag: tag)));
  }

  void _notifications() {
    final p = context.pal;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: p.glass ? tint(p.surface, 0.93) : p.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(p.r(1.6).clamp(18.0, 34.0).toDouble()),
        ),
        side: BorderSide(color: p.border, width: p.borderW),
      ),
      builder: (_) => const SizedBox(
        height: 300,
        child: EmptyState(title: 'لا توجد إشعارات', subtitle: 'ستظهر هنا فصولك الجديدة وأخبار المجتمع.'),
      ),
    );
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 5) return 'سهرة موفّقة';
    if (h < 12) return 'صباح الخير';
    if (h < 18) return 'نهارك سعيد';
    return 'مساء الخير';
  }

  @override
  Widget build(BuildContext context) {
    final pal = context.pal;
    return Stack(
      children: [
        // وهج محيطي يتلوّن بلون العمل الحالي ويتحرك ببطء مع التمرير
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          height: 560,
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: Listenable.merge([_tone, _scroll]),
              builder: (context, _) {
                final off = _scroll.hasClients ? _scroll.offset : 0.0;
                final tone = _tone.value ?? pal.accent;
                return Transform.translate(
                  offset: Offset(0, -off * 0.35),
                  child: TweenAnimationBuilder<Color?>(
                    tween: ColorTween(end: tone),
                    duration: const Duration(milliseconds: 900),
                    builder: (context, c, _) => DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(0, -0.75),
                          radius: 0.95,
                          colors: [
                            tint(c ?? tone, pal.isDark ? 0.32 : 0.2),
                            tint(c ?? tone, 0),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        _body(context),
      ],
    );
  }

  Widget _body(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: FutureBuilder<HomeData>(
        future: _future,
        builder: (context, snap) {
          if (snap.hasError) return ErrorState(onRetry: _reload);
          if (!snap.hasData) return const _HomeSkeleton();
          final d = snap.data!;
          return RefreshIndicator(
            onRefresh: () async {
              _reload();
              await _future;
            },
            child: CustomScrollView(
              controller: _scroll,
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _header(context)),
                SliverPersistentHeader(
                  pinned: true,
                  delegate: _SearchHeaderDelegate(builder: _searchBar),
                ),
                SliverList(
                  delegate: SliverChildListDelegate([
                    _moods(context, d),
                    DiscoverBanner(
                      covers: [...d.featured, ...d.popular].take(3).toList(),
                      onTap: () => GuideController.instance.run(
                        'btn.discover',
                        () => Navigator.push(
                          context,
                          sardRoute(const SearchScreen(standalone: true, openFiltersOnStart: true)),
                        ),
                      ),
                    ),
                    _continueReading(context, d),
                    if (d.featured.isNotEmpty) ...[
                      _sectionHeader(context, 'الأعمال المميزة', 'featured', 'الأضواء مسلّطة عليها الآن'),
                      HeroCarousel(
                        items: d.featured,
                        onTap: _open,
                        onFocus: (s) => _tone.value = seriesTone(s),
                      ),
                    ],
                    if (d.suggestions.isNotEmpty) ...[
                      _sectionHeader(context, 'اقتراحات لك', 'suggestions', 'قد تجد فيها ضالّتك'),
                      _horizontal(
                        d.suggestions,
                        292,
                        (s) => PosterCard(
                          series: s,
                          width: 138,
                          heroTag: 'home-suggestions-${s.id}',
                          onTap: () => _open(s, 'home-suggestions-${s.id}'),
                        ),
                      ),
                    ],
                    if (d.latest.isNotEmpty) ...[
                      _sectionHeader(context, 'أحدث الفصول', 'latest', 'فصول وصلت للتو'),
                      _latestWall(context, d.latest),
                    ],
                    if (d.popular.isNotEmpty) ...[
                      _sectionHeader(context, 'الأكثر مشاهدة', 'popular', 'الأعلى مشاهدة على Senok'),
                      ..._popular(context, d.popular),
                    ],
                    const SizedBox(height: 32),
                  ]),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ───────── الرأس ─────────
  Widget _header(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Row(
        children: [
          const MenuButton(),
          const SizedBox(width: 12),
          const LogoMark(size: 46),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_greeting(), style: context.ts(size: 12, color: p.textDim)),
              Text(AppConfig.appName, style: context.ds(size: 27, height: 1.1)),
            ],
          ),
          const Spacer(),
          _streakChip(context),
          RoundIconButton(icon: SardIcons.notifications_none_rounded, onTap: _notifications),
        ],
      ),
    );
  }

  /// شعلة المواظبة: عدد الأيام المتتالية، تفتح صفحة الأختام
  Widget _streakChip(BuildContext context) {
    final streak = context.watch<SettingsController>().streak;
    if (streak <= 0) return const SizedBox.shrink();
    const flame = Color(0xFFFF8A3D);
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 10),
      child: Pressable(
        scale: 0.93,
        onTap: () => Navigator.push(context, sardRoute(const StampsScreen())),
        child: Container(
          height: 40,
          padding: const EdgeInsetsDirectional.fromSTEB(10, 0, 13, 0),
          decoration: BoxDecoration(
            color: tint(flame, 0.15),
            borderRadius: BorderRadius.circular(99),
            border: Border.all(color: tint(flame, 0.45)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SIcon(SardIcons.local_fire_department_rounded, size: 20, color: flame),
              const SizedBox(width: 5),
              Text('$streak', style: context.ts(size: 13.5, w: FontWeight.w800, color: flame)),
            ],
          ),
        ),
      ),
    );
  }

  // ───────── شريط البحث (يثبت أعلى الصفحة بزجاج عند التمرير) ─────────
  Widget _searchBar(BuildContext context, bool pinned) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
      child: Pressable(
        scale: 0.985,
        onTap: () => GuideController.instance.run(
          'btn.home_search',
          () => Navigator.of(this.context).push(sardRoute(const SearchScreen(standalone: true))),
        ),
        child: Container(
          height: 54,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          decoration: BoxDecoration(
            color: p.glass ? tint(p.surface, 0.78) : p.surface,
            borderRadius: BorderRadius.circular(p.r(1.4).clamp(10.0, 32.0).toDouble()),
            border: Border.all(
              color: pinned ? tint(p.accent, 0.35) : tint(p.border, 0.65),
              width: p.borderW,
            ),
            boxShadow: softShadow(p, strength: pinned ? 1 : 0.8),
          ),
          child: Row(
            children: [
              SIcon(SardIcons.search_rounded, color: p.textDim, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'ابحث عن مانهوا أو مانغا...',
                  style: context.ts(size: 14, color: p.textDim),
                ),
              ),
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.14),
                  shape: BoxShape.circle,
                  boxShadow: p.glow > 0
                      ? [BoxShadow(color: tint(p.accent, 0.3 * p.glow), blurRadius: 10)]
                      : null,
                ),
                child: SIcon(SardIcons.tune_rounded, color: p.accent, size: 19),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ───────── شرائح الأنواع (مأخوذة من الأعمال نفسها) ─────────
  Widget _moods(BuildContext context, HomeData d) {
    final p = context.pal;
    final counts = <String, int>{};
    for (final s in [...d.featured, ...d.suggestions, ...d.latest, ...d.popular]) {
      for (final g in s.genres) {
        counts[g] = (counts[g] ?? 0) + 1;
      }
    }
    var names = counts.keys.toList()..sort((a, b) => counts[b]!.compareTo(counts[a]!));
    if (names.isEmpty) names = ['أكشن', 'رومانسي', 'خيال', 'دراما', 'كوميدي', 'غموض'];
    names = names.take(10).toList();

    return SizedBox(
      height: 46,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
        itemCount: names.length,
        separatorBuilder: (context, i) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final g = names[i];
          final hue = (g.codeUnits.fold<int>(0, (a, b) => (a * 31 + b) & 0xffff) % 360).toDouble();
          final c = HSLColor.fromAHSL(1, hue, 0.7, 0.58).toColor();
          return FadeSlide(
            index: i,
            dy: 0,
            child: Pressable(
              scale: 0.94,
              onTap: () => Navigator.push(
                context,
                sardRoute(CatalogScreen(title: g, genre: g)),
              ),
              child: Container(
                padding: const EdgeInsetsDirectional.fromSTEB(10, 0, 16, 0),
                decoration: BoxDecoration(
                  color: p.glass ? tint(p.surface, 0.7) : p.surface,
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(color: tint(c, 0.4), width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [c, Color.lerp(c, p.accent, 0.6)!],
                        ),
                        boxShadow: [BoxShadow(color: tint(c, 0.6), blurRadius: 8)],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(g, style: context.ts(size: 13, w: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ───────── عنوان قسم ─────────
  Widget _sectionHeader(BuildContext context, String title, String section, String subtitle) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 34, 20, 16),
      child: Row(children: [
        Container(
          width: 5,
          height: 38,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(99),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [p.accent, Color.lerp(p.accent, p.gold, 0.7)!],
            ),
            boxShadow: [BoxShadow(color: tint(p.accent, 0.5), blurRadius: 10)],
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: context.ds(size: 20, height: 1.15)),
              const SizedBox(height: 3),
              Text(subtitle, style: context.ts(size: 11.5, color: p.textDim)),
            ],
          ),
        ),
        Pressable(
          onTap: () => GuideController.instance.run(
            'btn.section_all',
            () => Navigator.push(
              context,
              sardRoute(CatalogScreen(title: title, section: section)),
            ),
          ),
          child: Container(
            padding: const EdgeInsetsDirectional.fromSTEB(12, 6, 6, 6),
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(99),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('الكل', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.accent)),
                const SizedBox(width: 2),
                SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.accent),
              ],
            ),
          ),
        ),
      ]),
    );
  }

  // ───────── أحدث الفصول: جدار متدرّج بعمودين ─────────
  Widget _latestWall(BuildContext context, List<Series> items) {
    final list = items.take(6).toList();
    final a = <Widget>[];
    final b = <Widget>[];
    for (var i = 0; i < list.length; i++) {
      final col = i % 2;
      final row = i ~/ 2;
      final tall = (row + col) % 2 == 0;
      final tag = 'home-latest-${list[i].id}';
      final card = Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: FadeSlide(
          index: i,
          child: _WallCard(
            series: list[i],
            aspect: tall ? 0.74 : 0.96,
            heroTag: tag,
            onTap: () => _open(list[i], tag),
          ),
        ),
      );
      (col == 0 ? a : b).add(card);
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: Column(children: a)),
          const SizedBox(width: 14),
          Expanded(child: Column(children: [const SizedBox(height: 28), ...b])),
        ],
      ),
    );
  }

  // ───────── الأكثر مشاهدة: منصّة تتويج ─────────
  List<Widget> _popular(BuildContext context, List<Series> items) {
    final list = items.take(6).toList();
    return [
      FadeSlide(child: _RankHero(series: list[0], onTap: () => _open(list[0]))),
      if (list.length > 1)
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
          child: Row(
            children: [
              Expanded(
                child: FadeSlide(
                  index: 1,
                  child: _RankMini(rank: 2, series: list[1], onTap: () => _open(list[1])),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: list.length > 2
                    ? FadeSlide(
                        index: 2,
                        child: _RankMini(rank: 3, series: list[2], onTap: () => _open(list[2])),
                      )
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      for (var i = 3; i < list.length; i++)
        FadeSlide(
          index: i - 2,
          child: SeriesTile(
            rank: i + 1,
            series: list[i],
            heroTag: 'home-popular-${list[i].id}',
            onTap: () => _open(list[i], 'home-popular-${list[i].id}'),
          ),
        ),
    ];
  }

  // ───────── تابع القراءة ─────────
  Widget _continueReading(BuildContext context, HomeData data) {
    final progress = context.watch<SettingsController>().exportProgress();
    if (progress.isEmpty) return const SizedBox.shrink();
    final all = [...data.featured, ...data.suggestions, ...data.latest, ...data.popular];
    final unique = <String, Series>{for (final series in all) series.id: series};
    final recent = progress.entries.toList()
      ..sort((a, b) {
        final aa = a.value as Map;
        final bb = b.value as Map;
        return ((bb['c'] as num?)?.toInt() ?? 0).compareTo((aa['c'] as num?)?.toInt() ?? 0);
      });
    final items = recent.where((entry) => unique.containsKey(entry.key)).take(8).toList();
    if (items.isEmpty) return const SizedBox.shrink();
    final p = context.pal;

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 28, 20, 12),
        child: Row(children: [
          SIcon(SardIcons.bookmark_rounded, size: 20, color: p.accent),
          const SizedBox(width: 8),
          Text('تابع القراءة', style: context.ds(size: 20)),
        ]),
      ),
      SizedBox(
        height: 112,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: items.length,
          separatorBuilder: (_, i) => const SizedBox(width: 12),
          itemBuilder: (c, i) {
            final entry = items[i];
            final series = unique[entry.key]!;
            final value = entry.value as Map;
            final chapter = (value['c'] as num?)?.toInt() ?? 1;
            final page = (value['p'] as num?)?.toInt() ?? 1;
            final total = (value['t'] as num?)?.toInt() ?? 1;
            final fraction = total <= 1 ? 0.0 : ((page - 1) / (total - 1)).clamp(0.0, 1.0).toDouble();
            final tone = seriesTone(series);
            return SizedBox(
              width: 292,
              child: Pressable(
                onTap: () => _open(series),
                child: Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: p.glass ? tint(p.surface, 0.78) : p.surface,
                    borderRadius: BorderRadius.circular(p.r(1.1).clamp(10.0, 30.0).toDouble()),
                    border: Border.all(color: tint(p.border, 0.65), width: p.borderW),
                    boxShadow: [
                      BoxShadow(
                        color: tint(tone, p.isDark ? 0.2 : 0.12),
                        blurRadius: 18,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(width: 78, child: CoverArt(series: series, radius: 0)),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(8, 12, 8, 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                series.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: context.ts(size: 14, w: FontWeight.w700),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'الفصل $chapter · الصفحة $page',
                                style: context.ts(size: 11.5, color: p.textDim),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${(fraction * 100).round()}% مقروء',
                                style: context.ts(size: 11, w: FontWeight.w700, color: p.accent),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 12),
                        child: Center(
                          child: SizedBox(
                            width: 46,
                            height: 46,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                SizedBox(
                                  width: 46,
                                  height: 46,
                                  child: CircularProgressIndicator(
                                    value: fraction,
                                    strokeWidth: 3,
                                    strokeCap: StrokeCap.round,
                                    backgroundColor: tint(p.border, 0.8),
                                    color: p.accent,
                                  ),
                                ),
                                Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    color: p.accent,
                                    shape: BoxShape.circle,
                                    boxShadow: p.glow > 0
                                        ? [BoxShadow(color: tint(p.accent, 0.45 * p.glow), blurRadius: 12)]
                                        : null,
                                  ),
                                  child: SIcon(SardIcons.play_arrow_rounded, color: p.onAccent, size: 21),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    ]);
  }

  Widget _horizontal(List<Series> items, double h, Widget Function(Series) build) {
    return SizedBox(
      height: h,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        clipBehavior: Clip.none,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: items.length,
        separatorBuilder: (context, i) => const SizedBox(width: 14),
        itemBuilder: (context, i) => FadeSlide(index: i, dy: 0, child: build(items[i])),
      ),
    );
  }
}

/// ترويسة البحث المثبّتة: شفافة في الأعلى، وتصير زجاجاً ضبابياً حين تعلو المحتوى.
class _SearchHeaderDelegate extends SliverPersistentHeaderDelegate {
  _SearchHeaderDelegate({required this.builder});
  final Widget Function(BuildContext context, bool pinned) builder;

  static const double _h = 74;

  @override
  double get minExtent => _h;

  @override
  double get maxExtent => _h;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final p = context.pal;
    final bar = builder(context, overlapsContent);
    if (!overlapsContent) return SizedBox(height: _h, child: bar);
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          height: _h,
          decoration: BoxDecoration(
            color: tint(p.bg, 0.78),
            border: Border(bottom: BorderSide(color: tint(p.border, 0.5), width: 0.8)),
          ),
          child: bar,
        ),
      ),
    );
  }

  @override
  bool shouldRebuild(covariant _SearchHeaderDelegate old) => true;
}

/// بطاقة «جدار الفصول»: غلاف كامل + شارة الفصل + عنوان فوق تدرّج سفلي.
class _WallCard extends StatelessWidget {
  const _WallCard({
    required this.series,
    required this.aspect,
    required this.heroTag,
    required this.onTap,
  });
  final Series series;
  final double aspect;
  final String heroTag;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final rad = p.r(1.1).clamp(12.0, 28.0).toDouble();
    final tone = seriesTone(series);
    final genre = series.genres.isEmpty ? series.type : series.genres.first;
    return Pressable(
      onTap: onTap,
      scale: 0.97,
      child: AspectRatio(
        aspectRatio: aspect,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(rad),
            border: Border.all(color: tint(p.text, 0.07), width: p.borderW),
            boxShadow: [
              BoxShadow(
                color: tint(tone, p.isDark ? 0.26 : 0.16),
                blurRadius: 22,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(rad),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Hero(tag: heroTag, child: CoverArt(series: series, radius: rad, showTitle: false)),
                DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [tint(Colors.black, 0.25), Colors.transparent, tint(Colors.black, 0.82)],
                      stops: const [0, 0.38, 1],
                    ),
                  ),
                ),
                PositionedDirectional(
                  top: 10,
                  start: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [p.accent, Color.lerp(p.accent, p.gold, 0.5)!]),
                      borderRadius: BorderRadius.circular(99),
                      boxShadow: [BoxShadow(color: tint(p.accent, 0.5), blurRadius: 10)],
                    ),
                    child: Text(
                      'الفصل ${series.chapters}',
                      style: context.ts(size: 11, w: FontWeight.w800, color: p.onAccent),
                    ),
                  ),
                ),
                if (series.isNew) const PositionedDirectional(top: 10, end: 10, child: NewTag()),
                PositionedDirectional(
                  start: 12,
                  end: 12,
                  bottom: 12,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        series.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: context.ds(size: 14, color: Colors.white, height: 1.3),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        genre,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.ts(size: 11, color: tint(Colors.white, 0.72)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

TextStyle _outlineStyle(double size, Color c) => TextStyle(
      fontFamily: sardFont,
      fontSize: size,
      fontWeight: FontWeight.w800,
      height: 1,
      foreground: Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = c,
    );

/// المركز الأول: بطاقة عريضة بخلفية ضبابية وغلاف مائل وشارة «الأول».
class _RankHero extends StatelessWidget {
  const _RankHero({required this.series, required this.onTap});
  final Series series;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final rad = p.r(1.5).clamp(16.0, 34.0).toDouble();
    final tone = seriesTone(series);
    final genres = series.genres.take(2).join(' · ');
    return Pressable(
      onTap: onTap,
      scale: 0.98,
      child: Container(
        height: 200,
        margin: const EdgeInsets.symmetric(horizontal: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(rad),
          border: Border.all(color: tint(p.gold, 0.5), width: 1.1),
          boxShadow: [
            BoxShadow(color: tint(tone, p.isDark ? 0.34 : 0.22), blurRadius: 28, offset: const Offset(0, 12)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(rad),
          child: Stack(
            fit: StackFit.expand,
            children: [
              RepaintBoundary(
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                  child: Transform.scale(
                    scale: 1.3,
                    child: CoverArt(series: series, radius: 0, showTitle: false),
                  ),
                ),
              ),
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: AlignmentDirectional.centerStart,
                    end: AlignmentDirectional.centerEnd,
                    colors: [tint(Colors.black, 0.78), tint(Colors.black, 0.35)],
                  ),
                ),
              ),
              PositionedDirectional(
                end: 112,
                bottom: -18,
                child: Text('1', style: _outlineStyle(140, tint(p.gold, 0.55))),
              ),
              PositionedDirectional(
                top: 14,
                end: 14,
                child: Transform.rotate(
                  angle: 0.07,
                  child: Container(
                    width: 100,
                    height: 142,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: tint(Colors.black, 0.55), blurRadius: 18, offset: const Offset(0, 8))],
                    ),
                    foregroundDecoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: tint(Colors.white, 0.4)),
                    ),
                    child: CoverArt(series: series, radius: 12, showTitle: false),
                  ),
                ),
              ),
              PositionedDirectional(
                start: 16,
                end: 132,
                top: 0,
                bottom: 0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [p.gold, Color.lerp(p.gold, Colors.white, 0.4)!]),
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: Text(
                        'الأكثر مشاهدة',
                        style: context.ts(size: 11, w: FontWeight.w800, color: Colors.black),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      series.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: context.ds(size: 21, color: Colors.white, height: 1.25),
                    ),
                    if (genres.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        genres,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.ts(size: 11.5, color: tint(Colors.white, 0.72)),
                      ),
                    ],
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        if (series.rating > 0)
                          StatPill(
                            icon: SardIcons.star_rounded,
                            label: series.rating.toStringAsFixed(1),
                            onDark: true,
                          ),
                        StatPill(
                          icon: SardIcons.visibility_rounded,
                          label: formatCount(series.views),
                          onDark: true,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// المركزان الثاني والثالث: غلاف كامل بترقيم مفرّغ فضّي/برونزي.
class _RankMini extends StatelessWidget {
  const _RankMini({required this.rank, required this.series, required this.onTap});
  final int rank;
  final Series series;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final rad = p.r(1.1).clamp(12.0, 28.0).toDouble();
    final medal = rank == 2 ? const Color(0xFFD5DAE3) : const Color(0xFFE0A070);
    return Pressable(
      onTap: onTap,
      scale: 0.97,
      child: Container(
        height: 176,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(rad),
          border: Border.all(color: tint(medal, 0.5), width: 1),
          boxShadow: softShadow(p, strength: 0.9),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(rad),
          child: Stack(
            fit: StackFit.expand,
            children: [
              CoverArt(series: series, radius: 0, showTitle: false),
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [tint(Colors.black, 0.2), Colors.transparent, tint(Colors.black, 0.85)],
                    stops: const [0, 0.38, 1],
                  ),
                ),
              ),
              PositionedDirectional(
                top: 6,
                start: 12,
                child: Text('$rank', style: _outlineStyle(54, medal)),
              ),
              PositionedDirectional(
                start: 12,
                end: 12,
                bottom: 12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      series.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: context.ds(size: 13.5, color: Colors.white, height: 1.3),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        SIcon(SardIcons.visibility_rounded, size: 13, color: tint(Colors.white, 0.75)),
                        const SizedBox(width: 4),
                        Text(
                          formatCount(series.views),
                          style: context.ts(size: 11, color: tint(Colors.white, 0.85)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HomeSkeleton extends StatelessWidget {
  const _HomeSkeleton();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20),
        children: [
          Row(children: const [
            Skeleton(width: 46, height: 46, radius: 15),
            SizedBox(width: 12),
            Skeleton(width: 110, height: 28),
          ]),
          const SizedBox(height: 18),
          const Skeleton(height: 54, radius: 20),
          const SizedBox(height: 16),
          Row(children: const [
            Skeleton(width: 84, height: 38, radius: 99),
            SizedBox(width: 8),
            Skeleton(width: 96, height: 38, radius: 99),
            SizedBox(width: 8),
            Skeleton(width: 80, height: 38, radius: 99),
          ]),
          const SizedBox(height: 16),
          const Skeleton(height: 156, radius: 28),
          const SizedBox(height: 30),
          Center(child: const Skeleton(width: 220, height: 330, radius: 26)),
          const SizedBox(height: 18),
          Center(child: const Skeleton(width: 180, height: 24)),
        ],
      ),
    );
  }
}
