import 'package:flutter/material.dart';

import 'package:flutter/services.dart';

import '../../core/guide/guide_controller.dart';
import '../../widgets/nav_bar.dart';
import '../../widgets/side_menu.dart';
import '../home/home_v2.dart';
import '../misc/community_screen.dart';
import '../misc/downloads_screen.dart';
import '../misc/posts_screen.dart';
import '../search/search_screen.dart';
import '../../widgets/sard_icons.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final PageController _controller = PageController();

  /// لكل زر لون خاص به. الإعدادات انتقلت إلى القائمة الجانبية.
  static const _items = [
    NavItem(SardIcons.home_outlined, SardIcons.home_rounded, 'الرئيسية', Color(0xFFFF5A3F)),
    NavItem(SardIcons.search_rounded, SardIcons.manage_search_rounded, 'البحث', Color(0xFF3B9EFF)),
    NavItem(SardIcons.download_outlined, SardIcons.download_rounded, 'التحميلات', Color(0xFF2FCB7A)),
    NavItem(SardIcons.groups_outlined, SardIcons.groups_rounded, 'المجتمع', Color(0xFFA463F2)),
    NavItem(SardIcons.dynamic_feed_outlined, SardIcons.dynamic_feed_rounded, 'المنشورات', Color(0xFFF5A524)),
  ];

  static const _tabGuide = ['tab.home', 'tab.search', 'tab.downloads', 'tab.community', 'tab.posts'];
  static const _navLift = 72.0; // ارتفاع شريط التنقل ليظهر الشرح فوقه

  @override
  void initState() {
    super.initState();
    // أول دخول: ترحيب ثم شرح الرئيسية
    Future<void>.delayed(const Duration(milliseconds: 500), () {
      if (!mounted) return;
      GuideController.instance.show('welcome', lift: _navLift);
      GuideController.instance.show('tab.home', lift: _navLift);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _go(int i) {
    final cur = _controller.hasClients && _controller.position.haveDimensions
        ? (_controller.page ?? 0).round()
        : 0;
    _controller.animateToPage(
      i,
      duration: Duration(milliseconds: 380 + 70 * (i - cur).abs()),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const HomeV2Screen(),
      const SearchScreen(),
      const DownloadsScreen(),
      const CommunityScreen(),
      const PostsScreen(),
    ];
    return Scaffold(
      drawer: const SardDrawer(),
      drawerEdgeDragWidth: 24,
      body: PageView(
        controller: _controller,
        // سحب بين الصفحات مع ارتداد ناعم عند الأطراف
        physics: const PageScrollPhysics(parent: BouncingScrollPhysics()),
        onPageChanged: (i) {
          HapticFeedback.selectionClick();
          GuideController.instance.show(_tabGuide[i], lift: _navLift);
        },
        children: [
          for (var i = 0; i < pages.length; i++)
            _ShellPage(controller: _controller, index: i, child: pages[i]),
        ],
      ),
      bottomNavigationBar: SardNavBar(
        controller: _controller,
        items: _items,
        onTap: _go,
      ),
    );
  }
}

/// يحفظ حالة كل صفحة (لا يعيد تحميلها) ويضيف تأثير تصغير/تلاشٍ خفيف
/// أثناء الانزلاق بين الصفحات.
class _ShellPage extends StatefulWidget {
  const _ShellPage({required this.controller, required this.index, required this.child});
  final PageController controller;
  final int index;
  final Widget child;

  @override
  State<_ShellPage> createState() => _ShellPageState();
}

class _ShellPageState extends State<_ShellPage> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final c = widget.controller;
    return AnimatedBuilder(
      animation: c,
      child: widget.child,
      builder: (context, child) {
        var d = 0.0;
        if (c.hasClients && c.position.haveDimensions) {
          d = ((c.page ?? widget.index.toDouble()) - widget.index).abs().clamp(0.0, 1.0).toDouble();
        }
        // نُبقي نفس الودجت دائماً حتى لا تضيع حالة الصفحة عند التبديل
        return Opacity(
          opacity: 1 - 0.3 * d,
          child: Transform.scale(scale: 1 - 0.05 * d, child: child),
        );
      },
    );
  }
}
