import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/search_filters.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/states.dart';
import '../details/details_screen.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// البحث المتقدم — AdvancedSearch
/// فلاتر كاملة فوق SearchFilters، مع حفظ عمليات البحث
/// (SavedSearch) وإعادة استخدامها بنقرة واحدة.
/// ──────────────────────────────────────────────────────────────────────────

/// مفتاح التخزين المحلي لعمليات البحث المحفوظة.
const String kSavedSearchesPrefsKey = 'disc_saved_searches_v1';

/// أقصى عدد عمليات بحث محفوظة.
const int kSavedSearchesMax = 20;

/// عملية بحث محفوظة: استعلام + فلاتر + عدد مرات الاستخدام.
@immutable
class SavedSearch {
  const SavedSearch({
    required this.id,
    required this.label,
    this.query = '',
    this.filters = SearchFilters.none,
    this.useCount = 0,
    required this.createdAt,
    this.lastUsedAt,
  });

  /// معرّف فريد.
  final String id;

  /// تسمية يعطيها المستخدم (مثلاً «أكشن مكتمل»).
  final String label;

  /// نص البحث.
  final String query;

  /// الفلاتر المحفوظة معه.
  final SearchFilters filters;

  /// كم مرة استُخدم.
  final int useCount;

  final DateTime createdAt;

  /// آخر استخدام.
  final DateTime? lastUsedAt;

  /// نسخة بعد استخدام (يزيد العدّاد ويحدّث الوقت).
  SavedSearch used({DateTime? at}) {
    final time = at ?? DateTime.now();
    return SavedSearch(
      id: id,
      label: label,
      query: query,
      filters: filters,
      useCount: useCount + 1,
      createdAt: createdAt,
      lastUsedAt: time,
    );
  }

  /// نسخة بتسمية جديدة.
  SavedSearch renamed(String newLabel) => SavedSearch(
        id: id,
        label: newLabel,
        query: query,
        filters: filters,
        useCount: useCount,
        createdAt: createdAt,
        lastUsedAt: lastUsedAt,
      );

  /// وصف مختصر للفلاتر (يُعرض تحت التسمية).
  String get summary {
    final parts = <String>[];
    if (query.isNotEmpty) parts.add('«$query»');
    if (filters.genres.isNotEmpty) {
      parts.add(filters.genres.join('، '));
    }
    if (filters.statuses.isNotEmpty) {
      parts.add(filters.statuses.join('، '));
    }
    if (filters.minRating > 0) {
      parts.add('تقييم ${filters.minRating.toStringAsFixed(1)}+');
    }
    if (filters.sort != 'new') {
      parts.add(_sortLabel(filters.sort));
    }
    if (parts.isEmpty) return 'بدون فلاتر';
    return parts.join(' · ');
  }

  static String _sortLabel(String sort) {
    switch (sort) {
      case 'views':
        return 'الأكثر مشاهدة';
      case 'rating':
        return 'الأعلى تقييماً';
      case 'chapters':
        return 'الأكثر فصولاً';
      case 'chapters_asc':
        return 'الأقل فصولاً';
      case 'year':
        return 'الأحدث إصداراً';
      default:
        return 'الأحدث';
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'query': query,
        'filters': _filtersToJson(filters),
        'use_count': useCount,
        'created_at': createdAt.toIso8601String(),
        'last_used_at': lastUsedAt?.toIso8601String(),
      };

  static Map<String, dynamic> _filtersToJson(SearchFilters f) => {
        'types': f.types.toList(),
        'genres': f.genres.toList(),
        'exclude': f.exclude.toList(),
        'match_all': f.matchAllGenres,
        'statuses': f.statuses.toList(),
        'chapters_min': f.chaptersMin,
        'chapters_max': f.chaptersMax,
        'min_rating': f.minRating,
        'min_views': f.minViews,
        'year_from': f.yearFrom,
        'year_to': f.yearTo,
        'only_new': f.onlyNew,
        'sort': f.sort,
      };

  factory SavedSearch.fromJson(Map<String, dynamic> j) {
    final raw = j['filters'];
    final f = raw is Map
        ? _filtersFromJson(Map<String, dynamic>.from(raw))
        : SearchFilters.none;
    return SavedSearch(
      id: '${j['id'] ?? ''}',
      label: '${j['label'] ?? 'بحث محفوظ'}',
      query: '${j['query'] ?? ''}',
      filters: f,
      useCount: (j['use_count'] as num?)?.toInt() ?? 0,
      createdAt:
          DateTime.tryParse('${j['created_at'] ?? ''}') ?? DateTime.now(),
      lastUsedAt: j['last_used_at'] == null
          ? null
          : DateTime.tryParse('${j['last_used_at']}'),
    );
  }

  static SearchFilters _filtersFromJson(Map<String, dynamic> j) {
    Set<String> set(dynamic v) => ((v as List?) ?? const [])
        .map((e) => '$e')
        .where((e) => e.isNotEmpty)
        .toSet();
    return SearchFilters(
      types: set(j['types']),
      genres: set(j['genres']),
      exclude: set(j['exclude']),
      matchAllGenres: j['match_all'] != false,
      statuses: set(j['statuses']),
      chaptersMin: (j['chapters_min'] as num?)?.toInt(),
      chaptersMax: (j['chapters_max'] as num?)?.toInt(),
      minRating: (j['min_rating'] as num?)?.toDouble() ?? 0,
      minViews: (j['min_views'] as num?)?.toInt() ?? 0,
      yearFrom: (j['year_from'] as num?)?.toInt(),
      yearTo: (j['year_to'] as num?)?.toInt(),
      onlyNew: j['only_new'] == true,
      sort: '${j['sort'] ?? 'new'}',
    );
  }

  static String newId() =>
      'saved_${DateTime.now().millisecondsSinceEpoch}';
}

/// مخزن عمليات البحث المحفوظة (نسخة واحدة [SavedSearchStore.i]).
class SavedSearchStore extends ChangeNotifier {
  SavedSearchStore._(this._prefs) {
    _readFromPrefs();
  }

  SavedSearchStore._deferred() : _prefs = null;

  /// النسخة الوحيدة في التطبيق.
  static final SavedSearchStore i = SavedSearchStore._deferred();

  /// نسخة للاختبارات مبنية على تفضيلات جاهزة (متزامنة).
  factory SavedSearchStore.testInstance(SharedPreferences prefs) =>
      SavedSearchStore._(prefs);

  /// نسخة جديدة محمّلة من التخزين.
  static Future<SavedSearchStore> loadNew() async =>
      SavedSearchStore._(await SharedPreferences.getInstance());

  SharedPreferences? _prefs;
  List<SavedSearch> _items = const [];

  /// كل العمليات المحفوظة (الأكثر استخداماً أولاً).
  List<SavedSearch> get items => List.unmodifiable(_items);

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _readFromPrefs();
    notifyListeners();
  }

  void _readFromPrefs() {
    final raw = _prefs?.getString(kSavedSearchesPrefsKey);
    if (raw == null || raw.isEmpty) {
      _items = const [];
      return;
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        final list = decoded
            .whereType<Map>()
            .map((e) =>
                SavedSearch.fromJson(Map<String, dynamic>.from(e)))
            .where((s) => s.id.isNotEmpty)
            .toList();
        list.sort((a, b) => b.useCount.compareTo(a.useCount));
        _items = list.take(kSavedSearchesMax).toList();
      }
    } catch (_) {
      _items = const [];
    }
  }

  Future<bool> _persist() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    final raw = jsonEncode(_items.map((s) => s.toJson()).toList());
    return prefs.setString(kSavedSearchesPrefsKey, raw);
  }

  void _saveAndNotify() {
    unawaited(_persist());
    notifyListeners();
  }

  /// عملية بحث بمعرّفها، أو null.
  SavedSearch? byId(String id) {
    for (final s in _items) {
      if (s.id == id) return s;
    }
    return null;
  }

  /// يحفظ بحثاً حالياً ويعيده.
  SavedSearch save({
    required String label,
    String query = '',
    SearchFilters filters = SearchFilters.none,
  }) {
    final item = SavedSearch(
      id: SavedSearch.newId(),
      label: label.trim().isEmpty ? 'بحث محفوظ' : label.trim(),
      query: query.trim(),
      filters: filters,
      createdAt: DateTime.now(),
    );
    _items = [item, ..._items].take(kSavedSearchesMax).toList();
    _saveAndNotify();
    return item;
  }

  /// يسجّل استخدام عملية محفوظة (يزيد عدّادها).
  void recordUse(String id) {
    final i = _items.indexWhere((s) => s.id == id);
    if (i < 0) return;
    final next = _items[i].used();
    _items = List<SavedSearch>.from(_items)..[i] = next;
    _items.sort((a, b) => b.useCount.compareTo(a.useCount));
    _saveAndNotify();
  }

  /// يعيد تسمية عملية محفوظة.
  bool rename(String id, String newLabel) {
    final i = _items.indexWhere((s) => s.id == id);
    if (i < 0) return false;
    _items = List<SavedSearch>.from(_items)
      ..[i] = _items[i].renamed(newLabel.trim());
    _saveAndNotify();
    return true;
  }

  /// يحذف عملية محفوظة.
  bool remove(String id) {
    final before = _items.length;
    _items = _items.where((s) => s.id != id).toList();
    if (_items.length == before) return false;
    _saveAndNotify();
    return true;
  }

  /// يمسح الكل.
  void clear() {
    _items = const [];
    _saveAndNotify();
  }
}

/// خيارات الترتيب المتاحة في البحث المتقدم.
const List<(String, String)> kAdvancedSortOptions = [
  ('new', 'الأحدث'),
  ('views', 'الأكثر مشاهدة'),
  ('rating', 'الأعلى تقييماً'),
  ('chapters', 'الأكثر فصولاً'),
  ('chapters_asc', 'الأقل فصولاً'),
  ('year', 'الأحدث إصداراً'),
];

/// شاشة البحث المتقدم: حقل بحث + فلاتر كاملة + نتائج + محفوظات.
///
/// تُفتح من شاشة الاكتشاف ومن شاشة البحث. النتائج تأتي من
/// [SardRepository.searchFiltered] (وضع تجريبي محلي عند غياب السيرفر).
class AdvancedSearchScreen extends StatefulWidget {
  const AdvancedSearchScreen({
    super.key,
    this.initialQuery = '',
    this.initialFilters = SearchFilters.none,
    this.repository,
  });

  final String initialQuery;
  final SearchFilters initialFilters;
  final SardRepository? repository;

  @override
  State<AdvancedSearchScreen> createState() => _AdvancedSearchScreenState();
}

class _AdvancedSearchScreenState extends State<AdvancedSearchScreen> {
  late final TextEditingController _queryCtl;
  late SearchFilters _f;
  late Future<List<Series>> _future;
  late final SardRepository _repo;
  bool _showFilters = false;

  @override
  void initState() {
    super.initState();
    _queryCtl = TextEditingController(text: widget.initialQuery);
    _f = widget.initialFilters;
    _repo = widget.repository ?? SardRepository();
    _future = _run();
    _showFilters = _f.isActive;
  }

  @override
  void dispose() {
    _queryCtl.dispose();
    super.dispose();
  }

  Future<List<Series>> _run() {
    return _repo.searchFiltered(_queryCtl.text.trim(), _f);
  }

  void _refresh() {
    setState(() => _future = _run());
  }

  void _setFilters(SearchFilters next) {
    setState(() {
      _f = next;
      _future = _run();
    });
  }

  Future<void> _saveCurrent() async {
    final p = context.pal;
    final ctl = TextEditingController(
      text: _queryCtl.text.trim().isEmpty
          ? _f.genres.isNotEmpty
              ? _f.genres.first
              : 'بحث محفوظ'
          : _queryCtl.text.trim(),
    );
    final label = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(p.r(1.0)),
        ),
        title: Text('حفظ هذا البحث', style: context.ds(size: 18)),
        content: TextField(
          controller: ctl,
          autofocus: true,
          style: context.ts(size: 15),
          decoration: InputDecoration(
            hintText: 'اسم البحث المحفوظ',
            hintStyle: context.ts(size: 14, color: p.textDim),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(p.r(0.8)),
              borderSide: BorderSide(color: p.border),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('إلغاء', style: context.ts(color: p.textDim)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(ctl.text.trim()),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    if (label == null || label.isEmpty) return;
    SavedSearchStore.i.save(
      label: label,
      query: _queryCtl.text.trim(),
      filters: _f,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('حُفظ البحث «$label»')),
    );
    setState(() {});
  }

  void _applySaved(SavedSearch s) {
    SavedSearchStore.i.recordUse(s.id);
    _queryCtl.text = s.query;
    _setFilters(s.filters);
    setState(() => _showFilters = s.filters.isActive);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final saved = SavedSearchStore.i.items;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('بحث متقدم', style: context.ds(size: 20)),
        actions: [
          IconButton(
            onPressed: _saveCurrent,
            icon: SIcon(SardIcons.bookmark_rounded, color: p.text),
            tooltip: 'حفظ هذا البحث',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              controller: _queryCtl,
              style: context.ts(size: 15),
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _refresh(),
              decoration: InputDecoration(
                hintText: 'ابحث عن عنوان، تصنيف، كاتب...',
                hintStyle: context.ts(size: 14, color: p.textDim),
                prefixIcon: SIcon(SardIcons.search_rounded,
                    color: p.textDim, size: 20),
                suffixIcon: _queryCtl.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _queryCtl.clear();
                          _refresh();
                        },
                        icon: SIcon(SardIcons.close_rounded,
                            color: p.textDim, size: 18),
                      ),
                filled: true,
                fillColor: p.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(p.r(1.0)),
                  borderSide: BorderSide(color: p.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(p.r(1.0)),
                  borderSide: BorderSide(color: p.border),
                ),
              ),
            ),
          ),
          _FilterToggleRow(
            activeCount: _f.activeCount,
            expanded: _showFilters,
            onToggle: () => setState(() => _showFilters = !_showFilters),
            onClear: _f.isActive
                ? () => _setFilters(SearchFilters.none)
                : null,
          ),
          if (_showFilters)
            _FiltersPanel(
              filters: _f,
              onChanged: _setFilters,
            ),
          if (_f.isActive)
            _ActiveChipsRow(
              filters: _f,
              onChanged: _setFilters,
            ),
          if (saved.isNotEmpty && _queryCtl.text.isEmpty && !_f.isActive)
            _SavedSearchesRow(
              items: saved,
              onApply: _applySaved,
              onDelete: (s) {
                SavedSearchStore.i.remove(s.id);
                setState(() {});
              },
            ),
          Expanded(
            child: FutureBuilder<List<Series>>(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(
                      child: CircularProgressIndicator());
                }
                if (snap.hasError) {
                  return ErrorState(onRetry: _refresh);
                }
                final list = snap.data ?? const <Series>[];
                if (list.isEmpty) {
                  return const EmptyState(
                    title: 'لا نتائج مطابقة',
                    subtitle: 'جرّب تخفيف الفلاتر أو كلمة بحث أخرى.',
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  itemCount: list.length,
                  itemBuilder: (context, i) {
                    final s = list[i];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: SeriesTile(
                        series: s,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) =>
                                  DetailsScreen(series: s),
                            ),
                          );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// صف تبديل عرض الفلاتر مع عدّاد الفلاتر المفعّلة.
class _FilterToggleRow extends StatelessWidget {
  const _FilterToggleRow({
    required this.activeCount,
    required this.expanded,
    required this.onToggle,
    this.onClear,
  });

  final int activeCount;
  final bool expanded;
  final VoidCallback onToggle;
  final VoidCallback? onClear;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Pressable(
            onTap: onToggle,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: activeCount > 0
                    ? tint(p.accent, 0.14)
                    : p.surface,
                borderRadius: BorderRadius.circular(p.r(1.2)),
                border: Border.all(
                  color:
                      activeCount > 0 ? tint(p.accent, 0.4) : p.border,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SIcon(SardIcons.tune_rounded,
                      size: 18,
                      color: activeCount > 0 ? p.accent : p.text),
                  const SizedBox(width: 6),
                  Text(
                    activeCount > 0
                        ? 'الفلاتر ($activeCount)'
                        : 'الفلاتر',
                    style: context.ts(
                      size: 13.5,
                      w: FontWeight.w700,
                      color: activeCount > 0 ? p.accent : p.text,
                    ),
                  ),
                  const SizedBox(width: 4),
                  SIcon(
                    expanded
                        ? SardIcons.expand_less_rounded
                        : SardIcons.expand_more_rounded,
                    size: 18,
                    color: p.textDim,
                  ),
                ],
              ),
            ),
          ),
          const Spacer(),
          if (onClear != null)
            TextButton(
              onPressed: onClear,
              child: Text('مسح الكل',
                  style: context.ts(size: 13, color: p.accent)),
            ),
        ],
      ),
    );
  }
}

/// شرائح الفلاتر المفعّلة القابلة للإزالة بنقرة.
class _ActiveChipsRow extends StatelessWidget {
  const _ActiveChipsRow({required this.filters, required this.onChanged});

  final SearchFilters filters;
  final ValueChanged<SearchFilters> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final chips = filters.activeChips();
    if (chips.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        itemCount: chips.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final (label, next) = chips[i];
          return Pressable(
            onTap: () => onChanged(next),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: tint(p.accent, 0.12),
                borderRadius: BorderRadius.circular(p.r(1.4)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(label,
                      style: context.ts(
                          size: 12.5, w: FontWeight.w700, color: p.accent)),
                  const SizedBox(width: 4),
                  SIcon(SardIcons.close_rounded,
                      size: 14, color: p.accent),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// لوحة الفلاتر الكاملة (أنواع، تصنيفات، حالة، فصول، تقييم، سنة، ترتيب).
class _FiltersPanel extends StatelessWidget {
  const _FiltersPanel({required this.filters, required this.onChanged});

  final SearchFilters filters;
  final ValueChanged<SearchFilters> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionLabel('النوع'),
          _ChipWrap(
            options: SearchFilters.typeOptions,
            selected: filters.types,
            onToggle: (v) {
              final next = Set<String>.from(filters.types);
              if (next.contains(v)) {
                next.remove(v);
              } else {
                next.add(v);
              }
              onChanged(filters.copyWith(types: next));
            },
          ),
          _SectionLabel('التصنيفات'),
          _ChipWrap(
            options: SearchFilters.genreOptions,
            selected: filters.genres,
            onToggle: (v) {
              final next = Set<String>.from(filters.genres);
              if (next.contains(v)) {
                next.remove(v);
              } else {
                next.add(v);
              }
              onChanged(filters.copyWith(genres: next));
            },
          ),
          Row(
            children: [
              Text('مطابقة كل التصنيفات',
                  style: context.ts(size: 13, color: p.textDim)),
              const Spacer(),
              Switch(
                value: filters.matchAllGenres,
                activeColor: p.accent,
                onChanged: (v) =>
                    onChanged(filters.copyWith(matchAllGenres: v)),
              ),
            ],
          ),
          _SectionLabel('استبعاد تصنيفات'),
          _ChipWrap(
            options: SearchFilters.genreOptions,
            selected: filters.exclude,
            onToggle: (v) {
              final next = Set<String>.from(filters.exclude);
              if (next.contains(v)) {
                next.remove(v);
              } else {
                next.add(v);
              }
              onChanged(filters.copyWith(exclude: next));
            },
          ),
          _SectionLabel('الحالة'),
          _ChipWrap(
            options: SearchFilters.statusOptions,
            selected: filters.statuses,
            onToggle: (v) {
              final next = Set<String>.from(filters.statuses);
              if (next.contains(v)) {
                next.remove(v);
              } else {
                next.add(v);
              }
              onChanged(filters.copyWith(statuses: next));
            },
          ),
          _SectionLabel(
              'التقييم الأدنى: ${filters.minRating.toStringAsFixed(1)}'),
          Slider(
            value: filters.minRating,
            min: 0,
            max: 9.5,
            divisions: 19,
            activeColor: p.accent,
            onChanged: (v) => onChanged(filters.copyWith(minRating: v)),
          ),
          Row(
            children: [
              Expanded(
                child: _NumberField(
                  label: 'فصول من',
                  value: filters.chaptersMin,
                  onChanged: (v) => onChanged(
                      filters.copyWith(chaptersMin: v)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _NumberField(
                  label: 'فصول إلى',
                  value: filters.chaptersMax,
                  onChanged: (v) => onChanged(
                      filters.copyWith(chaptersMax: v)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _NumberField(
                  label: 'سنة من',
                  value: filters.yearFrom,
                  onChanged: (v) =>
                      onChanged(filters.copyWith(yearFrom: v)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _NumberField(
                  label: 'سنة إلى',
                  value: filters.yearTo,
                  onChanged: (v) =>
                      onChanged(filters.copyWith(yearTo: v)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text('جديد فقط',
                  style: context.ts(size: 13, color: p.textDim)),
              const Spacer(),
              Switch(
                value: filters.onlyNew,
                activeColor: p.accent,
                onChanged: (v) =>
                    onChanged(filters.copyWith(onlyNew: v)),
              ),
            ],
          ),
          _SectionLabel('الترتيب'),
          _ChipWrap(
            options: kAdvancedSortOptions.map((e) => e.$2).toList(),
            selected: {
              kAdvancedSortOptions
                  .firstWhere((e) => e.$1 == filters.sort,
                      orElse: () => kAdvancedSortOptions.first)
                  .$2
            },
            onToggle: (label) {
              final sort = kAdvancedSortOptions
                  .firstWhere((e) => e.$2 == label,
                      orElse: () => kAdvancedSortOptions.first)
                  .$1;
              onChanged(filters.copyWith(sort: sort));
            },
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 6),
      child: Text(text,
          style: context.ds(size: 14.5, w: FontWeight.w700)),
    );
  }
}

/// صف شرائح اختيار (متعددة أو واحدة).
class _ChipWrap extends StatelessWidget {
  const _ChipWrap({
    required this.options,
    required this.selected,
    required this.onToggle,
  });

  final List<String> options;
  final Set<String> selected;
  final ValueChanged<String> onToggle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: options.map((o) {
        final on = selected.contains(o);
        return Pressable(
          onTap: () => onToggle(o),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
            decoration: BoxDecoration(
              color: on ? p.accent : p.surfaceHi,
              borderRadius: BorderRadius.circular(p.r(1.4)),
              border: Border.all(
                color: on ? p.accent : p.border,
              ),
            ),
            child: Text(
              o,
              style: context.ts(
                size: 13,
                w: FontWeight.w600,
                color: on ? p.onAccent : p.text,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// حقل رقمي صغير (فصول/سنة) بقيمة اختيارية.
/// متحكم ثابت داخل State حتى لا يفقد المؤشر موضعه أثناء الكتابة.
class _NumberField extends StatefulWidget {
  const _NumberField({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final int? value;
  final ValueChanged<int?> onChanged;

  @override
  State<_NumberField> createState() => _NumberFieldState();
}

class _NumberFieldState extends State<_NumberField> {
  late final TextEditingController _ctl;

  @override
  void initState() {
    super.initState();
    _ctl = TextEditingController(text: widget.value?.toString() ?? '');
  }

  @override
  void didUpdateWidget(covariant _NumberField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value &&
        _ctl.text != (widget.value?.toString() ?? '')) {
      _ctl.text = widget.value?.toString() ?? '';
    }
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return TextField(
      controller: _ctl,
      keyboardType: TextInputType.number,
      style: context.ts(size: 14),
      decoration: InputDecoration(
        labelText: widget.label,
        labelStyle: context.ts(size: 12.5, color: p.textDim),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(p.r(0.8)),
          borderSide: BorderSide(color: p.border),
        ),
      ),
      onChanged: (raw) {
        final v = int.tryParse(raw.trim());
        widget.onChanged(v);
      },
    );
  }
}

/// صف عمليات البحث المحفوظة (أفقي، قابل للتطبيق والحذف).
class _SavedSearchesRow extends StatelessWidget {
  const _SavedSearchesRow({
    required this.items,
    required this.onApply,
    required this.onDelete,
  });

  final List<SavedSearch> items;
  final ValueChanged<SavedSearch> onApply;
  final ValueChanged<SavedSearch> onDelete;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: Text('عمليات بحث محفوظة',
              style: context.ds(size: 15, w: FontWeight.w700)),
        ),
        SizedBox(
          height: 86,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) {
              final s = items[i];
              return Pressable(
                onTap: () => onApply(s),
                child: Container(
                  width: 190,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: p.surface,
                    borderRadius: BorderRadius.circular(p.r(0.9)),
                    border: Border.all(color: p.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              s.label,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: context.ts(
                                  size: 13.5, w: FontWeight.w700),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => onDelete(s),
                            child: SIcon(SardIcons.close_rounded,
                                size: 15, color: p.textDim),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        s.summary,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                      const Spacer(),
                      Text(
                        'استُخدم ${s.useCount} مرة',
                        style: context.ts(size: 11, color: p.textDim),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
