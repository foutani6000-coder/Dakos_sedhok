import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/discovery/reading_history.dart';
import '../../core/discovery/taste_profile.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// الموجز الأسبوعي — WeeklyDigest
/// ملخص كل أسبوع: كم فصلاً، كم دقيقة (تقدير)، ما أكثر عمل،
/// ما التصنيف الغالب، واقتراح واحد للأسبوع القادم.
/// يُبنى من سجل القراءة المحلي فقط.
/// ──────────────────────────────────────────────────────────────────────────

/// مفتاح التخزين المحلي للموجزات.
const String kWeeklyDigestPrefsKey = 'disc_weekly_digests_v1';

/// أقصى عدد موجزات محفوظة.
const int kWeeklyDigestMaxKept = 4;

/// موجز أسبوع واحد (غير قابل للتعديل).
@immutable
class WeeklyDigest {
  const WeeklyDigest({
    required this.id,
    required this.weekStart,
    required this.weekEnd,
    required this.chaptersRead,
    required this.minutesEstimate,
    required this.activeDays,
    required this.distinctSeries,
    required this.topSeriesId,
    required this.topSeriesTitle,
    required this.topSeriesChapters,
    required this.topGenre,
    required this.recommendationTitle,
    required this.recommendationReason,
    required this.quoteOfPeriod,
    required this.followedCount,
    required this.streak,
  });

  /// معرّف الموجز (مفتاح الاثنين YYYY-MM-DD).
  final String id;

  /// بداية الأسبوع (الاثنين).
  final DateTime weekStart;

  /// نهاية الأسبوع (الأحد).
  final DateTime weekEnd;

  /// فصول مقروءة في الأسبوع.
  final int chaptersRead;

  /// دقائق تقديرية (5 دقائق للفصل إن لم تُسجَّل ثوانٍ).
  final int minutesEstimate;

  /// أيام القراءة النشطة في الأسبوع.
  final int activeDays;

  /// أعمال مختلفة قُرئت في الأسبوع.
  final int distinctSeries;

  /// معرّف أكثر عمل قراءةً في الأسبوع.
  final String topSeriesId;

  /// عنوان أكثر عمل قراءةً.
  final String topSeriesTitle;

  /// فصول أكثر عمل قراءةً.
  final int topSeriesChapters;

  /// التصنيف الغالب في الأسبوع (من ذاكرة الأعمال).
  final String? topGenre;

  /// عنوان العمل المقترح للأسبوع القادم.
  final String recommendationTitle;

  /// سبب الاقتراح.
  final String recommendationReason;

  /// اقتباس الأسبوع (قواعدي من قائمة ثابتة).
  final String quoteOfPeriod;

  /// عدد الأعمال المتابَعة (للسياق).
  final int followedCount;

  /// السلسلة عند نهاية الأسبوع.
  final int streak;

  /// تسمية الفترة («12 – 18 مايو»).
  String get periodLabel =>
      '${weekStart.day} – ${weekEnd.day} ${kDigestMonths[weekEnd.month - 1]} ${weekEnd.year}';

  /// هل الأسبوع نشط (قُرئ فيه شيء)؟
  bool get hasActivity => chaptersRead > 0;

  /// نص مشاركة الموجز.
  String toShareText() {
    final buffer = StringBuffer('موجزي في القراءة على «Senok»\n');
    buffer.writeln('الأسبوع: $periodLabel');
    buffer.writeln('• قرأت $chaptersRead فصلاً في $activeDays أيام');
    buffer.writeln('• نحو $minutesEstimate دقيقة (تقدير)');
    if (topSeriesTitle.isNotEmpty) {
      buffer.writeln(
          '• أكثر عمل: «$topSeriesTitle» ($topSeriesChapters فصول)');
    }
    if (topGenre != null) {
      buffer.writeln('• تصنيف الأسبوع: $topGenre');
    }
    if (recommendationTitle.isNotEmpty) {
      buffer.writeln('• أقترح عليك الأسبوع القادم: «$recommendationTitle»');
    }
    return buffer.toString().trimRight();
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'week_start': weekStart.toIso8601String(),
        'week_end': weekEnd.toIso8601String(),
        'chapters_read': chaptersRead,
        'minutes_estimate': minutesEstimate,
        'active_days': activeDays,
        'distinct_series': distinctSeries,
        'top_series_id': topSeriesId,
        'top_series_title': topSeriesTitle,
        'top_series_chapters': topSeriesChapters,
        'top_genre': topGenre,
        'recommendation_title': recommendationTitle,
        'recommendation_reason': recommendationReason,
        'quote_of_period': quoteOfPeriod,
        'followed_count': followedCount,
        'streak': streak,
      };

  factory WeeklyDigest.fromJson(Map<String, dynamic> j) {
    return WeeklyDigest(
      id: '${j['id'] ?? ''}',
      weekStart:
          DateTime.tryParse('${j['week_start'] ?? ''}') ?? DateTime.now(),
      weekEnd:
          DateTime.tryParse('${j['week_end'] ?? ''}') ?? DateTime.now(),
      chaptersRead: (j['chapters_read'] as num?)?.toInt() ?? 0,
      minutesEstimate: (j['minutes_estimate'] as num?)?.toInt() ?? 0,
      activeDays: (j['active_days'] as num?)?.toInt() ?? 0,
      distinctSeries: (j['distinct_series'] as num?)?.toInt() ?? 0,
      topSeriesId: '${j['top_series_id'] ?? ''}',
      topSeriesTitle: '${j['top_series_title'] ?? ''}',
      topSeriesChapters: (j['top_series_chapters'] as num?)?.toInt() ?? 0,
      topGenre: j['top_genre'] as String?,
      recommendationTitle: '${j['recommendation_title'] ?? ''}',
      recommendationReason: '${j['recommendation_reason'] ?? ''}',
      quoteOfPeriod: '${j['quote_of_period'] ?? ''}',
      followedCount: (j['followed_count'] as num?)?.toInt() ?? 0,
      streak: (j['streak'] as num?)?.toInt() ?? 0,
    );
  }
}

const List<String> kDigestMonths = <String>[
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

/// اقتباسات الأسبوع (قائمة ثابتة، يُختار منها حسب رقم الأسبوع).
const List<String> kDigestQuotes = <String>[
  'الكتاب صديق لا يخون.',
  'من قرأ كثيراً عرف كثيراً.',
  'القراءة رحلة لا تنتهي.',
  'فصل واحد كل يوم يصنع مكتبة.',
  'الحكاية الجيدة تستحق السهر.',
  'اقرأ ما تحب، وستحب ما تقرأ.',
  'كل صفحة باب إلى عالم جديد.',
  'القارئ يعيش ألف حياة.',
];

/// يبني موجز أسبوع من البيانات المحلية (دوال ثابتة حتمية).
class WeeklyDigestBuilder {
  WeeklyDigestBuilder._();

  /// يبني موجز الأسبوع الذي يحتوي [now] (الاثنين..الأحد).
  static WeeklyDigest build({
    required SettingsController settings,
    required ReadingHistoryStore history,
    TasteProfile? profile,
    Series? topSeries,
    Series? recommendation,
    String? recommendationReason,
    DateTime? now,
  }) {
    final current = now ?? DateTime.now();
    final start = _startOfWeek(current);
    final end = start.add(const Duration(days: 6));
    final endOfWeek = DateTime(end.year, end.month, end.day, 23, 59, 59);

    final summary = history.summaryBetween(start, endOfWeek);
    final weekEntries = history.entriesBetween(start, endOfWeek);

    // التصنيف الغالب: من ذاكرة الأعمال المحفوظة في الإعدادات.
    var topGenre = settings.topGenre;
    if (summary.distinctSeries > 0) {
      final counts = <String, int>{};
      for (final e in weekEntries) {
        final s = settings.cachedSeries(e.seriesId);
        if (s == null) continue;
        for (final g in s.genres) {
          counts[g] = (counts[g] ?? 0) + 1;
        }
      }
      if (counts.isNotEmpty) {
        var best = '';
        var value = 0;
        for (final e in counts.entries) {
          if (e.value > value) {
            best = e.key;
            value = e.value;
          }
        }
        if (best.isNotEmpty) topGenre = best;
      }
    }

    // الدقائق: ثوانٍ مسجلة أولاً، وإلا تقدير 5 دقائق للفصل.
    final minutes = summary.seconds > 0
        ? (summary.seconds / 60).round()
        : summary.chapters * 5;

    // اقتباس الأسبوع: حسب رقم الأسبوع في السنة.
    final weekNumber = _weekNumber(start);
    final quote = kDigestQuotes[weekNumber % kDigestQuotes.length];

    // الاقتراح: العمل الممرَّر، أو أكثر عمل قراءةً، أو فارغ.
    var recTitle = recommendation?.title ?? '';
    var recReason = recommendationReason ?? '';
    if (recTitle.isEmpty && topSeries != null) {
      recTitle = topSeries.title;
      recReason = 'أكثر عمل قرأته هذا الأسبوع — أكمل رحلته.';
    }

    return WeeklyDigest(
      id: dayKey(start),
      weekStart: start,
      weekEnd: end,
      chaptersRead: summary.chapters,
      minutesEstimate: minutes,
      activeDays: summary.activeDays,
      distinctSeries: summary.distinctSeries,
      topSeriesId: topSeries?.id ?? '',
      topSeriesTitle: summary.topSeriesTitle,
      topSeriesChapters: summary.topSeriesChapters,
      topGenre: topGenre,
      recommendationTitle: recTitle,
      recommendationReason: recReason,
      quoteOfPeriod: quote,
      followedCount: settings.followedSeries.length,
      streak: history.streak(now: current),
    );
  }

  /// يبني موجز الأسبوع الماضي (للمقارنة).
  static WeeklyDigest buildLastWeek({
    required SettingsController settings,
    required ReadingHistoryStore history,
    TasteProfile? profile,
    Series? topSeries,
    DateTime? now,
  }) {
    final current = now ?? DateTime.now();
    final thisMonday = _startOfWeek(current);
    final lastMonday = thisMonday.subtract(const Duration(days: 7));
    return build(
      settings: settings,
      history: history,
      profile: profile,
      topSeries: topSeries,
      now: lastMonday.add(const Duration(days: 3)),
    );
  }

  static DateTime _startOfWeek(DateTime d) {
    final day = DateTime(d.year, d.month, d.day);
    return day.subtract(Duration(days: (d.weekday - 1) % 7));
  }

  static int _weekNumber(DateTime monday) {
    final first = DateTime(monday.year, 1, 1);
    final firstMonday = first.add(
        Duration(days: (8 - first.weekday) % 7));
    final diff = monday.difference(firstMonday).inDays;
    return (diff / 7).floor() + 1;
  }
}

/// مخزن الموجزات الأسبوعية (يحتفظ بآخر 4 موجزات).
class DigestStore extends ChangeNotifier {
  DigestStore._(this._prefs) {
    _readFromPrefs();
  }

  DigestStore._deferred() : _prefs = null;

  /// النسخة الوحيدة في التطبيق.
  static final DigestStore i = DigestStore._deferred();

  /// نسخة للاختبارات مبنية على تفضيلات جاهزة (متزامنة).
  factory DigestStore.testInstance(SharedPreferences prefs) =>
      DigestStore._(prefs);

  /// نسخة جديدة محمّلة من التخزين.
  static Future<DigestStore> loadNew() async =>
      DigestStore._(await SharedPreferences.getInstance());

  SharedPreferences? _prefs;
  List<WeeklyDigest> _digests = const [];

  /// الموجزات المحفوظة (الأحدث أولاً).
  List<WeeklyDigest> get digests => List.unmodifiable(_digests);

  /// أحدث موجز، أو null.
  WeeklyDigest? get latest =>
      _digests.isEmpty ? null : _digests.first;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _readFromPrefs();
    notifyListeners();
  }

  void _readFromPrefs() {
    final raw = _prefs?.getString(kWeeklyDigestPrefsKey);
    if (raw == null || raw.isEmpty) {
      _digests = const [];
      return;
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        final list = decoded
            .whereType<Map>()
            .map((e) =>
                WeeklyDigest.fromJson(Map<String, dynamic>.from(e)))
            .where((d) => d.id.isNotEmpty)
            .toList();
        list.sort((a, b) => b.weekStart.compareTo(a.weekStart));
        _digests = list.take(kWeeklyDigestMaxKept).toList();
      }
    } catch (_) {
      _digests = const [];
    }
  }

  Future<bool> _persist() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    final raw = jsonEncode(_digests.map((d) => d.toJson()).toList());
    return prefs.setString(kWeeklyDigestPrefsKey, raw);
  }

  void _saveAndNotify() {
    unawaited(_persist());
    notifyListeners();
  }

  /// يولّد موجز الأسبوع الحالي ويحفظه (يستبدل موجز الأسبوع نفسه).
  WeeklyDigest generate({
    required SettingsController settings,
    required ReadingHistoryStore history,
    TasteProfile? profile,
    Series? topSeries,
    Series? recommendation,
    String? recommendationReason,
    DateTime? now,
  }) {
    final digest = WeeklyDigestBuilder.build(
      settings: settings,
      history: history,
      profile: profile,
      topSeries: topSeries,
      recommendation: recommendation,
      recommendationReason: recommendationReason,
      now: now,
    );
    _digests = [
      digest,
      ..._digests.where((d) => d.id != digest.id),
    ].take(kWeeklyDigestMaxKept).toList();
    _saveAndNotify();
    return digest;
  }

  /// يحذف موجزاً.
  void remove(String id) {
    _digests = _digests.where((d) => d.id != id).toList();
    _saveAndNotify();
  }

  /// يمسح كل الموجزات.
  void clear() {
    _digests = const [];
    _saveAndNotify();
  }
}

/// شاشة الموجز الأسبوعي: بطاقة الأسبوع الحالي + أرشيف قصير.
class WeeklyDigestScreen extends StatelessWidget {
  const WeeklyDigestScreen({
    super.key,
    required this.settings,
    required this.history,
    this.topSeries,
    this.recommendation,
    this.recommendationReason,
  });

  final SettingsController settings;
  final ReadingHistoryStore history;
  final Series? topSeries;
  final Series? recommendation;
  final String? recommendationReason;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final digest = WeeklyDigestBuilder.build(
      settings: settings,
      history: history,
      topSeries: topSeries,
      recommendation: recommendation,
      recommendationReason: recommendationReason,
    );
    final archive = DigestStore.i.digests
        .where((d) => d.id != digest.id)
        .toList();
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('موجز الأسبوع', style: context.ds(size: 20)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        children: [
          _DigestHero(digest: digest, topSeries: topSeries),
          const SizedBox(height: 16),
          _DigestStatsRow(digest: digest),
          const SizedBox(height: 16),
          if (digest.recommendationTitle.isNotEmpty)
            _RecommendationCard(digest: digest),
          if (digest.recommendationTitle.isNotEmpty)
            const SizedBox(height: 16),
          _QuoteCard(digest: digest),
          const SizedBox(height: 16),
          _ShareTextCard(digest: digest),
          if (archive.isNotEmpty) ...[
            const SizedBox(height: 20),
            Text('موجزات سابقة',
                style: context.ds(size: 17)),
            const SizedBox(height: 10),
            ...archive.map((d) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ArchiveTile(digest: d),
                )),
          ],
        ],
      ),
    );
  }
}

class _DigestHero extends StatelessWidget {
  const _DigestHero({required this.digest, this.topSeries});
  final WeeklyDigest digest;
  final Series? topSeries;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(p.r(1.1)),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            p.accent,
            Color.lerp(p.accent, Colors.black, 0.25)!,
          ],
        ),
        boxShadow: softShadow(p),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.calendar_today_rounded,
                  size: 20, color: p.onAccent),
              const SizedBox(width: 8),
              Text(
                'أسبوع ${digest.periodLabel}',
                style: context.ts(
                    size: 14, w: FontWeight.w700, color: p.onAccent),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            digest.hasActivity
                ? 'قرأت ${digest.chaptersRead} فصلاً هذا الأسبوع'
                : 'أسبوع هادئ — لم تقرأ بعد',
            style: context.ds(size: 22, color: p.onAccent),
          ),
          const SizedBox(height: 6),
          Text(
            digest.hasActivity
                ? 'في ${digest.activeDays} أيام · نحو ${digest.minutesEstimate} دقيقة (تقدير) · سلسلة ${digest.streak} يوماً'
                : 'ابدأ فصلاً واحداً وستظهر أرقامك هنا الأسبوع القادم.',
            style: context.ts(size: 13, color: tint(p.onAccent, 0.85)),
          ),
          if (topSeries != null && digest.topSeriesTitle.isNotEmpty) ...[
            const SizedBox(height: 14),
            Row(
              children: [
                SizedBox(
                  width: 56,
                  height: 84,
                  child: CoverArt(series: topSeries!, radius: 10),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('أكثر عمل قرأته',
                          style: context.ts(
                              size: 12, color: tint(p.onAccent, 0.8))),
                      const SizedBox(height: 3),
                      Text(
                        digest.topSeriesTitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: context.ds(size: 16, color: p.onAccent),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${digest.topSeriesChapters} فصول هذا الأسبوع',
                        style: context.ts(
                            size: 12.5,
                            color: tint(p.onAccent, 0.85)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _DigestStatsRow extends StatelessWidget {
  const _DigestStatsRow({required this.digest});
  final WeeklyDigest digest;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _MiniStat(
          icon: SardIcons.menu_book_rounded,
          label: 'فصول',
          value: '${digest.chaptersRead}',
        ),
        const SizedBox(width: 10),
        _MiniStat(
          icon: SardIcons.watch_later_rounded,
          label: 'دقائق (تقدير)',
          value: '${digest.minutesEstimate}',
        ),
        const SizedBox(width: 10),
        _MiniStat(
          icon: SardIcons.collections_bookmark_rounded,
          label: 'أعمال',
          value: '${digest.distinctSeries}',
        ),
      ],
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({
    required this.icon,
    required this.label,
    required this.value,
  });

  final SIconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border),
        ),
        child: Column(
          children: [
            SIcon(icon, size: 18, color: p.accent),
            const SizedBox(height: 6),
            Text(value, style: context.ds(size: 19)),
            const SizedBox(height: 2),
            Text(label,
                textAlign: TextAlign.center,
                style: context.ts(size: 11.5, color: p.textDim)),
          ],
        ),
      ),
    );
  }
}

class _RecommendationCard extends StatelessWidget {
  const _RecommendationCard({required this.digest});
  final WeeklyDigest digest;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: tint(p.gold, 0.14),
              borderRadius: BorderRadius.circular(p.r(0.8)),
            ),
            child: SIcon(SardIcons.auto_awesome_rounded,
                size: 20, color: p.gold),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('اقتراح الأسبوع القادم',
                    style: context.ds(size: 15, w: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(
                  '«${digest.recommendationTitle}»',
                  style: context.ts(size: 14, w: FontWeight.w700),
                ),
                if (digest.recommendationReason.isNotEmpty) ...[
                  const SizedBox(height: 3),
                  Text(
                    digest.recommendationReason,
                    style:
                        context.ts(size: 12.5, color: p.textDim, height: 1.6),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _QuoteCard extends StatelessWidget {
  const _QuoteCard({required this.digest});
  final WeeklyDigest digest;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tint(p.accent, 0.08),
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: tint(p.accent, 0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SIcon(SardIcons.format_list_bulleted_rounded,
              size: 18, color: p.accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('اقتباس الأسبوع',
                    style: context.ds(size: 14, w: FontWeight.w700)),
                const SizedBox(height: 3),
                Text(
                  '«${digest.quoteOfPeriod}»',
                  style: context.ts(size: 13.5, height: 1.7),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ShareTextCard extends StatelessWidget {
  const _ShareTextCard({required this.digest});
  final WeeklyDigest digest;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('نص المشاركة',
              style: context.ds(size: 15, w: FontWeight.w700)),
          const SizedBox(height: 8),
          SelectableText(
            digest.toShareText(),
            style: context.ts(size: 13, height: 1.8),
          ),
        ],
      ),
    );
  }
}

class _ArchiveTile extends StatelessWidget {
  const _ArchiveTile({required this.digest});
  final WeeklyDigest digest;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          SIcon(SardIcons.history_rounded, size: 18, color: p.accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(digest.periodLabel,
                    style: context.ts(size: 13.5, w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  '${digest.chaptersRead} فصلاً · ${digest.activeDays} أيام',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          Pressable(
            onTap: () => DigestStore.i.remove(digest.id),
            child: SIcon(SardIcons.delete_outline_rounded,
                size: 18, color: p.textDim),
          ),
        ],
      ),
    );
  }
}
