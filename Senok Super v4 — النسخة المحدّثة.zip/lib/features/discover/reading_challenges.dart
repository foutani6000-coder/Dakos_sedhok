import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/discovery/reading_history.dart';
import '../../core/discovery/taste_profile.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// تحديات القراءة — ReadingChallenges
/// 12 تحدياً قواعدياً تُحسب من عدّادات محلية (فصول، أيام، تصنيفات).
///
/// يُستدعى [ChallengeStore.recordChapter] من القارئ بعد كل فصل مقروء،
/// فيحدّث العدّادات ويكتشف التحديات المكتملة. لا سيرفر ولا ذكاء اصطناعي.
/// ──────────────────────────────────────────────────────────────────────────

/// مفاتيح التخزين المحلي للتحديات.
const String kChallengePrefsKey = 'disc_challenges_v1';

/// نوع التحدي (يحدد طريقة حساب التقدم).
enum ReadingChallengeKind {
  /// فصول في الأسبوع الحالي.
  chaptersThisWeek,
  /// فصول في الشهر الحالي.
  chaptersThisMonth,
  /// فصول في السنة الحالية.
  chaptersThisYear,
  /// أيام قراءة متتالية.
  streakDays,
  /// فصول في يوم واحد.
  chaptersInOneDay,
  /// إكمال عمل واحد.
  finishSeries,
  /// بدء أعمال جديدة.
  newSeries,
  /// القراءة من تصنيفات مختلفة.
  genreExplorer,
  /// فصول بعد منتصف الليل (00:00–05:00).
  nightOwl,
  /// دقائق قراءة في الأسبوع (تقدير: 5 دقائق للفصل).
  minutesThisWeek,
  /// العودة بعد غياب.
  comeback,
  /// قراءة عمل جديد كلياً (غير مقروء من قبل).
  firstChapter,
}

/// فترة التحدي (متى يُصفَّر التقدم).
enum ChallengePeriod {
  day('يومي'),
  week('أسبوعي'),
  month('شهري'),
  year('سنوي'),
  allTime('مستمر');

  const ChallengePeriod(this.label);
  final String label;
}

/// تعريف تحدٍّ واحد (ثابت، لا يتغير).
@immutable
class ReadingChallenge {
  const ReadingChallenge({
    required this.id,
    required this.kind,
    required this.title,
    required this.description,
    required this.target,
    required this.unit,
    required this.period,
    required this.icon,
    required this.reward,
  });

  /// معرّف ثابت (يُحفظ في التخزين عند الإكمال).
  final String id;

  final ReadingChallengeKind kind;

  /// العنوان العربي.
  final String title;

  /// وصف قصير للشرط.
  final String description;

  /// الهدف الرقمي.
  final int target;

  /// وحدة الهدف («فصل»، «يوم»، «دقيقة»، «عمل»).
  final String unit;

  final ChallengePeriod period;

  /// أيقونة التحدي.
  final SIconData icon;

  /// المكافأة عند الإكمال (نص عربي، مثلاً «شارة الماراثون»).
  final String reward;

  /// نص الهدف كاملاً («اقرأ 10 فصول»).
  String get targetLabel => '$target $unit';

  /// هل الهدف كبير (يستحق تمييزاً بصرياً)؟
  bool get isEpic => target >= 100 || kind == ReadingChallengeKind.streakDays && target >= 30;
}

/// التحديات الاثنا عشر.
const List<ReadingChallenge> kReadingChallenges = <ReadingChallenge>[
  ReadingChallenge(
    id: 'chapters_week_10',
    kind: ReadingChallengeKind.chaptersThisWeek,
    title: 'أسبوع القارئ',
    description: 'اقرأ 10 فصول خلال هذا الأسبوع.',
    target: 10,
    unit: 'فصول',
    period: ChallengePeriod.week,
    icon: SardIcons.calendar_today_rounded,
    reward: 'شارة أسبوع القارئ',
  ),
  ReadingChallenge(
    id: 'chapters_month_30',
    kind: ReadingChallengeKind.chaptersThisMonth,
    title: 'ماراثون الشهر',
    description: 'اقرأ 30 فصلاً خلال هذا الشهر.',
    target: 30,
    unit: 'فصلاً',
    period: ChallengePeriod.month,
    icon: SardIcons.local_fire_department_rounded,
    reward: 'شارة ماراثون الشهر',
  ),
  ReadingChallenge(
    id: 'chapters_year_300',
    kind: ReadingChallengeKind.chaptersThisYear,
    title: 'قارئ العام',
    description: 'اقرأ 300 فصل خلال هذا العام.',
    target: 300,
    unit: 'فصل',
    period: ChallengePeriod.year,
    icon: SardIcons.star_rounded,
    reward: 'شارة قارئ العام',
  ),
  ReadingChallenge(
    id: 'streak_7',
    kind: ReadingChallengeKind.streakDays,
    title: 'مواظبة أسبوع',
    description: 'اقرأ 7 أيام متتالية دون انقطاع.',
    target: 7,
    unit: 'أيام',
    period: ChallengePeriod.allTime,
    icon: SardIcons.bolt_rounded,
    reward: 'شارة المواظبة',
  ),
  ReadingChallenge(
    id: 'streak_30',
    kind: ReadingChallengeKind.streakDays,
    title: 'شهر كامل دون انقطاع',
    description: 'اقرأ 30 يوماً متتالية دون انقطاع.',
    target: 30,
    unit: 'يوماً',
    period: ChallengePeriod.allTime,
    icon: SardIcons.local_fire_department_rounded,
    reward: 'شارة اللهب الذهبي',
  ),
  ReadingChallenge(
    id: 'marathon_day_10',
    kind: ReadingChallengeKind.chaptersInOneDay,
    title: 'يوم الماراثون',
    description: 'اقرأ 10 فصول في يوم واحد.',
    target: 10,
    unit: 'فصول',
    period: ChallengePeriod.day,
    icon: SardIcons.menu_book_rounded,
    reward: 'شارة الماراثون',
  ),
  ReadingChallenge(
    id: 'finish_one',
    kind: ReadingChallengeKind.finishSeries,
    title: 'أكملت عملاً',
    description: 'أكمل قراءة عمل حتى آخر فصل فيه.',
    target: 1,
    unit: 'عمل',
    period: ChallengePeriod.allTime,
    icon: SardIcons.check_circle_rounded,
    reward: 'شارة الإنجاز',
  ),
  ReadingChallenge(
    id: 'new_series_3',
    kind: ReadingChallengeKind.newSeries,
    title: 'مستكشف جديد',
    description: 'ابدأ قراءة 3 أعمال جديدة هذا الشهر.',
    target: 3,
    unit: 'أعمال',
    period: ChallengePeriod.month,
    icon: SardIcons.explore_rounded,
    reward: 'شارة المستكشف',
  ),
  ReadingChallenge(
    id: 'genre_explorer_5',
    kind: ReadingChallengeKind.genreExplorer,
    title: 'ذوّاقة التصنيفات',
    description: 'اقرأ من 5 تصنيفات مختلفة هذا الشهر.',
    target: 5,
    unit: 'تصنيفات',
    period: ChallengePeriod.month,
    icon: SardIcons.category_rounded,
    reward: 'شارة الذوّاقة',
  ),
  ReadingChallenge(
    id: 'night_owl_5',
    kind: ReadingChallengeKind.nightOwl,
    title: 'بومة الليل',
    description: 'اقرأ 5 فصول بعد منتصف الليل (حتى الخامسة فجراً).',
    target: 5,
    unit: 'فصول',
    period: ChallengePeriod.allTime,
    icon: SardIcons.nightlight_round,
    reward: 'شارة بومة الليل',
  ),
  ReadingChallenge(
    id: 'minutes_week_300',
    kind: ReadingChallengeKind.minutesThisWeek,
    title: 'ساعات القراءة',
    description: 'اقرأ 300 دقيقة هذا الأسبوع (تُقدَّر بـ 5 دقائق للفصل).',
    target: 300,
    unit: 'دقيقة',
    period: ChallengePeriod.week,
    icon: SardIcons.watch_later_rounded,
    reward: 'شارة ساعات القراءة',
  ),
  ReadingChallenge(
    id: 'comeback_3',
    kind: ReadingChallengeKind.comeback,
    title: 'العودة القوية',
    description: 'عُد للقراءة بعد غياب 7 أيام ثم اقرأ 3 فصول.',
    target: 3,
    unit: 'فصول',
    period: ChallengePeriod.allTime,
    icon: SardIcons.refresh_rounded,
    reward: 'شارة العودة القوية',
  ),
];

/// تقدّم تحدٍّ واحد في لحظة معينة.
@immutable
class ChallengeProgress {
  const ChallengeProgress({
    required this.challenge,
    required this.current,
    required this.completed,
    this.completedAt,
  });

  final ReadingChallenge challenge;

  /// التقدم الحالي (فصول/أيام/دقائق حسب التحدي).
  final int current;

  final bool completed;

  /// وقت الإكمال (إن اكتمل).
  final DateTime? completedAt;

  int get target => challenge.target;

  /// نسبة الإكمال 0..1.
  double get fraction =>
      target <= 0 ? 0 : (current / target).clamp(0.0, 1.0);

  /// كم بقي لإكماله.
  int get remaining => (target - current).clamp(0, target);

  /// نص التقدم («7 / 10 فصول»).
  String get progressLabel => '$current / $target ${challenge.unit}';
}

/// لقطة عدّادات يعتمد عليها حساب التقدم.
class ChallengeSnapshot {
  ChallengeSnapshot({
    required this.chaptersByDay,
    required this.finishedSeries,
    required this.newSeriesByMonth,
    required this.genresByMonth,
    required this.nightChapters,
    required this.lastReadDay,
    required this.comebackChapters,
    required this.now,
  });

  /// مفتاح اليوم (YYYY-MM-DD) ← عدد الفصول فيه.
  final Map<String, int> chaptersByDay;

  /// عدد الأعمال المكتملة.
  final int finishedSeries;

  /// مفتاح الشهر (YYYY-MM) ← أعمال جديدة بدأت فيه.
  final Map<String, int> newSeriesByMonth;

  /// مفتاح الشهر (YYYY-MM) ← تصنيفات قُرئت فيه.
  final Map<String, Set<String>> genresByMonth;

  /// عدد فصول ما بعد منتصف الليل (كل الأوقات).
  final int nightChapters;

  /// آخر يوم قُرئ فيه (للكشف عن الغياب)، أو null.
  final DateTime? lastReadDay;

  /// فصول ما بعد العودة من غياب 7 أيام.
  final int comebackChapters;

  final DateTime now;

  /// مفتاح الشهر الحالي.
  String get monthKey =>
      '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}';

  /// فصول هذا الأسبوع (من الاثنين حتى اليوم).
  int get chaptersThisWeek {
    final monday = _startOfWeek(now);
    var total = 0;
    for (final e in chaptersByDay.entries) {
      final d = DateTime.tryParse(e.key);
      if (d != null && !d.isBefore(monday)) total += e.value;
    }
    return total;
  }

  /// فصول هذا الشهر.
  int get chaptersThisMonth {
    var total = 0;
    for (final e in chaptersByDay.entries) {
      if (e.key.startsWith(monthKey)) total += e.value;
    }
    return total;
  }

  /// فصول هذه السنة.
  int get chaptersThisYear {
    var total = 0;
    final prefix = '${now.year}-';
    for (final e in chaptersByDay.entries) {
      if (e.key.startsWith(prefix)) total += e.value;
    }
    return total;
  }

  /// فصول اليوم.
  int get chaptersToday => chaptersByDay[dayKey(now)] ?? 0;

  /// دقائق هذا الأسبوع التقديرية (5 دقائق للفصل).
  int get minutesThisWeek => chaptersThisWeek * 5;

  /// أيام القراءة المتتالية حتى اليوم.
  int get streak {
    var d = DateTime(now.year, now.month, now.day);
    if ((chaptersByDay[dayKey(d)] ?? 0) <= 0) {
      d = d.subtract(const Duration(days: 1));
    }
    var n = 0;
    while ((chaptersByDay[dayKey(d)] ?? 0) > 0) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  static DateTime _startOfWeek(DateTime d) {
    final day = DateTime(d.year, d.month, d.day);
    return day.subtract(Duration(days: (d.weekday - 1) % 7));
  }
}

/// يحسب تقدّم تحدٍّ واحد من لقطة عدّادات.
class ChallengeEvaluator {
  ChallengeEvaluator._();

  static int currentOf(ReadingChallenge c, ChallengeSnapshot s) {
    switch (c.kind) {
      case ReadingChallengeKind.chaptersThisWeek:
        return s.chaptersThisWeek;
      case ReadingChallengeKind.chaptersThisMonth:
        return s.chaptersThisMonth;
      case ReadingChallengeKind.chaptersThisYear:
        return s.chaptersThisYear;
      case ReadingChallengeKind.streakDays:
        return s.streak;
      case ReadingChallengeKind.chaptersInOneDay:
        return s.chaptersToday;
      case ReadingChallengeKind.finishSeries:
        return s.finishedSeries;
      case ReadingChallengeKind.newSeries:
        return s.newSeriesByMonth[s.monthKey] ?? 0;
      case ReadingChallengeKind.genreExplorer:
        return s.genresByMonth[s.monthKey]?.length ?? 0;
      case ReadingChallengeKind.nightOwl:
        return s.nightChapters;
      case ReadingChallengeKind.minutesThisWeek:
        return s.minutesThisWeek;
      case ReadingChallengeKind.comeback:
        return s.comebackChapters;
      case ReadingChallengeKind.firstChapter:
        return s.chaptersByDay.isEmpty ? 0 : 1;
    }
  }

  static ChallengeProgress evaluate(
    ReadingChallenge c,
    ChallengeSnapshot s,
    DateTime? completedAt,
  ) {
    final current = currentOf(c, s);
    return ChallengeProgress(
      challenge: c,
      current: current,
      completed: current >= c.target || completedAt != null,
      completedAt: completedAt,
    );
  }
}

/// مخزن التحديات (نسخة واحدة [ChallengeStore.i]).
///
/// يُنادى [recordChapter] من القارئ بعد كل فصل. العدّادات تُحفظ
/// محلياً وتُستعاد عند الإقلاع عبر [load].
class ChallengeStore extends ChangeNotifier {
  ChallengeStore._(this._prefs) {
    _readFromPrefs();
  }

  ChallengeStore._deferred() : _prefs = null;

  /// النسخة الوحيدة في التطبيق.
  static final ChallengeStore i = ChallengeStore._deferred();

  /// نسخة للاختبارات مبنية على تفضيلات جاهزة (متزامنة).
  factory ChallengeStore.testInstance(SharedPreferences prefs) =>
      ChallengeStore._(prefs);

  /// نسخة جديدة محمّلة من التخزين.
  static Future<ChallengeStore> loadNew() async =>
      ChallengeStore._(await SharedPreferences.getInstance());

  SharedPreferences? _prefs;

  /// اليوم ← عدد الفصول.
  Map<String, int> _chaptersByDay = {};

  /// معرّف التحدي ← وقت إكماله (ISO).
  Map<String, String> _completedAt = {};

  /// أعمال مكتملة (المعرّف ← وقت الإكمال).
  Map<String, String> _finishedSeries = {};

  /// الشهر ← عدد الأعمال الجديدة.
  Map<String, int> _newSeriesByMonth = {};

  /// الشهر ← التصنيفات المقروءة.
  Map<String, Set<String>> _genresByMonth = {};

  /// عدد فصول ما بعد منتصف الليل.
  int _nightChapters = 0;

  /// آخر يوم قُرئ فيه (ISO للتاريخ فقط).
  String? _lastReadDay;

  /// فصول ما بعد العودة من غياب.
  int _comebackChapters = 0;

  /// هل كان هناك غياب 7 أيام قبل آخر قراءة؟
  bool _wasAway = false;

  /// آخر إشعار إكمال لم يُعرض بعد (معرّف التحدي).
  String? _pendingCelebration;

  /// معرّف تحدي اكتمل حديثاً ولم يُعرض احتفاله بعد.
  String? get pendingCelebration => _pendingCelebration;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _readFromPrefs();
    notifyListeners();
  }

  void _readFromPrefs() {
    final raw = _prefs?.getString(kChallengePrefsKey);
    if (raw == null || raw.isEmpty) return;
    try {
      final j = jsonDecode(raw);
      if (j is! Map) return;
      final map = Map<String, dynamic>.from(j);
      final days = map['days'];
      if (days is Map) {
        _chaptersByDay = days.map((k, v) =>
            MapEntry('$k', (v as num?)?.toInt() ?? 0));
      }
      final done = map['completed'];
      if (done is Map) {
        _completedAt =
            done.map((k, v) => MapEntry('$k', '$v'));
      }
      final fin = map['finished'];
      if (fin is Map) {
        _finishedSeries =
            fin.map((k, v) => MapEntry('$k', '$v'));
      }
      final fresh = map['new_series'];
      if (fresh is Map) {
        _newSeriesByMonth = fresh.map((k, v) =>
            MapEntry('$k', (v as num?)?.toInt() ?? 0));
      }
      final genres = map['genres'];
      if (genres is Map) {
        _genresByMonth = genres.map((k, v) {
          final list = (v as List?) ?? const [];
          return MapEntry('$k', list.map((e) => '$e').toSet());
        });
      }
      _nightChapters = (map['night'] as num?)?.toInt() ?? 0;
      _lastReadDay = map['last_day'] as String?;
      _comebackChapters = (map['comeback'] as num?)?.toInt() ?? 0;
      _wasAway = map['was_away'] == true;
    } catch (_) {
      // بيانات تالفة: نبدأ من جديد دون تعطيل التطبيق.
    }
  }

  Future<bool> _persist() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    final raw = jsonEncode({
      'days': _chaptersByDay,
      'completed': _completedAt,
      'finished': _finishedSeries,
      'new_series': _newSeriesByMonth,
      'genres': _genresByMonth
          .map((k, v) => MapEntry(k, v.toList())),
      'night': _nightChapters,
      'last_day': _lastReadDay,
      'comeback': _comebackChapters,
      'was_away': _wasAway,
    });
    return prefs.setString(kChallengePrefsKey, raw);
  }

  void _saveAndNotify() {
    unawaited(_persist());
    notifyListeners();
  }

  /// لقطة العدّادات الحالية (للحساب والعرض).
  ChallengeSnapshot snapshot({DateTime? now}) {
    final current = now ?? DateTime.now();
    DateTime? last;
    if (_lastReadDay != null) {
      last = DateTime.tryParse(_lastReadDay!);
    }
    return ChallengeSnapshot(
      chaptersByDay: Map<String, int>.from(_chaptersByDay),
      finishedSeries: _finishedSeries.length,
      newSeriesByMonth: Map<String, int>.from(_newSeriesByMonth),
      genresByMonth: Map<String, Set<String>>.from(_genresByMonth),
      nightChapters: _nightChapters,
      lastReadDay: last,
      comebackChapters: _comebackChapters,
      now: current,
    );
  }

  /// يسجّل فصلاً مقروءاً — يُنادى من القارئ بعد كل فصل.
  ///
  /// [at] وقت القراءة (الافتراضي الآن). [genres] تصنيفات العمل
  /// (لتحدي التصنيفات). [seriesId] معرّف العمل؛ إن كان جديداً
  /// كلياً يُحتسب في تحدي «مستكشف جديد». [finishedSeries] true
  /// عند إكمال العمل كاملاً. [isNewSeries] true عند بدء عمل جديد.
  void recordChapter({
    DateTime? at,
    List<String>? genres,
    String? seriesId,
    bool finishedSeries = false,
    bool isNewSeries = false,
  }) {
    final time = at ?? DateTime.now();
    final key = dayKey(time);
    _chaptersByDay[key] = (_chaptersByDay[key] ?? 0) + 1;

    // كشف الغياب: إن كان آخر يوم قراءة قبل 7 أيام فأكثر،
    // فهذه عودة، وتبدأ عدّادات العودة من جديد.
    final today = DateTime(time.year, time.month, time.day);
    if (_lastReadDay != null) {
      final last = DateTime.tryParse(_lastReadDay!);
      if (last != null) {
        final gap = today.difference(
          DateTime(last.year, last.month, last.day),
        ).inDays;
        if (gap >= 7) {
          _wasAway = true;
          _comebackChapters = 0;
        }
      }
    }
    if (_wasAway) {
      _comebackChapters++;
      if (_comebackChapters >= 3) _wasAway = false;
    }
    _lastReadDay = key;

    // فصول ما بعد منتصف الليل.
    if (time.hour < 5) _nightChapters++;

    // تصنيفات الشهر.
    final monthKey =
        '${time.year.toString().padLeft(4, '0')}-${time.month.toString().padLeft(2, '0')}';
    if (genres != null && genres.isNotEmpty) {
      final set = _genresByMonth.putIfAbsent(monthKey, () => <String>{});
      for (final g in genres) {
        final n = normalizeGenre(g);
        if (n.isNotEmpty) set.add(n);
      }
    }

    // عمل جديد هذا الشهر.
    if (isNewSeries) {
      _newSeriesByMonth[monthKey] =
          (_newSeriesByMonth[monthKey] ?? 0) + 1;
    }

    // إكمال عمل.
    if (finishedSeries && seriesId != null && seriesId.isNotEmpty) {
      _finishedSeries[seriesId] = time.toIso8601String();
    }

    _checkCompletions(time);
    _saveAndNotify();
  }

  /// يسجّل إكمال عمل مباشرة (دون فصل جديد).
  void recordSeriesFinished(String seriesId, {DateTime? at}) {
    if (seriesId.isEmpty) return;
    final time = at ?? DateTime.now();
    _finishedSeries[seriesId] = time.toIso8601String();
    _checkCompletions(time);
    _saveAndNotify();
  }

  /// يفحص التحديات المكتملة حديثاً ويحفظ وقت إكمالها.
  void _checkCompletions(DateTime now) {
    final snap = snapshot(now: now);
    for (final c in kReadingChallenges) {
      if (_completedAt.containsKey(c.id)) continue;
      final current = ChallengeEvaluator.currentOf(c, snap);
      if (current >= c.target) {
        _completedAt[c.id] = now.toIso8601String();
        _pendingCelebration ??= c.id;
      }
    }
  }

  /// تقدّم كل التحديات (مرتبة: غير المكتملة أولاً ثم المكتملة).
  List<ChallengeProgress> get allProgress {
    final snap = snapshot();
    final list = kReadingChallenges.map((c) {
      final done = _completedAt[c.id];
      return ChallengeEvaluator.evaluate(
        c,
        snap,
        done == null ? null : DateTime.tryParse(done),
      );
    }).toList();
    list.sort((a, b) {
      if (a.completed != b.completed) {
        return a.completed ? 1 : -1;
      }
      return b.fraction.compareTo(a.fraction);
    });
    return list;
  }

  /// تقدّم تحدٍّ واحد.
  ChallengeProgress progressFor(String challengeId, {DateTime? now}) {
    final c = kReadingChallenges.firstWhere(
      (e) => e.id == challengeId,
      orElse: () => kReadingChallenges.first,
    );
    final done = _completedAt[c.id];
    return ChallengeEvaluator.evaluate(
      c,
      snapshot(now: now),
      done == null ? null : DateTime.tryParse(done),
    );
  }

  /// عدد التحديات المكتملة.
  int get completedCount => _completedAt.length;

  /// هل اكتمل تحدٍّ معيّن؟
  bool isCompleted(String challengeId) =>
      _completedAt.containsKey(challengeId);

  /// أقرب تحدٍّ للإكمال (للعرض في الرئيسية).
  ChallengeProgress? get closestToCompletion {
    final list = allProgress.where((p) => !p.completed).toList();
    if (list.isEmpty) return null;
    list.sort((a, b) => b.fraction.compareTo(a.fraction));
    return list.first;
  }

  /// يستهلك إشعار الاحتفال بعد عرضه.
  void consumeCelebration() {
    _pendingCelebration = null;
    notifyListeners();
  }

  /// يعيد ضبط كل العدّادات (للاختبارات وإعادة البدء).
  void reset() {
    _chaptersByDay = {};
    _completedAt = {};
    _finishedSeries = {};
    _newSeriesByMonth = {};
    _genresByMonth = {};
    _nightChapters = 0;
    _lastReadDay = null;
    _comebackChapters = 0;
    _wasAway = false;
    _pendingCelebration = null;
    _saveAndNotify();
  }

  /// نص مشاركة إنجاز تحدٍّ مكتمل.
  String shareText(ChallengeProgress p) {
    return 'أكملت تحدي «${p.challenge.title}» في Senok '
        '(${p.challenge.targetLabel}) وحصلت على ${p.challenge.reward}!';
  }
}

/// ──────────────────────────────────────────────────────────────────────────
/// شاشة التحديات — تعرض التحديات الاثني عشر مع أشرطة التقدم،
/// وتحتفل بأحدث تحدٍّ مكتمل.
/// ──────────────────────────────────────────────────────────────────────────

/// شاشة تحديات القراءة.
class ReadingChallengesScreen extends StatefulWidget {
  const ReadingChallengesScreen({super.key});

  @override
  State<ReadingChallengesScreen> createState() =>
      _ReadingChallengesScreenState();
}

class _ReadingChallengesScreenState extends State<ReadingChallengesScreen> {
  @override
  void initState() {
    super.initState();
    ChallengeStore.i.load();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('تحديات القراءة', style: context.ds(size: 20)),
      ),
      body: AnimatedBuilder(
        animation: ChallengeStore.i,
        builder: (context, _) {
          final store = ChallengeStore.i;
          final progress = store.allProgress;
          final done = progress.where((e) => e.completed).length;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
            children: [
              _ChallengesSummaryCard(
                completed: done,
                total: kReadingChallenges.length,
              ),
              const SizedBox(height: 16),
              ...progress.map((item) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _ChallengeTile(progress: item),
                  )),
              const SizedBox(height: 8),
              _ChallengesNote(),
            ],
          );
        },
      ),
    );
  }
}

/// بطاقة ملخص: كم تحدياً اكتمل من 12.
class _ChallengesSummaryCard extends StatelessWidget {
  const _ChallengesSummaryCard({required this.completed, required this.total});
  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final fraction = total <= 0 ? 0.0 : completed / total;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.0)),
        border: Border.all(color: p.border),
        boxShadow: softShadow(p),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 64,
            height: 64,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 64,
                  height: 64,
                  child: CircularProgressIndicator(
                    value: fraction,
                    strokeWidth: 6,
                    backgroundColor: p.surfaceHi,
                    valueColor:
                        AlwaysStoppedAnimation<Color>(p.accent),
                  ),
                ),
                Text(
                  '$completed/$total',
                  style: context.ts(size: 13, w: FontWeight.w800),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  completed == total
                      ? 'أكملت كل التحديات!'
                      : 'تحدياتك هذا الموسم',
                  style: context.ds(size: 16),
                ),
                const SizedBox(height: 4),
                Text(
                  completed == total
                      ? 'أنت قارئ استثنائي — ستتجدد التحديات مع الوقت.'
                      : 'أكملت $completed من $total تحديات. '
                          'اقرأ فصولاً جديدة لتتقدّم.',
                  style: context.ts(size: 12.5, color: p.textDim, height: 1.6),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// بطاقة تحدٍّ واحد: أيقونة + عنوان + وصف + شريط تقدم + مكافأة.
class _ChallengeTile extends StatelessWidget {
  const _ChallengeTile({required this.progress});
  final ChallengeProgress progress;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = progress.challenge;
    final done = progress.completed;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: done ? tint(p.gold, 0.08) : p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(
          color: done ? tint(p.gold, 0.5) : p.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: done
                      ? tint(p.gold, 0.18)
                      : tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                ),
                child: SIcon(
                  c.icon,
                  size: 20,
                  color: done ? p.gold : p.accent,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(c.title,
                        style: context.ds(size: 15, w: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(c.description,
                        style: context.ts(
                            size: 12.5, color: p.textDim, height: 1.5)),
                  ],
                ),
              ),
              if (done)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: tint(p.gold, 0.16),
                    borderRadius: BorderRadius.circular(p.r(1.4)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SIcon(SardIcons.check_rounded,
                          size: 14, color: p.gold),
                      const SizedBox(width: 4),
                      Text('مكتمل',
                          style: context.ts(
                              size: 11.5,
                              w: FontWeight.w800,
                              color: p.gold)),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progress.fraction,
              minHeight: 8,
              backgroundColor: p.surfaceHi,
              valueColor: AlwaysStoppedAnimation<Color>(
                  done ? p.gold : p.accent),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(
                progress.progressLabel,
                style: context.ts(size: 12.5, w: FontWeight.w700),
              ),
              const Spacer(),
              Text(
                done
                    ? c.reward
                    : progress.remaining > 0
                        ? 'بقي ${progress.remaining} ${c.unit}'
                        : c.reward,
                style: context.ts(
                    size: 12,
                    color: done ? p.gold : p.textDim),
              ),
            ],
          ),
          if (done && progress.completedAt != null) ...[
            const SizedBox(height: 4),
            Text(
              'أُكمل في ${formatSardDay(progress.completedAt!)}',
              style: context.ts(size: 11.5, color: p.textDim),
            ),
          ],
        ],
      ),
    );
  }
}

/// ملاحظة أسفل الشاشة عن طريقة الحساب.
class _ChallengesNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tint(p.accent, 0.06),
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SIcon(SardIcons.info_outline_rounded,
              size: 18, color: p.accent),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'تُحسب التحديات من قراءتك الفعلية داخل التطبيق. '
              'التحديات الأسبوعية والشهرية تُصفَّر مع بداية كل فترة، '
              'أما المكتملة فتبقى في سجلك.',
              style: context.ts(size: 12.5, color: p.text, height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}
