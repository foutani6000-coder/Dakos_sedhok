import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/discovery/reading_history.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/states.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// إحصاءات القراءة — ReadingStats
/// تُحسب من SettingsController (الفصول والثواني والأيام) ومن
/// ReadingHistoryStore (التوزيعات الشهرية وأكثر الأعمال قراءة).
///
/// تنبيه صريح في الواجهة: الدقائق اليومية والأسبوعية تقديرات
/// (مبنية على ثوانٍ مسجلة داخل القارئ فقط، وليست قياساً دقيقاً).
/// ──────────────────────────────────────────────────────────────────────────

/// إحصاءات قراءة جاهزة للعرض.
@immutable
class ReadingStatsData {
  const ReadingStatsData({
    required this.totalChapters,
    required this.totalMinutes,
    required this.totalSeconds,
    required this.daysActive,
    required this.streak,
    required this.bestStreak,
    required this.bestDayChapters,
    required this.topGenre,
    required this.topSeriesTitle,
    required this.topSeriesChapters,
    required this.monthlyChapters,
    required this.weekdayChapters,
    required this.chaptersThisWeek,
    required this.chaptersThisMonth,
    required this.minutesThisWeekEstimate,
    required this.minutesTodayEstimate,
    required this.averageMinutesPerDay,
    required this.year,
  });

  /// إجمالي الفصول المقروءة.
  final int totalChapters;

  /// إجمالي الدقائق (من الثواني المسجلة).
  final int totalMinutes;

  /// إجمالي الثواني المسجلة.
  final int totalSeconds;

  /// عدد أيام القراءة المختلفة.
  final int daysActive;

  /// السلسلة الحالية (أيام متتالية).
  final int streak;

  /// أفضل سلسلة على الإطلاق.
  final int bestStreak;

  /// أفضل يوم (أكثر فصول في يوم واحد).
  final int bestDayChapters;

  /// أكثر تصنيف قراءةً.
  final String? topGenre;

  /// أكثر عمل قراءةً (العنوان).
  final String topSeriesTitle;

  /// فصول أكثر عمل قراءةً.
  final int topSeriesChapters;

  /// فصول كل شهر في السنة (1..12).
  final Map<int, int> monthlyChapters;

  /// فصول كل يوم أسبوع (0 = الاثنين .. 6 = الأحد).
  final Map<int, int> weekdayChapters;

  /// فصول هذا الأسبوع.
  final int chaptersThisWeek;

  /// فصول هذا الشهر.
  final int chaptersThisMonth;

  /// دقائق هذا الأسبوع التقديرية.
  final int minutesThisWeekEstimate;

  /// دقائق اليوم التقديرية.
  final int minutesTodayEstimate;

  /// متوسط الدقائق في اليوم النشط (تقدير).
  final double averageMinutesPerDay;

  /// سنة الإحصاءات الشهرية.
  final int year;

  /// هل يوجد أي نشاط؟
  bool get hasActivity => totalChapters > 0;

  /// متوسط الفصول في اليوم النشط.
  double get chaptersPerActiveDay => PaceEstimator.chaptersPerActiveDay(
        totalChapters: totalChapters,
        activeDays: daysActive,
      );

  /// أكثر شهر قراءةً (1..12)، أو 0 إن لم يوجد.
  int get bestMonth {
    var best = 0;
    var value = 0;
    for (final e in monthlyChapters.entries) {
      if (e.value > value) {
        best = e.key;
        value = e.value;
      }
    }
    return best;
  }

  /// اسم أكثر شهر قراءةً، أو «—».
  String get bestMonthName {
    if (bestMonth == 0) return '—';
    return kArabicMonths[bestMonth - 1];
  }

  /// أكثر يوم أسبوع قراءةً (0..6)، أو -1.
  int get bestWeekday {
    var best = -1;
    var value = 0;
    for (final e in weekdayChapters.entries) {
      if (e.value > value) {
        best = e.key;
        value = e.value;
      }
    }
    return best;
  }

  /// نص مشاركة الإحصاءات.
  String toShareText() {
    return 'إحصاءات قراءتي على Senok:\n'
        '• $totalChapters فصلاً مقروءاً\n'
        '• ${formatReadingTime(totalSeconds)} من القراءة\n'
        '• $daysActive يوم قراءة، وسلسلة $streak يوماً\n'
        '${topGenre == null ? '' : '• أكثر تصنيف: $topGenre\n'}'
        '• أفضل شهر: $bestMonthName';
  }

  static const ReadingStatsData empty = ReadingStatsData(
    totalChapters: 0,
    totalMinutes: 0,
    totalSeconds: 0,
    daysActive: 0,
    streak: 0,
    bestStreak: 0,
    bestDayChapters: 0,
    topGenre: null,
    topSeriesTitle: '',
    topSeriesChapters: 0,
    monthlyChapters: {},
    weekdayChapters: {},
    chaptersThisWeek: 0,
    chaptersThisMonth: 0,
    minutesThisWeekEstimate: 0,
    minutesTodayEstimate: 0,
    averageMinutesPerDay: 0,
    year: 2026,
  );
}

/// أسماء الأشهر العربية.
const List<String> kArabicMonths = <String>[
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

/// أسماء أيام الأسبوع (الاثنين أولاً).
const List<String> kArabicWeekdays = <String>[
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
  'الأحد',
];

/// حاسبة إحصاءات خالصة (قابلة للاختبار دون واجهات).
class ReadingStatsCalculator {
  ReadingStatsCalculator._();

  /// يبني الإحصاءات من المتحكم في الإعدادات وسجل القراءة.
  static ReadingStatsData build({
    required SettingsController settings,
    required ReadingHistoryStore history,
    DateTime? now,
  }) {
    final current = now ?? DateTime.now();
    final year = current.year;
    final summaryWeek = history.summaryLastDays(7, now: current);
    final summaryMonth = history.summaryLastDays(30, now: current);

    // أفضل يوم: أكثر فصول في يوم واحد من السجل.
    final perDay = <String, int>{};
    for (final e in history.entries) {
      perDay[e.day] = (perDay[e.day] ?? 0) + 1;
    }
    var bestDay = 0;
    for (final v in perDay.values) {
      if (v > bestDay) bestDay = v;
    }

    // أكثر عمل قراءةً (من السجل، مع عنوانه).
    final most = history.mostReadSeries;
    var topTitle = '';
    var topCount = 0;
    if (most != null) {
      topCount = most.value;
      final first = history.entries
          .firstWhere((e) => e.seriesId == most.key);
      topTitle = first.seriesTitle;
    }

    final minutesWeek = summaryWeek.seconds > 0
        ? (summaryWeek.seconds / 60).round()
        : summaryWeek.chapters * 5;
    final minutesToday = history
            .entriesBetween(
              DateTime(current.year, current.month, current.day),
              current,
            )
            .fold<int>(0, (a, e) => a + e.seconds) ~/
        60;

    return ReadingStatsData(
      totalChapters: settings.totalChaptersRead,
      totalMinutes: settings.totalReadingSeconds ~/ 60,
      totalSeconds: settings.totalReadingSeconds,
      daysActive: history.activeDays > 0
          ? history.activeDays
          : settings.readDaysInYear(year),
      streak: settings.streak,
      bestStreak: settings.bestStreak,
      bestDayChapters: bestDay,
      topGenre: settings.topGenre,
      topSeriesTitle: topTitle,
      topSeriesChapters: topCount,
      monthlyChapters: history.chaptersByMonth(year),
      weekdayChapters: history.chaptersByWeekday(),
      chaptersThisWeek: summaryWeek.chapters,
      chaptersThisMonth: summaryMonth.chapters,
      minutesThisWeekEstimate: minutesWeek,
      minutesTodayEstimate: minutesToday,
      averageMinutesPerDay: settings.totalChaptersRead > 0 &&
              history.activeDays > 0
          ? (settings.totalReadingSeconds / 60) / history.activeDays
          : 0,
      year: year,
    );
  }

  /// يبني إحصاءات من أرقام خام (للاختبارات).
  static ReadingStatsData fromRaw({
    int totalChapters = 0,
    int totalSeconds = 0,
    int daysActive = 0,
    int streak = 0,
    int bestStreak = 0,
    int bestDayChapters = 0,
    String? topGenre,
    String topSeriesTitle = '',
    int topSeriesChapters = 0,
    Map<int, int> monthlyChapters = const {},
    Map<int, int> weekdayChapters = const {},
    int chaptersThisWeek = 0,
    int chaptersThisMonth = 0,
    int year = 2026,
  }) {
    final minutesWeek = chaptersThisWeek * 5;
    return ReadingStatsData(
      totalChapters: totalChapters,
      totalMinutes: totalSeconds ~/ 60,
      totalSeconds: totalSeconds,
      daysActive: daysActive,
      streak: streak,
      bestStreak: bestStreak,
      bestDayChapters: bestDayChapters,
      topGenre: topGenre,
      topSeriesTitle: topSeriesTitle,
      topSeriesChapters: topSeriesChapters,
      monthlyChapters: monthlyChapters,
      weekdayChapters: weekdayChapters,
      chaptersThisWeek: chaptersThisWeek,
      chaptersThisMonth: chaptersThisMonth,
      minutesThisWeekEstimate: minutesWeek,
      minutesTodayEstimate: 0,
      averageMinutesPerDay:
          daysActive > 0 ? (totalSeconds / 60) / daysActive : 0,
      year: year,
    );
  }
}

/// شاشة إحصاءات القراءة: بطاقات رقمية + رسم شهري + توزيع أسبوعي.
class ReadingStatsScreen extends StatelessWidget {
  const ReadingStatsScreen({
    super.key,
    required this.settings,
    required this.history,
  });

  final SettingsController settings;
  final ReadingHistoryStore history;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final data = ReadingStatsCalculator.build(
      settings: settings,
      history: history,
    );
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('إحصاءات قراءتي', style: context.ds(size: 20)),
        actions: [
          IconButton(
            onPressed: () {
              // مشاركة نصية بسيطة عبر حافظة النظام.
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('أُعدّ نص المشاركة — انسخه من الأسفل')),
              );
            },
            icon: SIcon(SardIcons.share_rounded, color: p.text),
            tooltip: 'مشاركة الإحصاءات',
          ),
        ],
      ),
      body: data.hasActivity
          ? _StatsBody(data: data)
          : const EmptyState(
              title: 'لا إحصاءات بعد',
              subtitle: 'اقرأ بعض الفصول وستظهر إحصاءاتك هنا.',
            ),
    );
  }
}

class _StatsBody extends StatelessWidget {
  const _StatsBody({required this.data});
  final ReadingStatsData data;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        _StatGrid(data: data),
        const SizedBox(height: 18),
        _SectionTitle(
          title: 'فصول ${data.year} حسب الشهر',
          subtitle: 'عدد الفصول المقروءة في كل شهر.',
        ),
        _MonthlyBarChart(monthly: data.monthlyChapters),
        const SizedBox(height: 18),
        _SectionTitle(
          title: 'أيام الأسبوع',
          subtitle: 'متى تقرأ أكثر؟ (الاثنين أولاً).',
        ),
        _WeekdayBars(weekday: data.weekdayChapters),
        const SizedBox(height: 18),
        _SectionTitle(
          title: 'نظرة عامة',
          subtitle: 'ملخص سريع لعادات قراءتك.',
        ),
        _OverviewCard(data: data),
        const SizedBox(height: 18),
        _EstimateNote(),
        const SizedBox(height: 14),
        _ShareTextCard(data: data),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: context.ds(size: 17)),
          const SizedBox(height: 2),
          Text(subtitle,
              style: context.ts(size: 12.5, color: p.textDim)),
        ],
      ),
    );
  }
}

/// شبكة بطاقات رقمية (فصول، وقت، أيام، سلسلة).
class _StatGrid extends StatelessWidget {
  const _StatGrid({required this.data});
  final ReadingStatsData data;

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.55,
      children: [
        _StatCard(
          icon: SardIcons.menu_book_rounded,
          label: 'فصول مقروءة',
          value: '${data.totalChapters}',
          sub: 'في كل الأعمال',
        ),
        _StatCard(
          icon: SardIcons.watch_later_rounded,
          label: 'وقت القراءة',
          value: formatReadingTime(data.totalSeconds),
          sub: 'من الثواني المسجلة',
        ),
        _StatCard(
          icon: SardIcons.calendar_today_rounded,
          label: 'أيام قراءة',
          value: '${data.daysActive}',
          sub: 'يوم مختلف هذا العام',
        ),
        _StatCard(
          icon: SardIcons.local_fire_department_rounded,
          label: 'السلسلة الحالية',
          value: '${data.streak} يوم',
          sub: 'الأفضل: ${data.bestStreak} يوم',
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.sub,
  });

  final SIconData icon;
  final String label;
  final String value;
  final String sub;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
        boxShadow: softShadow(p),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(icon, size: 18, color: p.accent),
              const SizedBox(width: 6),
              Expanded(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style:
                        context.ts(size: 12.5, color: p.textDim)),
              ),
            ],
          ),
          const Spacer(),
          Text(value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.ds(size: 22)),
          const SizedBox(height: 2),
          Text(sub,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.ts(size: 11.5, color: p.textDim)),
        ],
      ),
    );
  }
}

/// رسم أعمدة شهري (أعمدة ملوّنة مع قيمة كل شهر).
class _MonthlyBarChart extends StatelessWidget {
  const _MonthlyBarChart({required this.monthly});
  final Map<int, int> monthly;

  /// اسم أكثر شهر قراءةً («أفضل شهر: مارس (12 فصلاً)») أو «—».
  static String _bestMonthLabel(Map<int, int> m) {
    var best = 0;
    var value = 0;
    for (final e in m.entries) {
      if (e.value > value) {
        best = e.key;
        value = e.value;
      }
    }
    if (best == 0 || value == 0) return 'أفضل شهر: —';
    return 'أفضل شهر: ${kArabicMonths[best - 1]} ($value فصلاً)';
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final now = DateTime.now();
    final maxValue = monthly.values.fold<int>(
        0, (a, b) => math.max(a, b));
    final values = List<int>.generate(
        12, (i) => monthly[i + 1] ?? 0);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 150,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(12, (i) {
                final v = values[i];
                final h = maxValue <= 0
                    ? 0.0
                    : (v / maxValue).clamp(0.05, 1.0).toDouble();
                final isCurrent = i + 1 == now.month;
                return Expanded(
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 2),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (v > 0)
                          Text('$v',
                              style: context.ts(
                                  size: 10,
                                  w: FontWeight.w700,
                                  color: p.textDim)),
                        const SizedBox(height: 3),
                        Container(
                          height: 110 * h,
                          decoration: BoxDecoration(
                            color: isCurrent
                                ? p.accent
                                : tint(p.accent, 0.35),
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(p.r(0.4)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: List.generate(12, (i) {
              return Expanded(
                child: Center(
                  child: Text(
                    kArabicMonths[i].substring(0, 3),
                    style: context.ts(
                      size: 10,
                      color: i + 1 == now.month
                          ? p.accent
                          : p.textDim,
                      w: i + 1 == now.month
                          ? FontWeight.w700
                          : null,
                    ),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 6),
          Text(
            _bestMonthLabel(monthly),
            style: context.ts(size: 11, color: p.textDim),
          ),
        ],
      ),
    );
  }
}

/// أشرطة أيام الأسبوع (نسبة مئوية لكل يوم).
class _WeekdayBars extends StatelessWidget {
  const _WeekdayBars({required this.weekday});
  final Map<int, int> weekday;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final maxValue =
        weekday.values.fold<int>(0, (a, b) => math.max(a, b));
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: List.generate(7, (i) {
          final v = weekday[i] ?? 0;
          final f = maxValue <= 0
              ? 0.0
              : (v / maxValue).clamp(0.0, 1.0).toDouble();
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                SizedBox(
                  width: 64,
                  child: Text(kArabicWeekdays[i],
                      style: context.ts(size: 12.5)),
                ),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: f,
                      minHeight: 10,
                      backgroundColor: p.surfaceHi,
                      valueColor:
                          AlwaysStoppedAnimation<Color>(p.accent),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 28,
                  child: Text('$v',
                      textAlign: TextAlign.left,
                      style: context.ts(
                          size: 12, w: FontWeight.w700)),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

/// بطاقة نظرة عامة (أكثر تصنيف، أكثر عمل، متوسط يومي).
class _OverviewCard extends StatelessWidget {
  const _OverviewCard({required this.data});
  final ReadingStatsData data;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          _OverviewRow(
            icon: SardIcons.category_rounded,
            label: 'أكثر تصنيف تقرؤه',
            value: data.topGenre ?? '—',
          ),
          const Divider(height: 20),
          _OverviewRow(
            icon: SardIcons.star_rounded,
            label: 'أكثر عمل قرأته',
            value: data.topSeriesTitle.isEmpty
                ? '—'
                : '${data.topSeriesTitle} (${data.topSeriesChapters} فصلاً)',
          ),
          const Divider(height: 20),
          _OverviewRow(
            icon: SardIcons.bolt_rounded,
            label: 'أفضل يوم لك',
            value: data.bestDayChapters <= 0
                ? '—'
                : '${data.bestDayChapters} فصول في يوم واحد',
          ),
          const Divider(height: 20),
          _OverviewRow(
            icon: SardIcons.watch_later_rounded,
            label: 'متوسطك اليومي (تقدير)',
            value:
                '${data.averageMinutesPerDay.toStringAsFixed(0)} دقيقة في اليوم النشط',
          ),
          const Divider(height: 20),
          _OverviewRow(
            icon: SardIcons.calendar_today_rounded,
            label: 'هذا الأسبوع',
            value:
                '${data.chaptersThisWeek} فصلاً · نحو ${data.minutesThisWeekEstimate} دقيقة (تقدير)',
          ),
          const Divider(height: 20),
          _OverviewRow(
            icon: SardIcons.calendar_today_rounded,
            label: 'هذا الشهر',
            value: '${data.chaptersThisMonth} فصلاً',
          ),
        ],
      ),
    );
  }
}

class _OverviewRow extends StatelessWidget {
  const _OverviewRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  final SIconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      children: [
        SIcon(icon, size: 18, color: p.accent),
        const SizedBox(width: 10),
        Expanded(
          child: Text(label, style: context.ts(size: 13.5)),
        ),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.left,
            style: context.ts(size: 13.5, w: FontWeight.w700),
          ),
        ),
      ],
    );
  }
}

/// ملاحظة صريحة بأن الدقائق تقديرات.
class _EstimateNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tint(p.gold, 0.1),
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: tint(p.gold, 0.35)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SIcon(SardIcons.info_outline_rounded,
              size: 18, color: p.gold),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'ملاحظة: الدقائق اليومية والأسبوعية تقديرات تقريبية، '
              'مبنية على الثواني المسجلة داخل القارئ وعلى تقدير '
              '5 دقائق للفصل الواحد، وليست قياساً دقيقاً لوقتك.',
              style: context.ts(size: 12.5, color: p.text, height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}

/// بطاقة نص المشاركة (جاهزة للنسخ).
class _ShareTextCard extends StatelessWidget {
  const _ShareTextCard({required this.data});
  final ReadingStatsData data;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('نص المشاركة',
              style: context.ds(size: 15, w: FontWeight.w700)),
          const SizedBox(height: 8),
          SelectableText(
            data.toShareText(),
            style: context.ts(size: 13, height: 1.8),
          ),
        ],
      ),
    );
  }
}
