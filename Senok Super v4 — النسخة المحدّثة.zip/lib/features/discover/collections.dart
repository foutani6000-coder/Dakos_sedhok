import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/states.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// مجموعات القراءة — Collections
/// قوائم ينشئها المستخدم (مثلاً «أفضل ما قرأت»، «للشتاء»)،
/// تُرتَّب بالسحب، وتُشارَك برابط مخططه senok://collection/
/// (ترميز base64url لملف JSON صغير). تُحفظ محلياً.
/// ──────────────────────────────────────────────────────────────────────────

/// مفتاح التخزين المحلي للمجموعات.
const String kCollectionsPrefsKey = 'disc_collections_v1';

/// مخطط روابط المشاركة (Senok).
const String kCollectionLinkScheme = 'senok://collection/';

/// مجموعة قراءة واحدة (غير قابلة للتعديل: كل تغيير ينتج نسخة جديدة).
@immutable
class ReadingCollection {
  const ReadingCollection({
    required this.id,
    required this.name,
    this.description = '',
    this.isPublic = true,
    this.seriesIds = const [],
    required this.createdAt,
    required this.updatedAt,
  });

  /// معرّف فريد محلي.
  final String id;

  /// اسم المجموعة.
  final String name;

  /// وصف اختياري.
  final String description;

  /// عامة (قابلة للمشاركة برابط) أم خاصة.
  final bool isPublic;

  /// معرّفات الأعمال بالترتيب.
  final List<String> seriesIds;

  final DateTime createdAt;
  final DateTime updatedAt;

  /// عدد الأعمال فيها.
  int get count => seriesIds.length;

  /// هل المجموعة فارغة؟
  bool get isEmpty => seriesIds.isEmpty;

  /// هل تحتوي عملاً معيناً؟
  bool contains(String seriesId) => seriesIds.contains(seriesId);

  /// نسخة باسم ووصف جديدين.
  ReadingCollection copyWith({
    String? name,
    String? description,
    bool? isPublic,
    List<String>? seriesIds,
    DateTime? updatedAt,
  }) {
    return ReadingCollection(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      isPublic: isPublic ?? this.isPublic,
      seriesIds: seriesIds ?? this.seriesIds,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }

  /// نسخة بإضافة عمل (بلا تكرار).
  ReadingCollection withAdded(String seriesId) {
    if (seriesIds.contains(seriesId)) return this;
    return copyWith(seriesIds: [...seriesIds, seriesId]);
  }

  /// نسخة بإزالة عمل.
  ReadingCollection withRemoved(String seriesId) {
    if (!seriesIds.contains(seriesId)) return this;
    return copyWith(
        seriesIds: seriesIds.where((e) => e != seriesId).toList());
  }

  /// نسخة بنقل عمل من موضع إلى آخر (للسحب وإعادة الترتيب).
  ReadingCollection withMoved(int from, int to) {
    if (from < 0 ||
        from >= seriesIds.length ||
        to < 0 ||
        to >= seriesIds.length) {
      return this;
    }
    final list = List<String>.from(seriesIds);
    final item = list.removeAt(from);
    list.insert(to, item);
    return copyWith(seriesIds: list);
  }

  /// نسخة بنقل عمل إلى البداية.
  ReadingCollection withMovedToTop(String seriesId) {
    if (!seriesIds.contains(seriesId)) return this;
    final list = List<String>.from(seriesIds)..remove(seriesId);
    list.insert(0, seriesId);
    return copyWith(seriesIds: list);
  }

  /// يحوّل المجموعة إلى رابط مشاركة.
  String toShareLink() => CollectionLinkCodec.encode(this);

  /// نص مشاركة جاهز (عنوان + رابط).
  String shareText() => CollectionLinkCodec.shareText(this);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'is_public': isPublic,
        'series_ids': seriesIds,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory ReadingCollection.fromJson(Map<String, dynamic> j) {
    return ReadingCollection(
      id: '${j['id'] ?? ''}',
      name: '${j['name'] ?? 'مجموعة'}',
      description: '${j['description'] ?? ''}',
      isPublic: j['is_public'] != false,
      seriesIds: ((j['series_ids'] as List?) ?? const [])
          .map((e) => '$e')
          .where((e) => e.isNotEmpty)
          .toList(),
      createdAt: DateTime.tryParse('${j['created_at'] ?? ''}') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse('${j['updated_at'] ?? ''}') ??
          DateTime.now(),
    );
  }

  /// معرّف جديد فريد.
  static String newId() =>
      'col_${DateTime.now().millisecondsSinceEpoch}';

  @override
  bool operator ==(Object other) =>
      other is ReadingCollection && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

/// ترميز وفك ترميز روابط مشاركة المجموعات.
///
/// الصيغة: senok://collection/<base64url(JSON)>
/// حيث JSON = {name, description, series_ids}.
/// الروابط القصيرة لا تحمل سوى الأسماء والمعرّفات، لا الصور.
class CollectionLinkCodec {
  CollectionLinkCodec._();

  /// مخطط الرابط.
  static const String scheme = kCollectionLinkScheme;

  /// يرمّز مجموعة إلى رابط مشاركة.
  static String encode(ReadingCollection c) {
    final payload = {
      'v': 1,
      'name': c.name,
      'description': c.description,
      'series_ids': c.seriesIds,
    };
    final raw = jsonEncode(payload);
    final encoded = base64Url.encode(utf8.encode(raw));
    return '$scheme$encoded';
  }

  /// يفكّ رابط مشاركة إلى مجموعة (معرّف جديد)، أو null إن كان غير صالح.
  static ReadingCollection? decode(String link) {
    final text = link.trim();
    if (!text.startsWith(scheme)) return null;
    final encoded = text.substring(scheme.length).trim();
    if (encoded.isEmpty) return null;
    try {
      final raw = utf8.decode(base64Url.decode(encoded));
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return null;
      final map = Map<String, dynamic>.from(decoded);
      final now = DateTime.now();
      final seriesIds = ((map['series_ids'] as List?) ?? const [])
          .map((e) => '$e')
          .where((e) => e.isNotEmpty)
          .toList();
      if (seriesIds.isEmpty && (map['name'] as String?)?.isEmpty != false) {
        return null;
      }
      return ReadingCollection(
        id: ReadingCollection.newId(),
        name: '${map['name'] ?? 'مجموعة مشارَكة'}',
        description: '${map['description'] ?? ''}',
        isPublic: true,
        seriesIds: seriesIds,
        createdAt: now,
        updatedAt: now,
      );
    } catch (_) {
      return null;
    }
  }

  /// هل النص رابط مجموعة صالح الشكل؟
  static bool looksLikeLink(String text) =>
      text.trim().startsWith(scheme);

  /// نص مشاركة جاهز للنسخ أو الإرسال.
  static String shareText(ReadingCollection c) {
    final count = c.seriesIds.length;
    final countLabel = count == 0
        ? 'مجموعة فارغة'
        : count == 1
            ? 'عمل واحد'
            : count == 2
                ? 'عملان'
                : '$count أعمال';
    return 'مجموعة «${c.name}» على Senok ($countLabel):\n${encode(c)}';
  }

  /// نص تلميح لحقل لصق الرابط.
  static const String pasteHint =
      'الصق رابط senok://collection/... هنا';
}

/// مخزن المجموعات (نسخة واحدة [CollectionsStore.i]).
class CollectionsStore extends ChangeNotifier {
  CollectionsStore._(this._prefs) {
    _readFromPrefs();
  }

  CollectionsStore._deferred() : _prefs = null;

  /// النسخة الوحيدة في التطبيق.
  static final CollectionsStore i = CollectionsStore._deferred();

  /// نسخة للاختبارات مبنية على تفضيلات جاهزة (متزامنة).
  factory CollectionsStore.testInstance(SharedPreferences prefs) =>
      CollectionsStore._(prefs);

  /// نسخة جديدة محمّلة من التخزين.
  static Future<CollectionsStore> loadNew() async =>
      CollectionsStore._(await SharedPreferences.getInstance());

  SharedPreferences? _prefs;
  List<ReadingCollection> _collections = const [];

  /// كل المجموعات (الأحدث تعديلاً أولاً).
  List<ReadingCollection> get collections =>
      List.unmodifiable(_collections);

  /// عدد المجموعات.
  int get count => _collections.length;

  /// إجمالي الأعمال في كل المجموعات (مع التكرار).
  int get totalSeries =>
      _collections.fold<int>(0, (a, c) => a + c.count);

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _readFromPrefs();
    notifyListeners();
  }

  void _readFromPrefs() {
    final raw = _prefs?.getString(kCollectionsPrefsKey);
    if (raw == null || raw.isEmpty) {
      _collections = const [];
      return;
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        final list = decoded
            .whereType<Map>()
            .map((e) => ReadingCollection.fromJson(
                Map<String, dynamic>.from(e)))
            .where((c) => c.id.isNotEmpty)
            .toList();
        list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        _collections = list;
      }
    } catch (_) {
      _collections = const [];
    }
  }

  Future<bool> _persist() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    final raw = jsonEncode(_collections.map((c) => c.toJson()).toList());
    return prefs.setString(kCollectionsPrefsKey, raw);
  }

  void _saveAndNotify() {
    unawaited(_persist());
    notifyListeners();
  }

  /// مجموعة بمعرّفها، أو null.
  ReadingCollection? byId(String id) {
    for (final c in _collections) {
      if (c.id == id) return c;
    }
    return null;
  }

  /// المجموعات التي تحتوي عملاً معيناً.
  List<ReadingCollection> containing(String seriesId) =>
      _collections.where((c) => c.contains(seriesId)).toList();

  /// ينشئ مجموعة جديدة ويعيدها.
  ReadingCollection create({
    required String name,
    String description = '',
    bool isPublic = true,
  }) {
    final now = DateTime.now();
    final c = ReadingCollection(
      id: ReadingCollection.newId(),
      name: name.trim().isEmpty ? 'مجموعة جديدة' : name.trim(),
      description: description.trim(),
      isPublic: isPublic,
      createdAt: now,
      updatedAt: now,
    );
    _collections = [c, ..._collections];
    _saveAndNotify();
    return c;
  }

  /// يعيد تسمية مجموعة / يعدّل وصفها.
  bool update(
    String id, {
    String? name,
    String? description,
    bool? isPublic,
  }) {
    final i = _collections.indexWhere((c) => c.id == id);
    if (i < 0) return false;
    final next = _collections[i].copyWith(
      name: name,
      description: description,
      isPublic: isPublic,
    );
    _collections = List<ReadingCollection>.from(_collections)
      ..[i] = next;
    _saveAndNotify();
    return true;
  }

  /// يحذف مجموعة.
  bool remove(String id) {
    final before = _collections.length;
    _collections = _collections.where((c) => c.id != id).toList();
    if (_collections.length == before) return false;
    _saveAndNotify();
    return true;
  }

  /// يضيف عملاً إلى مجموعة (بلا تكرار). يعيد false إن كان موجوداً.
  bool addTo(String collectionId, String seriesId) {
    final i = _collections.indexWhere((c) => c.id == collectionId);
    if (i < 0) return false;
    final c = _collections[i];
    if (c.contains(seriesId)) return false;
    _collections = List<ReadingCollection>.from(_collections)
      ..[i] = c.withAdded(seriesId);
    _saveAndNotify();
    return true;
  }

  /// يزيل عملاً من مجموعة.
  bool removeFrom(String collectionId, String seriesId) {
    final i = _collections.indexWhere((c) => c.id == collectionId);
    if (i < 0) return false;
    final c = _collections[i];
    if (!c.contains(seriesId)) return false;
    _collections = List<ReadingCollection>.from(_collections)
      ..[i] = c.withRemoved(seriesId);
    _saveAndNotify();
    return true;
  }

  /// يبدّل وجود عمل في مجموعة (لزر «أضف إلى مجموعة»).
  bool toggleIn(String collectionId, String seriesId) {
    final c = byId(collectionId);
    if (c == null) return false;
    if (c.contains(seriesId)) {
      return removeFrom(collectionId, seriesId);
    }
    return addTo(collectionId, seriesId);
  }

  /// يعيد ترتيب عمل داخل مجموعة (سحب).
  bool move(String collectionId, int from, int to) {
    final i = _collections.indexWhere((c) => c.id == collectionId);
    if (i < 0) return false;
    final next = _collections[i].withMoved(from, to);
    if (identical(next, _collections[i])) return false;
    _collections = List<ReadingCollection>.from(_collections)
      ..[i] = next;
    _saveAndNotify();
    return true;
  }

  /// يستورد مجموعة من رابط مشاركة (يعيدها أو null إن كان الرابط غير صالح).
  ReadingCollection? importFromLink(String link) {
    final decoded = CollectionLinkCodec.decode(link);
    if (decoded == null) return null;
    _collections = [decoded, ..._collections];
    _saveAndNotify();
    return decoded;
  }

  /// يستورد مجموعة جاهزة (من ملف JSON مثلاً).
  ReadingCollection importCollection(ReadingCollection c) {
    final fresh = ReadingCollection(
      id: ReadingCollection.newId(),
      name: c.name,
      description: c.description,
      isPublic: c.isPublic,
      seriesIds: List<String>.from(c.seriesIds),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    _collections = [fresh, ..._collections];
    _saveAndNotify();
    return fresh;
  }

  /// يصدّر كل المجموعات كـ JSON (للنسخ الاحتياطي).
  String exportJson() =>
      jsonEncode(_collections.map((c) => c.toJson()).toList());

  /// يستورد مجموعات من JSON (يستبدل الحالية). يعيد عدد المستوردة.
  int importJson(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return 0;
      final list = decoded
          .whereType<Map>()
          .map((e) => ReadingCollection.fromJson(
              Map<String, dynamic>.from(e)))
          .where((c) => c.id.isNotEmpty)
          .toList();
      _collections = list;
      _saveAndNotify();
      return list.length;
    } catch (_) {
      return 0;
    }
  }

  /// يمسح كل المجموعات.
  void clear() {
    _collections = const [];
    _saveAndNotify();
  }
}

/// مجموعات جاهزة تُقترح على المستخدم الجديد (تُنشأ عند أول فتح).
class StarterCollections {
  StarterCollections._();

  static List<ReadingCollection> build({DateTime? now}) {
    final at = now ?? DateTime.now();
    return [
      ReadingCollection(
        id: 'starter_favorites',
        name: 'أفضل ما قرأت',
        description: 'أعمال تستحق العودة إليها.',
        isPublic: true,
        createdAt: at,
        updatedAt: at,
      ),
      ReadingCollection(
        id: 'starter_later',
        name: 'للقراءة لاحقاً',
        description: 'أعمال تنتظر دورها في قائمتي.',
        isPublic: false,
        createdAt: at,
        updatedAt: at,
      ),
      ReadingCollection(
        id: 'starter_marathon',
        name: 'ماراثون نهاية الأسبوع',
        description: 'أعمال طويلة لجلسة قراءة مطوّلة.',
        isPublic: true,
        createdAt: at,
        updatedAt: at,
      ),
    ];
  }
}

/// ──────────────────────────────────────────────────────────────────────────
/// شاشات المجموعات — قائمة المجموعات، تفاصيل مجموعة،
/// وورقة «أضف إلى مجموعة» من أي عمل.
/// ──────────────────────────────────────────────────────────────────────────

/// شاشة «مجموعاتي»: إنشاء، فتح، حذف، استيراد من رابط.
class CollectionsScreen extends StatefulWidget {
  const CollectionsScreen({
    super.key,
    this.onOpenSeries,
    this.seriesById,
  });

  /// يُنادى عند الضغط على عمل داخل تفاصيل مجموعة.
  final void Function(Series series)? onOpenSeries;

  /// خريطة المعرف ← العمل (لعرض الأغلفة في التفاصيل).
  final Map<String, Series>? seriesById;

  @override
  State<CollectionsScreen> createState() => _CollectionsScreenState();
}

class _CollectionsScreenState extends State<CollectionsScreen> {
  @override
  void initState() {
    super.initState();
    CollectionsStore.i.load();
  }

  Future<void> _create() async {
    final p = context.pal;
    final nameCtl = TextEditingController();
    final descCtl = TextEditingController();
    var isPublic = true;
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          backgroundColor: p.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(p.r(1.0)),
          ),
          title: Text('مجموعة جديدة', style: context.ds(size: 18)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameCtl,
                autofocus: true,
                style: context.ts(size: 15),
                decoration: InputDecoration(
                  hintText: 'اسم المجموعة',
                  hintStyle: context.ts(size: 14, color: p.textDim),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(p.r(0.8)),
                    borderSide: BorderSide(color: p.border),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: descCtl,
                style: context.ts(size: 15),
                decoration: InputDecoration(
                  hintText: 'وصف اختياري',
                  hintStyle: context.ts(size: 14, color: p.textDim),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(p.r(0.8)),
                    borderSide: BorderSide(color: p.border),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Text('مجموعة عامة (قابلة للمشاركة)',
                      style: context.ts(size: 13)),
                  const Spacer(),
                  Switch(
                    value: isPublic,
                    activeColor: p.accent,
                    onChanged: (v) => setLocal(() => isPublic = v),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: Text('إلغاء',
                  style: context.ts(color: p.textDim)),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('إنشاء'),
            ),
          ],
        ),
      ),
    );
    if (result != true) return;
    CollectionsStore.i.create(
      name: nameCtl.text,
      description: descCtl.text,
      isPublic: isPublic,
    );
    setState(() {});
  }

  Future<void> _importLink() async {
    final p = context.pal;
    final ctl = TextEditingController();
    final link = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(p.r(1.0)),
        ),
        title: Text('استيراد مجموعة', style: context.ds(size: 18)),
        content: TextField(
          controller: ctl,
          autofocus: true,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: CollectionLinkCodec.pasteHint,
            hintStyle: context.ts(size: 12.5, color: p.textDim),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(p.r(0.8)),
              borderSide: BorderSide(color: p.border),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('إلغاء',
                style: context.ts(color: p.textDim)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(ctl.text.trim()),
            child: const Text('استيراد'),
          ),
        ],
      ),
    );
    if (link == null || link.isEmpty) return;
    final imported = CollectionsStore.i.importFromLink(link);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(imported == null
            ? 'الرابط غير صالح — تأكد أنه يبدأ بـ senok://collection/'
            : 'استُوردت مجموعة «${imported.name}»'),
      ),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('مجموعاتي', style: context.ds(size: 20)),
        actions: [
          IconButton(
            onPressed: _importLink,
            icon: SIcon(SardIcons.folder_copy_outlined, color: p.text),
            tooltip: 'استيراد من رابط',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        backgroundColor: p.accent,
        foregroundColor: p.onAccent,
        icon: SIcon(SardIcons.add_circle_outline, color: p.onAccent),
        label: Text('مجموعة جديدة',
            style: context.ts(size: 14, w: FontWeight.w700, color: p.onAccent)),
      ),
      body: AnimatedBuilder(
        animation: CollectionsStore.i,
        builder: (context, _) {
          final items = CollectionsStore.i.collections;
          if (items.isEmpty) {
            return const EmptyState(
              title: 'لا مجموعات بعد',
              subtitle:
                  'أنشئ مجموعتك الأولى: «أفضل ما قرأت»، «للشتاء»، أو أي قائمة تريدها.',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, i) {
              final c = items[i];
              return _CollectionTile(
                collection: c,
                onTap: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => CollectionDetailScreen(
                        collectionId: c.id,
                        onOpenSeries: widget.onOpenSeries,
                        seriesById: widget.seriesById,
                      ),
                    ),
                  );
                  setState(() {});
                },
                onDelete: () {
                  CollectionsStore.i.remove(c.id);
                  setState(() {});
                },
              );
            },
          );
        },
      ),
    );
  }
}

class _CollectionTile extends StatelessWidget {
  const _CollectionTile({
    required this.collection,
    required this.onTap,
    required this.onDelete,
  });

  final ReadingCollection collection;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Pressable(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.9)),
          border: Border.all(color: p.border),
          boxShadow: softShadow(p),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: tint(p.accent, 0.12),
                borderRadius: BorderRadius.circular(p.r(0.7)),
              ),
              child: SIcon(
                SardIcons.collections_bookmark_rounded,
                size: 22,
                color: p.accent,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(collection.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: context.ds(size: 15.5, w: FontWeight.w700)),
                  const SizedBox(height: 3),
                  Text(
                    collection.description.isEmpty
                        ? '${collection.count} عمل · ${collection.isPublic ? 'عامة' : 'خاصة'}'
                        : '${collection.description} · ${collection.count} عمل',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.ts(size: 12.5, color: p.textDim),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: onDelete,
              child: SIcon(SardIcons.delete_outline_rounded,
                  size: 19, color: p.textDim),
            ),
          ],
        ),
      ),
    );
  }
}

/// شاشة تفاصيل مجموعة: الأعمال بالترتيب + مشاركة + إعادة ترتيب.
class CollectionDetailScreen extends StatefulWidget {
  const CollectionDetailScreen({
    super.key,
    required this.collectionId,
    this.onOpenSeries,
    this.seriesById,
  });

  final String collectionId;
  final void Function(Series series)? onOpenSeries;
  final Map<String, Series>? seriesById;

  @override
  State<CollectionDetailScreen> createState() =>
      _CollectionDetailScreenState();
}

class _CollectionDetailScreenState extends State<CollectionDetailScreen> {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = CollectionsStore.i;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final c = store.byId(widget.collectionId);
        if (c == null) {
          return Scaffold(
            backgroundColor: p.bg,
            appBar: AppBar(title: Text('مجموعة', style: context.ds(size: 20))),
            body: const EmptyState(
              title: 'المجموعة غير موجودة',
              subtitle: 'ربما حُذفت.',
            ),
          );
        }
        final series = c.seriesIds
            .map((id) => widget.seriesById?[id])
            .whereType<Series>()
            .toList();
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            title: Text(c.name, style: context.ds(size: 20)),
            actions: [
              IconButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(c.shareText())),
                  );
                },
                icon: SIcon(SardIcons.share_rounded, color: p.text),
                tooltip: 'مشاركة الرابط',
              ),
            ],
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (c.description.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Text(c.description,
                      style: context.ts(size: 13.5, color: p.textDim)),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Text(
                  '${c.count} عمل · اسحب لإعادة الترتيب',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ),
              if (series.isEmpty)
                const Expanded(
                  child: EmptyState(
                    title: 'المجموعة فارغة',
                    subtitle:
                        'أضف أعمالاً من أي صفحة عمل عبر زر «أضف إلى مجموعة».',
                  ),
                )
              else
                Expanded(
                  child: ReorderableListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    itemCount: series.length,
                    onReorder: (from, to) {
                      final target = to > from ? to - 1 : to;
                      store.move(c.id, from, target);
                    },
                    itemBuilder: (context, i) {
                      final s = series[i];
                      return Padding(
                        key: ValueKey(s.id),
                        padding: const EdgeInsets.only(bottom: 10),
                        child: SeriesTile(
                          series: s,
                          onTap: () => widget.onOpenSeries?.call(s),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

/// ورقة «أضف إلى مجموعة» (تُفتح من صفحة أي عمل).
class AddToCollectionSheet extends StatefulWidget {
  const AddToCollectionSheet({super.key, required this.series});
  final Series series;

  @override
  State<AddToCollectionSheet> createState() => _AddToCollectionSheetState();

  /// يعرض الورقة ويعيد true إن أُضيف العمل إلى أي مجموعة.
  static Future<bool> show(BuildContext context, Series series) async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddToCollectionSheet(series: series),
    );
    return result ?? false;
  }
}

class _AddToCollectionSheetState extends State<AddToCollectionSheet> {
  @override
  void initState() {
    super.initState();
    CollectionsStore.i.load();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = CollectionsStore.i;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final items = store.collections;
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(p.r(1.4)),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: p.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text('أضف «${widget.series.title}» إلى...',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: context.ds(size: 16)),
              const SizedBox(height: 12),
              if (items.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    'لا مجموعات بعد — أنشئ أول مجموعة أدناه.',
                    style: context.ts(size: 13, color: p.textDim),
                  ),
                )
              else
                Flexible(
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: items.length,
                    separatorBuilder: (_, __) =>
                        const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final c = items[i];
                      final has = c.contains(widget.series.id);
                      return Pressable(
                        onTap: () {
                          store.toggleIn(c.id, widget.series.id);
                          Navigator.of(context).pop(true);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 11),
                          decoration: BoxDecoration(
                            color: has
                                ? tint(p.accent, 0.12)
                                : p.surfaceHi,
                            borderRadius:
                                BorderRadius.circular(p.r(0.8)),
                            border: Border.all(
                              color: has
                                  ? tint(p.accent, 0.4)
                                  : p.border,
                            ),
                          ),
                          child: Row(
                            children: [
                              SIcon(
                                has
                                    ? SardIcons.check_circle_rounded
                                    : SardIcons
                                        .collections_bookmark_outlined,
                                size: 19,
                                color: has ? p.accent : p.textDim,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  c.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: context.ts(
                                      size: 14, w: FontWeight.w600),
                                ),
                              ),
                              Text(
                                '${c.count} عمل',
                                style: context.ts(
                                    size: 12, color: p.textDim),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: PrimaryButton(
                  label: 'مجموعة جديدة',
                  icon: SardIcons.add_circle_outline,
                  onTap: () async {
                    final created = CollectionsStore.i.create(
                      name: 'مجموعة جديدة',
                    );
                    CollectionsStore.i.addTo(
                        created.id, widget.series.id);
                    if (context.mounted) {
                      Navigator.of(context).pop(true);
                    }
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
