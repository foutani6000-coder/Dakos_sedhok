import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/search_filters.dart';
import '../../core/discovery/reading_history.dart';
import '../../core/discovery/recommendation_engine.dart';
import '../../core/discovery/taste_profile.dart';
import '../../core/discovery/trending_engine.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cards.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/states.dart';
import '../details/details_screen.dart';
import 'advanced_search.dart';
import 'collections.dart';
import 'reading_challenges.dart';
import 'reading_stats.dart';
import 'weekly_digest.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// شاشة «اكتشف» — DiscoverScreen
/// الرائج + مقترح لك + تصنيفات + جديد + مختارات المحرر +
/// اختصارات (مجموعاتي، إحصاءاتي، تحدياتي، موجزي، ضبط ذوقي).
///
/// تُحمَّل البيانات من [SardRepository] ومن المخازن المحلية.
/// ──────────────────────────────────────────────────────────────────────────

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({
    super.key,
    this.repository,
    this.settings,
    this.history,
  });

  final SardRepository? repository;
  final SettingsController? settings;
  final ReadingHistoryStore? history;

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  late final SardRepository _repo;
  SettingsController? _settings;
  ReadingHistoryStore? _history;
  Future<HomeData>? _homeFuture;
  TrendingPeriod _period = TrendingPeriod.week;

  @override
  void initState() {
    super.initState();
    _repo = widget.repository ?? SardRepository();
    _settings = widget.settings;
    _history = widget.history;
    _homeFuture = _repo.home();
    _loadLocal();
  }

  Future<void> _loadLocal() async {
    if (_settings == null) {
      final s = await SettingsController.load();
      if (mounted) setState(() => _settings = s);
    }
    if (_history == null) {
      final h = await ReadingHistoryStore.loadNew();
      if (mounted) setState(() => _history = h);
    }
    await TasteProfileStore.i.load();
    await ReadingHistoryStore.i.load();
    await ChallengeStore.i.load();
    await CollectionsStore.i.load();
    if (mounted) setState(() {});
  }

  void _openDetails(Series s) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DetailsScreen(series: s),
      ),
    );
  }

  void _openAdvanced({SearchFilters filters = SearchFilters.none}) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => AdvancedSearchScreen(
          initialFilters: filters,
          repository: _repo,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('اكتشف', style: context.ds(size: 22)),
        actions: [
          IconButton(
            onPressed: () => _openAdvanced(),
            icon: SIcon(SardIcons.manage_search_rounded, color: p.text),
            tooltip: 'بحث متقدم',
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const TasteSettingsScreen(),
                ),
              );
            },
            icon: SIcon(SardIcons.tune_rounded, color: p.text),
            tooltip: 'ضبط ذوقي',
          ),
        ],
      ),
      body: FutureBuilder<HomeData>(
        future: _homeFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return ErrorState(
              onRetry: () => setState(() => _homeFuture = _repo.home()),
            );
          }
          final home = snap.data;
          if (home == null) {
            return const EmptyState(
              title: 'لا بيانات بعد',
              subtitle: 'تحقق من الاتصال وحاول مجدداً.',
            );
          }
          final all = _dedupeAll(home);
          return RefreshIndicator(
            color: p.accent,
            onRefresh: () async {
              setState(() => _homeFuture = _repo.home());
              await _homeFuture;
            },
            child: ListView(
              padding: const EdgeInsets.only(bottom: 28),
              children: [
                _SearchField(onTap: () => _openAdvanced()),
                _ShortcutsRow(
                  onCollections: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => CollectionsScreen(
                          seriesById: {for (final s in all) s.id: s},
                          onOpenSeries: _openDetails,
                        ),
                      ),
                    );
                  },
                  onStats: () {
                    final settings = _settings;
                    final history = _history;
                    if (settings == null || history == null) return;
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => ReadingStatsScreen(
                          settings: settings,
                          history: history,
                        ),
                      ),
                    );
                  },
                  onChallenges: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const ReadingChallengesScreen(),
                      ),
                    );
                  },
                  onDigest: () {
                    final settings = _settings;
                    final history = _history;
                    if (settings == null || history == null) return;
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => WeeklyDigestScreen(
                          settings: settings,
                          history: history,
                        ),
                      ),
                    );
                  },
                ),
                _SectionHeader(
                  title: 'الرائج الآن',
                  icon: SardIcons.local_fire_department_rounded,
                  trailing: _PeriodChips(
                    period: _period,
                    onChanged: (v) => setState(() => _period = v),
                  ),
                ),
                _TrendingRow(
                  entries: TrendingEngine.rank(
                    all,
                    period: _period,
                    limit: 10,
                  ),
                  onTap: _openDetails,
                ),
                _SectionHeader(
                  title: 'مقترح لك',
                  icon: SardIcons.auto_awesome_rounded,
                  subtitle: TasteProfileStore.i.profile.describe(),
                ),
                _RecommendedRow(
                  items: _recommendations(all),
                  onTap: _openDetails,
                ),
                _SectionHeader(
                  title: 'تصفّح حسب التصنيف',
                  icon: SardIcons.category_rounded,
                ),
                _GenreGrid(
                  onPick: (genre) {
                    _openAdvanced(
                      filters: SearchFilters(genres: {genre}),
                    );
                  },
                ),
                _SectionHeader(
                  title: 'جديد هذا الأسبوع',
                  icon: SardIcons.bolt_rounded,
                ),
                _FreshRow(
                  items: TrendingEngine.freshThisWeek(all).take(10).toList(),
                  onTap: _openDetails,
                ),
                _SectionHeader(
                  title: 'مختارات المحرر',
                  icon: SardIcons.star_rounded,
                  subtitle: 'الأعلى تقييماً بين الأعمال الحديثة.',
                ),
                _EditorPicksList(
                  items: EditorPicks.pick(all, limit: 6),
                  onTap: _openDetails,
                ),
                const SizedBox(height: 8),
                _HiddenGemsCard(
                  items: EditorPicks.hiddenGems(all, limit: 5),
                  onTap: _openDetails,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  List<Series> _dedupeAll(HomeData home) {
    final map = <String, Series>{};
    for (final s in [
      ...home.featured,
      ...home.suggestions,
      ...home.latest,
      ...home.popular,
    ]) {
      map[s.id] = s;
    }
    return map.values.toList();
  }

  List<ScoredSeries> _recommendations(List<Series> all) {
    final settings = _settings;
    final history = _history;
    final profile = TasteProfileStore.i.profile;
    final readIds = <String>{
      ...?history?.readChaptersBySeries.keys,
      ...?settings?.readingIds,
    };
    return RecommendationEngine.recommend(
      RecommendationInput(
        all: all,
        profile: profile,
        followedIds: settings?.followedSeries ?? const {},
        readIds: readIds,
        favoriteIds: settings?.favoriteIds.toSet() ?? const {},
      ),
      limit: 10,
    );
  }
}

/// حقل بحث وهمي يفتح البحث المتقدم.
class _SearchField extends StatelessWidget {
  const _SearchField({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Pressable(
        onTap: onTap,
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(1.0)),
            border: Border.all(color: p.border),
          ),
          child: Row(
            children: [
              SIcon(SardIcons.search_rounded, size: 20, color: p.textDim),
              const SizedBox(width: 10),
              Text(
                'ابحث عن عنوان أو تصنيف...',
                style: context.ts(size: 14, color: p.textDim),
              ),
              const Spacer(),
              SIcon(SardIcons.tune_rounded, size: 18, color: p.textDim),
            ],
          ),
        ),
      ),
    );
  }
}

/// صف اختصارات: مجموعاتي / إحصاءاتي / تحدياتي / موجزي.
class _ShortcutsRow extends StatelessWidget {
  const _ShortcutsRow({
    required this.onCollections,
    required this.onStats,
    required this.onChallenges,
    required this.onDigest,
  });

  final VoidCallback onCollections;
  final VoidCallback onStats;
  final VoidCallback onChallenges;
  final VoidCallback onDigest;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
      child: Row(
        children: [
          _Shortcut(
            icon: SardIcons.collections_bookmark_rounded,
            label: 'مجموعاتي',
            onTap: onCollections,
          ),
          const SizedBox(width: 8),
          _Shortcut(
            icon: SardIcons.menu_book_rounded,
            label: 'إحصاءاتي',
            onTap: onStats,
          ),
          const SizedBox(width: 8),
          _Shortcut(
            icon: SardIcons.local_fire_department_rounded,
            label: 'تحدياتي',
            onTap: onChallenges,
          ),
          const SizedBox(width: 8),
          _Shortcut(
            icon: SardIcons.calendar_today_rounded,
            label: 'موجزي',
            onTap: onDigest,
          ),
        ],
      ),
    );
  }
}

class _Shortcut extends StatelessWidget {
  const _Shortcut({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final SIconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Pressable(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(0.9)),
            border: Border.all(color: p.border),
          ),
          child: Column(
            children: [
              SIcon(icon, size: 20, color: p.accent),
              const SizedBox(height: 6),
              Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: context.ts(size: 12, w: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

/// عنوان قسم مع أيقونة ووصف اختياري وعنصر إضافي.
class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    required this.icon,
    this.subtitle,
    this.trailing,
  });

  final String title;
  final SIconData icon;
  final String? subtitle;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
      child: Row(
        children: [
          SIcon(icon, size: 20, color: p.accent),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.ds(size: 17)),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(subtitle!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style:
                          context.ts(size: 12, color: p.textDim)),
                ],
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// شرائح فترة الرائج (اليوم / الأسبوع / الشهر / الكل).
class _PeriodChips extends StatelessWidget {
  const _PeriodChips({required this.period, required this.onChanged});
  final TrendingPeriod period;
  final ValueChanged<TrendingPeriod> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: TrendingPeriod.values.map((v) {
        final on = v == period;
        return Padding(
          padding: const EdgeInsets.only(right: 4),
          child: Pressable(
            onTap: () => onChanged(v),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: on ? p.accent : p.surface,
                borderRadius: BorderRadius.circular(p.r(1.4)),
                border: Border.all(
                  color: on ? p.accent : p.border,
                ),
              ),
              child: Text(
                v.label,
                style: context.ts(
                  size: 11.5,
                  w: FontWeight.w700,
                  color: on ? p.onAccent : p.text,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// صف أفقي للرائج مع شارة الترتيب.
class _TrendingRow extends StatelessWidget {
  const _TrendingRow({required this.entries, required this.onTap});
  final List<TrendingEntry> entries;
  final ValueChanged<Series> onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (entries.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: EmptyState(
          title: 'لا أعمال رائجة',
          subtitle: 'ستظهر هنا عند توفر البيانات.',
        ),
      );
    }
    return SizedBox(
      height: 218,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: entries.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final e = entries[i];
          return SizedBox(
            width: 140,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    PosterCard(
                      series: e.series,
                      onTap: () => onTap(e.series),
                      width: 140,
                    ),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: TrendingRankLabel.isPodium(e.rank)
                              ? p.gold
                              : Colors.black.withAlpha(150),
                          borderRadius:
                              BorderRadius.circular(p.r(1.4)),
                        ),
                        child: Text(
                          TrendingRankLabel.label(e.rank),
                          style: context.ts(
                            size: 12,
                            w: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  e.why,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: context.ts(size: 11, color: p.textDim),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// صف أفقي للتوصيات مع سبب الترشيح.
class _RecommendedRow extends StatelessWidget {
  const _RecommendedRow({required this.items, required this.onTap});
  final List<ScoredSeries> items;
  final ValueChanged<Series> onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (items.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(0.9)),
            border: Border.all(color: p.border),
          ),
          child: Text(
            'اقرأ بعض الفصول أولاً وسنقترح عليك أعمالاً تناسب ذوقك.',
            style: context.ts(size: 13, color: p.textDim, height: 1.6),
          ),
        ),
      );
    }
    return SizedBox(
      height: 218,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final item = items[i];
          return SizedBox(
            width: 140,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                PosterCard(
                  series: item.series,
                  onTap: () => onTap(item.series),
                  width: 140,
                ),
                const SizedBox(height: 6),
                Text(
                  item.explanation,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: context.ts(size: 11, color: p.textDim),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// شبكة التصنيفات (نقرة تفتح البحث المتقدم بذلك التصنيف).
class _GenreGrid extends StatelessWidget {
  const _GenreGrid({required this.onPick});
  final ValueChanged<String> onPick;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: SearchFilters.genreOptions.map((g) {
          return Pressable(
            onTap: () => onPick(g),
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 9),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(p.r(1.4)),
                border: Border.all(color: p.border),
              ),
              child: Text(g,
                  style: context.ts(size: 13, w: FontWeight.w600)),
            ),
          );
        }).toList(),
      ),
    );
  }
}

/// صف أفقي للأعمال الجديدة.
class _FreshRow extends StatelessWidget {
  const _FreshRow({required this.items, required this.onTap});
  final List<Series> items;
  final ValueChanged<Series> onTap;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: EmptyState(
          title: 'لا جديد هذا الأسبوع',
          subtitle: 'تابعنا قريباً.',
        ),
      );
    }
    return SizedBox(
      height: 200,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final s = items[i];
          return PosterCard(
            series: s,
            onTap: () => onTap(s),
            width: 140,
            subtitle: s.year.toString(),
          );
        },
      ),
    );
  }
}

/// قائمة مختارات المحرر (صفوف أفقية بصور مصغرة).
class _EditorPicksList extends StatelessWidget {
  const _EditorPicksList({required this.items, required this.onTap});
  final List<Series> items;
  final ValueChanged<Series> onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: items
          .map((s) => Padding(
                padding:
                    const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: SeriesTile(series: s, onTap: () => onTap(s)),
              ))
          .toList(),
    );
  }
}

/// بطاقة «جواهر مخفية» (تقييم عالٍ ومشاهدات متواضعة).
class _HiddenGemsCard extends StatelessWidget {
  const _HiddenGemsCard({required this.items, required this.onTap});
  final List<Series> items;
  final ValueChanged<Series> onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (items.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: tint(p.gold, 0.08),
          borderRadius: BorderRadius.circular(p.r(1.0)),
          border: Border.all(color: tint(p.gold, 0.35)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SIcon(SardIcons.auto_awesome_rounded,
                    size: 18, color: p.gold),
                const SizedBox(width: 8),
                Text('جواهر مخفية',
                    style: context.ds(size: 15, w: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'تقييم عالٍ ومشاهدات متواضعة — اكتشفها قبل الجميع.',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
            const SizedBox(height: 10),
            ...items.map((s) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Pressable(
                    onTap: () => onTap(s),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 40,
                          height: 56,
                          child: CoverArt(series: s, radius: 8),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(s.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: context.ts(
                                      size: 13.5,
                                      w: FontWeight.w700)),
                              const SizedBox(height: 2),
                              Text(
                                'تقييم ${s.rating.toStringAsFixed(1)} · ${formatCount(s.views)} مشاهدة',
                                style: context.ts(
                                    size: 12, color: p.textDim),
                              ),
                            ],
                          ),
                        ),
                        SIcon(SardIcons.chevron_left_rounded,
                            size: 18, color: p.textDim),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

/// ──────────────────────────────────────────────────────────────────────────
/// شاشة «ضبط ذوقي» — TasteSettingsScreen
/// شرائح أوزان لكل تصنيف، تبديل للمكروهات، وإعادة بناء من سجل القراءة.
/// ──────────────────────────────────────────────────────────────────────────

class TasteSettingsScreen extends StatefulWidget {
  const TasteSettingsScreen({super.key});

  @override
  State<TasteSettingsScreen> createState() => _TasteSettingsScreenState();
}

class _TasteSettingsScreenState extends State<TasteSettingsScreen> {
  SettingsController? _settings;
  ReadingHistoryStore? _history;

  @override
  void initState() {
    super.initState();
    TasteProfileStore.i.load();
    _load();
  }

  Future<void> _load() async {
    final s = await SettingsController.load();
    final h = await ReadingHistoryStore.loadNew();
    if (mounted) {
      setState(() {
        _settings = s;
        _history = h;
      });
    }
  }

  Future<void> _rebuild() async {
    final settings = _settings;
    final history = _history;
    if (settings == null || history == null) return;
    final byId = <String, Series>{};
    for (final id in history.readChaptersBySeries.keys) {
      final s = settings.cachedSeries(id);
      if (s != null) byId[id] = s;
    }
    TasteProfileStore.i.rebuildFromHistory(
      readChapters: history.readChaptersBySeries,
      seriesById: byId,
      lastReadAt: history.lastReadAtBySeries,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('أُعيد بناء ملف ذوقك من سجل قراءتك')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text('ضبط ذوقي', style: context.ds(size: 20)),
        actions: [
          TextButton(
            onPressed: () {
              TasteProfileStore.i.reset();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('أُعيد ضبط ذوقك')),
              );
            },
            child: Text('إعادة ضبط',
                style: context.ts(size: 13, color: p.accent)),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: TasteProfileStore.i,
        builder: (context, _) {
          final profile = TasteProfileStore.i.profile;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(p.r(1.0)),
                  border: Border.all(color: p.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('ذوقك الحالي',
                        style: context.ds(size: 15, w: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(
                      profile.describe(),
                      style:
                          context.ts(size: 13, color: p.textDim, height: 1.6),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'اكتمال الملف: ${(profile.completeness * 100).round()}٪',
                      style: context.ts(size: 12, color: p.accent),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text('أوزان التصنيفات',
                  style: context.ds(size: 16)),
              const SizedBox(height: 6),
              Text(
                'اسحب الشريط لرفع أو خفض اهتمامك بتصنيف. '
                'الوزن 10 يعني التصنيف المفضّل.',
                style: context.ts(size: 12.5, color: p.textDim, height: 1.6),
              ),
              const SizedBox(height: 10),
              ...kKnownGenres.map((g) {
                final weight = profile.genreWeight(g);
                final disliked = profile.dislikes(g);
                return _GenreWeightRow(
                  genre: g,
                  weight: weight,
                  disliked: disliked,
                  onWeight: (v) =>
                      TasteProfileStore.i.setGenreWeight(g, v),
                  onDislike: (v) =>
                      TasteProfileStore.i.setDisliked(g, v),
                );
              }),
              const SizedBox(height: 18),
              Text('أنواع الأعمال المفضّلة',
                  style: context.ds(size: 16)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: SearchFilters.typeOptions.map((t) {
                  final on = profile.likedTypes.contains(t);
                  return Pressable(
                    onTap: () =>
                        TasteProfileStore.i.setLikedType(t, !on),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 9),
                      decoration: BoxDecoration(
                        color: on ? p.accent : p.surface,
                        borderRadius:
                            BorderRadius.circular(p.r(1.4)),
                        border: Border.all(
                          color: on ? p.accent : p.border,
                        ),
                      ),
                      child: Text(t,
                          style: context.ts(
                            size: 13,
                            w: FontWeight.w600,
                            color: on ? p.onAccent : p.text,
                          )),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              PrimaryButton(
                label: 'إعادة البناء من سجل قراءتي',
                icon: SardIcons.refresh_rounded,
                onTap: _rebuild,
              ),
              const SizedBox(height: 10),
              Text(
                'يعيد حساب الأوزان من الفصول التي قرأتها فعلاً، '
                'ويستبدل ضبطك اليدوي الحالي.',
                textAlign: TextAlign.center,
                style: context.ts(size: 12, color: p.textDim, height: 1.6),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// صف وزن تصنيف: الاسم + شريط + قيمة + تبديل «لا أريده».
class _GenreWeightRow extends StatelessWidget {
  const _GenreWeightRow({
    required this.genre,
    required this.weight,
    required this.disliked,
    required this.onWeight,
    required this.onDislike,
  });

  final String genre;
  final double weight;
  final bool disliked;
  final ValueChanged<double> onWeight;
  final ValueChanged<bool> onDislike;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(genre,
                    style: context.ts(size: 14, w: FontWeight.w700)),
              ),
              Text(
                disliked ? 'مكروه' : weight.toStringAsFixed(1),
                style: context.ts(
                  size: 13,
                  w: FontWeight.w700,
                  color: disliked ? p.accent : p.text,
                ),
              ),
              const SizedBox(width: 8),
              Switch(
                value: disliked,
                activeColor: p.accent,
                onChanged: onDislike,
              ),
            ],
          ),
          Slider(
            value: disliked ? 0 : weight,
            min: 0,
            max: kTasteMaxWeight,
            divisions: 20,
            activeColor: p.accent,
            onChanged: disliked ? null : onWeight,
          ),
        ],
      ),
    );
  }
}
