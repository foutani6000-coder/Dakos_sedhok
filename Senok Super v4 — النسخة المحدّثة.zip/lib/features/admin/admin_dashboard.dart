import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_announcements.dart';
import 'admin_audit.dart';
import 'admin_chapters.dart';
import 'admin_moderation.dart';
import 'admin_reports.dart';
import 'admin_repository.dart';
import 'admin_search.dart';
import 'admin_series.dart';
import 'admin_settings.dart';
import 'admin_users.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// لوحة تحكم الأدمن + شاشة الدخول التجريبي — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// البوابة الرئيسية للوحة: إحصاءات سريعة، وصول للأقسام التسعة، آخر إجراءات
/// التدقيق، والبلاغات المفتوحة. عند أول فتح تُنشر الفصول المجدولة التي حان
/// وقتها تلقائياً.
/// ──────────────────────────────────────────────────────────────────────────

/// شاشة الدخول التجريبي للوحة الأدمن.
class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final err = await AdminAuth.i.login(_userCtrl.text, _passCtrl.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const AdminDashboardScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text('لوحة الأدمن', style: context.ds(size: 19)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          const SizedBox(height: 8),
          Center(
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: tint(p.accent, 0.12),
                shape: BoxShape.circle,
              ),
              child: SIcon(SardIcons.shield_rounded, size: 44, color: p.accent),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'دخول المشرفين',
            style: context.ds(size: 22),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 6),
          Text(
            'هذه اللوحة للمشرفين فقط. كل إجراء يُسجَّل في سجل التدقيق.',
            style: context.ts(size: 13, color: p.textDim),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          const AdminDemoBanner(),
          const SizedBox(height: 20),
          _LoginField(
            controller: _userCtrl,
            label: 'اسم المستخدم',
            hint: 'مثال: admin',
            icon: SardIcons.person_rounded,
            onSubmitted: (_) => _submit(),
          ),
          const SizedBox(height: 12),
          _LoginField(
            controller: _passCtrl,
            label: 'كلمة المرور',
            hint: 'كلمة مرور الأدمن',
            icon: SardIcons.lock_outline,
            obscure: _obscure,
            onToggleObscure: () => setState(() => _obscure = !_obscure),
            onSubmitted: (_) => _submit(),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: tint(kAdminRed, 0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: tint(kAdminRed, 0.4)),
              ),
              child: Row(
                children: [
                  const SIcon(SardIcons.info_outline_rounded, size: 18, color: kAdminRed),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_error!, style: context.ts(size: 13, color: kAdminRed))),
                ],
              ),
            ),
          ],
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _busy ? null : _submit,
              style: FilledButton.styleFrom(
                backgroundColor: p.accent,
                foregroundColor: p.onAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _busy
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : Text('دخول', style: context.ts(size: 15, w: FontWeight.w800, color: p.onAccent)),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('بيانات الدخول التجريبي', style: context.ts(size: 13, w: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(
                  'اسم المستخدم: admin\nكلمة المرور: admin123',
                  style: context.ts(size: 13, color: p.textDim),
                ),
                const SizedBox(height: 4),
                Text(
                  'غيّر كلمة المرور من إعدادات الأدمن بعد أول دخول.',
                  style: context.ts(size: 12, color: kAdminAmber),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LoginField extends StatelessWidget {
  const _LoginField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.onToggleObscure,
    this.onSubmitted,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final SIconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final ValueChanged<String>? onSubmitted;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13, w: FontWeight.w700)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          obscureText: obscure,
          onSubmitted: onSubmitted,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13.5, color: p.textDim),
            prefixIcon: Padding(
              padding: const EdgeInsets.all(12),
              child: SIcon(icon, size: 20, color: p.textDim),
            ),
            suffixIcon: onToggleObscure == null
                ? null
                : IconButton(
                    onPressed: onToggleObscure,
                    icon: SIcon(
                      obscure ? SardIcons.visibility_rounded : SardIcons.visibility_off_outlined,
                      size: 20,
                      color: p.textDim,
                    ),
                  ),
            filled: true,
            fillColor: p.surface,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.accent, width: 1.6),
            ),
          ),
        ),
      ],
    );
  }
}

/// لوحة تحكم الأدمن الرئيسية.
class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  int _publishedDue = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final n = await AdminRepository.i.publishDueChapters();
      if (!mounted) return;
      if (n > 0) {
        setState(() => _publishedDue = n);
        if (mounted) {
          showAdminSnack(context, 'نُشر تلقائياً $n فصل مجدول حان وقته.');
        }
      }
    });
  }

  void _open(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  Future<void> _logout() async {
    final ok = await showAdminConfirm(
      context,
      title: 'تسجيل الخروج',
      message: 'هل تريد الخروج من لوحة الأدمن؟',
      confirmLabel: 'خروج',
    );
    if (!ok || !mounted) return;
    AdminAuth.i.logout();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const AdminLoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final stats = repo.computeStats();
        final audit = repo.recentAudit(limit: 8);
        final openReports = repo.reportsFiltered().where((r) => r.isOpen).take(4).toList();
        final attention = repo.attentionItems();
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('لوحة الأدمن', style: context.ds(size: 19)),
            actions: [
              IconButton(
                onPressed: () => _open(const AdminGlobalSearchScreen()),
                icon: SIcon(SardIcons.search_rounded, size: 22, color: p.text),
                tooltip: 'بحث شامل',
              ),
              IconButton(
                onPressed: () => _open(const AdminSettingsScreen()),
                icon: SIcon(SardIcons.settings_rounded, size: 22, color: p.text),
                tooltip: 'إعدادات الأدمن',
              ),
              IconButton(
                onPressed: _logout,
                icon: SIcon(SardIcons.logout_rounded, size: 22, color: p.text),
                tooltip: 'تسجيل الخروج',
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            children: [
              const AdminDemoBanner(),
              if (_publishedDue > 0) ...[
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: tint(kAdminGreen, 0.12),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: tint(kAdminGreen, 0.4)),
                  ),
                  child: Row(
                    children: [
                      const SIcon(SardIcons.check_circle_rounded, size: 18, color: kAdminGreen),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'نُشر تلقائياً $_publishedDue فصل مجدول حان وقته.',
                          style: context.ts(size: 13, w: FontWeight.w700, color: kAdminGreen),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 14),
              Text('نظرة عامة', style: context.ds(size: 18)),
              const SizedBox(height: 10),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.55,
                children: [
                  AdminStatCard(
                    label: 'الأعمال',
                    value: '${stats.totalSeries}',
                    icon: SardIcons.menu_book_rounded,
                    color: p.accent,
                    sub: '${stats.totalChapters} فصلاً',
                    onTap: () => _open(const AdminSeriesScreen()),
                  ),
                  AdminStatCard(
                    label: 'المستخدمون',
                    value: '${stats.totalUsers}',
                    icon: SardIcons.groups_rounded,
                    color: kAdminBlue,
                    sub: '${stats.newUsers30d} جدد هذا الشهر',
                    onTap: () => _open(const AdminUsersScreen()),
                  ),
                  AdminStatCard(
                    label: 'إجمالي المشاهدات',
                    value: formatCount(stats.totalViews),
                    icon: SardIcons.visibility_rounded,
                    color: kAdminPurple,
                    sub: 'كل الأعمال',
                    onTap: () => _open(const AdminReportsScreen()),
                  ),
                  AdminStatCard(
                    label: 'بلاغات مفتوحة',
                    value: '${stats.openReports}',
                    icon: SardIcons.gavel_rounded,
                    color: kAdminAmber,
                    sub: stats.openReports == 0 ? 'لا شيء بانتظارك' : 'تحتاج مراجعة',
                    onTap: () => _open(const AdminModerationScreen()),
                  ),
                  AdminStatCard(
                    label: 'فصول مجدولة',
                    value: '${stats.scheduledChapters}',
                    icon: SardIcons.watch_later_rounded,
                    color: kAdminTeal,
                    sub: stats.dueChapters > 0 ? '${stats.dueChapters} حان وقتها' : 'لا شيء حان وقته',
                    onTap: () => _open(const AdminChaptersScreen()),
                  ),
                  AdminStatCard(
                    label: 'إعلانات نشطة',
                    value: '${stats.liveAnnouncements}',
                    icon: SardIcons.campaign_rounded,
                    color: kAdminGreen,
                    sub: 'تظهر الآن للمستخدمين',
                    onTap: () => _open(const AdminAnnouncementsScreen()),
                  ),
                ],
              ),
              AdminSectionTitle(
                title: 'أقسام اللوحة',
                subtitle: 'كل أدوات الإدارة في مكان واحد',
                icon: SardIcons.layers_rounded,
              ),
              if (attention.isNotEmpty) ...[
                AdminSectionTitle(
                  title: 'يحتاج انتباهك',
                  subtitle: 'مهام عالقة تستحق المراجعة اليوم',
                  icon: SardIcons.priority_high_rounded,
                  count: attention.length,
                ),
                ...attention.map((item) {
                  final (icon, color, dest) = switch (item.kind) {
                    AdminAttentionKind.dueChapters => (
                        SardIcons.watch_later_rounded,
                        kAdminAmber,
                        const AdminChaptersScreen(),
                      ),
                    AdminAttentionKind.oldDrafts => (
                        SardIcons.chrome_reader_mode_rounded,
                        kAdminTeal,
                        const AdminChaptersScreen(),
                      ),
                    AdminAttentionKind.openReports => (
                        SardIcons.gavel_rounded,
                        kAdminAmber,
                        const AdminModerationScreen(),
                      ),
                    AdminAttentionKind.suspendedUsers => (
                        SardIcons.groups_rounded,
                        kAdminBlue,
                        const AdminUsersScreen(),
                      ),
                  };
                  return _SectionTile(
                    icon: icon,
                    color: color,
                    title: item.title,
                    subtitle: item.subtitle,
                    trailing: '${item.count}',
                    onTap: () => _open(dest),
                  );
                }),
              ],
              _SectionTile(
                icon: SardIcons.menu_book_rounded,
                color: p.accent,
                title: 'إدارة الأعمال',
                subtitle: 'إضافة أعمال وتعديلها وحذفها وتثبيتها',
                trailing: '${stats.totalSeries}',
                onTap: () => _open(const AdminSeriesScreen()),
              ),
              _SectionTile(
                icon: SardIcons.chrome_reader_mode_rounded,
                color: kAdminTeal,
                title: 'إدارة الفصول',
                subtitle: 'نشر وجدولة وإخفاء فصول كل عمل',
                trailing: '${stats.publishedChapters} منشور',
                onTap: () => _open(const AdminChaptersScreen()),
              ),
              _SectionTile(
                icon: SardIcons.groups_rounded,
                color: kAdminBlue,
                title: 'إدارة المستخدمين',
                subtitle: 'أدوار وحالات وتوثيق وحظر',
                trailing: '${stats.totalUsers}',
                onTap: () => _open(const AdminUsersScreen()),
              ),
              _SectionTile(
                icon: SardIcons.gavel_rounded,
                color: kAdminAmber,
                title: 'الإشراف والبلاغات',
                subtitle: 'مراجعة البلاغات ومعالجتها',
                trailing: stats.openReports == 0 ? 'نظيف' : '${stats.openReports} مفتوح',
                onTap: () => _open(const AdminModerationScreen()),
              ),
              _SectionTile(
                icon: SardIcons.campaign_rounded,
                color: kAdminGreen,
                title: 'الإعلانات',
                subtitle: 'إعلانات داخل التطبيق مع استهداف وجدولة',
                trailing: '${stats.liveAnnouncements} نشط',
                onTap: () => _open(const AdminAnnouncementsScreen()),
              ),
              _SectionTile(
                icon: SardIcons.signal_cellular_alt_rounded,
                color: kAdminPurple,
                title: 'التقارير والإحصاءات',
                subtitle: 'نمو المشاهدات وأفضل الأعمال والفصول',
                trailing: formatCount(stats.totalViews),
                onTap: () => _open(const AdminReportsScreen()),
              ),
              _SectionTile(
                icon: SardIcons.settings_rounded,
                color: p.textDim,
                title: 'إعدادات الأدمن',
                subtitle: 'كلمة المرور والنسخ الاحتياطي وإعادة التعيين',
                onTap: () => _open(const AdminSettingsScreen()),
              ),
              AdminSectionTitle(
                title: 'أكثر الأعمال مشاهدة',
                icon: SardIcons.local_fire_department_rounded,
                onAction: () => _open(const AdminReportsScreen()),
                actionLabel: 'التقارير',
              ),
              ...stats.topSeries.map((s) => _TopSeriesTile(series: s)),
              AdminSectionTitle(
                title: 'بلاغات تحتاج مراجعة',
                icon: SardIcons.gavel_rounded,
                count: stats.openReports,
                onAction: () => _open(const AdminModerationScreen()),
                actionLabel: 'الإشراف',
              ),
              if (openReports.isEmpty)
                const AdminEmptyState(
                  icon: SardIcons.check_circle_rounded,
                  title: 'لا بلاغات مفتوحة',
                  message: 'كل البلاغات معالجة. عمل رائع!',
                )
              else
                ...openReports.map((r) => _ReportTile(report: r)),
              AdminSectionTitle(
                title: 'آخر إجراءات التدقيق',
                subtitle: 'كل إجراء في اللوحة يُسجَّل هنا',
                icon: SardIcons.history_rounded,
                onAction: () => _open(const AdminAuditScreen()),
                actionLabel: 'عرض الكل',
              ),
              if (audit.isEmpty)
                const AdminEmptyState(
                  icon: SardIcons.history_rounded,
                  title: 'سجل التدقيق فارغ',
                  message: 'ستظهر هنا إجراءات الأدمن فور حدوثها.',
                )
              else
                ...audit.map((e) => _AuditTile(entry: e)),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  'لوحة أدمن Senok — الوضع التجريبي (بيانات محلية)',
                  style: context.ts(size: 11.5, color: p.textDim),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SectionTile extends StatelessWidget {
  const _SectionTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.trailing,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final String? trailing;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: tint(color, 0.13),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: SIcon(icon, size: 22, color: color),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: context.ts(size: 14.5, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
                    ],
                  ),
                ),
                if (trailing != null) ...[
                  Text(trailing!, style: context.ts(size: 12.5, w: FontWeight.w700, color: p.textDim)),
                  const SizedBox(width: 6),
                ],
                SIcon(SardIcons.chevron_left_rounded, size: 20, color: p.textDim),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TopSeriesTile extends StatelessWidget {
  const _TopSeriesTile({required this.series});

  final AdminSeries series;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 56,
              decoration: BoxDecoration(
                color: tint(p.accent, 0.14),
                borderRadius: BorderRadius.circular(8),
              ),
              alignment: Alignment.center,
              child: Text(
                series.title.isEmpty ? '؟' : series.title[0],
                style: context.ds(size: 20, color: p.accent),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(series.title, style: context.ts(size: 14, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 3),
                  Text(
                    '${series.typeShort} · ${series.chapters} فصلاً · ★ ${series.rating.toStringAsFixed(1)}',
                    style: context.ts(size: 12, color: p.textDim),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(formatCount(series.views), style: context.ts(size: 13.5, w: FontWeight.w800, color: p.accent)),
                Text('مشاهدة', style: context.ts(size: 11, color: p.textDim)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReportTile extends StatelessWidget {
  const _ReportTile({required this.report});

  final AdminReport report;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const AdminModerationScreen()),
          ),
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: tint(kAdminAmber, 0.13),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const SIcon(SardIcons.gavel_rounded, size: 18, color: kAdminAmber),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(report.targetTitle, style: context.ts(size: 13.5, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 2),
                      Text(
                        '${report.reason.label} · من ${report.reporterName} · ${timeAgoArabic(report.createdAt)}',
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                    ],
                  ),
                ),
                AdminStatusBadge(label: report.status.label, color: reportStatusColor(report.status)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AuditTile extends StatelessWidget {
  const _AuditTile({required this.entry});

  final AdminAuditEntry entry;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 8,
            height: 8,
            margin: const EdgeInsets.only(top: 6),
            decoration: BoxDecoration(color: p.accent, shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(entry.summary, style: context.ts(size: 13, w: FontWeight.w600)),
                Text(
                  '${entry.actorName} · ${timeAgoArabic(entry.at)}',
                  style: context.ts(size: 11.5, color: p.textDim),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
