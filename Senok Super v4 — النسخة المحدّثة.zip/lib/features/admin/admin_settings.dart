import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// إعدادات الأدمن — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// تغيير كلمة المرور التجريبية، النسخ الاحتياطي (تصدير/استيراد JSON)، سجل
/// التدقيق (عرض ومسح)، إعادة تعيين البيانات التجريبية، ومعلومات الوضع
/// التجريبي.
/// ──────────────────────────────────────────────────────────────────────────

class AdminSettingsScreen extends StatefulWidget {
  const AdminSettingsScreen({super.key});

  @override
  State<AdminSettingsScreen> createState() => _AdminSettingsScreenState();
}

class _AdminSettingsScreenState extends State<AdminSettingsScreen> {
  final _oldCtrl = TextEditingController();
  final _newCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscureOld = true;
  bool _obscureNew = true;
  bool _busy = false;

  @override
  void dispose() {
    _oldCtrl.dispose();
    _newCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  Future<void> _changePassword() async {
    if (_busy) return;
    setState(() => _busy = true);
    final err = await AdminAuth.i.changePassword(
      _oldCtrl.text,
      _newCtrl.text,
      _confirmCtrl.text,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      showAdminSnack(context, err, isError: true);
      return;
    }
    _oldCtrl.clear();
    _newCtrl.clear();
    _confirmCtrl.clear();
    showAdminSnack(context, 'تم تغيير كلمة المرور بنجاح.');
    setState(() {});
  }

  Future<void> _export() async {
    final json = AdminRepository.i.exportAllJson();
    await Clipboard.setData(ClipboardData(text: json));
    if (!mounted) return;
    showAdminSnack(context, 'نُسخت نسخة JSON الاحتياطية إلى الحافظة (${(json.length / 1024).toStringAsFixed(1)} ك.ب).');
  }

  Future<void> _import() async {
    final ctrl = TextEditingController();
    final p = context.pal;
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('استيراد نسخة احتياطية', style: context.ds(size: 17)),
        content: SizedBox(
          width: double.maxFinite,
          child: TextField(
            controller: ctrl,
            maxLines: 8,
            style: context.ts(size: 12.5),
            decoration: InputDecoration(
              hintText: 'الصق هنا نص JSON المصدَّر من لوحة الأدمن…',
              hintStyle: context.ts(size: 12.5, color: p.textDim),
              filled: true,
              fillColor: p.bg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: p.border),
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('إلغاء', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.textDim)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent),
            onPressed: () => Navigator.of(ctx).pop(ctrl.text),
            child: Text('استيراد', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.onAccent)),
          ),
        ],
      ),
    );
    if (result == null || result.trim().isEmpty) return;
    final res = await AdminRepository.i.importAllJson(result.trim());
    if (!mounted) return;
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
  }

  Future<void> _reset() async {
    final ok = await showAdminConfirm(
      context,
      title: 'إعادة تعيين البيانات',
      message: 'سيُمسح كل ما عدّلته في لوحة الأدمن ويُعاد زرع البيانات التجريبية. لا يمكن التراجع.',
      confirmLabel: 'إعادة تعيين',
      destructive: true,
    );
    if (!ok) return;
    await AdminRepository.i.resetToDemo();
    if (!mounted) return;
    showAdminSnack(context, 'أُعيد تعيين البيانات التجريبية.');
    setState(() {});
  }

  Future<void> _clearAudit() async {
    final ok = await showAdminConfirm(
      context,
      title: 'مسح سجل التدقيق',
      message: 'سيُمسح سجل إجراءات الأدمن بالكامل.',
      confirmLabel: 'مسح',
      destructive: true,
    );
    if (!ok) return;
    await AdminRepository.i.clearAudit();
    if (!mounted) return;
    showAdminSnack(context, 'مُسح سجل التدقيق.');
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final mustChange = AdminAuth.i.mustChangePassword;
        final auditCount = repo.audit.length;
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('إعدادات الأدمن', style: context.ds(size: 19)),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            children: [
              const AdminDemoBanner(),
              AdminSectionTitle(
                title: 'كلمة مرور الأدمن',
                subtitle: mustChange
                    ? 'ما زلت تستخدم كلمة المرور الافتراضية — غيّرها الآن'
                    : 'كلمة المرور محلية على هذا الجهاز',
                icon: SardIcons.lock_outline,
              ),
              if (mustChange)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: tint(kAdminRed, 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: tint(kAdminRed, 0.4)),
                  ),
                  child: Row(
                    children: [
                      const SIcon(SardIcons.priority_high_rounded, size: 18, color: kAdminRed),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'كلمة المرور الافتراضية admin123 ظاهرة في الشيفرة. غيّرها فوراً قبل أي استخدام حقيقي.',
                          style: context.ts(size: 12.5, w: FontWeight.w700, color: kAdminRed),
                        ),
                      ),
                    ],
                  ),
                ),
              _PassField(
                controller: _oldCtrl,
                label: 'كلمة المرور الحالية',
                obscure: _obscureOld,
                onToggle: () => setState(() => _obscureOld = !_obscureOld),
              ),
              const SizedBox(height: 10),
              _PassField(
                controller: _newCtrl,
                label: 'كلمة المرور الجديدة (6 أحرف على الأقل)',
                obscure: _obscureNew,
                onToggle: () => setState(() => _obscureNew = !_obscureNew),
              ),
              const SizedBox(height: 10),
              _PassField(
                controller: _confirmCtrl,
                label: 'تأكيد كلمة المرور الجديدة',
                obscure: _obscureNew,
                onToggle: () => setState(() => _obscureNew = !_obscureNew),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _busy ? null : _changePassword,
                  style: FilledButton.styleFrom(
                    backgroundColor: p.accent,
                    foregroundColor: p.onAccent,
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: _busy
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : Text('تغيير كلمة المرور', style: context.ts(size: 14, w: FontWeight.w800, color: p.onAccent)),
                ),
              ),
              AdminSectionTitle(
                title: 'النسخ الاحتياطي',
                subtitle: 'تصدير كل بيانات الأدمن JSON أو استيرادها',
                icon: SardIcons.download_rounded,
              ),
              _SettingRow(
                icon: SardIcons.share_rounded,
                color: kAdminBlue,
                title: 'تصدير نسخة احتياطية',
                subtitle: 'ينسخ JSON كاملاً إلى الحافظة',
                onTap: _export,
              ),
              _SettingRow(
                icon: SardIcons.download_rounded,
                color: kAdminGreen,
                title: 'استيراد نسخة احتياطية',
                subtitle: 'الصق نص JSON مصدَّراً سابقاً',
                onTap: _import,
              ),
              AdminSectionTitle(
                title: 'سجل التدقيق',
                subtitle: '$auditCount إجراء مسجَّل',
                icon: SardIcons.history_rounded,
              ),
              _SettingRow(
                icon: SardIcons.delete_outline_rounded,
                color: kAdminRed,
                title: 'مسح سجل التدقيق',
                subtitle: 'يمسح كل الإجراءات المسجلة',
                onTap: _clearAudit,
              ),
              AdminSectionTitle(
                title: 'منطقة الخطر',
                icon: SardIcons.priority_high_rounded,
              ),
              Container(
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                  border: Border.all(color: tint(kAdminRed, 0.5), width: p.borderW),
                ),
                child: _SettingRow(
                  icon: SardIcons.refresh_rounded,
                  color: kAdminRed,
                  title: 'إعادة تعيين البيانات التجريبية',
                  subtitle: 'يمسح كل تعديلاتك ويعيد زرع البيانات الافتراضية',
                  onTap: _reset,
                  noBorder: true,
                ),
              ),
              AdminSectionTitle(
                title: 'عن لوحة الأدمن',
                icon: SardIcons.info_outline_rounded,
              ),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                  border: Border.all(color: p.border, width: p.borderW),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _AboutLine('الإصدار', 'لوحة أدمن Senok v1 — الوضع التجريبي'),
                    _AboutLine('التخزين', 'محلي على الجهاز (SharedPreferences / JSON)'),
                    _AboutLine('الخادم', 'نقاط نهاية /admin/* غير موجودة بعد'),
                    _AboutLine('الأعمال', '${repo.series.length} عملاً · ${repo.chapters.length} فصلاً'),
                    _AboutLine('المستخدمون', '${repo.users.length} مستخدماً'),
                    _AboutLine('البلاغات', '${repo.reports.where((r) => r.isOpen).length} مفتوحة من ${repo.reports.length}'),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PassField extends StatelessWidget {
  const _PassField({
    required this.controller,
    required this.label,
    required this.obscure,
    required this.onToggle,
  });

  final TextEditingController controller;
  final String label;
  final bool obscure;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13, w: FontWeight.w700)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          obscureText: obscure,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: '••••••••',
            hintStyle: context.ts(size: 13.5, color: p.textDim),
            prefixIcon: Padding(
              padding: const EdgeInsets.all(12),
              child: SIcon(SardIcons.lock_outline, size: 20, color: p.textDim),
            ),
            suffixIcon: IconButton(
              onPressed: onToggle,
              icon: SIcon(
                obscure ? SardIcons.visibility_rounded : SardIcons.visibility_off_outlined,
                size: 20,
                color: p.textDim,
              ),
            ),
            filled: true,
            fillColor: p.surface,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.accent, width: 1.6),
            ),
          ),
        ),
      ],
    );
  }
}

class _SettingRow extends StatelessWidget {
  const _SettingRow({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.noBorder = false,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool noBorder;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: noBorder ? null : Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: tint(color, 0.13),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: SIcon(icon, size: 18, color: color),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: context.ts(size: 13.5, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
                    ],
                  ),
                ),
                SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AboutLine extends StatelessWidget {
  const _AboutLine(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 92,
            child: Text(label, style: context.ts(size: 12.5, w: FontWeight.w800, color: p.accent)),
          ),
          Expanded(child: Text(value, style: context.ts(size: 12.5, color: p.text))),
        ],
      ),
    );
  }
}
