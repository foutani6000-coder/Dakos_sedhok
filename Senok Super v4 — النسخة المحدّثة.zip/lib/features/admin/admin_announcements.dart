import 'package:flutter/material.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// الإعلانات — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// إعلانات داخل التطبيق مع استهداف (الجميع/القرّاء/المترجمون/الجدد)، وجدولة
/// نشر وانتهاء، وأولوية، ومعاينة حيّة كما يراها المستخدم.
/// ──────────────────────────────────────────────────────────────────────────

class AdminAnnouncementsScreen extends StatefulWidget {
  const AdminAnnouncementsScreen({super.key});

  @override
  State<AdminAnnouncementsScreen> createState() => _AdminAnnouncementsScreenState();
}

class _AdminAnnouncementsScreenState extends State<AdminAnnouncementsScreen> {
  bool _onlyLive = false;

  void _openEditor([AdminAnnouncement? a]) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AdminAnnouncementEditorScreen(announcement: a)),
    );
  }

  Future<void> _delete(AdminAnnouncement a) async {
    final ok = await showAdminConfirm(
      context,
      title: 'حذف الإعلان',
      message: 'سيُحذف «${a.title}» نهائياً.',
      confirmLabel: 'حذف',
      destructive: true,
    );
    if (!ok) return;
    final res = await AdminRepository.i.deleteAnnouncement(a.id);
    if (!mounted) return;
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        var list = repo.announcementsSorted();
        if (_onlyLive) list = list.where((a) => a.isLive).toList();
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('الإعلانات', style: context.ds(size: 19)),
            actions: [
              IconButton(
                onPressed: () => _openEditor(),
                icon: SIcon(SardIcons.add_circle_outline, size: 24, color: p.accent),
                tooltip: 'إعلان جديد',
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${list.length} إعلان · ${repo.announcements.where((a) => a.isLive).length} نشط الآن',
                        style: context.ts(size: 12.5, color: p.textDim),
                      ),
                    ),
                    FilterChip(
                      label: Text('النشطة فقط', style: context.ts(size: 12.5, w: FontWeight.w700, color: _onlyLive ? Colors.white : p.text)),
                      selected: _onlyLive,
                      onSelected: (v) => setState(() => _onlyLive = v),
                      selectedColor: kAdminGreen,
                      backgroundColor: p.surface,
                      showCheckmark: false,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: list.isEmpty
                    ? AdminEmptyState(
                        icon: SardIcons.campaign_rounded,
                        title: 'لا إعلانات',
                        message: 'أنشئ أول إعلان ليظهر للمستخدمين في التطبيق.',
                        actionLabel: 'إعلان جديد',
                        onAction: () => _openEditor(),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: list.length,
                        itemBuilder: (context, i) {
                          final a = list[i];
                          return _AnnouncementCard(
                            announcement: a,
                            onTap: () => _openEditor(a),
                            onDelete: () => _delete(a),
                            onToggle: (v) async {
                              final res = await repo.toggleAnnouncement(a.id, v);
                              if (context.mounted) {
                                showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openEditor(),
            backgroundColor: p.accent,
            foregroundColor: p.onAccent,
            icon: const SIcon(SardIcons.add_circle_outline, size: 20),
            label: Text('إعلان جديد', style: context.ts(size: 13.5, w: FontWeight.w800, color: p.onAccent)),
          ),
        );
      },
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  const _AnnouncementCard({
    required this.announcement,
    required this.onTap,
    required this.onDelete,
    required this.onToggle,
  });

  final AdminAnnouncement announcement;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  final ValueChanged<bool> onToggle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final a = announcement;
    final liveColor = a.isLive
        ? kAdminGreen
        : (a.statusLabel == 'مجدول' ? kAdminBlue : p.textDim);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: tint(kAdminGreen, 0.13),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: const SIcon(SardIcons.campaign_rounded, size: 17, color: kAdminGreen),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(a.title, style: context.ts(size: 14.5, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                    AdminStatusBadge(label: a.statusLabel, color: liveColor),
                  ],
                ),
                const SizedBox(height: 8),
                Text(a.body, style: context.ts(size: 13, color: p.textDim), maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 8),
                Row(
                  children: [
                    SIcon(SardIcons.groups_rounded, size: 14, color: p.textDim),
                    const SizedBox(width: 4),
                    Text(a.target.label, style: context.ts(size: 12, color: p.textDim)),
                    const SizedBox(width: 12),
                    SIcon(SardIcons.visibility_rounded, size: 14, color: p.textDim),
                    const SizedBox(width: 4),
                    Text('${a.views} مشاهدة', style: context.ts(size: 12, color: p.textDim)),
                    const SizedBox(width: 12),
                    SIcon(SardIcons.history_rounded, size: 14, color: p.textDim),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        timeAgoArabic(a.createdAt),
                        style: context.ts(size: 12, color: p.textDim),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Switch(
                      value: a.active,
                      onChanged: onToggle,
                      activeThumbColor: p.accent,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    IconButton(
                      onPressed: onDelete,
                      icon: SIcon(SardIcons.delete_outline_rounded, size: 19, color: kAdminRed),
                      tooltip: 'حذف الإعلان',
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// محرر إعلان مع معاينة حيّة.
class AdminAnnouncementEditorScreen extends StatefulWidget {
  const AdminAnnouncementEditorScreen({super.key, this.announcement});

  final AdminAnnouncement? announcement;

  @override
  State<AdminAnnouncementEditorScreen> createState() => _AdminAnnouncementEditorScreenState();
}

class _AdminAnnouncementEditorScreenState extends State<AdminAnnouncementEditorScreen> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _bodyCtrl;
  late AdminAnnouncementTarget _target;
  late int _priority;
  late bool _active;
  DateTime? _publishAt;
  DateTime? _expiresAt;
  bool _busy = false;

  bool get _isNew => widget.announcement == null;

  @override
  void initState() {
    super.initState();
    final a = widget.announcement;
    _titleCtrl = TextEditingController(text: a?.title ?? '');
    _bodyCtrl = TextEditingController(text: a?.body ?? '');
    _target = a?.target ?? AdminAnnouncementTarget.all;
    _priority = a?.priority ?? 0;
    _active = a?.active ?? true;
    _publishAt = a?.publishAt;
    _expiresAt = a?.expiresAt;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  Future<DateTime?> _pickDateTime(DateTime? initial, String help) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial ?? DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      helpText: help,
      cancelText: 'إلغاء',
      confirmText: 'تأكيد',
    );
    if (picked == null) return null;
    final time = await showTimePicker(
      context: context,
      initialTime: initial == null
          ? const TimeOfDay(hour: 12, minute: 0)
          : TimeOfDay(hour: initial.hour, minute: initial.minute),
      helpText: help,
      cancelText: 'إلغاء',
      confirmText: 'تأكيد',
    );
    if (time == null || !mounted) return null;
    return DateTime(picked.year, picked.month, picked.day, time.hour, time.minute);
  }

  Future<void> _save() async {
    if (_busy) return;
    final base = widget.announcement ??
        AdminAnnouncement(
          id: 'an_${DateTime.now().millisecondsSinceEpoch}',
          title: '',
          body: '',
          target: AdminAnnouncementTarget.all,
          createdAt: DateTime.now(),
          active: true,
        );
    final next = base.copyWith(
      title: _titleCtrl.text.trim(),
      body: _bodyCtrl.text.trim(),
      target: _target,
      priority: _priority,
      active: _active,
      publishAt: _publishAt,
      clearPublishAt: _publishAt == null,
      expiresAt: _expiresAt,
      clearExpiresAt: _expiresAt == null,
    );
    final err = next.validate();
    if (err != null) {
      showAdminSnack(context, err, isError: true);
      return;
    }
    setState(() => _busy = true);
    final res = _isNew
        ? await AdminRepository.i.addAnnouncement(next)
        : await AdminRepository.i.updateAnnouncement(next);
    if (!mounted) return;
    setState(() => _busy = false);
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
    if (res.isOk && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text(_isNew ? 'إعلان جديد' : 'تعديل الإعلان', style: context.ds(size: 19)),
        actions: [
          TextButton(
            onPressed: _busy ? null : _save,
            child: Text('حفظ', style: context.ts(size: 14.5, w: FontWeight.w800, color: p.accent)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          const AdminDemoBanner(compact: true),
          const SizedBox(height: 14),
          _AnnField(
            controller: _titleCtrl,
            label: 'عنوان الإعلان *',
            hint: 'مثال: تحديث كبير قادم',
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          _AnnField(
            controller: _bodyCtrl,
            label: 'نص الإعلان *',
            hint: 'اكتب رسالة واضحة ومختصرة للمستخدمين…',
            maxLines: 5,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          Text('الجمهور المستهدف', style: context.ts(size: 13, w: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: AdminAnnouncementTarget.values.map((t) {
              final selected = _target == t;
              return ChoiceChip(
                label: Text(t.label, style: context.ts(size: 12.5, w: FontWeight.w700, color: selected ? Colors.white : p.text)),
                selected: selected,
                onSelected: (_) => setState(() => _target = t),
                selectedColor: p.accent,
                backgroundColor: p.surface,
                side: BorderSide(color: selected ? p.accent : p.border, width: p.borderW),
                showCheckmark: false,
              );
            }).toList(),
          ),
          const SizedBox(height: 4),
          Text(_target.hint, style: context.ts(size: 12, color: p.textDim)),
          const SizedBox(height: 14),
          Text('الأولوية', style: context.ts(size: 13, w: FontWeight.w700)),
          Row(
            children: [
              Expanded(
                child: Slider(
                  value: _priority.toDouble(),
                  min: 0,
                  max: 3,
                  divisions: 3,
                  label: '$_priority',
                  activeColor: p.accent,
                  onChanged: (v) => setState(() => _priority = v.round()),
                ),
              ),
              Text(
                switch (_priority) {
                  0 => 'عادية',
                  1 => 'مهمة',
                  2 => 'مهمة جداً',
                  _ => 'عاجلة',
                },
                style: context.ts(size: 13, w: FontWeight.w800, color: p.accent),
              ),
            ],
          ),
          const SizedBox(height: 6),
          _DateRow(
            label: 'موعد النشر',
            value: _publishAt,
            onPick: () async {
              final d = await _pickDateTime(_publishAt, 'اختر موعد النشر');
              if (d != null) setState(() => _publishAt = d);
            },
            onClear: () => setState(() => _publishAt = null),
          ),
          const SizedBox(height: 10),
          _DateRow(
            label: 'تاريخ الانتهاء',
            value: _expiresAt,
            onPick: () async {
              final d = await _pickDateTime(_expiresAt, 'اختر تاريخ الانتهاء');
              if (d != null) setState(() => _expiresAt = d);
            },
            onClear: () => setState(() => _expiresAt = null),
          ),
          SwitchListTile(
            value: _active,
            onChanged: (v) => setState(() => _active = v),
            title: Text('الإعلان مفعّل', style: context.ts(size: 14, w: FontWeight.w700)),
            subtitle: Text('الإعلان المتوقف لا يظهر لأحد', style: context.ts(size: 12, color: p.textDim)),
            contentPadding: EdgeInsets.zero,
            activeThumbColor: p.accent,
          ),
          AdminSectionTitle(
            title: 'معاينة حيّة',
            subtitle: 'هكذا سيرى المستخدمون الإعلان',
            icon: SardIcons.visibility_rounded,
          ),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: tint(kAdminGreen, 0.13),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const SIcon(SardIcons.campaign_rounded, size: 18, color: kAdminGreen),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _titleCtrl.text.trim().isEmpty ? 'عنوان الإعلان' : _titleCtrl.text.trim(),
                        style: context.ts(size: 14, w: FontWeight.w800),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        _bodyCtrl.text.trim().isEmpty ? 'نص الإعلان يظهر هنا…' : _bodyCtrl.text.trim(),
                        style: context.ts(size: 13, color: p.textDim),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'لـ: ${_target.label} · الأولوية: $_priority · ${_active ? 'مفعّل' : 'متوقف'}',
                        style: context.ts(size: 11.5, color: p.textDim),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _busy ? null : _save,
              style: FilledButton.styleFrom(
                backgroundColor: p.accent,
                foregroundColor: p.onAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(_isNew ? 'نشر الإعلان' : 'حفظ التعديلات', style: context.ts(size: 15, w: FontWeight.w800, color: p.onAccent)),
            ),
          ),
        ],
      ),
    );
  }
}

class _AnnField extends StatelessWidget {
  const _AnnField({
    required this.controller,
    required this.label,
    required this.hint,
    this.maxLines = 1,
    this.onChanged,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final int maxLines;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13, w: FontWeight.w700)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          maxLines: maxLines,
          onChanged: onChanged,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13.5, color: p.textDim),
            filled: true,
            fillColor: p.surface,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.accent, width: 1.6),
            ),
          ),
        ),
      ],
    );
  }
}

class _DateRow extends StatelessWidget {
  const _DateRow({
    required this.label,
    required this.value,
    required this.onPick,
    required this.onClear,
  });

  final String label;
  final DateTime? value;
  final VoidCallback onPick;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Material(
      color: p.surface,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onPick,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: p.border, width: p.borderW),
          ),
          child: Row(
            children: [
              SIcon(SardIcons.calendar_today_rounded, size: 18, color: p.textDim),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: context.ts(size: 12, color: p.textDim)),
                    const SizedBox(height: 2),
                    Text(
                      value == null ? 'فوري (بدون جدولة)' : formatSardDateTime(value!),
                      style: context.ts(size: 13.5, w: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              if (value != null)
                TextButton(
                  onPressed: onClear,
                  child: Text('إلغاء', style: context.ts(size: 12.5, w: FontWeight.w700, color: kAdminRed)),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
