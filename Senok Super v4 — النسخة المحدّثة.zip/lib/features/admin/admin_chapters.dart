import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// إدارة الفصول — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// قائمة فصول عمل (أو اختيار العمل أولاً)، مع محرر فصل كامل: رقم، عنوان،
/// روابط صفحات، حالة (مسودة/مجدول/منشور/مخفي)، وجدولة نشر بتاريخ وساعة.
/// الفصول المجدولة التي حان وقتها تُنشر تلقائياً عند فتح لوحة الأدمن.
/// ──────────────────────────────────────────────────────────────────────────

class AdminChaptersScreen extends StatefulWidget {
  const AdminChaptersScreen({super.key, this.series});

  final AdminSeries? series;

  @override
  State<AdminChaptersScreen> createState() => _AdminChaptersScreenState();
}

class _AdminChaptersScreenState extends State<AdminChaptersScreen> {
  AdminSeries? _series;
  AdminChapterFilter _filter = const AdminChapterFilter();
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _series = widget.series;
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _openEditor([AdminChapter? chapter]) {
    final s = _series;
    if (s == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AdminChapterEditorScreen(series: s, chapter: chapter),
      ),
    );
  }

  Future<void> _delete(AdminChapter c) async {
    final ok = await showAdminConfirm(
      context,
      title: 'حذف الفصل',
      message: 'سيُحذف ${c.displayTitle} نهائياً. لا يمكن التراجع.',
      confirmLabel: 'حذف',
      destructive: true,
    );
    if (!ok) return;
    final res = await AdminRepository.i.deleteChapter(c.id);
    if (!mounted) return;
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
  }

  Future<void> _setStatus(AdminChapter c, AdminChapterStatus status) async {
    DateTime? publishAt;
    if (status == AdminChapterStatus.scheduled) {
      final picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now().add(const Duration(days: 1)),
        firstDate: DateTime.now(),
        lastDate: DateTime.now().add(const Duration(days: 365)),
        helpText: 'اختر تاريخ النشر',
        cancelText: 'إلغاء',
        confirmText: 'تأكيد',
      );
      if (picked == null) return;
      final time = await showTimePicker(
        context: context,
        initialTime: const TimeOfDay(hour: 12, minute: 0),
        helpText: 'اختر ساعة النشر',
        cancelText: 'إلغاء',
        confirmText: 'تأكيد',
      );
      if (time == null || !mounted) return;
      publishAt = DateTime(picked.year, picked.month, picked.day, time.hour, time.minute);
    }
    final res = await AdminRepository.i.setChapterStatus(c.id, status, publishAt: publishAt);
    if (!mounted) return;
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final series = _series;
        if (series == null) {
          final all = repo.series;
          return Scaffold(
            backgroundColor: p.bg,
            appBar: AppBar(
              backgroundColor: p.bg,
              elevation: 0,
              title: Text('إدارة الفصول', style: context.ds(size: 19)),
            ),
            body: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                const AdminDemoBanner(compact: true),
                AdminSectionTitle(
                  title: 'اختر العمل',
                  subtitle: 'لعرض فصوله وإدارتها',
                  icon: SardIcons.menu_book_rounded,
                ),
                if (all.isEmpty)
                  const AdminEmptyState(
                    icon: SardIcons.menu_book_rounded,
                    title: 'لا أعمال بعد',
                    message: 'أضف عملاً أولاً من إدارة الأعمال.',
                  )
                else
                  ...all.map((s) {
                    final count = repo.chaptersOf(s.id).length;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Material(
                        color: p.surface,
                        borderRadius: BorderRadius.circular(p.r(0.7)),
                        child: InkWell(
                          onTap: () => setState(() => _series = s),
                          borderRadius: BorderRadius.circular(p.r(0.7)),
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(p.r(0.7)),
                              border: Border.all(color: p.border, width: p.borderW),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 44,
                                  height: 56,
                                  decoration: BoxDecoration(
                                    color: tint(p.accent, 0.14),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    s.title.isEmpty ? '؟' : s.title[0],
                                    style: context.ds(size: 20, color: p.accent),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(s.title, style: context.ts(size: 14.5, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                                      const SizedBox(height: 2),
                                      Text('$count فصلاً · ${s.typeShort}', style: context.ts(size: 12, color: p.textDim)),
                                    ],
                                  ),
                                ),
                                SIcon(SardIcons.chevron_left_rounded, size: 20, color: p.textDim),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
              ],
            ),
          );
        }

        final list = repo.chaptersOf(series.id, filter: _filter);
        final due = repo.chaptersOf(series.id).where((c) => c.scheduleDue).length;
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('فصول «${adminEllipsis(series.title, 18)}»', style: context.ds(size: 18)),
            actions: [
              IconButton(
                onPressed: () => _openEditor(),
                icon: SIcon(SardIcons.add_circle_outline, size: 24, color: p.accent),
                tooltip: 'إضافة فصل',
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: AdminSearchField(
                  controller: _searchCtrl,
                  hint: 'ابحث برقم الفصل أو عنوانه…',
                  onChanged: (v) => setState(() => _filter = _filter.copyWith(query: v)),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    AdminChip(
                      label: 'الكل',
                      selected: _filter.status == null && !_filter.onlyDue,
                      onTap: () => setState(() => _filter = AdminChapterFilter(query: _filter.query)),
                    ),
                    const SizedBox(width: 8),
                    for (final st in AdminChapterStatus.values) ...[
                      AdminChip(
                        label: st.label,
                        selected: _filter.status == st,
                        onTap: () => setState(() => _filter = _filter.copyWith(
                          status: _filter.status == st ? null : st,
                        )),
                      ),
                      const SizedBox(width: 8),
                    ],
                    AdminChip(
                      label: 'حان وقتها',
                      selected: _filter.onlyDue,
                      count: due,
                      onTap: () => setState(() => _filter = _filter.copyWith(onlyDue: !_filter.onlyDue)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text('${list.length} فصل', style: context.ts(size: 12.5, color: p.textDim)),
                    const Spacer(),
                    if (due > 0)
                      Text(
                        '$due فصل حان وقت نشرها',
                        style: context.ts(size: 12.5, w: FontWeight.w700, color: kAdminAmber),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? AdminEmptyState(
                        icon: SardIcons.chrome_reader_mode_rounded,
                        title: 'لا فصول مطابقة',
                        message: 'أضف أول فصل لهذا العمل من زر الإضافة.',
                        actionLabel: 'إضافة فصل',
                        onAction: () => _openEditor(),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: list.length,
                        itemBuilder: (context, i) {
                          final c = list[i];
                          return _ChapterTile(
                            chapter: c,
                            onTap: () => _openEditor(c),
                            onDelete: () => _delete(c),
                            onSetStatus: (s) => _setStatus(c, s),
                          );
                        },
                      ),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openEditor(),
            backgroundColor: p.accent,
            foregroundColor: p.onAccent,
            icon: const SIcon(SardIcons.add_circle_outline, size: 20),
            label: Text('فصل جديد', style: context.ts(size: 13.5, w: FontWeight.w800, color: p.onAccent)),
          ),
        );
      },
    );
  }
}

class _ChapterTile extends StatelessWidget {
  const _ChapterTile({
    required this.chapter,
    required this.onTap,
    required this.onDelete,
    required this.onSetStatus,
  });

  final AdminChapter chapter;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  final ValueChanged<AdminChapterStatus> onSetStatus;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = chapter;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: tint(chapterStatusColor(c.status), 0.13),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '${c.number}',
                    style: context.ds(size: 16, color: chapterStatusColor(c.status)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(c.displayTitle, style: context.ts(size: 14, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 3),
                      Text(
                        '${c.pageCount} صفحة · ${formatCount(c.views)} مشاهدة',
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                      if (c.status == AdminChapterStatus.scheduled && c.publishAt != null) ...[
                        const SizedBox(height: 3),
                        Text(
                          c.scheduleDue
                              ? 'حان وقت النشر — سيُنشر تلقائياً'
                              : 'مجدول: ${formatSardDateTime(c.publishAt!)}',
                          style: context.ts(
                            size: 12,
                            w: FontWeight.w700,
                            color: c.scheduleDue ? kAdminAmber : kAdminBlue,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    AdminStatusBadge(label: c.status.label, color: chapterStatusColor(c.status)),
                    const SizedBox(height: 6),
                    PopupMenuButton<String>(
                      onSelected: (v) {
                        switch (v) {
                          case 'publish':
                            onSetStatus(AdminChapterStatus.published);
                          case 'schedule':
                            onSetStatus(AdminChapterStatus.scheduled);
                          case 'hide':
                            onSetStatus(AdminChapterStatus.hidden);
                          case 'draft':
                            onSetStatus(AdminChapterStatus.draft);
                          case 'delete':
                            onDelete();
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'publish', child: Text('نشر الآن')),
                        PopupMenuItem(value: 'schedule', child: Text('جدولة النشر…')),
                        PopupMenuItem(value: 'hide', child: Text('إخفاء')),
                        PopupMenuItem(value: 'draft', child: Text('إعادة لمسودة')),
                        PopupMenuItem(value: 'delete', child: Text('حذف الفصل')),
                      ],
                      icon: SIcon(SardIcons.menu_rounded, size: 20, color: p.textDim),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// محرر فصل: إضافة جديدة أو تعديل موجود.
class AdminChapterEditorScreen extends StatefulWidget {
  const AdminChapterEditorScreen({super.key, required this.series, this.chapter});

  final AdminSeries series;
  final AdminChapter? chapter;

  @override
  State<AdminChapterEditorScreen> createState() => _AdminChapterEditorScreenState();
}

class _AdminChapterEditorScreenState extends State<AdminChapterEditorScreen> {
  late final TextEditingController _numberCtrl;
  late final TextEditingController _titleCtrl;
  late List<TextEditingController> _pageCtrls;
  late AdminChapterStatus _status;
  DateTime? _publishAt;
  bool _busy = false;

  bool get _isNew => widget.chapter == null;

  @override
  void initState() {
    super.initState();
    final c = widget.chapter;
    _numberCtrl = TextEditingController(
      text: '${c?.number ?? AdminRepository.i.nextChapterNumber(widget.series.id)}',
    );
    _titleCtrl = TextEditingController(text: c?.title ?? '');
    _pageCtrls = (c?.pages ?? const <String>[]).map((p) => TextEditingController(text: p)).toList();
    _status = c?.status ?? AdminChapterStatus.draft;
    _publishAt = c?.publishAt;
  }

  @override
  void dispose() {
    _numberCtrl.dispose();
    _titleCtrl.dispose();
    for (final c in _pageCtrls) {
      c.dispose();
    }
    super.dispose();
  }

  List<String> get _pages => _pageCtrls.map((c) => c.text.trim()).where((t) => t.isNotEmpty).toList();

  Future<void> _pickSchedule() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _publishAt ?? DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      helpText: 'اختر تاريخ النشر',
      cancelText: 'إلغاء',
      confirmText: 'تأكيد',
    );
    if (picked == null) return;
    final time = await showTimePicker(
      context: context,
      initialTime: _publishAt == null
          ? const TimeOfDay(hour: 12, minute: 0)
          : TimeOfDay(hour: _publishAt!.hour, minute: _publishAt!.minute),
      helpText: 'اختر ساعة النشر',
      cancelText: 'إلغاء',
      confirmText: 'تأكيد',
    );
    if (time == null || !mounted) return;
    setState(() => _publishAt = DateTime(picked.year, picked.month, picked.day, time.hour, time.minute));
  }

  Future<void> _save() async {
    if (_busy) return;
    final number = int.tryParse(_numberCtrl.text.trim()) ?? 0;
    final base = widget.chapter ??
        AdminChapter.blank(seriesId: widget.series.id, number: number);
    final next = base.copyWith(
      number: number,
      title: _titleCtrl.text.trim(),
      pages: _pages,
      status: _status,
      publishAt: _status == AdminChapterStatus.scheduled ? _publishAt : null,
      clearPublishAt: _status != AdminChapterStatus.scheduled,
    );
    final err = next.validate();
    if (err != null) {
      showAdminSnack(context, err, isError: true);
      return;
    }
    setState(() => _busy = true);
    final res = _isNew
        ? await AdminRepository.i.addChapter(next)
        : await AdminRepository.i.updateChapter(next);
    if (!mounted) return;
    setState(() => _busy = false);
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
    if (res.isOk && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text(_isNew ? 'فصل جديد' : 'تعديل الفصل', style: context.ds(size: 19)),
        actions: [
          TextButton(
            onPressed: _busy ? null : _save,
            child: Text('حفظ', style: context.ts(size: 14.5, w: FontWeight.w800, color: p.accent)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          const AdminDemoBanner(compact: true),
          const SizedBox(height: 14),
          Text('العمل: ${widget.series.title}', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.accent)),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _ChapterField(
                  controller: _numberCtrl,
                  label: 'رقم الفصل *',
                  hint: '1',
                  keyboardType: TextInputType.number,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 5,
                child: _ChapterField(
                  controller: _titleCtrl,
                  label: 'عنوان الفصل (اختياري)',
                  hint: 'مثال: البداية',
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'عند غياب العنوان يظهر «الفصل ${_numberCtrl.text.trim().isEmpty ? '؟' : _numberCtrl.text.trim()}» كما في: ${_titleCtrl.text.trim().isEmpty ? 'الفصل ${_numberCtrl.text.trim().isEmpty ? '؟' : _numberCtrl.text.trim()}' : 'الفصل ${_numberCtrl.text.trim()}: ${_titleCtrl.text.trim()}'}',
            style: context.ts(size: 12, color: p.textDim),
          ),
          const SizedBox(height: 14),
          Text('حالة الفصل', style: context.ts(size: 13, w: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: AdminChapterStatus.values.map((st) {
              final selected = _status == st;
              return ChoiceChip(
                label: Text(st.label, style: context.ts(size: 12.5, w: FontWeight.w700, color: selected ? Colors.white : p.text)),
                selected: selected,
                onSelected: (_) => setState(() {
                  _status = st;
                  if (st != AdminChapterStatus.scheduled) _publishAt = null;
                }),
                selectedColor: chapterStatusColor(st),
                backgroundColor: p.surface,
                side: BorderSide(color: selected ? chapterStatusColor(st) : p.border, width: p.borderW),
                showCheckmark: false,
              );
            }).toList(),
          ),
          if (_status == AdminChapterStatus.scheduled) ...[
            const SizedBox(height: 12),
            Material(
              color: tint(kAdminBlue, 0.1),
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                onTap: _pickSchedule,
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: tint(kAdminBlue, 0.4)),
                  ),
                  child: Row(
                    children: [
                      const SIcon(SardIcons.watch_later_rounded, size: 20, color: kAdminBlue),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _publishAt == null
                              ? 'اختر تاريخ وساعة النشر…'
                              : 'موعد النشر: ${formatSardDateTime(_publishAt!)}',
                          style: context.ts(size: 13.5, w: FontWeight.w700, color: kAdminBlue),
                        ),
                      ),
                      SIcon(SardIcons.calendar_today_rounded, size: 18, color: p.textDim),
                    ],
                  ),
                ),
              ),
            ),
          ],
          AdminSectionTitle(
            title: 'روابط الصفحات',
            subtitle: 'بالترتيب، كل رابط في سطر — يجب أن تبدأ بـ https',
            icon: SardIcons.format_list_bulleted_rounded,
            count: _pageCtrls.length,
          ),
          if (_pageCtrls.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: p.border, width: p.borderW),
              ),
              child: Text(
                'لا صفحات بعد. أضف روابط الصفحات بالترتيب.',
                style: context.ts(size: 13, color: p.textDim),
                textAlign: TextAlign.center,
              ),
            )
          else
            ...List.generate(_pageCtrls.length, (i) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: tint(p.accent, 0.12),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      alignment: Alignment.center,
                      child: Text('${i + 1}', style: context.ts(size: 13, w: FontWeight.w800, color: p.accent)),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _pageCtrls[i],
                        style: context.ts(size: 13),
                        decoration: InputDecoration(
                          hintText: 'https://…/p${i + 1}.jpg',
                          hintStyle: context.ts(size: 12.5, color: p.textDim),
                          filled: true,
                          fillColor: p.surface,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: p.border, width: p.borderW),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: p.border, width: p.borderW),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: p.accent, width: 1.6),
                          ),
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => setState(() {
                        _pageCtrls[i].dispose();
                        _pageCtrls.removeAt(i);
                      }),
                      icon: SIcon(SardIcons.delete_outline_rounded, size: 20, color: kAdminRed),
                      tooltip: 'حذف الصفحة',
                    ),
                  ],
                ),
              );
            }),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => setState(() => _pageCtrls.add(TextEditingController())),
                  icon: const SIcon(SardIcons.add_circle_outline, size: 18),
                  label: Text('إضافة صفحة', style: context.ts(size: 13, w: FontWeight.w700)),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    side: BorderSide(color: p.border),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final base = _pageCtrls.isEmpty ? 1 : _pageCtrls.length + 1;
                    setState(() {
                      for (var k = 0; k < 5; k++) {
                        _pageCtrls.add(TextEditingController(
                          text: 'https://example.com/${widget.series.id}/${_numberCtrl.text.trim().isEmpty ? '1' : _numberCtrl.text.trim()}/p${base + k}.jpg',
                        ));
                      }
                    });
                  },
                  icon: const SIcon(SardIcons.playlist_add_rounded, size: 18),
                  label: Text('إضافة 5 صفحات', style: context.ts(size: 13, w: FontWeight.w700)),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    side: BorderSide(color: p.border),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _busy ? null : _save,
              style: FilledButton.styleFrom(
                backgroundColor: p.accent,
                foregroundColor: p.onAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(_isNew ? 'إضافة الفصل' : 'حفظ التعديلات', style: context.ts(size: 15, w: FontWeight.w800, color: p.onAccent)),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChapterField extends StatelessWidget {
  const _ChapterField({
    required this.controller,
    required this.label,
    required this.hint,
    this.keyboardType,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13, w: FontWeight.w700)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13.5, color: p.textDim),
            filled: true,
            fillColor: p.surface,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.accent, width: 1.6),
            ),
          ),
        ),
      ],
    );
  }
}
