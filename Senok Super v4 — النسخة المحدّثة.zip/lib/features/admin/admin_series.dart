import 'package:flutter/material.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_chapters.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// إدارة الأعمال (السلاسل) — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// قائمة بحث وفلترة وترتيب، مع محرر كامل للعمل (عنوان، نوع، حالة، تصنيفات،
/// غلاف، ملخص، سنة، تثبيت في الواجهة، «جديد»).
/// ──────────────────────────────────────────────────────────────────────────

const List<String> kAdminSeriesTypes = [
  'مانهوا كورية',
  'مانغا يابانية',
  'مانهوا صينية',
  'كوميك غربي',
  'رواية مصورة',
];

const List<String> kAdminGenres = [
  'أكشن',
  'مغامرات',
  'فانتازيا',
  'رومانسي',
  'دراما',
  'كوميديا',
  'غموض',
  'رعب',
  'خيال علمي',
  'تاريخي',
  'رياضي',
  'شريحة حياة',
  'إثارة',
  'انتقام',
];

class AdminSeriesScreen extends StatefulWidget {
  const AdminSeriesScreen({super.key});

  @override
  State<AdminSeriesScreen> createState() => _AdminSeriesScreenState();
}

class _AdminSeriesScreenState extends State<AdminSeriesScreen> {
  final _searchCtrl = TextEditingController();
  AdminSeriesFilter _filter = const AdminSeriesFilter();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _openEditor([AdminSeries? series]) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AdminSeriesEditorScreen(series: series)),
    );
  }

  void _openChapters(AdminSeries series) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AdminChaptersScreen(series: series)),
    );
  }

  Future<void> _delete(AdminSeries s) async {
    final ok = await showAdminConfirm(
      context,
      title: 'حذف العمل',
      message: 'سيُحذف «${s.title}» نهائياً مع كل فصوله. لا يمكن التراجع.',
      confirmLabel: 'حذف',
      destructive: true,
    );
    if (!ok) return;
    final res = await AdminRepository.i.deleteSeries(s.id);
    if (!mounted) return;
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final list = repo.searchSeries(_filter);
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('إدارة الأعمال', style: context.ds(size: 19)),
            actions: [
              IconButton(
                onPressed: () => _openEditor(),
                icon: SIcon(SardIcons.add_circle_outline, size: 24, color: p.accent),
                tooltip: 'إضافة عمل',
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: AdminSearchField(
                  controller: _searchCtrl,
                  hint: 'ابحث بالعنوان أو التصنيف…',
                  onChanged: (v) => setState(() => _filter = _filter.copyWith(query: v)),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    AdminChip(
                      label: 'الكل',
                      selected: _filter.state == null && _filter.type == null && !_filter.onlyFeatured && !_filter.onlyNew,
                      onTap: () => setState(() => _filter = AdminSeriesFilter(query: _filter.query, sort: _filter.sort)),
                    ),
                    const SizedBox(width: 8),
                    AdminChip(
                      label: 'مستمر',
                      selected: _filter.state == AdminSeriesState.ongoing,
                      onTap: () => setState(() => _filter = _filter.copyWith(
                        state: _filter.state == AdminSeriesState.ongoing ? null : AdminSeriesState.ongoing,
                      )),
                    ),
                    const SizedBox(width: 8),
                    AdminChip(
                      label: 'مكتمل',
                      selected: _filter.state == AdminSeriesState.completed,
                      onTap: () => setState(() => _filter = _filter.copyWith(
                        state: _filter.state == AdminSeriesState.completed ? null : AdminSeriesState.completed,
                      )),
                    ),
                    const SizedBox(width: 8),
                    AdminChip(
                      label: 'مثبّت',
                      selected: _filter.onlyFeatured,
                      onTap: () => setState(() => _filter = _filter.copyWith(onlyFeatured: !_filter.onlyFeatured)),
                    ),
                    const SizedBox(width: 8),
                    AdminChip(
                      label: 'جديد',
                      selected: _filter.onlyNew,
                      onTap: () => setState(() => _filter = _filter.copyWith(onlyNew: !_filter.onlyNew)),
                    ),
                    const SizedBox(width: 8),
                    PopupMenuButton<AdminSeriesSort>(
                      onSelected: (s) => setState(() => _filter = _filter.copyWith(sort: s)),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: AdminSeriesSort.newest, child: Text('الأحدث')),
                        PopupMenuItem(value: AdminSeriesSort.title, child: Text('العنوان')),
                        PopupMenuItem(value: AdminSeriesSort.views, child: Text('الأكثر مشاهدة')),
                        PopupMenuItem(value: AdminSeriesSort.rating, child: Text('الأعلى تقييماً')),
                        PopupMenuItem(value: AdminSeriesSort.chapters, child: Text('الأكثر فصولاً')),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: p.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: p.border, width: p.borderW),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SIcon(SardIcons.swap_vert_rounded, size: 16, color: p.textDim),
                            const SizedBox(width: 4),
                            Text(
                              switch (_filter.sort) {
                                AdminSeriesSort.newest => 'الأحدث',
                                AdminSeriesSort.title => 'العنوان',
                                AdminSeriesSort.views => 'المشاهدات',
                                AdminSeriesSort.rating => 'التقييم',
                                AdminSeriesSort.chapters => 'الفصول',
                              },
                              style: context.ts(size: 12.5, w: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text('${list.length} عمل', style: context.ts(size: 12.5, color: p.textDim)),
                    const Spacer(),
                    if (!_filter.isEmpty)
                      TextButton(
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() => _filter = const AdminSeriesFilter());
                        },
                        child: Text('مسح الفلاتر', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.accent)),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? AdminEmptyState(
                        icon: SardIcons.menu_book_rounded,
                        title: 'لا أعمال مطابقة',
                        message: _filter.isEmpty
                            ? 'لا توجد أعمال بعد. أضف أول عمل من زر الإضافة.'
                            : 'جرّب كلمة بحث أخرى أو امسح الفلاتر.',
                        actionLabel: 'إضافة عمل',
                        onAction: () => _openEditor(),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: list.length,
                        itemBuilder: (context, i) {
                          final s = list[i];
                          return _SeriesTile(
                            series: s,
                            onTap: () => _openEditor(s),
                            onChapters: () => _openChapters(s),
                            onDelete: () => _delete(s),
                            onDuplicate: () async {
                              final res = await repo.duplicateSeries(s.id);
                              if (context.mounted) {
                                showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
                              }
                            },
                            onToggleFeatured: () async {
                              final res = await repo.setSeriesFeatured(s.id, !s.featured);
                              if (context.mounted) {
                                showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openEditor(),
            backgroundColor: p.accent,
            foregroundColor: p.onAccent,
            icon: const SIcon(SardIcons.add_circle_outline, size: 20),
            label: Text('عمل جديد', style: context.ts(size: 13.5, w: FontWeight.w800, color: p.onAccent)),
          ),
        );
      },
    );
  }
}

class _SeriesTile extends StatelessWidget {
  const _SeriesTile({
    required this.series,
    required this.onTap,
    required this.onChapters,
    required this.onDelete,
    required this.onToggleFeatured,
    required this.onDuplicate,
  });

  final AdminSeries series;
  final VoidCallback onTap;
  final VoidCallback onChapters;
  final VoidCallback onDelete;
  final VoidCallback onToggleFeatured;
  final VoidCallback onDuplicate;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 68,
                  decoration: BoxDecoration(
                    color: tint(p.accent, 0.14),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    series.title.isEmpty ? '؟' : series.title[0],
                    style: context.ds(size: 24, color: p.accent),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(series.title, style: context.ts(size: 14.5, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                          ),
                          if (series.featured) ...[
                            const SizedBox(width: 6),
                            const SIcon(SardIcons.star_rounded, size: 16, color: Color(0xFFE9B44C)),
                          ],
                          if (series.isNew) ...[
                            const SizedBox(width: 6),
                            AdminStatusBadge(label: 'جديد', color: kAdminGreen),
                          ],
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${series.typeShort} · ${series.state.label} · ${series.chapters} فصلاً',
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '★ ${series.rating.toStringAsFixed(1)} · ${formatCount(series.views)} مشاهدة · ${series.year}',
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                      if (series.genres.isNotEmpty) ...[
                        const SizedBox(height: 5),
                        Text(
                          series.genresLabel,
                          style: context.ts(size: 11.5, color: p.accent),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (v) {
                    switch (v) {
                      case 'chapters':
                        onChapters();
                      case 'featured':
                        onToggleFeatured();
                      case 'duplicate':
                        onDuplicate();
                      case 'delete':
                        onDelete();
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'chapters', child: Text('إدارة الفصول')),
                    PopupMenuItem(
                      value: 'featured',
                      child: Text(series.featured ? 'إزالة التثبيت' : 'تثبيت في الواجهة'),
                    ),
                    const PopupMenuItem(value: 'duplicate', child: Text('نسخ العمل')),
                    const PopupMenuItem(value: 'delete', child: Text('حذف العمل')),
                  ],
                  icon: SIcon(SardIcons.menu_rounded, size: 20, color: p.textDim),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// محرر عمل: إضافة جديدة أو تعديل موجود.
class AdminSeriesEditorScreen extends StatefulWidget {
  const AdminSeriesEditorScreen({super.key, this.series});

  final AdminSeries? series;

  @override
  State<AdminSeriesEditorScreen> createState() => _AdminSeriesEditorScreenState();
}

class _AdminSeriesEditorScreenState extends State<AdminSeriesEditorScreen> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _coverCtrl;
  late final TextEditingController _synopsisCtrl;
  late final TextEditingController _yearCtrl;
  late String _type;
  late String _status;
  late Set<String> _genres;
  late bool _isNew;
  late bool _featured;
  bool _busy = false;

  bool get _isNewSeries => widget.series == null;

  @override
  void initState() {
    super.initState();
    final s = widget.series;
    _titleCtrl = TextEditingController(text: s?.title ?? '');
    _coverCtrl = TextEditingController(text: s?.cover ?? '');
    _synopsisCtrl = TextEditingController(text: s?.synopsis ?? '');
    _yearCtrl = TextEditingController(text: '${s?.year ?? DateTime.now().year}');
    _type = s?.type ?? kAdminSeriesTypes.first;
    _status = s?.status ?? 'مستمر';
    _genres = Set<String>.from(s?.genres ?? const []);
    _isNew = s?.isNew ?? false;
    _featured = s?.featured ?? false;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _coverCtrl.dispose();
    _synopsisCtrl.dispose();
    _yearCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) return;
    final year = int.tryParse(_yearCtrl.text.trim());
    final base = widget.series ?? AdminSeries.blank();
    final next = base.copyWith(
      title: _titleCtrl.text.trim(),
      cover: _coverCtrl.text.trim().isEmpty ? null : _coverCtrl.text.trim(),
      clearCover: _coverCtrl.text.trim().isEmpty,
      type: _type,
      status: _status,
      genres: _genres.toList(),
      synopsis: _synopsisCtrl.text.trim(),
      year: year ?? base.year,
      isNew: _isNew,
      featured: _featured,
    );
    final err = next.validate();
    if (err != null) {
      showAdminSnack(context, err, isError: true);
      return;
    }
    setState(() => _busy = true);
    final res = _isNewSeries
        ? await AdminRepository.i.addSeries(next)
        : await AdminRepository.i.updateSeries(next);
    if (!mounted) return;
    setState(() => _busy = false);
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
    if (res.isOk && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text(_isNewSeries ? 'عمل جديد' : 'تعديل العمل', style: context.ds(size: 19)),
        actions: [
          TextButton(
            onPressed: _busy ? null : _save,
            child: Text('حفظ', style: context.ts(size: 14.5, w: FontWeight.w800, color: p.accent)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          const AdminDemoBanner(compact: true),
          const SizedBox(height: 14),
          _Field(
            controller: _titleCtrl,
            label: 'عنوان العمل *',
            hint: 'مثال: فارس الحبر الأخير',
          ),
          const SizedBox(height: 12),
          _Field(
            controller: _coverCtrl,
            label: 'رابط الغلاف',
            hint: 'https://… (اختياري)',
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _DropdownField<String>(
                  label: 'النوع',
                  value: _type,
                  items: kAdminSeriesTypes,
                  onChanged: (v) => setState(() => _type = v),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _DropdownField<String>(
                  label: 'الحالة',
                  value: _status,
                  items: const ['مستمر', 'مكتمل', 'متوقف'],
                  onChanged: (v) => setState(() => _status = v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _Field(
            controller: _yearCtrl,
            label: 'سنة النشر',
            hint: '${DateTime.now().year}',
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 12),
          Text('التصنيفات (حتى 8)', style: context.ts(size: 13, w: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: kAdminGenres.map((g) {
              final selected = _genres.contains(g);
              return FilterChip(
                label: Text(g, style: context.ts(size: 12.5, w: FontWeight.w700, color: selected ? p.onAccent : p.text)),
                selected: selected,
                onSelected: (v) => setState(() {
                  if (v) {
                    if (_genres.length < 8) _genres.add(g);
                  } else {
                    _genres.remove(g);
                  }
                }),
                selectedColor: p.accent,
                backgroundColor: p.surface,
                side: BorderSide(color: selected ? p.accent : p.border, width: p.borderW),
                showCheckmark: false,
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          _Field(
            controller: _synopsisCtrl,
            label: 'الملخص',
            hint: 'اكتب نبذة جذابة عن العمل…',
            maxLines: 5,
          ),
          const SizedBox(height: 12),
          SwitchListTile(
            value: _isNew,
            onChanged: (v) => setState(() => _isNew = v),
            title: Text('عمل جديد', style: context.ts(size: 14, w: FontWeight.w700)),
            subtitle: Text('يظهر بشارة «جديد» في التطبيق', style: context.ts(size: 12, color: p.textDim)),
            contentPadding: EdgeInsets.zero,
            activeThumbColor: p.accent,
          ),
          SwitchListTile(
            value: _featured,
            onChanged: (v) => setState(() => _featured = v),
            title: Text('تثبيت في الواجهة', style: context.ts(size: 14, w: FontWeight.w700)),
            subtitle: Text('يظهر في قسم الأعمال المميزة', style: context.ts(size: 12, color: p.textDim)),
            contentPadding: EdgeInsets.zero,
            activeThumbColor: p.accent,
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _busy ? null : _save,
              style: FilledButton.styleFrom(
                backgroundColor: p.accent,
                foregroundColor: p.onAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(_isNewSeries ? 'إضافة العمل' : 'حفظ التعديلات', style: context.ts(size: 15, w: FontWeight.w800, color: p.onAccent)),
            ),
          ),
          if (!_isNewSeries) ...[
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => AdminChaptersScreen(series: widget.series!)),
              ),
              icon: const SIcon(SardIcons.chrome_reader_mode_rounded, size: 18),
              label: Text('إدارة فصول هذا العمل', style: context.ts(size: 13.5, w: FontWeight.w700)),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                side: BorderSide(color: p.border),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _Field extends StatelessWidget {
  const _Field({
    required this.controller,
    required this.label,
    required this.hint,
    this.maxLines = 1,
    this.keyboardType,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final int maxLines;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13, w: FontWeight.w700)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          maxLines: maxLines,
          keyboardType: keyboardType,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13.5, color: p.textDim),
            filled: true,
            fillColor: p.surface,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.accent, width: 1.6),
            ),
          ),
        ),
      ],
    );
  }
}

class _DropdownField<T> extends StatelessWidget {
  const _DropdownField({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  final String label;
  final T value;
  final List<T> items;
  final ValueChanged<T> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13, w: FontWeight.w700)),
        const SizedBox(height: 6),
        DropdownButtonFormField<T>(
          initialValue: value,
          items: items
              .map((e) => DropdownMenuItem<T>(value: e, child: Text('$e', style: context.ts(size: 13.5))))
              .toList(),
          onChanged: (v) {
            if (v != null) onChanged(v);
          },
          decoration: InputDecoration(
            filled: true,
            fillColor: p.surface,
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: p.border, width: p.borderW),
            ),
          ),
          dropdownColor: p.surface,
        ),
      ],
    );
  }
}
