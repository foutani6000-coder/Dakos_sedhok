import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// التقارير والإحصاءات — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// نمو المشاهدات (رسم بياني شريطي لآخر 14 يوماً)، أفضل الأعمال والفصول،
/// توزيع الأعمال حسب النوع والحالة، والمستخدمين حسب الدور، والبلاغات حسب
/// السبب، مع تصدير نسخة JSON إلى الحافظة.
/// ──────────────────────────────────────────────────────────────────────────

class AdminReportsScreen extends StatelessWidget {
  const AdminReportsScreen({super.key});

  Future<void> _export(BuildContext context) async {
    final json = AdminRepository.i.exportAllJson();
    await Clipboard.setData(ClipboardData(text: json));
    if (context.mounted) {
      showAdminSnack(context, 'نُسخت نسخة JSON الاحتياطية إلى الحافظة (${(json.length / 1024).toStringAsFixed(1)} ك.ب).');
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final stats = repo.computeStats();
        final dayLabels = List<String>.generate(14, (i) {
          final d = DateTime.now().subtract(Duration(days: 13 - i));
          return '${d.day}/${d.month}';
        });
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('التقارير والإحصاءات', style: context.ds(size: 19)),
            actions: [
              IconButton(
                onPressed: () => _export(context),
                icon: SIcon(SardIcons.share_rounded, size: 22, color: p.accent),
                tooltip: 'تصدير نسخة JSON',
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
            children: [
              const AdminDemoBanner(compact: true),
              const SizedBox(height: 14),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.55,
                children: [
                  AdminStatCard(
                    label: 'إجمالي المشاهدات',
                    value: formatCount(stats.totalViews),
                    icon: SardIcons.visibility_rounded,
                    color: kAdminPurple,
                    sub: 'كل الأعمال',
                  ),
                  AdminStatCard(
                    label: 'فصول منشورة',
                    value: '${stats.publishedChapters}',
                    icon: SardIcons.chrome_reader_mode_rounded,
                    color: kAdminGreen,
                    sub: 'من ${stats.totalChapters} فصلاً (${(stats.publishedRatio * 100).toStringAsFixed(0)}٪)',
                  ),
                  AdminStatCard(
                    label: 'مستخدمون نشطون',
                    value: '${stats.activeUsers}',
                    icon: SardIcons.groups_rounded,
                    color: kAdminBlue,
                    sub: 'من ${stats.totalUsers} (${(stats.activeUserRatio * 100).toStringAsFixed(0)}٪ نشطون هذا الأسبوع)',
                  ),
                  AdminStatCard(
                    label: 'فصول آخر 7 أيام',
                    value: '${stats.chaptersLast7Days}',
                    icon: SardIcons.calendar_today_rounded,
                    color: kAdminTeal,
                    sub: '${stats.draftChapters} مسودة بانتظار النشر',
                  ),
                ],
              ),
              AdminSectionTitle(
                title: 'مشاهدات آخر 14 يوماً',
                subtitle: 'توزيع تقديري من بيانات الأعمال المحلية',
                icon: SardIcons.signal_cellular_alt_rounded,
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                  border: Border.all(color: p.border, width: p.borderW),
                ),
                child: Column(
                  children: [
                    AdminBarChart(
                      values: stats.viewsLast14Days,
                      labels: dayLabels,
                      color: p.accent,
                      height: 170,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'الأقل: ${formatCount(stats.viewsLast14Days.reduce((a, b) => a < b ? a : b))}',
                          style: context.ts(size: 11.5, color: p.textDim),
                        ),
                        Text(
                          'الأعلى: ${formatCount(stats.viewsLast14Days.reduce((a, b) => a > b ? a : b))}',
                          style: context.ts(size: 11.5, color: p.textDim),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              AdminSectionTitle(
                title: 'أفضل الأعمال',
                subtitle: 'حسب إجمالي المشاهدات',
                icon: SardIcons.local_fire_department_rounded,
                count: stats.topSeries.length,
              ),
              ...stats.topSeries.asMap().entries.map((e) {
                final i = e.key;
                final s = e.value;
                return _RankTile(
                  rank: i + 1,
                  title: s.title,
                  subtitle: '${s.typeShort} · ${s.chapters} فصلاً · ★ ${s.rating.toStringAsFixed(1)}',
                  value: formatCount(s.views),
                  valueLabel: 'مشاهدة',
                  progress: stats.topSeries.isEmpty || stats.topSeries.first.views == 0
                      ? 0
                      : s.views / stats.topSeries.first.views,
                );
              }),
              AdminSectionTitle(
                title: 'أفضل الفصول',
                subtitle: 'حسب المشاهدات',
                icon: SardIcons.star_rounded,
                count: stats.topChapters.length,
              ),
              ...stats.topChapters.asMap().entries.map((e) {
                final i = e.key;
                final c = e.value;
                final series = repo.seriesById(c.seriesId);
                return _RankTile(
                  rank: i + 1,
                  title: c.displayTitle,
                  subtitle: series?.title ?? c.seriesId,
                  value: formatCount(c.views),
                  valueLabel: 'مشاهدة',
                  progress: stats.topChapters.isEmpty || stats.topChapters.first.views == 0
                      ? 0
                      : c.views / stats.topChapters.first.views,
                );
              }),
              AdminSectionTitle(
                title: 'الأعمال حسب النوع',
                icon: SardIcons.category_rounded,
              ),
              _DistributionCard(
                entries: stats.seriesByType.entries.toList(),
                total: stats.totalSeries,
                color: p.accent,
              ),
              AdminSectionTitle(
                title: 'الأعمال حسب الحالة',
                icon: SardIcons.layers_rounded,
              ),
              _DistributionCard(
                entries: stats.seriesByState.entries.toList(),
                total: stats.totalSeries,
                color: kAdminTeal,
              ),
              AdminSectionTitle(
                title: 'المستخدمون حسب الدور',
                icon: SardIcons.person_rounded,
              ),
              _DistributionCard(
                entries: stats.usersByRole.entries.toList(),
                total: stats.totalUsers,
                color: kAdminBlue,
              ),
              AdminSectionTitle(
                title: 'البلاغات حسب السبب',
                icon: SardIcons.gavel_rounded,
              ),
              _DistributionCard(
                entries: stats.reportsByReason.entries.toList(),
                total: repo.reports.length,
                color: kAdminAmber,
                emptyMessage: 'لا بلاغات مسجلة بعد.',
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                  border: Border.all(color: p.border, width: p.borderW),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const SIcon(SardIcons.info_outline_rounded, size: 18, color: kAdminAmber),
                        const SizedBox(width: 8),
                        Text('عن هذه الأرقام', style: context.ts(size: 13.5, w: FontWeight.w800)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'الإحصاءات تُحسب من البيانات المحلية في هذا الإصدار التجريبي. توزيع المشاهدات اليومي تقديري (من إجمالي مشاهدات كل عمل)، وسيُستبدل ببيانات خادم حقيقية عند توفّر نقاط نهاية /admin/*.',
                      style: context.ts(size: 12.5, color: p.textDim),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _RankTile extends StatelessWidget {
  const _RankTile({
    required this.rank,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.valueLabel,
    required this.progress,
  });

  final int rank;
  final String title;
  final String subtitle;
  final String value;
  final String valueLabel;
  final double progress;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final medalColor = switch (rank) {
      1 => const Color(0xFFE9B44C),
      2 => const Color(0xFF9AA7B8),
      3 => const Color(0xFFC08A5E),
      _ => p.textDim,
    };
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: tint(medalColor, 0.16),
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: Text('$rank', style: context.ds(size: 15, color: medalColor)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: context.ts(size: 13.5, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text(subtitle, style: context.ts(size: 12, color: p.textDim), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress.clamp(0.0, 1.0),
                      minHeight: 5,
                      backgroundColor: tint(p.accent, 0.12),
                      valueColor: AlwaysStoppedAnimation<Color>(p.accent),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(value, style: context.ts(size: 13.5, w: FontWeight.w800, color: p.accent)),
                Text(valueLabel, style: context.ts(size: 11, color: p.textDim)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DistributionCard extends StatelessWidget {
  const _DistributionCard({
    required this.entries,
    required this.total,
    required this.color,
    this.emptyMessage,
  });

  final List<MapEntry<String, int>> entries;
  final int total;
  final Color color;
  final String? emptyMessage;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (entries.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Text(
          emptyMessage ?? 'لا بيانات بعد.',
          style: context.ts(size: 13, color: p.textDim),
          textAlign: TextAlign.center,
        ),
      );
    }
    final sorted = entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    const barColors = [kAdminPurple, kAdminBlue, kAdminTeal, kAdminGreen, kAdminAmber, kAdminRed];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Column(
        children: sorted.asMap().entries.map((e) {
          final i = e.key;
          final entry = e.value;
          final ratio = total == 0 ? 0.0 : entry.value / total;
          return Padding(
            padding: EdgeInsets.only(bottom: i == sorted.length - 1 ? 0 : 10),
            child: Row(
              children: [
                SizedBox(
                  width: 110,
                  child: Text(entry.key, style: context.ts(size: 12.5, w: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: ratio.clamp(0.0, 1.0),
                      minHeight: 8,
                      backgroundColor: tint(color, 0.1),
                      valueColor: AlwaysStoppedAnimation<Color>(barColors[i % barColors.length]),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 64,
                  child: Text(
                    '${entry.value} (${(ratio * 100).toStringAsFixed(0)}٪)',
                    style: context.ts(size: 12, w: FontWeight.w700, color: p.textDim),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
