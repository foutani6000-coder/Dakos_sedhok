import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/mock_data.dart';
import '../../core/data/models.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// مستودع لوحة الأدمن — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// كل بيانات الأدمن محلية في هذا الإصدار («الوضع التجريبي») لأن نقاط نهاية
/// `/admin/*` في الخادم غير موجودة بعد. المستودع يحفظ كل شيء في
/// SharedPreferences بصيغة JSON، ويزرع بيانات تجريبية واقعية من MockData
/// عند أول تشغيل، ويسجّل كل إجراء في سجل تدقيق (audit) لا يُحذف إلا بإعادة
/// تعيين كاملة. عند توفّر الخادم يُستبدل الحفظ المحلي بطبقة شبكية فقط دون
/// تغيير واجهات الشاشات.
/// ──────────────────────────────────────────────────────────────────────────

const String _kSeries = 'admin_v1_series';
const String _kChapters = 'admin_v1_chapters';
const String _kUsers = 'admin_v1_users';
const String _kReports = 'admin_v1_reports';
const String _kAnnouncements = 'admin_v1_announcements';
const String _kAudit = 'admin_v1_audit';
const String _kSeeded = 'admin_v1_seeded';
const String _kDemoPass = 'admin_v1_demo_pass';

/// بيانات دخول الوضع التجريبي. يجب تغييرها فوراً من شاشة إعدادات الأدمن،
/// فهي ظاهرة في الشيفرة ولا تصلح للإنتاج.
const String kAdminDemoUser = 'admin';
const String kAdminDemoPass = 'admin123';

/// أكبر عدد من إدخالات التدقيق المحفوظة.
const int kAdminAuditLimit = 500;

/// أكبر عدد من النتائج في بحث واحد.
const int kAdminSearchLimit = 200;

// ═══════════════════════════════════════════════════════════════════════════
//  أدوات صغيرة
// ═══════════════════════════════════════════════════════════════════════════

String _id(String prefix) =>
    '${prefix}_${DateTime.now().millisecondsSinceEpoch}_${math.Random().nextInt(9999).toString().padLeft(4, '0')}';

int _asInt(dynamic v, [int fallback = 0]) =>
    v is num ? v.toInt() : int.tryParse('${v ?? ''}') ?? fallback;

double _asDouble(dynamic v, [double fallback = 0]) =>
    v is num ? v.toDouble() : double.tryParse('${v ?? ''}') ?? fallback;

DateTime? _asDate(dynamic v) {
  if (v == null) return null;
  if (v is DateTime) return v;
  return DateTime.tryParse('$v');
}

DateTime _asDateOrNow(dynamic v) => _asDate(v) ?? DateTime.now();

List<String> _asStringList(dynamic v) =>
    ((v as List?) ?? const []).map((e) => '$e').where((e) => e.isNotEmpty).toList();

bool _looksLikeUrl(String s) {
  final t = s.trim();
  if (t.isEmpty) return false;
  final uri = Uri.tryParse(t);
  if (uri == null) return false;
  if (!uri.hasScheme) return false;
  return uri.scheme == 'http' || uri.scheme == 'https';
}

bool _looksLikeEmail(String s) {
  final t = s.trim();
  if (t.isEmpty || t.contains(' ')) return false;
  final at = t.indexOf('@');
  if (at <= 0) return false;
  final dot = t.indexOf('.', at);
  return dot > at + 1 && dot < t.length - 1;
}

/// «2026/11/26»
String formatSardDate(DateTime d) =>
    '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

/// «2026/11/26 — 14:30»
String formatSardDateTime(DateTime d) =>
    '${formatSardDate(d)} — ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

/// «الآن» / «قبل 5 دقائق» / «قبل ساعتين» / «أمس» / «قبل 3 أيام» / تاريخ.
String timeAgoArabic(DateTime d, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final diff = n.difference(d);
  if (diff.isNegative || diff.inSeconds < 45) return 'الآن';
  if (diff.inMinutes < 60) {
    final m = diff.inMinutes;
    if (m == 1) return 'قبل دقيقة';
    if (m == 2) return 'قبل دقيقتين';
    if (m <= 10) return 'قبل $m دقائق';
    return 'قبل $m دقيقة';
  }
  if (diff.inHours < 24) {
    final h = diff.inHours;
    if (h == 1) return 'قبل ساعة';
    if (h == 2) return 'قبل ساعتين';
    if (h <= 10) return 'قبل $h ساعات';
    return 'قبل $h ساعة';
  }
  if (diff.inDays == 1) return 'أمس';
  if (diff.inDays < 7) {
    final dd = diff.inDays;
    if (dd == 2) return 'قبل يومين';
    if (dd <= 10) return 'قبل $dd أيام';
    return 'قبل $dd يوماً';
  }
  return formatSardDate(d);
}

/// الحرفان الأولان من الاسم (لأفاتار نصّي) دون حزمة characters.
String adminInitials(String name) {
  final parts = name.trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
  if (parts.isEmpty) return '؟';
  if (parts.length == 1) {
    final w = parts.first;
    return w.length >= 2 ? w.substring(0, 2) : w;
  }
  return '${parts[0][0]}${parts[1][0]}';
}

/// يقصّ نصاً طويلاً مع «…» دون كسر كلمة في المنتصف قدر الإمكان.
String adminEllipsis(String s, int max) {
  if (s.length <= max) return s;
  final cut = s.substring(0, max);
  final lastSpace = cut.lastIndexOf(' ');
  final base = lastSpace > max ~/ 2 ? cut.substring(0, lastSpace) : cut;
  return '$base…';
}

// ═══════════════════════════════════════════════════════════════════════════
//  التعدادات
// ═══════════════════════════════════════════════════════════════════════════

/// حالة فصل في لوحة الأدمن.
enum AdminChapterStatus {
  draft('مسودة', 'لم يُنشر بعد'),
  scheduled('مجدول', 'سيُنشر تلقائياً في موعده'),
  published('منشور', 'ظاهر للقرّاء'),
  hidden('مخفي', 'محجوب عن القرّاء مؤقتاً');

  const AdminChapterStatus(this.label, this.hint);
  final String label;
  final String hint;

  bool get visibleToReaders => this == AdminChapterStatus.published;

  static AdminChapterStatus fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final s in AdminChapterStatus.values) {
      if (s.name == t) return s;
    }
    return AdminChapterStatus.draft;
  }
}

/// حالة عمل في لوحة الأدمن (نفس نصوص Series.status في التطبيق).
enum AdminSeriesState {
  ongoing('مستمر'),
  completed('مكتمل'),
  paused('متوقف');

  const AdminSeriesState(this.label);
  final String label;

  static AdminSeriesState fromLabel(String? v) {
    switch ((v ?? '').trim()) {
      case 'مكتمل':
        return AdminSeriesState.completed;
      case 'متوقف':
        return AdminSeriesState.paused;
      default:
        return AdminSeriesState.ongoing;
    }
  }
}

/// دور مستخدم في لوحة الأدمن.
enum AdminRole {
  user('قارئ', 'يقرأ فقط'),
  translator('مترجم', 'يرفع فصولاً ويراجعها'),
  moderator('مشرف', 'يراجع البلاغات والتعليقات'),
  admin('أدمن', 'إدارة الأعمال والفصول والإعلانات'),
  superAdmin('أدمن أعلى', 'كل الصلاحيات بما فيها المستخدمين والإعدادات');

  const AdminRole(this.label, this.hint);
  final String label;
  final String hint;

  bool get canModerate => this == AdminRole.moderator || canManageContent;
  bool get canManageContent =>
      this == AdminRole.translator || this == AdminRole.admin || this == AdminRole.superAdmin;
  bool get canManageUsers => this == AdminRole.superAdmin;
  bool get canManageSettings => this == AdminRole.superAdmin;

  static AdminRole fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final r in AdminRole.values) {
      if (r.name == t) return r;
    }
    return AdminRole.user;
  }
}

/// حالة حساب مستخدم.
enum AdminUserStatus {
  active('نشط', 'يستطيع الدخول والقراءة'),
  suspended('موقوف', 'موقوف مؤقتاً عن النشر والتعليق'),
  banned('محظور', 'محظور من الدخول نهائياً'),
  pending('بانتظار التفعيل', 'أنشأ حساباً ولم يفعّله بعد');

  const AdminUserStatus(this.label, this.hint);
  final String label;
  final String hint;

  bool get canSignIn => this == AdminUserStatus.active || this == AdminUserStatus.pending;

  static AdminUserStatus fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final s in AdminUserStatus.values) {
      if (s.name == t) return s;
    }
    return AdminUserStatus.active;
  }
}

/// نوع الهدف الذي يخصّه بلاغ.
enum AdminReportTarget {
  series('عمل', 'بلاغ على عمل كامل'),
  chapter('فصل', 'بلاغ على فصل بعينه'),
  comment('تعليق', 'بلاغ على تعليق'),
  user('مستخدم', 'بلاغ على مستخدم');

  const AdminReportTarget(this.label, this.hint);
  final String label;
  final String hint;

  static AdminReportTarget fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final r in AdminReportTarget.values) {
      if (r.name == t) return r;
    }
    return AdminReportTarget.series;
  }
}

/// سبب بلاغ.
enum AdminReportReason {
  spam('إزعاج', 'محتوى مكرر أو إعلاني'),
  inappropriate('محتوى غير لائق', 'صور أو نصوص غير مناسبة'),
  copyright('حقوق نشر', 'محتوى مسروق أو منتهك للحقوق'),
  wrongContent('محتوى خاطئ', 'فصول مكررة أو صفحات ناقصة أو عنوان خاطئ'),
  harassment('إساءة', 'شتائم أو مضايقة أو تهديد'),
  other('أخرى', 'سبب آخر يوضّحه المُبلِّغ');

  const AdminReportReason(this.label, this.hint);
  final String label;
  final String hint;

  static AdminReportReason fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final r in AdminReportReason.values) {
      if (r.name == t) return r;
    }
    return AdminReportReason.other;
  }
}

/// حالة بلاغ.
enum AdminReportStatus {
  pending('بانتظار المراجعة'),
  reviewing('قيد المراجعة'),
  resolved('تمت المعالجة'),
  rejected('مرفوض');

  const AdminReportStatus(this.label);
  final String label;

  bool get isOpen => this == AdminReportStatus.pending || this == AdminReportStatus.reviewing;

  static AdminReportStatus fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final s in AdminReportStatus.values) {
      if (s.name == t) return s;
    }
    return AdminReportStatus.pending;
  }
}

/// جمهور إعلان.
enum AdminAnnouncementTarget {
  all('الجميع', 'يظهر لكل المستخدمين'),
  readers('القرّاء', 'لمن لديهم نشاط قراءة'),
  translators('المترجمون', 'للمترجمين والناشرين فقط'),
  newUsers('الجدد', 'لمن انضموا خلال آخر 30 يوماً');

  const AdminAnnouncementTarget(this.label, this.hint);
  final String label;
  final String hint;

  static AdminAnnouncementTarget fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final a in AdminAnnouncementTarget.values) {
      if (a.name == t) return a;
    }
    return AdminAnnouncementTarget.all;
  }
}

/// نوع إجراء في سجل التدقيق.
enum AdminAuditAction {
  create('إنشاء'),
  update('تعديل'),
  delete('حذف'),
  publish('نشر'),
  hide('إخفاء'),
  schedule('جدولة'),
  ban('حظر'),
  unban('رفع حظر'),
  suspend('إيقاف'),
  role('تغيير دور'),
  resolve('معالجة بلاغ'),
  reject('رفض بلاغ'),
  announce('إعلان'),
  login('دخول'),
  logout('خروج'),
  settings('إعدادات'),
  import('استيراد'),
  export('تصدير'),
  reset('إعادة تعيين');

  const AdminAuditAction(this.label);
  final String label;

  static AdminAuditAction fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final a in AdminAuditAction.values) {
      if (a.name == t) return a;
    }
    return AdminAuditAction.update;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  النماذج
// ═══════════════════════════════════════════════════════════════════════════

/// فصل كما يراه الأدمن (صفحاته روابط، وحالته خاضعة للمراجعة والجدولة).
class AdminChapter {
  const AdminChapter({
    required this.id,
    required this.seriesId,
    required this.number,
    required this.title,
    required this.pages,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.publishAt,
    this.views = 0,
  });

  final String id;
  final String seriesId;
  final int number;
  final String title;

  /// روابط صفحات الفصل بالترتيب.
  final List<String> pages;
  final AdminChapterStatus status;

  /// موعد النشر المجدول (null = بلا جدولة).
  final DateTime? publishAt;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int views;

  /// عنوان العرض: يستخدم الرقم عند غياب العنوان.
  String get displayTitle {
    final t = title.trim();
    if (t.isEmpty) return 'الفصل $number';
    return 'الفصل $number: $t';
  }

  /// صحيح فقط للمجدول الذي حان وقته.
  bool get scheduleDue =>
      status == AdminChapterStatus.scheduled &&
      publishAt != null &&
      !publishAt!.isAfter(DateTime.now());

  /// صحيح للفصل المجدول الذي لم يحن وقته بعد.
  bool get isScheduledFuture =>
      status == AdminChapterStatus.scheduled &&
      publishAt != null &&
      publishAt!.isAfter(DateTime.now());

  int get pageCount => pages.length;

  /// رسالة الخطأ الأولى، أو null إن كان الفصل صالحاً.
  String? validate() {
    if (number <= 0) return 'رقم الفصل يجب أن يكون أكبر من صفر.';
    if (title.trim().length > 120) return 'عنوان الفصل طويل جداً (120 حرفاً كحد أقصى).';
    if (pages.isEmpty) return 'أضف صفحة واحدة على الأقل.';
    if (pages.length > 300) return 'عدد الصفحات كبير جداً (300 كحد أقصى).';
    for (var i = 0; i < pages.length; i++) {
      final p = pages[i].trim();
      if (p.isEmpty) return 'الصفحة ${i + 1} فارغة.';
      if (!_looksLikeUrl(p)) return 'رابط الصفحة ${i + 1} غير صالح (يجب أن يبدأ بـ http).';
    }
    if (status == AdminChapterStatus.scheduled) {
      if (publishAt == null) return 'حدّد موعد النشر للفصل المجدول.';
      if (publishAt!.isBefore(DateTime.now().subtract(const Duration(minutes: 1)))) {
        return 'موعد النشر المجدول في الماضي.';
      }
    }
    return null;
  }

  AdminChapter copyWith({
    int? number,
    String? title,
    List<String>? pages,
    AdminChapterStatus? status,
    DateTime? publishAt,
    bool clearPublishAt = false,
    int? views,
    DateTime? updatedAt,
  }) {
    return AdminChapter(
      id: id,
      seriesId: seriesId,
      number: number ?? this.number,
      title: title ?? this.title,
      pages: pages ?? this.pages,
      status: status ?? this.status,
      publishAt: clearPublishAt ? null : (publishAt ?? this.publishAt),
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      views: views ?? this.views,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'series_id': seriesId,
        'number': number,
        'title': title,
        'pages': pages,
        'status': status.name,
        'publish_at': publishAt?.toIso8601String(),
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'views': views,
      };

  factory AdminChapter.fromJson(Map<String, dynamic> j) {
    return AdminChapter(
      id: '${j['id'] ?? ''}',
      seriesId: '${j['series_id'] ?? j['seriesId'] ?? ''}',
      number: _asInt(j['number']),
      title: '${j['title'] ?? ''}',
      pages: _asStringList(j['pages']),
      status: AdminChapterStatus.fromKey(j['status']),
      publishAt: _asDate(j['publish_at'] ?? j['publishAt']),
      createdAt: _asDateOrNow(j['created_at'] ?? j['createdAt']),
      updatedAt: _asDateOrNow(j['updated_at'] ?? j['updatedAt']),
      views: _asInt(j['views']),
    );
  }

  /// فصل جديد فارغ جاهز للتعبئة.
  factory AdminChapter.blank({required String seriesId, required int number}) {
    final now = DateTime.now();
    return AdminChapter(
      id: _id('ch'),
      seriesId: seriesId,
      number: number,
      title: '',
      pages: const [],
      status: AdminChapterStatus.draft,
      createdAt: now,
      updatedAt: now,
    );
  }
}

/// عمل (سلسلة) كما يراه الأدمن — مبني على حقول [Series] الحقيقية.
class AdminSeries {
  const AdminSeries({
    required this.id,
    required this.title,
    required this.type,
    required this.status,
    required this.genres,
    required this.synopsis,
    required this.chapters,
    required this.rating,
    required this.views,
    required this.year,
    required this.createdAt,
    required this.updatedAt,
    this.cover,
    this.isNew = false,
    this.featured = false,
  });

  final String id;
  final String title;
  final String? cover;
  final String type;
  final String status;
  final List<String> genres;
  final String synopsis;
  final int chapters;
  final double rating;
  final int views;
  final int year;
  final bool isNew;
  final bool featured;
  final DateTime createdAt;
  final DateTime updatedAt;

  AdminSeriesState get state => AdminSeriesState.fromLabel(status);
  bool get ongoing => state == AdminSeriesState.ongoing;

  /// رقم ثابت لتوليد قيم تقديرية (مطابق لمنطق Series.seed).
  int get seed => id.codeUnits.fold<int>(7, (a, b) => a * 31 + b) & 0x7fffffff;

  String get typeShort {
    if (type.contains('مانهوا')) return 'مانهوا';
    if (type.contains('مانغا')) return 'مانغا';
    if (type.contains('كوميك')) return 'كوميك';
    return type;
  }

  String get genresLabel => genres.isEmpty ? 'بلا تصنيفات' : genres.join('، ');

  String? validate() {
    if (title.trim().isEmpty) return 'عنوان العمل مطلوب.';
    if (title.trim().length > 120) return 'العنوان طويل جداً (120 حرفاً كحد أقصى).';
    if (title.trim().length < 2) return 'العنوان قصير جداً.';
    if (type.trim().isEmpty) return 'حدّد نوع العمل.';
    if (cover != null && cover!.trim().isNotEmpty && !_looksLikeUrl(cover!.trim())) {
      return 'رابط الغلاف غير صالح (يجب أن يبدأ بـ http).';
    }
    if (year < 1980 || year > DateTime.now().year + 1) return 'سنة النشر غير منطقية.';
    if (synopsis.length > 2000) return 'الملخص طويل جداً (2000 حرف كحد أقصى).';
    if (genres.length > 8) return 'التصنيفات كثيرة جداً (8 كحد أقصى).';
    return null;
  }

  AdminSeries copyWith({
    String? title,
    String? cover,
    bool clearCover = false,
    String? type,
    String? status,
    List<String>? genres,
    String? synopsis,
    int? chapters,
    double? rating,
    int? views,
    int? year,
    bool? isNew,
    bool? featured,
    DateTime? updatedAt,
  }) {
    return AdminSeries(
      id: id,
      title: title ?? this.title,
      cover: clearCover ? null : (cover ?? this.cover),
      type: type ?? this.type,
      status: status ?? this.status,
      genres: genres ?? this.genres,
      synopsis: synopsis ?? this.synopsis,
      chapters: chapters ?? this.chapters,
      rating: rating ?? this.rating,
      views: views ?? this.views,
      year: year ?? this.year,
      isNew: isNew ?? this.isNew,
      featured: featured ?? this.featured,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'cover': cover,
        'type': type,
        'status': status,
        'genres': genres,
        'synopsis': synopsis,
        'chapters': chapters,
        'rating': rating,
        'views': views,
        'year': year,
        'is_new': isNew,
        'featured': featured,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory AdminSeries.fromJson(Map<String, dynamic> j) {
    return AdminSeries(
      id: '${j['id'] ?? ''}',
      title: '${j['title'] ?? ''}',
      cover: j['cover'] as String?,
      type: '${j['type'] ?? 'مانهوا كورية'}',
      status: '${j['status'] ?? 'مستمر'}',
      genres: _asStringList(j['genres']),
      synopsis: '${j['synopsis'] ?? ''}',
      chapters: _asInt(j['chapters']),
      rating: _asDouble(j['rating']),
      views: _asInt(j['views']),
      year: _asInt(j['year'], DateTime.now().year),
      isNew: j['is_new'] == true,
      featured: j['featured'] == true,
      createdAt: _asDateOrNow(j['created_at'] ?? j['createdAt']),
      updatedAt: _asDateOrNow(j['updated_at'] ?? j['updatedAt']),
    );
  }

  factory AdminSeries.fromSeries(Series s) => AdminSeries(
        id: s.id,
        title: s.title,
        cover: s.cover,
        type: s.type,
        status: s.status,
        genres: List<String>.from(s.genres),
        synopsis: s.synopsis,
        chapters: s.chapters,
        rating: s.rating,
        views: s.views,
        year: s.year,
        isNew: s.isNew,
        createdAt: DateTime.now().subtract(Duration(days: 30 + s.seed % 300)),
        updatedAt: DateTime.now().subtract(Duration(days: s.seed % 20)),
      );

  Series toSeries() => Series(
        id: id,
        title: title,
        cover: cover,
        type: type,
        status: status,
        chapters: chapters,
        rating: rating,
        views: views,
        genres: genres,
        synopsis: synopsis,
        isNew: isNew,
        year: year,
      );

  factory AdminSeries.blank() {
    final now = DateTime.now();
    return AdminSeries(
      id: _id('sr'),
      title: '',
      type: 'مانهوا كورية',
      status: 'مستمر',
      genres: const [],
      synopsis: '',
      chapters: 0,
      rating: 0,
      views: 0,
      year: now.year,
      createdAt: now,
      updatedAt: now,
    );
  }
}

/// مستخدم كما يراه الأدمن.
class AdminUser {
  const AdminUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.status,
    required this.joinedAt,
    required this.lastActiveAt,
    this.chaptersRead = 0,
    this.readingSeconds = 0,
    this.isVerified = false,
    this.bannedReason,
    this.note,
  });

  final String id;
  final String name;
  final String email;
  final AdminRole role;
  final AdminUserStatus status;
  final DateTime joinedAt;
  final DateTime lastActiveAt;
  final int chaptersRead;
  final int readingSeconds;
  final bool isVerified;
  final String? bannedReason;
  final String? note;

  String get initials => adminInitials(name);
  String get readingTimeLabel => formatReadingTime(readingSeconds);
  bool get isNewUser => DateTime.now().difference(joinedAt).inDays < 30;
  bool get isActiveRecently => DateTime.now().difference(lastActiveAt).inDays < 7;

  String? validate() {
    if (name.trim().isEmpty) return 'اسم المستخدم مطلوب.';
    if (name.trim().length > 60) return 'الاسم طويل جداً.';
    if (!_looksLikeEmail(email)) return 'البريد الإلكتروني غير صالح.';
    if (status == AdminUserStatus.banned && (bannedReason ?? '').trim().isEmpty) {
      return 'اكتب سبب الحظر.';
    }
    return null;
  }

  AdminUser copyWith({
    String? name,
    String? email,
    AdminRole? role,
    AdminUserStatus? status,
    DateTime? lastActiveAt,
    int? chaptersRead,
    int? readingSeconds,
    bool? isVerified,
    String? bannedReason,
    bool clearBannedReason = false,
    String? note,
  }) {
    return AdminUser(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      role: role ?? this.role,
      status: status ?? this.status,
      joinedAt: joinedAt,
      lastActiveAt: lastActiveAt ?? this.lastActiveAt,
      chaptersRead: chaptersRead ?? this.chaptersRead,
      readingSeconds: readingSeconds ?? this.readingSeconds,
      isVerified: isVerified ?? this.isVerified,
      bannedReason: clearBannedReason ? null : (bannedReason ?? this.bannedReason),
      note: note ?? this.note,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'role': role.name,
        'status': status.name,
        'joined_at': joinedAt.toIso8601String(),
        'last_active_at': lastActiveAt.toIso8601String(),
        'chapters_read': chaptersRead,
        'reading_seconds': readingSeconds,
        'is_verified': isVerified,
        'banned_reason': bannedReason,
        'note': note,
      };

  factory AdminUser.fromJson(Map<String, dynamic> j) {
    return AdminUser(
      id: '${j['id'] ?? ''}',
      name: '${j['name'] ?? 'مستخدم'}',
      email: '${j['email'] ?? ''}',
      role: AdminRole.fromKey(j['role']),
      status: AdminUserStatus.fromKey(j['status']),
      joinedAt: _asDateOrNow(j['joined_at'] ?? j['joinedAt']),
      lastActiveAt: _asDateOrNow(j['last_active_at'] ?? j['lastActiveAt']),
      chaptersRead: _asInt(j['chapters_read']),
      readingSeconds: _asInt(j['reading_seconds']),
      isVerified: j['is_verified'] == true,
      bannedReason: j['banned_reason'] as String?,
      note: j['note'] as String?,
    );
  }
}

/// بلاغ من مستخدم على محتوى أو مستخدم.
class AdminReport {
  const AdminReport({
    required this.id,
    required this.targetType,
    required this.targetId,
    required this.targetTitle,
    required this.reason,
    required this.reporterId,
    required this.reporterName,
    required this.description,
    required this.status,
    required this.createdAt,
    this.resolvedAt,
    this.resolutionNote,
    this.moderatorId,
  });

  final String id;
  final AdminReportTarget targetType;
  final String targetId;
  final String targetTitle;
  final AdminReportReason reason;
  final String reporterId;
  final String reporterName;
  final String description;
  final AdminReportStatus status;
  final DateTime createdAt;
  final DateTime? resolvedAt;
  final String? resolutionNote;
  final String? moderatorId;

  bool get isOpen => status.isOpen;

  AdminReport copyWith({
    AdminReportStatus? status,
    DateTime? resolvedAt,
    String? resolutionNote,
    String? moderatorId,
  }) {
    return AdminReport(
      id: id,
      targetType: targetType,
      targetId: targetId,
      targetTitle: targetTitle,
      reason: reason,
      reporterId: reporterId,
      reporterName: reporterName,
      description: description,
      status: status ?? this.status,
      createdAt: createdAt,
      resolvedAt: resolvedAt ?? this.resolvedAt,
      resolutionNote: resolutionNote ?? this.resolutionNote,
      moderatorId: moderatorId ?? this.moderatorId,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'target_type': targetType.name,
        'target_id': targetId,
        'target_title': targetTitle,
        'reason': reason.name,
        'reporter_id': reporterId,
        'reporter_name': reporterName,
        'description': description,
        'status': status.name,
        'created_at': createdAt.toIso8601String(),
        'resolved_at': resolvedAt?.toIso8601String(),
        'resolution_note': resolutionNote,
        'moderator_id': moderatorId,
      };

  factory AdminReport.fromJson(Map<String, dynamic> j) {
    return AdminReport(
      id: '${j['id'] ?? ''}',
      targetType: AdminReportTarget.fromKey(j['target_type']),
      targetId: '${j['target_id'] ?? ''}',
      targetTitle: '${j['target_title'] ?? ''}',
      reason: AdminReportReason.fromKey(j['reason']),
      reporterId: '${j['reporter_id'] ?? ''}',
      reporterName: '${j['reporter_name'] ?? 'مستخدم'}',
      description: '${j['description'] ?? ''}',
      status: AdminReportStatus.fromKey(j['status']),
      createdAt: _asDateOrNow(j['created_at'] ?? j['createdAt']),
      resolvedAt: _asDate(j['resolved_at']),
      resolutionNote: j['resolution_note'] as String?,
      moderatorId: j['moderator_id'] as String?,
    );
  }
}

/// إعلان يُعرض داخل التطبيق.
class AdminAnnouncement {
  const AdminAnnouncement({
    required this.id,
    required this.title,
    required this.body,
    required this.target,
    required this.createdAt,
    required this.active,
    this.seriesId,
    this.publishAt,
    this.expiresAt,
    this.priority = 0,
    this.views = 0,
  });

  final String id;
  final String title;
  final String body;
  final AdminAnnouncementTarget target;
  final String? seriesId;
  final DateTime? publishAt;
  final DateTime? expiresAt;
  final int priority;
  final bool active;
  final int views;
  final DateTime createdAt;

  /// هل الإعلان ظاهر الآن فعلاً؟
  bool get isLive {
    if (!active) return false;
    final now = DateTime.now();
    if (publishAt != null && publishAt!.isAfter(now)) return false;
    if (expiresAt != null && expiresAt!.isBefore(now)) return false;
    return true;
  }

  String get statusLabel {
    if (!active) return 'متوقف';
    final now = DateTime.now();
    if (publishAt != null && publishAt!.isAfter(now)) return 'مجدول';
    if (expiresAt != null && expiresAt!.isBefore(now)) return 'منتهي';
    return 'نشط الآن';
  }

  String? validate() {
    if (title.trim().isEmpty) return 'عنوان الإعلان مطلوب.';
    if (title.trim().length > 100) return 'العنوان طويل جداً (100 حرف كحد أقصى).';
    if (body.trim().isEmpty) return 'نص الإعلان مطلوب.';
    if (body.trim().length > 1000) return 'النص طويل جداً (1000 حرف كحد أقصى).';
    if (publishAt != null && expiresAt != null && expiresAt!.isBefore(publishAt!)) {
      return 'تاريخ الانتهاء قبل تاريخ النشر.';
    }
    return null;
  }

  AdminAnnouncement copyWith({
    String? title,
    String? body,
    AdminAnnouncementTarget? target,
    String? seriesId,
    bool clearSeriesId = false,
    DateTime? publishAt,
    bool clearPublishAt = false,
    DateTime? expiresAt,
    bool clearExpiresAt = false,
    int? priority,
    bool? active,
    int? views,
  }) {
    return AdminAnnouncement(
      id: id,
      title: title ?? this.title,
      body: body ?? this.body,
      target: target ?? this.target,
      seriesId: clearSeriesId ? null : (seriesId ?? this.seriesId),
      publishAt: clearPublishAt ? null : (publishAt ?? this.publishAt),
      expiresAt: clearExpiresAt ? null : (expiresAt ?? this.expiresAt),
      priority: priority ?? this.priority,
      active: active ?? this.active,
      views: views ?? this.views,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'target': target.name,
        'series_id': seriesId,
        'publish_at': publishAt?.toIso8601String(),
        'expires_at': expiresAt?.toIso8601String(),
        'priority': priority,
        'active': active,
        'views': views,
        'created_at': createdAt.toIso8601String(),
      };

  factory AdminAnnouncement.fromJson(Map<String, dynamic> j) {
    return AdminAnnouncement(
      id: '${j['id'] ?? ''}',
      title: '${j['title'] ?? ''}',
      body: '${j['body'] ?? ''}',
      target: AdminAnnouncementTarget.fromKey(j['target']),
      seriesId: j['series_id'] as String?,
      publishAt: _asDate(j['publish_at']),
      expiresAt: _asDate(j['expires_at']),
      priority: _asInt(j['priority']),
      active: j['active'] != false,
      views: _asInt(j['views']),
      createdAt: _asDateOrNow(j['created_at'] ?? j['createdAt']),
    );
  }
}

/// إدخال واحد في سجل التدقيق.
class AdminAuditEntry {
  const AdminAuditEntry({
    required this.id,
    required this.actorId,
    required this.actorName,
    required this.action,
    required this.targetType,
    required this.targetId,
    required this.detail,
    required this.at,
  });

  final String id;
  final String actorId;
  final String actorName;
  final AdminAuditAction action;
  final String targetType;
  final String targetId;
  final String detail;
  final DateTime at;

  String get summary => '${action.label} — $detail';

  Map<String, dynamic> toJson() => {
        'id': id,
        'actor_id': actorId,
        'actor_name': actorName,
        'action': action.name,
        'target_type': targetType,
        'target_id': targetId,
        'detail': detail,
        'at': at.toIso8601String(),
      };

  factory AdminAuditEntry.fromJson(Map<String, dynamic> j) {
    return AdminAuditEntry(
      id: '${j['id'] ?? ''}',
      actorId: '${j['actor_id'] ?? ''}',
      actorName: '${j['actor_name'] ?? 'أدمن'}',
      action: AdminAuditAction.fromKey(j['action']),
      targetType: '${j['target_type'] ?? ''}',
      targetId: '${j['target_id'] ?? ''}',
      detail: '${j['detail'] ?? ''}',
      at: _asDateOrNow(j['at']),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  الفلاتر والترتيب
// ═══════════════════════════════════════════════════════════════════════════

enum AdminSeriesSort { newest, title, views, rating, chapters }

/// فلتر قائمة الأعمال.
class AdminSeriesFilter {
  const AdminSeriesFilter({
    this.query = '',
    this.type,
    this.state,
    this.genre,
    this.onlyFeatured = false,
    this.onlyNew = false,
    this.sort = AdminSeriesSort.newest,
  });

  final String query;
  final String? type;
  final AdminSeriesState? state;
  final String? genre;
  final bool onlyFeatured;
  final bool onlyNew;
  final AdminSeriesSort sort;

  bool get isEmpty =>
      query.trim().isEmpty && type == null && state == null && genre == null && !onlyFeatured && !onlyNew;

  AdminSeriesFilter copyWith({
    String? query,
    String? type,
    bool clearType = false,
    AdminSeriesState? state,
    bool clearState = false,
    String? genre,
    bool clearGenre = false,
    bool? onlyFeatured,
    bool? onlyNew,
    AdminSeriesSort? sort,
  }) {
    return AdminSeriesFilter(
      query: query ?? this.query,
      type: clearType ? null : (type ?? this.type),
      state: clearState ? null : (state ?? this.state),
      genre: clearGenre ? null : (genre ?? this.genre),
      onlyFeatured: onlyFeatured ?? this.onlyFeatured,
      onlyNew: onlyNew ?? this.onlyNew,
      sort: sort ?? this.sort,
    );
  }
}

enum AdminUserSort { newest, name, mostRead, lastActive }

/// فلتر قائمة المستخدمين.
class AdminUserFilter {
  const AdminUserFilter({
    this.query = '',
    this.role,
    this.status,
    this.onlyNew = false,
    this.onlyActiveRecently = false,
    this.sort = AdminUserSort.newest,
  });

  final String query;
  final AdminRole? role;
  final AdminUserStatus? status;
  final bool onlyNew;
  final bool onlyActiveRecently;
  final AdminUserSort sort;

  bool get isEmpty =>
      query.trim().isEmpty && role == null && status == null && !onlyNew && !onlyActiveRecently;

  AdminUserFilter copyWith({
    String? query,
    AdminRole? role,
    bool clearRole = false,
    AdminUserStatus? status,
    bool clearStatus = false,
    bool? onlyNew,
    bool? onlyActiveRecently,
    AdminUserSort? sort,
  }) {
    return AdminUserFilter(
      query: query ?? this.query,
      role: clearRole ? null : (role ?? this.role),
      status: clearStatus ? null : (status ?? this.status),
      onlyNew: onlyNew ?? this.onlyNew,
      onlyActiveRecently: onlyActiveRecently ?? this.onlyActiveRecently,
      sort: sort ?? this.sort,
    );
  }
}

/// فلتر قائمة الفصول.
class AdminChapterFilter {
  const AdminChapterFilter({this.status, this.query = '', this.onlyDue = false});

  final AdminChapterStatus? status;
  final String query;
  final bool onlyDue;

  bool get isEmpty => status == null && query.trim().isEmpty && !onlyDue;

  AdminChapterFilter copyWith({
    AdminChapterStatus? status,
    bool clearStatus = false,
    String? query,
    bool? onlyDue,
  }) {
    return AdminChapterFilter(
      status: clearStatus ? null : (status ?? this.status),
      query: query ?? this.query,
      onlyDue: onlyDue ?? this.onlyDue,
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  الإحصاءات
// ═══════════════════════════════════════════════════════════════════════════

/// لقطة إحصاءات تُحسب من بيانات المستودع لحظة طلبها.
class AdminStats {
  const AdminStats({
    required this.totalSeries,
    required this.totalChapters,
    required this.publishedChapters,
    required this.draftChapters,
    required this.scheduledChapters,
    required this.dueChapters,
    required this.totalUsers,
    required this.activeUsers,
    required this.newUsers30d,
    required this.totalViews,
    required this.openReports,
    required this.liveAnnouncements,
    required this.topSeries,
    required this.topChapters,
    required this.viewsLast14Days,
    required this.seriesByType,
    required this.seriesByState,
    required this.usersByRole,
    required this.reportsByReason,
    required this.chaptersLast7Days,
  });

  final int totalSeries;
  final int totalChapters;
  final int publishedChapters;
  final int draftChapters;
  final int scheduledChapters;
  final int dueChapters;
  final int totalUsers;
  final int activeUsers;
  final int newUsers30d;
  final int totalViews;
  final int openReports;
  final int liveAnnouncements;
  final List<AdminSeries> topSeries;
  final List<AdminChapter> topChapters;
  final List<int> viewsLast14Days;
  final Map<String, int> seriesByType;
  final Map<String, int> seriesByState;
  final Map<String, int> usersByRole;
  final Map<String, int> reportsByReason;
  final int chaptersLast7Days;

  double get publishedRatio => totalChapters == 0 ? 0 : publishedChapters / totalChapters;
  double get activeUserRatio => totalUsers == 0 ? 0 : activeUsers / totalUsers;
}

/// نتيجة عملية إدارية تحمل رسالة نجاح أو خطأ عربية.
class AdminResult {
  const AdminResult.ok(this.message) : error = null;
  const AdminResult.fail(this.error) : message = null;

  final String? message;
  final String? error;

  bool get isOk => error == null;
}

/// نتيجة بحث شامل في كل مجموعات الأدمن.
class AdminGlobalSearch {
  const AdminGlobalSearch({
    this.series = const [],
    this.chapters = const [],
    this.users = const [],
    this.reports = const [],
  });

  final List<AdminSeries> series;
  final List<AdminChapter> chapters;
  final List<AdminUser> users;
  final List<AdminReport> reports;

  int get totalCount => series.length + chapters.length + users.length + reports.length;
  bool get isEmpty => totalCount == 0;
}

/// نوع عنصر يحتاج انتباه الأدمن.
enum AdminAttentionKind {
  dueChapters('فصول حان وقتها'),
  oldDrafts('مسودات قديمة'),
  openReports('بلاغات مفتوحة'),
  suspendedUsers('مستخدمون موقوفون');

  const AdminAttentionKind(this.label);
  final String label;
}

/// عنصر واحد في قائمة «يحتاج انتباهك».
class AdminAttentionItem {
  const AdminAttentionItem({
    required this.kind,
    required this.title,
    required this.subtitle,
    required this.count,
  });

  final AdminAttentionKind kind;
  final String title;
  final String subtitle;
  final int count;
}

// ═══════════════════════════════════════════════════════════════════════════
//  المستودع
// ═══════════════════════════════════════════════════════════════════════════

/// مستودع لوحة الأدمن — نقطة الوصول الوحيدة لبيانات الأدمن.
///
/// يعمل في «الوضع التجريبي» محلياً: كل التعديلات تُحفظ في SharedPreferences
/// وتُبثّ عبر ChangeNotifier. عند توفّر خادم `/admin/*` تُستبدل طرق الحفظ
/// فقط، دون تغيير الشاشات.
class AdminRepository extends ChangeNotifier {
  AdminRepository._(this._prefs);

  static AdminRepository? _instance;

  /// النسخة المشتركة (يجب استدعاء [load] مرة واحدة عند الإقلاع).
  static AdminRepository get i {
    final inst = _instance;
    if (inst == null) throw StateError('AdminRepository.load() لم يُستدعَ بعد.');
    return inst;
  }

  /// يهيّئ النسخة المشتركة من التخزين المحلي ويزرع بيانات تجريبية إن لزم.
  static Future<AdminRepository> load() async {
    if (_instance != null) return _instance!;
    final prefs = await SharedPreferences.getInstance();
    final repo = AdminRepository._(prefs);
    await repo._loadAll();
    _instance = repo;
    return repo;
  }

  /// نسخة في الذاكرة فقط للاختبارات (بلا حفظ دائم)، مزروعة بالبيانات التجريبية.
  factory AdminRepository.memory() {
    final repo = AdminRepository._(null);
    repo._seedDemoData();
    repo._loaded = true;
    return repo;
  }

  final SharedPreferences? _prefs;

  List<AdminSeries> _series = [];
  List<AdminChapter> _chapters = [];
  List<AdminUser> _users = [];
  List<AdminReport> _reports = [];
  List<AdminAnnouncement> _announcements = [];
  List<AdminAuditEntry> _audit = [];

  bool _loaded = false;
  bool get isLoaded => _loaded;

  /// هل هذه البيانات تجريبية (زرعها التطبيق) أم عدّلها أدمن فعلياً؟
  bool get isDemoSeeded => _prefs?.getBool(_kSeeded) ?? true;

  List<AdminSeries> get series => List<AdminSeries>.unmodifiable(_series);
  List<AdminChapter> get chapters => List<AdminChapter>.unmodifiable(_chapters);
  List<AdminUser> get users => List<AdminUser>.unmodifiable(_users);
  List<AdminReport> get reports => List<AdminReport>.unmodifiable(_reports);
  List<AdminAnnouncement> get announcements => List<AdminAnnouncement>.unmodifiable(_announcements);
  List<AdminAuditEntry> get audit => List<AdminAuditEntry>.unmodifiable(_audit);

  // ── التحميل والحفظ ──────────────────────────────────────────────────────

  Future<void> _loadAll() async {
    final p = _prefs;
    if (p == null) {
      _seedDemoData();
      _loaded = true;
      return;
    }
    List<T> decode<T>(String key, T Function(Map<String, dynamic>) fromJson) {
      final raw = p.getString(key);
      if (raw == null || raw.isEmpty) return <T>[];
      try {
        final list = jsonDecode(raw) as List;
        return list
            .whereType<Map>()
            .map((e) => fromJson(Map<String, dynamic>.from(e)))
            .toList();
      } catch (_) {
        return <T>[];
      }
    }

    _series = decode<AdminSeries>(_kSeries, AdminSeries.fromJson);
    _chapters = decode<AdminChapter>(_kChapters, AdminChapter.fromJson);
    _users = decode<AdminUser>(_kUsers, AdminUser.fromJson);
    _reports = decode<AdminReport>(_kReports, AdminReport.fromJson);
    _announcements = decode<AdminAnnouncement>(_kAnnouncements, AdminAnnouncement.fromJson);
    _audit = decode<AdminAuditEntry>(_kAudit, AdminAuditEntry.fromJson);

    if (_series.isEmpty && _users.isEmpty && !(p.getBool(_kSeeded) ?? false)) {
      _seedDemoData();
      await _saveAll();
    }
    _loaded = true;
  }

  Future<void> _saveAll() async {
    final p = _prefs;
    if (p == null) return;
    String encode<T>(List<T> items) =>
        jsonEncode(items.map((e) => (e as dynamic).toJson() as Map<String, dynamic>).toList());
    await p.setString(_kSeries, encode(_series));
    await p.setString(_kChapters, encode(_chapters));
    await p.setString(_kUsers, encode(_users));
    await p.setString(_kReports, encode(_reports));
    await p.setString(_kAnnouncements, encode(_announcements));
    await p.setString(_kAudit, encode(_audit));
    await p.setBool(_kSeeded, true);
  }

  Future<void> _saveAndNotify() async {
    await _saveAll();
    notifyListeners();
  }

  // ── البيانات التجريبية ──────────────────────────────────────────────────

  void _seedDemoData() {
    final now = DateTime.now();
    _series = MockData.all.map(AdminSeries.fromSeries).toList();
    _chapters = [];
    for (final s in _series) {
      final count = s.chapters > 12 ? 8 : (s.chapters > 4 ? 5 : math.max(1, s.chapters));
      for (var n = 1; n <= count; n++) {
        final created = now.subtract(Duration(days: (count - n) * 3 + 2));
        final status = n <= count - 1
            ? AdminChapterStatus.published
            : (n == count ? AdminChapterStatus.draft : AdminChapterStatus.published);
        _chapters.add(AdminChapter(
          id: 'ch_${s.id}_$n',
          seriesId: s.id,
          number: n,
          title: n == 1 ? 'البداية' : '',
          pages: List<String>.generate(12, (i) => 'https://example.com/${s.id}/$n/p${i + 1}.jpg'),
          status: status,
          createdAt: created,
          updatedAt: created,
          views: (s.views ~/ s.chapters) + n * 37,
        ));
      }
    }
    // فصل مجدول حان وقته + فصل مجدول مستقبلي لاختبار scheduleDue.
    if (_series.isNotEmpty) {
      final s0 = _series.first;
      _chapters.add(AdminChapter(
        id: 'ch_${s0.id}_due',
        seriesId: s0.id,
        number: 999,
        title: 'فصل خاص مجدول',
        pages: List<String>.generate(5, (i) => 'https://example.com/${s0.id}/due/p${i + 1}.jpg'),
        status: AdminChapterStatus.scheduled,
        publishAt: now.subtract(const Duration(hours: 2)),
        createdAt: now.subtract(const Duration(days: 1)),
        updatedAt: now.subtract(const Duration(hours: 2)),
      ));
      _chapters.add(AdminChapter(
        id: 'ch_${s0.id}_future',
        seriesId: s0.id,
        number: 1000,
        title: 'فصل قادم',
        pages: List<String>.generate(5, (i) => 'https://example.com/${s0.id}/future/p${i + 1}.jpg'),
        status: AdminChapterStatus.scheduled,
        publishAt: now.add(const Duration(days: 3)),
        createdAt: now.subtract(const Duration(days: 1)),
        updatedAt: now.subtract(const Duration(hours: 1)),
      ));
    }
    _users = _demoUsers(now);
    _reports = _demoReports(now);
    _announcements = _demoAnnouncements(now);
    _audit = [
      AdminAuditEntry(
        id: _id('au'),
        actorId: 'admin',
        actorName: 'أدمن',
        action: AdminAuditAction.login,
        targetType: 'session',
        targetId: 'admin',
        detail: 'دخول تجريبي إلى لوحة الأدمن',
        at: now.subtract(const Duration(hours: 3)),
      ),
      AdminAuditEntry(
        id: _id('au'),
        actorId: 'admin',
        actorName: 'أدمن',
        action: AdminAuditAction.create,
        targetType: 'series',
        targetId: _series.isNotEmpty ? _series.first.id : '',
        detail: 'زرع بيانات تجريبية للوحة الأدمن',
        at: now.subtract(const Duration(days: 1)),
      ),
    ];
  }

  List<AdminUser> _demoUsers(DateTime now) {
    const names = [
      ('ليلى حسن', 'layla@example.com', AdminRole.user, true, 214, 48200),
      ('عمر فاروق', 'omar@example.com', AdminRole.translator, true, 156, 36400),
      ('سارة أحمد', 'sara@example.com', AdminRole.moderator, true, 189, 52100),
      ('يوسف علي', 'youssef@example.com', AdminRole.user, false, 96, 19800),
      ('مريم خالد', 'mariam@example.com', AdminRole.translator, true, 143, 41200),
      ('كريم سامي', 'karim@example.com', AdminRole.user, false, 54, 12300),
      ('نور الدين', 'nour@example.com', AdminRole.user, false, 231, 58900),
      ('هدى محمود', 'hoda@example.com', AdminRole.admin, true, 178, 44700),
      ('طارق زيدان', 'tarek@example.com', AdminRole.user, false, 12, 2400),
      ('أسماء جابر', 'asma@example.com', AdminRole.user, false, 88, 20100),
      ('بلال رشيد', 'bilal@example.com', AdminRole.user, false, 31, 7200),
      ('جنى عادل', 'jana@example.com', AdminRole.user, false, 167, 39600),
    ];
    final users = <AdminUser>[];
    for (var i = 0; i < names.length; i++) {
      final (name, email, role, verified, read, seconds) = names[i];
      users.add(AdminUser(
        id: 'u_${i + 1}',
        name: name,
        email: email,
        role: role,
        status: i == 8 ? AdminUserStatus.suspended : AdminUserStatus.active,
        joinedAt: now.subtract(Duration(days: 10 + i * 17)),
        lastActiveAt: now.subtract(Duration(hours: 2 + i * 5)),
        chaptersRead: read,
        readingSeconds: seconds,
        isVerified: verified,
        bannedReason: i == 8 ? 'نشر روابط إعلانية متكررة في التعليقات' : null,
      ));
    }
    return users;
  }

  List<AdminReport> _demoReports(DateTime now) {
    final s = _series;
    String sid(int i) => s.isEmpty ? 'm1' : s[i % s.length].id;
    String stitle(int i) => s.isEmpty ? 'عمل تجريبي' : s[i % s.length].title;
    return [
      AdminReport(
        id: 'rep_1',
        targetType: AdminReportTarget.chapter,
        targetId: 'ch_${sid(0)}_3',
        targetTitle: 'الفصل 3 — ${stitle(0)}',
        reason: AdminReportReason.wrongContent,
        reporterId: 'u_1',
        reporterName: 'ليلى حسن',
        description: 'الصفحات من 5 إلى 8 مكررة من الفصل السابق.',
        status: AdminReportStatus.pending,
        createdAt: now.subtract(const Duration(hours: 5)),
      ),
      AdminReport(
        id: 'rep_2',
        targetType: AdminReportTarget.comment,
        targetId: 'cmt_441',
        targetTitle: 'تعليق على ${stitle(1)}',
        reason: AdminReportReason.harassment,
        reporterId: 'u_4',
        reporterName: 'يوسف علي',
        description: 'شتائم موجّهة لمترجم العمل في التعليقات.',
        status: AdminReportStatus.reviewing,
        createdAt: now.subtract(const Duration(hours: 11)),
      ),
      AdminReport(
        id: 'rep_3',
        targetType: AdminReportTarget.series,
        targetId: sid(2),
        targetTitle: stitle(2),
        reason: AdminReportReason.copyright,
        reporterId: 'u_2',
        reporterName: 'عمر فاروق',
        description: 'غلاف العمل منسوخ من سلسلة أخرى منشورة.',
        status: AdminReportStatus.pending,
        createdAt: now.subtract(const Duration(days: 1, hours: 3)),
      ),
      AdminReport(
        id: 'rep_4',
        targetType: AdminReportTarget.user,
        targetId: 'u_9',
        targetTitle: 'طارق زيدان',
        reason: AdminReportReason.spam,
        reporterId: 'u_7',
        reporterName: 'نور الدين',
        description: 'ينشر روابط خارجية في كل منشور.',
        status: AdminReportStatus.resolved,
        createdAt: now.subtract(const Duration(days: 2)),
        resolvedAt: now.subtract(const Duration(days: 1)),
        resolutionNote: 'أُوقف الحساب 7 أيام وحُذفت الروابط.',
        moderatorId: 'admin',
      ),
      AdminReport(
        id: 'rep_5',
        targetType: AdminReportTarget.chapter,
        targetId: 'ch_${sid(3)}_1',
        targetTitle: 'الفصل 1 — ${stitle(3)}',
        reason: AdminReportReason.inappropriate,
        reporterId: 'u_10',
        reporterName: 'أسماء جابر',
        description: 'صفحة تحتوي محتوى غير مناسب للفئة العمرية.',
        status: AdminReportStatus.pending,
        createdAt: now.subtract(const Duration(days: 2, hours: 6)),
      ),
      AdminReport(
        id: 'rep_6',
        targetType: AdminReportTarget.series,
        targetId: sid(4),
        targetTitle: stitle(4),
        reason: AdminReportReason.other,
        reporterId: 'u_12',
        reporterName: 'جنى عادل',
        description: 'عنوان العمل مكتوب بشكل خاطئ في صفحة التفاصيل.',
        status: AdminReportStatus.rejected,
        createdAt: now.subtract(const Duration(days: 4)),
        resolvedAt: now.subtract(const Duration(days: 3)),
        resolutionNote: 'العنوان صحيح ومطابق للمصدر الرسمي.',
        moderatorId: 'admin',
      ),
    ];
  }

  List<AdminAnnouncement> _demoAnnouncements(DateTime now) {
    return [
      AdminAnnouncement(
        id: 'an_1',
        title: 'تحديث كبير قادم',
        body: 'نعمل على قارئ جديد أسرع مع وضع ليلي محسّن وإيماءات جديدة. شاركونا رأيكم في التعليقات!',
        target: AdminAnnouncementTarget.all,
        createdAt: now.subtract(const Duration(days: 2)),
        active: true,
        priority: 2,
        views: 1840,
      ),
      AdminAnnouncement(
        id: 'an_2',
        title: 'للمترجمين: دليل رفع الفصول',
        body: 'تأكدوا من أن روابط الصفحات تبدأ بـ https وأن ترتيبها صحيح قبل النشر. الفصول المجدولة تُنشر تلقائياً في موعدها.',
        target: AdminAnnouncementTarget.translators,
        createdAt: now.subtract(const Duration(days: 5)),
        active: true,
        priority: 1,
        views: 96,
      ),
      AdminAnnouncement(
        id: 'an_3',
        title: 'صيانة مجدولة',
        body: 'ستتوقف الخدمة لساعة واحدة فجر الجمعة لتحسين الخوادم. فصولكم المحفوظة لن تتأثر.',
        target: AdminAnnouncementTarget.all,
        createdAt: now.subtract(const Duration(days: 6)),
        publishAt: now.add(const Duration(days: 2)),
        active: true,
        priority: 0,
        views: 0,
      ),
    ];
  }

  // ── التدقيق ─────────────────────────────────────────────────────────────

  void _log(AdminAuditAction action, String targetType, String targetId, String detail) {
    _audit.insert(
      0,
      AdminAuditEntry(
        id: _id('au'),
        actorId: 'admin',
        actorName: 'أدمن',
        action: action,
        targetType: targetType,
        targetId: targetId,
        detail: detail,
        at: DateTime.now(),
      ),
    );
    if (_audit.length > kAdminAuditLimit) {
      _audit = _audit.sublist(0, kAdminAuditLimit);
    }
  }

  List<AdminAuditEntry> recentAudit({int limit = 20}) => _audit.take(limit).toList();

  List<AdminAuditEntry> auditFor(String targetType, String targetId) =>
      _audit.where((e) => e.targetType == targetType && e.targetId == targetId).toList();

  // ── الأعمال: بحث وفلترة ────────────────────────────────────────────────

  List<String> get allTypes => _series.map((s) => s.type).toSet().toList()..sort();
  List<String> get allGenres => _series.expand((s) => s.genres).toSet().toList()..sort();

  AdminSeries? seriesById(String id) {
    for (final s in _series) {
      if (s.id == id) return s;
    }
    return null;
  }

  List<AdminSeries> searchSeries(AdminSeriesFilter filter) {
    final q = filter.query.trim().toLowerCase();
    var list = _series.where((s) {
      if (filter.type != null && s.type != filter.type) return false;
      if (filter.state != null && s.state != filter.state) return false;
      if (filter.genre != null && !s.genres.contains(filter.genre)) return false;
      if (filter.onlyFeatured && !s.featured) return false;
      if (filter.onlyNew && !s.isNew) return false;
      if (q.isEmpty) return true;
      return s.title.toLowerCase().contains(q) ||
          s.synopsis.toLowerCase().contains(q) ||
          s.genres.any((g) => g.toLowerCase().contains(q)) ||
          s.id.toLowerCase() == q;
    }).toList();
    switch (filter.sort) {
      case AdminSeriesSort.newest:
        list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      case AdminSeriesSort.title:
        list.sort((a, b) => a.title.compareTo(b.title));
      case AdminSeriesSort.views:
        list.sort((a, b) => b.views.compareTo(a.views));
      case AdminSeriesSort.rating:
        list.sort((a, b) => b.rating.compareTo(a.rating));
      case AdminSeriesSort.chapters:
        list.sort((a, b) => b.chapters.compareTo(a.chapters));
    }
    return list.take(kAdminSearchLimit).toList();
  }

  // ── الأعمال: CRUD ───────────────────────────────────────────────────────

  Future<AdminResult> addSeries(AdminSeries series) async {
    final err = series.validate();
    if (err != null) return AdminResult.fail(err);
    if (_series.any((s) => s.id == series.id)) {
      return const AdminResult.fail('عمل بهذا المعرّف موجود بالفعل.');
    }
    _series.insert(0, series);
    _log(AdminAuditAction.create, 'series', series.id, 'أضاف العمل «${series.title}»');
    await _saveAndNotify();
    return AdminResult.ok('أُضيف العمل «${series.title}» بنجاح.');
  }

  Future<AdminResult> updateSeries(AdminSeries series) async {
    final err = series.validate();
    if (err != null) return AdminResult.fail(err);
    final i = _series.indexWhere((s) => s.id == series.id);
    if (i < 0) return const AdminResult.fail('العمل غير موجود.');
    _series[i] = series.copyWith(updatedAt: DateTime.now());
    _log(AdminAuditAction.update, 'series', series.id, 'عدّل العمل «${series.title}»');
    await _saveAndNotify();
    return const AdminResult.ok('حُفظت التعديلات.');
  }

  Future<AdminResult> deleteSeries(String id) async {
    final i = _series.indexWhere((s) => s.id == id);
    if (i < 0) return const AdminResult.fail('العمل غير موجود.');
    final title = _series[i].title;
    final removedChapters = _chapters.where((c) => c.seriesId == id).length;
    _series.removeAt(i);
    _chapters.removeWhere((c) => c.seriesId == id);
    _log(AdminAuditAction.delete, 'series', id, 'حذف العمل «$title» مع $removedChapters فصلاً');
    await _saveAndNotify();
    return AdminResult.ok('حُذف «$title» و$removedChapters فصلاً.');
  }

  Future<AdminResult> setSeriesFeatured(String id, bool featured) async {
    final i = _series.indexWhere((s) => s.id == id);
    if (i < 0) return const AdminResult.fail('العمل غير موجود.');
    _series[i] = _series[i].copyWith(featured: featured, updatedAt: DateTime.now());
    _log(AdminAuditAction.update, 'series', id,
        featured ? 'ثبّت «${_series[i].title}» في الواجهة' : 'أزال تثبيت «${_series[i].title}»');
    await _saveAndNotify();
    return const AdminResult.ok('تم التحديث.');
  }

  // ── الفصول ─────────────────────────────────────────────────────────────

  List<AdminChapter> chaptersOf(String seriesId, {AdminChapterFilter? filter}) {
    var list = _chapters.where((c) => c.seriesId == seriesId).toList();
    if (filter != null) {
      final q = filter.query.trim().toLowerCase();
      list = list.where((c) {
        if (filter.status != null && c.status != filter.status) return false;
        if (filter.onlyDue && !c.scheduleDue) return false;
        if (q.isEmpty) return true;
        return c.displayTitle.toLowerCase().contains(q) || '${c.number}' == q;
      }).toList();
    }
    list.sort((a, b) => b.number.compareTo(a.number));
    return list;
  }

  AdminChapter? chapterById(String id) {
    for (final c in _chapters) {
      if (c.id == id) return c;
    }
    return null;
  }

  int nextChapterNumber(String seriesId) {
    var max = 0;
    for (final c in _chapters) {
      if (c.seriesId == seriesId && c.number > max && c.number < 900) max = c.number;
    }
    return max + 1;
  }

  /// ينشر كل الفصول المجدولة التي حان وقتها. يُستدعى عند فتح لوحة الأدمن.
  Future<int> publishDueChapters() async {
    var count = 0;
    final now = DateTime.now();
    for (var i = 0; i < _chapters.length; i++) {
      final c = _chapters[i];
      if (c.status == AdminChapterStatus.scheduled &&
          c.publishAt != null &&
          !c.publishAt!.isAfter(now)) {
        _chapters[i] = c.copyWith(
          status: AdminChapterStatus.published,
          clearPublishAt: true,
          updatedAt: now,
        );
        count++;
      }
    }
    if (count > 0) {
      _log(AdminAuditAction.publish, 'chapter', 'due', 'نشر تلقائي لـ $count فصل مجدول حان وقته');
      await _saveAndNotify();
    }
    return count;
  }

  Future<AdminResult> addChapter(AdminChapter chapter) async {
    final err = chapter.validate();
    if (err != null) return AdminResult.fail(err);
    if (_chapters.any((c) => c.seriesId == chapter.seriesId && c.number == chapter.number)) {
      return AdminResult.fail('الفصل ${chapter.number} موجود بالفعل في هذا العمل.');
    }
    _chapters.add(chapter);
    final s = seriesById(chapter.seriesId);
    if (s != null) {
      final maxNumber = _chapters
          .where((c) => c.seriesId == s.id)
          .fold<int>(0, (m, c) => c.number > m && c.number < 900 ? c.number : m);
      _series[_series.indexOf(s)] = s.copyWith(chapters: maxNumber, updatedAt: DateTime.now());
    }
    _log(AdminAuditAction.create, 'chapter', chapter.id,
        'أضاف ${chapter.displayTitle} إلى «${s?.title ?? chapter.seriesId}»');
    await _saveAndNotify();
    return const AdminResult.ok('أُضيف الفصل بنجاح.');
  }

  Future<AdminResult> updateChapter(AdminChapter chapter) async {
    final err = chapter.validate();
    if (err != null) return AdminResult.fail(err);
    final i = _chapters.indexWhere((c) => c.id == chapter.id);
    if (i < 0) return const AdminResult.fail('الفصل غير موجود.');
    _chapters[i] = chapter.copyWith(updatedAt: DateTime.now());
    _log(AdminAuditAction.update, 'chapter', chapter.id, 'عدّل ${chapter.displayTitle}');
    await _saveAndNotify();
    return const AdminResult.ok('حُفظت التعديلات.');
  }

  Future<AdminResult> deleteChapter(String id) async {
    final i = _chapters.indexWhere((c) => c.id == id);
    if (i < 0) return const AdminResult.fail('الفصل غير موجود.');
    final title = _chapters[i].displayTitle;
    _chapters.removeAt(i);
    _log(AdminAuditAction.delete, 'chapter', id, 'حذف $title');
    await _saveAndNotify();
    return AdminResult.ok('حُذف $title.');
  }

  Future<AdminResult> setChapterStatus(String id, AdminChapterStatus status, {DateTime? publishAt}) async {
    final i = _chapters.indexWhere((c) => c.id == id);
    if (i < 0) return const AdminResult.fail('الفصل غير موجود.');
    var next = _chapters[i].copyWith(status: status, updatedAt: DateTime.now());
    if (status == AdminChapterStatus.scheduled) {
      if (publishAt == null) return const AdminResult.fail('حدّد موعد النشر للفصل المجدول.');
      next = next.copyWith(publishAt: publishAt);
    } else {
      next = next.copyWith(clearPublishAt: true);
    }
    final err = next.validate();
    if (err != null) return AdminResult.fail(err);
    _chapters[i] = next;
    final action = switch (status) {
      AdminChapterStatus.published => AdminAuditAction.publish,
      AdminChapterStatus.hidden => AdminAuditAction.hide,
      AdminChapterStatus.scheduled => AdminAuditAction.schedule,
      AdminChapterStatus.draft => AdminAuditAction.update,
    };
    _log(action, 'chapter', id, '${status.label}: ${next.displayTitle}');
    await _saveAndNotify();
    return AdminResult.ok('أصبح الفصل «${status.label}».');
  }

  // ── المستخدمون ─────────────────────────────────────────────────────────

  AdminUser? userById(String id) {
    for (final u in _users) {
      if (u.id == id) return u;
    }
    return null;
  }

  List<AdminUser> searchUsers(AdminUserFilter filter) {
    final q = filter.query.trim().toLowerCase();
    var list = _users.where((u) {
      if (filter.role != null && u.role != filter.role) return false;
      if (filter.status != null && u.status != filter.status) return false;
      if (filter.onlyNew && !u.isNewUser) return false;
      if (filter.onlyActiveRecently && !u.isActiveRecently) return false;
      if (q.isEmpty) return true;
      return u.name.toLowerCase().contains(q) ||
          u.email.toLowerCase().contains(q) ||
          u.id.toLowerCase() == q;
    }).toList();
    switch (filter.sort) {
      case AdminUserSort.newest:
        list.sort((a, b) => b.joinedAt.compareTo(a.joinedAt));
      case AdminUserSort.name:
        list.sort((a, b) => a.name.compareTo(b.name));
      case AdminUserSort.mostRead:
        list.sort((a, b) => b.chaptersRead.compareTo(a.chaptersRead));
      case AdminUserSort.lastActive:
        list.sort((a, b) => b.lastActiveAt.compareTo(a.lastActiveAt));
    }
    return list.take(kAdminSearchLimit).toList();
  }

  Future<AdminResult> addUser(AdminUser user) async {
    final err = user.validate();
    if (err != null) return AdminResult.fail(err);
    if (_users.any((u) => u.email.toLowerCase() == user.email.toLowerCase())) {
      return const AdminResult.fail('يوجد مستخدم بهذا البريد بالفعل.');
    }
    if (_users.any((u) => u.id == user.id)) {
      return const AdminResult.fail('يوجد مستخدم بهذا المعرّف بالفعل.');
    }
    _users.insert(0, user);
    _log(AdminAuditAction.create, 'user', user.id, 'أضاف المستخدم «${user.name}» (${user.role.label})');
    await _saveAndNotify();
    return AdminResult.ok('أُضيف «${user.name}» بنجاح.');
  }

  Future<AdminResult> updateUser(AdminUser user) async {
    final err = user.validate();
    if (err != null) return AdminResult.fail(err);
    final i = _users.indexWhere((u) => u.id == user.id);
    if (i < 0) return const AdminResult.fail('المستخدم غير موجود.');
    _users[i] = user;
    _log(AdminAuditAction.update, 'user', user.id, 'عدّل بيانات «${user.name}»');
    await _saveAndNotify();
    return const AdminResult.ok('حُفظت التعديلات.');
  }

  Future<AdminResult> setUserRole(String id, AdminRole role) async {
    final i = _users.indexWhere((u) => u.id == id);
    if (i < 0) return const AdminResult.fail('المستخدم غير موجود.');
    if (_users[i].role == role) return const AdminResult.ok('الدور كما هو.');
    _users[i] = _users[i].copyWith(role: role);
    _log(AdminAuditAction.role, 'user', id, 'غيّر دور «${_users[i].name}» إلى ${role.label}');
    await _saveAndNotify();
    return AdminResult.ok('أصبح «${_users[i].name}» ${role.label}.');
  }

  Future<AdminResult> setUserStatus(String id, AdminUserStatus status, {String? reason}) async {
    final i = _users.indexWhere((u) => u.id == id);
    if (i < 0) return const AdminResult.fail('المستخدم غير موجود.');
    if (status == AdminUserStatus.banned && (reason ?? '').trim().isEmpty) {
      return const AdminResult.fail('اكتب سبب الحظر.');
    }
    final action = switch (status) {
      AdminUserStatus.banned => AdminAuditAction.ban,
      AdminUserStatus.suspended => AdminAuditAction.suspend,
      AdminUserStatus.active => AdminAuditAction.unban,
      AdminUserStatus.pending => AdminAuditAction.update,
    };
    _users[i] = _users[i].copyWith(
      status: status,
      bannedReason: status == AdminUserStatus.banned ? reason : null,
      clearBannedReason: status != AdminUserStatus.banned,
    );
    _log(action, 'user', id, '«${_users[i].name}» → ${status.label}${reason == null ? '' : ' — $reason'}');
    await _saveAndNotify();
    return AdminResult.ok('أصبحت حالة «${_users[i].name}»: ${status.label}.');
  }

  Future<AdminResult> toggleUserVerified(String id) async {
    final i = _users.indexWhere((u) => u.id == id);
    if (i < 0) return const AdminResult.fail('المستخدم غير موجود.');
    _users[i] = _users[i].copyWith(isVerified: !_users[i].isVerified);
    _log(AdminAuditAction.update, 'user', id,
        _users[i].isVerified ? 'وثّق حساب «${_users[i].name}»' : 'ألغى توثيق «${_users[i].name}»');
    await _saveAndNotify();
    return const AdminResult.ok('تم التحديث.');
  }

  // ── البلاغات (الإشراف) ─────────────────────────────────────────────────

  List<AdminReport> reportsFiltered({AdminReportStatus? status, AdminReportReason? reason}) {
    var list = _reports.toList();
    if (status != null) list = list.where((r) => r.status == status).toList();
    if (reason != null) list = list.where((r) => r.reason == reason).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  AdminReport? reportById(String id) {
    for (final r in _reports) {
      if (r.id == id) return r;
    }
    return null;
  }

  Future<AdminResult> setReportStatus(String id, AdminReportStatus status, {String? note}) async {
    final i = _reports.indexWhere((r) => r.id == id);
    if (i < 0) return const AdminResult.fail('البلاغ غير موجود.');
    final now = DateTime.now();
    _reports[i] = _reports[i].copyWith(
      status: status,
      resolvedAt: status.isOpen ? null : now,
      resolutionNote: note,
      moderatorId: 'admin',
    );
    final action = status == AdminReportStatus.rejected ? AdminAuditAction.reject : AdminAuditAction.resolve;
    _log(action, 'report', id, 'بلاغ ${_reports[i].targetTitle} → ${status.label}');
    await _saveAndNotify();
    return AdminResult.ok('أصبح البلاغ «${status.label}».');
  }

  Future<AdminResult> addReport(AdminReport report) async {
    _reports.insert(0, report);
    _log(AdminAuditAction.create, 'report', report.id, 'بلاغ جديد على ${report.targetTitle}');
    await _saveAndNotify();
    return const AdminResult.ok('سُجّل البلاغ.');
  }

  // ── الإعلانات ──────────────────────────────────────────────────────────

  List<AdminAnnouncement> announcementsSorted() {
    final list = _announcements.toList();
    list.sort((a, b) {
      final live = (b.isLive ? 1 : 0) - (a.isLive ? 1 : 0);
      if (live != 0) return live;
      final pr = b.priority.compareTo(a.priority);
      if (pr != 0) return pr;
      return b.createdAt.compareTo(a.createdAt);
    });
    return list;
  }

  AdminAnnouncement? announcementById(String id) {
    for (final a in _announcements) {
      if (a.id == id) return a;
    }
    return null;
  }

  Future<AdminResult> addAnnouncement(AdminAnnouncement a) async {
    final err = a.validate();
    if (err != null) return AdminResult.fail(err);
    _announcements.insert(0, a);
    _log(AdminAuditAction.announce, 'announcement', a.id, 'أضاف الإعلان «${a.title}»');
    await _saveAndNotify();
    return const AdminResult.ok('نُشر الإعلان.');
  }

  Future<AdminResult> updateAnnouncement(AdminAnnouncement a) async {
    final err = a.validate();
    if (err != null) return AdminResult.fail(err);
    final i = _announcements.indexWhere((x) => x.id == a.id);
    if (i < 0) return const AdminResult.fail('الإعلان غير موجود.');
    _announcements[i] = a;
    _log(AdminAuditAction.update, 'announcement', a.id, 'عدّل الإعلان «${a.title}»');
    await _saveAndNotify();
    return const AdminResult.ok('حُفظت التعديلات.');
  }

  Future<AdminResult> deleteAnnouncement(String id) async {
    final i = _announcements.indexWhere((a) => a.id == id);
    if (i < 0) return const AdminResult.fail('الإعلان غير موجود.');
    final title = _announcements[i].title;
    _announcements.removeAt(i);
    _log(AdminAuditAction.delete, 'announcement', id, 'حذف الإعلان «$title»');
    await _saveAndNotify();
    return const AdminResult.ok('حُذف الإعلان.');
  }

  Future<AdminResult> toggleAnnouncement(String id, bool active) async {
    final i = _announcements.indexWhere((a) => a.id == id);
    if (i < 0) return const AdminResult.fail('الإعلان غير موجود.');
    _announcements[i] = _announcements[i].copyWith(active: active);
    _log(AdminAuditAction.update, 'announcement', id,
        active ? 'فعّل الإعلان «${_announcements[i].title}»' : 'أوقف الإعلان «${_announcements[i].title}»');
    await _saveAndNotify();
    return const AdminResult.ok('تم التحديث.');
  }

  // ── الإحصاءات ──────────────────────────────────────────────────────────

  AdminStats computeStats() {
    final now = DateTime.now();
    final topSeries = _series.toList()..sort((a, b) => b.views.compareTo(a.views));
    final topChapters = _chapters.toList()..sort((a, b) => b.views.compareTo(a.views));
    final views14 = List<int>.generate(14, (i) {
      // توزيع تقديري للمشاهدات على آخر 14 يوماً (بيانات تجريبية محلية).
      final day = now.subtract(Duration(days: 13 - i));
      var sum = 0;
      for (final s in _series) {
        sum += (s.views ~/ 30) + ((s.seed + day.day * 13) % 400);
      }
      return sum;
    });
    final byType = <String, int>{};
    final byState = <String, int>{};
    for (final s in _series) {
      byType[s.type] = (byType[s.type] ?? 0) + 1;
      byState[s.state.label] = (byState[s.state.label] ?? 0) + 1;
    }
    final byRole = <String, int>{};
    for (final u in _users) {
      byRole[u.role.label] = (byRole[u.role.label] ?? 0) + 1;
    }
    final byReason = <String, int>{};
    for (final r in _reports) {
      byReason[r.reason.label] = (byReason[r.reason.label] ?? 0) + 1;
    }
    return AdminStats(
      totalSeries: _series.length,
      totalChapters: _chapters.length,
      publishedChapters: _chapters.where((c) => c.status == AdminChapterStatus.published).length,
      draftChapters: _chapters.where((c) => c.status == AdminChapterStatus.draft).length,
      scheduledChapters: _chapters.where((c) => c.status == AdminChapterStatus.scheduled).length,
      dueChapters: _chapters.where((c) => c.scheduleDue).length,
      totalUsers: _users.length,
      activeUsers: _users.where((u) => u.isActiveRecently).length,
      newUsers30d: _users.where((u) => u.isNewUser).length,
      totalViews: _series.fold<int>(0, (a, s) => a + s.views),
      openReports: _reports.where((r) => r.isOpen).length,
      liveAnnouncements: _announcements.where((a) => a.isLive).length,
      topSeries: topSeries.take(5).toList(),
      topChapters: topChapters.take(5).toList(),
      viewsLast14Days: views14,
      seriesByType: byType,
      seriesByState: byState,
      usersByRole: byRole,
      reportsByReason: byReason,
      chaptersLast7Days: _chapters
          .where((c) => now.difference(c.createdAt).inDays < 7)
          .length,
    );
  }

  // ── بحث شامل ومهام تحتاج انتباهاً ───────────────────────────────────────

  /// بحث شامل في كل مجموعات الأدمن دفعة واحدة (للبحث السريع من لوحة التحكم).
  AdminGlobalSearch globalSearch(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return const AdminGlobalSearch();
    final series = _series
        .where((s) => s.title.toLowerCase().contains(q) || s.synopsis.toLowerCase().contains(q))
        .take(5)
        .toList();
    final chapters = _chapters
        .where((c) => c.displayTitle.toLowerCase().contains(q))
        .take(5)
        .toList();
    final users = _users
        .where((u) => u.name.toLowerCase().contains(q) || u.email.toLowerCase().contains(q))
        .take(5)
        .toList();
    final reports = _reports
        .where((r) => r.targetTitle.toLowerCase().contains(q) || r.description.toLowerCase().contains(q))
        .take(5)
        .toList();
    return AdminGlobalSearch(series: series, chapters: chapters, users: users, reports: reports);
  }

  /// سجل التدقيق بفلترة: إجراء، نص بحث، أو منذ تاريخ.
  List<AdminAuditEntry> auditFiltered({AdminAuditAction? action, String query = '', DateTime? since}) {
    final q = query.trim().toLowerCase();
    var list = _audit.where((e) {
      if (action != null && e.action != action) return false;
      if (since != null && e.at.isBefore(since)) return false;
      if (q.isEmpty) return true;
      return e.detail.toLowerCase().contains(q) ||
          e.actorName.toLowerCase().contains(q) ||
          e.targetId.toLowerCase().contains(q);
    }).toList();
    list.sort((a, b) => b.at.compareTo(a.at));
    return list;
  }

  /// ينسخ عملاً كاملاً (مع فصوله) تحت عنوان جديد.
  Future<AdminResult> duplicateSeries(String id) async {
    final s = seriesById(id);
    if (s == null) return const AdminResult.fail('العمل غير موجود.');
    final copy = AdminSeries(
      id: _id('sr'),
      title: '${s.title} (نسخة)',
      cover: s.cover,
      type: s.type,
      status: 'مستمر',
      genres: List<String>.from(s.genres),
      synopsis: s.synopsis,
      chapters: 0,
      rating: 0,
      views: 0,
      year: s.year,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    final err = copy.validate();
    if (err != null) return AdminResult.fail(err);
    _series.insert(0, copy);
    var copied = 0;
    for (final c in chaptersOf(id)) {
      _chapters.add(AdminChapter(
        id: _id('ch'),
        seriesId: copy.id,
        number: c.number,
        title: c.title,
        pages: List<String>.from(c.pages),
        status: AdminChapterStatus.draft,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ));
      copied++;
    }
    _series[0] = copy.copyWith(chapters: copied, updatedAt: DateTime.now());
    _log(AdminAuditAction.create, 'series', copy.id, 'نسخ العمل «${s.title}» مع $copied فصلاً');
    await _saveAndNotify();
    return AdminResult.ok('نُسخ «${s.title}» مع $copied فصلاً (كمسودات).');
  }

  /// يعالج عدة بلاغات دفعة واحدة بملاحظة واحدة.
  Future<AdminResult> bulkResolveReports(List<String> ids, {String note = 'عولج ضمن مراجعة جماعية.'}) async {
    var count = 0;
    final now = DateTime.now();
    for (var i = 0; i < _reports.length; i++) {
      final r = _reports[i];
      if (ids.contains(r.id) && r.isOpen) {
        _reports[i] = r.copyWith(
          status: AdminReportStatus.resolved,
          resolvedAt: now,
          resolutionNote: note,
          moderatorId: 'admin',
        );
        count++;
      }
    }
    if (count == 0) return const AdminResult.fail('لا بلاغات مفتوحة ضمن المحدد.');
    _log(AdminAuditAction.resolve, 'report', 'bulk', 'عالج $count بلاغاً دفعة واحدة');
    await _saveAndNotify();
    return AdminResult.ok('عولج $count بلاغاً.');
  }

  /// عناصر تحتاج انتباه الأدمن الآن: فصول حان وقتها، مسودات قديمة، بلاغات مفتوحة.
  List<AdminAttentionItem> attentionItems() {
    final now = DateTime.now();
    final items = <AdminAttentionItem>[];
    final due = _chapters.where((c) => c.scheduleDue).toList();
    if (due.isNotEmpty) {
      items.add(AdminAttentionItem(
        kind: AdminAttentionKind.dueChapters,
        title: '${due.length} فصل مجدول حان وقت نشرها',
        subtitle: due.take(3).map((c) => c.displayTitle).join('، '),
        count: due.length,
      ));
    }
    final oldDrafts = _chapters
        .where((c) =>
            c.status == AdminChapterStatus.draft && now.difference(c.updatedAt).inDays >= 7)
        .toList();
    if (oldDrafts.isNotEmpty) {
      items.add(AdminAttentionItem(
        kind: AdminAttentionKind.oldDrafts,
        title: '${oldDrafts.length} مسودة لم تُحدَّث منذ أسبوع أو أكثر',
        subtitle: 'راجعها: انشرها أو احذفها.',
        count: oldDrafts.length,
      ));
    }
    final open = _reports.where((r) => r.isOpen).length;
    if (open > 0) {
      items.add(AdminAttentionItem(
        kind: AdminAttentionKind.openReports,
        title: '$open بلاغ مفتوح بانتظار المراجعة',
        subtitle: 'ابدأ بالأقدم والأخطر.',
        count: open,
      ));
    }
    final suspended = _users.where((u) => u.status == AdminUserStatus.suspended).length;
    if (suspended > 0) {
      items.add(AdminAttentionItem(
        kind: AdminAttentionKind.suspendedUsers,
        title: '$suspended مستخدم موقوف مؤقتاً',
        subtitle: 'راجع حالات الإيقاف دورياً.',
        count: suspended,
      ));
    }
    return items;
  }

  // ── تصدير واستيراد وإعادة تعيين ─────────────────────────────────────────

  String exportAllJson() {
    String encode<T>(List<T> items) =>
        jsonEncode(items.map((e) => (e as dynamic).toJson() as Map<String, dynamic>).toList());
    return jsonEncode({
      'app': 'senok-admin',
      'version': 1,
      'exported_at': DateTime.now().toIso8601String(),
      'series': jsonDecode(encode(_series)),
      'chapters': jsonDecode(encode(_chapters)),
      'users': jsonDecode(encode(_users)),
      'reports': jsonDecode(encode(_reports)),
      'announcements': jsonDecode(encode(_announcements)),
      'audit': jsonDecode(encode(_audit)),
    });
  }

  /// يستورد ملفاً مصدّراً من [exportAllJson]. يعيد عدد العناصر المستوردة.
  Future<AdminResult> importAllJson(String raw) async {
    late Map<String, dynamic> root;
    try {
      root = Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return const AdminResult.fail('الملف ليس JSON صالحاً.');
    }
    if (root['app'] != 'senok-admin') {
      return const AdminResult.fail('هذا الملف ليس تصديراً من لوحة أدمن Senok.');
    }
    List<T> decode<T>(String key, T Function(Map<String, dynamic>) fromJson) {
      final v = root[key];
      if (v is! List) return <T>[];
      return v.whereType<Map>().map((e) => fromJson(Map<String, dynamic>.from(e))).toList();
    }

    final series = decode<AdminSeries>('series', AdminSeries.fromJson);
    final chapters = decode<AdminChapter>('chapters', AdminChapter.fromJson);
    final users = decode<AdminUser>('users', AdminUser.fromJson);
    final reports = decode<AdminReport>('reports', AdminReport.fromJson);
    final announcements = decode<AdminAnnouncement>('announcements', AdminAnnouncement.fromJson);
    if (series.isEmpty && chapters.isEmpty && users.isEmpty) {
      return const AdminResult.fail('الملف لا يحتوي أي بيانات.');
    }
    _series = series;
    _chapters = chapters;
    _users = users;
    _reports = reports;
    _announcements = announcements;
    _log(AdminAuditAction.import, 'backup', 'all',
        'استورد ${series.length} عملاً و${chapters.length} فصلاً و${users.length} مستخدماً');
    await _saveAndNotify();
    return AdminResult.ok('استُوردت البيانات بنجاح.');
  }

  /// يعيد زرع البيانات التجريبية من جديد (يمسح كل تعديلات الأدمن).
  Future<void> resetToDemo() async {
    _seedDemoData();
    _log(AdminAuditAction.reset, 'backup', 'all', 'أعاد تعيين لوحة الأدمن إلى البيانات التجريبية');
    await _saveAndNotify();
  }

  /// يمسح سجل التدقيق فقط.
  Future<void> clearAudit() async {
    _audit = [];
    await _saveAndNotify();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  الدخول التجريبي
// ═══════════════════════════════════════════════════════════════════════════

/// دخول الأدمن في الوضع التجريبي.
///
/// لا يوجد خادم `/admin/*` بعد، لذا تُحفظ كلمة المرور محلياً في
/// SharedPreferences. كلمة المرور الافتراضية `admin123` ويجب تغييرها فوراً
/// من شاشة إعدادات الأدمن — وتظهر الشاشات تنبيهاً واضحاً بذلك.
class AdminAuth extends ChangeNotifier {
  AdminAuth._(this._prefs);

  static AdminAuth? _instance;

  static AdminAuth get i {
    final inst = _instance;
    if (inst == null) throw StateError('AdminAuth.load() لم يُستدعَ بعد.');
    return inst;
  }

  static Future<AdminAuth> load() async {
    if (_instance != null) return _instance!;
    final prefs = await SharedPreferences.getInstance();
    final auth = AdminAuth._(prefs);
    _instance = auth;
    return auth;
  }

  /// نسخة في الذاكرة للاختبارات.
  factory AdminAuth.memory() => AdminAuth._(null);

  final SharedPreferences? _prefs;

  /// كلمة المرور في الذاكرة فقط (لنسخة الاختبارات بلا تخزين دائم).
  String? _memoryPass;

  bool _loggedIn = false;
  bool get isLoggedIn => _loggedIn;

  String get _storedPass => _prefs?.getString(_kDemoPass) ?? _memoryPass ?? kAdminDemoPass;

  /// صحيح ما دامت كلمة المرور الافتراضية لم تُغيَّر بعد.
  bool get mustChangePassword => _storedPass == kAdminDemoPass;

  /// يحاول الدخول. يعيد رسالة خطأ عربية أو null عند النجاح.
  Future<String?> login(String username, String password) async {
    final u = username.trim();
    final p = password;
    if (u.isEmpty || p.isEmpty) return 'اكتب اسم المستخدم وكلمة المرور.';
    if (u != kAdminDemoUser) return 'اسم المستخدم غير صحيح.';
    if (p != _storedPass) return 'كلمة المرور غير صحيحة.';
    _loggedIn = true;
    notifyListeners();
    return null;
  }

  void logout() {
    _loggedIn = false;
    notifyListeners();
  }

  /// يغيّر كلمة المرور التجريبية. يعيد رسالة خطأ أو null عند النجاح.
  Future<String?> changePassword(String oldPass, String newPass, String confirm) async {
    if (oldPass != _storedPass) return 'كلمة المرور الحالية غير صحيحة.';
    if (newPass.length < 6) return 'كلمة المرور الجديدة قصيرة جداً (6 أحرف على الأقل).';
    if (newPass.length > 64) return 'كلمة المرور الجديدة طويلة جداً.';
    if (newPass != confirm) return 'تأكيد كلمة المرور غير مطابق.';
    if (newPass == oldPass) return 'كلمة المرور الجديدة مطابقة للقديمة.';
    if (_prefs != null) {
      await _prefs.setString(_kDemoPass, newPass);
    } else {
      _memoryPass = newPass;
    }
    notifyListeners();
    return null;
  }
}
