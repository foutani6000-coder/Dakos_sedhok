import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// سجل التدقيق — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// كل إجراء في لوحة الأدمن يُسجَّل هنا: من فعله، ماذا فعل، متى. مع فلترة
/// حسب نوع الإجراء وبحث نصّي وفلترة زمنية، ونسخ السجل إلى الحافظة.
/// ──────────────────────────────────────────────────────────────────────────

class AdminAuditScreen extends StatefulWidget {
  const AdminAuditScreen({super.key});

  @override
  State<AdminAuditScreen> createState() => _AdminAuditScreenState();
}

class _AdminAuditScreenState extends State<AdminAuditScreen> {
  AdminAuditAction? _action;
  String _query = '';
  int _days = 0; // 0 = كل الفترات
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<AdminAuditEntry> _list() {
    final since = _days == 0 ? null : DateTime.now().subtract(Duration(days: _days));
    return AdminRepository.i.auditFiltered(action: _action, query: _query, since: since);
  }

  Future<void> _copyLog() async {
    final list = _list();
    final buf = StringBuffer('سجل تدقيق لوحة أدمن Senok — ${formatSardDateTime(DateTime.now())}\n');
    for (final e in list) {
      buf.writeln('[${formatSardDateTime(e.at)}] ${e.actorName} — ${e.summary}');
    }
    await Clipboard.setData(ClipboardData(text: buf.toString()));
    if (!mounted) return;
    showAdminSnack(context, 'نُسخ سجل التدقيق (${list.length} إجراء) إلى الحافظة.');
  }

  Future<void> _clear() async {
    final ok = await showAdminConfirm(
      context,
      title: 'مسح سجل التدقيق',
      message: 'سيُمسح سجل إجراءات الأدمن بالكامل.',
      confirmLabel: 'مسح',
      destructive: true,
    );
    if (!ok) return;
    await AdminRepository.i.clearAudit();
    if (!mounted) return;
    showAdminSnack(context, 'مُسح سجل التدقيق.');
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final list = _list();
        final byAction = <AdminAuditAction, int>{};
        for (final e in repo.audit) {
          byAction[e.action] = (byAction[e.action] ?? 0) + 1;
        }
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('سجل التدقيق', style: context.ds(size: 19)),
            actions: [
              IconButton(
                onPressed: _copyLog,
                icon: SIcon(SardIcons.share_rounded, size: 22, color: p.accent),
                tooltip: 'نسخ السجل',
              ),
              IconButton(
                onPressed: _clear,
                icon: SIcon(SardIcons.delete_outline_rounded, size: 22, color: kAdminRed),
                tooltip: 'مسح السجل',
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: AdminSearchField(
                  controller: _searchCtrl,
                  hint: 'ابحث في الإجراءات أو الفاعل…',
                  onChanged: (v) => setState(() => _query = v),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    AdminChip(
                      label: 'كل الفترات',
                      selected: _days == 0,
                      onTap: () => setState(() => _days = 0),
                    ),
                    const SizedBox(width: 8),
                    AdminChip(
                      label: 'آخر 7 أيام',
                      selected: _days == 7,
                      onTap: () => setState(() => _days = 7),
                    ),
                    const SizedBox(width: 8),
                    AdminChip(
                      label: 'آخر 30 يوماً',
                      selected: _days == 30,
                      onTap: () => setState(() => _days = 30),
                    ),
                    const SizedBox(width: 8),
                    PopupMenuButton<AdminAuditAction?>(
                      onSelected: (a) => setState(() => _action = a),
                      itemBuilder: (_) => [
                        const PopupMenuItem(value: null, child: Text('كل الإجراءات')),
                        ...AdminAuditAction.values.map(
                          (a) => PopupMenuItem(
                            value: a,
                            child: Text('${a.label} (${byAction[a] ?? 0})'),
                          ),
                        ),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: p.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _action == null ? p.border : p.accent, width: p.borderW),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SIcon(SardIcons.filter_list_rounded, size: 16, color: p.textDim),
                            const SizedBox(width: 4),
                            Text(
                              _action == null ? 'نوع الإجراء' : _action!.label,
                              style: context.ts(size: 12.5, w: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                child: Row(
                  children: [
                    Text('${list.length} إجراء', style: context.ts(size: 12.5, color: p.textDim)),
                    const Spacer(),
                    if (_action != null || _query.isNotEmpty || _days != 0)
                      TextButton(
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() {
                            _action = null;
                            _query = '';
                            _days = 0;
                          });
                        },
                        child: Text('مسح الفلاتر', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.accent)),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? const AdminEmptyState(
                        icon: SardIcons.history_rounded,
                        title: 'لا إجراءات مطابقة',
                        message: 'جرّب فلتراً آخر أو امسح الفلاتر.',
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: list.length,
                        itemBuilder: (context, i) {
                          final e = list[i];
                          final isFirstOfDay = i == 0 ||
                              formatSardDate(list[i - 1].at) != formatSardDate(e.at);
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (isFirstOfDay)
                                Padding(
                                  padding: const EdgeInsets.only(top: 8, bottom: 6),
                                  child: Text(
                                    formatSardDate(e.at) == formatSardDate(DateTime.now())
                                        ? 'اليوم'
                                        : formatSardDate(e.at),
                                    style: context.ts(size: 12.5, w: FontWeight.w800, color: p.accent),
                                  ),
                                ),
                              _AuditRow(entry: e),
                            ],
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AuditRow extends StatelessWidget {
  const _AuditRow({required this.entry});

  final AdminAuditEntry entry;

  Color _actionColor(AdminAuditAction a) => switch (a) {
        AdminAuditAction.delete || AdminAuditAction.ban => kAdminRed,
        AdminAuditAction.publish || AdminAuditAction.create => kAdminGreen,
        AdminAuditAction.hide || AdminAuditAction.suspend => kAdminAmber,
        AdminAuditAction.login || AdminAuditAction.logout => kAdminBlue,
        AdminAuditAction.reset || AdminAuditAction.reject => kAdminRed,
        _ => kAdminPurple,
      };

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final e = entry;
    final color = _actionColor(e.action);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(p.r(0.6)),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: tint(color, 0.13),
                borderRadius: BorderRadius.circular(9),
              ),
              child: SIcon(SardIcons.history_rounded, size: 16, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.summary, style: context.ts(size: 13, w: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(
                    '${e.actorName} · ${timeAgoArabic(e.at)} · ${formatSardDateTime(e.at)}',
                    style: context.ts(size: 11.5, color: p.textDim),
                  ),
                  if (e.targetType.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      'الهدف: ${e.targetType} — ${e.targetId}',
                      style: context.ts(size: 11.5, color: p.textDim),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
            AdminStatusBadge(label: e.action.label, color: color),
          ],
        ),
      ),
    );
  }
}
