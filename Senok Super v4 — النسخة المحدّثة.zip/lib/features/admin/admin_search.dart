import 'package:flutter/material.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_chapters.dart';
import 'admin_moderation.dart';
import 'admin_repository.dart';
import 'admin_series.dart';
import 'admin_users.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// البحث الشامل في لوحة الأدمن — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// يبحث دفعة واحدة في الأعمال والفصول والمستخدمين والبلاغات، ويعرض النتائج
/// مقسّمة حسب النوع مع الانتقال مباشرة إلى العنصر.
/// ──────────────────────────────────────────────────────────────────────────

class AdminGlobalSearchScreen extends StatefulWidget {
  const AdminGlobalSearchScreen({super.key});

  @override
  State<AdminGlobalSearchScreen> createState() => _AdminGlobalSearchScreenState();
}

class _AdminGlobalSearchScreenState extends State<AdminGlobalSearchScreen> {
  final _ctrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final result = repo.globalSearch(_query);
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('بحث شامل', style: context.ds(size: 19)),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: AdminSearchField(
                  controller: _ctrl,
                  hint: 'ابحث في الأعمال والفصول والمستخدمين والبلاغات…',
                  onChanged: (v) => setState(() => _query = v),
                ),
              ),
              const SizedBox(height: 8),
              if (_query.trim().isEmpty)
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    children: [
                      AdminSectionTitle(
                        title: 'اقتراحات سريعة',
                        subtitle: 'اضغط لعرضها مباشرة',
                        icon: SardIcons.auto_awesome_rounded,
                      ),
                      _QuickAction(
                        icon: SardIcons.gavel_rounded,
                        color: kAdminAmber,
                        title: 'البلاغات المفتوحة',
                        subtitle: '${repo.reports.where((r) => r.isOpen).length} بلاغ بانتظار المراجعة',
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const AdminModerationScreen()),
                        ),
                      ),
                      _QuickAction(
                        icon: SardIcons.watch_later_rounded,
                        color: kAdminBlue,
                        title: 'الفصول المجدولة',
                        subtitle: '${repo.chapters.where((c) => c.status == AdminChapterStatus.scheduled).length} فصل مجدول',
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const AdminChaptersScreen()),
                        ),
                      ),
                      _QuickAction(
                        icon: SardIcons.groups_rounded,
                        color: kAdminTeal,
                        title: 'المستخدمون الجدد',
                        subtitle: '${repo.users.where((u) => u.isNewUser).length} انضموا خلال آخر 30 يوماً',
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const AdminUsersScreen()),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'نصيحة: اكتب أي كلمة — عنوان عمل، اسم مستخدم، رقم فصل، أو كلمة من وصف بلاغ.',
                        style: context.ts(size: 12.5, color: p.textDim),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              else if (result.isEmpty)
                const Expanded(
                  child: AdminEmptyState(
                    icon: SardIcons.manage_search_rounded,
                    title: 'لا نتائج',
                    message: 'لا شيء يطابق بحثك في الأعمال أو الفصول أو المستخدمين أو البلاغات.',
                  ),
                )
              else
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                        child: Text(
                          '${result.totalCount} نتيجة لـ «$_query»',
                          style: context.ts(size: 12.5, color: p.textDim),
                        ),
                      ),
                      if (result.series.isNotEmpty) ...[
                        AdminSectionTitle(
                          title: 'الأعمال',
                          icon: SardIcons.menu_book_rounded,
                          count: result.series.length,
                        ),
                        ...result.series.map((s) => _ResultTile(
                              icon: SardIcons.menu_book_rounded,
                              color: p.accent,
                              title: s.title,
                              subtitle: '${s.typeShort} · ${s.state.label} · ${s.chapters} فصلاً',
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => AdminSeriesEditorScreen(series: s)),
                              ),
                            )),
                      ],
                      if (result.chapters.isNotEmpty) ...[
                        AdminSectionTitle(
                          title: 'الفصول',
                          icon: SardIcons.chrome_reader_mode_rounded,
                          count: result.chapters.length,
                        ),
                        ...result.chapters.map((c) {
                          final series = repo.seriesById(c.seriesId);
                          return _ResultTile(
                            icon: SardIcons.chrome_reader_mode_rounded,
                            color: chapterStatusColor(c.status),
                            title: c.displayTitle,
                            subtitle: '${series?.title ?? c.seriesId} · ${c.status.label}',
                            onTap: series == null
                                ? null
                                : () => Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => AdminChapterEditorScreen(series: series, chapter: c),
                                      ),
                                    ),
                          );
                        }),
                      ],
                      if (result.users.isNotEmpty) ...[
                        AdminSectionTitle(
                          title: 'المستخدمون',
                          icon: SardIcons.groups_rounded,
                          count: result.users.length,
                        ),
                        ...result.users.map((u) => _ResultTile(
                              icon: SardIcons.person_rounded,
                              color: roleColor(u.role),
                              title: u.name,
                              subtitle: '${u.email} · ${u.role.label} · ${u.status.label}',
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const AdminUsersScreen()),
                              ),
                            )),
                      ],
                      if (result.reports.isNotEmpty) ...[
                        AdminSectionTitle(
                          title: 'البلاغات',
                          icon: SardIcons.gavel_rounded,
                          count: result.reports.length,
                        ),
                        ...result.reports.map((r) => _ResultTile(
                              icon: SardIcons.gavel_rounded,
                              color: reportStatusColor(r.status),
                              title: r.targetTitle,
                              subtitle: '${r.reason.label} · من ${r.reporterName} · ${r.status.label}',
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const AdminModerationScreen()),
                              ),
                            )),
                      ],
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ResultTile extends StatelessWidget {
  const _ResultTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: tint(color, 0.13),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: SIcon(icon, size: 18, color: color),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: context.ts(size: 13.5, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 2),
                      Text(subtitle, style: context.ts(size: 12, color: p.textDim), maxLines: 1, overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: tint(color, 0.13),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: SIcon(icon, size: 20, color: color),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: context.ts(size: 14, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
                    ],
                  ),
                ),
                SIcon(SardIcons.chevron_left_rounded, size: 20, color: p.textDim),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
