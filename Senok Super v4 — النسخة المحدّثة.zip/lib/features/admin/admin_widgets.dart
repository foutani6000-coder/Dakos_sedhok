import 'package:flutter/material.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// ويدجتات مشتركة للوحة الأدمن — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// ألوان ثابتة للحالات (لا تتغيّر مع الثيم لتبقى دلالتها واضحة):
const Color kAdminGreen = Color(0xFF2FBF71);
const Color kAdminAmber = Color(0xFFF5A524);
const Color kAdminRed = Color(0xFFE5484D);
const Color kAdminBlue = Color(0xFF3B9EFF);
const Color kAdminPurple = Color(0xFF8B5CF6);
const Color kAdminTeal = Color(0xFF12B5A5);

Color chapterStatusColor(AdminChapterStatus s) => switch (s) {
      AdminChapterStatus.published => kAdminGreen,
      AdminChapterStatus.draft => kAdminAmber,
      AdminChapterStatus.scheduled => kAdminBlue,
      AdminChapterStatus.hidden => kAdminRed,
    };

Color userStatusColor(AdminUserStatus s) => switch (s) {
      AdminUserStatus.active => kAdminGreen,
      AdminUserStatus.suspended => kAdminAmber,
      AdminUserStatus.banned => kAdminRed,
      AdminUserStatus.pending => kAdminBlue,
    };

Color reportStatusColor(AdminReportStatus s) => switch (s) {
      AdminReportStatus.pending => kAdminAmber,
      AdminReportStatus.reviewing => kAdminBlue,
      AdminReportStatus.resolved => kAdminGreen,
      AdminReportStatus.rejected => kAdminRed,
    };

Color roleColor(AdminRole r) => switch (r) {
      AdminRole.superAdmin => kAdminPurple,
      AdminRole.admin => kAdminRed,
      AdminRole.moderator => kAdminBlue,
      AdminRole.translator => kAdminTeal,
      AdminRole.user => kAdminGreen,
    };

/// عنوان قسم في لوحة الأدمن مع عدّاد اختياري وزر إجراء.
///
/// ملاحظة: لا تستدعِ هذا الويدجت بـ const عند تمرير onAction (دالة) أو
/// count غير ثابت — فذلك خطأ ترجمة في Flutter.
class AdminSectionTitle extends StatelessWidget {
  const AdminSectionTitle({
    super.key,
    required this.title,
    this.subtitle,
    this.count,
    this.onAction,
    this.actionLabel,
    this.icon,
  });

  final String title;
  final String? subtitle;
  final int? count;
  final VoidCallback? onAction;
  final String? actionLabel;
  final SIconData? icon;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: tint(p.accent, 0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: SIcon(icon, size: 18, color: p.accent),
            ),
            const SizedBox(width: 10),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(title, style: context.ds(size: 17)),
                    ),
                    if (count != null) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: tint(p.accent, 0.14),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '$count',
                          style: context.ts(size: 12, w: FontWeight.w800, color: p.accent),
                        ),
                      ),
                    ],
                  ],
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(subtitle!, style: context.ts(size: 12.5, color: p.textDim)),
                ],
              ],
            ),
          ),
          if (onAction != null)
            TextButton(
              onPressed: onAction,
              child: Text(actionLabel ?? 'عرض الكل', style: context.ts(size: 13, w: FontWeight.w700, color: p.accent)),
            ),
        ],
      ),
    );
  }
}

/// بطاقة إحصائية صغيرة في لوحة التحكم.
class AdminStatCard extends StatelessWidget {
  const AdminStatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    this.sub,
    this.onTap,
  });

  final String label;
  final String value;
  final SIconData icon;
  final Color color;
  final String? sub;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final card = Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        border: Border.all(color: p.border, width: p.borderW),
        boxShadow: softShadow(p),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: tint(color, 0.13),
              borderRadius: BorderRadius.circular(11),
            ),
            child: SIcon(icon, size: 20, color: color),
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: context.ds(size: 21),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          Text(label, style: context.ts(size: 12.5, color: p.textDim)),
          if (sub != null) ...[
            const SizedBox(height: 2),
            Text(sub!, style: context.ts(size: 11.5, color: p.textDim)),
          ],
        ],
      ),
    );
    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: card,
      ),
    );
  }
}

/// حقل بحث موحّد لقوائم الأدمن.
class AdminSearchField extends StatelessWidget {
  const AdminSearchField({
    super.key,
    required this.controller,
    required this.hint,
    this.onChanged,
  });

  final TextEditingController controller;
  final String hint;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return TextField(
      controller: controller,
      onChanged: onChanged,
      textInputAction: TextInputAction.search,
      style: context.ts(size: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: context.ts(size: 13.5, color: p.textDim),
        prefixIcon: Padding(
          padding: const EdgeInsets.all(12),
          child: SIcon(SardIcons.search_rounded, size: 20, color: p.textDim),
        ),
        suffixIcon: controller.text.isEmpty
            ? null
            : IconButton(
                onPressed: () {
                  controller.clear();
                  onChanged?.call('');
                },
                icon: SIcon(SardIcons.close_rounded, size: 18, color: p.textDim),
              ),
        filled: true,
        fillColor: p.surface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.border, width: p.borderW),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.border, width: p.borderW),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.accent, width: 1.6),
        ),
      ),
    );
  }
}

/// حالة فارغة موحّدة (بلا نتائج / بلا عناصر).
class AdminEmptyState extends StatelessWidget {
  const AdminEmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final SIconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: tint(p.accent, 0.09),
                shape: BoxShape.circle,
              ),
              child: SIcon(icon, size: 34, color: p.textDim),
            ),
            const SizedBox(height: 14),
            Text(title, style: context.ds(size: 16)),
            const SizedBox(height: 6),
            Text(
              message,
              style: context.ts(size: 13, color: p.textDim),
              textAlign: TextAlign.center,
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: onAction,
                icon: const SIcon(SardIcons.add_circle_outline, size: 18),
                label: Text(actionLabel!, style: context.ts(size: 13.5, w: FontWeight.w700)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// شريحة فلتر قابلة للاختيار.
class AdminChip extends StatelessWidget {
  const AdminChip({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
    this.count,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final int? count;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ChoiceChip(
      label: Text(
        count == null ? label : '$label ($count)',
        style: context.ts(
          size: 12.5,
          w: FontWeight.w700,
          color: selected ? p.onAccent : p.text,
        ),
      ),
      selected: selected,
      onSelected: (_) => onTap(),
      selectedColor: p.accent,
      backgroundColor: p.surface,
      side: BorderSide(color: selected ? p.accent : p.border, width: p.borderW),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      showCheckmark: false,
    );
  }
}

/// شارة حالة ملوّنة صغيرة.
class AdminStatusBadge extends StatelessWidget {
  const AdminStatusBadge({
    super.key,
    required this.label,
    required this.color,
    this.icon,
  });

  final String label;
  final Color color;
  final SIconData? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: tint(color, 0.13),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: tint(color, 0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            SIcon(icon, size: 13, color: color),
            const SizedBox(width: 4),
          ],
          Text(label, style: context.ts(size: 11.5, w: FontWeight.w800, color: color)),
        ],
      ),
    );
  }
}

/// لافتة الوضع التجريبي: تظهر أعلى شاشات الأدمن دائماً في هذا الإصدار.
class AdminDemoBanner extends StatelessWidget {
  const AdminDemoBanner({super.key, this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final mustChange = AdminAuth.i.mustChangePassword;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(compact ? 10 : 12),
      decoration: BoxDecoration(
        color: tint(kAdminAmber, 0.13),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: tint(kAdminAmber, 0.45)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SIcon(SardIcons.info_outline_rounded, size: 20, color: kAdminAmber),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'الوضع التجريبي — البيانات محلية فقط',
                  style: context.ts(size: 13, w: FontWeight.w800, color: p.text),
                ),
                const SizedBox(height: 2),
                Text(
                  mustChange
                      ? 'نقاط نهاية /admin/* غير موجودة في الخادم بعد، والدخول بكلمة المرور الافتراضية admin123. غيّرها فوراً من إعدادات الأدمن.'
                      : 'نقاط نهاية /admin/* غير موجودة في الخادم بعد؛ كل التعديلات تُحفظ على هذا الجهاز فقط.',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// نافذة تأكيد موحّدة. تعيد true عند الموافقة.
Future<bool> showAdminConfirm(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'تأكيد',
  String cancelLabel = 'إلغاء',
  bool destructive = false,
}) async {
  final p = context.pal;
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: p.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text(title, style: context.ds(size: 17)),
      content: Text(message, style: context.ts(size: 13.5, color: p.textDim)),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: Text(cancelLabel, style: context.ts(size: 13.5, w: FontWeight.w700, color: p.textDim)),
        ),
        FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: destructive ? kAdminRed : p.accent,
            foregroundColor: Colors.white,
          ),
          onPressed: () => Navigator.of(ctx).pop(true),
          child: Text(confirmLabel, style: context.ts(size: 13.5, w: FontWeight.w700, color: Colors.white)),
        ),
      ],
    ),
  );
  return result ?? false;
}

/// رسالة عابرة (SnackBar) موحّدة للوحة الأدمن.
void showAdminSnack(BuildContext context, String message, {bool isError = false}) {
  final p = context.pal;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message, style: context.ts(size: 13.5, w: FontWeight.w600, color: Colors.white)),
      backgroundColor: isError ? kAdminRed : p.text,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 3),
    ),
  );
}

/// رسم بياني شريطي بسيط (بدون حزم خارجية) لشاشة التقارير.
class AdminBarChart extends StatelessWidget {
  const AdminBarChart({
    super.key,
    required this.values,
    required this.labels,
    this.color,
    this.height = 160,
    this.maxValue,
  });

  final List<int> values;
  final List<String> labels;
  final Color? color;
  final double height;
  final int? maxValue;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SizedBox(
      height: height,
      child: CustomPaint(
        painter: _AdminBarPainter(
          values: values,
          labels: labels,
          barColor: color ?? p.accent,
          labelColor: p.textDim,
          gridColor: p.border,
        ),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _AdminBarPainter extends CustomPainter {
  _AdminBarPainter({
    required this.values,
    required this.labels,
    required this.barColor,
    required this.labelColor,
    required this.gridColor,
  });

  final List<int> values;
  final List<String> labels;
  final Color barColor;
  final Color labelColor;
  final Color gridColor;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty) return;
    final max = values.fold<int>(1, (m, v) => v > m ? v : m);
    const bottomPad = 22.0;
    const topPad = 8.0;
    final chartH = size.height - bottomPad - topPad;
    final gridPaint = Paint()
      ..color = gridColor
      ..strokeWidth = 1;
    for (var i = 0; i <= 3; i++) {
      final y = topPad + chartH * i / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    final n = values.length;
    final slot = size.width / n;
    final barW = (slot * 0.55).clamp(6.0, 34.0);
    for (var i = 0; i < n; i++) {
      final h = (values[i] / max) * chartH;
      final x = slot * i + (slot - barW) / 2;
      final y = topPad + chartH - h;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(x, y, barW, h < 2 ? 2 : h),
        const Radius.circular(5),
      );
      canvas.drawRRect(
        rect,
        Paint()
          ..color = i == n - 1 ? barColor : tint(barColor, 0.55)
          ..style = PaintingStyle.fill,
      );
      if (i < labels.length) {
        final tp = TextPainter(
          text: TextSpan(
            text: labels[i],
            style: TextStyle(fontSize: 10, color: labelColor, fontFamily: 'Tajawal'),
          ),
          textDirection: TextDirection.rtl,
        )..layout(maxWidth: slot);
        tp.paint(canvas, Offset(slot * i + (slot - tp.width) / 2, size.height - 18));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _AdminBarPainter old) =>
      old.values != values || old.labels != labels || old.barColor != barColor;
}
