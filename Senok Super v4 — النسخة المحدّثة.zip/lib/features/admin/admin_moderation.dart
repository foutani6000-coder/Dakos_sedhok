import 'package:flutter/material.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// الإشراف والبلاغات — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// قائمة بلاغات بفلترة حسب الحالة والسبب، مع بطاقة بلاغ كاملة: الهدف، السبب،
/// المُبلِّغ، الوصف، وإجراءات المعالجة (قيد المراجعة / تمت المعالجة مع ملاحظة /
/// مرفوض). مع قواعد إشراف مكتوبة داخل اللوحة.
/// ──────────────────────────────────────────────────────────────────────────

const List<String> kAdminModerationRules = [
  'راجع البلاغ خلال 48 ساعة كحد أقصى، وابدأ بالأحدث والأخطر (إساءة، حقوق نشر).',
  'لا تحذف محتوى قبل قراءة الوصف كاملاً والتحقق من الهدف المُبلَّغ عنه.',
  'الحظر النهائي يحتاج سبباً مكتوباً واضحاً، ويُسجَّل في سجل التدقيق.',
  'البلاغات المرفوضة تحتاج ملاحظة قصيرة تشرح السبب للمُبلِّغ.',
  'لا تستخدم صلاحيات الإشراف لحذف آراء أو تقييمات لا تعجبك.',
  'المحتوى المكرر أو الإعلاني يُحذف، وصاحبه يُنبَّه أول مرة قبل الإيقاف.',
  'في شكوك حقوق النشر: أخفِ المحتوى مؤقتاً حتى يثبت صاحبه حقه.',
  'كل إجراء إشراف يظهر باسمك في سجل التدقيق — تصرّف كأن الجميع يراه.',
];

class AdminModerationScreen extends StatefulWidget {
  const AdminModerationScreen({super.key});

  @override
  State<AdminModerationScreen> createState() => _AdminModerationScreenState();
}

class _AdminModerationScreenState extends State<AdminModerationScreen> {
  AdminReportStatus? _status;
  AdminReportReason? _reason;
  bool _showRules = false;

  List<AdminReport> _list() =>
      AdminRepository.i.reportsFiltered(status: _status, reason: _reason);

  void _openDetail(AdminReport report) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _ReportDetailSheet(report: report),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final list = _list();
        final open = repo.reports.where((r) => r.isOpen).length;
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('الإشراف والبلاغات', style: context.ds(size: 19)),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            children: [
              const AdminDemoBanner(compact: true),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                  border: Border.all(color: p.border, width: p.borderW),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: tint(kAdminAmber, 0.13),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const SIcon(SardIcons.gavel_rounded, size: 22, color: kAdminAmber),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('$open بلاغ مفتوح', style: context.ds(size: 17)),
                          Text(
                            open == 0 ? 'كل شيء تحت السيطرة.' : 'راجع الأقدم أولاً، وابدأ بالإساءة وحقوق النشر.',
                            style: context.ts(size: 12.5, color: p.textDim),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text('الحالة', style: context.ts(size: 13, w: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  AdminChip(
                    label: 'الكل',
                    selected: _status == null,
                    onTap: () => setState(() => _status = null),
                  ),
                  for (final st in AdminReportStatus.values)
                    AdminChip(
                      label: st.label,
                      selected: _status == st,
                      count: repo.reports.where((r) => r.status == st).length,
                      onTap: () => setState(() => _status = _status == st ? null : st),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text('السبب', style: context.ts(size: 13, w: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  AdminChip(
                    label: 'الكل',
                    selected: _reason == null,
                    onTap: () => setState(() => _reason = null),
                  ),
                  for (final rs in AdminReportReason.values)
                    AdminChip(
                      label: rs.label,
                      selected: _reason == rs,
                      onTap: () => setState(() => _reason = _reason == rs ? null : rs),
                    ),
                ],
              ),
              AdminSectionTitle(
                title: 'البلاغات',
                icon: SardIcons.forum_rounded,
                count: list.length,
              ),
              if (list.isEmpty)
                const AdminEmptyState(
                  icon: SardIcons.check_circle_rounded,
                  title: 'لا بلاغات هنا',
                  message: 'لا توجد بلاغات مطابقة لهذا الفلتر.',
                )
              else
                ...list.map((r) => _ReportCard(report: r, onTap: () => _openDetail(r))),
              AdminSectionTitle(
                title: 'قواعد الإشراف',
                subtitle: 'اضغط لعرضها — تُطبَّق على كل المشرفين',
                icon: SardIcons.shield_rounded,
              ),
              Material(
                color: p.surface,
                borderRadius: BorderRadius.circular(p.r(0.7)),
                child: InkWell(
                  onTap: () => setState(() => _showRules = !_showRules),
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(p.r(0.7)),
                      border: Border.all(color: p.border, width: p.borderW),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            _showRules ? 'إخفاء قواعد الإشراف' : 'عرض قواعد الإشراف (${kAdminModerationRules.length})',
                            style: context.ts(size: 13.5, w: FontWeight.w700),
                          ),
                        ),
                        SIcon(
                          _showRules ? SardIcons.expand_less_rounded : SardIcons.expand_more_rounded,
                          size: 20,
                          color: p.textDim,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              if (_showRules) ...[
                const SizedBox(height: 10),
                ...kAdminModerationRules.asMap().entries.map((e) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            color: tint(p.accent, 0.13),
                            shape: BoxShape.circle,
                          ),
                          alignment: Alignment.center,
                          child: Text('${e.key + 1}', style: context.ts(size: 12, w: FontWeight.w800, color: p.accent)),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Text(e.value, style: context.ts(size: 13, color: p.text))),
                      ],
                    ),
                  );
                }),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _ReportCard extends StatelessWidget {
  const _ReportCard({required this.report, required this.onTap});

  final AdminReport report;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final r = report;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AdminStatusBadge(label: r.targetType.label, color: kAdminBlue),
                    const SizedBox(width: 6),
                    AdminStatusBadge(label: r.reason.label, color: kAdminAmber),
                    const Spacer(),
                    AdminStatusBadge(label: r.status.label, color: reportStatusColor(r.status)),
                  ],
                ),
                const SizedBox(height: 8),
                Text(r.targetTitle, style: context.ts(size: 14, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(r.description, style: context.ts(size: 13, color: p.textDim), maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 6),
                Text(
                  'من ${r.reporterName} · ${timeAgoArabic(r.createdAt)}',
                  style: context.ts(size: 11.5, color: p.textDim),
                ),
                if (r.resolutionNote != null) ...[
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: tint(kAdminGreen, 0.1),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Text(
                      'المعالجة: ${r.resolutionNote}',
                      style: context.ts(size: 12, color: kAdminGreen),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ReportDetailSheet extends StatefulWidget {
  const _ReportDetailSheet({required this.report});

  final AdminReport report;

  @override
  State<_ReportDetailSheet> createState() => _ReportDetailSheetState();
}

class _ReportDetailSheetState extends State<_ReportDetailSheet> {
  bool _busy = false;

  AdminReport get _report => AdminRepository.i.reportById(widget.report.id) ?? widget.report;

  Future<String?> _askNote(String title, String hint, {bool required = false}) async {
    final ctrl = TextEditingController();
    final p = context.pal;
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: context.ds(size: 17)),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13, color: p.textDim),
            filled: true,
            fillColor: p.bg,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.border),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('إلغاء', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.textDim)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent),
            onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
            child: Text('تأكيد', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.onAccent)),
          ),
        ],
      ),
    );
    if (result == null) return null;
    if (required && result.isEmpty) {
      showAdminSnack(context, 'اكتب ملاحظة المعالجة أولاً.', isError: true);
      return null;
    }
    return result;
  }

  Future<void> _setStatus(AdminReportStatus status) async {
    String? note;
    if (status == AdminReportStatus.resolved) {
      note = await _askNote('معالجة البلاغ', 'اكتب ما فعلته (مثال: حُذف التعليق وأُنذر صاحبه)…', required: true);
      if (note == null) return;
    } else if (status == AdminReportStatus.rejected) {
      note = await _askNote('رفض البلاغ', 'اشرح سبب الرفض باختصار…', required: true);
      if (note == null) return;
    }
    if (_busy) return;
    setState(() => _busy = true);
    final res = await AdminRepository.i.setReportStatus(_report.id, status, note: note);
    if (!mounted) return;
    setState(() => _busy = false);
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
    if (res.isOk && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: AdminRepository.i,
      builder: (context, _) {
        final report = _report;
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          minChildSize: 0.5,
          maxChildSize: 0.92,
          expand: false,
          builder: (context, scroll) {
            return ListView(
              controller: scroll,
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(3)),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    AdminStatusBadge(label: report.targetType.label, color: kAdminBlue),
                    const SizedBox(width: 6),
                    AdminStatusBadge(label: report.reason.label, color: kAdminAmber),
                    const Spacer(),
                    AdminStatusBadge(label: report.status.label, color: reportStatusColor(report.status)),
                  ],
                ),
                const SizedBox(height: 12),
                Text(report.targetTitle, style: context.ds(size: 19)),
                const SizedBox(height: 4),
                Text(
                  'من ${report.reporterName} · ${formatSardDateTime(report.createdAt)}',
                  style: context.ts(size: 12.5, color: p.textDim),
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: p.bg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: p.border, width: p.borderW),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('وصف البلاغ', style: context.ts(size: 12.5, w: FontWeight.w800, color: p.accent)),
                      const SizedBox(height: 4),
                      Text(report.description, style: context.ts(size: 13.5)),
                      const SizedBox(height: 12),
                      Text('لماذا هذا السبب؟', style: context.ts(size: 12.5, w: FontWeight.w800, color: p.accent)),
                      const SizedBox(height: 4),
                      Text(report.reason.hint, style: context.ts(size: 13, color: p.textDim)),
                    ],
                  ),
                ),
                if (report.resolutionNote != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: tint(kAdminGreen, 0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: tint(kAdminGreen, 0.35)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('ملاحظة المعالجة', style: context.ts(size: 12.5, w: FontWeight.w800, color: kAdminGreen)),
                        const SizedBox(height: 4),
                        Text(report.resolutionNote!, style: context.ts(size: 13.5)),
                        if (report.resolvedAt != null) ...[
                          const SizedBox(height: 4),
                          Text(
                            'عولج ${formatSardDateTime(report.resolvedAt!)}',
                            style: context.ts(size: 12, color: p.textDim),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
                if (report.isOpen) ...[
                  const SizedBox(height: 18),
                  Text('إجراءات الإشراف', style: context.ts(size: 13.5, w: FontWeight.w800)),
                  const SizedBox(height: 10),
                  if (report.status == AdminReportStatus.pending)
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _busy ? null : () => _setStatus(AdminReportStatus.reviewing),
                        icon: const SIcon(SardIcons.visibility_rounded, size: 18),
                        label: Text('بدء المراجعة', style: context.ts(size: 13.5, w: FontWeight.w700)),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          side: BorderSide(color: p.border),
                        ),
                      ),
                    ),
                  if (report.status == AdminReportStatus.pending) const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _busy ? null : () => _setStatus(AdminReportStatus.resolved),
                      icon: const SIcon(SardIcons.check_circle_rounded, size: 18),
                      label: Text('تمت المعالجة', style: context.ts(size: 13.5, w: FontWeight.w800, color: Colors.white)),
                      style: FilledButton.styleFrom(
                        backgroundColor: kAdminGreen,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _busy ? null : () => _setStatus(AdminReportStatus.rejected),
                      icon: const SIcon(SardIcons.close_rounded, size: 18),
                      label: Text('رفض البلاغ', style: context.ts(size: 13.5, w: FontWeight.w700, color: kAdminRed)),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        side: const BorderSide(color: kAdminRed),
                      ),
                    ),
                  ),
                ],
              ],
            );
          },
        );
      },
    );
  }
}
