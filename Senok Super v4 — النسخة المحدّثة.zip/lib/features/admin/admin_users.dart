import 'package:flutter/material.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'admin_repository.dart';
import 'admin_widgets.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// إدارة المستخدمين — Senok
/// ──────────────────────────────────────────────────────────────────────────
/// قائمة بحث وفلترة وترتيب، مع بطاقة مستخدم كاملة: الدور، الحالة، التوثيق،
/// الإيقاف/الحظر مع سبب، وتغيير الدور. كل إجراء يُسجَّل في سجل التدقيق.
/// ──────────────────────────────────────────────────────────────────────────

class AdminUsersScreen extends StatefulWidget {
  const AdminUsersScreen({super.key});

  @override
  State<AdminUsersScreen> createState() => _AdminUsersScreenState();
}

class _AdminUsersScreenState extends State<AdminUsersScreen> {
  final _searchCtrl = TextEditingController();
  AdminUserFilter _filter = const AdminUserFilter();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _openDetail(AdminUser user) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pal.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _UserDetailSheet(user: user),
    );
  }

  Future<void> _addUser() async {
    final nameCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    var role = AdminRole.user;
    final p = context.pal;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          backgroundColor: p.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text('مستخدم جديد', style: context.ds(size: 17)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameCtrl,
                style: context.ts(size: 14),
                decoration: InputDecoration(
                  labelText: 'الاسم',
                  hintText: 'مثال: أحمد محمد',
                  filled: true,
                  fillColor: p.bg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: p.border),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: emailCtrl,
                keyboardType: TextInputType.emailAddress,
                style: context.ts(size: 14),
                decoration: InputDecoration(
                  labelText: 'البريد الإلكتروني',
                  hintText: 'name@example.com',
                  filled: true,
                  fillColor: p.bg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: p.border),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<AdminRole>(
                initialValue: role,
                items: AdminRole.values
                    .map((r) => DropdownMenuItem<AdminRole>(value: r, child: Text(r.label, style: context.ts(size: 13.5))))
                    .toList(),
                onChanged: (v) => setDialogState(() => role = v ?? AdminRole.user),
                decoration: InputDecoration(
                  labelText: 'الدور',
                  filled: true,
                  fillColor: p.bg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: p.border),
                  ),
                ),
                dropdownColor: p.surface,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: Text('إلغاء', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.textDim)),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: p.onAccent),
              onPressed: () => Navigator.of(ctx).pop(true),
              child: Text('إضافة', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.onAccent)),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final now = DateTime.now();
    final user = AdminUser(
      id: 'u_${now.millisecondsSinceEpoch}',
      name: nameCtrl.text.trim(),
      email: emailCtrl.text.trim(),
      role: role,
      status: AdminUserStatus.active,
      joinedAt: now,
      lastActiveAt: now,
    );
    final res = await AdminRepository.i.addUser(user);
    if (!mounted) return;
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final repo = AdminRepository.i;
    return AnimatedBuilder(
      animation: repo,
      builder: (context, _) {
        final list = repo.searchUsers(_filter);
        final counts = <AdminUserStatus, int>{};
        for (final u in repo.users) {
          counts[u.status] = (counts[u.status] ?? 0) + 1;
        }
        return Scaffold(
          backgroundColor: p.bg,
          appBar: AppBar(
            backgroundColor: p.bg,
            elevation: 0,
            title: Text('إدارة المستخدمين', style: context.ds(size: 19)),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: AdminSearchField(
                  controller: _searchCtrl,
                  hint: 'ابحث بالاسم أو البريد…',
                  onChanged: (v) => setState(() => _filter = _filter.copyWith(query: v)),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    AdminChip(
                      label: 'الكل',
                      selected: _filter.isEmpty,
                      onTap: () => setState(() => _filter = AdminUserFilter(query: _filter.query, sort: _filter.sort)),
                    ),
                    const SizedBox(width: 8),
                    for (final st in AdminUserStatus.values) ...[
                      AdminChip(
                        label: st.label,
                        selected: _filter.status == st,
                        count: counts[st],
                        onTap: () => setState(() => _filter = _filter.copyWith(
                          status: _filter.status == st ? null : st,
                        )),
                      ),
                      const SizedBox(width: 8),
                    ],
                    AdminChip(
                      label: 'جدد',
                      selected: _filter.onlyNew,
                      onTap: () => setState(() => _filter = _filter.copyWith(onlyNew: !_filter.onlyNew)),
                    ),
                    const SizedBox(width: 8),
                    AdminChip(
                      label: 'نشطون مؤخراً',
                      selected: _filter.onlyActiveRecently,
                      onTap: () => setState(() => _filter = _filter.copyWith(onlyActiveRecently: !_filter.onlyActiveRecently)),
                    ),
                    const SizedBox(width: 8),
                    PopupMenuButton<AdminUserSort>(
                      onSelected: (s) => setState(() => _filter = _filter.copyWith(sort: s)),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: AdminUserSort.newest, child: Text('الأحدث انضماماً')),
                        PopupMenuItem(value: AdminUserSort.name, child: Text('الاسم')),
                        PopupMenuItem(value: AdminUserSort.mostRead, child: Text('الأكثر قراءة')),
                        PopupMenuItem(value: AdminUserSort.lastActive, child: Text('آخر نشاط')),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: p.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: p.border, width: p.borderW),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SIcon(SardIcons.swap_vert_rounded, size: 16, color: p.textDim),
                            const SizedBox(width: 4),
                            Text(
                              switch (_filter.sort) {
                                AdminUserSort.newest => 'الأحدث',
                                AdminUserSort.name => 'الاسم',
                                AdminUserSort.mostRead => 'الأكثر قراءة',
                                AdminUserSort.lastActive => 'آخر نشاط',
                              },
                              style: context.ts(size: 12.5, w: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    Text('الدور: ', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.textDim)),
                    const SizedBox(width: 4),
                    for (final role in AdminRole.values) ...[
                      AdminChip(
                        label: role.label,
                        selected: _filter.role == role,
                        onTap: () => setState(() => _filter = _filter.copyWith(
                          role: _filter.role == role ? null : role,
                        )),
                      ),
                      const SizedBox(width: 8),
                    ],
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                child: Row(
                  children: [
                    Text('${list.length} مستخدم', style: context.ts(size: 12.5, color: p.textDim)),
                    const Spacer(),
                    if (!_filter.isEmpty)
                      TextButton(
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() => _filter = const AdminUserFilter());
                        },
                        child: Text('مسح الفلاتر', style: context.ts(size: 12.5, w: FontWeight.w700, color: p.accent)),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? const AdminEmptyState(
                        icon: SardIcons.groups_rounded,
                        title: 'لا مستخدمين مطابقين',
                        message: 'جرّب كلمة بحث أخرى أو امسح الفلاتر.',
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: list.length,
                        itemBuilder: (context, i) => _UserTile(
                          user: list[i],
                          onTap: () => _openDetail(list[i]),
                        ),
                      ),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _addUser,
            backgroundColor: p.accent,
            foregroundColor: p.onAccent,
            icon: const SIcon(SardIcons.add_circle_outline, size: 20),
            label: Text('مستخدم جديد', style: context.ts(size: 13.5, w: FontWeight.w800, color: p.onAccent)),
          ),
        );
      },
    );
  }
}

class _UserTile extends StatelessWidget {
  const _UserTile({required this.user, required this.onTap});

  final AdminUser user;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.7)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(p.r(0.7)),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(p.r(0.7)),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: tint(roleColor(user.role), 0.16),
                      child: Text(user.initials, style: context.ds(size: 15, color: roleColor(user.role))),
                    ),
                    if (user.isVerified)
                      Positioned(
                        bottom: 0,
                        left: 0,
                        child: Container(
                          padding: const EdgeInsets.all(2),
                          decoration: const BoxDecoration(color: kAdminBlue, shape: BoxShape.circle),
                          child: const SIcon(SardIcons.check_rounded, size: 10, color: Colors.white),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(user.name, style: context.ts(size: 14.5, w: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                          ),
                          const SizedBox(width: 6),
                          AdminStatusBadge(label: user.role.label, color: roleColor(user.role)),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(user.email, style: context.ts(size: 12, color: p.textDim), maxLines: 1, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 3),
                      Text(
                        '${user.chaptersRead} فصلاً مقروءاً · آخر نشاط ${timeAgoArabic(user.lastActiveAt)}',
                        style: context.ts(size: 12, color: p.textDim),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                AdminStatusBadge(label: user.status.label, color: userStatusColor(user.status)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// بطاقة مستخدم كاملة في ورقة سفلية مع كل الإجراءات.
class _UserDetailSheet extends StatefulWidget {
  const _UserDetailSheet({required this.user});

  final AdminUser user;

  @override
  State<_UserDetailSheet> createState() => _UserDetailSheetState();
}

class _UserDetailSheetState extends State<_UserDetailSheet> {
  bool _busy = false;

  AdminUser get _user => AdminRepository.i.userById(widget.user.id) ?? widget.user;

  Future<void> _run(Future<AdminResult> Function() op) async {
    if (_busy) return;
    setState(() => _busy = true);
    final res = await op();
    if (!mounted) return;
    setState(() => _busy = false);
    showAdminSnack(context, res.message ?? res.error ?? '', isError: !res.isOk);
    if (res.isOk) setState(() {});
  }

  Future<String?> _askReason(String title, String hint) async {
    final ctrl = TextEditingController();
    final p = context.pal;
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: context.ds(size: 17)),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          style: context.ts(size: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13, color: p.textDim),
            filled: true,
            fillColor: p.bg,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.border),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('إلغاء', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.textDim)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kAdminRed, foregroundColor: Colors.white),
            onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
            child: Text('تأكيد', style: context.ts(size: 13.5, w: FontWeight.w700, color: Colors.white)),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return null;
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: AdminRepository.i,
      builder: (context, _) {
        final user = _user;
        return DraggableScrollableSheet(
          initialChildSize: 0.72,
          minChildSize: 0.5,
          maxChildSize: 0.92,
          expand: false,
          builder: (context, scroll) {
            return ListView(
              controller: scroll,
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(3)),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    CircleAvatar(
                      radius: 32,
                      backgroundColor: tint(roleColor(user.role), 0.16),
                      child: Text(user.initials, style: context.ds(size: 20, color: roleColor(user.role))),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(child: Text(user.name, style: context.ds(size: 18), maxLines: 1, overflow: TextOverflow.ellipsis)),
                              if (user.isVerified) ...[
                                const SizedBox(width: 6),
                                const SIcon(SardIcons.check_circle_rounded, size: 18, color: kAdminBlue),
                              ],
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(user.email, style: context.ts(size: 12.5, color: p.textDim)),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              AdminStatusBadge(label: user.role.label, color: roleColor(user.role)),
                              const SizedBox(width: 6),
                              AdminStatusBadge(label: user.status.label, color: userStatusColor(user.status)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _InfoGrid(user: user),
                if (user.status == AdminUserStatus.banned && user.bannedReason != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: tint(kAdminRed, 0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: tint(kAdminRed, 0.4)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('سبب الحظر', style: context.ts(size: 12.5, w: FontWeight.w800, color: kAdminRed)),
                        const SizedBox(height: 3),
                        Text(user.bannedReason!, style: context.ts(size: 13, color: p.text)),
                      ],
                    ),
                  ),
                ],
                AdminSectionTitle(
                  title: 'تغيير الدور',
                  subtitle: 'الدور يحدد صلاحيات المستخدم في التطبيق',
                  icon: SardIcons.shield_rounded,
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: AdminRole.values.map((r) {
                    final selected = user.role == r;
                    return ChoiceChip(
                      label: Text(r.label, style: context.ts(size: 12.5, w: FontWeight.w700, color: selected ? Colors.white : p.text)),
                      selected: selected,
                      onSelected: (_) => _run(() => AdminRepository.i.setUserRole(user.id, r)),
                      selectedColor: roleColor(r),
                      backgroundColor: p.surface,
                      side: BorderSide(color: selected ? roleColor(r) : p.border, width: p.borderW),
                      showCheckmark: false,
                    );
                  }).toList(),
                ),
                AdminSectionTitle(
                  title: 'إجراءات الحساب',
                  icon: SardIcons.tune_rounded,
                ),
                _ActionRow(
                  icon: SardIcons.check_circle_rounded,
                  color: kAdminBlue,
                  title: user.isVerified ? 'إلغاء التوثيق' : 'توثيق الحساب',
                  subtitle: 'تظهر علامة التوثيق بجانب الاسم',
                  onTap: _busy ? null : () => _run(() => AdminRepository.i.toggleUserVerified(user.id)),
                ),
                _ActionRow(
                  icon: SardIcons.pause_rounded,
                  color: kAdminAmber,
                  title: 'إيقاف مؤقت',
                  subtitle: 'يُمنع من النشر والتعليق مؤقتاً',
                  onTap: _busy
                      ? null
                      : () => _run(() => AdminRepository.i.setUserStatus(user.id, AdminUserStatus.suspended)),
                ),
                _ActionRow(
                  icon: SardIcons.gavel_rounded,
                  color: kAdminRed,
                  title: 'حظر نهائي',
                  subtitle: 'يُمنع من الدخول نهائياً مع كتابة السبب',
                  onTap: _busy
                      ? null
                      : () async {
                          final reason = await _askReason('حظر «${user.name}»', 'اكتب سبب الحظر بوضوح…');
                          if (reason == null) return;
                          await _run(() => AdminRepository.i.setUserStatus(
                                user.id,
                                AdminUserStatus.banned,
                                reason: reason,
                              ));
                        },
                ),
                if (user.status != AdminUserStatus.active)
                  _ActionRow(
                    icon: SardIcons.check_rounded,
                    color: kAdminGreen,
                    title: 'إعادة التفعيل',
                    subtitle: 'يعود الحساب نشطاً كما كان',
                    onTap: _busy ? null : () => _run(() => AdminRepository.i.setUserStatus(user.id, AdminUserStatus.active)),
                  ),
                const SizedBox(height: 12),
                Text(
                  'انضم ${formatSardDate(user.joinedAt)} · آخر نشاط ${timeAgoArabic(user.lastActiveAt)}',
                  style: context.ts(size: 12, color: p.textDim),
                  textAlign: TextAlign.center,
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _InfoGrid extends StatelessWidget {
  const _InfoGrid({required this.user});

  final AdminUser user;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    Widget cell(String label, String value) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: p.bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: p.border, width: p.borderW),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(value, style: context.ts(size: 15, w: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(label, style: context.ts(size: 11.5, color: p.textDim)),
          ],
        ),
      );
    }

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      childAspectRatio: 2.4,
      children: [
        cell('فصول مقروءة', '${user.chaptersRead}'),
        cell('وقت القراءة', user.readingTimeLabel),
        cell('انضم منذ', timeAgoArabic(user.joinedAt)),
        cell('آخر نشاط', timeAgoArabic(user.lastActiveAt)),
      ],
    );
  }
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: p.bg,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: p.border, width: p.borderW),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: tint(color, 0.13),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: SIcon(icon, size: 18, color: color),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: context.ts(size: 13.5, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
                    ],
                  ),
                ),
                SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
