/// ──────────────────────────────────────────────────────────────────────────
/// الوضع العائلي — Family Mode
/// حسابات أطفال بإشراف الوالدين: حد يومي للدقائق، وتصنيف عمري تقديري
/// للأعمال يُشتق من تصنيفاتها (رعب 16، جريمة 13، رومانسي 12، غيرها 7)،
/// وتقرير أسبوعي لكل طفل. التقدير العمري تقريبي ويُذكر كذلك في الواجهة.
/// كل شيء محلي بالكامل.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'reading_journal.dart';

/// التصنيف العمري التقديري لعمل حسب تصنيفاته.
///   رعب → 16 · جريمة → 13 · رومانسي → 12 · غيرها → 7
/// تقدير تقريبي من التصنيفات فقط، وليس تصنيفاً رسمياً من الناشر.
int ageRatingForSeries(Series s) {
  final genres = s.genres.map((g) => g.trim()).toList();
  if (genres.any((g) => g == 'رعب' || g.toLowerCase() == 'horror')) return 16;
  if (genres.any((g) => g == 'جريمة' || g.toLowerCase() == 'crime')) return 13;
  if (genres.any((g) => g == 'رومانسي' || g.toLowerCase() == 'romance')) {
    return 12;
  }
  return 7;
}

/// هل يُسمح لعمر [age] بقراءة العمل [s]؟ (العمر >= التصنيف التقديري).
bool isSeriesAllowedForAge(Series s, int age) => age >= ageRatingForSeries(s);

/// تصنيفات الأعمال التي تتطلب إشرافاً (تُبرز في الواجهة).
const List<String> kSupervisedGenres = <String>['رعب', 'جريمة'];

// ───────────────────────── ملف الطفل ─────────────────────────

/// ملف طفل في الوضع العائلي.
@immutable
class ChildProfile {
  const ChildProfile({
    required this.id,
    required this.name,
    required this.age,
    this.dailyLimitMinutes = 60,
    this.allowedGenres = const <String>[],
    this.blockedSeriesIds = const <String>[],
    required this.createdAt,
  });

  final String id;
  final String name;

  /// عمر الطفل بالسنوات.
  final int age;

  /// الحد اليومي لدقائق القراءة (الافتراضي 60).
  final int dailyLimitMinutes;

  /// تصنيفات مسموحة صراحةً (فارغة = كل التصنيفات المناسبة للعمر).
  final List<String> allowedGenres;

  /// أعمال محظورة صراحةً من الوالدين.
  final List<String> blockedSeriesIds;

  final DateTime createdAt;

  bool get hasCustomGenres => allowedGenres.isNotEmpty;

  ChildProfile copyWith({
    String? id,
    String? name,
    int? age,
    int? dailyLimitMinutes,
    List<String>? allowedGenres,
    List<String>? blockedSeriesIds,
    DateTime? createdAt,
  }) =>
      ChildProfile(
        id: id ?? this.id,
        name: name ?? this.name,
        age: age ?? this.age,
        dailyLimitMinutes: dailyLimitMinutes ?? this.dailyLimitMinutes,
        allowedGenres: allowedGenres ?? this.allowedGenres,
        blockedSeriesIds: blockedSeriesIds ?? this.blockedSeriesIds,
        createdAt: createdAt ?? this.createdAt,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'age': age,
        'daily_limit_minutes': dailyLimitMinutes,
        'allowed_genres': allowedGenres,
        'blocked_series_ids': blockedSeriesIds,
        'created_at': createdAt.toIso8601String(),
      };

  factory ChildProfile.fromJson(Map<String, dynamic> j) => ChildProfile(
        id: '${j['id'] ?? ''}',
        name: '${j['name'] ?? 'طفل'}',
        age: (j['age'] as num?)?.toInt() ?? 7,
        dailyLimitMinutes:
            (j['daily_limit_minutes'] as num?)?.toInt() ?? 60,
        allowedGenres:
            ((j['allowed_genres'] as List?) ?? const []).map((e) => '$e').toList(),
        blockedSeriesIds: ((j['blocked_series_ids'] as List?) ?? const [])
            .map((e) => '$e')
            .toList(),
        createdAt:
            DateTime.tryParse('${j['created_at'] ?? ''}') ?? DateTime.now(),
      );
}

/// نشاط يوم واحد لطفل: دقائق وفصول.
@immutable
class ChildDayActivity {
  const ChildDayActivity({this.minutes = 0, this.chapters = 0});

  final int minutes;
  final int chapters;

  ChildDayActivity operator +(ChildDayActivity other) => ChildDayActivity(
        minutes: minutes + other.minutes,
        chapters: chapters + other.chapters,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'minutes': minutes,
        'chapters': chapters,
      };

  factory ChildDayActivity.fromJson(Map<String, dynamic> j) =>
      ChildDayActivity(
        minutes: (j['minutes'] as num?)?.toInt() ?? 0,
        chapters: (j['chapters'] as num?)?.toInt() ?? 0,
      );
}

// ───────────────────────── التقرير الأسبوعي ─────────────────────────

/// تقرير أسبوعي لطفل واحد (7 أيام).
@immutable
class ParentWeeklyReport {
  const ParentWeeklyReport({
    required this.childName,
    required this.weekStart,
    required this.totalMinutes,
    required this.totalChapters,
    required this.daysActive,
    required this.perDayMinutes,
    required this.limitExceededDays,
    required this.dailyLimitMinutes,
  });

  final String childName;

  /// بداية الأسبوع (الاثنين).
  final DateTime weekStart;

  final int totalMinutes;
  final int totalChapters;

  /// عدد الأيام النشطة (دقائق > 0).
  final int daysActive;

  /// دقائق كل يوم من أيام الأسبوع السبعة (الاثنين أولاً).
  final List<int> perDayMinutes;

  /// عدد الأيام التي تجاوز فيها الطفل حده اليومي.
  final int limitExceededDays;

  final int dailyLimitMinutes;

  /// متوسط الدقائق في الأيام النشطة.
  double get averageActiveMinutes =>
      daysActive == 0 ? 0 : totalMinutes / daysActive;

  /// هل التزم الطفل بالحد طوال الأسبوع؟
  bool get stayedWithinLimit => limitExceededDays == 0;

  /// يبني تقريراً من دقائق الأيام السبعة وفصولها.
  factory ParentWeeklyReport.build({
    required ChildProfile child,
    required DateTime weekStart,
    required List<int> perDayMinutes,
    required int totalChapters,
  }) {
    assert(perDayMinutes.length == 7, 'perDayMinutes يجب أن يحوي 7 أيام');
    final total = perDayMinutes.fold<int>(0, (a, b) => a + b);
    final active = perDayMinutes.where((m) => m > 0).length;
    final exceeded = perDayMinutes
        .where((m) => m > child.dailyLimitMinutes)
        .length;
    return ParentWeeklyReport(
      childName: child.name,
      weekStart: weekStart,
      totalMinutes: total,
      totalChapters: totalChapters,
      daysActive: active,
      perDayMinutes: List<int>.unmodifiable(perDayMinutes),
      limitExceededDays: exceeded,
      dailyLimitMinutes: child.dailyLimitMinutes,
    );
  }

  String toShareText() {
    final b = StringBuffer();
    b.writeln('تقرير قراءة ${childName} — الأسبوع ${formatArabicDate(weekStart)}');
    b.writeln('قرأ $totalMinutes دقيقة في $daysActive أيام');
    b.writeln('وأنهى $totalChapters فصلاً');
    if (stayedWithinLimit) {
      b.writeln('والتزم بالحد اليومي ($dailyLimitMinutes دقيقة) طوال الأسبوع.');
    } else {
      b.writeln(
          'وتجاوز الحد اليومي في $limitExceededDays ${limitExceededDays == 1 ? 'يوم' : 'أيام'}.');
    }
    b.writeln('#Senok');
    return b.toString();
  }
}

/// بداية الأسبوع (الاثنين) الذي يقع فيه [day].
DateTime startOfWeek(DateTime day) {
  final d = startOfDay(day);
  return d.subtract(Duration(days: d.weekday - 1));
}

// ───────────────────────── مخزن الوضع العائلي ─────────────────────────

/// مخزن الوضع العائلي: ملفات الأطفال + نشاطهم اليومي (محلي بالكامل).
class FamilyStore extends ChangeNotifier {
  FamilyStore._(this._p) {
    _children = _readChildren();
    _activity = _readActivity();
  }

  final SharedPreferences _p;
  late List<ChildProfile> _children;

  /// معرّف الطفل ← مفتاح اليوم (YYYY-MM-DD) ← النشاط.
  late Map<String, Map<String, ChildDayActivity>> _activity;

  /// يبني مخزناً من تفضيلات جاهزة (للاختبارات والتكامل اليدوي).
  FamilyStore.forPrefs(SharedPreferences prefs) : this._(prefs);

  static const String kChildrenKey = 'family_children_v1';
  static const String kActivityKey = 'family_activity_v1';

  static Future<FamilyStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    return FamilyStore._(prefs);
  }

  /// نسخة للاختبارات.
  static Future<FamilyStore> testInstance({Map<String, Object>? seed}) async {
    // ignore: invalid_use_of_visible_for_testing_member
    SharedPreferences.setMockInitialValues(seed ?? const <String, Object>{});
    final prefs = await SharedPreferences.getInstance();
    return FamilyStore._(prefs);
  }

  List<ChildProfile> _readChildren() {
    try {
      final raw = _p.getString(kChildrenKey);
      if (raw == null || raw.isEmpty) return <ChildProfile>[];
      final list = jsonDecode(raw) as List;
      return list
          .whereType<Map>()
          .map((e) => ChildProfile.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      return <ChildProfile>[];
    }
  }

  Map<String, Map<String, ChildDayActivity>> _readActivity() {
    try {
      final raw = _p.getString(kActivityKey);
      if (raw == null || raw.isEmpty) {
        return <String, Map<String, ChildDayActivity>>{};
      }
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      final out = <String, Map<String, ChildDayActivity>>{};
      decoded.forEach((childId, days) {
        if (days is! Map) return;
        out[childId] = Map<String, dynamic>.from(days).map(
              (k, v) => MapEntry(
                  k,
                  v is Map
                      ? ChildDayActivity.fromJson(
                          Map<String, dynamic>.from(v))
                      : const ChildDayActivity()),
            );
      });
      return out;
    } catch (_) {
      return <String, Map<String, ChildDayActivity>>{};
    }
  }

  Future<void> _saveChildren() async {
    await _p.setString(
      kChildrenKey,
      jsonEncode(_children.map((c) => c.toJson()).toList()),
    );
  }

  Future<void> _saveActivity() async {
    await _p.setString(
      kActivityKey,
      jsonEncode(_activity.map((childId, days) => MapEntry(
            childId,
            days.map((k, v) => MapEntry(k, v.toJson())),
          ))),
    );
  }

  /// كل ملفات الأطفال.
  List<ChildProfile> get children => List<ChildProfile>.unmodifiable(_children);

  ChildProfile? childById(String id) {
    for (final c in _children) {
      if (c.id == id) return c;
    }
    return null;
  }

  /// يضيف طفلاً جديداً ويعيده.
  Future<ChildProfile> addChild({
    required String name,
    required int age,
    int dailyLimitMinutes = 60,
  }) async {
    final child = ChildProfile(
      id: 'ch${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}',
      name: name.trim().isEmpty ? 'طفل' : name.trim(),
      age: age.clamp(3, 17),
      dailyLimitMinutes: dailyLimitMinutes.clamp(15, 240),
      createdAt: DateTime.now(),
    );
    _children.add(child);
    await _saveChildren();
    notifyListeners();
    return child;
  }

  /// يحدّث ملف طفل (مطابقة بالمعرّف).
  Future<bool> updateChild(ChildProfile child) async {
    final i = _children.indexWhere((c) => c.id == child.id);
    if (i < 0) return false;
    _children[i] = child;
    await _saveChildren();
    notifyListeners();
    return true;
  }

  /// يحذف طفلاً ونشاطه.
  Future<bool> removeChild(String id) async {
    final before = _children.length;
    _children.removeWhere((c) => c.id == id);
    _activity.remove(id);
    if (_children.length == before) return false;
    await _saveChildren();
    await _saveActivity();
    notifyListeners();
    return true;
  }

  /// يسجّل قراءة لطفل في يوم محدد (دقائق وفصول). يعيد false إن لم يوجد الطفل.
  Future<bool> recordReading(
    String childId, {
    int minutes = 0,
    int chapters = 0,
    DateTime? at,
  }) async {
    final child = childById(childId);
    if (child == null) return false;
    final key = dayKeyOf(at ?? DateTime.now());
    final days = _activity.putIfAbsent(childId, () => <String, ChildDayActivity>{});
    final cur = days[key] ?? const ChildDayActivity();
    days[key] = ChildDayActivity(
      minutes: cur.minutes + minutes,
      chapters: cur.chapters + chapters,
    );
    await _saveActivity();
    notifyListeners();
    return true;
  }

  /// نشاط طفل في يوم محدد.
  ChildDayActivity activityOn(String childId, DateTime day) {
    final days = _activity[childId];
    if (days == null) return const ChildDayActivity();
    return days[dayKeyOf(day)] ?? const ChildDayActivity();
  }

  /// دقائق طفل اليوم (لشريط الحد اليومي).
  int minutesToday(String childId) =>
      activityOn(childId, DateTime.now()).minutes;

  /// هل تجاوز الطفل حده اليومي اليوم؟
  bool exceededToday(String childId) {
    final child = childById(childId);
    if (child == null) return false;
    return minutesToday(childId) > child.dailyLimitMinutes;
  }

  /// الدقائق المتبقية في حد اليوم (0 إن تجاوز).
  int remainingToday(String childId) {
    final child = childById(childId);
    if (child == null) return 0;
    final left = child.dailyLimitMinutes - minutesToday(childId);
    return left < 0 ? 0 : left;
  }

  /// هل يُسمح للطفل بقراءة العمل [series]؟ (العمر + الحظر الصريح).
  bool canRead(String childId, Series series) {
    final child = childById(childId);
    if (child == null) return false;
    if (child.blockedSeriesIds.contains(series.id)) return false;
    if (!isSeriesAllowedForAge(series, child.age)) return false;
    if (child.hasCustomGenres) {
      return series.genres.any((g) => child.allowedGenres.contains(g));
    }
    return true;
  }

  /// تقرير أسبوعي لطفل (الأسبوع الذي يقع فيه [weekDay]، أو الأسبوع الحالي).
  ParentWeeklyReport? weeklyReport(String childId, {DateTime? weekDay}) {
    final child = childById(childId);
    if (child == null) return null;
    final start = startOfWeek(weekDay ?? DateTime.now());
    final perDay = <int>[];
    var chapters = 0;
    for (var i = 0; i < 7; i++) {
      final a = activityOn(childId, start.add(Duration(days: i)));
      perDay.add(a.minutes);
      chapters += a.chapters;
    }
    return ParentWeeklyReport.build(
      child: child,
      weekStart: start,
      perDayMinutes: perDay,
      totalChapters: chapters,
    );
  }
}

// ───────────────────────── واجهة الوضع العائلي ─────────────────────────

/// شاشة الوضع العائلي: ملفات الأطفال + الحد اليومي + التقرير الأسبوعي.
class FamilyModeScreen extends StatefulWidget {
  const FamilyModeScreen({super.key});

  @override
  State<FamilyModeScreen> createState() => _FamilyModeScreenState();
}

class _FamilyModeScreenState extends State<FamilyModeScreen> {
  String? _selectedChildId;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<FamilyStore>();
    final children = store.children;
    final selected = _selectedChildId == null
        ? null
        : store.childById(_selectedChildId!);
    final report = selected == null
        ? null
        : store.weeklyReport(selected.id);

    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text('الوضع العائلي', style: context.ds(size: 20, color: p.text)),
        actions: [
          IconButton(
            onPressed: () => _openAddChild(context, store),
            icon: SIcon(SardIcons.add_circle_outline, size: 21, color: p.text),
            tooltip: 'إضافة طفل',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: p.border),
            ),
            child: Row(
              children: [
                SIcon(SardIcons.shield_rounded, size: 20, color: p.accent),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'حسابات أطفال بحد يومي للدقائق وتصنيف عمري تقديري للأعمال '
                    '(يُشتق من التصنيفات فقط، وليس تصنيفاً رسمياً من الناشر).',
                    style: context.ts(size: 12.5, color: p.textDim, height: 1.7),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (children.isEmpty)
            _FamilyEmptyState(onAdd: () => _openAddChild(context, store))
          else ...[
            Text('أطفالك', style: context.ds(size: 17, color: p.text)),
            const SizedBox(height: 10),
            for (final c in children) ...[
              _ChildCard(
                child: c,
                selected: selected?.id == c.id,
                store: store,
                onTap: () =>
                    setState(() => _selectedChildId = c.id),
                onEdit: () => _openEditChild(context, store, c),
              ),
              const SizedBox(height: 10),
            ],
            if (selected != null && report != null) ...[
              const SizedBox(height: 8),
              Text('تقرير أسبوع ${selected.name}',
                  style: context.ds(size: 17, color: p.text)),
              const SizedBox(height: 10),
              _WeeklyReportCard(
                report: report,
                store: store,
                child: selected,
              ),
            ],
          ],
        ],
      ),
    );
  }

  Future<void> _openAddChild(BuildContext context, FamilyStore store) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _ChildEditorSheet(store: store),
    );
  }

  Future<void> _openEditChild(
      BuildContext context, FamilyStore store, ChildProfile child) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _ChildEditorSheet(store: store, existing: child),
    );
  }
}

class _FamilyEmptyState extends StatelessWidget {
  const _FamilyEmptyState({required this.onAdd});

  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(
              color: p.bg,
              shape: BoxShape.circle,
              border: Border.all(color: p.border),
            ),
            child: SIcon(SardIcons.groups_rounded, size: 38, color: p.accent),
          ),
          const SizedBox(height: 16),
          Text('لا ملفات أطفال بعد',
              style: context.ds(size: 18, color: p.text)),
          const SizedBox(height: 6),
          Text(
            'أضف ملفاً لكل طفل: اسمه وعمره والحد اليومي للدقائق، '
            'وسيتولى التطبيق تقييد الأعمال غير المناسبة لعمره.',
            style: context.ts(size: 13.5, color: p.textDim, height: 1.8),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: onAdd,
            style: FilledButton.styleFrom(
              backgroundColor: p.accent,
              foregroundColor: p.onAccent,
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            icon: SIcon(SardIcons.add_circle_outline,
                size: 17, color: p.onAccent),
            label: Text('إضافة أول طفل',
                style: context.ts(size: 14, w: FontWeight.w700, color: p.onAccent)),
          ),
        ],
      ),
    );
  }
}

/// بطاقة طفل: الاسم والعمر والحد اليومي والتقدم اليومي.
class _ChildCard extends StatelessWidget {
  const _ChildCard({
    required this.child,
    required this.selected,
    required this.store,
    required this.onTap,
    required this.onEdit,
  });

  final ChildProfile child;
  final bool selected;
  final FamilyStore store;
  final VoidCallback onTap;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final minutes = store.minutesToday(child.id);
    final fraction =
        (minutes / child.dailyLimitMinutes).clamp(0.0, 1.0);
    final exceeded = store.exceededToday(child.id);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? p.accent.withValues(alpha: 0.1) : p.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: selected ? p.accent : p.border, width: selected ? 1.5 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: p.accent.withValues(alpha: 0.13),
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    child.name.isEmpty ? '؟' : child.name.characters.first,
                    style: context.ds(size: 19, color: p.accent),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(child.name,
                          style: context.ts(
                              size: 15, w: FontWeight.w700, color: p.text)),
                      Text('${child.age} سنوات · الحد اليومي ${child.dailyLimitMinutes} دقيقة',
                          style: context.ts(size: 12, color: p.textDim)),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: onEdit,
                  icon: SIcon(SardIcons.edit_rounded,
                      size: 18, color: p.textDim),
                  tooltip: 'تعديل الملف',
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: fraction,
                      minHeight: 8,
                      backgroundColor: p.border,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        exceeded
                            ? const Color(0xFFE5484D)
                            : p.accent,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  exceeded
                      ? 'تجاوز الحد ($minutes د)'
                      : '$minutes / ${child.dailyLimitMinutes} د',
                  style: context.ts(
                      size: 12,
                      w: FontWeight.w700,
                      color: exceeded
                          ? const Color(0xFFE5484D)
                          : p.textDim),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'المتبقي اليوم: ${store.remainingToday(child.id)} دقيقة.',
              style: context.ts(size: 11.5, color: p.textDim),
            ),
          ],
        ),
      ),
    );
  }
}

/// بطاقة التقرير الأسبوعي: أعمدة الأيام السبعة + الأرقام + مشاركة.
class _WeeklyReportCard extends StatelessWidget {
  const _WeeklyReportCard({
    required this.report,
    required this.store,
    required this.child,
  });

  final ParentWeeklyReport report;
  final FamilyStore store;
  final ChildProfile child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final maxDay =
        report.perDayMinutes.fold<int>(0, (a, b) => b > a ? b : a);
    const dayNames = <String>['إثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت', 'أحد'];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'أسبوع ${formatArabicDate(report.weekStart)}',
                  style: context.ds(size: 15.5, color: p.text),
                ),
              ),
              IconButton(
                onPressed: () async {
                  await Clipboard.setData(
                      ClipboardData(text: report.toShareText()));
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('نُسخ نص التقرير.')),
                  );
                },
                icon: SIcon(SardIcons.share_rounded,
                    size: 17, color: p.textDim),
                tooltip: 'نسخ التقرير',
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _ReportNumber(
                  label: 'دقيقة', value: '${report.totalMinutes}'),
              _ReportNumber(
                  label: 'فصلاً', value: '${report.totalChapters}'),
              _ReportNumber(
                  label: 'أيام نشطة', value: '${report.daysActive}'),
              _ReportNumber(
                  label: 'تجاوز الحد',
                  value: '${report.limitExceededDays}'),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < 7; i++)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: Column(
                      children: [
                        Text(
                          report.perDayMinutes[i] == 0
                              ? ''
                              : '${report.perDayMinutes[i]}',
                          style: context.ts(
                              size: 10,
                              w: FontWeight.w700,
                              color: report.perDayMinutes[i] >
                                      report.dailyLimitMinutes
                                  ? const Color(0xFFE5484D)
                                  : p.textDim),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          height: 10 +
                              (maxDay == 0
                                  ? 0
                                  : (report.perDayMinutes[i] / maxDay) * 72),
                          decoration: BoxDecoration(
                            color: report.perDayMinutes[i] >
                                    report.dailyLimitMinutes
                                ? const Color(0xFFE5484D)
                                : p.accent,
                            borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(5)),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(dayNames[i],
                            style: context.ts(size: 10, color: p.textDim)),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              SIcon(
                report.stayedWithinLimit
                    ? SardIcons.check_circle_rounded
                    : SardIcons.info_outline_rounded,
                size: 17,
                color: report.stayedWithinLimit
                    ? const Color(0xFF4CAF50)
                    : const Color(0xFFFFB020),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  report.stayedWithinLimit
                      ? 'التزم ${report.childName} بالحد اليومي طوال الأسبوع.'
                      : 'تجاوز ${report.childName} الحد اليومي في ${report.limitExceededDays} ${report.limitExceededDays == 1 ? 'يوم' : 'أيام'} هذا الأسبوع.',
                  style: context.ts(size: 12.5, color: p.text, height: 1.6),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ReportNumber extends StatelessWidget {
  const _ReportNumber({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: context.ds(size: 17, color: p.text),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          Text(label,
              style: context.ts(size: 11, color: p.textDim),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

/// ورقة إضافة/تعديل ملف طفل.
class _ChildEditorSheet extends StatefulWidget {
  const _ChildEditorSheet({required this.store, this.existing});

  final FamilyStore store;
  final ChildProfile? existing;

  @override
  State<_ChildEditorSheet> createState() => _ChildEditorSheetState();
}

class _ChildEditorSheetState extends State<_ChildEditorSheet> {
  late final TextEditingController _nameCtrl;
  late double _age;
  late double _limit;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _nameCtrl = TextEditingController(text: e?.name ?? '');
    _age = (e?.age ?? 8).toDouble();
    _limit = (e?.dailyLimitMinutes ?? 60).toDouble();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final isEdit = widget.existing != null;
    return Container(
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(p.radius)),
      ),
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: p.border,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(isEdit ? 'تعديل ملف الطفل' : 'إضافة طفل',
                style: context.ds(size: 19, color: p.text)),
            const SizedBox(height: 16),
            Text('الاسم',
                style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
            const SizedBox(height: 6),
            TextField(
              controller: _nameCtrl,
              style: context.ts(size: 14, color: p.text),
              decoration: InputDecoration(
                hintText: 'مثال: سارة',
                hintStyle: context.ts(size: 13, color: p.textDim),
                filled: true,
                fillColor: p.bg,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: p.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: p.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: p.accent, width: 1.4),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('العمر: ${_age.round()} سنوات',
                style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
            Slider(
              value: _age,
              min: 3,
              max: 17,
              divisions: 14,
              activeColor: p.accent,
              onChanged: (v) => setState(() => _age = v),
            ),
            Text(
              'الأعمال المناسبة لعمر ${_age.round()}: '
              '${_age.round() >= 16 ? 'كل التصنيفات' : _age.round() >= 13 ? 'ما عدا الرعب' : _age.round() >= 12 ? 'ما عدا الرعب والجريمة' : 'الأعمال العامة فقط'} (تقدير من التصنيفات).',
              style: context.ts(size: 12, color: p.textDim, height: 1.6),
            ),
            const SizedBox(height: 12),
            Text('الحد اليومي: ${_limit.round()} دقيقة',
                style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
            Slider(
              value: _limit,
              min: 15,
              max: 240,
              divisions: 15,
              activeColor: p.accent,
              onChanged: (v) => setState(() => _limit = v),
            ),
            const SizedBox(height: 8),
            if (isEdit)
              OutlinedButton.icon(
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      backgroundColor: ctx.pal.surface,
                      title: Text('حذف ملف الطفل؟',
                          style: ctx.ds(size: 17, color: ctx.pal.text)),
                      content: Text(
                        'سيُحذف الملف ونشاطه نهائياً.',
                        style: ctx.ts(size: 13.5, color: ctx.pal.textDim),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(ctx).pop(false),
                          child: Text('إلغاء',
                              style: ctx.ts(size: 14, color: ctx.pal.text)),
                        ),
                        TextButton(
                          onPressed: () => Navigator.of(ctx).pop(true),
                          child: Text('حذف',
                              style: ctx.ts(
                                  size: 14,
                                  w: FontWeight.w700,
                                  color: const Color(0xFFE5484D))),
                        ),
                      ],
                    ),
                  );
                  if (ok == true && context.mounted) {
                    await widget.store.removeChild(widget.existing!.id);
                    if (context.mounted) Navigator.of(context).pop();
                  }
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFE5484D),
                  side: const BorderSide(color: Color(0xFFE5484D)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                icon: SIcon(SardIcons.delete_outline_rounded,
                    size: 17, color: const Color(0xFFE5484D)),
                label: Text('حذف هذا الملف',
                    style: context.ts(
                        size: 13.5,
                        w: FontWeight.w700,
                        color: const Color(0xFFE5484D))),
              ),
            const SizedBox(height: 14),
            FilledButton(
              onPressed: _saving ? null : _save,
              style: FilledButton.styleFrom(
                backgroundColor: p.accent,
                foregroundColor: p.onAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: _saving
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: p.onAccent,
                      ),
                    )
                  : Text(isEdit ? 'حفظ التعديلات' : 'إضافة الطفل',
                      style: context.ts(
                          size: 15, w: FontWeight.w700, color: p.onAccent)),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب اسم الطفل أولاً.')),
      );
      return;
    }
    setState(() => _saving = true);
    final existing = widget.existing;
    if (existing != null) {
      await widget.store.updateChild(existing.copyWith(
        name: _nameCtrl.text,
        age: _age.round(),
        dailyLimitMinutes: _limit.round(),
      ));
    } else {
      await widget.store.addChild(
        name: _nameCtrl.text,
        age: _age.round(),
        dailyLimitMinutes: _limit.round(),
      );
    }
    if (!mounted) return;
    Navigator.of(context).pop();
  }
}
