/// ──────────────────────────────────────────────────────────────────────────
/// مجموعة الاقتباسات — Quotes
/// يحفظ القارئ أجمل الأسطر التي قرأها، مصنّفة حسب النوع، مع اقتباس
/// اليوم الحتمي (نفس الاقتباس لكل من يفتح التطبيق في اليوم نفسه)،
/// والمفضلة والبحث والمشاركة. كل شيء محلي بالكامل.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'reading_journal.dart';

/// تصنيفات الاقتباس الستة.
enum QuoteCategory {
  wisdom('حكمة', 'سطر يحمل معنى عميقاً'),
  motivational('تحفيزي', 'سطر يدفعك للأمام'),
  romantic('رومانسي', 'سطر عن الحب والمشاعر'),
  epic('ملحمي', 'سطر بطولي مهيب'),
  funny('مضحك', 'سطر أضحكك'),
  sad('حزين', 'سطر مؤثر وموجع');

  const QuoteCategory(this.label, this.hint);
  final String label;
  final String hint;

  SIconData get icon {
    switch (this) {
      case QuoteCategory.wisdom:
        return SardIcons.auto_awesome_rounded;
      case QuoteCategory.motivational:
        return SardIcons.local_fire_department_rounded;
      case QuoteCategory.romantic:
        return SardIcons.favorite_rounded;
      case QuoteCategory.epic:
        return SardIcons.bolt_rounded;
      case QuoteCategory.funny:
        return SardIcons.emoji_emotions_rounded;
      case QuoteCategory.sad:
        return SardIcons.nightlight_round;
    }
  }

  Color get color {
    switch (this) {
      case QuoteCategory.wisdom:
        return const Color(0xFFE9B44C);
      case QuoteCategory.motivational:
        return const Color(0xFFFF6B35);
      case QuoteCategory.romantic:
        return const Color(0xFFE0457B);
      case QuoteCategory.epic:
        return const Color(0xFF7E6BFF);
      case QuoteCategory.funny:
        return const Color(0xFF4CAF50);
      case QuoteCategory.sad:
        return const Color(0xFF3B9EFF);
    }
  }

  String get key => name;

  static QuoteCategory fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final c in QuoteCategory.values) {
      if (c.name == t) return c;
    }
    return QuoteCategory.wisdom;
  }
}

/// اقتباس واحد محفوظ.
@immutable
class Quote {
  const Quote({
    required this.id,
    required this.text,
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.category,
    required this.at,
    this.favorite = false,
  });

  final String id;
  final String text;
  final String seriesId;
  final String seriesTitle;

  /// رقم الفصل الذي ورد فيه الاقتباس (0 = غير معروف).
  final int chapter;
  final QuoteCategory category;
  final DateTime at;
  final bool favorite;

  bool get hasChapter => chapter > 0;

  String get sourceLabel => hasChapter
      ? '$seriesTitle — الفصل $chapter'
      : seriesTitle;

  Quote copyWith({
    String? id,
    String? text,
    String? seriesId,
    String? seriesTitle,
    int? chapter,
    QuoteCategory? category,
    DateTime? at,
    bool? favorite,
  }) =>
      Quote(
        id: id ?? this.id,
        text: text ?? this.text,
        seriesId: seriesId ?? this.seriesId,
        seriesTitle: seriesTitle ?? this.seriesTitle,
        chapter: chapter ?? this.chapter,
        category: category ?? this.category,
        at: at ?? this.at,
        favorite: favorite ?? this.favorite,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'text': text,
        'series_id': seriesId,
        'series_title': seriesTitle,
        'chapter': chapter,
        'category': category.key,
        'at': at.toIso8601String(),
        'favorite': favorite,
      };

  factory Quote.fromJson(Map<String, dynamic> j) => Quote(
        id: '${j['id'] ?? ''}',
        text: '${j['text'] ?? ''}',
        seriesId: '${j['series_id'] ?? ''}',
        seriesTitle: '${j['series_title'] ?? 'عمل'}',
        chapter: (j['chapter'] as num?)?.toInt() ?? 0,
        category: QuoteCategory.fromKey(j['category']),
        at: DateTime.tryParse('${j['at'] ?? ''}') ?? DateTime.now(),
        favorite: j['favorite'] == true,
      );

  @override
  bool operator ==(Object other) => other is Quote && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

/// اقتباسات افتراضية تُعرض عند أول فتح للمجموعة (حتى لا تبدو فارغة)،
/// ويمكن حذف أي منها. هي أسطر عامة ملهمة وليست منقولة من عمل بعينه.
List<Quote> kSeedQuotes(DateTime now) => <Quote>[
      Quote(
        id: 'seed_1',
        text: 'أقوى الناس من ينهض بعد كل سقوط، لا من لم يسقط أبداً.',
        seriesId: '',
        seriesTitle: 'من حكمة القراءة',
        chapter: 0,
        category: QuoteCategory.motivational,
        at: now,
      ),
      Quote(
        id: 'seed_2',
        text: 'الحكاية لا تنتهي حين تُغلق الصفحة، بل حين تتوقف عن التفكير فيها.',
        seriesId: '',
        seriesTitle: 'من حكمة القراءة',
        chapter: 0,
        category: QuoteCategory.wisdom,
        at: now,
      ),
      Quote(
        id: 'seed_3',
        text: 'في أعمق الظلام يولد أشد النور سطوعاً.',
        seriesId: '',
        seriesTitle: 'من حكمة القراءة',
        chapter: 0,
        category: QuoteCategory.epic,
        at: now,
      ),
    ];

// ───────────────────────── مخزن الاقتباسات ─────────────────────────

/// مخزن الاقتباسات المحلية (المفتاح `quotes_v1`).
class QuoteStore extends ChangeNotifier {
  QuoteStore._(this._p, {bool seed = true}) {
    _quotes = _readAll();
    if (_quotes.isEmpty && seed) {
      _quotes = kSeedQuotes(DateTime.now());
      _save();
    }
  }

  final SharedPreferences _p;
  late List<Quote> _quotes;

  /// يبني مخزناً من تفضيلات جاهزة (للاختبارات والتكامل اليدوي).
  QuoteStore.forPrefs(SharedPreferences prefs, {bool seed = false})
      : this._(prefs, seed: seed);

  static const String kStoreKey = 'quotes_v1';

  static Future<QuoteStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    return QuoteStore._(prefs);
  }

  /// نسخة للاختبارات: تبذر التفضيلات ثم تفتح المخزن (بلا اقتباسات افتراضية).
  static Future<QuoteStore> testInstance({Map<String, Object>? seed}) async {
    // ignore: invalid_use_of_visible_for_testing_member
    SharedPreferences.setMockInitialValues(seed ?? const <String, Object>{});
    final prefs = await SharedPreferences.getInstance();
    return QuoteStore._(prefs, seed: false);
  }

  List<Quote> _readAll() {
    try {
      final raw = _p.getString(kStoreKey);
      if (raw == null || raw.isEmpty) return <Quote>[];
      final list = jsonDecode(raw) as List;
      final out = list
          .whereType<Map>()
          .map((e) => Quote.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      out.sort((a, b) => b.at.compareTo(a.at));
      return out;
    } catch (_) {
      return <Quote>[];
    }
  }

  Future<void> _save() async {
    await _p.setString(
      kStoreKey,
      jsonEncode(_quotes.map((q) => q.toJson()).toList()),
    );
  }

  /// كل الاقتباسات (الأحدث أولاً).
  List<Quote> get entries => List<Quote>.unmodifiable(_quotes);

  int get length => _quotes.length;

  bool get isEmpty => _quotes.isEmpty;

  /// الاقتباسات المفضلة فقط.
  List<Quote> get favorites => _quotes.where((q) => q.favorite).toList();

  /// يضيف اقتباساً جديداً ويعيده.
  Future<Quote> add({
    required String text,
    String seriesId = '',
    String seriesTitle = '',
    int chapter = 0,
    QuoteCategory category = QuoteCategory.wisdom,
    DateTime? at,
  }) async {
    final q = Quote(
      id: 'q${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}'
          '${math.Random().nextInt(1 << 16).toRadixString(36)}',
      text: text.trim(),
      seriesId: seriesId,
      seriesTitle:
          seriesTitle.trim().isEmpty ? 'بلا مصدر' : seriesTitle.trim(),
      chapter: chapter < 0 ? 0 : chapter,
      category: category,
      at: at ?? DateTime.now(),
    );
    _quotes.insert(0, q);
    _quotes.sort((a, b) => b.at.compareTo(a.at));
    await _save();
    notifyListeners();
    return q;
  }

  /// يحذف اقتباساً بالمعرّف.
  Future<bool> remove(String id) async {
    final before = _quotes.length;
    _quotes.removeWhere((q) => q.id == id);
    if (_quotes.length == before) return false;
    await _save();
    notifyListeners();
    return true;
  }

  /// يبدّل حالة «مفضلة» لاقتباس ويعيد الحالة الجديدة (null إن لم يوجد).
  Future<bool?> toggleFavorite(String id) async {
    final i = _quotes.indexWhere((q) => q.id == id);
    if (i < 0) return null;
    final next = !_quotes[i].favorite;
    _quotes[i] = _quotes[i].copyWith(favorite: next);
    await _save();
    notifyListeners();
    return next;
  }

  /// اقتباسات تصنيف واحد.
  List<Quote> byCategory(QuoteCategory category) =>
      _quotes.where((q) => q.category == category).toList();

  /// بحث نصي في نص الاقتباس وعنوان العمل.
  List<Quote> search(String query) {
    final q = query.trim();
    if (q.isEmpty) return entries;
    return _quotes
        .where((e) => e.text.contains(q) || e.seriesTitle.contains(q))
        .toList();
  }

  /// اقتباس اليوم: حتمي تماماً — البذرة = السنة×372 + الشهر×31 + اليوم،
  /// فيرى كل من يفتح التطبيق في اليوم نفسه الاقتباس نفسه.
  /// يعيد null عند عدم وجود أي اقتباس.
  Quote? quoteOfDay({DateTime? day}) {
    if (_quotes.isEmpty) return null;
    final d = day ?? DateTime.now();
    final seed = d.year * 372 + d.month * 31 + d.day;
    return _quotes[seed % _quotes.length];
  }

  /// اقتباس عشوائي مختلف عن [excludeId] (يُستعمل لزر «اقتباس آخر»).
  Quote? randomQuote({String? excludeId}) {
    if (_quotes.isEmpty) return null;
    final pool =
        _quotes.where((q) => q.id != excludeId).toList();
    if (pool.isEmpty) return _quotes.first;
    return pool[math.Random().nextInt(pool.length)];
  }

  /// عدد الاقتباسات في كل تصنيف.
  Map<QuoteCategory, int> get countsByCategory {
    final m = <QuoteCategory, int>{};
    for (final q in _quotes) {
      m[q.category] = (m[q.category] ?? 0) + 1;
    }
    return m;
  }

  /// نص مشاركة اقتباس واحد.
  String shareText(Quote q) {
    final b = StringBuffer();
    b.writeln('«${q.text}»');
    b.writeln('— ${q.sourceLabel}');
    b.writeln('#Senok');
    return b.toString();
  }

  /// تصدير JSON.
  String exportJson() => jsonEncode(_quotes.map((q) => q.toJson()).toList());

  /// استيراد JSON (يتخطى المعرّفات المكررة) ويعيد عدد المستورَد.
  Future<int> importJson(String raw) async {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return 0;
      final existing = _quotes.map((q) => q.id).toSet();
      var added = 0;
      for (final item in decoded) {
        if (item is! Map) continue;
        final q = Quote.fromJson(Map<String, dynamic>.from(item));
        if (q.text.isEmpty || existing.contains(q.id)) continue;
        existing.add(q.id);
        _quotes.add(q);
        added++;
      }
      if (added > 0) {
        _quotes.sort((a, b) => b.at.compareTo(a.at));
        await _save();
        notifyListeners();
      }
      return added;
    } catch (_) {
      return 0;
    }
  }
}

// ───────────────────────── واجهة الاقتباسات ─────────────────────────

/// شاشة مجموعة الاقتباسات: اقتباس اليوم + تصفية بالتصنيف + بحث + قائمة.
class QuotesScreen extends StatefulWidget {
  const QuotesScreen({super.key});

  @override
  State<QuotesScreen> createState() => _QuotesScreenState();
}

class _QuotesScreenState extends State<QuotesScreen> {
  String _query = '';
  QuoteCategory? _category;
  bool _favoritesOnly = false;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<QuoteStore>();
    final today = store.quoteOfDay();
    var list = store.entries;
    if (_category != null) {
      list = list.where((q) => q.category == _category).toList();
    }
    if (_favoritesOnly) {
      list = list.where((q) => q.favorite).toList();
    }
    if (_query.trim().isNotEmpty) {
      list = store.search(_query.trim());
      if (_category != null) {
        list = list.where((q) => q.category == _category).toList();
      }
      if (_favoritesOnly) {
        list = list.where((q) => q.favorite).toList();
      }
    }

    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text('مجموعة الاقتباسات',
            style: context.ds(size: 20, color: p.text)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: p.accent,
        foregroundColor: p.onAccent,
        onPressed: () => _openAddSheet(context, store),
        icon: SIcon(SardIcons.add_circle_outline, size: 18, color: p.onAccent),
        label: Text('اقتباس جديد',
            style: context.ts(size: 14, w: FontWeight.w700, color: p.onAccent)),
      ),
      body: Column(
        children: [
          if (today != null) QuoteOfDayCard(quote: today, store: store),
          _QuoteSearchBar(onChanged: (v) => setState(() => _query = v)),
          _CategoryFilterRow(
            counts: store.countsByCategory,
            selected: _category,
            favoritesOnly: _favoritesOnly,
            onCategory: (c) => setState(() => _category = c),
            onFavorites: (v) => setState(() => _favoritesOnly = v),
          ),
          Expanded(
            child: list.isEmpty
                ? _QuotesEmptyState(
                    hasFilter: _query.isNotEmpty ||
                        _category != null ||
                        _favoritesOnly,
                    onAdd: () => _openAddSheet(context, store),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => QuoteCard(
                      quote: list[i],
                      store: store,
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _openAddSheet(BuildContext context, QuoteStore store) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => QuoteEditorSheet(store: store),
    );
  }
}

/// بطاقة «اقتباس اليوم» في أعلى الشاشة.
class QuoteOfDayCard extends StatelessWidget {
  const QuoteOfDayCard({super.key, required this.quote, required this.store});

  final Quote quote;
  final QuoteStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 6, 16, 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [p.accent, p.accent.withValues(alpha: 0.72)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.auto_awesome_rounded,
                  size: 18, color: p.onAccent),
              const SizedBox(width: 8),
              Text('اقتباس اليوم',
                  style: context.ds(size: 15, color: p.onAccent)),
              const Spacer(),
              Text(formatArabicDate(DateTime.now()),
                  style: context.ts(size: 12, color: p.onAccent)),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            '«${quote.text}»',
            style: context.ts(
                size: 16, w: FontWeight.w700, color: p.onAccent, height: 1.8),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  '— ${quote.sourceLabel}',
                  style: context.ts(size: 12.5, color: p.onAccent),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              IconButton(
                onPressed: () => _copy(context),
                icon: SIcon(SardIcons.share_rounded,
                    size: 18, color: p.onAccent),
                tooltip: 'نسخ الاقتباس',
              ),
              IconButton(
                onPressed: () => store.toggleFavorite(quote.id),
                icon: SIcon(
                  quote.favorite
                      ? SardIcons.favorite_rounded
                      : SardIcons.favorite_border_rounded,
                  size: 19,
                  color: p.onAccent,
                ),
                tooltip: 'مفضلة',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _copy(BuildContext context) async {
    await Clipboard.setData(ClipboardData(text: store.shareText(quote)));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('نُسخ الاقتباس.')),
    );
  }
}

class _QuoteSearchBar extends StatelessWidget {
  const _QuoteSearchBar({required this.onChanged});

  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: TextField(
        onChanged: onChanged,
        style: context.ts(size: 14, color: p.text),
        decoration: InputDecoration(
          hintText: 'ابحث في اقتباساتك…',
          hintStyle: context.ts(size: 13, color: p.textDim),
          prefixIcon:
              SIcon(SardIcons.search_rounded, size: 20, color: p.textDim),
          filled: true,
          fillColor: p.surface,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: p.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: p.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: p.accent, width: 1.4),
          ),
        ),
      ),
    );
  }
}

/// صف تصفية الاقتباسات: الكل + المفضلة + التصنيفات الستة مع العدّادات.
class _CategoryFilterRow extends StatelessWidget {
  const _CategoryFilterRow({
    required this.counts,
    required this.selected,
    required this.favoritesOnly,
    required this.onCategory,
    required this.onFavorites,
  });

  final Map<QuoteCategory, int> counts;
  final QuoteCategory? selected;
  final bool favoritesOnly;
  final ValueChanged<QuoteCategory?> onCategory;
  final ValueChanged<bool> onFavorites;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        children: [
          _FilterChip(
            label: 'الكل',
            selected: selected == null && !favoritesOnly,
            onTap: () {
              onCategory(null);
              onFavorites(false);
            },
          ),
          _FilterChip(
            label: 'المفضلة',
            selected: favoritesOnly,
            onTap: () => onFavorites(!favoritesOnly),
          ),
          for (final c in QuoteCategory.values)
            _FilterChip(
              label: '${c.label} (${counts[c] ?? 0})',
              color: c.color,
              selected: selected == c && !favoritesOnly,
              onTap: () {
                onFavorites(false);
                onCategory(selected == c ? null : c);
              },
            ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.color,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: Text(label,
            style: context.ts(
                size: 12.5,
                w: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? p.onAccent : p.text)),
        selected: selected,
        onSelected: (_) => onTap(),
        selectedColor: color ?? p.accent,
        backgroundColor: p.surface,
        side: BorderSide(color: selected ? Colors.transparent : p.border),
        showCheckmark: false,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      ),
    );
  }
}

class _QuotesEmptyState extends StatelessWidget {
  const _QuotesEmptyState({required this.hasFilter, required this.onAdd});

  final bool hasFilter;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: p.surface,
                shape: BoxShape.circle,
                border: Border.all(color: p.border),
              ),
              child: SIcon(SardIcons.format_list_bulleted_rounded,
                  size: 36, color: p.accent),
            ),
            const SizedBox(height: 16),
            Text(
              hasFilter ? 'لا اقتباسات مطابقة' : 'لا اقتباسات بعد',
              style: context.ds(size: 18, color: p.text),
            ),
            const SizedBox(height: 6),
            Text(
              hasFilter
                  ? 'جرّب كلمة أخرى أو ألغِ التصفية.'
                  : 'حين يعجبك سطر أثناء القراءة، احفظه هنا ليعود إليك في اقتباس اليوم.',
              style: context.ts(size: 13.5, color: p.textDim, height: 1.7),
              textAlign: TextAlign.center,
            ),
            if (!hasFilter) ...[
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: onAdd,
                style: FilledButton.styleFrom(
                  backgroundColor: p.accent,
                  foregroundColor: p.onAccent,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
                icon: SIcon(SardIcons.add_circle_outline,
                    size: 17, color: p.onAccent),
                label: Text('أضف أول اقتباس',
                    style: context.ts(
                        size: 14, w: FontWeight.w700, color: p.onAccent)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// بطاقة اقتباس واحد.
class QuoteCard extends StatelessWidget {
  const QuoteCard({super.key, required this.quote, required this.store});

  final Quote quote;
  final QuoteStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: quote.category.color.withValues(alpha: 0.13),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SIcon(quote.category.icon,
                        size: 13, color: quote.category.color),
                    const SizedBox(width: 4),
                    Text(quote.category.label,
                        style: context.ts(
                            size: 11.5,
                            w: FontWeight.w700,
                            color: quote.category.color)),
                  ],
                ),
              ),
              const Spacer(),
              Text(formatArabicDate(quote.at),
                  style: context.ts(size: 11.5, color: p.textDim)),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            '«${quote.text}»',
            style: context.ts(size: 14.5, w: FontWeight.w500, color: p.text, height: 1.8),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  '— ${quote.sourceLabel}',
                  style: context.ts(size: 12, color: p.textDim),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              IconButton(
                onPressed: () async {
                  await Clipboard.setData(
                      ClipboardData(text: store.shareText(quote)));
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('نُسخ الاقتباس.')),
                  );
                },
                icon: SIcon(SardIcons.share_rounded,
                    size: 17, color: p.textDim),
                tooltip: 'نسخ',
              ),
              IconButton(
                onPressed: () => store.toggleFavorite(quote.id),
                icon: SIcon(
                  quote.favorite
                      ? SardIcons.favorite_rounded
                      : SardIcons.favorite_border_rounded,
                  size: 18,
                  color: quote.favorite
                      ? const Color(0xFFE0457B)
                      : p.textDim,
                ),
                tooltip: 'مفضلة',
              ),
              IconButton(
                onPressed: () => store.remove(quote.id),
                icon: SIcon(SardIcons.delete_outline_rounded,
                    size: 18, color: p.textDim),
                tooltip: 'حذف',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// ورقة إضافة اقتباس جديد.
class QuoteEditorSheet extends StatefulWidget {
  const QuoteEditorSheet({super.key, required this.store, this.prefill});

  final QuoteStore store;

  /// نص مقترح (يُمرَّر من القارئ أو من محرر اليومية).
  final String? prefill;

  @override
  State<QuoteEditorSheet> createState() => _QuoteEditorSheetState();
}

class _QuoteEditorSheetState extends State<QuoteEditorSheet> {
  late final TextEditingController _textCtrl;
  late final TextEditingController _sourceCtrl;
  late final TextEditingController _chapterCtrl;
  QuoteCategory _category = QuoteCategory.wisdom;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _textCtrl = TextEditingController(text: widget.prefill ?? '');
    _sourceCtrl = TextEditingController();
    _chapterCtrl = TextEditingController();
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    _sourceCtrl.dispose();
    _chapterCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(p.radius)),
      ),
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: p.border,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text('اقتباس جديد', style: context.ds(size: 19, color: p.text)),
            const SizedBox(height: 4),
            Text('احفظ السطر الذي أعجبك مع مصدره وتصنيفه.',
                style: context.ts(size: 12.5, color: p.textDim)),
            const SizedBox(height: 16),
            _QuoteField(
              controller: _textCtrl,
              label: 'نص الاقتباس',
              hint: 'اكتب السطر كما ورد في الفصل…',
              maxLines: 3,
            ),
            const SizedBox(height: 10),
            _QuoteField(
              controller: _sourceCtrl,
              label: 'اسم العمل (اختياري)',
              hint: 'مثال: سولو ليفلينغ',
            ),
            const SizedBox(height: 10),
            _QuoteField(
              controller: _chapterCtrl,
              label: 'رقم الفصل (اختياري)',
              hint: 'مثال: 12',
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 14),
            Text('التصنيف',
                style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in QuoteCategory.values)
                  ChoiceChip(
                    label: Text(c.label,
                        style: context.ts(
                            size: 13,
                            w: _category == c ? FontWeight.w700 : FontWeight.w500,
                            color: _category == c ? p.onAccent : p.text)),
                    avatar: SIcon(c.icon,
                        size: 15,
                        color: _category == c ? p.onAccent : c.color),
                    selected: _category == c,
                    onSelected: (_) => setState(() => _category = c),
                    selectedColor: c.color,
                    backgroundColor: p.bg,
                    side: BorderSide(
                        color: _category == c ? Colors.transparent : p.border),
                    showCheckmark: false,
                  ),
              ],
            ),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: _saving ? null : _save,
              style: FilledButton.styleFrom(
                backgroundColor: p.accent,
                foregroundColor: p.onAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: _saving
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: p.onAccent,
                      ),
                    )
                  : Text('حفظ الاقتباس',
                      style: context.ts(
                          size: 15, w: FontWeight.w700, color: p.onAccent)),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_textCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب نص الاقتباس أولاً.')),
      );
      return;
    }
    setState(() => _saving = true);
    await widget.store.add(
      text: _textCtrl.text,
      seriesTitle: _sourceCtrl.text,
      chapter: int.tryParse(_chapterCtrl.text.trim()) ?? 0,
      category: _category,
    );
    if (!mounted) return;
    Navigator.of(context).pop();
  }
}

class _QuoteField extends StatelessWidget {
  const _QuoteField({
    required this.controller,
    required this.label,
    required this.hint,
    this.maxLines = 1,
    this.keyboardType,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final int maxLines;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          maxLines: maxLines,
          keyboardType: keyboardType,
          style: context.ts(size: 14, color: p.text),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13, color: p.textDim),
            filled: true,
            fillColor: p.bg,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.border),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.accent, width: 1.4),
            ),
          ),
        ),
      ],
    );
  }
}
