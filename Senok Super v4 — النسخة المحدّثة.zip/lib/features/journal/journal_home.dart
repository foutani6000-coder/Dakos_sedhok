/// ──────────────────────────────────────────────────────────────────────────
/// لوحة «يومي في القراءة» — Journal Home
/// قسم يُضاف إلى الشاشة الرئيسية يجمع كل وحدات اليوميات في مكان واحد:
/// اقتباس اليوم، وفي مثل هذا اليوم، وممر الذكريات، وآخر موجز،
/// وإحصاءات سريعة. يأخذ المخازن جاهزةً ولا ينشئ أي مخزن بنفسه.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'family_mode.dart';
import 'memory_lane.dart';
import 'quotes_collection.dart';
import 'reading_journal.dart';
import 'smart_digest.dart';

/// لوحة يوميات مختصرة للشاشة الرئيسية.
class JournalHomeSection extends StatelessWidget {
  const JournalHomeSection({
    super.key,
    required this.settings,
    required this.journal,
    required this.quotes,
    required this.digests,
    this.onOpenJournal,
    this.onOpenQuotes,
    this.onOpenMemories,
    this.onOpenDigest,
  });

  final SettingsController settings;
  final JournalStore journal;
  final QuoteStore quotes;
  final DigestStore digests;

  final VoidCallback? onOpenJournal;
  final VoidCallback? onOpenQuotes;
  final VoidCallback? onOpenMemories;
  final VoidCallback? onOpenDigest;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final todayQuote = quotes.quoteOfDay();
    final onThisDay = journal.onThisDay();
    final memories = MemoryLaneEngine.build(
      entries: journal.entries,
      settings: settings,
    );
    final latestDigest = digests.latest;
    final stats = journal.stats;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(
          title: 'يومي في القراءة',
          actionLabel: 'كل اليوميات',
          onTap: onOpenJournal,
        ),
        const SizedBox(height: 10),
        // شريط إحصاءات سريع.
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              _QuickStat(
                icon: SardIcons.menu_book_rounded,
                label: 'ملاحظة',
                value: '${stats.total}',
              ),
              _QuickStat(
                icon: SardIcons.star_rounded,
                label: 'متوسط تقييمي',
                value: stats.averageRatingLabel,
              ),
              _QuickStat(
                icon: SardIcons.local_fire_department_rounded,
                label: 'سلسلة الأيام',
                value: '${settings.streak}',
              ),
              _QuickStat(
                icon: SardIcons.format_list_bulleted_rounded,
                label: 'اقتباس',
                value: '${quotes.length}',
              ),
            ],
          ),
        ),
        // اقتباس اليوم (مصغّر).
        if (todayQuote != null) ...[
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _TodayQuoteMini(
              quote: todayQuote,
              onTap: onOpenQuotes,
            ),
          ),
        ],
        // في مثل هذا اليوم.
        if (onThisDay.isNotEmpty) ...[
          const SizedBox(height: 6),
          OnThisDayCard(entries: onThisDay),
        ],
        // ممر الذكريات.
        if (memories.isNotEmpty) ...[
          const SizedBox(height: 14),
          MemoryLaneStrip(memories: memories),
        ],
        // آخر موجز.
        if (latestDigest != null) ...[
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _LatestDigestMini(
              digest: latestDigest,
              onTap: onOpenDigest,
            ),
          ),
        ],
        if (todayQuote == null &&
            onThisDay.isEmpty &&
            memories.isEmpty &&
            latestDigest == null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ابدأ يومياتك اليوم',
                      style: context.ds(size: 15, color: p.text)),
                  const SizedBox(height: 4),
                  Text(
                    'اكتب ملاحظة بعد أول فصل تقرؤه، واحفظ أول اقتباس يعجبك — '
                    'وسيبدأ هذا القسم بالامتلاء بذكرياتك وموجزاتك.',
                    style: context.ts(size: 12.5, color: p.textDim, height: 1.7),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    required this.actionLabel,
    required this.onTap,
  });

  final String title;
  final String actionLabel;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Text(title, style: context.ds(size: 18, color: p.text)),
          const Spacer(),
          if (onTap != null)
            TextButton(
              onPressed: onTap,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(actionLabel,
                      style: context.ts(
                          size: 13, w: FontWeight.w700, color: p.accent)),
                  const SizedBox(width: 2),
                  SIcon(SardIcons.chevron_left_rounded,
                      size: 16, color: p.accent),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _QuickStat extends StatelessWidget {
  const _QuickStat({
    required this.icon,
    required this.label,
    required this.value,
  });

  final SIconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Container(
        margin: const EdgeInsetsDirectional.only(end: 8),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: p.border),
        ),
        child: Column(
          children: [
            SIcon(icon, size: 17, color: p.accent),
            const SizedBox(height: 5),
            Text(value,
                style: context.ds(size: 14, color: p.text),
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
            Text(label,
                style: context.ts(size: 10.5, color: p.textDim),
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

/// اقتباس اليوم بصيغة مصغرة للشاشة الرئيسية.
class _TodayQuoteMini extends StatelessWidget {
  const _TodayQuoteMini({required this.quote, required this.onTap});

  final Quote quote;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [p.accent, p.accent.withValues(alpha: 0.72)],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SIcon(SardIcons.auto_awesome_rounded,
                    size: 16, color: p.onAccent),
                const SizedBox(width: 6),
                Text('اقتباس اليوم',
                    style: context.ts(
                        size: 12, w: FontWeight.w700, color: p.onAccent)),
                const Spacer(),
                Text(quote.category.label,
                    style: context.ts(size: 11.5, color: p.onAccent)),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              '«${quote.text}»',
              style: context.ts(
                  size: 14.5, w: FontWeight.w700, color: p.onAccent, height: 1.8),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              '— ${quote.sourceLabel}',
              style: context.ts(size: 12, color: p.onAccent),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

/// آخر موجز بصيغة مصغرة.
class _LatestDigestMini extends StatelessWidget {
  const _LatestDigestMini({required this.digest, required this.onTap});

  final SmartDigest digest;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: p.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SIcon(SardIcons.calendar_today_rounded,
                    size: 16, color: p.accent),
                const SizedBox(width: 6),
                Text('آخر موجز — ${digest.periodLabel}',
                    style: context.ts(
                        size: 13, w: FontWeight.w700, color: p.text)),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              digest.hasActivity
                  ? 'قرأت ${digest.chaptersRead} ${digest.chaptersRead == 1 ? 'فصلاً' : 'فصولاً'} في نحو ${digest.minutesEstimate} دقيقة، وكتبت ${digest.journalEntries} ${digest.journalEntries == 1 ? 'ملاحظة' : 'ملاحظات'}.'
                  : 'لم تسجّل قراءة في هذه الفترة بعد.',
              style: context.ts(size: 12.5, color: p.textDim, height: 1.7),
            ),
            if (digest.recommendationTitle.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                'توصيتك: ${digest.recommendationTitle}',
                style: context.ts(size: 12.5, w: FontWeight.w500, color: p.accent),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// بطاقة وصول سريع لأقسام اليوميات (تُستعمل في القائمة الجانبية أو الإعدادات).
class JournalQuickLinks extends StatelessWidget {
  const JournalQuickLinks({
    super.key,
    required this.onJournal,
    required this.onQuotes,
    required this.onMemories,
    required this.onDigest,
    required this.onFamily,
    required this.onYearReview,
  });

  final VoidCallback onJournal;
  final VoidCallback onQuotes;
  final VoidCallback onMemories;
  final VoidCallback onDigest;
  final VoidCallback onFamily;
  final VoidCallback onYearReview;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _QuickLink(
          icon: SardIcons.menu_book_rounded,
          title: 'يوميات القراءة',
          subtitle: 'ملاحظاتك بعد كل فصل',
          onTap: onJournal,
        ),
        _QuickLink(
          icon: SardIcons.format_list_bulleted_rounded,
          title: 'مجموعة الاقتباسات',
          subtitle: 'أجمل الأسطر التي حفظتَها',
          onTap: onQuotes,
        ),
        _QuickLink(
          icon: SardIcons.history_rounded,
          title: 'ممر الذكريات',
          subtitle: 'ما قرأتَه في مثل هذا اليوم',
          onTap: onMemories,
        ),
        _QuickLink(
          icon: SardIcons.calendar_today_rounded,
          title: 'موجزي في القراءة',
          subtitle: 'ملخص دوري لقراءتك',
          onTap: onDigest,
        ),
        _QuickLink(
          icon: SardIcons.auto_stories_rounded,
          title: 'مراجعة السنة',
          subtitle: 'سنتك في القراءة باختصار',
          onTap: onYearReview,
        ),
        _QuickLink(
          icon: SardIcons.groups_rounded,
          title: 'الوضع العائلي',
          subtitle: 'ملفات الأطفال والتقارير الأسبوعية',
          onTap: onFamily,
        ),
      ],
    );
  }
}

class _QuickLink extends StatelessWidget {
  const _QuickLink({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final SIconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: p.border),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: p.accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: SIcon(icon, size: 19, color: p.accent),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: context.ts(
                          size: 14, w: FontWeight.w700, color: p.text)),
                  Text(subtitle,
                      style: context.ts(size: 12, color: p.textDim)),
                ],
              ),
            ),
            SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
          ],
        ),
      ),
    );
  }
}

/// مزوّدات المخازن الأربعة معاً (تُسجَّل في main حول التطبيق).
/// تُمرَّر المخازن المحمّلة مسبقاً عبر [JournalStore.load] ونظيراتها.
class JournalStoresScope extends StatelessWidget {
  const JournalStoresScope({
    super.key,
    required this.journal,
    required this.quotes,
    required this.digests,
    required this.family,
    required this.child,
  });

  final JournalStore journal;
  final QuoteStore quotes;
  final DigestStore digests;
  final FamilyStore family;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<JournalStore>.value(value: journal),
        ChangeNotifierProvider<QuoteStore>.value(value: quotes),
        ChangeNotifierProvider<DigestStore>.value(value: digests),
        ChangeNotifierProvider<FamilyStore>.value(value: family),
      ],
      child: child,
    );
  }
}
