/// ──────────────────────────────────────────────────────────────────────────
/// الموجز الذكي — Smart Digest
/// موجز دوري (يومي/أسبوعي/شهري) يلخّص قراءتك من بيانات حقيقية:
/// إدخالات اليوميات في الفترة، والاقتباسات الجديدة، والمواظبة،
/// وأكثر تصنيف قرأتَه (من ذاكرة الأعمال في SettingsController).
/// الدقائق تقديرية وتُذكر كذلك في الواجهة. بلا أي ذكاء اصطناعي.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'quotes_collection.dart';
import 'reading_journal.dart';

/// فترة الموجز.
enum DigestPeriod {
  daily('اليوم', 1, 'موجز اليوم'),
  weekly('هذا الأسبوع', 7, 'موجز الأسبوع'),
  monthly('هذا الشهر', 30, 'موجز الشهر');

  const DigestPeriod(this.label, this.days, this.title);
  final String label;
  final int days;
  final String title;

  SIconData get icon {
    switch (this) {
      case DigestPeriod.daily:
        return SardIcons.wb_sunny_rounded;
      case DigestPeriod.weekly:
        return SardIcons.calendar_today_rounded;
      case DigestPeriod.monthly:
        return SardIcons.auto_stories_rounded;
    }
  }

  String get key => name;

  static DigestPeriod fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final p in DigestPeriod.values) {
      if (p.name == t) return p;
    }
    return DigestPeriod.weekly;
  }
}

/// موجز قراءة لفترة محددة.
@immutable
class SmartDigest {
  const SmartDigest({
    required this.id,
    required this.period,
    required this.from,
    required this.to,
    required this.chaptersRead,
    required this.minutesEstimate,
    required this.journalEntries,
    required this.newQuotes,
    required this.streak,
    required this.topGenre,
    required this.topSeriesTitle,
    required this.recommendationTitle,
    required this.recommendationReason,
    required this.quoteOfPeriod,
    required this.followedCount,
    required this.periodLabel,
    required this.createdAt,
  });

  final String id;
  final DigestPeriod period;

  /// بداية الفترة ونهايتها.
  final DateTime from;
  final DateTime to;

  /// فصول قرأتها في الفترة (إدخالات يوميات ذات chapter > 0).
  final int chaptersRead;

  /// دقائق تقديرية (8 دقائق للفصل + دقيقتان لكل ملاحظة مكتوبة).
  final int minutesEstimate;

  /// عدد إدخالات اليوميات في الفترة.
  final int journalEntries;

  /// عدد الاقتباسات الجديدة في الفترة.
  final int newQuotes;

  /// سلسلة أيام القراءة المتتالية.
  final int streak;

  /// أكثر تصنيف قرأتَه (من ذاكرة الأعمال)، أو null.
  final String? topGenre;

  /// أكثر عمل كتبتَ عنه في الفترة، أو null.
  final String? topSeriesTitle;

  /// عنوان التوصية القواعدية.
  final String recommendationTitle;

  /// سبب التوصية.
  final String recommendationReason;

  /// اقتباس الفترة (اقتباس اليوم في نهاية الفترة).
  final String quoteOfPeriod;

  /// عدد الأعمال المتابَعة.
  final int followedCount;

  /// تسمية الفترة للعرض («الأسبوع 24–30 نوفمبر 2026»).
  final String periodLabel;

  final DateTime createdAt;

  bool get hasActivity => chaptersRead > 0 || journalEntries > 0;

  /// ساعات تقديرية بصيغة «1.5».
  String get hoursEstimateLabel => (minutesEstimate / 60).toStringAsFixed(1);

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'period': period.key,
        'from': from.toIso8601String(),
        'to': to.toIso8601String(),
        'chapters_read': chaptersRead,
        'minutes_estimate': minutesEstimate,
        'journal_entries': journalEntries,
        'new_quotes': newQuotes,
        'streak': streak,
        'top_genre': topGenre,
        'top_series_title': topSeriesTitle,
        'recommendation_title': recommendationTitle,
        'recommendation_reason': recommendationReason,
        'quote_of_period': quoteOfPeriod,
        'followed_count': followedCount,
        'period_label': periodLabel,
        'created_at': createdAt.toIso8601String(),
      };

  factory SmartDigest.fromJson(Map<String, dynamic> j) => SmartDigest(
        id: '${j['id'] ?? ''}',
        period: DigestPeriod.fromKey(j['period']),
        from: DateTime.tryParse('${j['from'] ?? ''}') ?? DateTime.now(),
        to: DateTime.tryParse('${j['to'] ?? ''}') ?? DateTime.now(),
        chaptersRead: (j['chapters_read'] as num?)?.toInt() ?? 0,
        minutesEstimate: (j['minutes_estimate'] as num?)?.toInt() ?? 0,
        journalEntries: (j['journal_entries'] as num?)?.toInt() ?? 0,
        newQuotes: (j['new_quotes'] as num?)?.toInt() ?? 0,
        streak: (j['streak'] as num?)?.toInt() ?? 0,
        topGenre: j['top_genre'] as String?,
        topSeriesTitle: j['top_series_title'] as String?,
        recommendationTitle: '${j['recommendation_title'] ?? ''}',
        recommendationReason: '${j['recommendation_reason'] ?? ''}',
        quoteOfPeriod: '${j['quote_of_period'] ?? ''}',
        followedCount: (j['followed_count'] as num?)?.toInt() ?? 0,
        periodLabel: '${j['period_label'] ?? ''}',
        createdAt:
            DateTime.tryParse('${j['created_at'] ?? ''}') ?? DateTime.now(),
      );

  /// نص مشاركة الموجز.
  String toShareText() {
    final b = StringBuffer();
    b.writeln('موجزي في القراءة على Senok');
    b.writeln(periodLabel);
    if (hasActivity) {
      b.writeln('قرأت $chaptersRead فصلاً في نحو $minutesEstimate دقيقة');
      b.writeln('وكتبت $journalEntries ملاحظة في يومياتي');
    } else {
      b.writeln('لم أقرأ شيئاً في هذه الفترة — العودة أقرب مما تظن.');
    }
    if (streak > 1) {
      b.writeln('سلسلة قراءتي المتتالية: $streak أيام');
    }
    if (topGenre != null) {
      b.writeln('أكثر تصنيف قرأتُه: $topGenre');
    }
    if (recommendationTitle.isNotEmpty) {
      b.writeln('توصيتي التالية: $recommendationTitle');
    }
    if (quoteOfPeriod.isNotEmpty) {
      b.writeln('«$quoteOfPeriod»');
    }
    b.writeln('#Senok');
    return b.toString();
  }
}

/// بانٍ حتمي للموجزات من المصادر الحقيقية.
class DigestBuilder {
  const DigestBuilder._();

  /// يبني موجزاً لفترة [period] تنتهي في [now] (أو الآن).
  static SmartDigest build({
    required SettingsController settings,
    required JournalStore journal,
    required QuoteStore quotes,
    required DigestPeriod period,
    DateTime? now,
  }) {
    final end = now ?? DateTime.now();
    final start = startOfDay(end).subtract(Duration(days: period.days - 1));
    final endInclusive = endOfDay(end);
    final inPeriod = journal.entriesInRange(start, endInclusive);

    var chapters = 0;
    final perSeries = <String, int>{};
    for (final e in inPeriod) {
      if (e.chapter > 0) chapters++;
      perSeries[e.seriesTitle] = (perSeries[e.seriesTitle] ?? 0) + 1;
    }
    String? topSeries;
    var topCount = 0;
    for (final e in perSeries.entries) {
      if (e.value > topCount) {
        topSeries = e.key;
        topCount = e.value;
      }
    }
    final newQuotes = quotes.entries
        .where((q) => !q.at.isBefore(start) && !q.at.isAfter(endInclusive))
        .length;
    final topGenre = settings.topGenre;
    final quote = quotes.quoteOfDay(day: end);

    final rec = _recommendation(
      topGenre: topGenre,
      topSeriesTitle: topSeries,
      followedCount: settings.followedSeries.length,
    );

    return SmartDigest(
      id: 'dg${end.microsecondsSinceEpoch.toRadixString(36)}',
      period: period,
      from: start,
      to: endInclusive,
      chaptersRead: chapters,
      // تقدير: 8 دقائق للفصل + دقيقتان لكل ملاحظة مكتوبة.
      minutesEstimate: chapters * 8 + inPeriod.length * 2,
      journalEntries: inPeriod.length,
      newQuotes: newQuotes,
      streak: settings.streak,
      topGenre: topGenre,
      topSeriesTitle: topSeries,
      recommendationTitle: rec.$1,
      recommendationReason: rec.$2,
      quoteOfPeriod: quote?.text ?? '',
      followedCount: settings.followedSeries.length,
      periodLabel: _periodLabel(period, start, end),
      createdAt: end,
    );
  }

  /// توصية قواعدية: حسب أكثر تصنيف وأكثر عمل، لا حسب أي نموذج.
  static (String, String) _recommendation({
    required String? topGenre,
    required String? topSeriesTitle,
    required int followedCount,
  }) {
    if (topSeriesTitle != null) {
      return (
        'واصل «$topSeriesTitle»',
        topGenre == null
            ? 'كتبتَ عنه أكثر من غيره في هذه الفترة.'
            : 'كتبتَ عنه أكثر من غيره، ويبدو أن تصنيف «$topGenre» يعجبك هذه الأيام.',
      );
    }
    if (topGenre != null) {
      return (
        'جرّب عملاً جديداً من تصنيف «$topGenre»',
        'هذا التصنيف هو أكثر ما قرأتَه مؤخراً.',
      );
    }
    if (followedCount > 0) {
      return (
        'عُد إلى أعمالك المتابَعة',
        'لديك $followedCount ${followedCount == 1 ? 'عمل' : 'أعمال'} تتابعها وتنتظرك فصولها.',
      );
    }
    return (
      'ابدأ أول فصل اليوم',
      'لم تسجّل قراءة بعد في هذه الفترة — فصل واحد يكفي لبدء الموجز القادم.',
    );
  }

  static String _periodLabel(DigestPeriod period, DateTime from, DateTime to) {
    switch (period) {
      case DigestPeriod.daily:
        return 'يوم ${formatArabicDate(to)}';
      case DigestPeriod.weekly:
        return 'الأسبوع ${formatArabicDate(from)} – ${formatArabicDate(to)}';
      case DigestPeriod.monthly:
        return '${kArabicMonths[to.month - 1]} ${to.year}';
    }
  }
}

// ───────────────────────── مخزن الموجزات ─────────────────────────

/// مخزن الموجزات المولّدة (المفتاح `smart_digests_v1`) — يحتفظ بآخر 4 فقط.
class DigestStore extends ChangeNotifier {
  DigestStore._(this._p) {
    _digests = _readAll();
  }

  final SharedPreferences _p;
  late List<SmartDigest> _digests;

  /// يبني مخزناً من تفضيلات جاهزة (للاختبارات والتكامل اليدوي).
  DigestStore.forPrefs(SharedPreferences prefs) : this._(prefs);

  static const String kStoreKey = 'smart_digests_v1';
  static const int kMaxKept = 4;

  static Future<DigestStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    return DigestStore._(prefs);
  }

  /// نسخة للاختبارات.
  static Future<DigestStore> testInstance({Map<String, Object>? seed}) async {
    // ignore: invalid_use_of_visible_for_testing_member
    SharedPreferences.setMockInitialValues(seed ?? const <String, Object>{});
    final prefs = await SharedPreferences.getInstance();
    return DigestStore._(prefs);
  }

  List<SmartDigest> _readAll() {
    try {
      final raw = _p.getString(kStoreKey);
      if (raw == null || raw.isEmpty) return <SmartDigest>[];
      final list = jsonDecode(raw) as List;
      final out = list
          .whereType<Map>()
          .map((e) => SmartDigest.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      out.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return out;
    } catch (_) {
      return <SmartDigest>[];
    }
  }

  Future<void> _save() async {
    await _p.setString(
      kStoreKey,
      jsonEncode(_digests.map((d) => d.toJson()).toList()),
    );
  }

  /// الموجزات المحفوظة (الأحدث أولاً، 4 كحد أقصى).
  List<SmartDigest> get digests => List<SmartDigest>.unmodifiable(_digests);

  /// أحدث موجز (null عند عدم وجود أي موجز).
  SmartDigest? get latest => _digests.isEmpty ? null : _digests.first;

  /// يولّد موجزاً جديداً للفترة ويحفظه (ويحذف الأقدم عند تجاوز 4).
  Future<SmartDigest> generate({
    required SettingsController settings,
    required JournalStore journal,
    required QuoteStore quotes,
    required DigestPeriod period,
    DateTime? now,
  }) async {
    final digest = DigestBuilder.build(
      settings: settings,
      journal: journal,
      quotes: quotes,
      period: period,
      now: now,
    );
    _digests.insert(0, digest);
    if (_digests.length > kMaxKept) {
      _digests = _digests.sublist(0, kMaxKept);
    }
    await _save();
    notifyListeners();
    return digest;
  }

  /// يحذف موجزاً بالمعرّف.
  Future<bool> remove(String id) async {
    final before = _digests.length;
    _digests.removeWhere((d) => d.id == id);
    if (_digests.length == before) return false;
    await _save();
    notifyListeners();
    return true;
  }
}

// ───────────────────────── واجهة الموجز ─────────────────────────

/// شاشة الموجز الذكي: توليد موجز جديد + قائمة الموجزات المحفوظة.
class DigestScreen extends StatefulWidget {
  const DigestScreen({
    super.key,
    required this.settings,
    required this.journal,
    required this.quotes,
    required this.store,
  });

  final SettingsController settings;
  final JournalStore journal;
  final QuoteStore quotes;
  final DigestStore store;

  @override
  State<DigestScreen> createState() => _DigestScreenState();
}

class _DigestScreenState extends State<DigestScreen> {
  DigestPeriod _period = DigestPeriod.weekly;
  bool _generating = false;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final digests = context.watch<DigestStore>().digests;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text('موجزي في القراءة', style: context.ds(size: 20, color: p.text)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Text(
            'ملخص دوري لقراءتك من بياناتك الحقيقية — بلا أي تحليل خارجي.',
            style: context.ts(size: 13, color: p.textDim, height: 1.7),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              for (final period in DigestPeriod.values)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8),
                    child: ChoiceChip(
                      label: Center(
                        child: Text(period.label,
                            style: context.ts(
                                size: 13,
                                w: _period == period
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                                color: _period == period
                                    ? p.onAccent
                                    : p.text)),
                      ),
                      selected: _period == period,
                      onSelected: (_) =>
                          setState(() => _period = period),
                      selectedColor: p.accent,
                      backgroundColor: p.surface,
                      side: BorderSide(
                          color: _period == period
                              ? Colors.transparent
                              : p.border),
                      showCheckmark: false,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _generating ? null : _generate,
            style: FilledButton.styleFrom(
              backgroundColor: p.accent,
              foregroundColor: p.onAccent,
              padding: const EdgeInsets.symmetric(vertical: 13),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            icon: _generating
                ? SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: p.onAccent,
                    ),
                  )
                : SIcon(SardIcons.auto_awesome_rounded,
                    size: 18, color: p.onAccent),
            label: Text('ولّد موجز ${_period.title}',
                style: context.ts(size: 14, w: FontWeight.w700, color: p.onAccent)),
          ),
          const SizedBox(height: 8),
          Text(
            'تُحفظ آخر 4 موجزات فقط؛ توليد موجز جديد يحذف الأقدم تلقائياً.',
            style: context.ts(size: 11.5, color: p.textDim),
          ),
          const SizedBox(height: 18),
          if (digests.isEmpty)
            _DigestEmptyState()
          else
            for (final d in digests) ...[
              DigestCard(digest: d, store: widget.store),
              const SizedBox(height: 10),
            ],
        ],
      ),
    );
  }

  Future<void> _generate() async {
    setState(() => _generating = true);
    await widget.store.generate(
      settings: widget.settings,
      journal: widget.journal,
      quotes: widget.quotes,
      period: _period,
    );
    if (mounted) setState(() => _generating = false);
  }
}

class _DigestEmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          SIcon(SardIcons.calendar_today_rounded, size: 36, color: p.accent),
          const SizedBox(height: 12),
          Text('لا موجزات بعد', style: context.ds(size: 17, color: p.text)),
          const SizedBox(height: 6),
          Text(
            'ولّد أول موجز لترى ملخص قراءتك: الفصول، والدقائق التقديرية، '
            'وأكثر تصنيف قرأتَه، وتوصيتك التالية.',
            style: context.ts(size: 13, color: p.textDim, height: 1.8),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

/// بطاقة موجز واحد محفوظ.
class DigestCard extends StatelessWidget {
  const DigestCard({super.key, required this.digest, required this.store});

  final SmartDigest digest;
  final DigestStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(digest.period.icon, size: 18, color: p.accent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(digest.periodLabel,
                    style: context.ds(size: 15.5, color: p.text),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
              ),
              IconButton(
                onPressed: () async {
                  await Clipboard.setData(
                      ClipboardData(text: digest.toShareText()));
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('نُسخ نص الموجز.')),
                  );
                },
                icon: SIcon(SardIcons.share_rounded, size: 17, color: p.textDim),
                tooltip: 'نسخ الموجز',
              ),
              IconButton(
                onPressed: () => store.remove(digest.id),
                icon: SIcon(SardIcons.delete_outline_rounded,
                    size: 17, color: p.textDim),
                tooltip: 'حذف',
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _DigestNumber(
                  label: 'فصلاً', value: '${digest.chaptersRead}'),
              _DigestNumber(
                  label: 'دقيقة (تقدير)', value: '${digest.minutesEstimate}'),
              _DigestNumber(
                  label: 'ملاحظة', value: '${digest.journalEntries}'),
              _DigestNumber(
                  label: 'سلسلة الأيام', value: '${digest.streak}'),
            ],
          ),
          if (digest.topGenre != null) ...[
            const SizedBox(height: 10),
            Text('أكثر تصنيف قرأتَه: ${digest.topGenre}',
                style: context.ts(size: 13, color: p.text)),
          ],
          if (digest.topSeriesTitle != null) ...[
            const SizedBox(height: 2),
            Text('أكثر عمل كتبتَ عنه: «${digest.topSeriesTitle}»',
                style: context.ts(size: 13, color: p.text)),
          ],
          if (digest.newQuotes > 0) ...[
            const SizedBox(height: 2),
            Text('اقتباسات جديدة: ${digest.newQuotes}',
                style: context.ts(size: 13, color: p.text)),
          ],
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: p.bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: p.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SIcon(SardIcons.light_mode_rounded,
                        size: 16, color: p.gold),
                    const SizedBox(width: 6),
                    Text('توصيتك التالية',
                        style: context.ts(
                            size: 12, w: FontWeight.w700, color: p.gold)),
                  ],
                ),
                const SizedBox(height: 4),
                Text(digest.recommendationTitle,
                    style: context.ts(
                        size: 13.5, w: FontWeight.w700, color: p.text)),
                Text(digest.recommendationReason,
                    style: context.ts(size: 12.5, color: p.textDim, height: 1.6)),
              ],
            ),
          ),
          if (digest.quoteOfPeriod.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text('«${digest.quoteOfPeriod}»',
                style: context.ts(
                    size: 13, w: FontWeight.w500, color: p.text, height: 1.7)),
          ],
          const SizedBox(height: 6),
          Text(
            'الدقائق تقديرية (8 دقائق للفصل + دقيقتان لكل ملاحظة).',
            style: context.ts(size: 11, color: p.textDim),
          ),
        ],
      ),
    );
  }
}

class _DigestNumber extends StatelessWidget {
  const _DigestNumber({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: context.ds(size: 17, color: p.text),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          Text(label,
              style: context.ts(size: 11, color: p.textDim),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}
