/// ──────────────────────────────────────────────────────────────────────────
/// مراجعة السنة — Year in Review
/// ملخص سنوي لرحلة القارئ: الفصول والدقائق وأيام القراءة وأفضل شهر،
/// مبني من بيانات حقيقية (SettingsController + اليوميات + الاقتباسات).
/// الأرقام الكلية (الفصول والدقائق) هي إجمالي ما سجّله التطبيق، بينما
/// توزيع الأشهر وأفضل شهر يُشتقّان من إدخالات اليوميات في تلك السنة،
/// ويُشار إلى التقدير بوضوح في الواجهة.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'quotes_collection.dart';
import 'reading_journal.dart';

/// بيانات مراجعة سنة كاملة. تُبنى عبر [YearInReviewData.of].
@immutable
class YearInReviewData {
  const YearInReviewData({
    required this.year,
    required this.chapters,
    required this.minutes,
    required this.days,
    required this.bestMonth,
    required this.journalEntries,
    required this.averageRating,
    required this.monthlyDistributionEstimated,
    required this.topSeriesTitle,
    required this.quotesCount,
    required this.dominantMood,
  });

  /// السنة التي تلخّصها هذه المراجعة.
  final int year;

  /// إجمالي الفصول المقروءة المسجلة في التطبيق.
  final int chapters;

  /// إجمالي دقائق القراءة المسجلة في التطبيق.
  final int minutes;

  /// عدد أيام القراءة في هذه السنة.
  final int days;

  /// أفضل شهر (1..12) حسب إدخالات اليوميات، أو 0 عند عدم وجود إدخالات.
  final int bestMonth;

  /// اسم أفضل شهر، أو '—' عند عدم وجوده.
  String get bestMonthName =>
      bestMonth == 0 ? '—' : kArabicMonths[bestMonth - 1];

  /// عدد إدخالات اليوميات في هذه السنة.
  final int journalEntries;

  /// متوسط تقييمات السنة (0.0 عند عدم وجود أي تقييم).
  final double averageRating;

  /// توزيع إدخالات اليوميات على أشهر السنة (12 رقماً).
  /// تقديري: يُحسب من إدخالات اليوميات فقط، وليس من سجل القراءة الكامل.
  final List<int> monthlyDistributionEstimated;

  /// أكثر عمل كُتبت عنه ملاحظات في السنة (null عند عدم وجود إدخالات).
  final String? topSeriesTitle;

  /// عدد الاقتباسات المحفوظة في السنة.
  final int quotesCount;

  /// المزاج الغالب في السنة (null عند عدم وجود إدخالات).
  final JournalMood? dominantMood;

  /// ساعات القراءة بصيغة «12.5».
  String get hoursLabel => (minutes / 60).toStringAsFixed(1);

  /// متوسط التقييم بصيغة «4.2» أو '—'.
  String get averageRatingLabel =>
      averageRating <= 0 ? '—' : averageRating.toStringAsFixed(1);

  /// أعلى قيمة في التوزيع الشهري (لتطبيع الأعمدة).
  int get maxMonthValue => monthlyDistributionEstimated.fold<int>(
      0, (a, b) => b > a ? b : a);

  /// يبني مراجعة سنة من المصادر الثلاثة.
  factory YearInReviewData.of(
    SettingsController settings,
    JournalStore journal,
    QuoteStore quotes, {
    int? year,
  }) {
    final y = year ?? DateTime.now().year;
    final entries = journal.entriesInYear(y);
    final monthly = List<int>.filled(12, 0);
    final perSeries = <String, int>{};
    final perMood = <JournalMood, int>{};
    var ratedSum = 0;
    var ratedCount = 0;
    for (final e in entries) {
      monthly[e.at.month - 1]++;
      perSeries[e.seriesTitle] = (perSeries[e.seriesTitle] ?? 0) + 1;
      perMood[e.mood] = (perMood[e.mood] ?? 0) + 1;
      if (e.hasRating) {
        ratedSum += e.rating;
        ratedCount++;
      }
    }
    var bestMonth = 0;
    var bestCount = 0;
    for (var i = 0; i < 12; i++) {
      if (monthly[i] > bestCount) {
        bestCount = monthly[i];
        bestMonth = i + 1;
      }
    }
    String? top;
    var topCount = 0;
    for (final e in perSeries.entries) {
      if (e.value > topCount) {
        top = e.key;
        topCount = e.value;
      }
    }
    JournalMood? dominant;
    var dominantCount = 0;
    for (final e in perMood.entries) {
      if (e.value > dominantCount) {
        dominant = e.key;
        dominantCount = e.value;
      }
    }
    final yearQuotes = quotes.entries.where((q) => q.at.year == y).length;
    return YearInReviewData(
      year: y,
      chapters: settings.totalChaptersRead,
      minutes: settings.totalReadingSeconds ~/ 60,
      days: settings.readDaysInYear(y),
      bestMonth: bestMonth,
      journalEntries: entries.length,
      averageRating: ratedCount == 0 ? 0.0 : ratedSum / ratedCount,
      monthlyDistributionEstimated: monthly,
      topSeriesTitle: top,
      quotesCount: yearQuotes,
      dominantMood: dominant,
    );
  }

  /// نص قابل للمشاركة يلخّص السنة.
  String toShareText() {
    final b = StringBuffer();
    b.writeln('مراجعتي في القراءة — $year على Senok');
    b.writeln('قرأت $chapters فصلاً في $days يوماً');
    b.writeln('بإجمالي $minutes دقيقة قراءة');
    if (bestMonth != 0) {
      b.writeln('أفضل شهور القراءة: $bestMonthName');
    }
    if (topSeriesTitle != null) {
      b.writeln('أكثر عمل كتبتُ عنه: $topSeriesTitle');
    }
    if (averageRating > 0) {
      b.writeln('متوسط تقييمي: ${averageRating.toStringAsFixed(1)} من 5');
    }
    b.writeln('وكتبت $journalEntries ملاحظة في يومياتي');
    if (quotesCount > 0) {
      b.writeln('وحفظت $quotesCount اقتباساً');
    }
    b.writeln('#Senok');
    return b.toString();
  }
}

// ───────────────────────── واجهة مراجعة السنة ─────────────────────────

/// شاشة مراجعة السنة: بطاقة ملخّص + أعمدة الأشهر + أبرز النقاط + مشاركة.
class YearInReviewScreen extends StatefulWidget {
  const YearInReviewScreen({
    super.key,
    required this.settings,
    required this.journal,
    required this.quotes,
    this.initialYear,
  });

  final SettingsController settings;
  final JournalStore journal;
  final QuoteStore quotes;
  final int? initialYear;

  @override
  State<YearInReviewScreen> createState() => _YearInReviewScreenState();
}

class _YearInReviewScreenState extends State<YearInReviewScreen> {
  late int _year;

  @override
  void initState() {
    super.initState();
    _year = widget.initialYear ?? DateTime.now().year;
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final data = YearInReviewData.of(
      widget.settings,
      widget.journal,
      widget.quotes,
      year: _year,
    );
    final nowYear = DateTime.now().year;
    final years = <int>[
      for (var y = nowYear; y >= nowYear - 4; y--) y,
    ];

    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text('مراجعة السنة', style: context.ds(size: 20, color: p.text)),
        actions: [
          IconButton(
            onPressed: () => _share(context, data),
            icon: SIcon(SardIcons.share_rounded, size: 20, color: p.text),
            tooltip: 'مشاركة مراجعتي',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          _YearPicker(
            years: years,
            selected: _year,
            onSelected: (y) => setState(() => _year = y),
          ),
          const SizedBox(height: 14),
          _SummaryCard(data: data),
          const SizedBox(height: 16),
          Text('نشاطك خلال الأشهر',
              style: context.ds(size: 17, color: p.text)),
          const SizedBox(height: 4),
          Text(
            'الأعمدة تُحسب من إدخالات يومياتك في كل شهر (تقديري).',
            style: context.ts(size: 12, color: p.textDim),
          ),
          const SizedBox(height: 12),
          _MonthsBarChart(data: data),
          const SizedBox(height: 20),
          Text('أبرز نقاط السنة', style: context.ds(size: 17, color: p.text)),
          const SizedBox(height: 10),
          _HighlightTile(
            icon: SardIcons.local_fire_department_rounded,
            color: const Color(0xFFFF6B35),
            title: 'أفضل شهر',
            value: data.bestMonthName,
            subtitle: data.bestMonth == 0
                ? 'اكتب ملاحظات في يومياتك ليظهر أفضل شهورك.'
                : 'الشهر الذي كتبتَ فيه أكثر الملاحظات.',
          ),
          _HighlightTile(
            icon: SardIcons.menu_book_rounded,
            color: p.accent,
            title: 'أكثر عمل كتبتَ عنه',
            value: data.topSeriesTitle ?? '—',
            subtitle: 'حسب ملاحظات اليوميات في هذه السنة.',
          ),
          _HighlightTile(
            icon: SardIcons.emoji_emotions_rounded,
            color: data.dominantMood?.color ?? p.textDim,
            title: 'مزاجك الغالب',
            value: data.dominantMood?.label ?? '—',
            subtitle: data.dominantMood == null
                ? 'سجّل مزاجك مع كل ملاحظة لترى نمطك.'
                : 'المزاج الأكثر تكراراً في ملاحظاتك.',
          ),
          _HighlightTile(
            icon: SardIcons.format_list_bulleted_rounded,
            color: p.gold,
            title: 'اقتباسات محفوظة',
            value: '${data.quotesCount}',
            subtitle: 'اقتباساً حفظتَه من فصول قرأتها هذه السنة.',
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: p.border),
            ),
            child: Text(
              'ملاحظة: عدد الفصول والدقائق هو إجمالي ما سجّله التطبيق منذ بدأت القراءة، '
              'بينما توزيع الأشهر وأفضل شهر يُحسبان من يومياتك في سنة $_year فقط.',
              style: context.ts(size: 12.5, color: p.textDim, height: 1.7),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _share(BuildContext context, YearInReviewData data) async {
    await Clipboard.setData(ClipboardData(text: data.toShareText()));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('نُسخ نص مراجعتك — شاركه أينما تريد.')),
    );
  }
}

/// منتقي السنة (رقائق أفقية).
class _YearPicker extends StatelessWidget {
  const _YearPicker({
    required this.years,
    required this.selected,
    required this.onSelected,
  });

  final List<int> years;
  final int selected;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: years.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final y = years[i];
          final isSel = y == selected;
          return ChoiceChip(
            label: Text('$y',
                style: context.ts(
                    size: 14,
                    w: isSel ? FontWeight.w700 : FontWeight.w500,
                    color: isSel ? p.onAccent : p.text)),
            selected: isSel,
            onSelected: (_) => onSelected(y),
            selectedColor: p.accent,
            backgroundColor: p.surface,
            side: BorderSide(color: isSel ? Colors.transparent : p.border),
            showCheckmark: false,
          );
        },
      ),
    );
  }
}

/// بطاقة الملخص الكبير: سنة + 4 أرقام رئيسية.
class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.data});

  final YearInReviewData data;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [p.accent, p.accent.withValues(alpha: 0.75)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.auto_stories_rounded,
                  size: 22, color: p.onAccent),
              const SizedBox(width: 8),
              Text('سنتك في القراءة',
                  style: context.ds(size: 16, color: p.onAccent)),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: p.onAccent.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text('${data.year}',
                    style: context.ds(size: 15, color: p.onAccent)),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              _BigNumber(
                  label: 'فصلاً قرأت', value: '${data.chapters}'),
              _BigNumber(label: 'يوم قراءة', value: '${data.days}'),
              _BigNumber(label: 'ساعة', value: data.hoursLabel),
              _BigNumber(
                  label: 'متوسط التقييم', value: data.averageRatingLabel),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'وكتبت ${data.journalEntries} ملاحظة في يومياتك خلال هذه السنة.',
            style: context.ts(
                size: 13, w: FontWeight.w500, color: p.onAccent, height: 1.6),
          ),
        ],
      ),
    );
  }
}

class _BigNumber extends StatelessWidget {
  const _BigNumber({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style: context.ds(size: 20, color: p.onAccent),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          Text(label,
              style: context.ts(size: 11.5, color: p.onAccent, height: 1.4),
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

/// رسم أعمدة شهري: 12 عموداً بارتفاع متناسب مع عدد الملاحظات.
class _MonthsBarChart extends StatelessWidget {
  const _MonthsBarChart({required this.data});

  final YearInReviewData data;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final max = data.maxMonthValue;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 10),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (var i = 0; i < 12; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      max == 0 ? '' : '${data.monthlyDistributionEstimated[i]}',
                      style: context.ts(
                          size: 10,
                          w: FontWeight.w700,
                          color: data.bestMonth == i + 1 ? p.gold : p.textDim),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      height: 8 +
                          (max == 0
                              ? 0
                              : (data.monthlyDistributionEstimated[i] / max) *
                                  92),
                      decoration: BoxDecoration(
                        color: data.bestMonth == i + 1 ? p.gold : p.accent,
                        borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(5)),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      kArabicMonths[i].substring(0, 3),
                      style: context.ts(
                          size: 10,
                          color: data.bestMonth == i + 1 ? p.text : p.textDim),
                      maxLines: 1,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// صف «أبرز نقطة» بأيقونة وعنوان وقيمة.
class _HighlightTile extends StatelessWidget {
  const _HighlightTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.value,
    required this.subtitle,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String value;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.13),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SIcon(icon, size: 20, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: context.ts(size: 12, color: p.textDim)),
                Text(value,
                    style: context.ts(size: 15, w: FontWeight.w700, color: p.text),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                Text(subtitle,
                    style: context.ts(size: 12, color: p.textDim, height: 1.5),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
