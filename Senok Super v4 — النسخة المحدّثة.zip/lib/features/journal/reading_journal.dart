/// ──────────────────────────────────────────────────────────────────────────
/// يوميات القراءة — Journal
/// يكتب القارئ ملاحظة قصيرة بعد كل فصل: ماذا شعر؟ ما الاقتباس الذي علق
/// بذهنه؟ وتقييمه من 5 نجوم. كل شيء محلي بالكامل (SharedPreferences)،
/// بلا خادم وبلا حساب، مع تصدير/استيراد نصي وJSON.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// أسماء الأشهر العربية (المشرقية) المستعملة في كل وحدات اليوميات.
const List<String> kArabicMonths = <String>[
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

/// أسماء أيام الأسبوع العربية (يبدأ بالأحد كما في التقويم العربي الشائع).
const List<String> kArabicWeekdays = <String>[
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
  'الأحد',
];

/// 2026-11-26 -> «26 نوفمبر 2026»
String formatArabicDate(DateTime d) => '${d.day} ${kArabicMonths[d.month - 1]} ${d.year}';

/// 2026-11-26 -> «الخميس، 26 نوفمبر 2026»
String formatArabicFullDate(DateTime d) =>
    '${kArabicWeekdays[d.weekday - 1]}، ${formatArabicDate(d)}';

/// مفتاح يوم بصيغة YYYY-MM-DD (مطابق لمفاتيح SettingsController).
String dayKeyOf(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// هل التاريخان في اليوم نفسه؟
bool isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// هل التاريخان في الشهر نفسه؟
bool isSameMonth(DateTime a, DateTime b) => a.year == b.year && a.month == b.month;

/// بداية اليوم (00:00).
DateTime startOfDay(DateTime d) => DateTime(d.year, d.month, d.day);

/// نهاية اليوم (23:59:59).
DateTime endOfDay(DateTime d) => DateTime(d.year, d.month, d.day, 23, 59, 59);

/// معرّف فريد قصير من الطابع الزمني وعشوائية صغيرة.
String newJournalId() {
  final n = DateTime.now().microsecondsSinceEpoch;
  final r = math.Random().nextInt(1 << 20);
  return 'j${n.toRadixString(36)}${r.toRadixString(36)}';
}

// ───────────────────────── المزاج ─────────────────────────

/// مزاج القراءة: خمس حالات فقط، لكل منها لون وتسمية عربية.
enum JournalMood {
  amazing('مذهل', 'فصل لا يُنسى', 0xFFFFB020),
  happy('سعيد', 'قراءة ممتعة', 0xFF4CAF50),
  calm('هادئ', 'قراءة هادئة مريحة', 0xFF3B9EFF),
  tense('متوتر', 'أحداث مشدودة', 0xFFFF6B35),
  sad('حزين', 'لحظات مؤثرة', 0xFF7E6BFF);

  const JournalMood(this.label, this.hint, this.colorValue);
  final String label;
  final String hint;
  final int colorValue;

  Color get color => Color(colorValue);

  /// أيقونة معبّرة من مجموعة أيقونات التطبيق (بلا إيموجي).
  SIconData get icon {
    switch (this) {
      case JournalMood.amazing:
        return SardIcons.auto_awesome_rounded;
      case JournalMood.happy:
        return SardIcons.emoji_emotions_rounded;
      case JournalMood.calm:
        return SardIcons.spa_rounded;
      case JournalMood.tense:
        return SardIcons.local_fire_department_rounded;
      case JournalMood.sad:
        return SardIcons.nightlight_round;
    }
  }

  String get key => name;

  static JournalMood fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final m in JournalMood.values) {
      if (m.name == t) return m;
    }
    return JournalMood.calm;
  }
}

// ───────────────────────── إدخال اليومية ─────────────────────────

/// إدخال واحد في يوميات القراءة: ملاحظة على فصل محدد من عمل محدد.
@immutable
class JournalEntry {
  const JournalEntry({
    required this.id,
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.text,
    required this.mood,
    required this.rating,
    required this.at,
    this.quote = '',
  });

  /// معرّف الإدخال.
  final String id;

  /// معرّف العمل.
  final String seriesId;

  /// عنوان العمل (يُحفظ مع الإدخال ليبقى ظاهراً حتى لو حُذف العمل).
  final String seriesTitle;

  /// رقم الفصل الذي كُتبت عنه الملاحظة (0 = ملاحظة عامة بلا فصل).
  final int chapter;

  /// نص الملاحظة.
  final String text;

  /// اقتباس أعجب القارئ من الفصل (اختياري).
  final String quote;

  /// مزاج القراءة.
  final JournalMood mood;

  /// التقييم من 0 إلى 5 (0 = بلا تقييم).
  final int rating;

  /// وقت كتابة الإدخال.
  final DateTime at;

  bool get hasQuote => quote.trim().isNotEmpty;
  bool get hasRating => rating > 0;
  bool get hasChapter => chapter > 0;

  /// نجوم التقييم كنص: «★★★☆☆».
  String get starsLabel {
    final r = rating.clamp(0, 5);
    return '★' * r + '☆' * (5 - r);
  }

  /// عنوان قصير للعرض: «الفصل 12» أو «ملاحظة عامة».
  String get chapterLabel => hasChapter ? 'الفصل $chapter' : 'ملاحظة عامة';

  JournalEntry copyWith({
    String? id,
    String? seriesId,
    String? seriesTitle,
    int? chapter,
    String? text,
    String? quote,
    JournalMood? mood,
    int? rating,
    DateTime? at,
  }) =>
      JournalEntry(
        id: id ?? this.id,
        seriesId: seriesId ?? this.seriesId,
        seriesTitle: seriesTitle ?? this.seriesTitle,
        chapter: chapter ?? this.chapter,
        text: text ?? this.text,
        quote: quote ?? this.quote,
        mood: mood ?? this.mood,
        rating: rating ?? this.rating,
        at: at ?? this.at,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'series_id': seriesId,
        'series_title': seriesTitle,
        'chapter': chapter,
        'text': text,
        'quote': quote,
        'mood': mood.key,
        'rating': rating,
        'at': at.toIso8601String(),
      };

  factory JournalEntry.fromJson(Map<String, dynamic> j) => JournalEntry(
        id: '${j['id'] ?? newJournalId()}',
        seriesId: '${j['series_id'] ?? ''}',
        seriesTitle: '${j['series_title'] ?? 'عمل'}',
        chapter: (j['chapter'] as num?)?.toInt() ?? 0,
        text: '${j['text'] ?? ''}',
        quote: '${j['quote'] ?? ''}',
        mood: JournalMood.fromKey(j['mood']),
        rating: ((j['rating'] as num?)?.toInt() ?? 0).clamp(0, 5),
        at: DateTime.tryParse('${j['at'] ?? ''}') ?? DateTime.now(),
      );

  @override
  bool operator ==(Object other) => other is JournalEntry && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

// ───────────────────────── إحصاءات اليوميات ─────────────────────────

/// ملخص إحصائي لإدخالات اليوميات.
@immutable
class JournalStats {
  const JournalStats({
    required this.total,
    required this.perMood,
    required this.topSeriesTitle,
    required this.averageRating,
    required this.totalChapters,
    required this.ratedCount,
    required this.thisMonthCount,
  });

  /// عدد الإدخالات الكلي.
  final int total;

  /// عدد الإدخالات لكل مزاج.
  final Map<JournalMood, int> perMood;

  /// عنوان أكثر عمل كُتبت عنه ملاحظات (null عند عدم وجود إدخالات).
  final String? topSeriesTitle;

  /// متوسط التقييمات (0.0 عند عدم وجود أي تقييم).
  final double averageRating;

  /// عدد الفصول المميزة التي كُتبت عنها ملاحظات (chapter > 0).
  final int totalChapters;

  /// عدد الإدخالات التي تحمل تقييماً.
  final int ratedCount;

  /// عدد إدخالات الشهر الحالي.
  final int thisMonthCount;

  static const JournalStats empty = JournalStats(
    total: 0,
    perMood: {},
    topSeriesTitle: null,
    averageRating: 0.0,
    totalChapters: 0,
    ratedCount: 0,
    thisMonthCount: 0,
  );

  /// أكثر مزاج تكراراً (null عند عدم وجود إدخالات).
  JournalMood? get dominantMood {
    JournalMood? best;
    var bestCount = 0;
    for (final e in perMood.entries) {
      if (e.value > bestCount) {
        best = e.key;
        bestCount = e.value;
      }
    }
    return best;
  }

  /// متوسط التقييم بصيغة «4.2».
  String get averageRatingLabel => averageRating <= 0 ? '—' : averageRating.toStringAsFixed(1);
}

// ───────────────────────── مخزن اليوميات ─────────────────────────

/// مخزن يوميات القراءة: يحفظ الإدخالات محلياً في SharedPreferences
/// (المفتاح `journal_entries_v1`) ويُعلم الواجهة عند كل تغيير.
class JournalStore extends ChangeNotifier {
  JournalStore._(this._p) {
    _entries = _readAll();
  }

  final SharedPreferences _p;
  late List<JournalEntry> _entries;

  /// يبني مخزناً من تفضيلات جاهزة (للاختبارات والتكامل اليدوي).
  JournalStore.forPrefs(SharedPreferences prefs) : this._(prefs);

  static const String kStoreKey = 'journal_entries_v1';

  /// يفتح المخزن من التخزين المحلي.
  static Future<JournalStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    return JournalStore._(prefs);
  }

  /// نسخة للاختبارات: يبذر التفضيلات بقيم [seed] ثم يفتح المخزن.
  static Future<JournalStore> testInstance({Map<String, Object>? seed}) async {
    // ignore: invalid_use_of_visible_for_testing_member
    SharedPreferences.setMockInitialValues(seed ?? const <String, Object>{});
    final prefs = await SharedPreferences.getInstance();
    return JournalStore._(prefs);
  }

  List<JournalEntry> _readAll() {
    try {
      final raw = _p.getString(kStoreKey);
      if (raw == null || raw.isEmpty) return <JournalEntry>[];
      final list = jsonDecode(raw) as List;
      final out = list
          .whereType<Map>()
          .map((e) => JournalEntry.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      out.sort((a, b) => b.at.compareTo(a.at));
      return out;
    } catch (_) {
      return <JournalEntry>[];
    }
  }

  Future<void> _save() async {
    await _p.setString(
      kStoreKey,
      jsonEncode(_entries.map((e) => e.toJson()).toList()),
    );
  }

  /// كل الإدخالات (الأحدث أولاً). قائمة للقراءة فقط.
  List<JournalEntry> get entries => List<JournalEntry>.unmodifiable(_entries);

  /// عدد الإدخالات.
  int get length => _entries.length;

  bool get isEmpty => _entries.isEmpty;

  /// يضيف إدخالاً جديداً ويعيد الإدخال المنشأ.
  Future<JournalEntry> add({
    required String seriesId,
    required String seriesTitle,
    int chapter = 0,
    String text = '',
    String quote = '',
    JournalMood mood = JournalMood.calm,
    int rating = 0,
    DateTime? at,
  }) async {
    final entry = JournalEntry(
      id: newJournalId(),
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter < 0 ? 0 : chapter,
      text: text.trim(),
      quote: quote.trim(),
      mood: mood,
      rating: rating.clamp(0, 5),
      at: at ?? DateTime.now(),
    );
    _entries.insert(0, entry);
    _entries.sort((a, b) => b.at.compareTo(a.at));
    await _save();
    notifyListeners();
    return entry;
  }

  /// يحدّث إدخالاً موجوداً (مطابقة بالمعرّف). يعيد false إن لم يوجد.
  Future<bool> update(JournalEntry entry) async {
    final i = _entries.indexWhere((e) => e.id == entry.id);
    if (i < 0) return false;
    _entries[i] = entry;
    _entries.sort((a, b) => b.at.compareTo(a.at));
    await _save();
    notifyListeners();
    return true;
  }

  /// يحذف إدخالاً بالمعرّف. يعيد false إن لم يوجد.
  Future<bool> remove(String id) async {
    final before = _entries.length;
    _entries.removeWhere((e) => e.id == id);
    if (_entries.length == before) return false;
    await _save();
    notifyListeners();
    return true;
  }

  /// يحذف كل الإدخالات (بعد تأكيد المستخدم في الواجهة).
  Future<void> clearAll() async {
    _entries.clear();
    await _save();
    notifyListeners();
  }

  /// إدخالات عمل محدد (الأحدث أولاً).
  List<JournalEntry> entriesForSeries(String seriesId) =>
      _entries.where((e) => e.seriesId == seriesId).toList();

  /// إدخالات ضمن نطاق زمني [from]..[to] (شاملان).
  List<JournalEntry> entriesInRange(DateTime from, DateTime to) => _entries
      .where((e) => !e.at.isBefore(from) && !e.at.isAfter(to))
      .toList();

  /// إدخالات سنة كاملة.
  List<JournalEntry> entriesInYear(int year) =>
      _entries.where((e) => e.at.year == year).toList();

  /// إدخالات شهر محدد.
  List<JournalEntry> entriesInMonth(int year, int month) =>
      _entries.where((e) => e.at.year == year && e.at.month == month).toList();

  /// إدخالات يوم محدد.
  List<JournalEntry> entriesOnDay(DateTime day) =>
      _entries.where((e) => isSameDay(e.at, day)).toList();

  /// إحصاءات اليوميات كاملة.
  JournalStats get stats {
    final perMood = <JournalMood, int>{};
    final perSeries = <String, int>{};
    var ratedSum = 0;
    var ratedCount = 0;
    var chapters = 0;
    final now = DateTime.now();
    var thisMonth = 0;
    for (final e in _entries) {
      perMood[e.mood] = (perMood[e.mood] ?? 0) + 1;
      perSeries[e.seriesTitle] = (perSeries[e.seriesTitle] ?? 0) + 1;
      if (e.hasRating) {
        ratedSum += e.rating;
        ratedCount++;
      }
      if (e.hasChapter) chapters++;
      if (isSameMonth(e.at, now)) thisMonth++;
    }
    String? top;
    var topCount = 0;
    for (final e in perSeries.entries) {
      if (e.value > topCount) {
        top = e.key;
        topCount = e.value;
      }
    }
    return JournalStats(
      total: _entries.length,
      perMood: Map<JournalMood, int>.unmodifiable(perMood),
      topSeriesTitle: top,
      averageRating: ratedCount == 0 ? 0.0 : ratedSum / ratedCount,
      totalChapters: chapters,
      ratedCount: ratedCount,
      thisMonthCount: thisMonth,
    );
  }

  /// بحث نصي في الملاحظات والاقتباسات وعناوين الأعمال.
  List<JournalEntry> search(String query) {
    final q = query.trim();
    if (q.isEmpty) return entries;
    return _entries
        .where((e) =>
            e.text.contains(q) ||
            e.quote.contains(q) ||
            e.seriesTitle.contains(q))
        .toList();
  }

  /// «في مثل هذا اليوم»: إدخالات من اليوم والشهر نفسه في سنوات سابقة.
  List<JournalEntry> onThisDay({DateTime? today}) {
    final d = today ?? DateTime.now();
    return _entries
        .where((e) =>
            e.at.month == d.month && e.at.day == d.day && e.at.year != d.year)
        .toList();
  }

  /// آخر نشاط لكل عمل: معرّف العمل ← وقت آخر إدخال عنه.
  Map<String, DateTime> lastActivityBySeries() {
    final out = <String, DateTime>{};
    for (final e in _entries) {
      final cur = out[e.seriesId];
      if (cur == null || e.at.isAfter(cur)) out[e.seriesId] = e.at;
    }
    return out;
  }

  /// أحدث إدخال (null عند عدم وجود إدخالات).
  JournalEntry? get latest => _entries.isEmpty ? null : _entries.first;

  /// عدد أيام القراءة المميزة التي لها إدخالات.
  int get distinctDays {
    final days = <String>{};
    for (final e in _entries) {
      days.add(dayKeyOf(e.at));
    }
    return days.length;
  }

  /// تصدير نصي جميل للمشاركة أو الحفظ.
  String exportText() {
    final b = StringBuffer();
    b.writeln('يومياتي في القراءة على Senok');
    b.writeln('عدد الإدخالات: ${_entries.length}');
    b.writeln('—' * 24);
    for (final e in _entries) {
      b.writeln('• ${e.seriesTitle} — ${e.chapterLabel}');
      b.writeln('  ${formatArabicDate(e.at)} · ${e.mood.label}'
          '${e.hasRating ? ' · ${e.starsLabel}' : ''}');
      if (e.text.isNotEmpty) b.writeln('  ${e.text}');
      if (e.hasQuote) b.writeln('  «${e.quote}»');
      b.writeln();
    }
    return b.toString();
  }

  /// تصدير JSON (قائمة الإدخالات كاملة).
  String exportJson() =>
      jsonEncode(_entries.map((e) => e.toJson()).toList());

  /// استيراد JSON: يدمج الإدخالات الجديدة (يتخطى المعرّفات المكررة)
  /// ويعيد عدد الإدخالات المستورَدة فعلاً.
  Future<int> importJson(String raw) async {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return 0;
      final existing = _entries.map((e) => e.id).toSet();
      var added = 0;
      for (final item in decoded) {
        if (item is! Map) continue;
        final entry =
            JournalEntry.fromJson(Map<String, dynamic>.from(item));
        if (existing.contains(entry.id)) continue;
        existing.add(entry.id);
        _entries.add(entry);
        added++;
      }
      if (added > 0) {
        _entries.sort((a, b) => b.at.compareTo(a.at));
        await _save();
        notifyListeners();
      }
      return added;
    } catch (_) {
      return 0;
    }
  }
}

/// يوفّر مخزن يوميات جاهزاً (محمّلاً عبر [JournalStore.load]) لشجرة الواجهة.
class JournalScope extends StatelessWidget {
  const JournalScope({super.key, required this.store, required this.child});

  final JournalStore store;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<JournalStore>.value(
      value: store,
      child: child,
    );
  }
}

// ───────────────────────── واجهة اليوميات ─────────────────────────

/// شاشة يوميات القراءة: إحصاءات موجزة + بحث + تصفية بالمزاج + قائمة الإدخالات.
class JournalScreen extends StatefulWidget {
  const JournalScreen({super.key, this.seriesId, this.seriesTitle});

  /// إن مُرّر معرّف عمل، تعرض الشاشة إدخالات ذلك العمل فقط.
  final String? seriesId;
  final String? seriesTitle;

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  String _query = '';
  JournalMood? _moodFilter;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<JournalStore>();
    final onlySeries = widget.seriesId != null;
    var list = onlySeries
        ? store.entriesForSeries(widget.seriesId!)
        : store.entries;
    if (_query.trim().isNotEmpty) {
      final q = _query.trim();
      list = list
          .where((e) =>
              e.text.contains(q) ||
              e.quote.contains(q) ||
              e.seriesTitle.contains(q))
          .toList();
    }
    if (_moodFilter != null) {
      list = list.where((e) => e.mood == _moodFilter).toList();
    }
    final stats = store.stats;

    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text(
          onlySeries
              ? 'يوميات «${widget.seriesTitle ?? ''}»'
              : 'يوميات القراءة',
          style: context.ds(size: 20, color: p.text),
        ),
        actions: [
          IconButton(
            onPressed: () => _showExportSheet(context, store),
            icon: SIcon(SardIcons.share_rounded, size: 20, color: p.text),
            tooltip: 'تصدير اليوميات',
          ),
          IconButton(
            onPressed: () => _confirmClear(context, store),
            icon: SIcon(SardIcons.delete_outline_rounded,
                size: 20, color: p.textDim),
            tooltip: 'مسح الكل',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: p.accent,
        foregroundColor: p.onAccent,
        onPressed: () => _openEditor(
          context,
          store,
          seriesId: widget.seriesId,
          seriesTitle: widget.seriesTitle,
        ),
        icon: SIcon(SardIcons.edit_rounded, size: 18, color: p.onAccent),
        label: Text('ملاحظة جديدة', style: context.ts(size: 14, w: FontWeight.w700, color: p.onAccent)),
      ),
      body: Column(
        children: [
          if (!onlySeries) _JournalStatsHeader(stats: stats),
          _JournalSearchBar(
            onChanged: (v) => setState(() => _query = v),
          ),
          _MoodFilterRow(
            selected: _moodFilter,
            onSelected: (m) => setState(() => _moodFilter = m),
          ),
          Expanded(
            child: list.isEmpty
                ? _JournalEmptyState(
                    hasFilter: _query.isNotEmpty || _moodFilter != null,
                    onAdd: () => _openEditor(
                      context,
                      store,
                      seriesId: widget.seriesId,
                      seriesTitle: widget.seriesTitle,
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => JournalEntryCard(
                      entry: list[i],
                      store: store,
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _openEditor(
    BuildContext context,
    JournalStore store, {
    String? seriesId,
    String? seriesTitle,
    JournalEntry? existing,
  }) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => JournalEditorSheet(
        store: store,
        seriesId: seriesId,
        seriesTitle: seriesTitle,
        existing: existing,
      ),
    );
  }

  void _showExportSheet(BuildContext context, JournalStore store) {
    final p = context.pal;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: p.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(p.radius)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('تصدير اليوميات', style: ctx.ds(size: 18, color: p.text)),
              const SizedBox(height: 6),
              Text(
                'انسخ نص يومياتك كاملاً لمشاركته أو حفظه في ملف.',
                style: ctx.ts(size: 13, color: p.textDim),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 180,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: p.bg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: p.border),
                  ),
                  child: SingleChildScrollView(
                    child: SelectableText(
                      store.exportText(),
                      style: ctx.ts(size: 12.5, color: p.text, height: 1.7),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'عدد الإدخالات: ${store.length} · التصدير النصي يبدأ دائماً بترويسة «يومياتي في القراءة على Senok».',
                style: ctx.ts(size: 12, color: p.textDim),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmClear(BuildContext context, JournalStore store) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        final p = ctx.pal;
        return AlertDialog(
          backgroundColor: p.surface,
          title: Text('مسح كل اليوميات؟',
              style: ctx.ds(size: 18, color: p.text)),
          content: Text(
            'سيُحذف كل ما كتبتَه في اليوميات نهائياً، ولا يمكن التراجع.',
            style: ctx.ts(size: 14, color: p.textDim),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: Text('إلغاء', style: ctx.ts(size: 14, color: p.text)),
            ),
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: Text('مسح الكل',
                  style: ctx.ts(size: 14, w: FontWeight.w700, color: const Color(0xFFE5484D))),
            ),
          ],
        );
      },
    );
    if (ok == true) await store.clearAll();
  }
}

/// شريط إحصاءات موجز أعلى شاشة اليوميات.
class _JournalStatsHeader extends StatelessWidget {
  const _JournalStatsHeader({required this.stats});

  final JournalStats stats;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          _StatCell(
            label: 'ملاحظة',
            value: '${stats.total}',
            icon: SardIcons.menu_book_rounded,
          ),
          _StatCell(
            label: 'هذا الشهر',
            value: '${stats.thisMonthCount}',
            icon: SardIcons.calendar_today_rounded,
          ),
          _StatCell(
            label: 'متوسط التقييم',
            value: stats.averageRatingLabel,
            icon: SardIcons.star_rounded,
          ),
          _StatCell(
            label: 'المزاج الغالب',
            value: stats.dominantMood?.label ?? '—',
            icon: stats.dominantMood?.icon ?? SardIcons.spa_rounded,
          ),
        ],
      ),
    );
  }
}

class _StatCell extends StatelessWidget {
  const _StatCell({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final SIconData icon;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Column(
        children: [
          SIcon(icon, size: 18, color: p.accent),
          const SizedBox(height: 4),
          Text(value,
              style: context.ds(size: 15, color: p.text),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          Text(label,
              style: context.ts(size: 11, color: p.textDim),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

/// شريط بحث نصي في اليوميات.
class _JournalSearchBar extends StatelessWidget {
  const _JournalSearchBar({required this.onChanged});

  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: TextField(
        onChanged: onChanged,
        style: context.ts(size: 14, color: p.text),
        decoration: InputDecoration(
          hintText: 'ابحث في ملاحظاتك واقتباساتك…',
          hintStyle: context.ts(size: 13, color: p.textDim),
          prefixIcon: SIcon(SardIcons.search_rounded, size: 20, color: p.textDim),
          filled: true,
          fillColor: p.surface,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: p.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: p.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: p.accent, width: 1.4),
          ),
        ),
      ),
    );
  }
}

/// صف تصفية حسب المزاج (رقائق قابلة للتبديل).
class _MoodFilterRow extends StatelessWidget {
  const _MoodFilterRow({required this.selected, required this.onSelected});

  final JournalMood? selected;
  final ValueChanged<JournalMood?> onSelected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        children: [
          _MoodChip(
            label: 'الكل',
            selected: selected == null,
            onTap: () => onSelected(null),
          ),
          for (final m in JournalMood.values)
            _MoodChip(
              label: m.label,
              color: m.color,
              selected: selected == m,
              onTap: () => onSelected(selected == m ? null : m),
            ),
        ],
      ),
    );
  }
}

class _MoodChip extends StatelessWidget {
  const _MoodChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.color,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: Text(label,
            style: context.ts(
                size: 12.5,
                w: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? p.onAccent : p.text)),
        selected: selected,
        onSelected: (_) => onTap(),
        selectedColor: color ?? p.accent,
        backgroundColor: p.surface,
        side: BorderSide(color: selected ? Colors.transparent : p.border),
        showCheckmark: false,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      ),
    );
  }
}

/// حالة فراغ شاشة اليوميات.
class _JournalEmptyState extends StatelessWidget {
  const _JournalEmptyState({required this.hasFilter, required this.onAdd});

  final bool hasFilter;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: p.surface,
                shape: BoxShape.circle,
                border: Border.all(color: p.border),
              ),
              child: SIcon(SardIcons.menu_book_rounded,
                  size: 38, color: p.accent),
            ),
            const SizedBox(height: 16),
            Text(
              hasFilter ? 'لا نتائج مطابقة' : 'يومياتك فارغة بعد',
              style: context.ds(size: 18, color: p.text),
            ),
            const SizedBox(height: 6),
            Text(
              hasFilter
                  ? 'جرّب كلمة أخرى أو ألغِ تصفية المزاج.'
                  : 'اكتب أول ملاحظة بعد فصل قرأته: ما الذي أعجبك؟ وما الذي أزعجك؟',
              style: context.ts(size: 13.5, color: p.textDim, height: 1.7),
              textAlign: TextAlign.center,
            ),
            if (!hasFilter) ...[
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: onAdd,
                style: FilledButton.styleFrom(
                  backgroundColor: p.accent,
                  foregroundColor: p.onAccent,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
                icon: SIcon(SardIcons.edit_rounded,
                    size: 17, color: p.onAccent),
                label: Text('اكتب أول ملاحظة',
                    style: context.ts(
                        size: 14, w: FontWeight.w700, color: p.onAccent)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// بطاقة إدخال واحد في اليوميات.
class JournalEntryCard extends StatelessWidget {
  const JournalEntryCard({super.key, required this.entry, required this.store});

  final JournalEntry entry;
  final JournalStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: entry.mood.color.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: SIcon(entry.mood.icon, size: 17, color: entry.mood.color),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      entry.seriesTitle,
                      style: context.ts(size: 14, w: FontWeight.w700, color: p.text),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '${entry.chapterLabel} · ${formatArabicDate(entry.at)}',
                      style: context.ts(size: 12, color: p.textDim),
                    ),
                  ],
                ),
              ),
              if (entry.hasRating)
                Text(entry.starsLabel,
                    style: TextStyle(fontSize: 12, color: p.gold)),
              PopupMenuButton<String>(
                color: p.surface,
                icon: SIcon(SardIcons.menu_rounded, size: 18, color: p.textDim),
                onSelected: (v) async {
                  if (v == 'edit') {
                    await showModalBottomSheet<void>(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (_) => JournalEditorSheet(
                        store: store,
                        existing: entry,
                      ),
                    );
                  } else if (v == 'delete') {
                    await store.remove(entry.id);
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(
                    value: 'edit',
                    child: Text('تعديل',
                        style: context.ts(size: 14, color: p.text)),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: Text('حذف',
                        style: context.ts(
                            size: 14, color: const Color(0xFFE5484D))),
                  ),
                ],
              ),
            ],
          ),
          if (entry.text.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(entry.text,
                style: context.ts(size: 13.5, color: p.text, height: 1.7)),
          ],
          if (entry.hasQuote) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: p.bg,
                borderRadius: BorderRadius.circular(10),
                border: Border(
                  right: BorderSide(color: p.gold, width: 3),
                ),
              ),
              child: Text(
                '«${entry.quote}»',
                style: context.ts(
                    size: 13, w: FontWeight.w500, color: p.text, height: 1.7),
              ),
            ),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              _MiniTag(label: entry.mood.label, color: entry.mood.color),
              const SizedBox(width: 6),
              if (entry.hasRating)
                _MiniTag(label: 'تقييمي ${entry.rating}/5', color: p.gold),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniTag extends StatelessWidget {
  const _MiniTag({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: context.ts(size: 11, w: FontWeight.w700, color: color)),
    );
  }
}

// ───────────────────────── محرر اليومية ─────────────────────────

/// ورقة إضافة/تعديل ملاحظة يومية: العمل والفصل والمزاج والتقييم والاقتباس.
class JournalEditorSheet extends StatefulWidget {
  const JournalEditorSheet({
    super.key,
    required this.store,
    this.seriesId,
    this.seriesTitle,
    this.existing,
    this.chapter = 0,
  });

  final JournalStore store;
  final String? seriesId;
  final String? seriesTitle;
  final JournalEntry? existing;

  /// رقم الفصل المقترح (يُمرَّر من القارئ عند إنهاء فصل).
  final int chapter;

  @override
  State<JournalEditorSheet> createState() => _JournalEditorSheetState();
}

class _JournalEditorSheetState extends State<JournalEditorSheet> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _textCtrl;
  late final TextEditingController _quoteCtrl;
  late final TextEditingController _chapterCtrl;
  JournalMood _mood = JournalMood.calm;
  int _rating = 0;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _titleCtrl = TextEditingController(
        text: e?.seriesTitle ?? widget.seriesTitle ?? '');
    _textCtrl = TextEditingController(text: e?.text ?? '');
    _quoteCtrl = TextEditingController(text: e?.quote ?? '');
    _chapterCtrl = TextEditingController(
        text: e != null
            ? (e.chapter > 0 ? '${e.chapter}' : '')
            : (widget.chapter > 0 ? '${widget.chapter}' : ''));
    if (e != null) {
      _mood = e.mood;
      _rating = e.rating;
    }
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _textCtrl.dispose();
    _quoteCtrl.dispose();
    _chapterCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final isEdit = widget.existing != null;
    return Container(
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(p.radius)),
      ),
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: p.border,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              isEdit ? 'تعديل الملاحظة' : 'ملاحظة جديدة',
              style: context.ds(size: 19, color: p.text),
            ),
            const SizedBox(height: 4),
            Text(
              'سجّل انطباعك بعد القراءة؛ تبقى ملاحظاتك على جهازك فقط.',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
            const SizedBox(height: 16),
            _SheetField(
              controller: _titleCtrl,
              label: 'اسم العمل',
              hint: 'مثال: سولو ليفلينغ',
              enabled: !isEdit,
            ),
            const SizedBox(height: 10),
            _SheetField(
              controller: _chapterCtrl,
              label: 'رقم الفصل (اختياري)',
              hint: 'مثال: 12',
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 14),
            Text('كيف كان شعورك؟', style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final m in JournalMood.values)
                  ChoiceChip(
                    label: Text(m.label,
                        style: context.ts(
                            size: 13,
                            w: _mood == m ? FontWeight.w700 : FontWeight.w500,
                            color: _mood == m ? p.onAccent : p.text)),
                    avatar: SIcon(m.icon,
                        size: 16,
                        color: _mood == m ? p.onAccent : m.color),
                    selected: _mood == m,
                    onSelected: (_) => setState(() => _mood = m),
                    selectedColor: m.color,
                    backgroundColor: p.bg,
                    side: BorderSide(
                        color: _mood == m ? Colors.transparent : p.border),
                    showCheckmark: false,
                  ),
              ],
            ),
            const SizedBox(height: 14),
            Text('تقييمك للفصل', style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
            const SizedBox(height: 6),
            StarRatingInput(
              value: _rating,
              onChanged: (v) => setState(() => _rating = v),
            ),
            const SizedBox(height: 14),
            _SheetField(
              controller: _textCtrl,
              label: 'ملاحظتك',
              hint: 'ما الذي أعجبك؟ ما الذي أزعجك؟ ماذا تتوقع بعد؟',
              maxLines: 4,
            ),
            const SizedBox(height: 10),
            _SheetField(
              controller: _quoteCtrl,
              label: 'اقتباس أعجبك (اختياري)',
              hint: 'اكتب السطر الذي علق بذهنك…',
              maxLines: 2,
            ),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: _saving ? null : _save,
              style: FilledButton.styleFrom(
                backgroundColor: p.accent,
                foregroundColor: p.onAccent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: _saving
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: p.onAccent,
                      ),
                    )
                  : Text(
                      isEdit ? 'حفظ التعديلات' : 'حفظ الملاحظة',
                      style: context.ts(
                          size: 15, w: FontWeight.w700, color: p.onAccent),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    final title = _titleCtrl.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب اسم العمل أولاً.')),
      );
      return;
    }
    final chapter = int.tryParse(_chapterCtrl.text.trim()) ?? 0;
    setState(() => _saving = true);
    final existing = widget.existing;
    if (existing != null) {
      await widget.store.update(existing.copyWith(
        seriesTitle: title,
        chapter: chapter,
        text: _textCtrl.text,
        quote: _quoteCtrl.text,
        mood: _mood,
        rating: _rating,
      ));
    } else {
      await widget.store.add(
        seriesId: widget.seriesId ?? 'manual_${title.hashCode}',
        seriesTitle: title,
        chapter: chapter,
        text: _textCtrl.text,
        quote: _quoteCtrl.text,
        mood: _mood,
        rating: _rating,
      );
    }
    if (!mounted) return;
    Navigator.of(context).pop();
  }
}

class _SheetField extends StatelessWidget {
  const _SheetField({
    required this.controller,
    required this.label,
    required this.hint,
    this.maxLines = 1,
    this.enabled = true,
    this.keyboardType,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final int maxLines;
  final bool enabled;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: context.ts(size: 13, w: FontWeight.w700, color: p.text)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          enabled: enabled,
          maxLines: maxLines,
          keyboardType: keyboardType,
          style: context.ts(size: 14, color: p.text),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: context.ts(size: 13, color: p.textDim),
            filled: true,
            fillColor: p.bg,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.border),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.accent, width: 1.4),
            ),
            disabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: p.border),
            ),
          ),
        ),
      ],
    );
  }
}

/// صف نجوم لاختيار تقييم من 0 إلى 5 (الضغط على النجمة المختارة يلغي التقييم).
class StarRatingInput extends StatelessWidget {
  const StarRatingInput({super.key, required this.value, required this.onChanged});

  final int value;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= 5; i++)
          IconButton(
            onPressed: () => onChanged(value == i ? 0 : i),
            icon: SIcon(
              i <= value ? SardIcons.star_rounded : SardIcons.star_border_rounded,
              size: 30,
              color: i <= value ? p.gold : p.textDim,
            ),
            tooltip: 'تقييم $i من 5',
          ),
        const SizedBox(width: 6),
        Text(
          value == 0 ? 'بلا تقييم' : '$value من 5',
          style: context.ts(size: 12.5, color: p.textDim),
        ),
      ],
    );
  }
}

/// بطاقة «في مثل هذا اليوم» — تستعمل في الشاشة الرئيسية لاحقاً.
class OnThisDayCard extends StatelessWidget {
  const OnThisDayCard({super.key, required this.entries});

  final List<JournalEntry> entries;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (entries.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.gold.withValues(alpha: 0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.history_rounded, size: 18, color: p.gold),
              const SizedBox(width: 8),
              Text('في مثل هذا اليوم',
                  style: context.ds(size: 15, color: p.text)),
            ],
          ),
          const SizedBox(height: 8),
          for (final e in entries.take(3))
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                '• ${e.seriesTitle} — ${e.chapterLabel} (${e.at.year})',
                style: context.ts(size: 13, color: p.text),
              ),
            ),
        ],
      ),
    );
  }
}
