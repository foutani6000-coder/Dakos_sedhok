/// ──────────────────────────────────────────────────────────────────────────
/// ممر الذكريات — Memory Lane
/// يعيد إليك القارئ لحظات من رحلته: ما الذي قرأه في مثل هذا اليوم
/// قبل سنة؟ ما الذي قرأه قبل شهر؟ وما الأعمال التي نسيها منذ أكثر
/// من 60 يوماً وتستحق أن يعود إليها؟ كل القواعد حتمية وقابلة للاختبار.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'package:flutter/material.dart';

import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'reading_journal.dart';

/// نوع الذكرى.
enum MemoryKind {
  /// إدخال يومية من اليوم والشهر نفسه في سنة سابقة.
  sameDay('في مثل هذا اليوم', 'قرأتَ هذا في مثل هذا اليوم قبل سنة أو أكثر'),

  /// إدخال من قبل نحو شهر (25–35 يوماً).
  monthAgo('قبل شهر', 'مرّ شهر على هذه القراءة'),

  /// عمل لم تلمسه منذ 60 يوماً أو أكثر ويستحق العودة.
  rediscover('أعد اكتشافه', 'لم تقرأ هذا العمل منذ مدة طويلة'),

  /// يوم قراءة كامل من مثل هذا اليوم في سنة سابقة (بلا إدخال يومية).
  readDay('يوم قراءة', 'قرأتَ في مثل هذا اليوم قبل سنة');

  const MemoryKind(this.label, this.hint);
  final String label;
  final String hint;

  SIconData get icon {
    switch (this) {
      case MemoryKind.sameDay:
        return SardIcons.history_rounded;
      case MemoryKind.monthAgo:
        return SardIcons.calendar_today_rounded;
      case MemoryKind.rediscover:
        return SardIcons.auto_awesome_rounded;
      case MemoryKind.readDay:
        return SardIcons.local_fire_department_rounded;
    }
  }

  Color get color {
    switch (this) {
      case MemoryKind.sameDay:
        return const Color(0xFFE9B44C);
      case MemoryKind.monthAgo:
        return const Color(0xFF3B9EFF);
      case MemoryKind.rediscover:
        return const Color(0xFF7E6BFF);
      case MemoryKind.readDay:
        return const Color(0xFFFF6B35);
    }
  }
}

/// ذكرى واحدة يعرضها ممر الذكريات.
@immutable
class MemoryItem {
  const MemoryItem({
    required this.kind,
    required this.seriesId,
    required this.seriesTitle,
    required this.date,
    required this.title,
    required this.subtitle,
    this.chapter = 0,
    this.entryId,
    this.daysAgo = 0,
  });

  /// نوع الذكرى.
  final MemoryKind kind;

  /// معرّف العمل المرتبط (قد يكون فارغاً لذكرى «يوم قراءة» عامة).
  final String seriesId;

  /// عنوان العمل.
  final String seriesTitle;

  /// تاريخ الحدث الأصلي.
  final DateTime date;

  /// عنوان الذكرى للعرض.
  final String title;

  /// سطر توضيحي.
  final String subtitle;

  /// رقم الفصل (إن وُجد).
  final int chapter;

  /// معرّف إدخال اليومية المرتبط (إن وُجد).
  final String? entryId;

  /// عدد الأيام منذ الحدث.
  final int daysAgo;

  bool get hasChapter => chapter > 0;

  /// «قبل 412 يوماً» أو «قبل شهر».
  String get agoLabel {
    if (daysAgo <= 0) return 'اليوم';
    if (daysAgo == 1) return 'قبل يوم';
    if (daysAgo == 2) return 'قبل يومين';
    if (daysAgo < 11) return 'قبل $daysAgo أيام';
    if (daysAgo < 30) return 'قبل $daysAgo يوماً';
    final months = daysAgo ~/ 30;
    if (months == 1) return 'قبل شهر';
    if (months == 2) return 'قبل شهرين';
    if (months < 11) return 'قبل $months أشهر';
    final years = daysAgo ~/ 365;
    if (years == 1) return 'قبل سنة';
    if (years == 2) return 'قبل سنتين';
    return 'قبل $years سنوات';
  }
}

/// محرك بناء الذكريات: قواعد حتمية خالصة، بلا أي عشوائية.
class MemoryLaneEngine {
  const MemoryLaneEngine._();

  /// يبني قائمة الذكريات من إدخالات اليوميات وسجل أيام القراءة.
  /// [today] يُمرَّر في الاختبارات لتثبيت «اليوم»؛ في الواجهة يُترك null.
  static List<MemoryItem> build({
    required List<JournalEntry> entries,
    required SettingsController settings,
    DateTime? today,
  }) {
    final now = today ?? DateTime.now();
    final day = startOfDay(now);
    final out = <MemoryItem>[];

    // 1) في مثل هذا اليوم: إدخالات من الشهر واليوم نفسه في سنوات سابقة.
    final sameDay = entries
        .where((e) =>
            e.at.month == now.month &&
            e.at.day == now.day &&
            e.at.year < now.year)
        .toList()
      ..sort((a, b) => b.at.compareTo(a.at));
    for (final e in sameDay) {
      out.add(MemoryItem(
        kind: MemoryKind.sameDay,
        seriesId: e.seriesId,
        seriesTitle: e.seriesTitle,
        date: e.at,
        title: 'في مثل هذا اليوم (${e.at.year})',
        subtitle: e.text.isNotEmpty
            ? e.text
            : 'قرأت ${e.chapterLabel} من «${e.seriesTitle}».',
        chapter: e.chapter,
        entryId: e.id,
        daysAgo: day.difference(startOfDay(e.at)).inDays,
      ));
    }

    // 2) قبل شهر: إدخالات عمرها بين 25 و35 يوماً.
    final monthAgo = entries.where((e) {
      final age = day.difference(startOfDay(e.at)).inDays;
      return age >= 25 && age <= 35;
    }).toList()
      ..sort((a, b) => b.at.compareTo(a.at));
    for (final e in monthAgo) {
      out.add(MemoryItem(
        kind: MemoryKind.monthAgo,
        seriesId: e.seriesId,
        seriesTitle: e.seriesTitle,
        date: e.at,
        title: 'قبل شهر تقريباً',
        subtitle: 'قرأت ${e.chapterLabel} من «${e.seriesTitle}».',
        chapter: e.chapter,
        entryId: e.id,
        daysAgo: day.difference(startOfDay(e.at)).inDays,
      ));
    }

    // 3) أعد اكتشافه: أقدم إدخال لكل عمل لم يُلمس منذ 60 يوماً أو أكثر.
    final lastBySeries = <String, JournalEntry>{};
    for (final e in entries) {
      final cur = lastBySeries[e.seriesId];
      if (cur == null || e.at.isAfter(cur.at)) lastBySeries[e.seriesId] = e;
    }
    final stale = <JournalEntry>[];
    for (final e in lastBySeries.values) {
      final age = day.difference(startOfDay(e.at)).inDays;
      if (age >= 60) stale.add(e);
    }
    stale.sort((a, b) => a.at.compareTo(b.at));
    for (final e in stale.take(3)) {
      out.add(MemoryItem(
        kind: MemoryKind.rediscover,
        seriesId: e.seriesId,
        seriesTitle: e.seriesTitle,
        date: e.at,
        title: 'أعد اكتشاف «${e.seriesTitle}»',
        subtitle: 'آخر ملاحظة لك عنه كانت ${formatArabicDate(e.at)}.',
        chapter: e.chapter,
        entryId: e.id,
        daysAgo: day.difference(startOfDay(e.at)).inDays,
      ));
    }

    // 4) يوم قراءة: قرأتَ في مثل هذا اليوم قبل سنة أو سنتين (من سجل الأيام).
    for (var yearsBack = 1; yearsBack <= 2; yearsBack++) {
      final probe = DateTime(now.year - yearsBack, now.month, now.day);
      if (probe.year < 2000) continue;
      if (!settings.readOnDay(probe)) continue;
      // لا نكرر ذكرى «في مثل هذا اليوم» إن وُجد إدخال يومية في التاريخ نفسه.
      final covered = sameDay.any((e) => isSameDay(e.at, probe));
      if (covered) continue;
      out.add(MemoryItem(
        kind: MemoryKind.readDay,
        seriesId: '',
        seriesTitle: 'يوم قراءة',
        date: probe,
        title: 'قرأتَ في مثل هذا اليوم قبل $yearsBack'
            '${yearsBack == 1 ? ' سنة' : ' سنتين'}',
        subtitle: 'يوم ${formatArabicDate(probe)} كان يوم قراءة لك.',
        daysAgo: day.difference(startOfDay(probe)).inDays,
      ));
    }

    // الترتيب: في مثل هذا اليوم أولاً، ثم قبل شهر، ثم يوم قراءة، ثم إعادة اكتشاف.
    const order = <MemoryKind>[
      MemoryKind.sameDay,
      MemoryKind.monthAgo,
      MemoryKind.readDay,
      MemoryKind.rediscover,
    ];
    out.sort((a, b) {
      final c = order.indexOf(a.kind).compareTo(order.indexOf(b.kind));
      if (c != 0) return c;
      return b.date.compareTo(a.date);
    });
    return out.take(8).toList();
  }
}

// ───────────────────────── واجهة ممر الذكريات ─────────────────────────

/// شاشة ممر الذكريات: قائمة ذكريات مبنية من يومياتك وسجل قراءتك.
class MemoryLaneScreen extends StatelessWidget {
  const MemoryLaneScreen({
    super.key,
    required this.entries,
    required this.settings,
  });

  final List<JournalEntry> entries;
  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final memories = MemoryLaneEngine.build(
      entries: entries,
      settings: settings,
    );
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text('ممر الذكريات', style: context.ds(size: 20, color: p.text)),
      ),
      body: memories.isEmpty
          ? _MemoryEmptyState()
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              itemCount: memories.length + 1,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                if (i == 0) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(
                      'لحظات من رحلتك في القراءة تعود إليك اليوم.',
                      style: context.ts(size: 13.5, color: p.textDim, height: 1.7),
                    ),
                  );
                }
                return MemoryCard(item: memories[i - 1]);
              },
            ),
    );
  }
}

class _MemoryEmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: p.surface,
                shape: BoxShape.circle,
                border: Border.all(color: p.border),
              ),
              child: SIcon(SardIcons.history_rounded,
                  size: 38, color: p.accent),
            ),
            const SizedBox(height: 16),
            Text('لا ذكريات بعد',
                style: context.ds(size: 18, color: p.text)),
            const SizedBox(height: 6),
            Text(
              'حين تكتب ملاحظات في يومياتك وتقرأ بانتظام، '
              'سيجمع لك هذا الممر ذكرياتك: ما قرأتَه في مثل هذا اليوم، '
              'وما نسيتَه منذ مدة.',
              style: context.ts(size: 13.5, color: p.textDim, height: 1.8),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

/// بطاقة ذكرى واحدة.
class MemoryCard extends StatelessWidget {
  const MemoryCard({super.key, required this.item});

  final MemoryItem item;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final kind = item.kind;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: kind.color.withValues(alpha: 0.13),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SIcon(kind.icon, size: 20, color: kind.color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: kind.color.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(kind.label,
                          style: context.ts(
                              size: 11,
                              w: FontWeight.w700,
                              color: kind.color)),
                    ),
                    const SizedBox(width: 6),
                    Text(item.agoLabel,
                        style: context.ts(size: 11.5, color: p.textDim)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(item.title,
                    style: context.ts(
                        size: 14.5, w: FontWeight.w700, color: p.text),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text(item.subtitle,
                    style: context.ts(size: 12.5, color: p.textDim, height: 1.6),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis),
                if (item.seriesTitle.isNotEmpty &&
                    item.kind != MemoryKind.readDay) ...[
                  const SizedBox(height: 6),
                  Text(
                    '«${item.seriesTitle}»'
                    '${item.hasChapter ? ' — الفصل ${item.chapter}' : ''}',
                    style: context.ts(size: 12.5, w: FontWeight.w500, color: p.accent),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// بطاقة أفقية صغيرة لذكرى واحدة (تُستعمل في الشاشة الرئيسية لاحقاً).
class MemoryMiniCard extends StatelessWidget {
  const MemoryMiniCard({super.key, required this.item});

  final MemoryItem item;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      width: 240,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(item.kind.icon, size: 15, color: item.kind.color),
              const SizedBox(width: 6),
              Text(item.kind.label,
                  style: context.ts(
                      size: 11.5, w: FontWeight.w700, color: item.kind.color)),
              const Spacer(),
              Text(item.agoLabel,
                  style: context.ts(size: 11, color: p.textDim)),
            ],
          ),
          const SizedBox(height: 8),
          Text(item.title,
              style: context.ts(size: 13.5, w: FontWeight.w700, color: p.text),
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
          if (item.seriesTitle.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text('«${item.seriesTitle}»',
                style: context.ts(size: 12, color: p.textDim),
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
          ],
        ],
      ),
    );
  }
}

/// شريط ذكريات أفقي للشاشة الرئيسية (يأخذ الذكريات جاهزة).
class MemoryLaneStrip extends StatelessWidget {
  const MemoryLaneStrip({super.key, required this.memories});

  final List<MemoryItem> memories;

  @override
  Widget build(BuildContext context) {
    if (memories.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text('ممر الذكريات',
              style: context.ds(size: 17, color: context.pal.text)),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 118,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: memories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) => MemoryMiniCard(item: memories[i]),
          ),
        ),
      ],
    );
  }
}
