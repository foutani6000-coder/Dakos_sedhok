import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/data/social_repository.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/sard_icons.dart';
import '../../widgets/verified_badge.dart';

/// القراءة المشتركة: غرفة بين صديقين يقرآن الفصل نفسه،
/// يظهر فيها موضع كل منهما مع دردشة صغيرة (تعتمد نظام المحادثات الموجود).
///
/// الأجزاء:
///  • [ReadRoomController]  حالة الغرفة: الموضع، الرسائل، المزامنة الدورية.
///  • [ReadRoomChip]        كبسولة عائمة داخل القارئ تعرض موضع الصديق.
///  • [showReadRoomSheet]   ورقة الغرفة: المواضع + الدردشة.
///  • [showReadRoomInvite]  ورقة اختيار الصديق وإنشاء الغرفة.

const _pink = Color(0xFFE0457B);
const _avatarColors = [
  Color(0xFF3B9EFF),
  Color(0xFF2FCB7A),
  Color(0xFFA463F2),
  Color(0xFFF5A524),
  Color(0xFFE0457B),
  Color(0xFF22C7D6),
];

Color _colorFor(String name) => _avatarColors[name.codeUnits.fold<int>(0, (a, b) => a + b) % _avatarColors.length];

/// «صفحة» / «صفحتين» / «3 صفحات» / «12 صفحة»
String readRoomPages(int n) => n == 1
    ? 'صفحة'
    : n == 2
        ? 'صفحتين'
        : n <= 10
            ? '$n صفحات'
            : '$n صفحة';

// ───────────────────────── الحالة ─────────────────────────

class ReadRoomController extends ChangeNotifier {
  ReadRoomController(this._repo, SardReadRoom room) : _room = room;

  final SardRepository _repo;
  SardReadRoom _room;
  SardReadRoom get room => _room;

  List<SardChatMessage> messages = const [];

  /// رسائل الصديق التي لم تُقرأ (والورقة مغلقة)
  int unread = 0;
  bool sending = false;

  int myChapter = 0, myPage = 0, myTotal = 0;

  /// تُضبط من الورقة عند فتحها/إغلاقها (دون إشعار لتفادي التحديث أثناء الإغلاق)
  bool chatOpen = false;

  Timer? _poll;
  Timer? _flush;
  bool _busy = false, _dirty = false, _disposed = false;

  static const _pollEvery = Duration(seconds: 4);
  static const _flushAfter = Duration(seconds: 2);

  void start() {
    _tick();
    _poll = Timer.periodic(_pollEvery, (_) => _tick());
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  // موضع المستخدم ← يُرسل مجمّعاً كل بضع ثوانٍ
  void report(int chapter, int page, int total) {
    if (chapter == myChapter && page == myPage && total == myTotal) return;
    myChapter = chapter;
    myPage = page;
    myTotal = total;
    _dirty = true;
    _flush ??= Timer(_flushAfter, _flushPosition);
    // تأجيل الإشعار: قد يُستدعى report أثناء بناء الواجهة
    scheduleMicrotask(_notify);
  }

  Future<void> _flushPosition() async {
    _flush = null;
    if (!_dirty || _disposed || myChapter == 0) return;
    _dirty = false;
    try {
      await _repo.updateReadPosition(_room.id, chapter: myChapter, page: myPage, total: myTotal);
    } catch (_) {
      _dirty = true; // نعيد المحاولة في الدورة التالية
    }
  }

  Future<void> _tick() async {
    if (_busy || _disposed) return;
    _busy = true;
    try {
      if (_dirty && _flush == null) unawaited(_flushPosition());
      final r = await _repo.readRoom(_room);
      final m = await _repo.chatMessages(_room.chatId);
      if (_disposed) return;
      _room = r;
      if (m.length >= messages.length) {
        if (!chatOpen) {
          unread += m.skip(messages.length).where((e) => !e.mine).length;
        }
        messages = m;
      }
      _notify();
    } catch (_) {
      // انقطاع مؤقت: نكمل في الدورة التالية دون إزعاج القارئ
    } finally {
      _busy = false;
    }
  }

  Future<String?> send(String text) async {
    final t = text.trim();
    if (t.isEmpty || sending) return null;
    sending = true;
    _notify();
    try {
      final m = await _repo.sendMessage(_room.chatId, t);
      messages = [...messages, m];
      _repo.mockFriendReply(_room.chatId);
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      sending = false;
      _notify();
    }
  }

  void markRead() {
    unread = 0;
  }

  Future<void> leave() async {
    try {
      await _repo.leaveReadRoom(_room.id);
    } catch (_) {}
  }

  // ───────── المقارنة بين الموضعين ─────────

  bool get sameChapter => _room.friendKnown && myChapter > 0 && _room.friendChapter == myChapter;

  /// موجب = الصديق أمامك. null إن تعذّرت المقارنة (فصلان مختلفان أو غير معروف).
  int? get delta => sameChapter ? _room.friendPage - myPage : null;

  /// نص قصير لحالة الصديق بالنسبة لك
  String get status {
    if (!_room.friendKnown) return _room.friendOnline ? 'لم يبدأ بعد' : 'بانتظار صديقك';
    if (myChapter == 0) return 'فصل ${_room.friendChapter} · ص ${_room.friendPage}';
    final d = delta;
    if (d != null) {
      if (d == 0) return 'معك على الصفحة نفسها';
      return d > 0 ? 'أمامك · ${readRoomPages(d)}' : 'خلفك · ${readRoomPages(-d)}';
    }
    final g = _room.friendChapter - myChapter;
    return g > 0 ? 'أمامك · فصل ${_room.friendChapter}' : 'خلفك · فصل ${_room.friendChapter}';
  }

  @override
  void dispose() {
    _disposed = true;
    _poll?.cancel();
    _flush?.cancel();
    if (_dirty && myChapter > 0) {
      unawaited(_repo.updateReadPosition(_room.id, chapter: myChapter, page: myPage, total: myTotal).catchError((_) {}));
    }
    super.dispose();
  }
}

// ───────────────────────── عناصر مشتركة ─────────────────────────

class _Avatar extends StatelessWidget {
  const _Avatar(this.name, {this.size = 30, this.online = false});
  final String name;
  final double size;
  final bool online;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = _colorFor(name);
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: tint(c, 0.18),
              shape: BoxShape.circle,
              border: Border.all(color: tint(c, 0.55), width: 1.4),
            ),
            child: Text(name.characters.first, style: context.ds(size: size * 0.44, color: c)),
          ),
          if (online)
            PositionedDirectional(
              end: -1,
              bottom: -1,
              child: Container(
                width: size * 0.32,
                height: size * 0.32,
                decoration: BoxDecoration(
                  color: const Color(0xFF2FCB7A),
                  shape: BoxShape.circle,
                  border: Border.all(color: p.surface, width: 1.6),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ───────────────────────── الكبسولة داخل القارئ ─────────────────────────

class ReadRoomChip extends StatelessWidget {
  const ReadRoomChip({super.key, required this.ctrl, required this.onTap});
  final ReadRoomController ctrl;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: ctrl,
      builder: (context, _) {
        final r = ctrl.room;
        final ahead = (ctrl.delta ?? 0) > 0;
        return Pressable(
          onTap: onTap,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 230),
            padding: const EdgeInsetsDirectional.fromSTEB(6, 6, 14, 6),
            decoration: BoxDecoration(
              color: tint(p.surface, p.glass ? 0.82 : 0.96),
              borderRadius: BorderRadius.circular(40),
              border: Border.all(color: tint(_pink, 0.6), width: p.borderW),
              boxShadow: [
                BoxShadow(color: tint(_pink, 0.22 + 0.2 * p.glow), blurRadius: 14),
                BoxShadow(color: tint(Colors.black, 0.22), blurRadius: 12, offset: const Offset(0, 4)),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _Avatar(r.friendName, size: 32, online: r.friendOnline),
                const SizedBox(width: 9),
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(r.friendName, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.ts(size: 12, w: FontWeight.w700)),
                      Text(
                        ctrl.status,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.ts(size: 10.5, w: FontWeight.w600, color: ahead ? _pink : p.textDim),
                      ),
                    ],
                  ),
                ),
                if (ctrl.unread > 0) ...[
                  const SizedBox(width: 8),
                  Container(
                    constraints: const BoxConstraints(minWidth: 20),
                    height: 20,
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(color: _pink, shape: BoxShape.rectangle, borderRadius: BorderRadius.all(Radius.circular(10))),
                    child: Text('${ctrl.unread}', style: context.ts(size: 10.5, w: FontWeight.w700, color: Colors.white)),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

// ───────────────────────── ورقة الغرفة ─────────────────────────

Future<void> showReadRoomSheet(
  BuildContext context, {
  required ReadRoomController ctrl,
  required VoidCallback onJumpToFriend,
  required Future<void> Function() onLeave,
}) {
  ctrl.markRead();
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _RoomSheet(ctrl: ctrl, onJumpToFriend: onJumpToFriend, onLeave: onLeave),
  );
}

class _RoomSheet extends StatefulWidget {
  const _RoomSheet({required this.ctrl, required this.onJumpToFriend, required this.onLeave});
  final ReadRoomController ctrl;
  final VoidCallback onJumpToFriend;
  final Future<void> Function() onLeave;

  @override
  State<_RoomSheet> createState() => _RoomSheetState();
}

class _RoomSheetState extends State<_RoomSheet> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  int _shown = 0;

  @override
  void initState() {
    super.initState();
    widget.ctrl.chatOpen = true;
    widget.ctrl.addListener(_onChange);
    _shown = widget.ctrl.messages.length;
    _toBottom();
  }

  @override
  void dispose() {
    widget.ctrl.removeListener(_onChange);
    widget.ctrl.chatOpen = false;
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _onChange() {
    widget.ctrl.markRead();
    if (widget.ctrl.messages.length != _shown) {
      _shown = widget.ctrl.messages.length;
      _toBottom();
    }
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 240), curve: Curves.easeOutCubic);
      }
    });
  }

  Future<void> _send() async {
    final text = _input.text;
    if (text.trim().isEmpty) return;
    _input.clear();
    final err = await widget.ctrl.send(text);
    if (err != null && mounted) {
      _input.text = text;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  Future<void> _confirmLeave() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('مغادرة الغرفة؟', style: ctx.ts(size: 16, w: FontWeight.w700)),
        content: Text('ستتوقف مشاركة موضعك مع ${widget.ctrl.room.friendName}.', style: ctx.ts(size: 13)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('مغادرة')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    Navigator.pop(context);
    await widget.onLeave();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final inset = MediaQuery.of(context).viewInsets.bottom;
    final height = MediaQuery.of(context).size.height;
    final rad = Radius.circular(p.r(1.6).clamp(18.0, 32.0).toDouble());
    return Padding(
      padding: EdgeInsets.only(bottom: inset),
      child: SizedBox(
        height: height * 0.78,
        child: Container(
          decoration: BoxDecoration(
            color: p.bg,
            borderRadius: BorderRadius.only(topLeft: rad, topRight: rad),
            border: Border.all(color: p.border, width: p.borderW),
          ),
          child: AnimatedBuilder(
            animation: widget.ctrl,
            builder: (context, _) {
              final c = widget.ctrl;
              final r = c.room;
              return Column(
                children: [
                  const SizedBox(height: 8),
                  Container(width: 42, height: 4, decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4))),
                  Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(18, 12, 10, 4),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(color: tint(_pink, 0.16), borderRadius: BorderRadius.circular(p.r(0.9).toDouble())),
                          child: SIcon(SardIcons.groups_rounded, color: _pink, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('قراءة مشتركة', style: context.ds(size: 15)),
                              Text(
                                '${r.seriesTitle} · فصل ${r.chapter}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: context.ts(size: 11.5, color: p.textDim),
                              ),
                            ],
                          ),
                        ),
                        Pressable(
                          onTap: _confirmLeave,
                          child: Padding(
                            padding: const EdgeInsets.all(8),
                            child: SIcon(SardIcons.logout_rounded, color: p.textDim, size: 22),
                          ),
                        ),
                      ],
                    ),
                  ),
                  _positions(context, c),
                  Divider(height: 1, color: p.border),
                  Expanded(
                    child: c.messages.isEmpty
                        ? Center(child: Text('ابدأ الدردشة مع ${r.friendName}', style: context.ts(size: 13, color: p.textDim)))
                        : ListView.builder(
                            controller: _scroll,
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                            itemCount: c.messages.length,
                            itemBuilder: (context, i) => _bubble(context, c.messages[i]),
                          ),
                  ),
                  _inputBar(context, c),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _positions(BuildContext context, ReadRoomController c) {
    final p = context.pal;
    final r = c.room;
    final canJump = r.friendKnown && (c.delta == null || c.delta != 0);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
      child: Column(
        children: [
          _PosRow(
            name: 'أنت',
            color: p.accent,
            chapter: c.myChapter,
            page: c.myPage,
            total: c.myTotal,
          ),
          const SizedBox(height: 10),
          _PosRow(
            name: r.friendName,
            badge: r.friendBadge,
            color: _pink,
            chapter: r.friendChapter,
            page: r.friendPage,
            total: r.friendTotal,
            online: r.friendOnline,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Text(c.status, style: context.ts(size: 12, w: FontWeight.w600, color: (c.delta ?? 0) > 0 ? _pink : p.textDim)),
              ),
              if (canJump)
                Pressable(
                  onTap: () {
                    Navigator.pop(context);
                    widget.onJumpToFriend();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: tint(_pink, 0.14),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: tint(_pink, 0.5)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SIcon(SardIcons.auto_stories_rounded, color: _pink, size: 16),
                        const SizedBox(width: 6),
                        Text('اذهب إلى موضعه', style: context.ts(size: 11.5, w: FontWeight.w700, color: _pink)),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _bubble(BuildContext context, SardChatMessage m) {
    final p = context.pal;
    final mine = m.mine;
    return Align(
      alignment: mine ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.74),
        decoration: BoxDecoration(
          color: mine ? p.accent : p.surface,
          borderRadius: BorderRadius.circular(16),
          border: mine ? null : Border.all(color: p.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(m.text, style: context.ts(size: 13, color: mine ? p.onAccent : p.text, height: 1.5)),
            const SizedBox(height: 2),
            Text(m.time, style: context.ts(size: 9.5, color: mine ? tint(p.onAccent, 0.7) : p.textDim)),
          ],
        ),
      ),
    );
  }

  Widget _inputBar(BuildContext context, ReadRoomController c) {
    final p = context.pal;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _input,
                minLines: 1,
                maxLines: 3,
                style: context.ts(),
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: 'اكتب لصديقك…',
                  filled: true,
                  fillColor: p.surface,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide(color: p.border)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide(color: p.border)),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Pressable(
              onTap: _send,
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: p.accent, shape: BoxShape.circle),
                child: c.sending
                    ? Padding(padding: const EdgeInsets.all(13), child: CircularProgressIndicator(strokeWidth: 2, color: p.onAccent))
                    : SIcon(SardIcons.send_rounded, color: p.onAccent, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// صف موضع قارئ: الاسم + «فصل/صفحة» + شريط تقدّم
class _PosRow extends StatelessWidget {
  const _PosRow({
    required this.name,
    required this.color,
    required this.chapter,
    required this.page,
    required this.total,
    this.badge = SardBadge.none,
    this.online = false,
  });
  final String name;
  final SardBadge badge;
  final Color color;
  final int chapter, page, total;
  final bool online;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final known = chapter > 0 && page > 0;
    final frac = known && total > 0 ? (page / total).clamp(0.0, 1.0).toDouble() : 0.0;
    return Row(
      children: [
        _Avatar(name, size: 34, online: online),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: NameWithBadge(name, badge, style: context.ts(size: 12.5, w: FontWeight.w700), badgeSize: 14)),
                  Text(
                    known ? (total > 0 ? 'فصل $chapter · ص $page / $total' : 'فصل $chapter · ص $page') : '—',
                    style: context.ts(size: 11, w: FontWeight.w600, color: known ? color : p.textDim),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: frac,
                  minHeight: 7,
                  backgroundColor: tint(color, 0.16),
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ───────────────────────── ورقة الدعوة ─────────────────────────

/// تعرض أصدقاءك (من المحادثات) وتنشئ الغرفة عند الاختيار. تعيد الغرفة أو null.
Future<SardReadRoom?> showReadRoomInvite(
  BuildContext context, {
  required Series series,
  required int chapter,
}) {
  return showModalBottomSheet<SardReadRoom>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _InviteSheet(series: series, chapter: chapter),
  );
}

class _InviteSheet extends StatefulWidget {
  const _InviteSheet({required this.series, required this.chapter});
  final Series series;
  final int chapter;

  @override
  State<_InviteSheet> createState() => _InviteSheetState();
}

class _InviteSheetState extends State<_InviteSheet> {
  late Future<List<SardChat>> _future;
  String? _creating;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<SardChat>> _load() async {
    final all = await context.read<SardRepository>().chats();
    // المحادثات الفردية فقط (لها معرّف مستخدم)، وبدون المجموعات
    return all.where((c) => c.userId.isNotEmpty).toList();
  }

  Future<void> _pick(SardChat c) async {
    if (_creating != null) return;
    setState(() => _creating = c.id);
    try {
      final room = await context.read<SardRepository>().createReadRoom(
            seriesId: widget.series.id,
            seriesTitle: widget.series.title,
            chapter: widget.chapter,
            friendId: c.userId,
            friendName: c.name,
            friendBadge: c.badge,
          );
      if (mounted) Navigator.pop(context, room);
    } catch (e) {
      if (!mounted) return;
      setState(() => _creating = null);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر إنشاء الغرفة: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final rad = Radius.circular(p.r(1.6).clamp(18.0, 32.0).toDouble());
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.7),
      decoration: BoxDecoration(
        color: p.bg,
        borderRadius: BorderRadius.only(topLeft: rad, topRight: rad),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 8),
          Container(width: 42, height: 4, decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4))),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(color: tint(_pink, 0.16), borderRadius: BorderRadius.circular(p.r(0.9).toDouble())),
                  child: SIcon(SardIcons.groups_rounded, color: _pink, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('اقرأ مع صديق', style: context.ds(size: 15)),
                      Text(
                        '${widget.series.title} · فصل ${widget.chapter}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.ts(size: 11.5, color: p.textDim),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 6, 20, 10),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text('اختر صديقاً لتقرآ الفصل معاً ويرى كل منكما موضع الآخر.', style: context.ts(size: 12, color: p.textDim, height: 1.5)),
            ),
          ),
          Flexible(
            child: FutureBuilder<List<SardChat>>(
              future: _future,
              builder: (context, snap) {
                if (snap.hasError) {
                  return _note(context, 'تعذّر تحميل الأصدقاء. تأكد من اتصالك وحاول مجدداً.');
                }
                if (!snap.hasData) {
                  return const Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator()));
                }
                final items = snap.data!;
                if (items.isEmpty) return _note(context, 'لا يوجد أصدقاء بعد. ابدأ محادثة مع قارئ ثم عُد لدعوته.');
                return ListView.builder(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                  itemCount: items.length,
                  itemBuilder: (context, i) {
                    final c = items[i];
                    final busy = _creating == c.id;
                    return Pressable(
                      scale: 0.98,
                      onTap: () => _pick(c),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: p.surface,
                          borderRadius: BorderRadius.circular(p.r(1.2).toDouble()),
                          border: Border.all(color: p.border, width: p.borderW),
                        ),
                        child: Row(
                          children: [
                            _Avatar(c.name, size: 40),
                            const SizedBox(width: 12),
                            Expanded(child: NameWithBadge(c.name, c.badge, style: context.ts(size: 14, w: FontWeight.w700))),
                            busy
                                ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: _pink))
                                : Text('ادعُ', style: context.ts(size: 12.5, w: FontWeight.w700, color: _pink)),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _note(BuildContext context, String text) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Text(text, textAlign: TextAlign.center, style: context.ts(size: 13, color: context.pal.textDim, height: 1.6)),
      );
}
