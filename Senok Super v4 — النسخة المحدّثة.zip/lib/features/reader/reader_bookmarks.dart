// ──────────────────────────────────────────────────────────────────────────
//  الإشارات المرجعية v2 — حفظ مواضع في الفصول مع ملاحظات وألوان،
//  وتجميعها حسب العمل، وتصدير/استيراد.
//  المفتاح: rv2_bookmarks_v1
// ──────────────────────────────────────────────────────────────────────────
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'reader_progress.dart';

/// مفتاح تخزين الإشارات المرجعية.
const String kRv2BookmarksKey = 'rv2_bookmarks_v1';

/// أقصى عدد إشارات يُحتفظ بها.
const int kRv2BookmarksMax = 300;

// ───────── نموذج الإشارة ─────────

/// ألوان الإشارات المرجعية المتاحة.
enum BookmarkColor {
  red('أحمر', Color(0xFFE5484D)),
  amber('كهرماني', Color(0xFFF5A524)),
  green('أخضر', Color(0xFF0F9D75)),
  blue('أزرق', Color(0xFF3B9EFF)),
  purple('بنفسجي', Color(0xFFB44CFF)),
  pink('وردي', Color(0xFFE0457B));

  const BookmarkColor(this.label, this.color);
  final String label;
  final Color color;

  static BookmarkColor fromKey(String? key) {
    for (final c in BookmarkColor.values) {
      if (c.name == key) return c;
    }
    return BookmarkColor.amber;
  }
}

/// إشارة مرجعية واحدة: موضع + ملاحظة اختيارية + لون.
@immutable
class ReaderBookmark {
  const ReaderBookmark({
    required this.id,
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.page,
    required this.totalPages,
    required this.createdAt,
    this.note = '',
    this.color = BookmarkColor.amber,
  });

  final String id;
  final String seriesId;
  final String seriesTitle;
  final int chapter;
  final int page;
  final int totalPages;
  final DateTime createdAt;
  final String note;
  final BookmarkColor color;

  /// نسبة الموضع داخل الفصل 0..1
  double get fraction {
    if (totalPages <= 1) return 0;
    return ((page - 1) / (totalPages - 1)).clamp(0.0, 1.0).toDouble();
  }

  bool get hasNote => note.trim().isNotEmpty;

  /// جملة وصف: «الفصل 12 · صفحة 5»
  String get positionLabel => 'الفصل $chapter · صفحة $page';

  ReaderBookmark copyWith({
    String? note,
    BookmarkColor? color,
    int? page,
    int? totalPages,
  }) {
    return ReaderBookmark(
      id: id,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      page: page ?? this.page,
      totalPages: totalPages ?? this.totalPages,
      createdAt: createdAt,
      note: note ?? this.note,
      color: color ?? this.color,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'series_id': seriesId,
        'series_title': seriesTitle,
        'chapter': chapter,
        'page': page,
        'total_pages': totalPages,
        'created_at': createdAt.millisecondsSinceEpoch,
        'note': note,
        'color': color.name,
      };

  factory ReaderBookmark.fromJson(Map<String, dynamic> j) {
    DateTime at(dynamic v) {
      if (v is num) return DateTime.fromMillisecondsSinceEpoch(v.toInt());
      return DateTime.tryParse('$v') ?? DateTime.now();
    }

    return ReaderBookmark(
      id: '${j['id'] ?? ''}',
      seriesId: '${j['series_id'] ?? ''}',
      seriesTitle: '${j['series_title'] ?? ''}',
      chapter: (j['chapter'] as num?)?.toInt() ?? 0,
      page: (j['page'] as num?)?.toInt() ?? 1,
      totalPages: (j['total_pages'] as num?)?.toInt() ?? 0,
      createdAt: at(j['created_at']),
      note: '${j['note'] ?? ''}',
      color: BookmarkColor.fromKey(j['color'] as String?),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is ReaderBookmark && id == other.id;

  @override
  int get hashCode => id.hashCode;
}

// ───────── مخزن الإشارات ─────────

/// مخزن الإشارات المرجعية (مفردة عبر [ReaderBookmarkStore.i]).
class ReaderBookmarkStore extends ChangeNotifier {
  ReaderBookmarkStore._(this._p) {
    _items = _loadAll();
  }

  static ReaderBookmarkStore? _instance;

  static ReaderBookmarkStore get i {
    final inst = _instance;
    if (inst == null) throw StateError('ReaderBookmarkStore لم يُحمَّل بعد — نادِ load() أولاً.');
    return inst;
  }

  static Future<ReaderBookmarkStore> load() async {
    final p = await SharedPreferences.getInstance();
    return _instance ??= ReaderBookmarkStore._(p);
  }

  static ReaderBookmarkStore testInstance() => ReaderBookmarkStore._(_Rv2BmFakePrefs());

  final SharedPreferences _p;
  late List<ReaderBookmark> _items;

  List<ReaderBookmark> _loadAll() {
    try {
      final raw = _p.getString(kRv2BookmarksKey);
      if (raw == null || raw.isEmpty) return <ReaderBookmark>[];
      final list = jsonDecode(raw) as List;
      final out = <ReaderBookmark>[];
      for (final e in list) {
        if (e is! Map) continue;
        try {
          out.add(ReaderBookmark.fromJson(Map<String, dynamic>.from(e)));
        } catch (_) {}
      }
      out.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return out;
    } catch (_) {
      return <ReaderBookmark>[];
    }
  }

  Future<void> _save() async {
    final trimmed = _items.take(kRv2BookmarksMax).toList();
    if (trimmed.length != _items.length) _items = trimmed;
    await _p.setString(
      kRv2BookmarksKey,
      jsonEncode(_items.map((b) => b.toJson()).toList()),
    );
  }

  /// كل الإشارات (الأحدث أولاً).
  List<ReaderBookmark> get all => List<ReaderBookmark>.unmodifiable(_items);

  int get count => _items.length;

  /// إشارات عمل معيّن (الأحدث أولاً).
  List<ReaderBookmark> forSeries(String seriesId) =>
      _items.where((b) => b.seriesId == seriesId).toList();

  /// إشارات فصل معيّن.
  List<ReaderBookmark> forChapter(String seriesId, int chapter) =>
      _items.where((b) => b.seriesId == seriesId && b.chapter == chapter).toList();

  /// هل توجد إشارة في هذا الموضع بالضبط؟
  bool hasAt(String seriesId, int chapter, int page) =>
      _items.any((b) => b.seriesId == seriesId && b.chapter == chapter && b.page == page);

  /// إشارة موضع معيّن (أو null).
  ReaderBookmark? at(String seriesId, int chapter, int page) {
    for (final b in _items) {
      if (b.seriesId == seriesId && b.chapter == chapter && b.page == page) return b;
    }
    return null;
  }

  /// الأعمال ذات الإشارات (الأحدث أولاً) مع عدد إشارات كل عمل.
  List<(String id, String title, int count)> seriesWithBookmarks() {
    final map = <String, (String, int)>{};
    for (final b in _items) {
      final cur = map[b.seriesId];
      map[b.seriesId] = (b.seriesTitle, (cur?.$2 ?? 0) + 1);
    }
    final out = map.entries
        .map((e) => (e.key, e.value.$1, e.value.$2))
        .toList();
    return out;
  }

  /// يضيف إشارة جديدة ويعيدها.
  Future<ReaderBookmark> add({
    required Series series,
    required int chapter,
    required int page,
    required int totalPages,
    String note = '',
    BookmarkColor color = BookmarkColor.amber,
  }) async {
    final existing = at(series.id, chapter, page);
    if (existing != null) {
      // تحديث الإشارة الموجودة في الموضع نفسه بدل التكرار
      final updated = existing.copyWith(note: note, color: color);
      final i = _items.indexOf(existing);
      _items[i] = updated;
      await _save();
      notifyListeners();
      return updated;
    }
    final b = ReaderBookmark(
      id: 'bm_${DateTime.now().millisecondsSinceEpoch}_${math.Random().nextInt(9999)}',
      seriesId: series.id,
      seriesTitle: series.title,
      chapter: chapter,
      page: page,
      totalPages: totalPages,
      createdAt: DateTime.now(),
      note: note,
      color: color,
    );
    _items.insert(0, b);
    await _save();
    notifyListeners();
    return b;
  }

  /// يبدّل الإشارة في موضع: يضيفها إن غابت ويحذفها إن وُجدت.
  /// يعيد true إن صارت موجودة، وfalse إن حُذفت.
  Future<bool> toggle({
    required Series series,
    required int chapter,
    required int page,
    required int totalPages,
  }) async {
    final existing = at(series.id, chapter, page);
    if (existing != null) {
      await remove(existing.id);
      return false;
    }
    await add(series: series, chapter: chapter, page: page, totalPages: totalPages);
    return true;
  }

  /// يحدّث ملاحظة إشارة أو لونها.
  Future<void> update(String id, {String? note, BookmarkColor? color}) async {
    final i = _items.indexWhere((b) => b.id == id);
    if (i < 0) return;
    _items[i] = _items[i].copyWith(note: note, color: color);
    await _save();
    notifyListeners();
  }

  /// يحذف إشارة بمعرّفها.
  Future<void> remove(String id) async {
    _items.removeWhere((b) => b.id == id);
    await _save();
    notifyListeners();
  }

  /// يحذف كل إشارات عمل معيّن.
  Future<void> clearSeries(String seriesId) async {
    _items.removeWhere((b) => b.seriesId == seriesId);
    await _save();
    notifyListeners();
  }

  /// يمسح كل الإشارات.
  Future<void> clearAll() async {
    _items.clear();
    await _save();
    notifyListeners();
  }

  /// تصدير JSON نصاً.
  String exportJson() => jsonEncode(_items.map((b) => b.toJson()).toList());

  /// استيراد من JSON — يعيد عدد المستوردة.
  Future<int> importJson(String raw) async {
    try {
      final list = jsonDecode(raw) as List;
      var added = 0;
      for (final e in list) {
        if (e is! Map) continue;
        try {
          final b = ReaderBookmark.fromJson(Map<String, dynamic>.from(e));
          if (b.seriesId.isEmpty || b.id.isEmpty) continue;
          if (_items.any((x) => x.id == b.id)) continue;
          _items.add(b);
          added++;
        } catch (_) {}
      }
      _items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      await _save();
      notifyListeners();
      return added;
    } catch (_) {
      return 0;
    }
  }
}

/// بديل خفيف لـ SharedPreferences في الاختبارات (ذاكرة فقط).
class _Rv2BmFakePrefs implements SharedPreferences {
  final Map<String, Object> _m = {};

  @override
  Set<String> getKeys() => _m.keys.toSet();
  @override
  Object? get(String key) => _m[key];
  @override
  bool? getBool(String key) => _m[key] as bool?;
  @override
  double? getDouble(String key) => _m[key] as double?;
  @override
  int? getInt(String key) => _m[key] as int?;
  @override
  String? getString(String key) => _m[key] as String?;
  @override
  List<String>? getStringList(String key) => _m[key] as List<String>?;
  @override
  bool containsKey(String key) => _m.containsKey(key);
  @override
  Future<bool> setBool(String key, bool value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setDouble(String key, double value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setInt(String key, int value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setString(String key, String value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> remove(String key) async {
    _m.remove(key);
    return true;
  }

  @override
  Future<bool> clear() async {
    _m.clear();
    return true;
  }

  @override
  Future<bool> commit() async => true;
  @override
  Future<void> reload() async {}
}

// ───────── ويدجتات الإشارات المرجعية ─────────

/// زر إشارة مرجعية (للاستخدام في شريط القارئ).
class BookmarkButton extends StatelessWidget {
  const BookmarkButton({
    super.key,
    required this.bookmarked,
    required this.onToggle,
    this.size = 22,
  });

  final bool bookmarked;
  final VoidCallback onToggle;
  final double size;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return IconButton(
      onPressed: onToggle,
      tooltip: bookmarked ? 'إزالة الإشارة' : 'إضافة إشارة مرجعية',
      icon: SIcon(
        SardIcons.bookmark_rounded,
        size: size,
        color: bookmarked ? p.gold : p.text,
      ),
    );
  }
}

/// صفّ إشارة واحدة في القائمة.
class BookmarkRow extends StatelessWidget {
  const BookmarkRow({
    super.key,
    required this.bookmark,
    this.onTap,
    this.onDelete,
    this.onEditNote,
  });

  final ReaderBookmark bookmark;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final VoidCallback? onEditNote;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(0.8)),
            border: Border.all(color: p.border),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: tint(bookmark.color.color, 0.15),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Center(
                  child: SIcon(
                    SardIcons.bookmark_rounded,
                    size: 18,
                    color: bookmark.color.color,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      bookmark.seriesTitle,
                      style: context.ts(size: 14, w: FontWeight.w700),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${bookmark.positionLabel} · ${formatRv2DayLabel(bookmark.createdAt)}',
                      style: context.ts(size: 12, color: p.textDim),
                    ),
                    if (bookmark.hasNote) ...[
                      const SizedBox(height: 4),
                      Text(
                        bookmark.note,
                        style: context.ts(size: 12.5, color: p.text),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),
              if (onEditNote != null)
                IconButton(
                  onPressed: onEditNote,
                  tooltip: 'تعديل الملاحظة',
                  icon: SIcon(SardIcons.edit_rounded, size: 18, color: p.textDim),
                ),
              if (onDelete != null)
                IconButton(
                  onPressed: onDelete,
                  tooltip: 'حذف الإشارة',
                  icon: SIcon(SardIcons.close_rounded, size: 18, color: p.textDim),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// نافذة إضافة/تعديل ملاحظة ولون إشارة.
/// تعيد (الملاحظة، اللون) أو null عند الإلغاء.
Future<(String, BookmarkColor)?> showBookmarkEditor(
  BuildContext context, {
  String initialNote = '',
  BookmarkColor initialColor = BookmarkColor.amber,
}) {
  final noteCtrl = TextEditingController(text: initialNote);
  var color = initialColor;
  return showDialog<(String, BookmarkColor)?>(
    context: context,
    builder: (ctx) {
      final p = ctx.pal;
      return StatefulBuilder(
        builder: (ctx, setState) {
          return AlertDialog(
            title: const Text('إشارة مرجعية'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: noteCtrl,
                  maxLines: 3,
                  maxLength: 200,
                  decoration: const InputDecoration(
                    hintText: 'ملاحظة اختيارية — لماذا حفظت هذا الموضع؟',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                Text('اللون', style: ctx.ts(size: 13, w: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: BookmarkColor.values.map((c) {
                    final sel = c == color;
                    return Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () => setState(() => color = c),
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: c.color,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: sel ? p.text : Colors.transparent,
                              width: 2,
                            ),
                          ),
                          child: sel
                              ? const Center(
                                  child: Icon(Icons.check, size: 16, color: Colors.white),
                                )
                              : null,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(null),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(ctx).pop((noteCtrl.text.trim(), color)),
                child: const Text('حفظ'),
              ),
            ],
          );
        },
      );
    },
  );
}

// ───────── شاشة الإشارات المرجعية ─────────

/// شاشة كل الإشارات المرجعية، مجمّعة حسب العمل.
/// [onJump] يُنادى عند الضغط على إشارة (للانتقال لموضعها في القارئ).
class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key, this.onJump, this.seriesId});

  final void Function(ReaderBookmark bookmark)? onJump;

  /// إن مُرّر عمل، تُعرض إشاراته فقط.
  final String? seriesId;

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  late ReaderBookmarkStore store;
  BookmarkColor? _filterColor;
  String _query = '';

  @override
  void initState() {
    super.initState();
    store = ReaderBookmarkStore.i;
  }

  List<ReaderBookmark> get _visible {
    var list = widget.seriesId == null
        ? store.all
        : store.forSeries(widget.seriesId!);
    if (_filterColor != null) {
      list = list.where((b) => b.color == _filterColor).toList();
    }
    final q = _query.trim();
    if (q.isNotEmpty) {
      list = list
          .where((b) =>
              b.seriesTitle.contains(q) ||
              b.note.contains(q) ||
              b.positionLabel.contains(q))
          .toList();
    }
    return list;
  }

  Future<void> _editNote(ReaderBookmark b) async {
    final res = await showBookmarkEditor(
      context,
      initialNote: b.note,
      initialColor: b.color,
    );
    if (res == null) return;
    await store.update(b.id, note: res.$1, color: res.$2);
    setState(() {});
  }

  Future<void> _delete(ReaderBookmark b) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الإشارة؟'),
        content: Text('ستُحذف إشارة «${b.seriesTitle} — ${b.positionLabel}».'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await store.remove(b.id);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('الإشارات المرجعية'),
        actions: [
          if (store.count > 0)
            IconButton(
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('مسح كل الإشارات؟'),
                    content: Text('سيُحذف ${store.count} إشارة مرجعية نهائياً.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('إلغاء')),
                      FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('مسح الكل')),
                    ],
                  ),
                );
                if (ok == true) {
                  await store.clearAll();
                  setState(() {});
                }
              },
              tooltip: 'مسح الكل',
              icon: SIcon(SardIcons.close_rounded, size: 20, color: p.text),
            ),
        ],
      ),
      body: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          final list = _visible;
          // تجميع حسب العمل مع الحفاظ على ترتيب الأحدث
          final groups = <String, List<ReaderBookmark>>{};
          final titles = <String, String>{};
          for (final b in list) {
            (groups[b.seriesId] ??= <ReaderBookmark>[]).add(b);
            titles[b.seriesId] = b.seriesTitle;
          }
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: TextField(
                  onChanged: (v) => setState(() => _query = v),
                  decoration: InputDecoration(
                    hintText: 'ابحث في الإشارات والملاحظات…',
                    prefixIcon: SIcon(SardIcons.filter_list_rounded, size: 20, color: p.textDim),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: p.border),
                    ),
                    filled: true,
                    fillColor: p.surface,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                ),
              ),
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _ColorChip(
                      label: 'كل الألوان',
                      selected: _filterColor == null,
                      onTap: () => setState(() => _filterColor = null),
                    ),
                    for (final c in BookmarkColor.values)
                      _ColorChip(
                        label: c.label,
                        color: c.color,
                        selected: _filterColor == c,
                        onTap: () => setState(() =>
                            _filterColor = _filterColor == c ? null : c),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? _EmptyBookmarks(onBrowse: () => Navigator.of(context).pop())
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                        itemCount: groups.length,
                        itemBuilder: (context, gi) {
                          final sid = groups.keys.elementAt(gi);
                          final items = groups[sid]!;
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: 10),
                                child: Row(
                                  children: [
                                    Text(
                                      titles[sid] ?? sid,
                                      style: context.ds(size: 15),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: tint(p.accent, 0.12),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        '${items.length}',
                                        style: context.ts(size: 11.5, w: FontWeight.w800, color: p.accent),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              for (final b in items) ...[
                                BookmarkRow(
                                  bookmark: b,
                                  onTap: () => widget.onJump?.call(b),
                                  onEditNote: () => _editNote(b),
                                  onDelete: () => _delete(b),
                                ),
                                const SizedBox(height: 8),
                              ],
                            ],
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ColorChip extends StatelessWidget {
  const _ColorChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.color,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: selected ? p.text : p.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color ?? p.border),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (color != null) ...[
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                ],
                Text(
                  label,
                  style: context.ts(
                    size: 12.5,
                    w: selected ? FontWeight.w800 : FontWeight.w500,
                    color: selected ? p.bg : p.text,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptyBookmarks extends StatelessWidget {
  const _EmptyBookmarks({this.onBrowse});

  final VoidCallback? onBrowse;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: tint(p.gold, 0.14),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: SIcon(SardIcons.bookmark_rounded, size: 38, color: p.gold),
              ),
            ),
            const SizedBox(height: 16),
            Text('لا إشارات مرجعية بعد', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'أثناء القراءة، اضغط زر الإشارة أو اضغط مطولاً على صفحة لحفظ موضعها هنا مع ملاحظة ولون.',
              style: context.ts(size: 13, color: p.textDim),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            if (onBrowse != null)
              FilledButton(
                onPressed: onBrowse,
                child: const Text('تصفح الأعمال'),
              ),
          ],
        ),
      ),
    );
  }
}

// ───────── مشاركة وتصدير الإشارات ─────────

/// يبني نص مشاركة لإشارة مرجعية واحدة.
String buildBookmarkShareText(ReaderBookmark b) {
  final buf = StringBuffer();
  buf.writeln('إشارة مرجعية من «${b.seriesTitle}» على Senok:');
  buf.writeln(b.positionLabel);
  if (b.hasNote) buf.writeln('ملاحظتي: ${b.note}');
  return buf.toString().trim();
}

/// يبني نص قائمة إشارات عمل كامل (للمشاركة أو النسخ).
String buildBookmarksListText(String seriesTitle, List<ReaderBookmark> items) {
  if (items.isEmpty) return 'لا إشارات مرجعية في «$seriesTitle» بعد.';
  final buf = StringBuffer('إشاراتي في «$seriesTitle»:\n');
  for (final b in items) {
    buf.write('• ${b.positionLabel}');
    if (b.hasNote) buf.write(' — ${b.note}');
    buf.writeln();
  }
  return buf.toString().trim();
}

/// نافذة القفز السريع إلى إشارة: تعرض إشارات عمل وتعيد المختارة.
Future<ReaderBookmark?> showBookmarkJumpDialog(
  BuildContext context,
  List<ReaderBookmark> bookmarks,
) {
  final p = context.pal;
  return showDialog<ReaderBookmark?>(
    context: context,
    builder: (ctx) {
      return AlertDialog(
        title: const Text('القفز إلى إشارة'),
        content: SizedBox(
          width: double.maxFinite,
          child: bookmarks.isEmpty
              ? Text('لا إشارات في هذا العمل بعد.', style: ctx.ts(size: 13, color: p.textDim))
              : ListView.separated(
                  shrinkWrap: true,
                  itemCount: bookmarks.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 6),
                  itemBuilder: (ctx, i) {
                    final b = bookmarks[i];
                    return ListTile(
                      leading: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: tint(b.color.color, 0.15),
                          borderRadius: BorderRadius.circular(9),
                        ),
                        child: Center(
                          child: SIcon(SardIcons.bookmark_rounded, size: 16, color: b.color.color),
                        ),
                      ),
                      title: Text(b.positionLabel, style: ctx.ts(size: 13.5, w: FontWeight.w700)),
                      subtitle: b.hasNote ? Text(b.note, maxLines: 1, overflow: TextOverflow.ellipsis) : null,
                      onTap: () => Navigator.of(ctx).pop(b),
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(null),
            child: const Text('إلغاء'),
          ),
        ],
      );
    },
  );
}
