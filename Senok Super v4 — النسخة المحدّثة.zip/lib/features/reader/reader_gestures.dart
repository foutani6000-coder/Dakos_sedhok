// ──────────────────────────────────────────────────────────────────────────
//  إيماءات القارئ v2 — مناطق النقر، السحب، النقر المزدوج، الضغط المطوّل.
//  منطق قواعدي خالص: لا ذكاء اصطناعي، لا تعلّم آلي، قواعد ثابتة قابلة للاختبار.
// ──────────────────────────────────────────────────────────────────────────
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// مفتاح تخزين إعدادات الإيماءات.
const String kRv2GesturesKey = 'rv2_gestures_v1';

// ───────── مناطق النقر ─────────

/// منطقة النقر داخل صفحة القارئ.
///   first  = الثلث الأول (طرف البداية — حسب اتجاه القراءة)
///   center = الوسط (فتح/إغلاق واجهة القارئ)
///   last   = الثلث الأخير (طرف النهاية)
enum ReaderTapZone { first, center, last }

/// النسبة الافتراضية لعرض كل طرف (28٪) — الوسط يأخذ الباقي (44٪).
const double kRv2TapEdgeFraction = 0.28;

/// يحدّد منطقة النقر لنقطة [point] داخل صفحة بحجم [size].
/// القاعدة: x < 28٪ من العرض = الطرف الأول، x > 72٪ = الطرف الأخير،
/// وما بينهما = الوسط. خارج الحدود يُعامل كوسط.
ReaderTapZone tapZoneFor(Offset point, Size size) {
  if (size.width <= 0 || size.height <= 0) return ReaderTapZone.center;
  final edge = size.width * kRv2TapEdgeFraction;
  if (point.dx < edge) return ReaderTapZone.first;
  if (point.dx > size.width - edge) return ReaderTapZone.last;
  return ReaderTapZone.center;
}

/// مستطيلات مناطق النقر الثلاث داخل صفحة بحجم [size].
Map<ReaderTapZone, Rect> tapZoneRects(Size size, {double edgeFraction = kRv2TapEdgeFraction}) {
  final e = (edgeFraction.clamp(0.05, 0.45) * size.width).toDouble();
  return {
    ReaderTapZone.first: Rect.fromLTWH(0, 0, e, size.height),
    ReaderTapZone.center: Rect.fromLTWH(e, 0, size.width - 2 * e, size.height),
    ReaderTapZone.last: Rect.fromLTWH(size.width - e, 0, e, size.height),
  };
}

extension ReaderTapZoneX on ReaderTapZone {
  /// الاسم العربي للمنطقة.
  String get label {
    switch (this) {
      case ReaderTapZone.first:
        return 'الطرف الأول';
      case ReaderTapZone.center:
        return 'الوسط';
      case ReaderTapZone.last:
        return 'الطرف الأخير';
    }
  }

  /// وصف ما تفعله المنطقة افتراضياً في الوضع العمودي.
  String get hint {
    switch (this) {
      case ReaderTapZone.first:
        return 'العودة للصفحة السابقة';
      case ReaderTapZone.center:
        return 'إظهار/إخفاء أزرار القارئ';
      case ReaderTapZone.last:
        return 'الانتقال للصفحة التالية';
    }
  }
}

// ───────── إجراءات الإيماءات ─────────

/// الإجراءات التي يمكن ربطها بإيماءة.
enum ReaderGestureAction {
  none('لا شيء'),
  nextPage('الصفحة التالية'),
  prevPage('الصفحة السابقة'),
  toggleUi('إظهار/إخفاء الواجهة'),
  openChapters('قائمة الفصول'),
  openSettings('إعدادات القارئ'),
  toggleBookmark('إضافة/إزالة إشارة'),
  togglePanelMode('وضع اللوحات'),
  toggleAutoScroll('التمرير التلقائي'),
  nextChapter('الفصل التالي'),
  prevChapter('الفصل السابق');

  const ReaderGestureAction(this.label);
  final String label;

  static ReaderGestureAction fromKey(String? key) {
    for (final a in ReaderGestureAction.values) {
      if (a.name == key) return a;
    }
    return ReaderGestureAction.none;
  }
}

// ───────── السحب ─────────

/// اتجاه سحبة مصنّفة قواعدياً.
enum ReaderSwipeDirection { up, down, left, right, none }

/// يصنّف سحبة من إزاحتها [delta] وسرعتها [velocity].
/// القواعد: إزاحة أقل من 24 بكسل أو سرعة أقل من 100 بكسل/ثانية = لا سحبة.
/// الاتجاه الغالب (الأكبر إزاحة) هو الفائز.
ReaderSwipeDirection classifySwipe(Offset delta, double velocity) {
  const minDistance = 24.0;
  const minVelocity = 100.0;
  if (delta.distance < minDistance && velocity < minVelocity) {
    return ReaderSwipeDirection.none;
  }
  if (delta.distance < minDistance) return ReaderSwipeDirection.none;
  if (delta.dx.abs() > delta.dy.abs()) {
    return delta.dx > 0 ? ReaderSwipeDirection.right : ReaderSwipeDirection.left;
  }
  return delta.dy > 0 ? ReaderSwipeDirection.down : ReaderSwipeDirection.up;
}

/// هل السحبة أفقية (يمين/يسار)؟
bool isHorizontalSwipe(ReaderSwipeDirection d) =>
    d == ReaderSwipeDirection.left || d == ReaderSwipeDirection.right;

/// هل السحبة عمودية (أعلى/أسفل)؟
bool isVerticalSwipe(ReaderSwipeDirection d) =>
    d == ReaderSwipeDirection.up || d == ReaderSwipeDirection.down;

/// يحوّل اتجاه سحبة إلى إجراء تنقّل حسب وضع القراءة.
///  - الوضع العمودي: سحبة للأعلى = التالي، للأسفل = السابق.
///  - صفحة بصفحة (يمين←يسار): سحبة لليسار = التالي، لليمين = السابق.
///  - صفحة بصفحة (يسار←يمين): العكس.
ReaderGestureAction swipeToAction(
  ReaderSwipeDirection direction, {
  required bool vertical,
  required bool rtl,
}) {
  if (direction == ReaderSwipeDirection.none) return ReaderGestureAction.none;
  if (vertical) {
    if (direction == ReaderSwipeDirection.up) return ReaderGestureAction.nextPage;
    if (direction == ReaderSwipeDirection.down) return ReaderGestureAction.prevPage;
    return ReaderGestureAction.none;
  }
  if (rtl) {
    if (direction == ReaderSwipeDirection.left) return ReaderGestureAction.nextPage;
    if (direction == ReaderSwipeDirection.right) return ReaderGestureAction.prevPage;
  } else {
    if (direction == ReaderSwipeDirection.right) return ReaderGestureAction.nextPage;
    if (direction == ReaderSwipeDirection.left) return ReaderGestureAction.prevPage;
  }
  return ReaderGestureAction.none;
}

// ───────── النقر المزدوج والضغط المطوّل ─────────

/// إجراءات النقر المزدوج المتاحة.
enum ReaderDoubleTapAction {
  zoom('تكبير/تصغير'),
  nextPage('الصفحة التالية'),
  prevPage('الصفحة السابقة'),
  toggleUi('إظهار/إخفاء الواجهة'),
  none('لا شيء');

  const ReaderDoubleTapAction(this.label);
  final String label;

  static ReaderDoubleTapAction fromKey(String? key) {
    for (final a in ReaderDoubleTapAction.values) {
      if (a.name == key) return a;
    }
    return ReaderDoubleTapAction.zoom;
  }
}

/// إجراءات الضغط المطوّل المتاحة.
enum ReaderLongPressAction {
  bookmark('إضافة إشارة مرجعية'),
  openSettings('فتح الإعدادات'),
  openChapters('قائمة الفصول'),
  sharePage('مشاركة الصفحة'),
  none('لا شيء');

  const ReaderLongPressAction(this.label);
  final String label;

  static ReaderLongPressAction fromKey(String? key) {
    for (final a in ReaderLongPressAction.values) {
      if (a.name == key) return a;
    }
    return ReaderLongPressAction.bookmark;
  }
}

// ───────── إعدادات الإيماءات ─────────

/// إعدادات إيماءات القارئ v2 — تُحفظ محلياً وتُستعاد عند الإقلاع.
@immutable
class ReaderGestureSettings {
  const ReaderGestureSettings({
    this.tapZonesEnabled = true,
    this.edgeFraction = kRv2TapEdgeFraction,
    this.swipeEnabled = true,
    this.doubleTap = ReaderDoubleTapAction.zoom,
    this.longPress = ReaderLongPressAction.bookmark,
    this.tapFirst = ReaderGestureAction.prevPage,
    this.tapLast = ReaderGestureAction.nextPage,
    this.tapCenter = ReaderGestureAction.toggleUi,
    this.volumeKeysTurnPages = false,
    this.swipeToNextChapter = true,
    this.hapticFeedback = true,
  });

  /// تفعيل مناطق النقر (الأطراف/الوسط).
  final bool tapZonesEnabled;

  /// عرض كل طرف كنسبة من عرض الصفحة (0.15..0.40).
  final double edgeFraction;

  /// تفعيل السحب للتنقل.
  final bool swipeEnabled;

  /// إجراء النقر المزدوج.
  final ReaderDoubleTapAction doubleTap;

  /// إجراء الضغط المطوّل.
  final ReaderLongPressAction longPress;

  /// إجراء النقر على الطرف الأول / الأخير / الوسط.
  final ReaderGestureAction tapFirst;
  final ReaderGestureAction tapLast;
  final ReaderGestureAction tapCenter;

  /// أزرار الصوت تقلّب الصفحات (حيث يدعمها النظام).
  final bool volumeKeysTurnPages;

  /// السحب بعد آخر صفحة ينتقل للفصل التالي.
  final bool swipeToNextChapter;

  /// اهتزاز خفيف عند تنفيذ إجراء.
  final bool hapticFeedback;

  factory ReaderGestureSettings.defaults() => const ReaderGestureSettings();

  ReaderGestureSettings copyWith({
    bool? tapZonesEnabled,
    double? edgeFraction,
    bool? swipeEnabled,
    ReaderDoubleTapAction? doubleTap,
    ReaderLongPressAction? longPress,
    ReaderGestureAction? tapFirst,
    ReaderGestureAction? tapLast,
    ReaderGestureAction? tapCenter,
    bool? volumeKeysTurnPages,
    bool? swipeToNextChapter,
    bool? hapticFeedback,
  }) {
    return ReaderGestureSettings(
      tapZonesEnabled: tapZonesEnabled ?? this.tapZonesEnabled,
      edgeFraction: edgeFraction ?? this.edgeFraction,
      swipeEnabled: swipeEnabled ?? this.swipeEnabled,
      doubleTap: doubleTap ?? this.doubleTap,
      longPress: longPress ?? this.longPress,
      tapFirst: tapFirst ?? this.tapFirst,
      tapLast: tapLast ?? this.tapLast,
      tapCenter: tapCenter ?? this.tapCenter,
      volumeKeysTurnPages: volumeKeysTurnPages ?? this.volumeKeysTurnPages,
      swipeToNextChapter: swipeToNextChapter ?? this.swipeToNextChapter,
      hapticFeedback: hapticFeedback ?? this.hapticFeedback,
    );
  }

  Map<String, dynamic> toJson() => {
        'tap_zones': tapZonesEnabled,
        'edge_fraction': edgeFraction,
        'swipe': swipeEnabled,
        'double_tap': doubleTap.name,
        'long_press': longPress.name,
        'tap_first': tapFirst.name,
        'tap_last': tapLast.name,
        'tap_center': tapCenter.name,
        'volume_keys': volumeKeysTurnPages,
        'swipe_next_chapter': swipeToNextChapter,
        'haptic': hapticFeedback,
      };

  factory ReaderGestureSettings.fromJson(Map<String, dynamic> j) {
    double edge(dynamic v) {
      final d = (v as num?)?.toDouble() ?? kRv2TapEdgeFraction;
      return d.clamp(0.15, 0.40).toDouble();
    }

    return ReaderGestureSettings(
      tapZonesEnabled: j['tap_zones'] != false,
      edgeFraction: edge(j['edge_fraction']),
      swipeEnabled: j['swipe'] != false,
      doubleTap: ReaderDoubleTapAction.fromKey(j['double_tap'] as String?),
      longPress: ReaderLongPressAction.fromKey(j['long_press'] as String?),
      tapFirst: ReaderGestureAction.fromKey(j['tap_first'] as String?),
      tapLast: ReaderGestureAction.fromKey(j['tap_last'] as String?),
      tapCenter: ReaderGestureAction.fromKey(j['tap_center'] as String?),
      volumeKeysTurnPages: j['volume_keys'] == true,
      swipeToNextChapter: j['swipe_next_chapter'] != false,
      hapticFeedback: j['haptic'] != false,
    );
  }

  /// إجراء منطقة نقر معيّنة حسب الإعدادات الحالية.
  ReaderGestureAction actionForZone(ReaderTapZone zone) {
    if (!tapZonesEnabled) return ReaderGestureAction.none;
    switch (zone) {
      case ReaderTapZone.first:
        return tapFirst;
      case ReaderTapZone.center:
        return tapCenter;
      case ReaderTapZone.last:
        return tapLast;
    }
  }

  /// إجراء نقطة نقر داخل صفحة بحجم [size].
  ReaderGestureAction actionForTap(Offset point, Size size) =>
      actionForZone(tapZoneFor(point, size));
}

/// مخزن إعدادات الإيماءات (مفردة).
class ReaderGestureStore extends ChangeNotifier {
  ReaderGestureStore._(this._p) {
    _settings = _load();
  }

  static ReaderGestureStore? _instance;

  static ReaderGestureStore get i {
    final inst = _instance;
    if (inst == null) throw StateError('ReaderGestureStore لم يُحمَّل بعد — نادِ load() أولاً.');
    return inst;
  }

  static Future<ReaderGestureStore> load() async {
    final p = await SharedPreferences.getInstance();
    return _instance ??= ReaderGestureStore._(p);
  }

  static ReaderGestureStore testInstance() => ReaderGestureStore._(_Rv2FakePrefs());

  final SharedPreferences _p;
  late ReaderGestureSettings _settings;

  ReaderGestureSettings _load() {
    try {
      final raw = _p.getString(kRv2GesturesKey);
      if (raw == null || raw.isEmpty) return ReaderGestureSettings.defaults();
      return ReaderGestureSettings.fromJson(
        Map<String, dynamic>.from(jsonDecode(raw) as Map),
      );
    } catch (_) {
      return ReaderGestureSettings.defaults();
    }
  }

  ReaderGestureSettings get settings => _settings;

  Future<void> update(ReaderGestureSettings next) async {
    _settings = next;
    await _p.setString(kRv2GesturesKey, jsonEncode(next.toJson()));
    notifyListeners();
  }

  Future<void> reset() async => update(ReaderGestureSettings.defaults());
}

/// بديل خفيف لـ SharedPreferences في الاختبارات (ذاكرة فقط).
class _Rv2FakePrefs implements SharedPreferences {
  final Map<String, Object> _m = {};

  @override
  Set<String> getKeys() => _m.keys.toSet();
  @override
  Object? get(String key) => _m[key];
  @override
  bool? getBool(String key) => _m[key] as bool?;
  @override
  double? getDouble(String key) => _m[key] as double?;
  @override
  int? getInt(String key) => _m[key] as int?;
  @override
  String? getString(String key) => _m[key] as String?;
  @override
  List<String>? getStringList(String key) => _m[key] as List<String>?;
  @override
  bool containsKey(String key) => _m.containsKey(key);
  @override
  Future<bool> setBool(String key, bool value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setDouble(String key, double value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setInt(String key, int value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setString(String key, String value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> remove(String key) async {
    _m.remove(key);
    return true;
  }

  @override
  Future<bool> clear() async {
    _m.clear();
    return true;
  }

  @override
  Future<bool> commit() async => true;
  @override
  Future<void> reload() async {}
}

// ───────── ويدجتات الإيماءات ─────────

/// طبقة توضيحية لمناطق النقر (تُعرض عند الطلب من دليل الإيماءات).
/// تُظهر الطرفين والوسط بألوان شفافة مع تسميات.
class TapZoneOverlay extends StatelessWidget {
  const TapZoneOverlay({
    super.key,
    required this.settings,
    this.onZoneTap,
  });

  final ReaderGestureSettings settings;
  final ValueChanged<ReaderTapZone>? onZoneTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = Size(constraints.maxWidth, constraints.maxHeight);
        final rects = tapZoneRects(size, edgeFraction: settings.edgeFraction);
        Widget zone(ReaderTapZone z, Color color) {
          final r = rects[z]!;
          final action = settings.actionForZone(z);
          return Positioned(
            left: r.left,
            top: r.top,
            width: r.width,
            height: r.height,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onZoneTap == null ? null : () => onZoneTap!(z),
                child: Container(
                  decoration: BoxDecoration(
                    color: tint(color, 0.10),
                    border: Border.all(color: tint(color, 0.35)),
                  ),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(z.label, style: context.ts(size: 13, w: FontWeight.w800, color: p.text)),
                          const SizedBox(height: 2),
                          Text(
                            action.label,
                            style: context.ts(size: 11.5, color: p.textDim),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        }

        return Stack(
          children: [
            zone(ReaderTapZone.first, p.accent),
            zone(ReaderTapZone.center, p.gold),
            zone(ReaderTapZone.last, p.accent),
          ],
        );
      },
    );
  }
}

/// بطاقة إرشاد إيماءة واحدة في الدليل.
class GestureHintRow extends StatelessWidget {
  const GestureHintRow({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
  });

  final SIconData icon;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Center(child: SIcon(icon, size: 19, color: p.accent)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.ts(size: 14, w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(description, style: context.ts(size: 12.5, color: p.textDim)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// ورقة دليل الإيماءات الكاملة (تُفتح من القارئ).
class GestureGuideSheet extends StatelessWidget {
  const GestureGuideSheet({super.key, required this.settings});

  final ReaderGestureSettings settings;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: p.border,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('دليل الإيماءات', style: context.ds(size: 19)),
            const SizedBox(height: 4),
            Text(
              'كل الإيماءات قابلة للتخصيص من إعدادات القارئ — هذه الإعدادات الحالية:',
              style: context.ts(size: 12.5, color: p.textDim),
            ),
            const SizedBox(height: 14),
            GestureHintRow(
              icon: SardIcons.chrome_reader_mode_rounded,
              title: 'النقر على الأطراف',
              description:
                  'الطرف الأول (${(settings.edgeFraction * 100).round()}٪): ${settings.tapFirst.label} · الطرف الأخير: ${settings.tapLast.label}',
            ),
            const GestureHintRow(
              icon: SardIcons.visibility_rounded,
              title: 'النقر على الوسط',
              description: 'يُظهر أزرار القارئ أو يخفيها — الوسط يغطي 44٪ من عرض الصفحة.',
            ),
            GestureHintRow(
              icon: SardIcons.auto_stories_rounded,
              title: 'السحب',
              description: settings.swipeEnabled
                  ? 'اسحب للأعلى/للأسفل في الوضع العمودي، أو يميناً/يساراً في وضع الصفحات للتنقل.'
                  : 'السحب معطّل حالياً من الإعدادات.',
            ),
            GestureHintRow(
              icon: SardIcons.star_rounded,
              title: 'النقر المزدوج: ${settings.doubleTap.label}',
              description: 'انقر مرتين بسرعة على أي صفحة لتنفيذ الإجراء المختار.',
            ),
            GestureHintRow(
              icon: SardIcons.bookmark_rounded,
              title: 'الضغط المطوّل: ${settings.longPress.label}',
              description: 'اضغط مطولاً على صفحة لتنفيذ الإجراء المختار.',
            ),
            if (settings.swipeToNextChapter)
              const GestureHintRow(
                icon: SardIcons.play_arrow_rounded,
                title: 'الانتقال للفصل التالي',
                description: 'السحب بعد آخر صفحة ينقلك تلقائياً إلى الفصل التالي (إن وُجد).',
              ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('فهمت'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// يفتح ورقة دليل الإيماءات.
Future<void> showGestureGuide(BuildContext context, ReaderGestureSettings settings) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => GestureGuideSheet(settings: settings),
  );
}

// ───────── شاشة إعدادات الإيماءات ─────────

/// شاشة إعدادات الإيماءات الكاملة: تفعيل المناطق، عرض الطرف،
/// إجراءات النقر المزدوج والضغط المطوّل، وربط مناطق النقر.
class GestureSettingsScreen extends StatefulWidget {
  const GestureSettingsScreen({super.key});

  @override
  State<GestureSettingsScreen> createState() => _GestureSettingsScreenState();
}

class _GestureSettingsScreenState extends State<GestureSettingsScreen> {
  late ReaderGestureStore _store;

  @override
  void initState() {
    super.initState();
    _store = ReaderGestureStore.i;
  }

  Future<void> _update(ReaderGestureSettings Function(ReaderGestureSettings s) fn) async {
    await _store.update(fn(_store.settings));
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('إعدادات الإيماءات'),
        actions: [
          TextButton(
            onPressed: () async {
              await _store.reset();
              setState(() {});
            },
            child: const Text('إعادة تعيين'),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: _store,
        builder: (context, _) {
          final s = _store.settings;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
            children: [
              _GestureSection(
                icon: SardIcons.chrome_reader_mode_rounded,
                color: const Color(0xFF3B9EFF),
                title: 'مناطق النقر',
                note: 'قسّم الصفحة إلى ثلاثة أجزاء: طرفان للتنقل ووسط للواجهة.',
                child: Column(
                  children: [
                    _GestureSwitch(
                      title: 'تفعيل مناطق النقر',
                      subtitle: 'إيقافها يجعل أي نقرة تُظهر/تخفي الواجهة',
                      value: s.tapZonesEnabled,
                      onChanged: (v) => _update((s) => s.copyWith(tapZonesEnabled: v)),
                    ),
                    _GestureSlider(
                      title: 'عرض الطرف',
                      valueLabel: '${(s.edgeFraction * 100).round()}٪ من عرض الصفحة',
                      value: s.edgeFraction,
                      min: 0.15,
                      max: 0.40,
                      onChanged: (v) => _update((s) => s.copyWith(edgeFraction: v)),
                    ),
                    const SizedBox(height: 6),
                    _ZoneActionPicker(
                      label: 'الطرف الأول',
                      value: s.tapFirst,
                      onChanged: (a) => _update((s) => s.copyWith(tapFirst: a)),
                    ),
                    _ZoneActionPicker(
                      label: 'الوسط',
                      value: s.tapCenter,
                      onChanged: (a) => _update((s) => s.copyWith(tapCenter: a)),
                    ),
                    _ZoneActionPicker(
                      label: 'الطرف الأخير',
                      value: s.tapLast,
                      onChanged: (a) => _update((s) => s.copyWith(tapLast: a)),
                    ),
                  ],
                ),
              ),
              _GestureSection(
                icon: SardIcons.auto_stories_rounded,
                color: const Color(0xFF0F9D75),
                title: 'السحب واللمس',
                note: 'سلوك السحب للتنقل بين الصفحات والفصول.',
                child: Column(
                  children: [
                    _GestureSwitch(
                      title: 'السحب للتنقل',
                      subtitle: 'اسحب للانتقال بين الصفحات',
                      value: s.swipeEnabled,
                      onChanged: (v) => _update((s) => s.copyWith(swipeEnabled: v)),
                    ),
                    _GestureSwitch(
                      title: 'السحب للفصل التالي',
                      subtitle: 'السحب بعد آخر صفحة ينتقل للفصل التالي',
                      value: s.swipeToNextChapter,
                      onChanged: (v) => _update((s) => s.copyWith(swipeToNextChapter: v)),
                    ),
                    _GestureSwitch(
                      title: 'اهتزاز خفيف',
                      subtitle: 'اهتزاز قصير عند تنفيذ إجراء',
                      value: s.hapticFeedback,
                      onChanged: (v) => _update((s) => s.copyWith(hapticFeedback: v)),
                    ),
                  ],
                ),
              ),
              _GestureSection(
                icon: SardIcons.star_rounded,
                color: const Color(0xFFF5A524),
                title: 'النقر المزدوج والضغط المطوّل',
                note: 'اختر ما يفعله النقر المزدوج والضغط المطوّل على صفحة.',
                child: Column(
                  children: [
                    _EnumPicker<ReaderDoubleTapAction>(
                      label: 'النقر المزدوج',
                      value: s.doubleTap,
                      values: ReaderDoubleTapAction.values,
                      labelOf: (a) => a.label,
                      onChanged: (a) => _update((s) => s.copyWith(doubleTap: a)),
                    ),
                    const SizedBox(height: 10),
                    _EnumPicker<ReaderLongPressAction>(
                      label: 'الضغط المطوّل',
                      value: s.longPress,
                      values: ReaderLongPressAction.values,
                      labelOf: (a) => a.label,
                      onChanged: (a) => _update((s) => s.copyWith(longPress: a)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => showGestureGuide(context, s),
                  icon: SIcon(SardIcons.visibility_rounded, size: 18, color: p.text),
                  label: const Text('عرض دليل الإيماءات'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _GestureSection extends StatelessWidget {
  const _GestureSection({
    required this.icon,
    required this.color,
    required this.title,
    required this.note,
    required this.child,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String note;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: tint(color, 0.13),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: SIcon(icon, size: 18, color: color)),
              ),
              const SizedBox(width: 10),
              Expanded(child: Text(title, style: context.ds(size: 15.5))),
            ],
          ),
          const SizedBox(height: 4),
          Text(note, style: context.ts(size: 12.5, color: p.textDim)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _GestureSwitch extends StatelessWidget {
  const _GestureSwitch({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.ts(size: 13.5, w: FontWeight.w700)),
                Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChanged, activeColor: p.accent),
        ],
      ),
    );
  }
}

class _GestureSlider extends StatelessWidget {
  const _GestureSlider({
    required this.title,
    required this.valueLabel,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  final String title;
  final String valueLabel;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(title, style: context.ts(size: 13.5, w: FontWeight.w700))),
              Text(valueLabel, style: context.ts(size: 12, w: FontWeight.w800, color: p.accent)),
            ],
          ),
          Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            activeColor: p.accent,
            inactiveColor: p.border,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

/// منتقي إجراء لمنطقة نقر (قائمة منسدلة بسيطة).
class _ZoneActionPicker extends StatelessWidget {
  const _ZoneActionPicker({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final ReaderGestureAction value;
  final ValueChanged<ReaderGestureAction> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: context.ts(size: 13.5, w: FontWeight.w700))),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: p.surfaceHi,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: p.border),
            ),
            child: DropdownButton<ReaderGestureAction>(
              value: value,
              underline: const SizedBox.shrink(),
              icon: SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
              items: ReaderGestureAction.values
                  .map((a) => DropdownMenuItem(value: a, child: Text(a.label, style: context.ts(size: 12.5))))
                  .toList(),
              onChanged: (a) {
                if (a != null) onChanged(a);
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// منتقي عام لقيم تعدادية (شرائح اختيار).
class _EnumPicker<T> extends StatelessWidget {
  const _EnumPicker({
    required this.label,
    required this.value,
    required this.values,
    required this.labelOf,
    required this.onChanged,
  });

  final String label;
  final T value;
  final List<T> values;
  final String Function(T) labelOf;
  final ValueChanged<T> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13.5, w: FontWeight.w700)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: values.map((v) {
            final sel = v == value;
            return ChoiceChip(
              label: Text(labelOf(v)),
              selected: sel,
              selectedColor: tint(p.accent, 0.2),
              labelStyle: context.ts(size: 12.5, w: sel ? FontWeight.w800 : FontWeight.w500),
              onSelected: (_) => onChanged(v),
            );
          }).toList(),
        ),
      ],
    );
  }
}
