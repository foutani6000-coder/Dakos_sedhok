import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import 'package:flutter/rendering.dart' show RenderAbstractViewport, ScrollDirection;

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/mock_page.dart';
import '../../widgets/sard_icons.dart';

/// واجهة مشتركة للانتقال لصفحة معيّنة (تبدأ من 1)
abstract class PageJumper {
  void jumpToPage(int page);
}

// ───────── اختيار الرابط والجودة (البند 18) ─────────

/// الرابط المخفّض إن وُجد وكان التوفير مفعّلاً، وإلا الرابط الكامل
String pageUrl(PageSrc s, bool low) => (low && s.low != null) ? s.low! : s.url;

/// مزوّد صورة واحد يُستعمل للعرض وللتحميل المسبق ليتطابق مفتاح الكاش.
/// عند التوفير تُصغَّر الصورة في الذاكرة إلى 720 بكسل عرضاً.
ImageProvider pageProvider(PageSrc s, bool low, double widthPx) {
  if (s.url.startsWith('file:')) return FileImage(File(s.url.substring(5)));
  final w = low ? math.min(widthPx, 720.0) : math.min(widthPx, 1600.0);
  return CachedNetworkImageProvider(pageUrl(s, low), maxWidth: w.round());
}

// ───────── تكبير بالقرص + نقر مزدوج ─────────

class ZoomBox extends StatefulWidget {
  const ZoomBox({super.key, required this.builder, this.onTap, this.onZoomChanged});

  final Widget Function(BuildContext context, bool zoomed) builder;
  final void Function(Offset local, Size size)? onTap;
  final ValueChanged<bool>? onZoomChanged;

  @override
  State<ZoomBox> createState() => _ZoomBoxState();
}

class _ZoomBoxState extends State<ZoomBox> with SingleTickerProviderStateMixin {
  final TransformationController _tc = TransformationController();
  late final AnimationController _ac = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 260),
  );
  Animation<Matrix4>? _anim;
  bool _zoomed = false;
  Offset _dt = Offset.zero;

  @override
  void initState() {
    super.initState();
    _ac.addListener(() {
      final a = _anim;
      if (a != null) _tc.value = a.value;
    });
    _ac.addStatusListener((s) {
      if (s == AnimationStatus.completed) _sync();
    });
  }

  @override
  void dispose() {
    _ac.dispose();
    _tc.dispose();
    super.dispose();
  }

  void _sync() {
    final z = _tc.value.getMaxScaleOnAxis() > 1.02;
    if (z != _zoomed) {
      setState(() => _zoomed = z);
      widget.onZoomChanged?.call(z);
    }
  }

  void _toggle() {
    final from = _tc.value.clone();
    Matrix4 to;
    if (_zoomed) {
      to = Matrix4.identity();
    } else {
      const s = 2.4;
      to = Matrix4.identity()
        ..translate(-_dt.dx * (s - 1), -_dt.dy * (s - 1))
        ..scale(s, s, 1.0);
    }
    _anim = Matrix4Tween(begin: from, end: to)
        .animate(CurvedAnimation(parent: _ac, curve: Curves.easeOutCubic));
    _ac
      ..reset()
      ..forward();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final size = box.biggest;
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (d) => widget.onTap?.call(d.localPosition, size),
          onDoubleTapDown: (d) => _dt = d.localPosition,
          onDoubleTap: _toggle,
          child: InteractiveViewer(
            transformationController: _tc,
            minScale: 1,
            maxScale: 4,
            panEnabled: _zoomed,
            onInteractionEnd: (_) => _sync(),
            child: widget.builder(context, _zoomed),
          ),
        );
      },
    );
  }
}

// ───────── صورة صفحة واحدة ─────────

/// تعرض صفحة بنسبتها الحقيقية (بعد أول تحميل تُحفظ النسبة في [ratios]
/// فلا تحدث قفزات عند إعادة البناء). في الوضع العمودي تأخذ العرض كاملاً،
/// وفي وضع صفحة-بصفحة تُحتوى داخل الشاشة.
class ReaderPageImage extends StatefulWidget {
  const ReaderPageImage({
    super.key,
    required this.src,
    required this.low,
    required this.widthPx,
    required this.ratios,
    this.paged = false,
  });

  final PageSrc src;
  final bool low;
  final double widthPx;
  final Map<String, double> ratios;
  final bool paged;

  @override
  State<ReaderPageImage> createState() => _ReaderPageImageState();
}

class _ReaderPageImageState extends State<ReaderPageImage> {
  ImageProvider? _provider;
  ImageStream? _stream;
  ImageStreamListener? _listener;
  bool _loaded = false;
  bool _failed = false;
  bool _built = false;
  double? _ratio;

  @override
  void initState() {
    super.initState();
    _ratio = widget.ratios[widget.src.url];
    _start();
  }

  @override
  void didUpdateWidget(covariant ReaderPageImage old) {
    super.didUpdateWidget(old);
    if (old.src.url != widget.src.url || old.low != widget.low) {
      _loaded = false;
      _failed = false;
      _start();
    }
  }

  void _start() {
    _stop();
    if (widget.src.isMock) {
      _loaded = true;
      return;
    }
    final prov = pageProvider(widget.src, widget.low, widget.widthPx);
    _provider = prov;
    final stream = prov.resolve(ImageConfiguration.empty);
    final l = ImageStreamListener(
      (info, sync) {
        final h = info.image.height;
        if (h <= 0) return;
        final r = info.image.width / h;
        widget.ratios[widget.src.url] = r;
        _ratio = r;
        _loaded = true;
        _failed = false;
        if (mounted && _built) setState(() {});
      },
      onError: (Object e, StackTrace? st) {
        _failed = true;
        if (mounted && _built) setState(() {});
      },
    );
    stream.addListener(l);
    _stream = stream;
    _listener = l;
  }

  void _stop() {
    final s = _stream;
    final l = _listener;
    if (s != null && l != null) s.removeListener(l);
    _stream = null;
    _listener = null;
  }

  @override
  void dispose() {
    _stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _built = true;
    final p = context.pal;

    if (widget.src.isMock) {
      return widget.paged
          ? Center(child: MockPage(src: widget.src.url))
          : MockPage(src: widget.src.url);
    }

    if (_failed) {
      return Pressable(
        onTap: () {
          setState(() => _failed = false);
          _start();
        },
        child: AspectRatio(
          aspectRatio: widget.paged ? 0.75 : 1.2,
          child: Container(
            color: p.surface,
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SIcon(SardIcons.refresh_rounded, size: 30, color: p.textDim),
                const SizedBox(height: 8),
                Text('تعذّر تحميل الصفحة · اضغط للإعادة',
                    style: context.ts(size: 12.5, color: p.textDim)),
              ],
            ),
          ),
        ),
      );
    }

    if (widget.paged) {
      if (!_loaded || _provider == null) {
        return Center(
          child: SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(strokeWidth: 2.4, color: p.accent),
          ),
        );
      }
      return SizedBox.expand(
        child: Image(
          image: _provider!,
          fit: BoxFit.contain,
          gaplessPlayback: true,
          filterQuality: FilterQuality.medium,
        ),
      );
    }

    return AspectRatio(
      aspectRatio: _ratio ?? 0.7,
      child: (_loaded && _provider != null)
          ? Image(
              image: _provider!,
              fit: BoxFit.fill,
              gaplessPlayback: true,
              filterQuality: FilterQuality.medium,
            )
          : const Skeleton(radius: 0),
    );
  }
}

// ───────── السحب عند الحافة للتنقل بين الفصول ─────────

/// يلتقط السحب الزائد (Overscroll) عند أول/آخر المحتوى ويُظهر تلميحاً حيّاً،
/// وعند تجاوز العتبة يستدعي [onEdge] بـ +1 (الفصل التالي) أو -1 (السابق).
class EdgeSwipe extends StatefulWidget {
  const EdgeSwipe({
    super.key,
    required this.axis,
    required this.onEdge,
    required this.child,
    this.canNext = true,
    this.canPrev = true,
    this.threshold = 110,
  });

  final Axis axis;
  final ValueChanged<int> onEdge;
  final Widget child;
  final bool canNext;
  final bool canPrev;
  final double threshold;

  @override
  State<EdgeSwipe> createState() => _EdgeSwipeState();
}

class _EdgeSwipeState extends State<EdgeSwipe> {
  final ValueNotifier<double> _hint = ValueNotifier<double>(0);
  double _over = 0;
  bool _fired = false;

  @override
  void dispose() {
    _hint.dispose();
    super.dispose();
  }

  bool _onNote(ScrollNotification n) {
    if (n.depth != 0 || n.metrics.axis != widget.axis) return false;
    if (n is OverscrollNotification) {
      if (n.dragDetails == null || _fired) return false;
      _over += n.overscroll;
      final v = (_over / widget.threshold).clamp(-1.0, 1.0).toDouble();
      _hint.value = v;
      if (v.abs() >= 1) {
        _fired = true;
        widget.onEdge(v > 0 ? 1 : -1);
      }
    } else if (n is ScrollUpdateNotification) {
      // رجوع الإصبع للاتجاه المعاكس يلغي السحب
      if (_over != 0 && !_fired) {
        _over = 0;
        _hint.value = 0;
      }
    } else if (n is ScrollEndNotification) {
      _over = 0;
      _fired = false;
      _hint.value = 0;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: NotificationListener<ScrollNotification>(
            onNotification: _onNote,
            child: widget.child,
          ),
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: ValueListenableBuilder<double>(
              valueListenable: _hint,
              builder: (context, v, _) {
                if (v.abs() < 0.06) return const SizedBox.shrink();
                final next = v > 0;
                final can = next ? widget.canNext : widget.canPrev;
                final p = context.pal;
                final color = can ? p.accent : p.textDim;
                final text = can
                    ? (next ? 'اسحب للفصل التالي' : 'اسحب للفصل السابق')
                    : (next ? 'هذا آخر فصل' : 'هذا أول فصل');
                return Align(
                  alignment: next ? Alignment.bottomCenter : Alignment.topCenter,
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(
                      40,
                      MediaQuery.of(context).padding.top + 90,
                      40,
                      MediaQuery.of(context).padding.bottom + 120,
                    ),
                    child: Opacity(
                      opacity: v.abs().clamp(0.0, 1.0).toDouble(),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                        decoration: BoxDecoration(
                          color: p.surface,
                          borderRadius: BorderRadius.circular(p.r(1.2).clamp(14.0, 28.0).toDouble()),
                          border: Border.all(color: color, width: p.borderW + 0.4),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SIcon(next ? SardIcons.skip_next_rounded : SardIcons.skip_previous_rounded,
                                    color: color, size: 22),
                                const SizedBox(width: 8),
                                Text(text, style: context.ts(size: 13.5, w: FontWeight.w700, color: p.text)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: 150,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(99),
                                child: LinearProgressIndicator(
                                  value: v.abs().clamp(0.0, 1.0).toDouble(),
                                  minHeight: 5,
                                  color: color,
                                  backgroundColor: tint(color, 0.2),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

// ───────── الوضع العمودي (ويبتون) ─────────

class VerticalReader extends StatefulWidget {
  const VerticalReader({
    super.key,
    required this.pages,
    required this.low,
    required this.widthPx,
    required this.ratios,
    required this.initialPage,
    required this.onPage,
    required this.onTap,
    required this.onUserScroll,
    required this.footer,
    this.onEdge,
    this.onAutoChanged,
    this.canNext = true,
    this.canPrev = true,
    this.nextPages,
    this.divider,
    this.onEnterNext,
  });

  final List<PageSrc> pages;
  final bool low;
  final double widthPx;
  final Map<String, double> ratios;
  final int initialPage;
  final ValueChanged<int> onPage;
  final VoidCallback onTap;
  final VoidCallback onUserScroll;
  final Widget footer;

  /// القراءة المتصلة: صفحات الفصل التالي تُلحق بعد [divider] في نفس القائمة.
  /// حين تصل القراءة إلى أول صفحة منها يُستدعى [onEnterNext]؛ فإن مرّر الأب
  /// الفصل التالي كـ [pages] الجديدة (والفصل الذي يليه كـ [nextPages]) يتحوّل
  /// القارئ بلا أي قفزة في موضع التمرير.
  final List<PageSrc>? nextPages;
  final Widget? divider;
  final VoidCallback? onEnterNext;

  /// +1 = الفصل التالي، -1 = السابق (عند السحب الزائد عند الحافة)
  final ValueChanged<int>? onEdge;

  /// يُستدعى بـ false عند توقّف التمرير التلقائي (لمس المستخدم أو نهاية الفصل)
  final ValueChanged<bool>? onAutoChanged;
  final bool canNext;
  final bool canPrev;

  @override
  State<VerticalReader> createState() => VerticalReaderState();
}

class VerticalReaderState extends State<VerticalReader> implements PageJumper {
  final ScrollController _scroll = ScrollController();
  late List<GlobalKey> _keys;
  List<GlobalKey> _nextKeys = const <GlobalKey>[];
  bool _enterFired = false;
  late int _page;
  Timer? _autoTimer;

  static List<GlobalKey> _gen(int n) => List<GlobalKey>.generate(n, (_) => GlobalKey());

  bool get autoRunning => _autoTimer != null;

  /// تمرير تلقائي بسرعة [pxPerSec] بكسل في الثانية
  void startAuto(double pxPerSec) {
    _autoTimer?.cancel();
    _autoTimer = Timer.periodic(const Duration(milliseconds: 16), (_) {
      if (!_scroll.hasClients) return;
      final pos = _scroll.position;
      if (pos.extentAfter <= 0.5) {
        stopAuto(notify: true);
        return;
      }
      _scroll.jumpTo(math.min(pos.pixels + pxPerSec * 0.016, pos.maxScrollExtent));
    });
  }

  void stopAuto({bool notify = false}) {
    final was = _autoTimer != null;
    _autoTimer?.cancel();
    _autoTimer = null;
    if (was && notify) widget.onAutoChanged?.call(false);
  }

  @override
  void initState() {
    super.initState();
    _keys = _gen(widget.pages.length);
    _nextKeys = _gen(widget.nextPages?.length ?? 0);
    _page = widget.initialPage;
    _scroll.addListener(_onScroll);
    if (_page > 1) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) jumpToPage(_page);
      });
    }
  }

  @override
  void dispose() {
    _autoTimer?.cancel();
    _scroll.dispose();
    super.dispose();
  }

  /// بُعد بداية العنصر عن بداية المحتوى (بكسل)، أو null إن لم يُبنَ بعد
  double? _offsetOf(GlobalKey k) {
    final ctx = k.currentContext;
    if (ctx == null) return null;
    final ro = ctx.findRenderObject();
    if (ro == null || !ro.attached) return null;
    final vp = RenderAbstractViewport.maybeOf(ro);
    if (vp == null) return null;
    return vp.getOffsetToReveal(ro, 0.0).offset;
  }

  @override
  void didUpdateWidget(covariant VerticalReader old) {
    super.didUpdateWidget(old);
    final np = widget.nextPages;
    if (!identical(old.pages, widget.pages)) {
      // تحويل سلس: الفصل التالي صار هو الحالي. نقيس قبل أن تتغير الشجرة
      // (التخطيط الأخير ما زال قائماً) ثم نعدّل موضع التمرير بنفس القيمة
      // فلا يتحرك شيء على الشاشة.
      double? shift;
      final onp = old.nextPages;
      if (onp != null && identical(onp, widget.pages) && _nextKeys.isNotEmpty) {
        shift = _offsetOf(_nextKeys.first);
      }
      _keys = _gen(widget.pages.length);
      _nextKeys = _gen(np?.length ?? 0);
      _enterFired = false;
      _page = 1;
      if (shift != null && _scroll.hasClients) {
        _scroll.position.correctBy(-shift);
      }
    } else if (!identical(old.nextPages, np)) {
      _nextKeys = _gen(np?.length ?? 0);
      _enterFired = false;
    }
  }

  @override
  void jumpToPage(int page) {
    if (!_scroll.hasClients || widget.pages.isEmpty) return;
    final i = (page - 1).clamp(0, widget.pages.length - 1).toInt();
    final width = MediaQuery.of(context).size.width;
    var off = 0.0;
    for (var k = 0; k < i; k++) {
      final src = widget.pages[k];
      final r = widget.ratios[src.url] ?? (src.isMock ? kMockPageRatio : 0.7);
      off += width / r;
    }
    _scroll.jumpTo(off.clamp(0.0, _scroll.position.maxScrollExtent).toDouble());
    _refine(i, 0);
  }

  /// بعد القفزة التقريبية نضبط الموضع بدقة على الصفحة الفعلية
  void _refine(int i, int tries) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final ctx = _keys[i].currentContext;
      if (ctx != null) {
        Scrollable.ensureVisible(ctx, alignment: 0, duration: Duration.zero);
      } else if (tries < 3 && _scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
        _refine(i, tries + 1);
      }
    });
  }

  /// هل منتصف الشاشة داخل هذا العنصر؟
  bool _hasMid(GlobalKey k, double mid) {
    final c = k.currentContext;
    if (c == null) return false;
    final ro = c.findRenderObject();
    if (ro is! RenderBox || !ro.attached || !ro.hasSize) return false;
    final top = ro.localToGlobal(Offset.zero).dy;
    return top <= mid && top + ro.size.height > mid;
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final mid = MediaQuery.of(context).size.height / 2;
    int? found;
    for (var i = 0; i < _keys.length; i++) {
      if (_hasMid(_keys[i], mid)) {
        found = i + 1;
        break;
      }
    }
    // دخلت القراءة صفحات الفصل التالي: نُبلغ الأب ليحوّل الفصل الحالي
    if (found == null && !_enterFired && widget.onEnterNext != null) {
      for (var i = 0; i < _nextKeys.length; i++) {
        if (_hasMid(_nextKeys[i], mid)) {
          _enterFired = true;
          widget.onEnterNext!();
          return;
        }
      }
    }
    if (found == null && _nextKeys.isEmpty && _scroll.position.extentAfter < 40) {
      found = widget.pages.length;
    }
    if (found != null && found != _page) {
      _page = found;
      widget.onPage(found);
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = NotificationListener<UserScrollNotification>(
      onNotification: (n) {
        if (n.direction != ScrollDirection.idle) {
          widget.onUserScroll();
          stopAuto(notify: true); // لمس المستخدم يوقف التمرير التلقائي
        }
        return false;
      },
      child: ZoomBox(
        onTap: (pos, size) => widget.onTap(),
        builder: (context, zoomed) => ListView.builder(
          controller: _scroll,
          physics: zoomed
              ? const NeverScrollableScrollPhysics()
              : const ClampingScrollPhysics(),
          padding: EdgeInsets.zero,
          // تحميل مسبق: ما يقارب شاشتين ونصف أسفل الصفحة الحالية (البند 13)
          cacheExtent: 2600,
          itemCount: widget.pages.length +
              ((widget.nextPages?.isNotEmpty ?? false) ? widget.nextPages!.length + 1 : 0) +
              1,
          itemBuilder: (context, i) {
            final n = widget.pages.length;
            if (i < n) {
              return KeyedSubtree(
                key: _keys[i],
                child: ReaderPageImage(
                  src: widget.pages[i],
                  low: widget.low,
                  widthPx: widget.widthPx,
                  ratios: widget.ratios,
                ),
              );
            }
            final np = widget.nextPages;
            if (np != null && np.isNotEmpty) {
              if (i == n) return widget.divider ?? const SizedBox.shrink();
              if (i <= n + np.length) {
                final j = i - n - 1;
                return KeyedSubtree(
                  key: j < _nextKeys.length ? _nextKeys[j] : null,
                  child: ReaderPageImage(
                    src: np[j],
                    low: widget.low,
                    widthPx: widget.widthPx,
                    ratios: widget.ratios,
                  ),
                );
              }
            }
            return widget.footer;
          },
        ),
      ),
    );
    final onEdge = widget.onEdge;
    if (onEdge == null) return list;
    return EdgeSwipe(
      axis: Axis.vertical,
      onEdge: onEdge,
      canNext: widget.canNext,
      canPrev: widget.canPrev,
      child: list,
    );
  }
}

// ───────── وضع صفحة بصفحة ─────────

class PagedReader extends StatefulWidget {
  const PagedReader({
    super.key,
    required this.pages,
    required this.low,
    required this.widthPx,
    required this.ratios,
    required this.initialPage,
    required this.ltr,
    required this.onPage,
    required this.onTap,
    required this.footer,
    this.onEdge,
    this.canNext = true,
    this.canPrev = true,
  });

  final List<PageSrc> pages;
  final bool low;
  final double widthPx;
  final Map<String, double> ratios;
  final int initialPage;

  /// false = يمين←يسار (مانغا) وهو الافتراضي في واجهة عربية
  final bool ltr;
  final ValueChanged<int> onPage;
  final VoidCallback onTap;
  final Widget footer;

  /// +1 = الفصل التالي، -1 = السابق (السحب بعد آخر صفحة أو قبل أولها)
  final ValueChanged<int>? onEdge;
  final bool canNext;
  final bool canPrev;

  @override
  State<PagedReader> createState() => PagedReaderState();
}

class PagedReaderState extends State<PagedReader> implements PageJumper {
  late final PageController _pc;
  bool _locked = false;

  @override
  void initState() {
    super.initState();
    _pc = PageController(
      initialPage: (widget.initialPage - 1).clamp(0, widget.pages.length).toInt(),
    );
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  void jumpToPage(int page) {
    if (!_pc.hasClients || widget.pages.isEmpty) return;
    _pc.jumpToPage((page - 1).clamp(0, widget.pages.length - 1).toInt());
  }

  void _next() => _pc.nextPage(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
      );

  void _prev() => _pc.previousPage(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
      );

  /// أطراف الشاشة تقلّب الصفحة، والوسط يُظهر/يُخفي الأشرطة
  void _tap(Offset pos, Size size) {
    final x = pos.dx / size.width;
    if (x < 0.3) {
      widget.ltr ? _prev() : _next();
    } else if (x > 0.7) {
      widget.ltr ? _next() : _prev();
    } else {
      widget.onTap();
    }
  }

  @override
  Widget build(BuildContext context) {
    final view = PageView.builder(
      controller: _pc,
      reverse: widget.ltr,
      physics: _locked
          ? const NeverScrollableScrollPhysics()
          : const PageScrollPhysics(),
      itemCount: widget.pages.length + 1,
      onPageChanged: (i) {
        if (_locked) setState(() => _locked = false);
        widget.onPage(math.min(i + 1, widget.pages.length));
      },
      itemBuilder: (context, i) {
        if (i == widget.pages.length) return widget.footer;
        return ZoomBox(
          onTap: _tap,
          onZoomChanged: (z) => setState(() => _locked = z),
          builder: (context, zoomed) => ReaderPageImage(
            src: widget.pages[i],
            low: widget.low,
            widthPx: widget.widthPx,
            ratios: widget.ratios,
            paged: true,
          ),
        );
      },
    );
    final onEdge = widget.onEdge;
    if (onEdge == null) return view;
    return EdgeSwipe(
      axis: Axis.horizontal,
      threshold: 90,
      onEdge: onEdge,
      canNext: widget.canNext,
      canPrev: widget.canPrev,
      child: view,
    );
  }
}
