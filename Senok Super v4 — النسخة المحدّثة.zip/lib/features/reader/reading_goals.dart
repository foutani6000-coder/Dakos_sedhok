// ──────────────────────────────────────────────────────────────────────────
//  أهداف القراءة v2 (أهداف القارئ) — أهداف يومية/أسبوعية/شهرية/سنوية
//  تُقاس من بيانات القراءة المحلية (SettingsController + سجلّ v2).
//  المفاتيح: rv2_goals_v1 — مختلفة عن أهداف الحساب (sard_reading_goals_v2).
// ──────────────────────────────────────────────────────────────────────────
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'reader_progress.dart';

/// مفتاح تخزين أهداف القارئ v2.
const String kRv2GoalsKey = 'rv2_goals_v1';

// ───────── أنواع الأهداف ─────────

/// نوع الهدف — يحدّد وحدة القياس وفترة التصفير.
enum ReadingGoalKind {
  /// فصول في اليوم.
  dailyChapters('فصول يومياً', 'فصل'),

  /// دقائق قراءة في اليوم.
  dailyMinutes('دقائق يومياً', 'دقيقة'),

  /// فصول في الأسبوع.
  weeklyChapters('فصول أسبوعياً', 'فصل'),

  /// فصول في الشهر.
  monthlyChapters('فصول شهرياً', 'فصل'),

  /// أعمال تُكملها في السنة.
  yearlySeries('أعمال سنوياً', 'عمل'),

  /// أيام قراءة متتالية (سلسلة).
  streakDays('أيام متتالية', 'يوم');

  const ReadingGoalKind(this.label, this.unit);
  final String label;
  final String unit;

  /// هل الهدف يومي (يُصفَّر كل يوم)؟
  bool get isDaily => this == ReadingGoalKind.dailyChapters || this == ReadingGoalKind.dailyMinutes;

  /// هل الهدف أسبوعي؟
  bool get isWeekly => this == ReadingGoalKind.weeklyChapters;

  /// هل الهدف شهري؟
  bool get isMonthly => this == ReadingGoalKind.monthlyChapters;

  /// هل الهدف سنوي؟
  bool get isYearly => this == ReadingGoalKind.yearlySeries;

  static ReadingGoalKind fromKey(String? key) {
    for (final k in ReadingGoalKind.values) {
      if (k.name == key) return k;
    }
    return ReadingGoalKind.dailyChapters;
  }
}

// ───────── نموذج الهدف ─────────

/// هدف قراءة واحد.
@immutable
class ReadingGoal {
  const ReadingGoal({
    required this.id,
    required this.kind,
    required this.target,
    required this.createdAt,
    this.archived = false,
    this.colorValue,
  });

  final String id;
  final ReadingGoalKind kind;

  /// الهدف العددي (فصول/دقائق/أعمال/أيام).
  final int target;
  final DateTime createdAt;

  /// مؤرشف (لا يُحتسب في التقدم الحالي).
  final bool archived;

  /// لون مخصص (قيمة Color) — null = لون التمييز.
  final int? colorValue;

  Color get color => colorValue == null ? const Color(0xFFE63E2A) : Color(colorValue!);

  /// عنوان افتراضي عربي: «5 فصول يومياً»
  String get defaultTitle => '$target ${kind.unit} ${kind.label.split(' ').last}';

  /// عنوان كامل: «هدف يومي: 5 فصول»
  String get fullTitle {
    final period = kind.isDaily
        ? 'يومي'
        : kind.isWeekly
            ? 'أسبوعي'
            : kind.isMonthly
                ? 'شهري'
                : kind.isYearly
                    ? 'سنوي'
                    : 'مستمر';
    return 'هدف $period: $target ${kind.unit}';
  }

  ReadingGoal copyWith({
    ReadingGoalKind? kind,
    int? target,
    bool? archived,
    int? colorValue,
  }) {
    return ReadingGoal(
      id: id,
      kind: kind ?? this.kind,
      target: target ?? this.target,
      createdAt: createdAt,
      archived: archived ?? this.archived,
      colorValue: colorValue ?? this.colorValue,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'target': target,
        'created_at': createdAt.millisecondsSinceEpoch,
        'archived': archived,
        'color': colorValue,
      };

  factory ReadingGoal.fromJson(Map<String, dynamic> j) {
    DateTime at(dynamic v) {
      if (v is num) return DateTime.fromMillisecondsSinceEpoch(v.toInt());
      return DateTime.tryParse('$v') ?? DateTime.now();
    }

    return ReadingGoal(
      id: '${j['id'] ?? ''}',
      kind: ReadingGoalKind.fromKey(j['kind'] as String?),
      target: (j['target'] as num?)?.toInt() ?? 1,
      createdAt: at(j['created_at']),
      archived: j['archived'] == true,
      colorValue: (j['color'] as num?)?.toInt(),
    );
  }

  /// تقدّم الهدف الحالي من بيانات القراءة.
  /// [settings] للإحصاءات العامة، و[progress] لسجلّ v2، و[now] لليوم المرجعي.
  GoalProgress progress({
    required SettingsController settings,
    ReaderProgressStore? progress,
    DateTime? now,
  }) {
    final n = now ?? DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    var current = 0;
    switch (kind) {
      case ReadingGoalKind.dailyChapters:
        current = _chaptersOn(settings, progress, today);
        break;
      case ReadingGoalKind.dailyMinutes:
        current = _minutesOn(settings, progress, today);
        break;
      case ReadingGoalKind.weeklyChapters:
        current = _chaptersInWeek(settings, progress, today);
        break;
      case ReadingGoalKind.monthlyChapters:
        current = _chaptersInMonth(settings, progress, today);
        break;
      case ReadingGoalKind.yearlySeries:
        current = _seriesFinishedThisYear(settings, n.year);
        break;
      case ReadingGoalKind.streakDays:
        current = settings.streak;
        break;
    }
    final fraction = target <= 0 ? 0.0 : (current / target).clamp(0.0, 1.0).toDouble();
    return GoalProgress(
      goal: this,
      current: current,
      target: target,
      fraction: fraction,
      done: current >= target,
    );
  }

  /// فصول مقروءة في يوم (من read_chapters + سجلّ v2).
  static int _chaptersOn(SettingsController settings, ReaderProgressStore? progress, DateTime day) {
    var n = 0;
    // من سجلّ v2: فصول مكتملة في ذلك اليوم
    if (progress != null) {
      final seen = <String>{};
      for (final r in progress.recordsOn(day)) {
        if (r.completed) seen.add('${r.seriesId}:${r.chapter}');
      }
      n += seen.length;
    }
    // من SettingsController: فصول اليوم الحالي فقط (لا تاريخ تفصيلي محفوظ)
    final today = DateTime.now();
    final isToday = day.year == today.year && day.month == today.month && day.day == today.day;
    if (isToday) {
      // عدد فصول اليوم = day_count المحفوظ (فصول اليوم)
      n = math.max(n, _dayChaptersToday(settings));
    }
    return n;
  }

  static int _dayChaptersToday(SettingsController settings) {
    // SettingsController يحفظ best_day_chapters وday_count داخلياً دون getter عام؛
    // نستنتج فصول اليوم من إجمالي الفصول المقروءة اليوم عبر read_days:
    // إن قرأ اليوم فعلى الأقل فصل واحد — الأفضل: الاعتماد على سجلّ v2.
    // هنا نعيد 0 ونترك سجلّ v2 مصدراً دقيقاً؛ تبقى الدالة للتوافق.
    return 0;
  }

  static int _minutesOn(SettingsController settings, ReaderProgressStore? progress, DateTime day) {
    if (progress != null) {
      return progress.recordsOn(day).fold<int>(0, (a, r) => a + r.seconds) ~/ 60;
    }
    final today = DateTime.now();
    final isToday = day.year == today.year && day.month == today.month && day.day == today.day;
    if (!isToday) return 0;
    return settings.totalReadingSeconds ~/ 60;
  }

  static int _chaptersInWeek(SettingsController settings, ReaderProgressStore? progress, DateTime today) {
    var n = 0;
    final seen = <String>{};
    final start = today.subtract(Duration(days: today.weekday - 1));
    for (var i = 0; i < 7; i++) {
      final day = start.add(Duration(days: i));
      if (progress != null) {
        for (final r in progress.recordsOn(day)) {
          if (r.completed) seen.add('${r.seriesId}:${r.chapter}');
        }
      }
    }
    n = seen.length;
    return n;
  }

  static int _chaptersInMonth(SettingsController settings, ReaderProgressStore? progress, DateTime today) {
    var n = 0;
    final seen = <String>{};
    final daysInMonth = DateTime(today.year, today.month + 1, 0).day;
    for (var d = 1; d <= today.day && d <= daysInMonth; d++) {
      final day = DateTime(today.year, today.month, d);
      if (progress != null) {
        for (final r in progress.recordsOn(day)) {
          if (r.completed) seen.add('${r.seriesId}:${r.chapter}');
        }
      }
    }
    n = seen.length;
    return n;
  }

  static int _seriesFinishedThisYear(SettingsController settings, int year) {
    // عدد الأعمال التي لها تقدّم مكتمل: تقدير من عدد الأعمال المقروءة
    // (لا توجد إشارة «مكتمل العمل» صريحة في البيانات القديمة).
    // نستخدم عدد الأعمال ذات الفصول المقروءة كتقدير محافظ.
    return settings.topReadIds.length;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is ReadingGoal && id == other.id;

  @override
  int get hashCode => id.hashCode;
}

/// تقدّم هدف في لحظة معيّنة.
@immutable
class GoalProgress {
  const GoalProgress({
    required this.goal,
    required this.current,
    required this.target,
    required this.fraction,
    required this.done,
  });

  final ReadingGoal goal;
  final int current;
  final int target;
  final double fraction;
  final bool done;

  /// «3 من 5 فصول»
  String get label => '$current من $target ${goal.kind.unit}';

  /// نسبة مئوية نصاً: «60٪»
  String get percentLabel => '${(fraction * 100).round()}٪';

  /// المتبقي لإكمال الهدف.
  int get remaining => (target - current).clamp(0, 1 << 20).toInt();

  String get remainingLabel {
    if (done) return 'اكتمل الهدف — أحسنت!';
    if (remaining == 1) return 'تبقّى ${goal.kind.unit} واحد';
    if (remaining == 2) return 'تبقّى ${goal.kind.unit}ان';
    if (remaining <= 10) return 'تبقّى $remaining ${goal.kind.unit}';
    return 'تبقّى $remaining ${goal.kind.unit}';
  }
}

// ───────── مخزن الأهداف ─────────

/// مخزن أهداف القارئ v2 (مفردة عبر [ReadingGoalsStore.i]).
class ReadingGoalsStore extends ChangeNotifier {
  ReadingGoalsStore._(this._p) {
    _goals = _loadAll();
  }

  static ReadingGoalsStore? _instance;

  static ReadingGoalsStore get i {
    final inst = _instance;
    if (inst == null) throw StateError('ReadingGoalsStore لم يُحمَّل بعد — نادِ load() أولاً.');
    return inst;
  }

  static Future<ReadingGoalsStore> load() async {
    final p = await SharedPreferences.getInstance();
    return _instance ??= ReadingGoalsStore._(p);
  }

  static ReadingGoalsStore testInstance() => ReadingGoalsStore._(_Rv2GoalsFakePrefs());

  final SharedPreferences _p;
  late List<ReadingGoal> _goals;

  List<ReadingGoal> _loadAll() {
    try {
      final raw = _p.getString(kRv2GoalsKey);
      if (raw == null || raw.isEmpty) return <ReadingGoal>[];
      final list = jsonDecode(raw) as List;
      final out = <ReadingGoal>[];
      for (final e in list) {
        if (e is! Map) continue;
        try {
          out.add(ReadingGoal.fromJson(Map<String, dynamic>.from(e)));
        } catch (_) {}
      }
      out.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      return out;
    } catch (_) {
      return <ReadingGoal>[];
    }
  }

  Future<void> _save() async {
    await _p.setString(
      kRv2GoalsKey,
      jsonEncode(_goals.map((g) => g.toJson()).toList()),
    );
  }

  /// كل الأهداف (غير المؤرشفة أولاً ثم المؤرشفة).
  List<ReadingGoal> get goals => List<ReadingGoal>.unmodifiable(_goals);

  /// الأهداف النشطة فقط.
  List<ReadingGoal> get activeGoals => _goals.where((g) => !g.archived).toList();

  /// الأهداف المؤرشفة.
  List<ReadingGoal> get archivedGoals => _goals.where((g) => g.archived).toList();

  int get count => _goals.length;

  ReadingGoal? byId(String id) {
    for (final g in _goals) {
      if (g.id == id) return g;
    }
    return null;
  }

  /// يضيف هدفاً جديداً ويعيده.
  Future<ReadingGoal> add({required ReadingGoalKind kind, required int target, int? colorValue}) async {
    final g = ReadingGoal(
      id: 'goal_${DateTime.now().millisecondsSinceEpoch}_${math.Random().nextInt(9999)}',
      kind: kind,
      target: target.clamp(1, 10000).toInt(),
      createdAt: DateTime.now(),
      colorValue: colorValue,
    );
    _goals.add(g);
    await _save();
    notifyListeners();
    return g;
  }

  /// يحدّث هدفاً (النوع/الهدف/اللون).
  Future<void> update(String id, {ReadingGoalKind? kind, int? target, int? colorValue}) async {
    final i = _goals.indexWhere((g) => g.id == id);
    if (i < 0) return;
    _goals[i] = _goals[i].copyWith(
      kind: kind,
      target: target == null ? null : target.clamp(1, 10000).toInt(),
      colorValue: colorValue,
    );
    await _save();
    notifyListeners();
  }

  /// يؤرشف هدفاً (يُخفى من القائمة النشطة دون حذف).
  Future<void> archive(String id, {bool archived = true}) async {
    final i = _goals.indexWhere((g) => g.id == id);
    if (i < 0) return;
    _goals[i] = _goals[i].copyWith(archived: archived);
    await _save();
    notifyListeners();
  }

  /// يحذف هدفاً نهائياً.
  Future<void> remove(String id) async {
    _goals.removeWhere((g) => g.id == id);
    await _save();
    notifyListeners();
  }

  /// تقدّم كل الأهداف النشطة دفعة واحدة.
  List<GoalProgress> progressAll({
    required SettingsController settings,
    ReaderProgressStore? progress,
    DateTime? now,
  }) {
    return activeGoals
        .map((g) => g.progress(settings: settings, progress: progress, now: now))
        .toList();
  }

  /// عدد الأهداف المكتملة اليوم (من الأهداف النشطة).
  int doneCount({
    required SettingsController settings,
    ReaderProgressStore? progress,
    DateTime? now,
  }) {
    return progressAll(settings: settings, progress: progress, now: now)
        .where((p) => p.done)
        .length;
  }

  /// تصدير JSON نصاً.
  String exportJson() => jsonEncode(_goals.map((g) => g.toJson()).toList());

  /// استيراد من JSON — يعيد عدد المستوردة.
  Future<int> importJson(String raw) async {
    try {
      final list = jsonDecode(raw) as List;
      var added = 0;
      for (final e in list) {
        if (e is! Map) continue;
        try {
          final g = ReadingGoal.fromJson(Map<String, dynamic>.from(e));
          if (g.id.isEmpty) continue;
          if (_goals.any((x) => x.id == g.id)) continue;
          _goals.add(g);
          added++;
        } catch (_) {}
      }
      await _save();
      notifyListeners();
      return added;
    } catch (_) {
      return 0;
    }
  }
}

/// بديل خفيف لـ SharedPreferences في الاختبارات (ذاكرة فقط).
class _Rv2GoalsFakePrefs implements SharedPreferences {
  final Map<String, Object> _m = {};

  @override
  Set<String> getKeys() => _m.keys.toSet();
  @override
  Object? get(String key) => _m[key];
  @override
  bool? getBool(String key) => _m[key] as bool?;
  @override
  double? getDouble(String key) => _m[key] as double?;
  @override
  int? getInt(String key) => _m[key] as int?;
  @override
  String? getString(String key) => _m[key] as String?;
  @override
  List<String>? getStringList(String key) => _m[key] as List<String>?;
  @override
  bool containsKey(String key) => _m.containsKey(key);
  @override
  Future<bool> setBool(String key, bool value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setDouble(String key, double value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setInt(String key, int value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setString(String key, String value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> remove(String key) async {
    _m.remove(key);
    return true;
  }

  @override
  Future<bool> clear() async {
    _m.clear();
    return true;
  }

  @override
  Future<bool> commit() async => true;
  @override
  Future<void> reload() async {}
}

// ───────── ويدجتات الأهداف ─────────

/// شريط تقدم هدف مع نسبة مئوية.
class GoalProgressBar extends StatelessWidget {
  const GoalProgressBar({
    super.key,
    required this.progress,
    this.height = 8,
  });

  final GoalProgress progress;
  final double height;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final color = progress.done ? const Color(0xFF0F9D75) : progress.goal.color;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                progress.label,
                style: context.ts(size: 12.5, w: FontWeight.w700, color: p.text),
              ),
            ),
            Text(
              progress.percentLabel,
              style: context.ts(size: 12.5, w: FontWeight.w800, color: color),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(height / 2),
          child: LinearProgressIndicator(
            value: progress.fraction,
            minHeight: height,
            backgroundColor: p.border,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          progress.remainingLabel,
          style: context.ts(size: 11.5, color: progress.done ? const Color(0xFF0F9D75) : p.textDim),
        ),
      ],
    );
  }
}

/// بطاقة هدف واحد مع أزرار الأرشفة والحذف.
class GoalCard extends StatelessWidget {
  const GoalCard({
    super.key,
    required this.progress,
    this.onArchive,
    this.onDelete,
    this.onTap,
  });

  final GoalProgress progress;
  final VoidCallback? onArchive;
  final VoidCallback? onDelete;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final g = progress.goal;
    final icon = switch (g.kind) {
      ReadingGoalKind.dailyChapters => SardIcons.menu_book_rounded,
      ReadingGoalKind.dailyMinutes => SardIcons.history_rounded,
      ReadingGoalKind.weeklyChapters => SardIcons.calendar_today_rounded,
      ReadingGoalKind.monthlyChapters => SardIcons.calendar_today_rounded,
      ReadingGoalKind.yearlySeries => SardIcons.star_rounded,
      ReadingGoalKind.streakDays => SardIcons.local_fire_department_rounded,
    };
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(p.r(1)),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(1)),
            border: Border.all(
              color: progress.done ? tint(const Color(0xFF0F9D75), 0.5) : p.border,
            ),
            boxShadow: softShadow(p, strength: 0.6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: tint(g.color, 0.14),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: Center(child: SIcon(icon, size: 19, color: g.color)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(g.fullTitle, style: context.ds(size: 15)),
                        Text(
                          'أُنشئ ${formatRv2Date(g.createdAt)}',
                          style: context.ts(size: 11.5, color: p.textDim),
                        ),
                      ],
                    ),
                  ),
                  if (progress.done)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: tint(const Color(0xFF0F9D75), 0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SIcon(SardIcons.check_rounded, size: 13, color: const Color(0xFF0F9D75)),
                          const SizedBox(width: 3),
                          Text('مكتمل', style: context.ts(size: 11, w: FontWeight.w800, color: const Color(0xFF0F9D75))),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              GoalProgressBar(progress: progress),
              if (onArchive != null || onDelete != null) ...[
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (onArchive != null)
                      TextButton(
                        onPressed: onArchive,
                        child: Text(g.archived ? 'إلغاء الأرشفة' : 'أرشفة'),
                      ),
                    if (onDelete != null)
                      TextButton(
                        onPressed: onDelete,
                        child: const Text('حذف'),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// نافذة إنشاء هدف جديد.
/// تعيد (النوع، الهدف العددي، اللون) أو null عند الإلغاء.
Future<(ReadingGoalKind, int, int?)?> showCreateGoalSheet(BuildContext context) {
  var kind = ReadingGoalKind.dailyChapters;
  var target = 3;
  Color? color;
  const palette = [
    Color(0xFFE63E2A),
    Color(0xFFF5A524),
    Color(0xFF0F9D75),
    Color(0xFF3B9EFF),
    Color(0xFFB44CFF),
    Color(0xFFE0457B),
  ];
  return showModalBottomSheet<(ReadingGoalKind, int, int?)?>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      final p = ctx.pal;
      return StatefulBuilder(
        builder: (ctx, setState) {
          return Container(
            padding: EdgeInsets.fromLTRB(
              20,
              12,
              20,
              28 + MediaQuery.of(ctx).viewInsets.bottom,
            ),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 4,
                    decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4)),
                  ),
                ),
                const SizedBox(height: 16),
                Text('هدف قراءة جديد', style: ctx.ds(size: 19)),
                const SizedBox(height: 14),
                Text('نوع الهدف', style: ctx.ts(size: 13, w: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: ReadingGoalKind.values.map((k) {
                    final sel = k == kind;
                    return ChoiceChip(
                      label: Text(k.label),
                      selected: sel,
                      onSelected: (_) => setState(() {
                        kind = k;
                        // قيم افتراضية معقولة لكل نوع
                        target = switch (k) {
                          ReadingGoalKind.dailyChapters => 3,
                          ReadingGoalKind.dailyMinutes => 30,
                          ReadingGoalKind.weeklyChapters => 10,
                          ReadingGoalKind.monthlyChapters => 30,
                          ReadingGoalKind.yearlySeries => 12,
                          ReadingGoalKind.streakDays => 7,
                        };
                      }),
                      selectedColor: tint(p.accent, 0.2),
                      labelStyle: ctx.ts(size: 12.5, w: sel ? FontWeight.w800 : FontWeight.w500),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Text('الهدف: $target ${kind.unit}', style: ctx.ts(size: 14, w: FontWeight.w700)),
                    ),
                    IconButton(
                      onPressed: () => setState(() => target = (target - 1).clamp(1, 10000).toInt()),
                      icon: SIcon(SardIcons.chevron_right_rounded, size: 22, color: p.text),
                    ),
                    IconButton(
                      onPressed: () => setState(() => target = (target + 1).clamp(1, 10000).toInt()),
                      icon: SIcon(SardIcons.chevron_left_rounded, size: 22, color: p.text),
                    ),
                  ],
                ),
                Slider(
                  value: target.clamp(1, 100).toDouble(),
                  min: 1,
                  max: 100,
                  divisions: 99,
                  activeColor: p.accent,
                  onChanged: (v) => setState(() => target = v.round().clamp(1, 10000).toInt()),
                ),
                const SizedBox(height: 8),
                Text('اللون', style: ctx.ts(size: 13, w: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: palette.map((c) {
                    final sel = color?.toARGB32() == c.toARGB32();
                    return Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () => setState(() => color = sel ? null : c),
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: c,
                            shape: BoxShape.circle,
                            border: Border.all(color: sel ? p.text : Colors.transparent, width: 2),
                          ),
                          child: sel
                              ? const Center(child: Icon(Icons.check, size: 16, color: Colors.white))
                              : null,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => Navigator.of(ctx).pop((kind, target, color?.toARGB32())),
                    child: const Text('إنشاء الهدف'),
                  ),
                ),
              ],
            ),
          );
        },
      );
    },
  );
}

// ───────── شاشة أهداف القراءة ─────────

/// شاشة أهداف القراءة v2: الأهداف النشطة مع تقدّمها، والمؤرشفة.
class ReadingGoalsScreen extends StatefulWidget {
  const ReadingGoalsScreen({super.key, required this.settings, this.progress});

  final SettingsController settings;
  final ReaderProgressStore? progress;

  @override
  State<ReadingGoalsScreen> createState() => _ReadingGoalsScreenState();
}

class _ReadingGoalsScreenState extends State<ReadingGoalsScreen> {
  late ReadingGoalsStore store;
  bool _showArchived = false;

  @override
  void initState() {
    super.initState();
    store = ReadingGoalsStore.i;
  }

  Future<void> _create() async {
    final res = await showCreateGoalSheet(context);
    if (res == null) return;
    await store.add(kind: res.$1, target: res.$2, colorValue: res.$3);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('أهداف القراءة'),
        actions: [
          IconButton(
            onPressed: _create,
            tooltip: 'هدف جديد',
            icon: SIcon(SardIcons.edit_rounded, size: 20, color: p.text),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          final progresses = store.progressAll(
            settings: widget.settings,
            progress: widget.progress,
          );
          final done = progresses.where((x) => x.done).length;
          final goals = _showArchived ? store.archivedGoals : store.activeGoals;
          final shown = _showArchived
              ? goals
                  .map((g) => g.progress(settings: widget.settings, progress: widget.progress))
                  .toList()
              : progresses;
          return Column(
            children: [
              if (progresses.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: p.surface,
                      borderRadius: BorderRadius.circular(p.r(1)),
                      border: Border.all(color: p.border),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: tint(p.gold, 0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(
                            child: SIcon(SardIcons.star_rounded, size: 22, color: p.gold),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'أكملت $done من ${progresses.length} أهداف',
                                style: context.ds(size: 15.5),
                              ),
                              Text(
                                done == progresses.length && progresses.isNotEmpty
                                    ? 'كل الأهداف مكتملة اليوم — يوم رائع!'
                                    : 'تابع القراءة لإكمال بقية الأهداف.',
                                style: context.ts(size: 12.5, color: p.textDim),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: Row(
                  children: [
                    ChoiceChip(
                      label: const Text('النشطة'),
                      selected: !_showArchived,
                      onSelected: (_) => setState(() => _showArchived = false),
                    ),
                    const SizedBox(width: 8),
                    ChoiceChip(
                      label: Text('المؤرشفة (${store.archivedGoals.length})'),
                      selected: _showArchived,
                      onSelected: (_) => setState(() => _showArchived = true),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: _create,
                      child: const Text('هدف جديد +'),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: shown.isEmpty
                    ? _EmptyGoals(onCreate: _create)
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: shown.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, i) {
                          final pr = shown[i];
                          return GoalCard(
                            progress: pr,
                            onArchive: () async {
                              await store.archive(pr.goal.id, archived: !pr.goal.archived);
                              setState(() {});
                            },
                            onDelete: () async {
                              final ok = await showDialog<bool>(
                                context: context,
                                builder: (ctx) => AlertDialog(
                                  title: const Text('حذف الهدف؟'),
                                  content: Text('سيُحذف هدف «${pr.goal.fullTitle}» نهائياً.'),
                                  actions: [
                                    TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('إلغاء')),
                                    FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('حذف')),
                                  ],
                                ),
                              );
                              if (ok == true) {
                                await store.remove(pr.goal.id);
                                setState(() {});
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: SIcon(SardIcons.edit_rounded, size: 18, color: p.onAccent),
        label: Text('هدف جديد', style: context.ts(size: 13.5, w: FontWeight.w700, color: p.onAccent)),
      ),
    );
  }
}

class _EmptyGoals extends StatelessWidget {
  const _EmptyGoals({required this.onCreate});

  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: tint(p.accent, 0.12),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: SIcon(SardIcons.star_rounded, size: 38, color: p.accent),
              ),
            ),
            const SizedBox(height: 16),
            Text('لا أهداف بعد', style: context.ds(size: 18)),
            const SizedBox(height: 6),
            Text(
              'حدّد هدفاً يومياً أو أسبوعياً — فصول أو دقائق — وتابع تقدّمك هنا. الأهداف تُقاس من قراءتك الفعلية.',
              style: context.ts(size: 13, color: p.textDim),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: onCreate,
              child: const Text('أنشئ أول هدف'),
            ),
          ],
        ),
      ),
    );
  }
}

// ───────── قوالب أهداف جاهزة ─────────

/// قالب هدف جاهز بنقرة واحدة.
@immutable
class GoalTemplate {
  const GoalTemplate({
    required this.kind,
    required this.target,
    required this.title,
    required this.description,
    required this.colorValue,
  });

  final ReadingGoalKind kind;
  final int target;
  final String title;
  final String description;
  final int colorValue;

  Color get color => Color(colorValue);
}

/// قوالب الأهداف المقترحة للمبتدئين.
const List<GoalTemplate> kGoalTemplates = [
  GoalTemplate(
    kind: ReadingGoalKind.dailyChapters,
    target: 1,
    title: 'بداية خفيفة',
    description: 'فصل واحد كل يوم — عادة صغيرة تدوم.',
    colorValue: 0xFF0F9D75,
  ),
  GoalTemplate(
    kind: ReadingGoalKind.dailyChapters,
    target: 3,
    title: 'قارئ منتظم',
    description: 'ثلاثة فصول يومياً — إيقاع متوازن.',
    colorValue: 0xFF3B9EFF,
  ),
  GoalTemplate(
    kind: ReadingGoalKind.dailyMinutes,
    target: 30,
    title: 'نصف ساعة يومياً',
    description: '30 دقيقة قراءة كل يوم.',
    colorValue: 0xFFF5A524,
  ),
  GoalTemplate(
    kind: ReadingGoalKind.weeklyChapters,
    target: 10,
    title: 'أسبوع قوي',
    description: 'عشرة فصول كل أسبوع.',
    colorValue: 0xFFB44CFF,
  ),
  GoalTemplate(
    kind: ReadingGoalKind.monthlyChapters,
    target: 30,
    title: 'تحدي الشهر',
    description: 'ثلاثون فصلاً في الشهر.',
    colorValue: 0xFFE0457B,
  ),
  GoalTemplate(
    kind: ReadingGoalKind.yearlySeries,
    target: 12,
    title: 'عمل كل شهر',
    description: 'أكمل 12 عملاً في السنة.',
    colorValue: 0xFFE63E2A,
  ),
  GoalTemplate(
    kind: ReadingGoalKind.streakDays,
    target: 7,
    title: 'أسبوع متتابع',
    description: 'اقرأ 7 أيام متتالية دون انقطاع.',
    colorValue: 0xFF0F9D75,
  ),
  GoalTemplate(
    kind: ReadingGoalKind.streakDays,
    target: 30,
    title: 'شهر متتابع',
    description: 'اقرأ 30 يوماً متتالية — سلسلة ذهبية.',
    colorValue: 0xFFE9B44C,
  ),
];

/// بطاقة قالب هدف.
class GoalTemplateCard extends StatelessWidget {
  const GoalTemplateCard({super.key, required this.template, this.onSelect});

  final GoalTemplate template;
  final VoidCallback? onSelect;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onSelect,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(0.9)),
            border: Border.all(color: tint(template.color, 0.35)),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: tint(template.color, 0.14),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Center(
                  child: Text(
                    '${template.target}',
                    style: context.ds(size: 15, color: template.color),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(template.title, style: context.ts(size: 13.5, w: FontWeight.w800)),
                    Text(template.description, style: context.ts(size: 11.5, color: p.textDim), maxLines: 2, overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              SIcon(SardIcons.chevron_left_rounded, size: 18, color: p.textDim),
            ],
          ),
        ),
      ),
    );
  }
}

/// ورقة قوالب الأهداف — تختار قالباً فينشأ هدف منه فوراً.
Future<GoalTemplate?> showGoalTemplatesSheet(BuildContext context) {
  final p = context.pal;
  return showModalBottomSheet<GoalTemplate?>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      return Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.8),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Container(width: 44, height: 4, decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4))),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('قوالب جاهزة', style: ctx.ds(size: 18)),
                  const SizedBox(height: 4),
                  Text('اختر قالباً وسينشأ هدفك فوراً — يمكنك تعديله لاحقاً.', style: ctx.ts(size: 12.5, color: p.textDim)),
                ],
              ),
            ),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                itemCount: kGoalTemplates.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (ctx, i) {
                  final t = kGoalTemplates[i];
                  return GoalTemplateCard(
                    template: t,
                    onSelect: () => Navigator.of(ctx).pop(t),
                  );
                },
              ),
            ),
          ],
        ),
      );
    },
  );
}

// ───────── ملخص أسبوعي للأهداف ─────────

/// بطاقة ملخص أسبوع الأهداف: الأهداف المكتملة هذا الأسبوع ونسبة الإنجاز.
class WeeklyGoalsSummary extends StatelessWidget {
  const WeeklyGoalsSummary({
    super.key,
    required this.progresses,
  });

  final List<GoalProgress> progresses;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (progresses.isEmpty) return const SizedBox.shrink();
    final done = progresses.where((x) => x.done).length;
    final avg = progresses.fold<double>(0, (a, x) => a + x.fraction) / progresses.length;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [tint(p.accent, 0.16), tint(p.gold, 0.12)],
        ),
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: tint(p.accent, 0.25)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 56,
            height: 56,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 56,
                  height: 56,
                  child: CircularProgressIndicator(
                    value: avg,
                    strokeWidth: 5,
                    backgroundColor: p.border,
                    valueColor: AlwaysStoppedAnimation<Color>(p.accent),
                  ),
                ),
                Text('${(avg * 100).round()}٪', style: context.ts(size: 12, w: FontWeight.w800)),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('إنجاز أهدافك: $done من ${progresses.length} مكتملة', style: context.ds(size: 14.5)),
                const SizedBox(height: 2),
                Text(
                  avg >= 1
                      ? 'كل الأهداف مكتملة — استمر على هذا الإيقاع!'
                      : avg >= 0.5
                          ? 'أنجزت أكثر من النصف — واصل!'
                          : 'بداية جيدة — كل صفحة تقرّبك من هدفك.',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ───────── ملخص سلسلة الأهداف ─────────

/// بطاقة سلسلة الأهداف: عدد الأيام المتتالية مع أهداف مكتملة.
class GoalStreakCard extends StatelessWidget {
  const GoalStreakCard({
    super.key,
    required this.streakDays,
    required this.doneToday,
    required this.totalGoals,
  });

  final int streakDays;
  final int doneToday;
  final int totalGoals;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tint(const Color(0xFFE5484D), 0.08),
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: tint(const Color(0xFFE5484D), 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: tint(const Color(0xFFE5484D), 0.15),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Center(
              child: SIcon(SardIcons.local_fire_department_rounded, size: 23, color: const Color(0xFFE5484D)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  streakDays <= 0
                      ? 'ابدأ سلسلتك اليوم'
                      : streakDays == 1
                          ? 'يوم واحد متتابع — بداية موفقة!'
                          : '$streakDays أيام متتالية — واصل!',
                  style: context.ds(size: 14.5),
                ),
                Text(
                  totalGoals <= 0
                      ? 'أنشئ هدفاً لتبدأ تتبع سلسلتك.'
                      : 'أكملت $doneToday من $totalGoals أهداف اليوم.',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// سجلّ إكمال هدف في يوم معيّن (للعرض في سجلّ الإنجازات).
@immutable
class GoalCompletionLog {
  const GoalCompletionLog({
    required this.goalId,
    required this.goalTitle,
    required this.completedAt,
  });

  final String goalId;
  final String goalTitle;
  final DateTime completedAt;

  Map<String, dynamic> toJson() => {
        'goal_id': goalId,
        'title': goalTitle,
        'at': completedAt.millisecondsSinceEpoch,
      };

  factory GoalCompletionLog.fromJson(Map<String, dynamic> j) {
    DateTime at(dynamic v) {
      if (v is num) return DateTime.fromMillisecondsSinceEpoch(v.toInt());
      return DateTime.tryParse('$v') ?? DateTime.now();
    }

    return GoalCompletionLog(
      goalId: '${j['goal_id'] ?? ''}',
      goalTitle: '${j['title'] ?? ''}',
      completedAt: at(j['at']),
    );
  }
}

/// يبني جملة تشجيعية حسب نسبة إنجاز الأهداف.
String goalEncouragement(double fraction) {
  if (fraction >= 1) return 'مذهل! كل الأهداف مكتملة — أنت قارئ استثنائي اليوم.';
  if (fraction >= 0.75) return 'اقتربت كثيراً — هدف واحد يفصلك عن الكمال.';
  if (fraction >= 0.5) return 'تخطيت النصف — واصل بنفس الإيقاع.';
  if (fraction > 0) return 'بداية جيدة — كل صفحة تقرّبك.';
  return 'يوم جديد وهدف جديد — ابدأ بأول فصل.';
}

/// أهداف مقترحة حسب مستوى القارئ (من إحصاءاته العامة).
List<GoalTemplate> suggestedTemplatesFor({
  required int totalChaptersRead,
  required int streak,
}) {
  if (totalChaptersRead <= 0) {
    return kGoalTemplates.where((t) => t.kind == ReadingGoalKind.dailyChapters && t.target <= 1).toList();
  }
  if (totalChaptersRead < 20) {
    return kGoalTemplates
        .where((t) => (t.kind == ReadingGoalKind.dailyChapters && t.target <= 3) || t.kind == ReadingGoalKind.dailyMinutes)
        .toList();
  }
  if (streak >= 7) {
    return kGoalTemplates
        .where((t) => t.kind == ReadingGoalKind.streakDays || t.kind == ReadingGoalKind.weeklyChapters)
        .toList();
  }
  return kGoalTemplates
      .where((t) => t.kind == ReadingGoalKind.weeklyChapters || t.kind == ReadingGoalKind.monthlyChapters)
      .toList();
}
