// ──────────────────────────────────────────────────────────────────────────
//  وضع اللوحات v2 — تقسيم الصفحات الطويلة (ويبتون) إلى لوحات قابلة للتنقل.
//  تقسيم قواعدي خالص: حسب نسبة أبعاد الصفحة وعدد اللوحات المطلوب،
//  وليس كشف صور — لا تحليل بكسل ولا ذكاء اصطناعي.
// ──────────────────────────────────────────────────────────────────────────
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// مفتاح تخزين إعدادات وضع اللوحات.
const String kRv2PanelKey = 'rv2_panel_v1';

// ───────── نماذج اللوحات ─────────

/// استراتيجية تقسيم الصفحة إلى لوحات.
enum PanelSplitStrategy {
  /// تقسيم متساوٍ حسب الارتفاع (الافتراضي للويبتون الطويل).
  byHeight('تقسيم متساوٍ'),

  /// عدد ثابت من اللوحات مهما كان الارتفاع.
  byCount('عدد ثابت'),

  /// حسب نسبة الأبعاد: الصفحة الطويلة جداً تُقسّم أكثر.
  byAspect('حسب نسبة الأبعاد');

  const PanelSplitStrategy(this.label);
  final String label;

  static PanelSplitStrategy fromKey(String? key) {
    for (final s in PanelSplitStrategy.values) {
      if (s.name == key) return s;
    }
    return PanelSplitStrategy.byHeight;
  }
}

/// لوحة واحدة داخل صفحة: مستطيل نسبي (0..1) + رقمها + وصفها.
@immutable
class PanelRect {
  const PanelRect({
    required this.index,
    required this.left,
    required this.top,
    required this.width,
    required this.height,
  });

  /// رقم اللوحة داخل الصفحة (يبدأ من 0)
  final int index;

  /// إحداثيات نسبية من أبعاد الصفحة (0..1)
  final double left;
  final double top;
  final double width;
  final double height;

  double get right => left + width;
  double get bottom => top + height;

  /// مركز اللوحة (نسبي) — للتمرير إليه.
  Offset get center => Offset(left + width / 2, top + height / 2);

  /// نسبة اللوحة من ارتفاع الصفحة.
  double get heightFraction => height;

  Map<String, dynamic> toJson() => {
        'i': index,
        'l': left,
        't': top,
        'w': width,
        'h': height,
      };

  factory PanelRect.fromJson(Map<String, dynamic> j) => PanelRect(
        index: (j['i'] as num?)?.toInt() ?? 0,
        left: (j['l'] as num?)?.toDouble() ?? 0,
        top: (j['t'] as num?)?.toDouble() ?? 0,
        width: (j['w'] as num?)?.toDouble() ?? 1,
        height: (j['h'] as num?)?.toDouble() ?? 1,
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PanelRect &&
          index == other.index &&
          left == other.left &&
          top == other.top &&
          width == other.width &&
          height == other.height;

  @override
  int get hashCode => Object.hash(index, left, top, width, height);
}

/// خطة لوحات صفحة كاملة.
@immutable
class PanelPlan {
  const PanelPlan({
    required this.pageIndex,
    required this.pageAspect,
    required this.panels,
    required this.strategy,
  });

  /// رقم الصفحة في الفصل (يبدأ من 0)
  final int pageIndex;

  /// نسبة أبعاد الصفحة (العرض ÷ الارتفاع)
  final double pageAspect;

  /// اللوحات بالترتيب (من الأعلى إلى الأسفل)
  final List<PanelRect> panels;

  final PanelSplitStrategy strategy;

  int get count => panels.length;

  bool get isSingle => panels.length <= 1;

  PanelRect panelAt(int i) => panels[i.clamp(0, panels.length - 1)];

  /// اللوحة التي تحتوي نقطة نسبية [point].
  PanelRect panelContaining(Offset point) {
    for (final p in panels) {
      if (point.dy >= p.top && point.dy < p.bottom) return p;
    }
    return panels.last;
  }

  Map<String, dynamic> toJson() => {
        'page': pageIndex,
        'aspect': pageAspect,
        'strategy': strategy.name,
        'panels': panels.map((p) => p.toJson()).toList(),
      };

  factory PanelPlan.fromJson(Map<String, dynamic> j) {
    final list = (j['panels'] as List?) ?? const [];
    return PanelPlan(
      pageIndex: (j['page'] as num?)?.toInt() ?? 0,
      pageAspect: (j['aspect'] as num?)?.toDouble() ?? 0.5,
      strategy: PanelSplitStrategy.fromKey(j['strategy'] as String?),
      panels: list
          .whereType<Map>()
          .map((e) => PanelRect.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
    );
  }
}

// ───────── محرك التقسيم القواعدي ─────────

/// يقرّر عدد اللوحات لصفحة بنسبة أبعاد [aspect] (عرض ÷ ارتفاع).
/// القواعد:
///   - صفحة عريضة (aspect >= 1.2): لوحة واحدة (لا تقسيم عمودي).
///   - صفحة مربعة تقريباً (0.8..1.2): لوحتان كحد أقصى.
///   - صفحة طويلة (0.5..0.8): 3 لوحات.
///   - صفحة ويبتون طويلة جداً (aspect < 0.5): 4..6 لوحات حسب الطول.
int panelCountForAspect(
  double aspect, {
  int maxPanels = 6,
  int minPanels = 1,
}) {
  int n;
  if (aspect >= 1.2) {
    n = 1;
  } else if (aspect >= 0.8) {
    n = 2;
  } else if (aspect >= 0.5) {
    n = 3;
  } else if (aspect >= 0.35) {
    n = 4;
  } else if (aspect >= 0.25) {
    n = 5;
  } else {
    n = 6;
  }
  return n.clamp(minPanels, maxPanels).toInt();
}

/// يقسّم صفحة إلى لوحات حسب [strategy].
///  - byHeight: ارتفاعات متساوية مع تداخل [overlap] بين اللوحات.
///  - byCount: عدد ثابت [count] من اللوحات المتساوية.
///  - byAspect: العدد من نسبة الأبعاد (panelCountForAspect).
/// التداخل (overlap 0..0.2) يبقي سياقاً بصرياً بين لوحتين متتاليتين.
PanelPlan splitPageIntoPanels({
  required int pageIndex,
  required double pageAspect,
  required PanelSplitStrategy strategy,
  int count = 3,
  int maxPanels = 6,
  double overlap = 0.08,
}) {
  final aspect = pageAspect.isFinite && pageAspect > 0 ? pageAspect : 0.5;
  final ov = overlap.clamp(0.0, 0.2).toDouble();
  int n;
  switch (strategy) {
    case PanelSplitStrategy.byHeight:
      // عدد اللوحات يتناسب مع طول الصفحة: كل لوحة ~ نسبة 0.5 ارتفاعاً.
      n = (1 / aspect / 2).ceil().clamp(1, maxPanels).toInt();
      break;
    case PanelSplitStrategy.byCount:
      n = count.clamp(1, maxPanels).toInt();
      break;
    case PanelSplitStrategy.byAspect:
      n = panelCountForAspect(aspect, maxPanels: maxPanels);
      break;
  }
  if (n <= 1) {
    return PanelPlan(
      pageIndex: pageIndex,
      pageAspect: aspect,
      strategy: strategy,
      panels: const [PanelRect(index: 0, left: 0, top: 0, width: 1, height: 1)],
    );
  }
  // ارتفاع كل لوحة مع تداخل: المساحة الكلية = 1 + (n-1)*overlap
  final rawH = (1 + (n - 1) * ov) / n;
  final panels = <PanelRect>[];
  for (var i = 0; i < n; i++) {
    final top = (i * (1 - rawH) / (n - 1)).clamp(0.0, 1.0).toDouble();
    panels.add(PanelRect(
      index: i,
      left: 0,
      top: top,
      width: 1,
      height: rawH.clamp(0.05, 1.0).toDouble(),
    ));
  }
  return PanelPlan(
    pageIndex: pageIndex,
    pageAspect: aspect,
    strategy: strategy,
    panels: panels,
  );
}

/// يبني خططاً لكل صفحات فصل (أبعادها معروفة تقريبياً).
List<PanelPlan> splitChapterIntoPanels({
  required List<double> pageAspects,
  required PanelSplitStrategy strategy,
  int count = 3,
  int maxPanels = 6,
  double overlap = 0.08,
}) {
  final out = <PanelPlan>[];
  for (var i = 0; i < pageAspects.length; i++) {
    out.add(splitPageIntoPanels(
      pageIndex: i,
      pageAspect: pageAspects[i],
      strategy: strategy,
      count: count,
      maxPanels: maxPanels,
      overlap: overlap,
    ));
  }
  return out;
}

// ───────── ملّاح اللوحات ─────────

/// حالة التنقل داخل لوحات فصل: الصفحة الحالية + اللوحة الحالية.
/// يتحرك لوحةً لوحة، وينتقل للصفحة التالية عند آخر لوحة.
class PanelNavigator extends ChangeNotifier {
  PanelNavigator({required this.plans}) {
    _page = 0;
    _panel = 0;
  }

  final List<PanelPlan> plans;

  int _page = 0;
  int _panel = 0;

  int get page => _page;
  int get panel => _panel;

  int get totalPages => plans.length;

  PanelPlan? get currentPlan => plans.isEmpty ? null : plans[_page.clamp(0, plans.length - 1)];

  PanelRect? get currentPanel {
    final plan = currentPlan;
    if (plan == null) return null;
    return plan.panelAt(_panel);
  }

  /// إجمالي اللوحات في الفصل كله.
  int get totalPanels => plans.fold<int>(0, (a, p) => a + p.count);

  /// رقم اللوحة العام (عبر كل الصفحات) — لشريط التقدم.
  int get globalPanelIndex {
    var n = 0;
    for (var i = 0; i < _page && i < plans.length; i++) {
      n += plans[i].count;
    }
    return n + _panel;
  }

  double get fraction => totalPanels <= 1 ? 0 : globalPanelIndex / (totalPanels - 1);

  bool get isFirst => _page == 0 && _panel == 0;
  bool get isLast {
    if (plans.isEmpty) return true;
    return _page == plans.length - 1 && _panel == plans.last.count - 1;
  }

  /// التالي: لوحة تالية، أو أول لوحة في الصفحة التالية.
  /// يعيد false إن كنا في آخر لوحة في الفصل.
  bool next() {
    final plan = currentPlan;
    if (plan == null) return false;
    if (_panel < plan.count - 1) {
      _panel++;
      notifyListeners();
      return true;
    }
    if (_page < plans.length - 1) {
      _page++;
      _panel = 0;
      notifyListeners();
      return true;
    }
    return false;
  }

  /// السابق: لوحة سابقة، أو آخر لوحة في الصفحة السابقة.
  bool prev() {
    if (_panel > 0) {
      _panel--;
      notifyListeners();
      return true;
    }
    if (_page > 0) {
      _page--;
      final plan = currentPlan;
      _panel = plan == null ? 0 : plan.count - 1;
      notifyListeners();
      return true;
    }
    return false;
  }

  void jumpTo(int page, int panel) {
    if (plans.isEmpty) return;
    _page = page.clamp(0, plans.length - 1).toInt();
    final plan = currentPlan!;
    _panel = panel.clamp(0, plan.count - 1).toInt();
    notifyListeners();
  }

  void jumpToGlobal(int globalIndex) {
    var rest = globalIndex.clamp(0, totalPanels - 1).toInt();
    for (var i = 0; i < plans.length; i++) {
      if (rest < plans[i].count) {
        _page = i;
        _panel = rest;
        notifyListeners();
        return;
      }
      rest -= plans[i].count;
    }
  }
}

// ───────── إعدادات وضع اللوحات ─────────

@immutable
class PanelModeSettings {
  const PanelModeSettings({
    this.enabled = false,
    this.strategy = PanelSplitStrategy.byAspect,
    this.maxPanels = 6,
    this.overlap = 0.08,
    this.showIndicator = true,
    this.autoAdvance = false,
  });

  final bool enabled;
  final PanelSplitStrategy strategy;
  final int maxPanels;
  final double overlap;
  final bool showIndicator;
  final bool autoAdvance;

  factory PanelModeSettings.defaults() => const PanelModeSettings();

  PanelModeSettings copyWith({
    bool? enabled,
    PanelSplitStrategy? strategy,
    int? maxPanels,
    double? overlap,
    bool? showIndicator,
    bool? autoAdvance,
  }) {
    return PanelModeSettings(
      enabled: enabled ?? this.enabled,
      strategy: strategy ?? this.strategy,
      maxPanels: maxPanels ?? this.maxPanels,
      overlap: overlap ?? this.overlap,
      showIndicator: showIndicator ?? this.showIndicator,
      autoAdvance: autoAdvance ?? this.autoAdvance,
    );
  }

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'strategy': strategy.name,
        'max_panels': maxPanels,
        'overlap': overlap,
        'indicator': showIndicator,
        'auto_advance': autoAdvance,
      };

  factory PanelModeSettings.fromJson(Map<String, dynamic> j) {
    return PanelModeSettings(
      enabled: j['enabled'] == true,
      strategy: PanelSplitStrategy.fromKey(j['strategy'] as String?),
      maxPanels: ((j['max_panels'] as num?)?.toInt() ?? 6).clamp(1, 8).toInt(),
      overlap: ((j['overlap'] as num?)?.toDouble() ?? 0.08).clamp(0.0, 0.2).toDouble(),
      showIndicator: j['indicator'] != false,
      autoAdvance: j['auto_advance'] == true,
    );
  }
}

/// مخزن إعدادات وضع اللوحات (مفردة).
class PanelModeStore extends ChangeNotifier {
  PanelModeStore._(this._p) {
    _settings = _load();
  }

  static PanelModeStore? _instance;

  static PanelModeStore get i {
    final inst = _instance;
    if (inst == null) throw StateError('PanelModeStore لم يُحمَّل بعد — نادِ load() أولاً.');
    return inst;
  }

  static Future<PanelModeStore> load() async {
    final p = await SharedPreferences.getInstance();
    return _instance ??= PanelModeStore._(p);
  }

  static PanelModeStore testInstance() => PanelModeStore._(_Rv2PanelFakePrefs());

  final SharedPreferences _p;
  late PanelModeSettings _settings;

  PanelModeSettings _load() {
    try {
      final raw = _p.getString(kRv2PanelKey);
      if (raw == null || raw.isEmpty) return PanelModeSettings.defaults();
      return PanelModeSettings.fromJson(
        Map<String, dynamic>.from(jsonDecode(raw) as Map),
      );
    } catch (_) {
      return PanelModeSettings.defaults();
    }
  }

  PanelModeSettings get settings => _settings;

  Future<void> update(PanelModeSettings next) async {
    _settings = next;
    await _p.setString(kRv2PanelKey, jsonEncode(next.toJson()));
    notifyListeners();
  }

  Future<void> setEnabled(bool v) async => update(_settings.copyWith(enabled: v));
}

/// بديل خفيف لـ SharedPreferences في الاختبارات (ذاكرة فقط).
class _Rv2PanelFakePrefs implements SharedPreferences {
  final Map<String, Object> _m = {};

  @override
  Set<String> getKeys() => _m.keys.toSet();
  @override
  Object? get(String key) => _m[key];
  @override
  bool? getBool(String key) => _m[key] as bool?;
  @override
  double? getDouble(String key) => _m[key] as double?;
  @override
  int? getInt(String key) => _m[key] as int?;
  @override
  String? getString(String key) => _m[key] as String?;
  @override
  List<String>? getStringList(String key) => _m[key] as List<String>?;
  @override
  bool containsKey(String key) => _m.containsKey(key);
  @override
  Future<bool> setBool(String key, bool value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setDouble(String key, double value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setInt(String key, int value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setString(String key, String value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> remove(String key) async {
    _m.remove(key);
    return true;
  }

  @override
  Future<bool> clear() async {
    _m.clear();
    return true;
  }

  @override
  Future<bool> commit() async => true;
  @override
  Future<void> reload() async {}
}

// ───────── ويدجتات وضع اللوحات ─────────

/// مؤشر اللوحة الحالية: «اللوحة 3 من 12» + شريط تقدم رفيع.
class PanelIndicator extends StatelessWidget {
  const PanelIndicator({super.key, required this.navigator});

  final PanelNavigator navigator;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: navigator,
      builder: (context, _) {
        final cur = navigator.globalPanelIndex + 1;
        final total = navigator.totalPanels;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: tint(Colors.black, 0.55),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SIcon(SardIcons.chrome_reader_mode_rounded, size: 15, color: Colors.white),
              const SizedBox(width: 6),
              Text(
                'اللوحة $cur من $total',
                style: context.ts(size: 12, w: FontWeight.w700, color: Colors.white),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 64,
                child: LinearProgressIndicator(
                  value: navigator.fraction,
                  backgroundColor: tint(Colors.white, 0.25),
                  valueColor: AlwaysStoppedAnimation<Color>(p.gold),
                  minHeight: 3,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// بطاقة شرح وضع اللوحات (تُعرض عند تفعيله أول مرة).
class PanelModeIntroCard extends StatelessWidget {
  const PanelModeIntroCard({super.key, this.onDismiss, this.onEnable});

  final VoidCallback? onDismiss;
  final VoidCallback? onEnable;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: tint(p.gold, 0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SIcon(SardIcons.chrome_reader_mode_rounded, size: 20, color: p.gold),
              const SizedBox(width: 8),
              Expanded(
                child: Text('وضع اللوحات', style: context.ds(size: 16)),
              ),
              if (onDismiss != null)
                IconButton(
                  onPressed: onDismiss,
                  icon: SIcon(SardIcons.close_rounded, size: 18, color: p.textDim),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'يقسّم الصفحات الطويلة إلى لوحات تتنقل بينها لوحةً لوحة — مثالي للهواتف الصغيرة. التقسيم قواعدي حسب طول الصفحة، وليس كشفاً للصور.',
            style: context.ts(size: 13, color: p.textDim),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: onDismiss,
                  child: const Text('ليس الآن'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  onPressed: onEnable,
                  child: const Text('تفعيل الوضع'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// يقدّر نسبة أبعاد صفحة من عرضها وارتفاعها بالبكسل (0.5 افتراضياً للويبتون).
double estimatePageAspect({required int widthPx, required int heightPx}) {
  if (widthPx <= 0 || heightPx <= 0) return 0.5;
  return (widthPx / heightPx).clamp(0.1, 3.0).toDouble();
}

/// أقصى عدد لوحات مسموح حسب ارتفاع الصفحة بالبكسل (للتقييد العملي).
int maxPanelsForHeight(int heightPx) {
  if (heightPx < 1200) return 2;
  if (heightPx < 2400) return 3;
  if (heightPx < 4800) return 4;
  if (heightPx < 8000) return 5;
  return 6;
}

// ───────── معاينة خطة اللوحات ─────────

/// معاينة مرئية لخطة لوحات صفحة: مستطيلات تمثل اللوحات مع أرقامها.
/// تُستخدم في إعدادات وضع اللوحات لتوضيح التقسيم قبل التفعيل.
class PanelPlanPreview extends StatelessWidget {
  const PanelPlanPreview({
    super.key,
    required this.plan,
    this.height = 220,
    this.selectedIndex,
    this.onPanelTap,
  });

  final PanelPlan plan;
  final double height;
  final int? selectedIndex;
  final ValueChanged<int>? onPanelTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: p.surfaceHi,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: p.border),
      ),
      child: Stack(
        children: [
          for (final panel in plan.panels)
            Positioned(
              left: 8 + panel.left * 20,
              right: 8 + (1 - panel.right) * 20,
              top: 8 + panel.top * (height - 16),
              height: (panel.height * (height - 16)).clamp(24.0, height - 16).toDouble(),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: onPanelTap == null ? null : () => onPanelTap!(panel.index),
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    decoration: BoxDecoration(
                      color: panel.index == selectedIndex
                          ? tint(p.accent, 0.25)
                          : tint(p.accent, 0.10),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: panel.index == selectedIndex ? p.accent : tint(p.accent, 0.4),
                        width: panel.index == selectedIndex ? 2 : 1,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        'اللوحة ${panel.index + 1}',
                        style: context.ts(
                          size: 12,
                          w: FontWeight.w800,
                          color: panel.index == selectedIndex ? p.accent : p.textDim,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// بطاقة إعدادات وضع اللوحات (تُستخدم داخل شاشة الإعدادات).
class PanelModeSettingsCard extends StatefulWidget {
  const PanelModeSettingsCard({super.key});

  @override
  State<PanelModeSettingsCard> createState() => _PanelModeSettingsCardState();
}

class _PanelModeSettingsCardState extends State<PanelModeSettingsCard> {
  late PanelModeStore _store;
  int _selectedPanel = 0;

  @override
  void initState() {
    super.initState();
    _store = PanelModeStore.i;
  }

  PanelPlan get _previewPlan => splitPageIntoPanels(
        pageIndex: 0,
        pageAspect: 0.3,
        strategy: _store.settings.strategy,
        maxPanels: _store.settings.maxPanels,
        overlap: _store.settings.overlap,
      );

  Future<void> _update(PanelModeSettings Function(PanelModeSettings s) fn) async {
    await _store.update(fn(_store.settings));
    setState(() => _selectedPanel = 0);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return AnimatedBuilder(
      animation: _store,
      builder: (context, _) {
        final s = _store.settings;
        final plan = _previewPlan;
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(p.r(1)),
            border: Border.all(color: p.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: tint(p.gold, 0.14),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(child: SIcon(SardIcons.chrome_reader_mode_rounded, size: 18, color: p.gold)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text('وضع اللوحات', style: context.ds(size: 15.5))),
                  Switch(
                    value: s.enabled,
                    activeColor: p.accent,
                    onChanged: (v) => _update((s) => s.copyWith(enabled: v)),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'يقسّم الصفحات الطويلة إلى لوحات تتنقل بينها — التقسيم قواعدي حسب طول الصفحة.',
                style: context.ts(size: 12.5, color: p.textDim),
              ),
              const SizedBox(height: 12),
              Text('الاستراتيجية', style: context.ts(size: 13, w: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: PanelSplitStrategy.values.map((st) {
                  final sel = st == s.strategy;
                  return ChoiceChip(
                    label: Text(st.label),
                    selected: sel,
                    selectedColor: tint(p.accent, 0.2),
                    labelStyle: context.ts(size: 12.5, w: sel ? FontWeight.w800 : FontWeight.w500),
                    onSelected: (_) => _update((s) => s.copyWith(strategy: st)),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: Text('أقصى عدد لوحات: ${s.maxPanels}', style: context.ts(size: 13, w: FontWeight.w700))),
                  IconButton(
                    onPressed: () => _update((s) => s.copyWith(maxPanels: (s.maxPanels - 1).clamp(1, 8).toInt())),
                    icon: SIcon(SardIcons.chevron_right_rounded, size: 20, color: p.text),
                  ),
                  IconButton(
                    onPressed: () => _update((s) => s.copyWith(maxPanels: (s.maxPanels + 1).clamp(1, 8).toInt())),
                    icon: SIcon(SardIcons.chevron_left_rounded, size: 20, color: p.text),
                  ),
                ],
              ),
              Slider(
                value: s.maxPanels.toDouble(),
                min: 1,
                max: 8,
                divisions: 7,
                activeColor: p.accent,
                onChanged: (v) => _update((s) => s.copyWith(maxPanels: v.round())),
              ),
              Row(
                children: [
                  Expanded(child: Text('التداخل بين اللوحات: ${(s.overlap * 100).round()}٪', style: context.ts(size: 13, w: FontWeight.w700))),
                ],
              ),
              Slider(
                value: s.overlap,
                min: 0,
                max: 0.2,
                activeColor: p.accent,
                onChanged: (v) => _update((s) => s.copyWith(overlap: v)),
              ),
              const SizedBox(height: 8),
              Text('معاينة التقسيم (صفحة ويبتون طويلة)', style: context.ts(size: 12.5, color: p.textDim)),
              const SizedBox(height: 8),
              PanelPlanPreview(
                plan: plan,
                selectedIndex: _selectedPanel,
                onPanelTap: (i) => setState(() => _selectedPanel = i),
              ),
              const SizedBox(height: 8),
              Text(
                'الصفحة تُقسّم إلى ${plan.count} لوحات بهذه الإعدادات.',
                style: context.ts(size: 12, color: p.textDim),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ───────── ورقة دليل وضع اللوحات ─────────

/// ورقة شرح وضع اللوحات مع مثال حي للتقسيم.
class PanelModeGuideSheet extends StatefulWidget {
  const PanelModeGuideSheet({super.key, required this.settings});

  final PanelModeSettings settings;

  @override
  State<PanelModeGuideSheet> createState() => _PanelModeGuideSheetState();
}

class _PanelModeGuideSheetState extends State<PanelModeGuideSheet> {
  int _selected = 0;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final plan = splitPageIntoPanels(
      pageIndex: 0,
      pageAspect: 0.3,
      strategy: widget.settings.strategy,
      maxPanels: widget.settings.maxPanels,
      overlap: widget.settings.overlap,
    );
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(width: 44, height: 4, decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4))),
            ),
            const SizedBox(height: 16),
            Text('كيف يعمل وضع اللوحات؟', style: context.ds(size: 19)),
            const SizedBox(height: 8),
            Text(
              'الصفحات الطويلة (ويبتون) تُقسَّم إلى لوحات حسب طولها، فتقرأ لوحةً لوحة بدل التمرير الطويل. جرّب الضغط على لوحة في المثال:',
              style: context.ts(size: 13, color: p.textDim),
            ),
            const SizedBox(height: 14),
            PanelPlanPreview(
              plan: plan,
              height: 240,
              selectedIndex: _selected,
              onPanelTap: (i) => setState(() => _selected = i),
            ),
            const SizedBox(height: 10),
            Text(
              'اللوحة المحددة: ${_selected + 1} من ${plan.count} — التنقل بين اللوحات يتم بالنقر على الأطراف أو السحب.',
              style: context.ts(size: 12.5, color: p.textDim),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('فهمت'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// يفتح ورقة دليل وضع اللوحات.
Future<void> showPanelModeGuide(BuildContext context, PanelModeSettings settings) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => PanelModeGuideSheet(settings: settings),
  );
}

/// يقدّر عدد اللوحات المثالي لصفحة من أبعادها بالبكسل.
int idealPanelCountForPixels({required int widthPx, required int heightPx}) {
  final aspect = estimatePageAspect(widthPx: widthPx, heightPx: heightPx);
  return panelCountForAspect(aspect, maxPanels: maxPanelsForHeight(heightPx));
}
