// ──────────────────────────────────────────────────────────────────────────
//  تتبّع تقدّم القراءة v2 — سجلّ الجلسات والفصول والسرعة والإحصاءات.
//  كل البيانات محلية (SharedPreferences) ولا تُرسل لأي خادم.
//  المفتاح: rv2_progress_v1
// ──────────────────────────────────────────────────────────────────────────
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/data/models.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// مفتاح تخزين سجلّ القراءة v2.
const String kRv2ProgressKey = 'rv2_progress_v1';

/// أقصى عدد سجلات يُحتفظ بها (الأحدث أولاً).
const int kRv2ProgressMaxRecords = 400;

// ───────── تنسيقات عربية ─────────

/// 0 -> "0 ثوانٍ" · 45 -> "45 ثانية" · 90 -> "دقيقة واحدة" · 150 -> "دقيقتان"
/// 3600 -> "ساعة واحدة" · 7260 -> "ساعتان ودقيقة واحدة" · 9000 -> "ساعتان و30 دقيقة"
String formatDurationArabic(int seconds) {
  if (seconds <= 0) return '0 ثوانٍ';
  if (seconds < 60) {
    if (seconds == 1) return 'ثانية واحدة';
    if (seconds == 2) return 'ثانيتان';
    if (seconds <= 10) return '$seconds ثوانٍ';
    return '$seconds ثانية';
  }
  final minutes = seconds ~/ 60;
  final rem = seconds % 60;
  String minPart;
  if (minutes == 1) {
    minPart = 'دقيقة واحدة';
  } else if (minutes == 2) {
    minPart = 'دقيقتان';
  } else if (minutes <= 10) {
    minPart = '$minutes دقائق';
  } else if (minutes < 60) {
    minPart = '$minutes دقيقة';
  } else {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    String hourPart;
    if (h == 1) {
      hourPart = 'ساعة واحدة';
    } else if (h == 2) {
      hourPart = 'ساعتان';
    } else if (h <= 10) {
      hourPart = '$h ساعات';
    } else {
      hourPart = '$h ساعة';
    }
    if (m == 0) return hourPart;
    if (m == 1) return '$hourPart ودقيقة واحدة';
    if (m == 2) return '$hourPart ودقيقتان';
    if (m <= 10) return '$hourPart و$m دقائق';
    return '$hourPart و$m دقيقة';
  }
  if (rem == 0) return minPart;
  if (rem == 1) return '$minPart وثانية واحدة';
  if (rem == 2) return '$minPart وثانيتان';
  if (rem <= 10) return '$minPart و$rem ثوانٍ';
  return '$minPart و$rem ثانية';
}

/// "قرأت 12 دقيقة" — جملة جاهزة للعرض في شريحة آخر قراءة.
String formatReadSummary({required int seconds, required double speedPpm}) {
  final base = 'قرأت ${formatDurationArabic(seconds)}';
  if (speedPpm <= 0) return base;
  return '$base · ${speedPpm.toStringAsFixed(1)} صفحة/دقيقة';
}

/// 3.5 -> "3.5 صفحة/دقيقة" · 0 -> "—"
String formatSpeedLabel(double ppm) {
  if (ppm <= 0 || !ppm.isFinite) return '—';
  if (ppm >= 10) return '${ppm.toStringAsFixed(0)} صفحة/دقيقة';
  return '${ppm.toStringAsFixed(1)} صفحة/دقيقة';
}

/// تنسيق تاريخ عربي مختصر: 26 نوفمبر 2026
String formatRv2Date(DateTime d) {
  const months = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];
  return '${d.day} ${months[d.month - 1]} ${d.year}';
}

/// "اليوم" / "أمس" / تاريخ مختصر — لعرض سجلّ القراءة.
String formatRv2DayLabel(DateTime d, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final today = DateTime(n.year, n.month, n.day);
  final day = DateTime(d.year, d.month, d.day);
  final diff = today.difference(day).inDays;
  if (diff == 0) return 'اليوم';
  if (diff == 1) return 'أمس';
  if (diff < 7) {
    const names = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
    return names[day.weekday - 1];
  }
  return formatRv2Date(day);
}

/// مفتاح يوم YYYY-MM-DD
String rv2DayKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

// ───────── سجلّ فصل واحد ─────────

/// سجلّ قراءة فصل واحد: المدة والصفحات والسرعة ووقت البدء والانتهاء.
/// غير قابل للتعديل (immutable) — أي تحديث ينتج نسخة جديدة عبر [copyWith].
@immutable
class ChapterRecord {
  const ChapterRecord({
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.seconds,
    required this.pagesRead,
    required this.totalPages,
    required this.startedAt,
    this.finishedAt,
    this.speedPpm = 0,
  });

  final String seriesId;
  final String seriesTitle;

  /// رقم الفصل
  final int chapter;

  /// ثواني القراءة الفعلية داخل هذا الفصل
  final int seconds;

  /// عدد الصفحات التي قُرئت في هذه الجلسة
  final int pagesRead;

  /// إجمالي صفحات الفصل (0 = غير معروف)
  final int totalPages;

  final DateTime startedAt;

  /// وقت إكمال الفصل (null = لم يُكمل بعد)
  final DateTime? finishedAt;

  /// صفحات في الدقيقة (محسوبة عند الحفظ)
  final double speedPpm;

  bool get completed => finishedAt != null;

  /// نسبة إكمال الفصل 0..1 (حسب الصفحات)
  double get fraction {
    if (totalPages <= 0) return completed ? 1 : 0;
    return (pagesRead / totalPages).clamp(0.0, 1.0).toDouble();
  }

  /// دقائق القراءة (عدد صحيح للعرض)
  int get minutes => seconds ~/ 60;

  /// هل السجلّ من اليوم؟
  bool get isToday {
    final n = DateTime.now();
    return startedAt.year == n.year && startedAt.month == n.month && startedAt.day == n.day;
  }

  ChapterRecord copyWith({
    String? seriesId,
    String? seriesTitle,
    int? chapter,
    int? seconds,
    int? pagesRead,
    int? totalPages,
    DateTime? startedAt,
    DateTime? finishedAt,
    double? speedPpm,
  }) {
    return ChapterRecord(
      seriesId: seriesId ?? this.seriesId,
      seriesTitle: seriesTitle ?? this.seriesTitle,
      chapter: chapter ?? this.chapter,
      seconds: seconds ?? this.seconds,
      pagesRead: pagesRead ?? this.pagesRead,
      totalPages: totalPages ?? this.totalPages,
      startedAt: startedAt ?? this.startedAt,
      finishedAt: finishedAt ?? this.finishedAt,
      speedPpm: speedPpm ?? this.speedPpm,
    );
  }

  Map<String, dynamic> toJson() => {
        'series_id': seriesId,
        'series_title': seriesTitle,
        'chapter': chapter,
        'seconds': seconds,
        'pages_read': pagesRead,
        'total_pages': totalPages,
        'started_at': startedAt.millisecondsSinceEpoch,
        'finished_at': finishedAt?.millisecondsSinceEpoch,
        'speed_ppm': speedPpm,
      };

  factory ChapterRecord.fromJson(Map<String, dynamic> j) {
    DateTime at(dynamic v, {required DateTime fallback}) {
      if (v is num) return DateTime.fromMillisecondsSinceEpoch(v.toInt());
      final parsed = DateTime.tryParse('$v');
      return parsed ?? fallback;
    }

    final now = DateTime.now();
    return ChapterRecord(
      seriesId: '${j['series_id'] ?? ''}',
      seriesTitle: '${j['series_title'] ?? ''}',
      chapter: (j['chapter'] as num?)?.toInt() ?? 0,
      seconds: (j['seconds'] as num?)?.toInt() ?? 0,
      pagesRead: (j['pages_read'] as num?)?.toInt() ?? 0,
      totalPages: (j['total_pages'] as num?)?.toInt() ?? 0,
      startedAt: at(j['started_at'], fallback: now),
      finishedAt: j['finished_at'] == null ? null : at(j['finished_at'], fallback: now),
      speedPpm: (j['speed_ppm'] as num?)?.toDouble() ?? 0,
    );
  }

  /// جملة ملخّص للعرض: «الفصل 12 · قرأت 14 دقيقة»
  String get summaryLabel =>
      'الفصل $chapter · ${formatDurationArabic(seconds)}';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ChapterRecord &&
          seriesId == other.seriesId &&
          chapter == other.chapter &&
          startedAt == other.startedAt;

  @override
  int get hashCode => Object.hash(seriesId, chapter, startedAt);
}

// ───────── جلسة قراءة حيّة ─────────

/// جلسة قراءة جارية داخل القارئ: توقّت الثواني وتعدّ الصفحات.
/// تُنشأ عند فتح فصل، وتُغلق عند الخروج أو إكمال الفصل، فيُحفظ سجلّها.
class ReadingSession {
  ReadingSession({
    required this.series,
    required this.chapter,
    required this.totalPages,
    this.startPage = 1,
  }) : _startedAt = DateTime.now();

  final Series series;
  final int chapter;
  final int totalPages;
  final int startPage;

  final DateTime _startedAt;
  DateTime? _pausedAt;
  int _pausedSeconds = 0;
  int _lastPage = 0;
  int _maxPage = 0;
  bool _finished = false;

  DateTime get startedAt => _startedAt;
  bool get isPaused => _pausedAt != null;
  bool get finished => _finished;

  int get currentPage => _lastPage > 0 ? _lastPage : startPage;
  int get maxPageReached => _maxPage;

  /// الصفحات المقروءة في هذه الجلسة (من أول صفحة عُرضت إلى أبعد صفحة)
  int get pagesRead {
    if (_maxPage <= 0) return 0;
    final from = startPage.clamp(1, totalPages <= 0 ? startPage : totalPages);
    return (_maxPage - from + 1).clamp(0, 1 << 20).toInt();
  }

  /// ثواني القراءة الفعلية (دون وقت الإيقاف المؤقت)
  int get seconds {
    var s = DateTime.now().difference(_startedAt).inSeconds - _pausedSeconds;
    if (_pausedAt != null) {
      s -= DateTime.now().difference(_pausedAt!).inSeconds;
    }
    return s.clamp(0, 1 << 30).toInt();
  }

  /// صفحات في الدقيقة حتى الآن
  double get speedPpm {
    final m = seconds / 60;
    if (m <= 0) return 0;
    return pagesRead / m;
  }

  void onPage(int page) {
    if (page <= 0) return;
    if (_lastPage == 0) _lastPage = page;
    _lastPage = page;
    if (page > _maxPage) _maxPage = page;
  }

  void pause() {
    _pausedAt ??= DateTime.now();
  }

  void resume() {
    if (_pausedAt == null) return;
    _pausedSeconds += DateTime.now().difference(_pausedAt!).inSeconds;
    _pausedAt = null;
  }

  void markFinished() => _finished = true;

  /// يحوّل الجلسة إلى سجلّ نهائي قابل للحفظ.
  ChapterRecord toRecord({DateTime? finishedAt}) {
    final secs = seconds;
    final pages = pagesRead;
    final ppm = secs > 0 ? pages / (secs / 60) : 0.0;
    return ChapterRecord(
      seriesId: series.id,
      seriesTitle: series.title,
      chapter: chapter,
      seconds: secs,
      pagesRead: pages,
      totalPages: totalPages,
      startedAt: _startedAt,
      finishedAt: _finished ? (finishedAt ?? DateTime.now()) : null,
      speedPpm: ppm.isFinite ? ppm : 0,
    );
  }
}

// ───────── إحصاءات عمل واحد ─────────

/// إحصاءات القراءة لعمل واحد (من السجلات المحفوظة).
@immutable
class SeriesReadingStats {
  const SeriesReadingStats({
    required this.seriesId,
    required this.seriesTitle,
    required this.totalSeconds,
    required this.totalChapters,
    required this.totalPages,
    required this.sessions,
    required this.averageSpeedPpm,
    required this.bestSpeedPpm,
    required this.lastReadAt,
    required this.completedChapters,
  });

  final String seriesId;
  final String seriesTitle;
  final int totalSeconds;
  final int totalChapters;
  final int totalPages;
  final int sessions;
  final double averageSpeedPpm;
  final double bestSpeedPpm;
  final DateTime? lastReadAt;
  final int completedChapters;

  factory SeriesReadingStats.empty(String seriesId, String seriesTitle) =>
      SeriesReadingStats(
        seriesId: seriesId,
        seriesTitle: seriesTitle,
        totalSeconds: 0,
        totalChapters: 0,
        totalPages: 0,
        sessions: 0,
        averageSpeedPpm: 0,
        bestSpeedPpm: 0,
        lastReadAt: null,
        completedChapters: 0,
      );

  factory SeriesReadingStats.fromRecords(
    String seriesId,
    String seriesTitle,
    List<ChapterRecord> records,
  ) {
    if (records.isEmpty) return SeriesReadingStats.empty(seriesId, seriesTitle);
    var secs = 0;
    var pages = 0;
    var done = 0;
    var best = 0.0;
    DateTime? last;
    final chapters = <int>{};
    for (final r in records) {
      secs += r.seconds;
      pages += r.pagesRead;
      if (r.completed) done++;
      if (r.speedPpm > best) best = r.speedPpm;
      chapters.add(r.chapter);
      if (last == null || r.startedAt.isAfter(last)) last = r.startedAt;
    }
    final avg = secs > 0 ? pages / (secs / 60) : 0.0;
    return SeriesReadingStats(
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      totalSeconds: secs,
      totalChapters: chapters.length,
      totalPages: pages,
      sessions: records.length,
      averageSpeedPpm: avg.isFinite ? avg : 0,
      bestSpeedPpm: best,
      lastReadAt: last,
      completedChapters: done,
    );
  }

  String get timeLabel => formatDurationArabic(totalSeconds);
  String get speedLabel => formatSpeedLabel(averageSpeedPpm);
}

// ───────── تجميع يومي ─────────

/// ملخّص قراءة يوم واحد.
@immutable
class DayReadingSummary {
  const DayReadingSummary({
    required this.dayKey,
    required this.date,
    required this.seconds,
    required this.chapters,
    required this.pages,
    required this.seriesTitles,
  });

  final String dayKey;
  final DateTime date;
  final int seconds;
  final int chapters;
  final int pages;
  final List<String> seriesTitles;

  String get timeLabel => formatDurationArabic(seconds);

  String get label {
    if (chapters <= 0) return timeLabel;
    if (chapters == 1) return 'فصل واحد · $timeLabel';
    if (chapters == 2) return 'فصلان · $timeLabel';
    if (chapters <= 10) return '$chapters فصول · $timeLabel';
    return '$chapters فصلاً · $timeLabel';
  }
}

// ───────── مخزن سجلّ القراءة ─────────

/// مخزن سجلّات القراءة v2 (مفردة عبر [ReaderProgressStore.i]).
/// يحفظ الجلسات المكتملة، ويقدّم الإحصاءات والتجميع اليومي والتصدير.
class ReaderProgressStore extends ChangeNotifier {
  ReaderProgressStore._(this._p) {
    _records = _loadAll();
  }

  static ReaderProgressStore? _instance;

  /// المفردة المعتمدة داخل التطبيق.
  static ReaderProgressStore get i {
    final inst = _instance;
    if (inst == null) throw StateError('ReaderProgressStore لم يُحمَّل بعد — نادِ load() أولاً.');
    return inst;
  }

  /// ينشئ المفردة (أو يعيدها إن وُجدت) من SharedPreferences.
  static Future<ReaderProgressStore> load() async {
    final p = await SharedPreferences.getInstance();
    return _instance ??= ReaderProgressStore._(p);
  }

  /// نسخة اختبار بذاكرة فارغة (للاختبارات فقط).
  static ReaderProgressStore testInstance() {
    return ReaderProgressStore._(_FakePrefs());
  }

  final SharedPreferences _p;
  late List<ChapterRecord> _records;

  List<ChapterRecord> _loadAll() {
    try {
      final raw = _p.getString(kRv2ProgressKey);
      if (raw == null || raw.isEmpty) return <ChapterRecord>[];
      final list = jsonDecode(raw) as List;
      final out = <ChapterRecord>[];
      for (final e in list) {
        if (e is! Map) continue;
        try {
          out.add(ChapterRecord.fromJson(Map<String, dynamic>.from(e)));
        } catch (_) {
          // سجلّ تالف يُتجاهل دون كسر بقية السجلّ
        }
      }
      out.sort((a, b) => b.startedAt.compareTo(a.startedAt));
      return out;
    } catch (_) {
      return <ChapterRecord>[];
    }
  }

  Future<void> _save() async {
    final trimmed = _records.take(kRv2ProgressMaxRecords).toList();
    if (trimmed.length != _records.length) _records = trimmed;
    await _p.setString(
      kRv2ProgressKey,
      jsonEncode(_records.map((r) => r.toJson()).toList()),
    );
  }

  /// كل السجلات (الأحدث أولاً) — نسخة للقراءة فقط.
  List<ChapterRecord> get records => List<ChapterRecord>.unmodifiable(_records);

  /// عدد السجلات المحفوظة.
  int get count => _records.length;

  /// إجمالي ثواني القراءة المسجلة.
  int get totalSeconds => _records.fold<int>(0, (a, r) => a + r.seconds);

  /// إجمالي الفصول المكتملة.
  int get totalCompletedChapters => _records.where((r) => r.completed).length;

  /// إجمالي الصفحات المقروءة.
  int get totalPages => _records.fold<int>(0, (a, r) => a + r.pagesRead);

  /// متوسط السرعة العام (صفحات/دقيقة).
  double get averageSpeedPpm {
    final secs = totalSeconds;
    if (secs <= 0) return 0;
    final ppm = totalPages / (secs / 60);
    return ppm.isFinite ? ppm : 0;
  }

  /// آخر سجلّ لعمل معيّن (أو null إن لم يُقرأ بعد).
  ChapterRecord? lastRecord(String seriesId) {
    for (final r in _records) {
      if (r.seriesId == seriesId) return r;
    }
    return null;
  }

  /// كل سجلات عمل معيّن (الأحدث أولاً).
  List<ChapterRecord> recordsFor(String seriesId) =>
      _records.where((r) => r.seriesId == seriesId).toList();

  /// أحدث السجلات (الأحدث أولاً) بعدد [limit].
  List<ChapterRecord> recent({int limit = 20}) => _records.take(limit).toList();

  /// إحصاءات عمل واحد من سجلاته.
  SeriesReadingStats statsFor(String seriesId, String seriesTitle) =>
      SeriesReadingStats.fromRecords(seriesId, seriesTitle, recordsFor(seriesId));

  /// الأعمال مرتّبة بحسب آخر قراءة (الأحدث أولاً).
  List<SeriesReadingStats> topSeries({int limit = 10}) {
    final byId = <String, List<ChapterRecord>>{};
    final titles = <String, String>{};
    for (final r in _records) {
      (byId[r.seriesId] ??= <ChapterRecord>[]).add(r);
      titles[r.seriesId] = r.seriesTitle;
    }
    final stats = byId.entries
        .map((e) => SeriesReadingStats.fromRecords(e.key, titles[e.key] ?? e.key, e.value))
        .toList();
    stats.sort((a, b) {
      final la = a.lastReadAt;
      final lb = b.lastReadAt;
      if (la == null && lb == null) return 0;
      if (la == null) return 1;
      if (lb == null) return -1;
      return lb.compareTo(la);
    });
    return stats.take(limit).toList();
  }

  /// سجلات يوم معيّن.
  List<ChapterRecord> recordsOn(DateTime day) {
    final key = rv2DayKey(day);
    return _records.where((r) => rv2DayKey(r.startedAt) == key).toList();
  }

  /// ملخّصات الأيام الأخيرة (الأحدث أولاً) حتى [days] يوماً.
  List<DayReadingSummary> lastDays({int days = 30, DateTime? now}) {
    final n = now ?? DateTime.now();
    final out = <DayReadingSummary>[];
    for (var i = 0; i < days; i++) {
      final day = DateTime(n.year, n.month, n.day - i);
      final list = recordsOn(day);
      if (list.isEmpty) continue;
      var secs = 0;
      var pages = 0;
      final chapters = <int>{};
      final titles = <String>{};
      for (final r in list) {
        secs += r.seconds;
        pages += r.pagesRead;
        chapters.add(r.chapter);
        titles.add(r.seriesTitle);
      }
      out.add(DayReadingSummary(
        dayKey: rv2DayKey(day),
        date: day,
        seconds: secs,
        chapters: chapters.length,
        pages: pages,
        seriesTitles: titles.toList(),
      ));
    }
    return out;
  }

  /// عدد أيام القراءة المتتالية (من السجلات فقط).
  int streak({DateTime? now}) {
    var d = now ?? DateTime.now();
    var day = DateTime(d.year, d.month, d.day);
    if (recordsOn(day).isEmpty) day = day.subtract(const Duration(days: 1));
    var n = 0;
    while (recordsOn(day).isNotEmpty) {
      n++;
      day = day.subtract(const Duration(days: 1));
    }
    return n;
  }

  /// يحفظ سجلّ جلسة (يُدمج مع سجلّ سابق للفصل نفسه في اليوم نفسه
  /// إن وُجد، بجمع الثواني والصفحات وأخذ أقصى سرعة).
  Future<void> addRecord(ChapterRecord record) async {
    final sameDay = _records.indexWhere(
      (r) =>
          r.seriesId == record.seriesId &&
          r.chapter == record.chapter &&
          rv2DayKey(r.startedAt) == rv2DayKey(record.startedAt) &&
          r.startedAt.difference(record.startedAt).inHours.abs() < 6,
    );
    if (sameDay >= 0) {
      final old = _records[sameDay];
      final merged = old.copyWith(
        seconds: old.seconds + record.seconds,
        pagesRead: math.max(old.pagesRead, record.pagesRead),
        totalPages: record.totalPages > 0 ? record.totalPages : old.totalPages,
        finishedAt: record.finishedAt ?? old.finishedAt,
        speedPpm: math.max(old.speedPpm, record.speedPpm),
      );
      _records[sameDay] = merged;
    } else {
      _records.insert(0, record);
    }
    _records.sort((a, b) => b.startedAt.compareTo(a.startedAt));
    await _save();
    notifyListeners();
  }

  /// يحفظ جلسة منتهية مباشرة.
  Future<void> addSession(ReadingSession session) async {
    await addRecord(session.toRecord());
  }

  /// يحذف سجلّاً واحداً.
  Future<void> removeRecord(ChapterRecord record) async {
    _records.remove(record);
    await _save();
    notifyListeners();
  }

  /// يحذف كل سجلات عمل معيّن.
  Future<void> clearSeries(String seriesId) async {
    _records.removeWhere((r) => r.seriesId == seriesId);
    await _save();
    notifyListeners();
  }

  /// يمسح كل السجلات (بعد تأكيد المستخدم).
  Future<void> clearAll() async {
    _records.clear();
    await _save();
    notifyListeners();
  }

  /// تصدير كل السجلات JSON نصاً.
  String exportJson() => jsonEncode(_records.map((r) => r.toJson()).toList());

  /// استيراد سجلات من JSON — يعيد عدد السجلات المستوردة.
  Future<int> importJson(String raw) async {
    try {
      final list = jsonDecode(raw) as List;
      var added = 0;
      for (final e in list) {
        if (e is! Map) continue;
        try {
          final r = ChapterRecord.fromJson(Map<String, dynamic>.from(e));
          if (r.seriesId.isEmpty) continue;
          _records.add(r);
          added++;
        } catch (_) {}
      }
      _records.sort((a, b) => b.startedAt.compareTo(a.startedAt));
      await _save();
      notifyListeners();
      return added;
    } catch (_) {
      return 0;
    }
  }
}

/// بديل خفيف لـ SharedPreferences في الاختبارات (ذاكرة فقط).
class _FakePrefs implements SharedPreferences {
  final Map<String, Object> _m = {};

  @override
  Set<String> getKeys() => _m.keys.toSet();

  @override
  Object? get(String key) => _m[key];

  @override
  bool? getBool(String key) => _m[key] as bool?;

  @override
  double? getDouble(String key) => _m[key] as double?;

  @override
  int? getInt(String key) => _m[key] as int?;

  @override
  String? getString(String key) => _m[key] as String?;

  @override
  List<String>? getStringList(String key) => _m[key] as List<String>?;

  @override
  bool containsKey(String key) => _m.containsKey(key);

  @override
  Future<bool> setBool(String key, bool value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setDouble(String key, double value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setInt(String key, int value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setString(String key, String value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> remove(String key) async {
    _m.remove(key);
    return true;
  }

  @override
  Future<bool> clear() async {
    _m.clear();
    return true;
  }

  @override
  Future<bool> commit() async => true;

  @override
  Future<void> reload() async {}
}

// ───────── ويدجتات العرض ─────────

/// شريحة «آخر قراءة» — تعرض آخر سجلّ لعمل معيّن بأمان كامل مع القيم الفارغة.
/// إن لم يوجد سجلّ تُظهر «لم تقرأ هذا العمل بعد».
class LastReadChip extends StatelessWidget {
  const LastReadChip({super.key, required this.record, this.onTap});

  /// آخر سجلّ (قد يكون null).
  final ChapterRecord? record;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final r = record;
    final String text;
    final SIconData icon;
    if (r == null) {
      text = 'لم تقرأ هذا العمل بعد';
      icon = SardIcons.history_rounded;
    } else {
      // وصول آمن للحقول القابلة لأن تكون null (seconds/speedPpm)
      text = formatReadSummary(seconds: r.seconds, speedPpm: r.speedPpm);
      icon = SardIcons.history_rounded;
    }
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: tint(p.accent, 0.10),
            borderRadius: BorderRadius.circular(p.r(0.8)),
            border: Border.all(color: tint(p.accent, 0.25)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SIcon(icon, size: 16, color: p.accent),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  text,
                  style: context.ts(size: 12.5, w: FontWeight.w700, color: p.text),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// بطاقة ملخّص إحصاءات القراءة (الوقت الكلي، الفصول، السرعة، السلسلة).
class ReadingStatsCard extends StatelessWidget {
  const ReadingStatsCard({super.key, required this.store});

  final ReaderProgressStore store;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final items = <(SIconData, String, String)>[
      (SardIcons.history_rounded, 'وقت القراءة', formatDurationArabic(store.totalSeconds)),
      (SardIcons.menu_book_rounded, 'فصول مكتملة', '${store.totalCompletedChapters}'),
      (SardIcons.chrome_reader_mode_rounded, 'صفحات مقروءة', formatCount(store.totalPages)),
      (SardIcons.local_fire_department_rounded, 'سلسلة الأيام', '${store.streak()} يوم'),
    ];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
        boxShadow: softShadow(p),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('إحصاءات القراءة', style: context.ds(size: 17)),
          const SizedBox(height: 4),
          Text(
            'من سجلّ القراءة المحلي — السرعة المتوسطة ${formatSpeedLabel(store.averageSpeedPpm)}',
            style: context.ts(size: 12.5, color: p.textDim),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.6,
            ),
            itemCount: items.length,
            itemBuilder: (context, i) {
              final (icon, label, value) = items[i];
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: p.surfaceHi,
                  borderRadius: BorderRadius.circular(p.r(0.7)),
                ),
                child: Row(
                  children: [
                    SIcon(icon, size: 20, color: p.accent),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(value, style: context.ds(size: 15), maxLines: 1, overflow: TextOverflow.ellipsis),
                          Text(label, style: context.ts(size: 11.5, color: p.textDim), maxLines: 1, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

/// صفّ سجلّ واحد في قائمة السجلّ.
class RecordRow extends StatelessWidget {
  const RecordRow({super.key, required this.record, this.onDelete});

  final ChapterRecord record;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                '${record.chapter}',
                style: context.ds(size: 15, color: p.accent),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.seriesTitle,
                  style: context.ts(size: 14, w: FontWeight.w700),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  '${formatRv2DayLabel(record.startedAt)} · ${formatReadSummary(seconds: record.seconds, speedPpm: record.speedPpm)}',
                  style: context.ts(size: 12, color: p.textDim),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (record.completed)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: tint(p.gold, 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text('مكتمل', style: context.ts(size: 11, w: FontWeight.w700, color: p.gold)),
            ),
          if (onDelete != null) ...[
            const SizedBox(width: 4),
            IconButton(
              onPressed: onDelete,
              icon: SIcon(SardIcons.close_rounded, size: 18, color: p.textDim),
              tooltip: 'حذف السجلّ',
            ),
          ],
        ],
      ),
    );
  }
}

// ───────── شاشة سجلّ القراءة ─────────

/// شاشة سجلّ القراءة v2: الأيام الأخيرة مجمّعة + آخر السجلات + تصدير.
class ReadingHistoryScreen extends StatefulWidget {
  const ReadingHistoryScreen({super.key, required this.store});

  final ReaderProgressStore store;

  @override
  State<ReadingHistoryScreen> createState() => _ReadingHistoryScreenState();
}

class _ReadingHistoryScreenState extends State<ReadingHistoryScreen> {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('سجلّ القراءة'),
        actions: [
          IconButton(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('مسح السجلّ؟'),
                  content: Text('سيُحذف ${widget.store.count} سجلّ قراءة نهائياً.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('إلغاء')),
                    FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('مسح')),
                  ],
                ),
              );
              if (ok == true) {
                await widget.store.clearAll();
                setState(() {});
              }
            },
            tooltip: 'مسح السجلّ',
            icon: SIcon(SardIcons.close_rounded, size: 20, color: p.text),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: widget.store,
        builder: (context, _) {
          final days = widget.store.lastDays(days: 30);
          final recent = widget.store.recent(limit: 30);
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
            children: [
              ReadingStatsCard(store: widget.store),
              const SizedBox(height: 18),
              if (days.isNotEmpty) ...[
                Text('الأيام الأخيرة', style: context.ds(size: 17)),
                const SizedBox(height: 8),
                for (final d in days) _DaySummaryRow(summary: d),
                const SizedBox(height: 18),
              ],
              Text('آخر الجلسات', style: context.ds(size: 17)),
              const SizedBox(height: 8),
              if (recent.isEmpty)
                _EmptyHistory()
              else
                for (final r in recent) ...[
                  RecordRow(
                    record: r,
                    onDelete: () => widget.store.removeRecord(r),
                  ),
                  const SizedBox(height: 8),
                ],
            ],
          );
        },
      ),
    );
  }
}

class _DaySummaryRow extends StatelessWidget {
  const _DaySummaryRow({required this.summary});

  final DayReadingSummary summary;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final maxSeconds = 7200; // ساعتان = الشريط الكامل
    final fraction = (summary.seconds / maxSeconds).clamp(0.0, 1.0).toDouble();
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  formatRv2DayLabel(summary.date),
                  style: context.ts(size: 14, w: FontWeight.w700),
                ),
              ),
              Text(summary.timeLabel, style: context.ts(size: 12.5, w: FontWeight.w800, color: p.accent)),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: fraction,
              minHeight: 5,
              backgroundColor: p.border,
              valueColor: AlwaysStoppedAnimation<Color>(p.accent),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            summary.label,
            style: context.ts(size: 11.5, color: p.textDim),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class _EmptyHistory extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          SIcon(SardIcons.history_rounded, size: 36, color: p.textDim),
          const SizedBox(height: 10),
          Text('لا سجلّ قراءة بعد', style: context.ds(size: 16)),
          const SizedBox(height: 4),
          Text(
            'ابدأ القراءة وسيظهر سجلّ جلساتك هنا مع الوقت والسرعة.',
            style: context.ts(size: 12.5, color: p.textDim),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

/// يبني نص مشاركة لملخص قراءة أسبوعي (للمشاركة الخارجية).
String buildWeeklyShareText({
  required List<DayReadingSummary> days,
  required int totalSeconds,
  required int totalChapters,
}) {
  final buf = StringBuffer('ملخص قراءتي هذا الأسبوع على Senok:\n');
  buf.writeln('• الوقت: ${formatDurationArabic(totalSeconds)}');
  buf.writeln('• الفصول: $totalChapters');
  buf.writeln('• أيام القراءة: ${days.length}');
  if (days.isNotEmpty) {
    final best = days.reduce((a, b) => a.seconds >= b.seconds ? a : b);
    buf.writeln('• أفضل يوم: ${formatRv2DayLabel(best.date)} (${best.timeLabel})');
  }
  return buf.toString().trim();
}

// ───────── مخطط القراءة الأسبوعي ─────────

/// نقطة بيانات واحدة في مخطط الأسبوع (يوم + ثوانٍ).
@immutable
class WeekChartPoint {
  const WeekChartPoint({required this.date, required this.seconds, required this.chapters});

  final DateTime date;
  final int seconds;
  final int chapters;

  double get hours => seconds / 3600;

  String get dayName {
    const names = ['اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت', 'أحد'];
    return names[date.weekday - 1];
  }
}

/// يبني نقاط مخطط آخر 7 أيام من السجلات.
List<WeekChartPoint> buildWeekChartPoints(ReaderProgressStore store, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final today = DateTime(n.year, n.month, n.day);
  final out = <WeekChartPoint>[];
  for (var i = 6; i >= 0; i--) {
    final day = today.subtract(Duration(days: i));
    final list = store.recordsOn(day);
    var secs = 0;
    final chapters = <int>{};
    for (final r in list) {
      secs += r.seconds;
      if (r.completed) chapters.add(r.chapter);
    }
    out.add(WeekChartPoint(date: day, seconds: secs, chapters: chapters.length));
  }
  return out;
}

/// مخطط أعمدة أسبوعي بسيط (رسم مخصص بدون حزم خارجية).
class WeeklyReadingChart extends StatelessWidget {
  const WeeklyReadingChart({super.key, required this.points});

  final List<WeekChartPoint> points;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final maxSeconds = points.fold<int>(0, (a, x) => x.seconds > a ? x.seconds : a);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text('قراءة الأسبوع', style: context.ds(size: 15.5))),
              Text(
                'الإجمالي ${formatDurationArabic(points.fold<int>(0, (a, x) => a + x.seconds))}',
                style: context.ts(size: 12, w: FontWeight.w700, color: p.accent),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 120,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final pt in points)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            pt.seconds > 0 ? formatDurationArabic(pt.seconds) : '',
                            style: context.ts(size: 9.5, w: FontWeight.w700, color: p.textDim),
                            maxLines: 1,
                            overflow: TextOverflow.clip,
                          ),
                          const SizedBox(height: 4),
                          Container(
                            height: (maxSeconds <= 0
                                    ? 4.0
                                    : (pt.seconds / maxSeconds * 72).clamp(4.0, 72.0))
                                .toDouble(),
                            decoration: BoxDecoration(
                              color: pt.seconds > 0 ? p.accent : p.border,
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(pt.dayName, style: context.ts(size: 10.5, color: p.textDim)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'كل عمود يمثل يوماً — الارتفاع يتناسب مع وقت القراءة فيه.',
            style: context.ts(size: 11.5, color: p.textDim),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

/// بطاقة أفضل يوم قراءة في الفترة.
class BestDayCard extends StatelessWidget {
  const BestDayCard({super.key, required this.days});

  final List<DayReadingSummary> days;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (days.isEmpty) return const SizedBox.shrink();
    final best = days.reduce((a, b) => a.seconds >= b.seconds ? a : b);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tint(p.gold, 0.10),
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: tint(p.gold, 0.35)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: tint(p.gold, 0.18),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(child: SIcon(SardIcons.star_rounded, size: 20, color: p.gold)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('أفضل يوم: ${formatRv2DayLabel(best.date)}', style: context.ds(size: 14.5)),
                Text(best.label, style: context.ts(size: 12.5, color: p.textDim)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
