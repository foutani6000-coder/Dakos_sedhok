import 'dart:async';
import 'dart:math' as math;

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../../core/guide/guide_controller.dart';
import '../../core/data/models.dart';
import '../../core/data/download_manager.dart';
import '../../core/data/repository.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/fx.dart';
import '../../widgets/ink_spirit.dart';
import '../../widgets/states.dart';
import 'read_room.dart';
import 'reader_views.dart';
import '../../widgets/sard_icons.dart';
import '../discover/reading_challenges.dart';

/// شاشة القارئ (البنود 13–19)
///  13: تمرير عمودي + تكبير + تحميل مسبق + أشرطة تختفي بالنقر
///  14: أوضاع القراءة (عمودي / يمين←يسار / يسار←يمين) محفوظة في الإعدادات
///  15: شريط تقدّم + الفصل التالي/السابق + قائمة الفصول
///  16: حفظ آخر فصل وصفحة (يقرؤها زر «تابع القراءة» في التفاصيل)
///  17: الصفحات من Repository.pages
///  18: جودة الصور حسب DataMode + connectivity_plus
///  19: سطوع القارئ + إبقاء الشاشة مفتوحة
class ReaderScreen extends StatefulWidget {
  const ReaderScreen({
    super.key,
    required this.series,
    required this.chapters,
    required this.initialChapter,
    this.initialPage = 1,
  });

  final Series series;
  final List<Chapter> chapters;
  final int initialChapter;
  final int initialPage;

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> with WidgetsBindingObserver {
  late final SettingsController _settings;
  late final SardRepository _repo;
  late final List<Chapter> _chs; // تصاعدي حسب الرقم
  late int _idx;

  List<PageSrc>? _pages;

  /// صفحات الفصل التالي بعد تحميلها (للقراءة المتصلة في الوضع العمودي)
  List<PageSrc>? _nextPages;
  late bool _chain;

  /// رقم الفصل الذي يُعرض شريطه العابر عند التحويل السلس
  int? _flashChapter;
  Timer? _flashTimer;
  Object? _error;
  int _startPage = 1;
  int _loadToken = 0;
  int _prefetchedChapter = -1;

  final ValueNotifier<int> _pageV = ValueNotifier<int>(1);
  double? _drag;
  bool _bars = true;

  late ReaderMode _mode;
  late double _bright;
  late bool _awake;
  late int _autoLevel;
  bool _auto = false;
  static const List<double> _autoPx = [50, 110, 200];

  bool _onMobile = false;
  StreamSubscription<List<ConnectivityResult>>? _conn;

  double _px = 1080;
  final Map<String, double> _ratios = {};
  final Map<int, Future<List<PageSrc>>> _cache = {};
  final Set<String> _warm = {};

  final GlobalKey<VerticalReaderState> _vKey = GlobalKey<VerticalReaderState>();
  final GlobalKey<PagedReaderState> _pKey = GlobalKey<PagedReaderState>();
  Timer? _saveTimer;

  /// غرفة القراءة المشتركة (null = غير مفعّلة)
  ReadRoomController? _room;

  // ───────── قياس وقت القراءة ─────────
  Timer? _clockTimer;
  DateTime? _clockStart;

  void _flushReadingTime() {
    final start = _clockStart;
    if (start == null) return;
    final now = DateTime.now();
    _settings.addReadingSeconds(widget.series.id, now.difference(start).inSeconds);
    _clockStart = now;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _clockStart ??= DateTime.now();
    } else {
      _flushReadingTime();
      _clockStart = null; // لا نحسب الوقت والتطبيق في الخلفية
    }
  }

  @override
  void initState() {
    super.initState();
    _settings = context.read<SettingsController>();
    _repo = context.read<SardRepository>();
    _settings.cacheSeries(widget.series);
    WidgetsBinding.instance.addObserver(this);
    _clockStart = DateTime.now();
    _clockTimer = Timer.periodic(const Duration(seconds: 15), (_) => _flushReadingTime());

    final seen = <int>{};
    _chs = widget.chapters.where((c) => seen.add(c.number)).toList()
      ..sort((a, b) => a.number.compareTo(b.number));
    final i = _chs.indexWhere((c) => c.number == widget.initialChapter);
    _idx = i < 0 ? 0 : i;

    _mode = _settings.readerMode;
    _bright = _settings.readerBrightness;
    _awake = _settings.keepAwake;
    _chain = _settings.chainChapters;
    _autoLevel = _settings.readerAutoSpeed;
    _applyAwake();

    final c = Connectivity();
    c.checkConnectivity().then(_onConn).catchError((_) {});
    _conn = c.onConnectivityChanged.listen(_onConn);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _load(_idx, page: widget.initialPage);
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final mq = MediaQuery.of(context);
    _px = mq.size.width * mq.devicePixelRatio;
  }

  @override
  void dispose() {
    _flashTimer?.cancel();
    _clockTimer?.cancel();
    _flushReadingTime();
    _clockStart = null;
    WidgetsBinding.instance.removeObserver(this);
    _saveTimer?.cancel();
    _saveNow();
    _conn?.cancel();
    _room?.dispose();
    _pageV.dispose();
    WakelockPlus.disable();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  // ───────── الاتصال والجودة (البند 18) ─────────

  void _onConn(List<ConnectivityResult> r) {
    final mobile = r.contains(ConnectivityResult.mobile) &&
        !r.contains(ConnectivityResult.wifi) &&
        !r.contains(ConnectivityResult.ethernet);
    if (mobile != _onMobile && mounted) setState(() => _onMobile = mobile);
  }

  /// هل تُعرض الصور بجودة مخفّضة الآن؟
  bool get _low {
    switch (_settings.dataMode) {
      case DataMode.hd:
        return false;
      case DataMode.always:
        return true;
      case DataMode.mobile:
        return _onMobile;
    }
  }

  /// هل نسمح بتحميل مسبق موسّع الآن؟ (حسب إعداد المستخدم ونوع الاتصال)
  bool get _deepPrefetch {
    switch (_settings.prefetchMode) {
      case PrefetchMode.off:
        return false;
      case PrefetchMode.wifi:
        return !_onMobile;
      case PrefetchMode.always:
        return true;
    }
  }

  // ───────── التحميل (البنود 13 و17) ─────────

  Future<List<PageSrc>> _fetch(int number) => _cache.putIfAbsent(number, () async {
    final offline = await DownloadManager.instance.offlinePages(widget.series.id, number);
    if (offline != null) return offline;
    return _repo.pages(widget.series.id, number);
  });

  Future<void> _load(int idx, {int page = 1}) async {
    final token = ++_loadToken;
    final number = _chs[idx].number;
    setState(() {
      _auto = false;
      _idx = idx;
      _pages = null;
      _nextPages = null;
      _prefetchedChapter = -1;
      _error = null;
      _startPage = page;
    });
    _pageV.value = page;
    try {
      final pages = await _fetch(number);
      if (!mounted || token != _loadToken) return;
      final start = page.clamp(1, math.max(1, pages.length)).toInt();
      setState(() {
        _pages = pages;
        _startPage = start;
      });
      _pageV.value = start;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && token == _loadToken) _onPage(start);
      });
    } catch (e) {
      _cache.remove(number);
      if (!mounted || token != _loadToken) return;
      setState(() => _error = e);
    }
  }

  void _warmPage(PageSrc s) {
    if (s.isMock) return;
    final key = pageUrl(s, _low);
    if (!_warm.add(key)) return;
    precacheImage(
      pageProvider(s, _low, _px),
      context,
      onError: (e, st) => _warm.remove(key),
    );
  }

  /// تحميل مسبق لثلاث صفحات قادمة
  void _prefetchAhead(int page) {
    final pages = _pages;
    if (pages == null) return;
    final ahead = _deepPrefetch ? 6 : 3;
    for (var k = 0; k < ahead; k++) {
      final i = page + k; // الفهرس التالي لأن page يبدأ من 1
      if (i >= pages.length) break;
      _warmPage(pages[i]);
    }
  }

  /// عند تجاوز 70% من الفصل نحمّل قائمة الفصل التالي وأول صفحتين منه
  void _prefetchNextChapter() {
    final n = _idx + 1;
    if (n >= _chs.length || _prefetchedChapter == n) return;
    _prefetchedChapter = n;
    final number = _chs[n].number;
    _fetch(number).then((pages) {
      if (!mounted) return;
      for (final s in pages.take(_deepPrefetch ? 8 : 2)) {
        _warmPage(s);
      }
      // القراءة المتصلة: نُلحق صفحات الفصل التالي بالقائمة الحالية
      if (_idx + 1 == n && pages.isNotEmpty && !identical(_nextPages, pages)) {
        setState(() => _nextPages = pages);
      }
    }).catchError((_) {
      _cache.remove(number);
    });
  }

  // ───────── التقدّم (البنود 15 و16) ─────────

  void _onPage(int page) {
    final total = _pages?.length ?? 0;
    if (total == 0) return;
    final pg = page.clamp(1, total).toInt();
    _pageV.value = pg;
    _room?.report(_chs[_idx].number, pg, total);
    _prefetchAhead(pg);
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 500), _saveNow);
    if (pg >= total) {
      _settings.markRead(widget.series.id, _chs[_idx].number);
      ChallengeStore.i.recordChapter();
    }
    if (pg >= (total * (_deepPrefetch ? 0.4 : 0.7)).ceil()) _prefetchNextChapter();
  }

  void _saveNow() {
    final pages = _pages;
    if (pages == null || pages.isEmpty) return;
    _settings.saveProgress(
      widget.series.id,
      _chs[_idx].number,
      _pageV.value,
      pages.length,
    );
  }

  void _jump(int page) {
    _vKey.currentState?.jumpToPage(page);
    _pKey.currentState?.jumpToPage(page);
  }

  /// وصلت القراءة إلى أول صفحة من الفصل التالي المُلحق: نحوّله إلى الفصل الحالي
  /// دون إعادة تحميل، فيستمر التمرير (والتمرير التلقائي) بلا انقطاع.
  void _enterNext() {
    final np = _nextPages;
    if (!mounted || np == null || !_hasNext) return;
    _saveTimer?.cancel();
    _settings.markRead(widget.series.id, _chs[_idx].number);
    _loadToken++;
    setState(() {
      _idx = _idx + 1;
      _pages = np;
      _nextPages = null;
      _startPage = 1;
      _error = null;
      _flashChapter = _chs[_idx].number;
    });
    _prefetchedChapter = -1;
    _pageV.value = 1;
    HapticFeedback.lightImpact();
    _flashTimer?.cancel();
    _flashTimer = Timer(const Duration(milliseconds: 2200), () {
      if (mounted) setState(() => _flashChapter = null);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _onPage(1);
    });
  }

  bool get _hasNext => _idx < _chs.length - 1;
  bool get _hasPrev => _idx > 0;

  void _go(int delta) {
    final n = _idx + delta;
    if (n < 0 || n >= _chs.length) return;
    _saveTimer?.cancel();
    _saveNow();
    if (!_bars) _setBars(true);
    _load(n);
  }

  // ───────── الأشرطة والنظام ─────────

  void _setBars(bool v) {
    if (_bars == v) return;
    setState(() => _bars = v);
    SystemChrome.setEnabledSystemUIMode(
      v ? SystemUiMode.edgeToEdge : SystemUiMode.immersiveSticky,
    );
  }

  void _toggleBars() => _setBars(!_bars);
  void _hideBars() => _setBars(false);

  void _applyAwake() {
    if (_awake) {
      WakelockPlus.enable();
    } else {
      WakelockPlus.disable();
    }
  }

  // ───────── الانزلاق عند الحافة والتمرير التلقائي ─────────

  void _toast(String m) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 2)));
  }

  /// +1 / -1 من السحب عند الحافة
  void _onEdge(int d) {
    if (d > 0 ? _hasNext : _hasPrev) {
      _go(d);
    } else {
      _toast(d > 0 ? 'هذا آخر فصل متاح' : 'هذا أول فصل');
    }
  }

  void _toggleAuto() {
    if (_mode != ReaderMode.vertical) {
      _toast('التمرير التلقائي متاح في الوضع العمودي فقط');
      return;
    }
    final v = _vKey.currentState;
    if (v == null) return;
    if (_auto) {
      v.stopAuto();
      setState(() => _auto = false);
    } else {
      v.startAuto(_autoPx[_autoLevel]);
      setState(() => _auto = true);
      _hideBars();
    }
  }

  void _setMode(ReaderMode m) {
    if (m == _mode) return;
    final cur = _pageV.value;
    setState(() {
      _auto = false;
      _mode = m;
      _startPage = cur;
    });
    _settings.setReaderMode(m);
  }

  // ───────── البناء ─────────

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _content(context)),
          // سطوع القارئ: تعتيم داخلي
          Positioned.fill(
            child: IgnorePointer(
              child: ColoredBox(color: tint(Colors.black, (1 - _bright) * 0.85)),
            ),
          ),
          _topBar(context),
          _bottomBar(context),
          _roomChip(context),
          _chapterFlash(context),
        ],
      ),
    );
  }

  // ───────── القراءة المشتركة ─────────

  /// كبسولة موضع الصديق: تنزل تحت الشريط العلوي، وتصعد حين تختفي الأشرطة
  Widget _roomChip(BuildContext context) {
    final c = _room;
    if (c == null) return const SizedBox.shrink();
    final top = MediaQuery.of(context).padding.top;
    return AnimatedPositionedDirectional(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      top: _bars ? top + 66 : top + 10,
      start: 14,
      child: ReadRoomChip(ctrl: c, onTap: _openRoom),
    );
  }

  Future<void> _openRoom() async {
    final existing = _room;
    if (existing != null) {
      await _showRoom(existing);
      return;
    }
    final room = await showReadRoomInvite(context, series: widget.series, chapter: _chs[_idx].number);
    if (room == null || !mounted) return;
    final c = ReadRoomController(_repo, room)..start();
    final total = _pages?.length ?? 0;
    if (total > 0) c.report(_chs[_idx].number, _pageV.value, total);
    setState(() => _room = c);
    await _showRoom(c);
  }

  Future<void> _showRoom(ReadRoomController c) async {
    if (!mounted) return;
    await showReadRoomSheet(context, ctrl: c, onJumpToFriend: _jumpToFriend, onLeave: _leaveRoom);
  }

  /// ينقلك إلى الصفحة (والفصل) التي يقرؤها صديقك الآن
  void _jumpToFriend() {
    final r = _room?.room;
    if (r == null || !r.friendKnown) return;
    final i = _chs.indexWhere((c) => c.number == r.friendChapter);
    if (i < 0) {
      _toast('فصل صديقك غير متاح لديك');
      return;
    }
    if (i == _idx) {
      _jump(r.friendPage);
    } else {
      _saveTimer?.cancel();
      _saveNow();
      _load(i, page: r.friendPage);
    }
  }

  Future<void> _leaveRoom() async {
    final c = _room;
    if (c == null) return;
    setState(() => _room = null);
    await c.leave();
    c.dispose();
  }

  /// شريط عابر يعلن الفصل الجديد عند التحويل السلس
  Widget _chapterFlash(BuildContext context) {
    final p = context.pal;
    final top = MediaQuery.of(context).padding.top;
    return Positioned(
      top: top + 70,
      left: 0,
      right: 0,
      child: IgnorePointer(
        child: AnimatedSlide(
          offset: _flashChapter == null ? const Offset(0, -0.8) : Offset.zero,
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
          child: AnimatedOpacity(
            opacity: _flashChapter == null ? 0 : 1,
            duration: const Duration(milliseconds: 250),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [p.accent, Color.lerp(p.accent, p.gold, 0.5)!]),
                  borderRadius: BorderRadius.circular(99),
                  boxShadow: [BoxShadow(color: tint(p.accent, 0.5), blurRadius: 18)],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SIcon(SardIcons.auto_stories_rounded, size: 17, color: p.onAccent),
                    const SizedBox(width: 7),
                    Text(
                      'الفصل ${_flashChapter ?? ''}',
                      style: context.ts(size: 13, w: FontWeight.w800, color: p.onAccent),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _content(BuildContext context) {
    final p = context.pal;
    if (_error != null) {
      return ErrorState(onRetry: () => _load(_idx, page: _startPage));
    }
    final pages = _pages;
    if (pages == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const InkSpirit(size: 76),
            const SizedBox(height: 14),
            Text('جارٍ تحميل الفصل ${_chs[_idx].number}…',
                style: context.ts(size: 14, color: p.textDim)),
          ],
        ),
      );
    }
    if (pages.isEmpty) {
      return const EmptyState(
        title: 'لا توجد صفحات في هذا الفصل',
        subtitle: 'ربما لم يُرفع بعد. جرّب فصلاً آخر.',
      );
    }

    final low = _low;
    final Widget view;
    switch (_mode) {
      case ReaderMode.vertical:
        view = VerticalReader(
          key: _vKey,
          pages: pages,
          low: low,
          widthPx: _px,
          ratios: _ratios,
          initialPage: _startPage,
          onPage: _onPage,
          onTap: _toggleBars,
          onUserScroll: _hideBars,
          footer: _endCard(expand: false),
          onEdge: _onEdge,
          canNext: _hasNext,
          canPrev: _hasPrev,
          nextPages: (_chain && _hasNext) ? _nextPages : null,
          divider: (_chain && _hasNext)
              ? _ChapterDivider(
                  from: _chs[_idx].number,
                  to: _chs[_idx + 1].number,
                  title: _chs[_idx + 1].title,
                )
              : null,
          onEnterNext: _enterNext,
          onAutoChanged: (on) {
            if (mounted && _auto != on) setState(() => _auto = on);
          },
        );
        break;
      case ReaderMode.pagedRtl:
      case ReaderMode.pagedLtr:
        view = PagedReader(
          key: _pKey,
          pages: pages,
          low: low,
          widthPx: _px,
          ratios: _ratios,
          initialPage: _startPage,
          ltr: _mode == ReaderMode.pagedLtr,
          onPage: _onPage,
          onTap: _toggleBars,
          footer: _endCard(expand: true),
          onEdge: _onEdge,
          canNext: _hasNext,
          canPrev: _hasPrev,
        );
        break;
    }
    return FadeSlide(dy: 0, child: view);
  }

  Widget _endCard({required bool expand}) {
    final card = _EndCard(
      chapter: _chs[_idx].number,
      hasNext: _hasNext,
      hasPrev: _hasPrev,
      onNext: () => _go(1),
      onPrev: () => _go(-1),
      onExit: () => Navigator.of(context).pop(),
    );
    if (expand) return SizedBox.expand(child: Center(child: SingleChildScrollView(child: card)));
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 460),
      child: Center(child: card),
    );
  }

  // ───────── الشريط العلوي (كبسولات عائمة ملوّنة) ─────────

  BoxDecoration _floatDeco(SardPalette p, {Color? edge, double rf = 1.2}) {
    final r = p.r(rf).clamp(14.0, 34.0).toDouble();
    return BoxDecoration(
      color: tint(p.surface, p.glass ? 0.82 : 0.97),
      borderRadius: BorderRadius.circular(r),
      border: Border.all(color: edge ?? p.border, width: p.borderW),
      boxShadow: [
        BoxShadow(
          color: tint(edge ?? p.accent, p.glow > 0 ? 0.30 * p.glow : 0.0),
          blurRadius: 18,
        ),
        BoxShadow(color: tint(Colors.black, 0.25), blurRadius: 16, offset: const Offset(0, 6)),
      ],
    );
  }

  Widget _topBar(BuildContext context) {
    final p = context.pal;
    final top = MediaQuery.of(context).padding.top;
    final ch = _chs[_idx];
    final extra = (ch.title.isNotEmpty && ch.title != 'فصل ${ch.number}') ? ' · ${ch.title}' : '';
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !_bars,
        child: AnimatedSlide(
          offset: _bars ? Offset.zero : const Offset(0, -1.2),
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
          child: AnimatedOpacity(
            opacity: _bars ? 1 : 0,
            duration: const Duration(milliseconds: 220),
            child: Padding(
              padding: EdgeInsets.fromLTRB(14, top + 8, 14, 0),
              child: Row(
                children: [
                  _CircleBtn(
                    icon: SardIcons.arrow_back_rounded,
                    color: p.text,
                    deco: _floatDeco(p),
                    onTap: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 48,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: _floatDeco(p, rf: 1),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            widget.series.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: context.ts(size: 13.5, w: FontWeight.w700),
                          ),
                          Text(
                            'فصل ${ch.number}$extra',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: context.ts(size: 11, w: FontWeight.w600, color: p.accent),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _CircleBtn(
                    icon: SardIcons.groups_rounded,
                    color: const Color(0xFFE0457B),
                    deco: _floatDeco(p, edge: tint(const Color(0xFFE0457B), _room == null ? 0.6 : 1.0)),
                    onTap: _openRoom,
                  ),
                  const SizedBox(width: 10),
                  _CircleBtn(
                    icon: SardIcons.tune_rounded,
                    color: const Color(0xFFF5A524),
                    deco: _floatDeco(p, edge: tint(const Color(0xFFF5A524), 0.6)),
                    onTap: () => GuideController.instance.run('btn.reader_settings', _openSettings),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ───────── الشريط السفلي (بطاقة عائمة) ─────────

  Widget _bottomBar(BuildContext context) {
    final p = context.pal;
    final bottom = MediaQuery.of(context).padding.bottom;
    const blue = Color(0xFF3B9EFF);
    const green = Color(0xFF2FCB7A);
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !_bars,
        child: AnimatedSlide(
          offset: _bars ? Offset.zero : const Offset(0, 1.2),
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
          child: AnimatedOpacity(
            opacity: _bars ? 1 : 0,
            duration: const Duration(milliseconds: 220),
            child: Padding(
              padding: EdgeInsets.fromLTRB(14, 0, 14, bottom + 12),
              child: Container(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
                decoration: _floatDeco(p, rf: 1.4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ValueListenableBuilder<int>(
                      valueListenable: _pageV,
                      builder: (context, page, _) {
                        final total = _pages?.length ?? 0;
                        final shown = _drag?.round() ?? page;
                        return Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: tint(p.accent, 0.16),
                                borderRadius: BorderRadius.circular(99),
                              ),
                              child: Text(
                                total == 0 ? '—' : '$shown / $total',
                                style: context.ts(size: 12.5, w: FontWeight.w800, color: p.accent),
                              ),
                            ),
                            Expanded(
                              child: SliderTheme(
                                data: SliderTheme.of(context).copyWith(
                                  trackHeight: 5,
                                  activeTrackColor: p.accent,
                                  inactiveTrackColor: p.border,
                                  thumbColor: p.accent,
                                  overlayColor: Colors.transparent,
                                  disabledActiveTrackColor: p.border,
                                  disabledThumbColor: p.border,
                                ),
                                child: Slider(
                                  value: total <= 1
                                      ? 1
                                      : (_drag ?? page.toDouble()).clamp(1.0, total.toDouble()).toDouble(),
                                  min: 1,
                                  max: total <= 1 ? 1 : total.toDouble(),
                                  divisions: total > 1 ? total - 1 : null,
                                  onChanged: total > 1 ? (v) => setState(() => _drag = v) : null,
                                  onChangeEnd: (v) {
                                    setState(() => _drag = null);
                                    _jump(v.round());
                                    _onPage(v.round());
                                  },
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _CircleBtn(
                          icon: SardIcons.chevron_right_rounded,
                          color: _hasPrev ? p.text : p.textDim,
                          deco: BoxDecoration(
                            color: p.surfaceHi,
                            shape: BoxShape.circle,
                            border: Border.all(color: p.border, width: p.borderW),
                          ),
                          size: 46,
                          onTap: _hasPrev ? () => GuideController.instance.run('btn.reader_nav', () => _go(-1)) : null,
                        ),
                        const SizedBox(width: 10),
                        _CircleBtn(
                          icon: _auto ? SardIcons.pause_rounded : SardIcons.play_arrow_rounded,
                          color: _mode == ReaderMode.vertical ? green : p.textDim,
                          deco: BoxDecoration(
                            color: tint(green, _auto ? 0.32 : 0.14),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: tint(green, _mode == ReaderMode.vertical ? 0.7 : 0.2),
                              width: p.borderW,
                            ),
                          ),
                          size: 46,
                          onTap: () => GuideController.instance.run('btn.reader_auto', _toggleAuto),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Pressable(
                            onTap: () => GuideController.instance.run('btn.reader_chapters', _openChapters),
                            child: Container(
                              height: 46,
                              decoration: BoxDecoration(
                                color: tint(blue, 0.18),
                                borderRadius: BorderRadius.circular(99),
                                border: Border.all(color: tint(blue, 0.6), width: p.borderW),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const SIcon(SardIcons.format_list_bulleted_rounded, size: 19, color: blue),
                                  const SizedBox(width: 8),
                                  Text('الفصول',
                                      style: context.ts(size: 13.5, w: FontWeight.w700, color: p.text)),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        _CircleBtn(
                          icon: SardIcons.chevron_left_rounded,
                          color: _hasNext ? p.onAccent : p.textDim,
                          deco: BoxDecoration(
                            color: _hasNext ? p.accent : p.surfaceHi,
                            shape: BoxShape.circle,
                            boxShadow: _hasNext && p.glow > 0
                                ? [BoxShadow(color: tint(p.accent, 0.5 * p.glow), blurRadius: 14)]
                                : null,
                          ),
                          size: 46,
                          onTap: _hasNext ? () => GuideController.instance.run('btn.reader_nav', () => _go(1)) : null,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ───────── النوافذ المنبثقة ─────────

  ShapeBorder _sheetShape(SardPalette p) => RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(_rad(p, 1.5, 22, 34))),
        side: BorderSide(color: p.border, width: p.borderW),
      );

  Color _sheetBg(SardPalette p) => p.glass ? tint(p.surface, 0.93) : p.surface;

  void _openChapters() {
    final p = context.pal;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: _sheetBg(p),
      isScrollControlled: true,
      shape: _sheetShape(p),
      builder: (ctx) => _ChapterSheet(
        chapters: _chs,
        current: _chs[_idx].number,
        read: _settings.readChapters(widget.series.id),
        onPick: (i) {
          Navigator.of(ctx).pop();
          if (i != _idx) {
            _saveNow();
            _load(i);
          }
        },
      ),
    );
  }

  void _openSettings() {
    final p = context.pal;
    const blue = Color(0xFF3B9EFF);
    const green = Color(0xFF2FCB7A);
    const amber = Color(0xFFF5A524);
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: _sheetBg(p),
      isScrollControlled: true,
      shape: _sheetShape(p),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          final q = ctx.pal;
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(top: 12, bottom: 18),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sheetHandle(q),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
                    child: Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: tint(q.accent, 0.16),
                            borderRadius: BorderRadius.circular(_rad(q, 0.7, 12, 18)),
                            border: Border.all(color: tint(q.accent, 0.5), width: q.borderW),
                          ),
                          child: SIcon(SardIcons.tune_rounded, size: 22, color: q.accent),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text('إعدادات القارئ', style: ctx.ts(size: 20, w: FontWeight.w800)),
                        ),
                      ],
                    ),
                  ),
                  _SetCard(
                    icon: SardIcons.chrome_reader_mode_rounded,
                    color: blue,
                    title: 'وضع القراءة',
                    note: 'العمودي مناسب للمانهوا، وصفحة بصفحة (يمين ← يسار) مناسب للمانغا. '
                        'انقر طرفي الشاشة لقلب الصفحة، والنقر المزدوج للتكبير.',
                    child: _SegRow(
                      labels: const ['عمودي', 'يمين ← يسار', 'يسار ← يمين'],
                      index: _mode.index,
                      color: blue,
                      onChanged: (i) {
                        _setMode(ReaderMode.values[i]);
                        setSheet(() {});
                      },
                    ),
                  ),
                  _SetCard(
                    icon: SardIcons.play_circle_rounded,
                    color: green,
                    title: 'التمرير التلقائي',
                    note: 'اضغط زر التشغيل في الشريط السفلي للتمرير التلقائي (الوضع العمودي). يتوقف عند لمس الشاشة.',
                    child: _SegRow(
                      labels: const ['بطيء', 'متوسط', 'سريع'],
                      index: _autoLevel,
                      color: green,
                      onChanged: (i) {
                        setState(() => _autoLevel = i);
                        setSheet(() {});
                        _settings.setReaderAutoSpeed(i);
                        if (_auto) _vKey.currentState?.startAuto(_autoPx[i]);
                      },
                    ),
                  ),
                  _SetCard(
                    icon: SardIcons.layers_rounded,
                    color: green,
                    title: 'القراءة المتصلة',
                    note: 'في الوضع العمودي يتابع الفصل التالي مباشرة بعد نهاية الفصل دون خروج أو ضغط أي زر.',
                    trailing: Switch(
                      value: _chain,
                      activeColor: green,
                      onChanged: (v) {
                        setState(() => _chain = v);
                        setSheet(() {});
                        _settings.setChainChapters(v);
                      },
                    ),
                  ),
                  _SetCard(
                    icon: SardIcons.light_mode_rounded,
                    color: amber,
                    title: 'سطوع القارئ',
                    trailing: Text(
                      '${(_bright * 100).round()}%',
                      style: ctx.ts(size: 13, w: FontWeight.w800, color: amber),
                    ),
                    child: Row(
                      children: [
                        SIcon(SardIcons.brightness_low_rounded, color: q.textDim, size: 20),
                        Expanded(
                          child: SliderTheme(
                            data: SliderTheme.of(ctx).copyWith(
                              trackHeight: 4,
                              activeTrackColor: amber,
                              inactiveTrackColor: q.border,
                              thumbColor: amber,
                              overlayColor: Colors.transparent,
                            ),
                            child: Slider(
                              value: _bright,
                              min: 0.25,
                              max: 1,
                              onChanged: (v) {
                                setState(() => _bright = v);
                                setSheet(() {});
                              },
                              onChangeEnd: _settings.setReaderBrightness,
                            ),
                          ),
                        ),
                        SIcon(SardIcons.brightness_high_rounded, color: q.text, size: 20),
                      ],
                    ),
                  ),
                  _SetCard(
                    icon: SardIcons.screen_lock_portrait_rounded,
                    color: q.accent,
                    title: 'إبقاء الشاشة مفتوحة',
                    note: 'تبقى الشاشة مضاءة أثناء القراءة ولا تنطفئ تلقائياً.',
                    trailing: Switch(
                      value: _awake,
                      activeColor: q.accent,
                      onChanged: (v) {
                        setState(() => _awake = v);
                        setSheet(() {});
                        _settings.setKeepAwake(v);
                        _applyAwake();
                      },
                    ),
                  ),
                  _SetCard(
                    icon: _low ? SardIcons.data_saver_on_rounded : SardIcons.hd_rounded,
                    color: blue,
                    title: 'جودة الصور',
                    note: _low
                        ? 'جودة الصور الآن: مخفّضة (توفير البيانات). تُغيَّر من الإعدادات.'
                        : 'جودة الصور الآن: كاملة. تُغيَّر من الإعدادات ← توفير البيانات.',
                    trailing: _chip(ctx, _low ? SardIcons.data_saver_on_rounded : SardIcons.hd_rounded,
                        _low ? 'مخفّضة' : 'كاملة', blue),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ───────── مساعدات الأشكال (تتبع الثيم) ─────────

/// زاوية من الثيم مع حدّ أدنى وأعلى
double _rad(SardPalette p, double f, double lo, double hi) =>
    p.r(f).clamp(lo, hi).toDouble();

/// توهّج اختياري حسب شدة الثيم
List<BoxShadow>? _glowOf(SardPalette p, Color c, [double a = 0.4]) {
  if (p.glow <= 0) return null;
  return [BoxShadow(color: tint(c, a * p.glow), blurRadius: 18)];
}

Widget _sheetHandle(SardPalette p) => Center(
      child: Container(
        width: 42,
        height: 4,
        decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4)),
      ),
    );

/// شارة صغيرة بأيقونة ونص
Widget _chip(BuildContext context, SIconData icon, String label, Color c) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: tint(c, 0.16),
      borderRadius: BorderRadius.circular(99),
      border: Border.all(color: tint(c, 0.45), width: context.pal.borderW),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SIcon(icon, size: 14, color: c),
        const SizedBox(width: 5),
        Text(label, style: context.ts(size: 11.5, w: FontWeight.w700, color: c)),
      ],
    ),
  );
}

/// بطاقة قسم في ورقة الإعدادات
class _SetCard extends StatelessWidget {
  const _SetCard({
    required this.icon,
    required this.color,
    required this.title,
    this.note,
    this.trailing,
    this.child,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String? note;
  final Widget? trailing;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.glass ? tint(p.surfaceHi, 0.72) : p.surfaceHi,
        borderRadius: BorderRadius.circular(_rad(p, 1.1, 14, 26)),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: tint(color, 0.18),
                  borderRadius: BorderRadius.circular(_rad(p, 0.6, 10, 16)),
                  border: Border.all(color: tint(color, 0.5), width: p.borderW),
                  boxShadow: _glowOf(p, color, 0.45),
                ),
                child: SIcon(icon, size: 20, color: color),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(title, style: context.ts(size: 14.5, w: FontWeight.w700)),
              ),
              if (trailing != null) trailing!,
            ],
          ),
          if (note != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                note!,
                style: context.ts(size: 12, color: p.textDim, height: 1.7),
              ),
            ),
          if (child != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: child!,
            ),
        ],
      ),
    );
  }
}

/// مبدّل خيارات بسيط داخل البطاقات
class _SegRow extends StatelessWidget {
  const _SegRow({
    required this.labels,
    required this.index,
    required this.color,
    required this.onChanged,
  });

  final List<String> labels;
  final int index;
  final Color color;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final r = _rad(p, 0.8, 10, 20);
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(r + 4),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 240),
                  curve: Curves.easeOutCubic,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: i == index ? tint(color, 0.22) : Colors.transparent,
                    borderRadius: BorderRadius.circular(r),
                    border: Border.all(
                      color: i == index ? tint(color, 0.7) : Colors.transparent,
                      width: p.borderW,
                    ),
                  ),
                  child: Text(
                    labels[i],
                    style: context.ts(
                      size: 12.5,
                      w: i == index ? FontWeight.w800 : FontWeight.w500,
                      color: i == index ? p.text : p.textDim,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ───────── مكوّنات القارئ ─────────

/// بطاقة نهاية الفصل (تظهر بعد آخر صفحة)
class _EndCard extends StatelessWidget {
  const _EndCard({
    required this.chapter,
    required this.hasNext,
    required this.hasPrev,
    required this.onNext,
    required this.onPrev,
    required this.onExit,
  });

  final int chapter;
  final bool hasNext;
  final bool hasPrev;
  final VoidCallback onNext;
  final VoidCallback onPrev;
  final VoidCallback onExit;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    const blue = Color(0xFF3B9EFF);
    final r = _rad(p, 1.0, 14, 26);

    Widget action({
      required String label,
      required SIconData icon,
      required Color color,
      required VoidCallback tap,
      Color? solidFg,
    }) {
      final solid = solidFg != null;
      final fg = solidFg ?? p.text;
      return Pressable(
        onTap: tap,
        child: Container(
          height: 52,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: solid ? color : tint(color, 0.14),
            borderRadius: BorderRadius.circular(r),
            border: Border.all(color: solid ? color : tint(color, 0.6), width: p.borderW),
            boxShadow: solid ? _glowOf(p, color, 0.55) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SIcon(icon, size: 20, color: solid ? fg : color),
              const SizedBox(width: 8),
              Text(label, style: context.ts(size: 14, w: FontWeight.w700, color: fg)),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0.6, end: 1),
            duration: const Duration(milliseconds: 600),
            curve: Curves.elasticOut,
            builder: (context, v, child) => Transform.scale(scale: v, child: child),
            child: Container(
              width: 76,
              height: 76,
              decoration: BoxDecoration(
                color: p.accent,
                shape: BoxShape.circle,
                border: Border.all(color: tint(p.onAccent, 0.35), width: p.borderW + 1),
                boxShadow: [
                  BoxShadow(color: tint(p.accent, 0.25 + 0.2 * p.glow), blurRadius: 30),
                ],
              ),
              child: SIcon(SardIcons.check_rounded, size: 40, color: p.onAccent),
            ),
          ),
          const SizedBox(height: 20),
          FadeSlide(
            index: 1,
            dy: 12,
            child: Column(
              children: [
                Text('انتهى الفصل $chapter', style: context.ts(size: 22, w: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(
                  hasNext ? 'جاهز للفصل التالي؟' : 'وصلت إلى آخر فصل متاح حالياً.',
                  style: context.ts(size: 13.5, color: p.textDim),
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          FadeSlide(
            index: 2,
            dy: 12,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (hasPrev || hasNext)
                  Row(
                    children: [
                      if (hasPrev)
                        Expanded(
                          child: action(
                            label: 'السابق',
                            icon: SardIcons.arrow_forward_rounded,
                            color: blue,
                            tap: onPrev,
                          ),
                        ),
                      if (hasPrev && hasNext) const SizedBox(width: 12),
                      if (hasNext)
                        Expanded(
                          child: action(
                            label: 'الفصل التالي',
                            icon: SardIcons.arrow_back_rounded,
                            color: p.accent,
                            tap: onNext,
                            solidFg: p.onAccent,
                          ),
                        ),
                    ],
                  ),
                if (hasPrev || hasNext) const SizedBox(height: 12),
                action(
                  label: 'الخروج',
                  icon: SardIcons.close_rounded,
                  color: p.textDim,
                  tap: onExit,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// قائمة الفصول (تصاعدية داخلياً، وتُعرض الأحدث أولاً)
class _ChapterSheet extends StatefulWidget {
  const _ChapterSheet({
    required this.chapters,
    required this.current,
    required this.read,
    required this.onPick,
  });

  final List<Chapter> chapters;
  final int current;
  final Set<int> read;

  /// الفهرس داخل القائمة التصاعدية
  final ValueChanged<int> onPick;

  @override
  State<_ChapterSheet> createState() => _ChapterSheetState();
}

class _ChapterSheetState extends State<_ChapterSheet> {
  static const double _item = 78;
  late final List<int> _order; // فهارس بترتيب العرض (الأحدث أولاً)
  late final ScrollController _ctrl;

  @override
  void initState() {
    super.initState();
    _order = List.generate(widget.chapters.length, (i) => widget.chapters.length - 1 - i);
    final pos = _order.indexWhere((i) => widget.chapters[i].number == widget.current);
    _ctrl = ScrollController(initialScrollOffset: math.max(0, pos - 2) * _item);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    const green = Color(0xFF2FCB7A);
    const amber = Color(0xFFF5A524);
    final mq = MediaQuery.of(context);
    final h = mq.size.height * 0.74;
    final total = widget.chapters.length;
    final readCount = widget.chapters.where((c) => widget.read.contains(c.number)).length;
    final r = _rad(p, 0.9, 14, 24);

    return SizedBox(
      height: h,
      child: Column(
        children: [
          const SizedBox(height: 12),
          _sheetHandle(p),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 14),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: tint(p.accent, 0.16),
                    borderRadius: BorderRadius.circular(_rad(p, 0.7, 12, 18)),
                    border: Border.all(color: tint(p.accent, 0.5), width: p.borderW),
                    boxShadow: _glowOf(p, p.accent, 0.4),
                  ),
                  child: SIcon(SardIcons.format_list_bulleted_rounded, size: 22, color: p.accent),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('قائمة الفصول', style: context.ts(size: 19, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text('أنت الآن في الفصل ${widget.current}',
                          style: context.ts(size: 12, color: p.textDim)),
                    ],
                  ),
                ),
                _chip(context, SardIcons.menu_book_rounded, '$total فصل', p.accent),
                const SizedBox(width: 6),
                _chip(context, SardIcons.done_all_rounded, '$readCount مقروء', green),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              controller: _ctrl,
              itemExtent: _item,
              padding: EdgeInsets.fromLTRB(16, 0, 16, 12 + mq.padding.bottom),
              itemCount: _order.length,
              itemBuilder: (context, i) {
                final idx = _order[i];
                final c = widget.chapters[idx];
                final isCur = c.number == widget.current;
                final isRead = widget.read.contains(c.number);
                final fg = isCur ? p.onAccent : (isRead ? p.textDim : p.text);
                final tileBg = isCur
                    ? tint(p.onAccent, 0.2)
                    : (isRead ? tint(p.textDim, 0.14) : tint(p.accent, 0.14));
                final tileFg = isCur ? p.onAccent : (isRead ? p.textDim : p.accent);
                final hasTitle = c.title.isNotEmpty && c.title != 'فصل ${c.number}';
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Pressable(
                    onTap: () => widget.onPick(idx),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: isCur
                            ? p.accent
                            : (p.glass ? tint(p.surfaceHi, 0.72) : p.surfaceHi),
                        borderRadius: BorderRadius.circular(r),
                        border: Border.all(
                          color: isCur ? p.accent : p.border,
                          width: p.borderW,
                        ),
                        boxShadow: isCur ? _glowOf(p, p.accent, 0.5) : null,
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            decoration: BoxDecoration(
                              color: tileBg,
                              borderRadius: BorderRadius.circular(_rad(p, 0.7, 10, 16)),
                            ),
                            child: FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text('${c.number}',
                                  style: context.ts(size: 18, w: FontWeight.w800, color: tileFg)),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(hasTitle ? c.title : 'فصل ${c.number}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: context.ts(size: 14, w: FontWeight.w700, color: fg)),
                                const SizedBox(height: 2),
                                Text(
                                  '${c.pages} صفحة · ${c.date}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: context.ts(
                                    size: 11.5,
                                    color: isCur ? tint(p.onAccent, 0.75) : p.textDim,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (c.isNew) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: tint(amber, isCur ? 0.95 : 0.2),
                                borderRadius: BorderRadius.circular(99),
                                border: Border.all(color: tint(amber, 0.7), width: p.borderW),
                              ),
                              child: Text(
                                'جديد',
                                style: context.ts(
                                  size: 10.5,
                                  w: FontWeight.w800,
                                  color: isCur ? Colors.black : amber,
                                ),
                              ),
                            ),
                          ],
                          if (isCur) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: tint(p.onAccent, 0.2),
                                borderRadius: BorderRadius.circular(99),
                              ),
                              child: Text(
                                'تقرأ الآن',
                                style: context.ts(size: 10.5, w: FontWeight.w800, color: p.onAccent),
                              ),
                            ),
                          ] else if (isRead) ...[
                            const SizedBox(width: 6),
                            Container(
                              width: 24,
                              height: 24,
                              decoration: BoxDecoration(
                                color: tint(green, 0.18),
                                shape: BoxShape.circle,
                                border: Border.all(color: tint(green, 0.6), width: p.borderW),
                              ),
                              child: const SIcon(SardIcons.check_rounded, size: 15, color: green),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// زر دائري عائم (يستعمل في شريطي القارئ)
/// فاصل أنيق بين فصلين متصلين: ختم الإنجاز + الفصل التالي.
class _ChapterDivider extends StatelessWidget {
  const _ChapterDivider({required this.from, required this.to, required this.title});
  final int from;
  final int to;
  final String title;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final named = title.isNotEmpty && title != 'فصل $to';
    return Container(
      width: double.infinity,
      color: p.bg,
      padding: const EdgeInsets.fromLTRB(28, 44, 28, 44),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [p.accent, Color.lerp(p.accent, p.gold, 0.6)!],
              ),
              boxShadow: [BoxShadow(color: tint(p.accent, 0.45), blurRadius: 22)],
            ),
            child: SIcon(SardIcons.check_rounded, size: 30, color: p.onAccent),
          ),
          const SizedBox(height: 14),
          Text('انتهى الفصل $from', style: context.ts(size: 13, w: FontWeight.w700, color: p.textDim)),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(child: Container(height: 1, color: tint(p.accent, 0.3))),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('يتبع', style: context.ts(size: 11.5, w: FontWeight.w700, color: p.accent)),
              ),
              Expanded(child: Container(height: 1, color: tint(p.accent, 0.3))),
            ],
          ),
          const SizedBox(height: 22),
          Text('الفصل $to', style: context.ds(size: 24)),
          if (named) ...[
            const SizedBox(height: 6),
            Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: context.ts(size: 13, color: p.textDim),
            ),
          ],
        ],
      ),
    );
  }
}

class _CircleBtn extends StatelessWidget {
  const _CircleBtn({
    required this.icon,
    required this.color,
    required this.deco,
    required this.onTap,
    this.size = 48,
  });
  final SIconData icon;
  final Color color;
  final BoxDecoration deco;
  final VoidCallback? onTap;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: deco,
        child: SIcon(icon, size: size * 0.5, color: color),
      ),
    );
  }
}
