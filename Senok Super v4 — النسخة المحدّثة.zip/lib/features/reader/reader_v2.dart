// ──────────────────────────────────────────────────────────────────────────
//  القارئ v2 — قارئ احترافي: أوضاع عمودي/صفحات، مناطق نقر، وضع لوحات،
//  تمرير تلقائي، إشارات مرجعية، سجلّ جلسات، إعدادات لكل عمل.
//  يُفتح بعمل وفصوله؛ يحمّل الصفحات من SardRepository (أو بيانات تجريبية).
// ──────────────────────────────────────────────────────────────────────────
import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../../core/data/mock_data.dart';
import '../../core/data/models.dart';
import '../../core/data/repository.dart';
import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/cover_art.dart';
import '../../widgets/sard_icons.dart';
import '../discover/reading_challenges.dart';
import 'panel_mode.dart';
import 'reader_bookmarks.dart';
import 'reader_gestures.dart';
import 'reader_progress.dart';
import 'reader_settings.dart';
import 'reading_goals.dart';

/// القارئ الاحترافي v2.
///
/// [onChapterFinished] يُنادى عند إكمال فصل (لربط التحديات/المكافآت من الخارج
/// دون اعتماد متقاطع بين الوحدات).
class ReaderV2Screen extends StatefulWidget {
  const ReaderV2Screen({
    super.key,
    required this.series,
    required this.chapters,
    required this.initialChapter,
    this.initialPage = 1,
    this.onChapterFinished,
  });

  final Series series;
  final List<Chapter> chapters;
  final int initialChapter;
  final int initialPage;
  final void Function(Series series, int chapter)? onChapterFinished;

  @override
  State<ReaderV2Screen> createState() => _ReaderV2ScreenState();
}

class _ReaderV2ScreenState extends State<ReaderV2Screen> with WidgetsBindingObserver {
  // ── المخازن ──
  late ReaderV2Settings _settings;
  late ReaderProgressStore _progressStore;
  late ReaderBookmarkStore _bookmarkStore;
  late ReaderGestureStore _gestureStore;
  late PanelModeStore _panelStore;
  SettingsController? _appSettings;

  bool _storesReady = false;

  // ── حالة الفصل والصفحة ──
  late int _chapterNumber;
  late Chapter _chapter;
  List<PageSrc>? _pages;
  String? _pagesError;
  final Map<int, Future<List<PageSrc>>> _pageCache = {};

  // عمودي
  final ScrollController _vScroll = ScrollController();
  // صفحات
  PageController? _pageController;
  int _page = 1; // 1-based
  int get _totalPages => _pages?.length ?? _chapter.pages;

  // واجهة
  bool _uiVisible = true;
  bool _showTapZones = false;
  Timer? _uiTimer;
  Timer? _autoTimer;

  // جلسة القراءة الحالية
  ReadingSession? _session;

  // وضع اللوحات
  PanelNavigator? _panelNav;

  // مؤشر التحميل المسبق للفصل التالي
  bool _warmingNext = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _chapterNumber = widget.initialChapter;
    _chapter = _chapterByNumber(_chapterNumber) ?? widget.chapters.first;
    _page = widget.initialPage.clamp(1, 1 << 20).toInt();
    _initStores();
  }

  Future<void> _initStores() async {
    try {
      _settings = await ReaderV2Settings.load();
    } catch (_) {
      _settings = ReaderV2Settings.testInstance();
    }
    try {
      _progressStore = await ReaderProgressStore.load();
    } catch (_) {
      _progressStore = ReaderProgressStore.testInstance();
    }
    try {
      _bookmarkStore = await ReaderBookmarkStore.load();
    } catch (_) {
      _bookmarkStore = ReaderBookmarkStore.testInstance();
    }
    try {
      _gestureStore = await ReaderGestureStore.load();
    } catch (_) {
      _gestureStore = ReaderGestureStore.testInstance();
    }
    try {
      _panelStore = await PanelModeStore.load();
    } catch (_) {
      _panelStore = PanelModeStore.testInstance();
    }
    if (!mounted) return;
    setState(() => _storesReady = true);
    _applyKeepAwake();
    await _loadChapter(_chapterNumber, initialPage: _page);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _appSettings ??= _readAppSettings();
  }

  SettingsController? _readAppSettings() {
    try {
      return context.read<SettingsController>();
    } catch (_) {
      return null;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _uiTimer?.cancel();
    _autoTimer?.cancel();
    _vScroll.dispose();
    _pageController?.dispose();
    _finishSession(completed: false);
    WakelockPlus.disable();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _session?.pause();
      _stopAutoScroll();
    } else if (state == AppLifecycleState.resumed) {
      _session?.resume();
    }
  }

  // ───────── الفصول والصفحات ─────────

  Chapter? _chapterByNumber(int n) {
    for (final c in widget.chapters) {
      if (c.number == n) return c;
    }
    return null;
  }

  int get _chapterIndex => widget.chapters.indexWhere((c) => c.number == _chapterNumber);

  Chapter? get _nextChapter {
    final i = _chapterIndex;
    if (i < 0 || i + 1 >= widget.chapters.length) return null;
    return widget.chapters[i + 1];
  }

  Chapter? get _prevChapter {
    final i = _chapterIndex;
    if (i <= 0) return null;
    return widget.chapters[i - 1];
  }

  Future<List<PageSrc>> _fetchPages(int number) {
    return _pageCache.putIfAbsent(number, () async {
      try {
        final repo = context.read<SardRepository>();
        return await repo.pages(widget.series.id, number);
      } catch (_) {
        return MockData.pagesFor(widget.series.id, number);
      }
    });
  }

  Future<void> _loadChapter(int number, {int initialPage = 1}) async {
    final chapter = _chapterByNumber(number);
    if (chapter == null) return;
    _stopAutoScroll();
    _finishSession(completed: false);
    setState(() {
      _chapterNumber = number;
      _chapter = chapter;
      _pages = null;
      _pagesError = null;
      _page = initialPage.clamp(1, 1 << 20).toInt();
      _panelNav = null;
    });
    try {
      final pages = await _fetchPages(number);
      if (!mounted) return;
      setState(() {
        _pages = pages;
        if (_page > pages.length && pages.isNotEmpty) _page = pages.length;
      });
      _startSession();
      _buildPanelPlans();
      _warmNextChapter();
      _restoreProgress();
    } catch (e) {
      if (!mounted) return;
      setState(() => _pagesError = 'تعذّر تحميل صفحات الفصل — تحقق من الاتصال وحاول مجدداً.');
    }
  }

  /// يبني خطط اللوحات من أبعاد الصفحات (تقريبية: ويبتون طويل).
  void _buildPanelPlans() {
    if (!_settings.panelModeFor(widget.series.id)) return;
    final settings = _panelStore.settings;
    final aspects = List<double>.filled(_totalPages, 0.45);
    final plans = splitChapterIntoPanels(
      pageAspects: aspects,
      strategy: settings.strategy,
      maxPanels: settings.maxPanels,
      overlap: settings.overlap,
    );
    setState(() {
      _panelNav = PanelNavigator(plans: plans)..jumpTo(_page - 1, 0);
    });
  }

  /// تحميل مسبق خفيف لصفحات الفصل التالي.
  Future<void> _warmNextChapter() async {
    final next = _nextChapter;
    if (next == null || _warmingNext) return;
    _warmingNext = true;
    try {
      await _fetchPages(next.number);
    } catch (_) {}
    _warmingNext = false;
  }

  /// يستعيد آخر موضع محفوظ في هذا الفصل (إن وُجد ولم يُمرَّر initialPage صريح).
  void _restoreProgress() {
    final saved = _appSettings?.progressOf(widget.series.id);
    if (saved == null) return;
    if (saved.chapter != _chapterNumber) return;
    if (widget.initialPage > 1) return; // المستخدم طلب صفحة محددة
    final target = saved.page.clamp(1, _totalPages).toInt();
    if (target <= 1) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _goToPage(target, animate: false);
    });
  }

  // ───────── جلسة القراءة ─────────

  void _startSession() {
    _session = ReadingSession(
      series: widget.series,
      chapter: _chapterNumber,
      totalPages: _totalPages,
      startPage: _page,
    );
    _session!.onPage(_page);
  }

  /// يغلق الجلسة الحالية ويحفظ سجلّها (دون إكمال ما لم يُطلب).
  void _finishSession({required bool completed}) {
    final s = _session;
    if (s == null) return;
    _session = null;
    if (completed) s.markFinished();
    if (s.seconds < 3 && s.pagesRead <= 0) return; // جلسة قصيرة جداً تُهمل
    unawaited(_progressStore.addSession(s));
  }

  /// يُنادى عند إكمال فصل: حفظ التقدّم + تمييز كمقروء + خطّاف خارجي.
  Future<void> _onChapterFinished() async {
    _finishSession(completed: true);
    final app = _appSettings;
    if (app != null) {
      app.markRead(widget.series.id, _chapterNumber);
      ChallengeStore.i.recordChapter();
      app.saveProgress(widget.series.id, _chapterNumber, _totalPages, _totalPages);
    }
    // خطّاف خارجي (التحديات/المكافآت) — يربطه التطبيق من الأعلى.
    widget.onChapterFinished?.call(widget.series, _chapterNumber);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('أكملت الفصل $_chapterNumber من «${widget.series.title}» — أحسنت!')),
    );
  }

  // ───────── إبقاء الشاشة مضاءة ─────────

  void _applyKeepAwake() {
    if (!_storesReady) return;
    final keep = _settings.keepAwake;
    if (keep) {
      WakelockPlus.enable();
    } else {
      WakelockPlus.disable();
    }
  }

  // ───────── التنقّل بين الصفحات والفصول ─────────

  bool get _isVertical => _settings.modeFor(widget.series.id) == ReaderMode.vertical;

  bool get _isRtl => _settings.modeFor(widget.series.id) != ReaderMode.pagedLtr;

  Future<void> _goToPage(int page, {bool animate = true}) async {
    final total = _totalPages;
    if (total <= 0) return;
    final target = page.clamp(1, total).toInt();
    setState(() => _page = target);
    _session?.onPage(target);
    _panelNav?.jumpTo(target - 1, 0);
    if (_isVertical) {
      if (_vScroll.hasClients) {
        // تقدير ارتفاع الصفحة من ارتفاع الشاشة (الصفحات متساوية تقريباً)
        final h = MediaQuery.of(context).size.height * 0.9;
        final offset = (target - 1) * h;
        if (animate) {
          await _vScroll.animateTo(
            offset,
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOut,
          );
        } else {
          _vScroll.jumpTo(offset);
        }
      }
    } else {
      _pageController ??= PageController(initialPage: target - 1);
      if (_pageController!.hasClients) {
        if (animate) {
          await _pageController!.animateToPage(
            target - 1,
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOut,
          );
        } else {
          _pageController!.jumpToPage(target - 1);
        }
      }
    }
    _saveProgressThrottled();
  }

  Timer? _progressTimer;

  /// حفظ التقدّم بلا إفراط (مرة كل ثانيتين كحد أقصى أثناء التنقل).
  void _saveProgressThrottled() {
    if (_progressTimer?.isActive == true) return;
    _progressTimer = Timer(const Duration(seconds: 2), () {
      _appSettings?.saveProgress(widget.series.id, _chapterNumber, _page, _totalPages);
    });
  }

  /// الصفحة التالية — أو الفصل التالي إن كنا في آخر صفحة.
  Future<void> _nextPage() async {
    if (_panelNav != null && _settings.panelModeFor(widget.series.id)) {
      if (_panelNav!.next()) {
        setState(() => _page = _panelNav!.page + 1);
        _session?.onPage(_page);
        return;
      }
    }
    if (_page < _totalPages) {
      await _goToPage(_page + 1);
      return;
    }
    // آخر صفحة: إكمال الفصل ثم الفصل التالي
    await _onChapterFinished();
    final next = _nextChapter;
    if (next != null) {
      await _loadChapter(next.number);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('هذا آخر فصل متاح في العمل حالياً.')),
      );
    }
  }

  /// الصفحة السابقة — أو الفصل السابق إن كنا في أول صفحة.
  Future<void> _prevPage() async {
    if (_panelNav != null && _settings.panelModeFor(widget.series.id)) {
      if (_panelNav!.prev()) {
        setState(() => _page = _panelNav!.page + 1);
        _session?.onPage(_page);
        return;
      }
    }
    if (_page > 1) {
      await _goToPage(_page - 1);
      return;
    }
    final prev = _prevChapter;
    if (prev != null) {
      await _loadChapter(prev.number, initialPage: 1 << 20);
      // الانتقال لآخر صفحة في الفصل السابق
      await _goToPage(_totalPages, animate: false);
    }
  }

  Future<void> _goNextChapter() async {
    final next = _nextChapter;
    if (next == null) return;
    await _onChapterFinished();
    await _loadChapter(next.number);
  }

  Future<void> _goPrevChapter() async {
    final prev = _prevChapter;
    if (prev == null) return;
    await _loadChapter(prev.number);
  }

  // ───────── الإيماءات ─────────

  /// تنفيذ إجراء إيماءة.
  Future<void> _runAction(ReaderGestureAction action) async {
    switch (action) {
      case ReaderGestureAction.none:
        break;
      case ReaderGestureAction.nextPage:
        await _nextPage();
        break;
      case ReaderGestureAction.prevPage:
        await _prevPage();
        break;
      case ReaderGestureAction.toggleUi:
        _toggleUi();
        break;
      case ReaderGestureAction.openChapters:
        _showChaptersSheet();
        break;
      case ReaderGestureAction.openSettings:
        _showSettingsSheet();
        break;
      case ReaderGestureAction.toggleBookmark:
        await _toggleBookmark();
        break;
      case ReaderGestureAction.togglePanelMode:
        await _togglePanelMode();
        break;
      case ReaderGestureAction.toggleAutoScroll:
        _toggleAutoScroll();
        break;
      case ReaderGestureAction.nextChapter:
        await _goNextChapter();
        break;
      case ReaderGestureAction.prevChapter:
        await _goPrevChapter();
        break;
    }
  }

  void _onTap(Offset local, Size size) {
    if (!_gestureStore.settings.tapZonesEnabled) {
      _toggleUi();
      return;
    }
    final action = _gestureStore.settings.actionForTap(local, size);
    unawaited(_runAction(action));
  }

  void _onDoubleTap() {
    final action = _gestureStore.settings.doubleTap;
    switch (action) {
      case ReaderDoubleTapAction.zoom:
        _toggleUi();
        break;
      case ReaderDoubleTapAction.nextPage:
        unawaited(_nextPage());
        break;
      case ReaderDoubleTapAction.prevPage:
        unawaited(_prevPage());
        break;
      case ReaderDoubleTapAction.toggleUi:
        _toggleUi();
        break;
      case ReaderDoubleTapAction.none:
        break;
    }
  }

  Future<void> _onLongPress() async {
    final action = _gestureStore.settings.longPress;
    switch (action) {
      case ReaderLongPressAction.bookmark:
        await _toggleBookmark();
        break;
      case ReaderLongPressAction.openSettings:
        _showSettingsSheet();
        break;
      case ReaderLongPressAction.openChapters:
        _showChaptersSheet();
        break;
      case ReaderLongPressAction.sharePage:
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('مشاركة «${widget.series.title}» — الفصل $_chapterNumber، صفحة $_page')),
        );
        break;
      case ReaderLongPressAction.none:
        break;
    }
  }

  void _toggleUi() {
    setState(() => _uiVisible = !_uiVisible);
    _uiTimer?.cancel();
    if (_uiVisible) {
      _uiTimer = Timer(const Duration(seconds: 4), () {
        if (mounted) setState(() => _uiVisible = false);
      });
    }
  }

  // ───────── التمرير التلقائي ─────────

  void _toggleAutoScroll() {
    if (_autoTimer != null) {
      _stopAutoScroll();
      return;
    }
    final speed = _settings.autoSpeed;
    if (_isVertical) {
      _autoTimer = Timer.periodic(const Duration(milliseconds: 100), (_) {
        if (!_vScroll.hasClients) return;
        final next = _vScroll.offset + speed.pixelsPerSecond / 10;
        if (next >= _vScroll.position.maxScrollExtent) {
          _stopAutoScroll();
          unawaited(_nextPage());
          return;
        }
        _vScroll.jumpTo(next);
      });
    } else {
      _autoTimer = Timer.periodic(
        Duration(milliseconds: (speed.secondsPerPage * 1000).round()),
        (_) => unawaited(_nextPage()),
      );
    }
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('التمرير التلقائي يعمل — سرعة ${speed.label}')),
    );
  }

  void _stopAutoScroll() {
    _autoTimer?.cancel();
    _autoTimer = null;
    if (mounted) setState(() {});
  }

  bool get _autoScrolling => _autoTimer != null;

  // ───────── الإشارات المرجعية ─────────

  bool get _bookmarkedHere =>
      _storesReady && _bookmarkStore.hasAt(widget.series.id, _chapterNumber, _page);

  Future<void> _toggleBookmark() async {
    final added = await _bookmarkStore.toggle(
      series: widget.series,
      chapter: _chapterNumber,
      page: _page,
      totalPages: _totalPages,
    );
    if (!mounted) return;
    if (added) {
      final res = await showBookmarkEditor(context);
      if (res != null) {
        final b = _bookmarkStore.at(widget.series.id, _chapterNumber, _page);
        if (b != null) await _bookmarkStore.update(b.id, note: res.$1, color: res.$2);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أُضيفت الإشارة المرجعية')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أُزيلت الإشارة المرجعية')),
      );
    }
    setState(() {});
  }

  Future<void> _togglePanelMode() async {
    final cur = _settings.panelModeFor(widget.series.id);
    final ov = _settings.overridesFor(widget.series.id);
    await _settings.setOverrides(
      widget.series.id,
      ov.copyWith(panelMode: !cur),
    );
    if (!cur) {
      _buildPanelPlans();
    } else {
      setState(() {
        _panelNav = null;
        });
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(!cur ? 'وضع اللوحات مفعّل' : 'وضع اللوحات متوقف')),
    );
  }

  // ───────── الأوراق (Sheets) ─────────

  void _showSettingsSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.85,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, controller) => ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          child: ReaderSettingsScreen(
            seriesId: widget.series.id,
            seriesTitle: widget.series.title,
          ),
        ),
      ),
    ).then((_) {
      _applyKeepAwake();
      setState(() {});
    });
  }

  void _showChaptersSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final p = ctx.pal;
        final read = _appSettings;
        return Container(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.75),
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(width: 44, height: 4, decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4))),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(child: Text('فصول «${widget.series.title}»', style: ctx.ds(size: 17))),
                    Text('${widget.chapters.length} فصلاً', style: ctx.ts(size: 12.5, color: p.textDim)),
                  ],
                ),
              ),
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  itemCount: widget.chapters.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 6),
                  itemBuilder: (ctx, i) {
                    final c = widget.chapters[i];
                    final isCurrent = c.number == _chapterNumber;
                    final isRead = read?.readChapters(widget.series.id).contains(c.number) ?? false;
                    return Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () {
                          Navigator.of(ctx).pop();
                          unawaited(_loadChapter(c.number));
                        },
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                          decoration: BoxDecoration(
                            color: isCurrent ? tint(p.accent, 0.12) : p.surfaceHi,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: isCurrent ? tint(p.accent, 0.4) : Colors.transparent),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  color: isCurrent ? p.accent : tint(p.accent, 0.12),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Center(
                                  child: Text(
                                    '${c.number}',
                                    style: ctx.ds(size: 14, color: isCurrent ? p.onAccent : p.accent),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      c.title.isEmpty ? 'الفصل ${c.number}' : c.title,
                                      style: ctx.ts(size: 13.5, w: isCurrent ? FontWeight.w800 : FontWeight.w500),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    Text(
                                      '${c.pages} صفحة · ${c.date}',
                                      style: ctx.ts(size: 11.5, color: p.textDim),
                                    ),
                                  ],
                                ),
                              ),
                              if (isRead)
                                SIcon(SardIcons.check_rounded, size: 17, color: const Color(0xFF0F9D75)),
                              if (c.isNew)
                                Container(
                                  margin: const EdgeInsets.only(right: 6),
                                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: tint(p.gold, 0.18),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text('جديد', style: ctx.ts(size: 10.5, w: FontWeight.w800, color: p.gold)),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showBookmarksSheet() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => BookmarksScreen(
          seriesId: widget.series.id,
          onJump: (b) {
            Navigator.of(context).pop();
            if (b.chapter != _chapterNumber) {
              unawaited(_loadChapter(b.chapter, initialPage: b.page));
            } else {
              unawaited(_goToPage(b.page));
            }
          },
        ),
      ),
    );
  }

  void _showGoalsSheet() {
    final app = _appSettings;
    if (app == null) return;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ReadingGoalsScreen(settings: app, progress: _progressStore),
      ),
    );
  }

  /// ورقة إحصاءات القراءة: بطاقة الإحصاءات + آخر الجلسات + السجلّ الكامل.
  void _showStatsSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final p = ctx.pal;
        return DraggableScrollableSheet(
          initialChildSize: 0.85,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          expand: false,
          builder: (_, controller) {
            return Container(
              decoration: BoxDecoration(
                color: p.bg,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: ListView(
                controller: controller,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
                children: [
                  Center(
                    child: Container(width: 44, height: 4, decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4))),
                  ),
                  const SizedBox(height: 14),
                  Text('إحصاءات قراءتي', style: ctx.ds(size: 19)),
                  const SizedBox(height: 12),
                  ReadingStatsCard(store: _progressStore),
                  const SizedBox(height: 12),
                  Text('آخر الجلسات', style: ctx.ds(size: 16)),
                  const SizedBox(height: 8),
                  for (final r in _progressStore.recent(limit: 8)) ...[
                    RecordRow(record: r),
                    const SizedBox(height: 8),
                  ],
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.of(ctx).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => ReadingHistoryScreen(store: _progressStore),
                          ),
                        );
                      },
                      icon: SIcon(SardIcons.history_rounded, size: 18, color: p.text),
                      label: const Text('عرض السجلّ الكامل'),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showGestureGuide() {
    unawaited(showGestureGuide(context, _gestureStore.settings));
  }

  // ───────── البناء ─────────

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (!_storesReady) {
      return Scaffold(
        backgroundColor: p.bg,
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final bg = _settings.backgroundFor(widget.series.id);
    final brightness = _settings.brightnessFor(widget.series.id);
    final isVertical = _isVertical;

    return Scaffold(
      backgroundColor: bg.bgColor,
      body: Stack(
        children: [
          // جسم القراءة
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapUp: (d) {
              final box = context.findRenderObject() as RenderBox?;
              if (box == null) return;
              final local = box.globalToLocal(d.globalPosition);
              _onTap(local, box.size);
            },
            onDoubleTap: _onDoubleTap,
            onLongPress: _onLongPress,
            child: _pagesError != null
                ? _ErrorView(message: _pagesError!, onRetry: () => _loadChapter(_chapterNumber, initialPage: _page))
                : _pages == null
                    ? const Center(child: CircularProgressIndicator())
                    : isVertical
                        ? _buildVerticalBody()
                        : _buildPagedBody(),
          ),
          // تعتيم السطوع (فوق الصفحات، تحت الواجهة)
          if (brightness < 1)
            IgnorePointer(
              child: Container(
                color: Colors.black.withAlpha(((1 - brightness) * 0.75 * 255).round()),
              ),
            ),
          // طبقة مناطق النقر التوضيحية
          if (_showTapZones)
            Positioned.fill(
              child: TapZoneOverlay(
                settings: _gestureStore.settings,
                onZoneTap: (z) => unawaited(_runAction(_gestureStore.settings.actionForZone(z))),
              ),
            ),
          // الواجهة العلوية والسفلية
          if (_uiVisible) ...[
            Positioned(top: 0, left: 0, right: 0, child: _buildTopBar()),
            Positioned(bottom: 0, left: 0, right: 0, child: _buildBottomBar()),
          ],
          // مؤشر اللوحات
          if (_panelNav != null && _settings.panelModeFor(widget.series.id))
            Positioned(
              bottom: _uiVisible ? 92 : 24,
              left: 0,
              right: 0,
              child: Center(child: PanelIndicator(navigator: _panelNav!)),
            ),
        ],
      ),
    );
  }

  Widget _buildVerticalBody() {
    final pages = _pages!;
    return NotificationListener<ScrollNotification>(
      onNotification: (n) {
        if (n is ScrollUpdateNotification && _vScroll.hasClients) {
          final h = MediaQuery.of(context).size.height * 0.9;
          if (h > 0) {
            final est = (_vScroll.offset / h).floor() + 1;
            final clamped = est.clamp(1, _totalPages).toInt();
            if (clamped != _page) {
              setState(() => _page = clamped);
              _session?.onPage(clamped);
              if (clamped >= _totalPages) {
                _saveProgressThrottled();
              }
            }
          }
        }
        return false;
      },
      child: ListView.builder(
        controller: _vScroll,
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 8,
          bottom: 110,
        ),
        itemCount: pages.length + 1,
        itemBuilder: (context, i) {
          if (i >= pages.length) return _buildEndCard();
          return _ReaderPageImage(
            src: pages[i],
            series: widget.series,
            pageNumber: i + 1,
            totalPages: pages.length,
            background: _settings.backgroundFor(widget.series.id),
          );
        },
      ),
    );
  }

  Widget _buildPagedBody() {
    final pages = _pages!;
    _pageController ??= PageController(initialPage: (_page - 1).clamp(0, pages.length - 1).toInt());
    return PageView.builder(
      controller: _pageController,
      reverse: _isRtl,
      itemCount: pages.length + 1,
      onPageChanged: (i) {
        final next = (i + 1).clamp(1, pages.length + 1).toInt();
        setState(() => _page = next > pages.length ? pages.length : next);
        _session?.onPage(_page);
        _panelNav?.jumpTo(_page - 1, 0);
        _saveProgressThrottled();
      },
      itemBuilder: (context, i) {
        if (i >= pages.length) return _buildEndCard();
        return Center(
          child: _ReaderPageImage(
            src: pages[i],
            series: widget.series,
            pageNumber: i + 1,
            totalPages: pages.length,
            background: _settings.backgroundFor(widget.series.id),
          ),
        );
      },
    );
  }

  /// بطاقة نهاية الفصل: آخر قراءة + الفصل التالي + اختصارات.
  Widget _buildEndCard() {
    final p = context.pal;
    final record = _progressStore.lastRecord(widget.series.id);
    final next = _nextChapter;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1.1)),
        border: Border.all(color: p.border),
        boxShadow: softShadow(p),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: tint(const Color(0xFF0F9D75), 0.14),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Icon(Icons.check, size: 22, color: Color(0xFF0F9D75)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('نهاية الفصل $_chapterNumber', style: context.ds(size: 17)),
                    Text(
                      '«${widget.series.title}»',
                      style: context.ts(size: 12.5, color: p.textDim),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // وصول آمن: record قد يكون null — الشريحة تتعامل مع ذلك داخلياً
          LastReadChip(record: record),
          const SizedBox(height: 14),
          if (next != null)
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => unawaited(_goNextChapter()),
                icon: SIcon(SardIcons.play_arrow_rounded, size: 18, color: p.onAccent),
                label: Text('الفصل التالي: ${next.title.isEmpty ? 'الفصل ${next.number}' : next.title}'),
              ),
            )
          else
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('العودة إلى العمل'),
              ),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _showBookmarksSheet,
                  icon: SIcon(SardIcons.bookmark_rounded, size: 17, color: p.text),
                  label: const Text('إشاراتي'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _showGoalsSheet,
                  icon: SIcon(SardIcons.star_rounded, size: 17, color: p.text),
                  label: const Text('أهدافي'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _showStatsSheet,
              icon: SIcon(SardIcons.history_rounded, size: 17, color: p.text),
              label: const Text('إحصاءات قراءتي'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    final p = context.pal;
    final bg = _settings.backgroundFor(widget.series.id);
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top,
        bottom: 8,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [tint(Colors.black, 0.65), tint(Colors.black, 0)],
        ),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () {
              _finishSession(completed: _page >= _totalPages);
              Navigator.of(context).pop();
            },
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
            tooltip: 'رجوع',
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.series.title,
                  style: context.ds(size: 15.5, color: Colors.white),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  'الفصل $_chapterNumber · صفحة $_page من $_totalPages',
                  style: context.ts(size: 11.5, color: tint(Colors.white, 0.8)),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => setState(() => _showTapZones = !_showTapZones),
            icon: SIcon(SardIcons.visibility_rounded, size: 20, color: Colors.white),
            tooltip: 'إظهار مناطق النقر',
          ),
          IconButton(
            onPressed: _showGestureGuide,
            icon: SIcon(SardIcons.chrome_reader_mode_rounded, size: 20, color: Colors.white),
            tooltip: 'دليل الإيماءات',
          ),
          IconButton(
            onPressed: () => _togglePanelMode(),
            icon: SIcon(
              SardIcons.layers_rounded,
              size: 20,
              color: _settings.panelModeFor(widget.series.id) ? bg.bgColor == Colors.black ? Colors.white : p.gold : Colors.white,
            ),
            tooltip: 'وضع اللوحات',
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar() {
    final p = context.pal;
    final fraction = _totalPages <= 1 ? 0.0 : ((_page - 1) / (_totalPages - 1)).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).padding.bottom + 10,
        top: 6,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [tint(Colors.black, 0.72), tint(Colors.black, 0)],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Row(
              children: [
                Text('$_page', style: context.ts(size: 12.5, w: FontWeight.w800, color: Colors.white)),
                const SizedBox(width: 8),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: fraction,
                      minHeight: 4,
                      backgroundColor: tint(Colors.white, 0.3),
                      valueColor: AlwaysStoppedAnimation<Color>(p.gold),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text('$_totalPages', style: context.ts(size: 12.5, w: FontWeight.w700, color: tint(Colors.white, 0.85))),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _BottomAction(
                icon: SardIcons.menu_book_rounded,
                label: 'الفصول',
                onTap: _showChaptersSheet,
              ),
              _BottomAction(
                icon: SardIcons.bookmark_rounded,
                label: 'إشارة',
                active: _bookmarkedHere,
                onTap: () => unawaited(_toggleBookmark()),
              ),
              _BottomAction(
                icon: _autoScrolling ? SardIcons.pause_rounded : SardIcons.play_arrow_rounded,
                label: 'تلقائي',
                active: _autoScrolling,
                onTap: _toggleAutoScroll,
              ),
              _BottomAction(
                icon: SardIcons.star_rounded,
                label: 'أهدافي',
                onTap: _showGoalsSheet,
              ),
              _BottomAction(
                icon: SardIcons.settings_rounded,
                label: 'الإعدادات',
                onTap: _showSettingsSheet,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// زر في الشريط السفلي للقارئ.
class _BottomAction extends StatelessWidget {
  const _BottomAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
  });

  final SIconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final color = active ? const Color(0xFFE9B44C) : Colors.white;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SIcon(icon, size: 21, color: color),
              const SizedBox(height: 3),
              Text(
                label,
                style: context.ts(size: 10.5, w: active ? FontWeight.w800 : FontWeight.w500, color: color),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// صورة صفحة واحدة: شبكية أو تجريبية (mock) مع رقم الصفحة.
class _ReaderPageImage extends StatelessWidget {
  const _ReaderPageImage({
    required this.src,
    required this.series,
    required this.pageNumber,
    required this.totalPages,
    required this.background,
  });

  final PageSrc src;
  final Series series;
  final int pageNumber;
  final int totalPages;
  final ReaderBackground background;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (src.isMock || !src.url.startsWith('http')) {
      // صفحة تجريبية: لوحة ملوّنة بلون العمل مع رقم الصفحة
      final tone = seriesTone(series);
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        height: MediaQuery.of(context).size.height * 0.72,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [tint(tone, 0.85), tint(tone, 0.45)],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: background.pageBorderColor),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                series.title,
                style: context.ds(size: 20, color: Colors.white),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                'صفحة $pageNumber من $totalPages',
                style: context.ts(size: 13, w: FontWeight.w700, color: tint(Colors.white, 0.85)),
              ),
              const SizedBox(height: 4),
              Text(
                'صفحة تجريبية — تُستبدل بصورة الفصل عند توفرها',
                style: context.ts(size: 11.5, color: tint(Colors.white, 0.7)),
              ),
            ],
          ),
        ),
      );
    }
    return CachedNetworkImage(
      imageUrl: src.url,
      fit: BoxFit.fitWidth,
      width: double.infinity,
      placeholder: (context, _) => Container(
        height: 320,
        alignment: Alignment.center,
        child: CircularProgressIndicator(color: p.accent),
      ),
      errorWidget: (context, _, __) => Container(
        height: 320,
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: p.border),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SIcon(SardIcons.refresh_rounded, size: 28, color: p.textDim),
              const SizedBox(height: 8),
              Text('تعذّر تحميل الصفحة $pageNumber', style: context.ts(size: 13, color: p.textDim)),
            ],
          ),
        ),
      ),
    );
  }
}

/// عرض خطأ تحميل الفصل مع زر إعادة المحاولة.
class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SIcon(SardIcons.refresh_rounded, size: 40, color: p.textDim),
            const SizedBox(height: 14),
            Text(message, style: context.ts(size: 14, color: p.textDim), textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
          ],
        ),
      ),
    );
  }
}

// ───────── مؤشر الجلسة الحي ─────────

/// مؤشر جلسة القراءة الحية: الوقت المنقضي والصفحات والسرعة.
/// يُحدَّث كل ثانية عبر مؤقّت داخلي — يُستخدم فوق القارئ عند الطلب.
class ReaderSessionHud extends StatefulWidget {
  const ReaderSessionHud({super.key, required this.session, this.onClose});

  final ReadingSession session;
  final VoidCallback? onClose;

  @override
  State<ReaderSessionHud> createState() => _ReaderSessionHudState();
}

class _ReaderSessionHudState extends State<ReaderSessionHud> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.session;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: tint(Colors.black, 0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(SardIcons.history_rounded, size: 15, color: Colors.white),
          const SizedBox(width: 6),
          Text(
            formatDurationArabic(s.seconds),
            style: context.ts(size: 12, w: FontWeight.w700, color: Colors.white),
          ),
          const SizedBox(width: 10),
          SIcon(SardIcons.menu_book_rounded, size: 15, color: Colors.white),
          const SizedBox(width: 4),
          Text(
            '${s.pagesRead} صفحة',
            style: context.ts(size: 12, w: FontWeight.w700, color: Colors.white),
          ),
          const SizedBox(width: 10),
          Text(
            formatSpeedLabel(s.speedPpm),
            style: context.ts(size: 12, color: tint(Colors.white, 0.85)),
          ),
          if (widget.onClose != null) ...[
            const SizedBox(width: 6),
            GestureDetector(
              onTap: widget.onClose,
              child: SIcon(SardIcons.close_rounded, size: 15, color: tint(Colors.white, 0.8)),
            ),
          ],
        ],
      ),
    );
  }
}

/// بطاقة موجزة لجلسة قراءة منتهية (للعرض في الإشعارات داخل التطبيق).
class SessionSummaryCard extends StatelessWidget {
  const SessionSummaryCard({super.key, required this.record});

  final ChapterRecord record;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: tint(p.accent, 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(child: SIcon(SardIcons.menu_book_rounded, size: 20, color: p.accent)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(record.seriesTitle, style: context.ts(size: 14, w: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 2),
                Text(
                  record.summaryLabel,
                  style: context.ts(size: 12.5, color: p.textDim),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(formatSpeedLabel(record.speedPpm), style: context.ts(size: 12, w: FontWeight.w800, color: p.accent)),
              Text(
                formatRv2DayLabel(record.startedAt),
                style: context.ts(size: 11.5, color: p.textDim),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ───────── مساعدات فتح القارئ ─────────

/// يفتح القارئ v2 لعمل وفصوله.
/// [onChapterFinished] خطّاف خارجي يُنادى عند إكمال كل فصل.
Future<void> openReaderV2(
  BuildContext context, {
  required Series series,
  required List<Chapter> chapters,
  required int initialChapter,
  int initialPage = 1,
  void Function(Series series, int chapter)? onChapterFinished,
}) {
  return Navigator.of(context).push<void>(
    MaterialPageRoute<void>(
      builder: (_) => ReaderV2Screen(
        series: series,
        chapters: chapters,
        initialChapter: initialChapter,
        initialPage: initialPage,
        onChapterFinished: onChapterFinished,
      ),
    ),
  );
}

/// يفتح القارئ v2 من آخر موضع محفوظ في [settings] (أو من الفصل الأول).
Future<void> openReaderV2AtLastPosition(
  BuildContext context, {
  required Series series,
  required List<Chapter> chapters,
  required SettingsController settings,
  void Function(Series series, int chapter)? onChapterFinished,
}) {
  final saved = settings.progressOf(series.id);
  var chapter = chapters.isEmpty ? 1 : chapters.first.number;
  var page = 1;
  if (saved != null) {
    chapter = saved.chapter;
    page = saved.page;
  }
  return openReaderV2(
    context,
    series: series,
    chapters: chapters,
    initialChapter: chapter,
    initialPage: page,
    onChapterFinished: onChapterFinished,
  );
}

/// زر «متابعة القراءة» — يعرض آخر موضع ويفتح القارئ عنده.
class ContinueReadingButton extends StatelessWidget {
  const ContinueReadingButton({
    super.key,
    required this.series,
    required this.chapters,
    required this.settings,
    this.onChapterFinished,
  });

  final Series series;
  final List<Chapter> chapters;
  final SettingsController settings;
  final void Function(Series series, int chapter)? onChapterFinished;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final saved = settings.progressOf(series.id);
    final label = saved == null
        ? 'ابدأ القراءة'
        : 'متابعة: الفصل ${saved.chapter} · صفحة ${saved.page}';
    return SizedBox(
      width: double.infinity,
      child: FilledButton.icon(
        onPressed: () => openReaderV2AtLastPosition(
          context,
          series: series,
          chapters: chapters,
          settings: settings,
          onChapterFinished: onChapterFinished,
        ),
        icon: SIcon(SardIcons.play_arrow_rounded, size: 19, color: p.onAccent),
        label: Text(label, style: context.ts(size: 14, w: FontWeight.w700, color: p.onAccent)),
      ),
    );
  }
}

/// شريط أدوات مصغّر للقارئ (للاستخدام في صفحات التفاصيل):
/// زر الإعدادات السريعة + زر الإشارات + زر الأهداف.
class ReaderQuickActions extends StatelessWidget {
  const ReaderQuickActions({
    super.key,
    required this.series,
    required this.settings,
    this.onOpenBookmarks,
    this.onOpenGoals,
  });

  final Series series;
  final ReaderV2Settings settings;
  final VoidCallback? onOpenBookmarks;
  final VoidCallback? onOpenGoals;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => showReaderQuickSettings(context, settings, seriesId: series.id),
            icon: SIcon(SardIcons.settings_rounded, size: 17, color: p.text),
            label: const Text('إعدادات القراءة'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: onOpenBookmarks,
            icon: SIcon(SardIcons.bookmark_rounded, size: 17, color: p.text),
            label: const Text('إشاراتي'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: onOpenGoals,
            icon: SIcon(SardIcons.star_rounded, size: 17, color: p.text),
            label: const Text('أهدافي'),
          ),
        ),
      ],
    );
  }
}
