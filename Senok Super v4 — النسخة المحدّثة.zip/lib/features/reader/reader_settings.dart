// ──────────────────────────────────────────────────────────────────────────
//  إعدادات القارئ v2 — الخلفية، الخط، السطوع، التمرير التلقائي، الأوضاع،
//  وتجاوزات لكل عمل على حدة (خلفية/وضع/خط خاص بعمل معيّن).
//  المفاتيح: rv2_reader_* (العامة) و rv2_overrides (التجاوزات).
// ──────────────────────────────────────────────────────────────────────────
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/storage/settings.dart';
import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// بادئة مفاتيح إعدادات القارئ v2.
const String kRv2SettingsPrefix = 'rv2_reader_';

// ───────── خلفية القراءة ─────────

/// خلفية القراءة: لون ما خلف الصفحات وحولها.
enum ReaderBackground {
  /// ورق دافئ (الافتراضي): بيج فاتح مريح للعين نهاراً.
  paper,

  /// ليلي أسود: خلفية سوداء كاملة للقراءة في الظلام.
  night,

  /// بني عتيق: لون ورق قديم دافئ.
  sepia,

  /// حبر: كحلي داكن مزرقّ، بديل أنعم من الأسود الخالص.
  ink,

  /// فجر: رمادي وردي هادئ للقراءة المسائية.
  dawn;

  static ReaderBackground fromKey(String? key) {
    for (final b in ReaderBackground.values) {
      if (b.name == key) return b;
    }
    return ReaderBackground.paper;
  }
}

extension ReaderBackgroundX on ReaderBackground {
  /// الاسم العربي.
  String get label {
    switch (this) {
      case ReaderBackground.paper:
        return 'ورقي';
      case ReaderBackground.night:
        return 'ليلي';
      case ReaderBackground.sepia:
        return 'عتيق';
      case ReaderBackground.ink:
        return 'حبر';
      case ReaderBackground.dawn:
        return 'فجر';
    }
  }

  /// وصف قصير يظهر تحت الاسم في المنتقي.
  String get hint {
    switch (this) {
      case ReaderBackground.paper:
        return 'بيج فاتح مريح نهاراً';
      case ReaderBackground.night:
        return 'أسود كامل للظلام';
      case ReaderBackground.sepia:
        return 'ورق قديم دافئ';
      case ReaderBackground.ink:
        return 'كحلي داكن أنعم من الأسود';
      case ReaderBackground.dawn:
        return 'رمادي وردي للمساء';
    }
  }

  /// لون الخلفية خلف الصفحات.
  Color get bgColor {
    switch (this) {
      case ReaderBackground.paper:
        return const Color(0xFFF3EDE0);
      case ReaderBackground.night:
        return const Color(0xFF000000);
      case ReaderBackground.sepia:
        return const Color(0xFFE8D9B5);
      case ReaderBackground.ink:
        return const Color(0xFF0B1626);
      case ReaderBackground.dawn:
        return const Color(0xFFE9DFDC);
    }
  }

  /// لون إطار الصفحة/الحواف.
  Color get pageBorderColor {
    switch (this) {
      case ReaderBackground.paper:
        return const Color(0xFFD8CDB2);
      case ReaderBackground.night:
        return const Color(0xFF1F1F1F);
      case ReaderBackground.sepia:
        return const Color(0xFFC9B184);
      case ReaderBackground.ink:
        return const Color(0xFF22364F);
      case ReaderBackground.dawn:
        return const Color(0xFFC9B8B2);
    }
  }

  /// لون النص فوق الخلفية (للأزرار العائمة فوقها).
  Color get onColor {
    switch (this) {
      case ReaderBackground.paper:
      case ReaderBackground.sepia:
      case ReaderBackground.dawn:
        return const Color(0xFF241C14);
      case ReaderBackground.night:
      case ReaderBackground.ink:
        return const Color(0xFFF4EEE4);
    }
  }

  /// هل الخلفية داكنة؟ (لاختيار لون أيقونات الواجهة فوقها)
  bool get isDark => this == ReaderBackground.night || this == ReaderBackground.ink;
}

/// يحوّل فهرساً مخزّناً إلى خلفية (آمن مع القيم القديمة).
ReaderBackground readerBackgroundFromIndex(int i) {
  if (i < 0 || i >= ReaderBackground.values.length) return ReaderBackground.paper;
  return ReaderBackground.values[i];
}

// ───────── سرعة التمرير التلقائي ─────────

/// سرعة التمرير التلقائي: 0 بطيء، 1 متوسط، 2 سريع.
enum ReaderAutoSpeed { slow, medium, fast }

extension ReaderAutoSpeedX on ReaderAutoSpeed {
  String get label {
    switch (this) {
      case ReaderAutoSpeed.slow:
        return 'بطيء';
      case ReaderAutoSpeed.medium:
        return 'متوسط';
      case ReaderAutoSpeed.fast:
        return 'سريع';
    }
  }

  /// بكسل في الثانية في الوضع العمودي (تقريبي).
  double get pixelsPerSecond {
    switch (this) {
      case ReaderAutoSpeed.slow:
        return 45;
      case ReaderAutoSpeed.medium:
        return 90;
      case ReaderAutoSpeed.fast:
        return 170;
    }
  }

  /// ثوانٍ لكل صفحة في وضع الصفحات.
  double get secondsPerPage {
    switch (this) {
      case ReaderAutoSpeed.slow:
        return 14;
      case ReaderAutoSpeed.medium:
        return 8;
      case ReaderAutoSpeed.fast:
        return 4.5;
    }
  }
}

// ───────── تجاوزات عمل واحد ─────────

/// تجاوزات إعدادات لعمل معيّن: أي حقل null يعني «استخدم الإعداد العام».
@immutable
class ReaderSeriesOverrides {
  const ReaderSeriesOverrides({
    this.background,
    this.mode,
    this.fontScale,
    this.brightness,
    this.panelMode,
    this.autoScroll,
  });

  final ReaderBackground? background;
  final ReaderMode? mode;
  final double? fontScale;
  final double? brightness;
  final bool? panelMode;
  final bool? autoScroll;

  bool get isEmpty =>
      background == null &&
      mode == null &&
      fontScale == null &&
      brightness == null &&
      panelMode == null &&
      autoScroll == null;

  int get overriddenCount {
    var n = 0;
    if (background != null) n++;
    if (mode != null) n++;
    if (fontScale != null) n++;
    if (brightness != null) n++;
    if (panelMode != null) n++;
    if (autoScroll != null) n++;
    return n;
  }

  ReaderSeriesOverrides copyWith({
    ReaderBackground? background,
    ReaderMode? mode,
    double? fontScale,
    double? brightness,
    bool? panelMode,
    bool? autoScroll,
    bool clearBackground = false,
    bool clearMode = false,
    bool clearFontScale = false,
    bool clearBrightness = false,
    bool clearPanelMode = false,
    bool clearAutoScroll = false,
  }) {
    return ReaderSeriesOverrides(
      background: clearBackground ? null : (background ?? this.background),
      mode: clearMode ? null : (mode ?? this.mode),
      fontScale: clearFontScale ? null : (fontScale ?? this.fontScale),
      brightness: clearBrightness ? null : (brightness ?? this.brightness),
      panelMode: clearPanelMode ? null : (panelMode ?? this.panelMode),
      autoScroll: clearAutoScroll ? null : (autoScroll ?? this.autoScroll),
    );
  }

  Map<String, dynamic> toJson() => {
        'background': background?.name,
        'mode': mode?.name,
        'font_scale': fontScale,
        'brightness': brightness,
        'panel_mode': panelMode,
        'auto_scroll': autoScroll,
      };

  factory ReaderSeriesOverrides.fromJson(Map<String, dynamic> j) {
    ReaderMode? modeFrom(String? key) {
      if (key == null) return null;
      for (final m in ReaderMode.values) {
        if (m.name == key) return m;
      }
      return null;
    }

    return ReaderSeriesOverrides(
      background: j['background'] == null
          ? null
          : ReaderBackground.fromKey(j['background'] as String?),
      mode: modeFrom(j['mode'] as String?),
      fontScale: (j['font_scale'] as num?)?.toDouble(),
      brightness: (j['brightness'] as num?)?.toDouble(),
      panelMode: j['panel_mode'] as bool?,
      autoScroll: j['auto_scroll'] as bool?,
    );
  }
}

// ───────── مخزن إعدادات القارئ v2 ─────────

/// مخزن إعدادات القارئ v2 (مفردة عبر [ReaderV2Settings.i]).
/// يقرأ الإعدادات القديمة من [SettingsController] كقيم افتراضية أول مرة.
class ReaderV2Settings extends ChangeNotifier {
  ReaderV2Settings._(this._p) {
    _load();
  }

  static ReaderV2Settings? _instance;

  static ReaderV2Settings get i {
    final inst = _instance;
    if (inst == null) throw StateError('ReaderV2Settings لم يُحمَّل بعد — نادِ load() أولاً.');
    return inst;
  }

  static Future<ReaderV2Settings> load() async {
    final p = await SharedPreferences.getInstance();
    return _instance ??= ReaderV2Settings._(p);
  }

  static ReaderV2Settings testInstance() => ReaderV2Settings._(_Rv2SettingsFakePrefs());

  final SharedPreferences _p;

  late ReaderBackground _background;
  late ReaderMode _mode;
  late double _fontScale;
  late double _brightness;
  late ReaderAutoSpeed _autoSpeed;
  late bool _keepAwake;
  late bool _chainChapters;
  late bool _tapZones;
  late bool _panelMode;
  late bool _autoScroll;
  late bool _showPageNumbers;
  late bool _hideStatusBar;
  late Map<String, ReaderSeriesOverrides> _overrides;

  String _k(String name) => '$kRv2SettingsPrefix$name';

  void _load() {
    _background = ReaderBackground.fromKey(_p.getString(_k('background')));
    final modeI = _p.getInt(_k('mode'));
    _mode = modeI == null
        ? ReaderMode.vertical
        : ReaderMode.values[modeI.clamp(0, ReaderMode.values.length - 1).toInt()];
    _fontScale = (_p.getDouble(_k('font_scale')) ?? 1.0).clamp(0.8, 1.6).toDouble();
    _brightness = (_p.getDouble(_k('brightness')) ?? 1.0).clamp(0.25, 1.0).toDouble();
    final speedI = _p.getInt(_k('auto_speed'));
    _autoSpeed = speedI == null
        ? ReaderAutoSpeed.medium
        : ReaderAutoSpeed.values[speedI.clamp(0, ReaderAutoSpeed.values.length - 1).toInt()];
    _keepAwake = _p.getBool(_k('keep_awake')) ?? true;
    _chainChapters = _p.getBool(_k('chain')) ?? true;
    _tapZones = _p.getBool(_k('tap_zones')) ?? true;
    _panelMode = _p.getBool(_k('panel_mode')) ?? false;
    _autoScroll = _p.getBool(_k('auto_scroll')) ?? false;
    _showPageNumbers = _p.getBool(_k('page_numbers')) ?? true;
    _hideStatusBar = _p.getBool(_k('hide_status_bar')) ?? true;
    _overrides = {};
    try {
      final raw = _p.getString('${kRv2SettingsPrefix}overrides');
      if (raw != null && raw.isNotEmpty) {
        final map = jsonDecode(raw) as Map;
        map.forEach((k, v) {
          if (v is Map) {
            _overrides['$k'] =
                ReaderSeriesOverrides.fromJson(Map<String, dynamic>.from(v));
          }
        });
      }
    } catch (_) {}
  }

  Future<void> _saveOverrides() async {
    await _p.setString(
      '${kRv2SettingsPrefix}overrides',
      jsonEncode(_overrides.map((k, v) => MapEntry(k, v.toJson()))),
    );
  }

  // ── القيم العامة ──

  ReaderBackground get background => _background;
  ReaderMode get mode => _mode;
  double get fontScale => _fontScale;
  double get brightness => _brightness;
  ReaderAutoSpeed get autoSpeed => _autoSpeed;
  bool get keepAwake => _keepAwake;
  bool get chainChapters => _chainChapters;
  bool get tapZonesEnabled => _tapZones;
  bool get panelModeEnabled => _panelMode;
  bool get autoScrollEnabled => _autoScroll;
  bool get showPageNumbers => _showPageNumbers;
  bool get hideStatusBar => _hideStatusBar;

  void setBackground(ReaderBackground b) {
    _background = b;
    _p.setString(_k('background'), b.name);
    notifyListeners();
  }

  void setMode(ReaderMode m) {
    _mode = m;
    _p.setInt(_k('mode'), m.index);
    notifyListeners();
  }

  void setModeIndex(int i) => setMode(ReaderMode.values[i.clamp(0, ReaderMode.values.length - 1).toInt()]);

  void setFontScale(double v) {
    _fontScale = v.clamp(0.8, 1.6).toDouble();
    _p.setDouble(_k('font_scale'), _fontScale);
    notifyListeners();
  }

  void setBrightness(double v) {
    _brightness = v.clamp(0.25, 1.0).toDouble();
    _p.setDouble(_k('brightness'), _brightness);
    notifyListeners();
  }

  void setAutoSpeed(ReaderAutoSpeed s) {
    _autoSpeed = s;
    _p.setInt(_k('auto_speed'), s.index);
    notifyListeners();
  }

  void setKeepAwake(bool v) {
    _keepAwake = v;
    _p.setBool(_k('keep_awake'), v);
    notifyListeners();
  }

  void setChainChapters(bool v) {
    _chainChapters = v;
    _p.setBool(_k('chain'), v);
    notifyListeners();
  }

  void setTapZonesEnabled(bool v) {
    _tapZones = v;
    _p.setBool(_k('tap_zones'), v);
    notifyListeners();
  }

  void setPanelModeEnabled(bool v) {
    _panelMode = v;
    _p.setBool(_k('panel_mode'), v);
    notifyListeners();
  }

  void setAutoScrollEnabled(bool v) {
    _autoScroll = v;
    _p.setBool(_k('auto_scroll'), v);
    notifyListeners();
  }

  void setShowPageNumbers(bool v) {
    _showPageNumbers = v;
    _p.setBool(_k('page_numbers'), v);
    notifyListeners();
  }

  void setHideStatusBar(bool v) {
    _hideStatusBar = v;
    _p.setBool(_k('hide_status_bar'), v);
    notifyListeners();
  }

  // ── القيم الفعّالة لعمل معيّن (تجاوزات أو عام) ──

  ReaderSeriesOverrides overridesFor(String seriesId) =>
      _overrides[seriesId] ?? const ReaderSeriesOverrides();

  ReaderBackground backgroundFor(String seriesId) =>
      overridesFor(seriesId).background ?? _background;

  ReaderMode modeFor(String seriesId) => overridesFor(seriesId).mode ?? _mode;

  double fontScaleFor(String seriesId) =>
      overridesFor(seriesId).fontScale ?? _fontScale;

  double brightnessFor(String seriesId) =>
      overridesFor(seriesId).brightness ?? _brightness;

  bool panelModeFor(String seriesId) =>
      overridesFor(seriesId).panelMode ?? _panelMode;

  bool autoScrollFor(String seriesId) =>
      overridesFor(seriesId).autoScroll ?? _autoScroll;

  Future<void> setOverrides(String seriesId, ReaderSeriesOverrides o) async {
    if (o.isEmpty) {
      _overrides.remove(seriesId);
    } else {
      _overrides[seriesId] = o;
    }
    await _saveOverrides();
    notifyListeners();
  }

  Future<void> clearOverrides(String seriesId) async {
    _overrides.remove(seriesId);
    await _saveOverrides();
    notifyListeners();
  }

  /// أسماء الأعمال ذات التجاوزات (للشاشة).
  List<String> get overriddenSeriesIds => _overrides.keys.toList();

  /// يعيد كل الإعدادات للافتراضي.
  Future<void> resetAll() async {
    _background = ReaderBackground.paper;
    _mode = ReaderMode.vertical;
    _fontScale = 1.0;
    _brightness = 1.0;
    _autoSpeed = ReaderAutoSpeed.medium;
    _keepAwake = true;
    _chainChapters = true;
    _tapZones = true;
    _panelMode = false;
    _autoScroll = false;
    _showPageNumbers = true;
    _hideStatusBar = true;
    _overrides.clear();
    for (final name in [
      'background', 'mode', 'font_scale', 'brightness', 'auto_speed',
      'keep_awake', 'chain', 'tap_zones', 'panel_mode', 'auto_scroll',
      'page_numbers', 'hide_status_bar', 'overrides',
    ]) {
      await _p.remove(_k(name));
    }
    notifyListeners();
  }

  /// ملخّص نصي للإعدادات الحالية (للعرض في بطاقة).
  String get summaryText {
    final modeLabel = switch (_mode) {
      ReaderMode.vertical => 'عمودي',
      ReaderMode.pagedRtl => 'صفحة بصفحة (يمين←يسار)',
      ReaderMode.pagedLtr => 'صفحة بصفحة (يسار←يمين)',
    };
    return '$modeLabel · خلفية ${_background.label} · خط ${(_fontScale * 100).round()}٪';
  }
}

/// بديل خفيف لـ SharedPreferences في الاختبارات (ذاكرة فقط).
class _Rv2SettingsFakePrefs implements SharedPreferences {
  final Map<String, Object> _m = {};

  @override
  Set<String> getKeys() => _m.keys.toSet();
  @override
  Object? get(String key) => _m[key];
  @override
  bool? getBool(String key) => _m[key] as bool?;
  @override
  double? getDouble(String key) => _m[key] as double?;
  @override
  int? getInt(String key) => _m[key] as int?;
  @override
  String? getString(String key) => _m[key] as String?;
  @override
  List<String>? getStringList(String key) => _m[key] as List<String>?;
  @override
  bool containsKey(String key) => _m.containsKey(key);
  @override
  Future<bool> setBool(String key, bool value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setDouble(String key, double value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setInt(String key, int value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setString(String key, String value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> setStringList(String key, List<String> value) async {
    _m[key] = value;
    return true;
  }

  @override
  Future<bool> remove(String key) async {
    _m.remove(key);
    return true;
  }

  @override
  Future<bool> clear() async {
    _m.clear();
    return true;
  }

  @override
  Future<bool> commit() async => true;
  @override
  Future<void> reload() async {}
}

// ───────── ويدجتات إعدادات القارئ ─────────

/// منتقي خلفية القراءة: يعرض الخلفيات الخمس كعينات ملوّنة.
/// [selected] قد تكون null وتعني «العام» عند allowGeneral=true.
class _BackgroundPicker extends StatelessWidget {
  const _BackgroundPicker({
    required this.selected,
    required this.onPick,
    this.allowGeneral = false,
  });

  final ReaderBackground? selected;
  final ValueChanged<ReaderBackground?> onPick;
  final bool allowGeneral;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final items = <ReaderBackground?>[
      if (allowGeneral) null,
      ...ReaderBackground.values,
    ];
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: items.map((b) {
        final isSel = b == selected;
        final isGeneral = b == null;
        final bg = isGeneral ? p.surfaceHi : b.bgColor;
        final border = isGeneral ? p.border : b.pageBorderColor;
        final label = isGeneral ? 'عام' : b.label;
        return Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => onPick(b),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              width: 62,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSel ? p.accent : border,
                  width: isSel ? 2 : 1,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 34,
                    height: 44,
                    decoration: BoxDecoration(
                      color: isGeneral ? p.surface : b.bgColor,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: isGeneral ? p.border : b.pageBorderColor,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        'أ',
                        style: TextStyle(
                          fontFamily: sardFont,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: isGeneral ? p.textDim : b.onColor,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    label,
                    style: context.ts(
                      size: 11.5,
                      w: isSel ? FontWeight.w800 : FontWeight.w500,
                      color: isGeneral ? p.text : b.onColor,
                    ),
                  ),
                  if (isSel)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: SIcon(SardIcons.check_rounded, size: 13, color: p.accent),
                    ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// بطاقة قسم في شاشة الإعدادات.
class _ReaderSectionCard extends StatelessWidget {
  const _ReaderSectionCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.note,
    required this.child,
  });

  final SIconData icon;
  final Color color;
  final String title;
  final String note;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(1)),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: tint(color, 0.13),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: SIcon(icon, size: 18, color: color)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(title, style: context.ds(size: 15.5)),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(note, style: context.ts(size: 12.5, color: p.textDim)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

/// صفّ مقطّع (اختيار من خيارات نصية).
class _SegRow extends StatelessWidget {
  const _SegRow({
    required this.labels,
    required this.index,
    required this.color,
    required this.onChanged,
  });

  final List<String> labels;
  final int index;
  final Color color;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: p.surfaceHi,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => onChanged(i),
                  borderRadius: BorderRadius.circular(9),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    decoration: BoxDecoration(
                      color: i == index ? p.surface : Colors.transparent,
                      borderRadius: BorderRadius.circular(9),
                      boxShadow: i == index ? softShadow(p, strength: 0.5) : null,
                    ),
                    child: Text(
                      labels[i],
                      textAlign: TextAlign.center,
                      style: context.ts(
                        size: 12.5,
                        w: i == index ? FontWeight.w800 : FontWeight.w500,
                        color: i == index ? color : p.textDim,
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// صفّ تبديل (مفتاح) في الإعدادات.
class _SwitchRow extends StatelessWidget {
  const _SwitchRow({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.ts(size: 13.5, w: FontWeight.w700)),
                const SizedBox(height: 1),
                Text(subtitle, style: context.ts(size: 12, color: p.textDim)),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: p.accent,
          ),
        ],
      ),
    );
  }
}

/// صفّ منزلق (قيمة رقمية) في الإعدادات.
class _SliderRow extends StatelessWidget {
  const _SliderRow({
    required this.title,
    required this.valueLabel,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  final String title;
  final String valueLabel;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(title, style: context.ts(size: 13.5, w: FontWeight.w700)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: tint(p.accent, 0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(valueLabel, style: context.ts(size: 12, w: FontWeight.w800, color: p.accent)),
              ),
            ],
          ),
          Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            activeColor: p.accent,
            inactiveColor: p.border,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

// ───────── شاشة إعدادات القارئ v2 ─────────

/// شاشة إعدادات القارئ الكاملة: الوضع، الخلفية، الخط، السطوع، التمرير،
/// الإيماءات، اللوحات، وتجاوزات الأعمال.
class ReaderSettingsScreen extends StatefulWidget {
  const ReaderSettingsScreen({super.key, this.seriesId, this.seriesTitle});

  /// إن مُرّر عمل، تُعرض تجاوزاته أولاً مع خيار التعديل.
  final String? seriesId;
  final String? seriesTitle;

  @override
  State<ReaderSettingsScreen> createState() => _ReaderSettingsScreenState();
}

class _ReaderSettingsScreenState extends State<ReaderSettingsScreen> {
  late ReaderV2Settings s;

  @override
  void initState() {
    super.initState();
    s = ReaderV2Settings.i;
  }

  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final hasSeries = widget.seriesId != null && widget.seriesId!.isNotEmpty;
    final ov = hasSeries ? s.overridesFor(widget.seriesId!) : const ReaderSeriesOverrides();
    final effMode = hasSeries ? s.modeFor(widget.seriesId!) : s.mode;
    final effFont = hasSeries ? s.fontScaleFor(widget.seriesId!) : s.fontScale;
    final effBright = hasSeries ? s.brightnessFor(widget.seriesId!) : s.brightness;

    Future<void> updateOverrides(ReaderSeriesOverrides next) async {
      await s.setOverrides(widget.seriesId!, next);
      _refresh();
    }

    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: Text(hasSeries ? 'إعدادات هذا العمل' : 'إعدادات القارئ'),
        actions: [
          TextButton(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('إعادة تعيين؟'),
                  content: const Text('ستعود كل إعدادات القارئ إلى القيم الافتراضية.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('إلغاء')),
                    FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('إعادة تعيين')),
                  ],
                ),
              );
              if (ok == true) {
                await s.resetAll();
                _refresh();
              }
            },
            child: const Text('إعادة تعيين'),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: s,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
            children: [
              if (hasSeries)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: tint(p.gold, 0.12),
                    borderRadius: BorderRadius.circular(p.r(0.9)),
                    border: Border.all(color: tint(p.gold, 0.35)),
                  ),
                  child: Row(
                    children: [
                      SIcon(SardIcons.menu_book_rounded, size: 18, color: p.gold),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          ov.isEmpty
                              ? 'إعدادات «${widget.seriesTitle ?? ''}» تتبع الإعدادات العامة حالياً — غيّر أي شيء هنا ليصبح خاصاً بهذا العمل.'
                              : 'لهذا العمل ${ov.overriddenCount} تجاوزات خاصة — يمكنك مسحها للعودة للعام.',
                          style: context.ts(size: 12.5, color: p.text),
                        ),
                      ),
                      if (!ov.isEmpty)
                        TextButton(
                          onPressed: () async {
                            await s.clearOverrides(widget.seriesId!);
                            _refresh();
                          },
                          child: const Text('مسح التجاوزات'),
                        ),
                    ],
                  ),
                ),
              _ReaderSectionCard(
                icon: SardIcons.chrome_reader_mode_rounded,
                color: const Color(0xFF3B9EFF),
                title: 'وضع القراءة',
                note: 'العمودي يناسب المانهوا الطويلة، وصفحة بصفحة يناسب المانغا، وصفحتان معاً للشاشات العريضة.',
                child: _SegRow(
                  labels: const ['عمودي', 'صفحة بصفحة', 'صفحتان'],
                  index: effMode == ReaderMode.vertical
                      ? 0
                      : effMode == ReaderMode.pagedRtl
                          ? 1
                          : 2,
                  color: const Color(0xFF3B9EFF),
                  onChanged: (i) async {
                    final m = i == 0
                        ? ReaderMode.vertical
                        : i == 1
                            ? ReaderMode.pagedRtl
                            : ReaderMode.pagedLtr;
                    if (hasSeries) {
                      await updateOverrides(ov.copyWith(mode: m));
                    } else {
                      s.setMode(m);
                      _refresh();
                    }
                  },
                ),
              ),
              _ReaderSectionCard(
                icon: SardIcons.menu_book_rounded,
                color: const Color(0xFFF5A524),
                title: 'خلفية القراءة',
                note: 'تؤثر في اللون خلف الصفحات وحولها. الورقي مريح نهاراً، والليلي للقراءة في الظلام.',
                child: _BackgroundPicker(
                  selected: hasSeries ? ov.background : s.background,
                  allowGeneral: hasSeries,
                  onPick: (b) async {
                    if (hasSeries) {
                      await updateOverrides(ov.copyWith(
                        background: b,
                        clearBackground: b == null,
                      ));
                    } else {
                      // b غير null هنا لأن الوضع العام لا يعرض خيار «عام»
                      s.setBackground(b ?? ReaderBackground.paper);
                      _refresh();
                    }
                  },
                ),
              ),
              _ReaderSectionCard(
                icon: SardIcons.wb_sunny_rounded,
                color: const Color(0xFFFF8A3D),
                title: 'السطوع وحجم الخط',
                note: 'السطوع تعتيم داخل التطبيق دون لمس سطوع النظام. حجم الخط يؤثر في نصوص الواجهة داخل القارئ.',
                child: Column(
                  children: [
                    _SliderRow(
                      title: 'سطوع القارئ',
                      valueLabel: '${(effBright * 100).round()}٪',
                      value: effBright,
                      min: 0.25,
                      max: 1.0,
                      onChanged: (v) async {
                        if (hasSeries) {
                          await updateOverrides(ov.copyWith(brightness: v));
                        } else {
                          s.setBrightness(v);
                          _refresh();
                        }
                      },
                    ),
                    _SliderRow(
                      title: 'حجم الخط',
                      valueLabel: '${(effFont * 100).round()}٪',
                      value: effFont,
                      min: 0.8,
                      max: 1.6,
                      onChanged: (v) async {
                        if (hasSeries) {
                          await updateOverrides(ov.copyWith(fontScale: v));
                        } else {
                          s.setFontScale(v);
                          _refresh();
                        }
                      },
                    ),
                  ],
                ),
              ),
              _ReaderSectionCard(
                icon: SardIcons.play_arrow_rounded,
                color: const Color(0xFF0F9D75),
                title: 'التمرير التلقائي',
                note: 'يمرّر الصفحات تلقائياً بسرعة ثابتة — مثالي للقراءة دون لمس الشاشة.',
                child: Column(
                  children: [
                    _SwitchRow(
                      title: 'تفعيل التمرير التلقائي',
                      subtitle: s.autoSpeed.label + ' · يتوقف عند لمس الشاشة',
                      value: hasSeries ? s.autoScrollFor(widget.seriesId!) : s.autoScrollEnabled,
                      onChanged: (v) async {
                        if (hasSeries) {
                          await updateOverrides(ov.copyWith(autoScroll: v));
                        } else {
                          s.setAutoScrollEnabled(v);
                          _refresh();
                        }
                      },
                    ),
                    _SegRow(
                      labels: const ['بطيء', 'متوسط', 'سريع'],
                      index: s.autoSpeed.index,
                      color: const Color(0xFF0F9D75),
                      onChanged: (i) {
                        s.setAutoSpeed(ReaderAutoSpeed.values[i]);
                        _refresh();
                      },
                    ),
                  ],
                ),
              ),
              _ReaderSectionCard(
                icon: SardIcons.layers_rounded,
                color: const Color(0xFFB44CFF),
                title: 'وضع اللوحات والإيماءات',
                note: 'وضع اللوحات يقسّم الصفحات الطويلة إلى لوحات. مناطق النقر: الأطراف للتنقل والوسط للواجهة.',
                child: Column(
                  children: [
                    _SwitchRow(
                      title: 'وضع اللوحات',
                      subtitle: 'تقسيم قواعدي حسب طول الصفحة',
                      value: hasSeries ? s.panelModeFor(widget.seriesId!) : s.panelModeEnabled,
                      onChanged: (v) async {
                        if (hasSeries) {
                          await updateOverrides(ov.copyWith(panelMode: v));
                        } else {
                          s.setPanelModeEnabled(v);
                          _refresh();
                        }
                      },
                    ),
                    _SwitchRow(
                      title: 'مناطق النقر',
                      subtitle: 'النقر على الأطراف يقلّب الصفحات',
                      value: s.tapZonesEnabled,
                      onChanged: (v) {
                        s.setTapZonesEnabled(v);
                        _refresh();
                      },
                    ),
                    _SwitchRow(
                      title: 'متابعة الفصل التالي',
                      subtitle: 'الوضع العمودي يتابع الفصل التالي دون انقطاع',
                      value: s.chainChapters,
                      onChanged: (v) {
                        s.setChainChapters(v);
                        _refresh();
                      },
                    ),
                  ],
                ),
              ),
              _ReaderSectionCard(
                icon: SardIcons.settings_rounded,
                color: p.accent,
                title: 'خيارات عامة',
                note: 'تفضيلات العرض والسلوك داخل القارئ.',
                child: Column(
                  children: [
                    _SwitchRow(
                      title: 'إبقاء الشاشة مضاءة',
                      subtitle: 'يمنع إطفاء الشاشة أثناء القراءة',
                      value: s.keepAwake,
                      onChanged: (v) {
                        s.setKeepAwake(v);
                        _refresh();
                      },
                    ),
                    _SwitchRow(
                      title: 'أرقام الصفحات',
                      subtitle: 'إظهار رقم الصفحة الحالية',
                      value: s.showPageNumbers,
                      onChanged: (v) {
                        s.setShowPageNumbers(v);
                        _refresh();
                      },
                    ),
                    _SwitchRow(
                      title: 'إخفاء شريط الحالة',
                      subtitle: 'قراءة بملء الشاشة دون ساعة وبطارية',
                      value: s.hideStatusBar,
                      onChanged: (v) {
                        s.setHideStatusBar(v);
                        _refresh();
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'ملخص الإعدادات: ${s.summaryText}',
                style: context.ts(size: 12, color: p.textDim),
                textAlign: TextAlign.center,
              ),
            ],
          );
        },
      ),
    );
  }
}

// ───────── ورقة الإعدادات السريعة ─────────

/// ورقة إعدادات سريعة تُفتح من داخل القارئ: الوضع والخلفية والسطوع
/// والتمرير التلقائي — دون مغادرة صفحة القراءة.
class ReaderQuickSettingsSheet extends StatelessWidget {
  const ReaderQuickSettingsSheet({super.key, required this.settings, this.seriesId});

  final ReaderV2Settings settings;
  final String? seriesId;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final hasSeries = seriesId != null && seriesId!.isNotEmpty;
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: AnimatedBuilder(
        animation: settings,
        builder: (context, _) {
          final bg = hasSeries ? settings.backgroundFor(seriesId!) : settings.background;
          final mode = hasSeries ? settings.modeFor(seriesId!) : settings.mode;
          final bright = hasSeries ? settings.brightnessFor(seriesId!) : settings.brightness;
          return SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(width: 44, height: 4, decoration: BoxDecoration(color: p.border, borderRadius: BorderRadius.circular(4))),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(child: Text('إعدادات سريعة', style: context.ds(size: 18))),
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => ReaderSettingsScreen(seriesId: seriesId),
                          ),
                        );
                      },
                      child: const Text('كل الإعدادات'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text('وضع القراءة', style: context.ts(size: 13, w: FontWeight.w700)),
                const SizedBox(height: 8),
                _SegRow(
                  labels: const ['عمودي', 'صفحة بصفحة', 'صفحتان'],
                  index: mode == ReaderMode.vertical ? 0 : mode == ReaderMode.pagedRtl ? 1 : 2,
                  color: const Color(0xFF3B9EFF),
                  onChanged: (i) async {
                    final m = i == 0 ? ReaderMode.vertical : i == 1 ? ReaderMode.pagedRtl : ReaderMode.pagedLtr;
                    if (hasSeries) {
                      final ov = settings.overridesFor(seriesId!);
                      await settings.setOverrides(seriesId!, ov.copyWith(mode: m));
                    } else {
                      settings.setMode(m);
                    }
                  },
                ),
                const SizedBox(height: 14),
                Text('الخلفية', style: context.ts(size: 13, w: FontWeight.w700)),
                const SizedBox(height: 8),
                _BackgroundPicker(
                  selected: hasSeries ? settings.overridesFor(seriesId!).background : bg,
                  allowGeneral: hasSeries,
                  onPick: (b) async {
                    if (hasSeries) {
                      final ov = settings.overridesFor(seriesId!);
                      await settings.setOverrides(
                        seriesId!,
                        ov.copyWith(background: b, clearBackground: b == null),
                      );
                    } else {
                      settings.setBackground(b ?? ReaderBackground.paper);
                    }
                  },
                ),
                const SizedBox(height: 14),
                _SliderRow(
                  title: 'السطوع',
                  valueLabel: '${(bright * 100).round()}٪',
                  value: bright,
                  min: 0.25,
                  max: 1.0,
                  onChanged: (v) async {
                    if (hasSeries) {
                      final ov = settings.overridesFor(seriesId!);
                      await settings.setOverrides(seriesId!, ov.copyWith(brightness: v));
                    } else {
                      settings.setBrightness(v);
                    }
                  },
                ),
                _SwitchRow(
                  title: 'التمرير التلقائي',
                  subtitle: 'سرعة ${settings.autoSpeed.label}',
                  value: hasSeries ? settings.autoScrollFor(seriesId!) : settings.autoScrollEnabled,
                  onChanged: (v) async {
                    if (hasSeries) {
                      final ov = settings.overridesFor(seriesId!);
                      await settings.setOverrides(seriesId!, ov.copyWith(autoScroll: v));
                    } else {
                      settings.setAutoScrollEnabled(v);
                    }
                  },
                ),
                _SwitchRow(
                  title: 'وضع اللوحات',
                  subtitle: 'تقسيم الصفحات الطويلة إلى لوحات',
                  value: hasSeries ? settings.panelModeFor(seriesId!) : settings.panelModeEnabled,
                  onChanged: (v) async {
                    if (hasSeries) {
                      final ov = settings.overridesFor(seriesId!);
                      await settings.setOverrides(seriesId!, ov.copyWith(panelMode: v));
                    } else {
                      settings.setPanelModeEnabled(v);
                    }
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// يفتح ورقة الإعدادات السريعة.
Future<void> showReaderQuickSettings(
  BuildContext context,
  ReaderV2Settings settings, {
  String? seriesId,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => ReaderQuickSettingsSheet(settings: settings, seriesId: seriesId),
  );
}

// ───────── إدارة تجاوزات الأعمال ─────────

/// بطاقة تجاوزات عمل واحد في قائمة التجاوزات.
class SeriesOverrideRow extends StatelessWidget {
  const SeriesOverrideRow({
    super.key,
    required this.seriesId,
    required this.seriesTitle,
    required this.overrides,
    this.onClear,
    this.onEdit,
  });

  final String seriesId;
  final String seriesTitle;
  final ReaderSeriesOverrides overrides;
  final VoidCallback? onClear;
  final VoidCallback? onEdit;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final parts = <String>[];
    if (overrides.background != null) parts.add('خلفية ${overrides.background!.label}');
    if (overrides.mode != null) {
      parts.add(switch (overrides.mode!) {
        ReaderMode.vertical => 'عمودي',
        ReaderMode.pagedRtl => 'صفحة بصفحة',
        ReaderMode.pagedLtr => 'صفحتان',
      });
    }
    if (overrides.fontScale != null) parts.add('خط ${(overrides.fontScale! * 100).round()}٪');
    if (overrides.brightness != null) parts.add('سطوع ${(overrides.brightness! * 100).round()}٪');
    if (overrides.panelMode != null) parts.add(overrides.panelMode! ? 'لوحات' : 'بلا لوحات');
    if (overrides.autoScroll != null) parts.add(overrides.autoScroll! ? 'تمرير تلقائي' : 'بلا تمرير');
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(seriesTitle, style: context.ts(size: 14, w: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 2),
                Text(parts.join(' · '), style: context.ts(size: 12, color: p.textDim), maxLines: 2, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          if (onEdit != null)
            IconButton(
              onPressed: onEdit,
              tooltip: 'تعديل',
              icon: SIcon(SardIcons.edit_rounded, size: 18, color: p.textDim),
            ),
          if (onClear != null)
            IconButton(
              onPressed: onClear,
              tooltip: 'مسح التجاوزات',
              icon: SIcon(SardIcons.close_rounded, size: 18, color: p.textDim),
            ),
        ],
      ),
    );
  }
}

/// شاشة إدارة كل تجاوزات الأعمال.
class SeriesOverridesScreen extends StatefulWidget {
  const SeriesOverridesScreen({super.key, required this.settings});

  final ReaderV2Settings settings;

  @override
  State<SeriesOverridesScreen> createState() => _SeriesOverridesScreenState();
}

class _SeriesOverridesScreenState extends State<SeriesOverridesScreen> {
  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title: const Text('إعدادات خاصة بالأعمال')),
      body: AnimatedBuilder(
        animation: widget.settings,
        builder: (context, _) {
          final ids = widget.settings.overriddenSeriesIds;
          if (ids.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SIcon(SardIcons.menu_book_rounded, size: 40, color: p.textDim),
                    const SizedBox(height: 12),
                    Text('لا تجاوزات خاصة بعد', style: context.ds(size: 17)),
                    const SizedBox(height: 6),
                    Text(
                      'عند تعديل إعدادات القارئ أثناء قراءة عمل معيّن، تُحفظ كتجاوز خاص به وتظهر هنا.',
                      style: context.ts(size: 13, color: p.textDim),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            itemCount: ids.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final id = ids[i];
              final ov = widget.settings.overridesFor(id);
              return SeriesOverrideRow(
                seriesId: id,
                seriesTitle: id,
                overrides: ov,
                onEdit: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => ReaderSettingsScreen(seriesId: id, seriesTitle: id),
                    ),
                  );
                },
                onClear: () async {
                  await widget.settings.clearOverrides(id);
                  setState(() {});
                },
              );
            },
          );
        },
      ),
    );
  }
}
