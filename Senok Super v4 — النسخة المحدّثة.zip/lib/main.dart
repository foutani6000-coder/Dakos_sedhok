import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/config/app_config.dart';
import 'core/data/repository.dart';
import 'core/discovery/taste_profile.dart';
import 'features/auth/guest_mode.dart';
import 'features/auth/session_manager.dart';
import 'core/data/download_manager.dart';
import 'core/guide/guide_controller.dart';
import 'core/storage/settings.dart';
import 'core/theme/app_themes.dart';
import 'features/onboarding/onboarding_screen.dart';
import 'features/brand/senok_splash.dart';
import 'features/shell/shell.dart';
import 'widgets/guide_assistant.dart';
import 'widgets/stamp_seal.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppConfig.loadOverride();
  final settings = await SettingsController.load();
  final guide = await GuideController.load();
  await DownloadManager.instance.init();
  await TasteProfileStore.i.load();
  await SessionManager.load();
  await GuestModeController.load();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<SettingsController>.value(value: settings),
        ChangeNotifierProvider<GuideController>.value(value: guide),
        Provider<SardRepository>(create: (_) => SardRepository()),
      ],
      child: const SardApp(),
    ),
  );
}

class SardApp extends StatelessWidget {
  const SardApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsController>();
    final isSystem = settings.themeId == 'system';
    final lightPal = applyAccent(
      isSystem ? SardThemes.paper : SardThemes.byId(settings.themeId),
      settings.accentId,
    );
    final darkPal = applyAccent(
      isSystem ? SardThemes.obsidian : SardThemes.byId(settings.themeId),
      settings.accentId,
    );
    final pal = isSystem && WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark
        ? darkPal
        : lightPal;
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      scrollBehavior: const SardScrollBehavior(),
      theme: buildTheme(lightPal),
      darkTheme: buildTheme(darkPal),
      themeMode: isSystem ? ThemeMode.system : ThemeMode.light,
      // تبديل الثيم بتلاشٍ ناعم
      themeAnimationDuration: const Duration(milliseconds: 450),
      themeAnimationCurve: Curves.easeOutCubic,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final effective = Theme.of(context).extension<SardPalette>() ?? pal;
        // حجم الخط: معامل المستخدم (الافتراضي 0.88) × تكبير النظام لإمكانية الوصول
        final mq = MediaQuery.of(context);
        final system = mq.textScaler.scale(100) / 100;
        final scaled = MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear((system * settings.fontScale).clamp(0.7, 1.5).toDouble()),
          ),
          child: child!,
        );
        return AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: effective.isDark ? Brightness.light : Brightness.dark,
          systemNavigationBarColor: effective.bg,
          systemNavigationBarIconBrightness:
              effective.isDark ? Brightness.light : Brightness.dark,
        ),
        child: StampToastHost(
          settings: settings,
          child: GuideOverlay(child: scaled),
        ),
      );
      },
      home: const RootGate(),
    );
  }
}

/// إقلاع متحرك ← ترحيب (أول مرة) ← الهيكل الرئيسي
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _splash = true;


  @override
  Widget build(BuildContext context) {
    final onboarded = context.watch<SettingsController>().onboarded;
    final Widget page;
    if (_splash) {
      page = SenokSplashScreen(
        key: const ValueKey('splash'),
        onDone: () {
          if (mounted) setState(() => _splash = false);
        },
      );
    } else if (!onboarded) {
      page = const OnboardingScreen(key: ValueKey('onboarding'));
    } else {
      page = const Shell(key: ValueKey('shell'));
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 650),
      switchInCurve: Curves.easeOutCubic,
      child: page,
    );
  }
}
