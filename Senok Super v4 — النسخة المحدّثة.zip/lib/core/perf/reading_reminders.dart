// ──────────────────────────────────────────────────────────────────────────
//  تذكيرات القراءة — لافتات داخل التطبيق فقط
//  ──────────────────────────────────────────────────────────────────────────
//  مهم: لا يستخدم هذا الملف أي حزمة إشعارات نظام (flutter_local_notifications
//  غير مضمّنة في التطبيق)، فكل التذكيرات لافتات تظهر داخل التطبيق عند
//  فتحه، وتُحفظ في SharedPreferences. الواجهة توضح ذلك للمستخدم صراحةً.
//  النصوص قواعديّة بالكامل: قوالب عربية تُختار حسب الوقت والمواظبة والهدف،
//  بلا أي توليد ذكي.
// ──────────────────────────────────────────────────────────────────────────
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// نوع التذكير.
enum ReminderKind {
  daily('تذكير يومي', 'حان وقت قراءتك اليومية'),
  streak('المواظبة', 'حافظ على سلسلة أيامك'),
  newChapter('فصل جديد', 'صدر فصل جديد في عمل تتابعه'),
  goal('الهدف', 'اقتربتَ من هدف قراءتك'),
  welcomeBack('عودة', 'اشتقنا لقراءتك');

  const ReminderKind(this.label, this.hint);
  final String label;
  final String hint;

  static ReminderKind fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => ReminderKind.daily,
      );
}

/// تذكير واحد مجدول أو معروض.
@immutable
class ReadingReminder {
  const ReadingReminder({
    required this.id,
    required this.kind,
    required this.title,
    required this.body,
    required this.scheduledFor,
    this.seriesId,
    this.chapter,
    this.actionLabel = 'اقرأ الآن',
    this.delivered = false,
    this.dismissed = false,
    this.snoozedUntil,
  });

  final String id;
  final ReminderKind kind;
  final String title;
  final String body;
  final DateTime scheduledFor;
  final String? seriesId;
  final int? chapter;
  final String actionLabel;
  final bool delivered;
  final bool dismissed;
  final DateTime? snoozedUntil;

  bool isDue(DateTime now) =>
      !delivered && !dismissed && !scheduledFor.isAfter(now) &&
      (snoozedUntil == null || !snoozedUntil!.isAfter(now));

  bool get isActive => !delivered && !dismissed;

  ReadingReminder copyWith({
    bool? delivered,
    bool? dismissed,
    DateTime? snoozedUntil,
    DateTime? scheduledFor,
  }) {
    return ReadingReminder(
      id: id,
      kind: kind,
      title: title,
      body: body,
      scheduledFor: scheduledFor ?? this.scheduledFor,
      seriesId: seriesId,
      chapter: chapter,
      actionLabel: actionLabel,
      delivered: delivered ?? this.delivered,
      dismissed: dismissed ?? this.dismissed,
      snoozedUntil: snoozedUntil ?? this.snoozedUntil,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'title': title,
        'body': body,
        'scheduledFor': scheduledFor.millisecondsSinceEpoch,
        'seriesId': seriesId,
        'chapter': chapter,
        'actionLabel': actionLabel,
        'delivered': delivered,
        'dismissed': dismissed,
        'snoozedUntil': snoozedUntil?.millisecondsSinceEpoch,
      };

  factory ReadingReminder.fromJson(Map<String, dynamic> j) {
    return ReadingReminder(
      id: '${j['id']}',
      kind: ReminderKind.fromName(j['kind'] as String?),
      title: '${j['title'] ?? ''}',
      body: '${j['body'] ?? ''}',
      scheduledFor: j['scheduledFor'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['scheduledFor'] as num).toInt())
          : DateTime.now(),
      seriesId: j['seriesId'] as String?,
      chapter: (j['chapter'] as num?)?.toInt(),
      actionLabel: '${j['actionLabel'] ?? 'اقرأ الآن'}',
      delivered: j['delivered'] == true,
      dismissed: j['dismissed'] == true,
      snoozedUntil: j['snoozedUntil'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['snoozedUntil'] as num).toInt())
          : null,
    );
  }
}

/// إعدادات التذكيرات.
@immutable
class ReminderSettings {
  const ReminderSettings({
    this.enabled = true,
    this.dailyHour = 20,
    this.dailyMinute = 0,
    this.daysOfWeek = const <int>{1, 2, 3, 4, 5, 6, 7},
    this.quietStartHour = 23,
    this.quietEndHour = 8,
    this.streakReminders = true,
    this.newChapterReminders = true,
    this.goalReminders = true,
    this.maxPerDay = 3,
  });

  final bool enabled;
  final int dailyHour;
  final int dailyMinute;
  final Set<int> daysOfWeek;
  final int quietStartHour;
  final int quietEndHour;
  final bool streakReminders;
  final bool newChapterReminders;
  final bool goalReminders;
  final int maxPerDay;

  String get dailyTimeLabel =>
      '${dailyHour.toString().padLeft(2, '0')}:${dailyMinute.toString().padLeft(2, '0')}';

  String get quietLabel =>
      'من ${quietStartHour.toString().padLeft(2, '0')}:00 إلى ${quietEndHour.toString().padLeft(2, '0')}:00';

  bool isDayEnabled(int weekday) => daysOfWeek.contains(weekday);

  /// هل الوقت الحالي داخل ساعات الهدوء؟
  bool isQuietAt(DateTime at) {
    final h = at.hour;
    if (quietStartHour == quietEndHour) return false;
    if (quietStartHour < quietEndHour) {
      return h >= quietStartHour && h < quietEndHour;
    }
    return h >= quietStartHour || h < quietEndHour;
  }

  ReminderSettings copyWith({
    bool? enabled,
    int? dailyHour,
    int? dailyMinute,
    Set<int>? daysOfWeek,
    int? quietStartHour,
    int? quietEndHour,
    bool? streakReminders,
    bool? newChapterReminders,
    bool? goalReminders,
    int? maxPerDay,
  }) {
    return ReminderSettings(
      enabled: enabled ?? this.enabled,
      dailyHour: dailyHour ?? this.dailyHour,
      dailyMinute: dailyMinute ?? this.dailyMinute,
      daysOfWeek: daysOfWeek ?? this.daysOfWeek,
      quietStartHour: quietStartHour ?? this.quietStartHour,
      quietEndHour: quietEndHour ?? this.quietEndHour,
      streakReminders: streakReminders ?? this.streakReminders,
      newChapterReminders: newChapterReminders ?? this.newChapterReminders,
      goalReminders: goalReminders ?? this.goalReminders,
      maxPerDay: maxPerDay ?? this.maxPerDay,
    );
  }

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'dailyHour': dailyHour,
        'dailyMinute': dailyMinute,
        'daysOfWeek': daysOfWeek.toList(),
        'quietStartHour': quietStartHour,
        'quietEndHour': quietEndHour,
        'streakReminders': streakReminders,
        'newChapterReminders': newChapterReminders,
        'goalReminders': goalReminders,
        'maxPerDay': maxPerDay,
      };

  factory ReminderSettings.fromJson(Map<String, dynamic> j) {
    return ReminderSettings(
      enabled: j['enabled'] as bool? ?? true,
      dailyHour: (j['dailyHour'] as num?)?.toInt() ?? 20,
      dailyMinute: (j['dailyMinute'] as num?)?.toInt() ?? 0,
      daysOfWeek: ((j['daysOfWeek'] as List?) ?? const <int>[1, 2, 3, 4, 5, 6, 7])
          .map((e) => (e as num).toInt())
          .toSet(),
      quietStartHour: (j['quietStartHour'] as num?)?.toInt() ?? 23,
      quietEndHour: (j['quietEndHour'] as num?)?.toInt() ?? 8,
      streakReminders: j['streakReminders'] as bool? ?? true,
      newChapterReminders: j['newChapterReminders'] as bool? ?? true,
      goalReminders: j['goalReminders'] as bool? ?? true,
      maxPerDay: (j['maxPerDay'] as num?)?.toInt() ?? 3,
    );
  }
}

/// بيانات لافتة جاهزة للعرض داخل التطبيق.
@immutable
class ReminderBannerData {
  const ReminderBannerData({
    required this.reminder,
    required this.icon,
    required this.accent,
  });

  final ReadingReminder reminder;
  final SIconData icon;
  final Color accent;
}

/// قوالب عربية للتذكير اليومي حسب وقت اليوم.
class DailyReminderTexts {
  DailyReminderTexts._();

  static const List<String> morningTitles = <String>[
    'صباح الخير يا قارئ',
    'ابدأ يومك بفصل',
    'قهوتك بانتظار فصل جديد',
  ];

  static const List<String> eveningTitles = <String>[
    'حان وقت قراءتك المسائية',
    'استرح مع فصل قبل النوم',
    'قصتك بانتظارك الليلة',
  ];

  static const List<String> nightTitles = <String>[
    'فصل أخير قبل النوم؟',
    'الليل للقراءة الهادئة',
  ];

  static const List<String> bodies = <String>[
    'فصل واحد اليوم يكفي للحفاظ على عادتك.',
    'تابِع من حيث توقفت — قصتك لم تنتهِ بعد.',
    'خمس دقائق قراءة خير من لا شيء.',
    'عملك المفضل تقدّم وأنت غائب عنه.',
  ];

  /// يختار عنواناً حسب الساعة (قواعدي: الصباح/المساء/الليل).
  static String titleForHour(int hour, {int seed = 0}) {
    final list = hour < 12 ? morningTitles : (hour < 19 ? eveningTitles : nightTitles);
    return list[seed % list.length];
  }

  static String bodyFor({required int streak, required int minutesToday, int seed = 0}) {
    if (streak >= 7) {
      return 'سلسلتك $streak أيام — لا تكسرها اليوم! فصل واحد يكفي.';
    }
    if (minutesToday > 0) {
      return 'قرأتَ $minutesToday دقيقة اليوم — أكمل فصلاً آخر.';
    }
    return bodies[seed % bodies.length];
  }
}

/// قوالب تذكير المواظبة حسب طول السلسلة.
class StreakReminderTexts {
  StreakReminderTexts._();

  static String titleFor(int streak) {
    if (streak >= 30) return 'سلسلة أسطورية: $streak يوماً!';
    if (streak >= 14) return 'أسبوعان من المواظبة!';
    if (streak >= 7) return 'أسبوع كامل من القراءة!';
    if (streak >= 3) return 'سلسلتك تكبر: $streak أيام';
    return 'ابدأ سلسلة قراءتك اليوم';
  }

  static String bodyFor(int streak) {
    if (streak <= 0) return 'اقرأ فصلاً واحداً اليوم لتبدأ سلسلتك.';
    if (streak >= 30) return 'أنت من القلائل الذين وصلوا إلى $streak يوماً متتالياً. واصل!';
    return 'اقرأ اليوم لتحافظ على سلسلة $streak أيام — غداً تصبح ${streak + 1}.';
  }
}

/// مركز التذكيرات (مفردة): يبني التذكيرات ويجدولها ويعرض المستحق منها.
///
/// دورة الحياة:
///   1. عند فتح التطبيق يستدعي [refreshForToday] بسياق القراءة
///      (المواظبة، دقائق اليوم، الهدف) فيبني تذكير اليوم إن لزم.
///   2. تعرض الواجهة [dueBanners] كلافتات أعلى الصفحة الرئيسية.
///   3. الضغط على «اقرأ الآن» يسلّم التذكير ([markDelivered]) ويفتح العمل.
///   4. «لاحقاً» يؤجّل ساعتين ([snooze])، و«تجاهل» يحذف تذكير اليوم.
class ReminderCenter extends ChangeNotifier {
  ReminderCenter._();
  static final ReminderCenter i = ReminderCenter._();

  /// نسخة اختبار بذاكرة مستقلة.
  factory ReminderCenter.testInstance() => ReminderCenter._();

  static const String _settingsKey = 'sard_reminders_settings_v1';
  static const String _remindersKey = 'sard_reminders_v1';
  static const String _deliveredDayKey = 'sard_reminders_day_v1';
  static const String _deliveryLogKey = 'sard_reminders_log_v1';

  ReminderSettings _settings = const ReminderSettings();
  final List<ReadingReminder> _reminders = <ReadingReminder>[];
  final List<ReminderDeliveryLog> _deliveryLog = <ReminderDeliveryLog>[];
  bool _ready = false;
  String _lastDailyKey = '';

  ReminderSettings get settings => _settings;
  List<ReadingReminder> get reminders => List<ReadingReminder>.unmodifiable(_reminders);
  bool get isReady => _ready;

  List<ReadingReminder> get pending =>
      _reminders.where((r) => r.isActive).toList();

  List<ReminderDeliveryLog> get deliveryLog =>
      List<ReminderDeliveryLog>.unmodifiable(_deliveryLog);

  ReminderDeliveryStats get deliveryStats =>
      ReminderDeliveryStats.fromLog(_deliveryLog);

  /// المستحق الآن (مراعياً ساعات الهدوء والحدّ اليومي).
  List<ReadingReminder> dueReminders({DateTime? now}) {
    final at = now ?? DateTime.now();
    if (!_settings.enabled) return const <ReadingReminder>[];
    if (_settings.isQuietAt(at)) return const <ReadingReminder>[];
    final due = _reminders.where((r) => r.isDue(at)).toList()
      ..sort((a, b) => a.scheduledFor.compareTo(b.scheduledFor));
    if (due.length <= _settings.maxPerDay) return due;
    return due.take(_settings.maxPerDay).toList();
  }

  /// لافتات جاهزة للعرض مع أيقونة ولون حسب النوع.
  List<ReminderBannerData> dueBanners({DateTime? now}) {
    return dueReminders(now: now).map((r) {
      switch (r.kind) {
        case ReminderKind.daily:
          return ReminderBannerData(reminder: r, icon: SardIcons.menu_book_rounded, accent: const Color(0xFFE63E2A));
        case ReminderKind.streak:
          return ReminderBannerData(reminder: r, icon: SardIcons.local_fire_department_rounded, accent: const Color(0xFFF0A21A));
        case ReminderKind.newChapter:
          return ReminderBannerData(reminder: r, icon: SardIcons.notifications_active_rounded, accent: const Color(0xFF0F9D75));
        case ReminderKind.goal:
          return ReminderBannerData(reminder: r, icon: SardIcons.star_rounded, accent: const Color(0xFFE9B44C));
        case ReminderKind.welcomeBack:
          return ReminderBannerData(reminder: r, icon: SardIcons.home_rounded, accent: const Color(0xFF5B5BEA));
      }
    }).toList();
  }

  Future<void> load() async {
    if (_ready) return;
    final p = await SharedPreferences.getInstance();
    try {
      final raw = p.getString(_settingsKey);
      if (raw != null && raw.isNotEmpty) {
        _settings = ReminderSettings.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      }
    } catch (_) {}
    try {
      final raw = p.getString(_remindersKey);
      if (raw != null && raw.isNotEmpty) {
        final list = (jsonDecode(raw) as List).cast<Map>();
        for (final e in list) {
          try {
            _reminders.add(ReadingReminder.fromJson(Map<String, dynamic>.from(e)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    _lastDailyKey = p.getString(_deliveredDayKey) ?? '';
    try {
      final logRaw = p.getString(_deliveryLogKey);
      if (logRaw != null && logRaw.isNotEmpty) {
        final list = (jsonDecode(logRaw) as List).cast<Map>();
        for (final e in list) {
          try {
            _deliveryLog.add(ReminderDeliveryLog.fromJson(Map<String, dynamic>.from(e)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    // تنظيف: احذف المنتهية منذ أكثر من 7 أيام.
    final cutoff = DateTime.now().subtract(const Duration(days: 7));
    _reminders.removeWhere((r) => r.scheduledFor.isBefore(cutoff) && !r.isActive);
    _ready = true;
    await _persist();
    notifyListeners();
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_settingsKey, jsonEncode(_settings.toJson()));
    await p.setString(_remindersKey, jsonEncode(_reminders.map((e) => e.toJson()).toList()));
    await p.setString(_deliveredDayKey, _lastDailyKey);
    await p.setString(_deliveryLogKey, jsonEncode(_deliveryLog.map((e) => e.toJson()).toList()));
  }

  Future<void> updateSettings(ReminderSettings settings) async {
    _settings = settings;
    await _persist();
    notifyListeners();
  }

  /// يبني تذكير اليوم (مرة واحدة يومياً) من سياق القراءة.
  /// يعيد التذكير المنشأ أو null إن لم يلزم (معطّل، يوم غير مفعّل، هادئ).
  Future<ReadingReminder?> refreshForToday({
    required int streak,
    required int minutesToday,
    required int goalChapters,
    required int readChaptersToday,
    DateTime? now,
  }) async {
    await load();
    final at = now ?? DateTime.now();
    if (!_settings.enabled) return null;
    if (!_settings.isDayEnabled(at.weekday)) return null;
    final dayKey = '${at.year}-${at.month}-${at.day}';
    if (_lastDailyKey == dayKey) return null;
    if (minutesToday > 0 && readChaptersToday >= goalChapters && goalChapters > 0) {
      // حقق هدفه اليوم — لا حاجة لتذكير.
      return null;
    }
    final when = DateTime(at.year, at.month, at.day, _settings.dailyHour, _settings.dailyMinute);
    final seed = at.day + at.month;
    ReadingReminder reminder;
    if (_settings.streakReminders && streak >= 3 && streak % 7 == 0) {
      reminder = ReadingReminder(
        id: 'streak_$dayKey',
        kind: ReminderKind.streak,
        title: StreakReminderTexts.titleFor(streak),
        body: StreakReminderTexts.bodyFor(streak),
        scheduledFor: when,
      );
    } else if (_settings.goalReminders && goalChapters > 0 && readChaptersToday < goalChapters) {
      final left = goalChapters - readChaptersToday;
      reminder = ReadingReminder(
        id: 'goal_$dayKey',
        kind: ReminderKind.goal,
        title: 'بقي $left ${left == 1 ? 'فصل' : 'فصول'} على هدفك اليوم',
        body: DailyReminderTexts.bodyFor(streak: streak, minutesToday: minutesToday, seed: seed),
        scheduledFor: when,
      );
    } else {
      reminder = ReadingReminder(
        id: 'daily_$dayKey',
        kind: ReminderKind.daily,
        title: DailyReminderTexts.titleForHour(_settings.dailyHour, seed: seed),
        body: DailyReminderTexts.bodyFor(streak: streak, minutesToday: minutesToday, seed: seed),
        scheduledFor: when,
      );
    }
    _reminders.add(reminder);
    _lastDailyKey = dayKey;
    await _persist();
    notifyListeners();
    return reminder;
  }

  /// يجدول تذكير فصل جديد لعمل يتابعه المستخدم.
  Future<ReadingReminder?> scheduleNewChapter({
    required String seriesId,
    required String seriesTitle,
    required int chapter,
    DateTime? now,
  }) async {
    await load();
    if (!_settings.enabled || !_settings.newChapterReminders) return null;
    final at = now ?? DateTime.now();
    if (_settings.isQuietAt(at)) return null;
    final id = 'new_${seriesId}_$chapter';
    if (_reminders.any((r) => r.id == id && r.isActive)) return null;
    final reminder = ReadingReminder(
      id: id,
      kind: ReminderKind.newChapter,
      title: 'فصل جديد: $seriesTitle',
      body: 'صدر الفصل $chapter — تابِع القراءة من حيث توقفت.',
      scheduledFor: at,
      seriesId: seriesId,
      chapter: chapter,
      actionLabel: 'اقرأ الفصل $chapter',
    );
    _reminders.add(reminder);
    await _persist();
    notifyListeners();
    return reminder;
  }

  /// يجدول تذكير عودة بعد غياب N يوم.
  Future<ReadingReminder?> scheduleWelcomeBack({required int absentDays, DateTime? now}) async {
    await load();
    if (!_settings.enabled || absentDays < 3) return null;
    final at = now ?? DateTime.now();
    final id = 'back_${at.year}_${at.month}_${at.day}';
    if (_reminders.any((r) => r.id == id && r.isActive)) return null;
    final reminder = ReadingReminder(
      id: id,
      kind: ReminderKind.welcomeBack,
      title: 'اشتقنا إليك بعد $absentDays أيام',
      body: 'قصصك بانتظارك — فصل واحد يكفي للعودة إلى عادتك.',
      scheduledFor: at,
    );
    _reminders.add(reminder);
    await _persist();
    notifyListeners();
    return reminder;
  }

  /// موعد التذكير اليومي التالي (للعرض في الإعدادات).
  DateTime nextDailyTime({DateTime? now}) {
    final at = now ?? DateTime.now();
    var next = DateTime(at.year, at.month, at.day, _settings.dailyHour, _settings.dailyMinute);
    if (!next.isAfter(at)) next = next.add(const Duration(days: 1));
    while (!_settings.isDayEnabled(next.weekday)) {
      next = next.add(const Duration(days: 1));
    }
    return next;
  }

  Future<void> markDelivered(String id) async {
    final index = _reminders.indexWhere((r) => r.id == id);
    if (index < 0) return;
    final reminder = _reminders[index];
    _reminders[index] = reminder.copyWith(delivered: true);
    _deliveryLog.add(ReminderDeliveryLog(
      reminderId: id,
      kind: reminder.kind,
      deliveredAt: DateTime.now(),
    ));
    while (_deliveryLog.length > 30) {
      _deliveryLog.removeAt(0);
    }
    await _persist();
    notifyListeners();
  }

  /// يسجّل أن المستخدم ضغط إجراء التذكير (فتح العمل) بعد تسليمه.
  Future<void> markActionTaken(String id) async {
    for (var i = _deliveryLog.length - 1; i >= 0; i--) {
      if (_deliveryLog[i].reminderId == id && !_deliveryLog[i].actionTaken) {
        _deliveryLog[i] = ReminderDeliveryLog(
          reminderId: _deliveryLog[i].reminderId,
          kind: _deliveryLog[i].kind,
          deliveredAt: _deliveryLog[i].deliveredAt,
          actionTaken: true,
        );
        await _persist();
        notifyListeners();
        return;
      }
    }
  }

  Future<void> dismiss(String id) async {
    final index = _reminders.indexWhere((r) => r.id == id);
    if (index < 0) return;
    _reminders[index] = _reminders[index].copyWith(dismissed: true);
    await _persist();
    notifyListeners();
  }

  Future<void> snooze(String id, {Duration by = const Duration(hours: 2), DateTime? now}) async {
    final index = _reminders.indexWhere((r) => r.id == id);
    if (index < 0) return;
    final r = _reminders[index];
    _reminders[index] = r.copyWith(snoozedUntil: (now ?? DateTime.now()).add(by));
    await _persist();
    notifyListeners();
  }

  Future<void> dismissAllDue({DateTime? now}) async {
    final at = now ?? DateTime.now();
    var changed = false;
    for (var k = 0; k < _reminders.length; k++) {
      if (_reminders[k].isDue(at)) {
        _reminders[k] = _reminders[k].copyWith(dismissed: true);
        changed = true;
      }
    }
    if (changed) {
      await _persist();
      notifyListeners();
    }
  }

  /// مسح الحالة بالكامل (للاختبارات فقط).
  Future<void> resetForTest() async {
    _settings = const ReminderSettings();
    _reminders.clear();
    _deliveryLog.clear();
    _lastDailyKey = '';
    _ready = false;
    final p = await SharedPreferences.getInstance();
    await p.remove(_settingsKey);
    await p.remove(_remindersKey);
    await p.remove(_deliveredDayKey);
    await p.remove(_deliveryLogKey);
    notifyListeners();
  }
}

/// لافتة تذكير داخل التطبيق: عنوان + نص + زر الإجراء + «لاحقاً» و«تجاهل».
class ReminderBanner extends StatelessWidget {
  const ReminderBanner({
    super.key,
    required this.data,
    this.onAction,
    this.onSnooze,
    this.onDismiss,
  });

  final ReminderBannerData data;
  final VoidCallback? onAction;
  final VoidCallback? onSnooze;
  final VoidCallback? onDismiss;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final r = data.reminder;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.9)),
        border: Border.all(color: tint(data.accent, 0.35), width: 1),
        boxShadow: softShadow(p, strength: 0.6),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(color: tint(data.accent, 0.14), shape: BoxShape.circle),
            child: SIcon(data.icon, size: 20, color: data.accent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(r.title, style: context.ts(size: 14, w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(r.body, style: context.ts(size: 12.5, color: p.textDim)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    if (onAction != null)
                      _BannerButton(label: r.actionLabel, filled: true, accent: data.accent, onTap: onAction!),
                    const SizedBox(width: 8),
                    if (onSnooze != null)
                      _BannerButton(label: 'لاحقاً', filled: false, accent: p.textDim, onTap: onSnooze!),
                    const Spacer(),
                    if (onDismiss != null)
                      InkWell(
                        onTap: onDismiss,
                        borderRadius: BorderRadius.circular(20),
                        child: Padding(
                          padding: const EdgeInsets.all(4),
                          child: SIcon(SardIcons.close_rounded, size: 16, color: p.textDim),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BannerButton extends StatelessWidget {
  const _BannerButton({required this.label, required this.filled, required this.accent, required this.onTap});
  final String label;
  final bool filled;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: filled ? accent : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: filled ? accent : p.border),
        ),
        child: Text(
          label,
          style: context.ts(
            size: 12,
            w: FontWeight.w700,
            color: filled ? Colors.white : p.text,
          ),
        ),
      ),
    );
  }
}

/// أسماء أيام الأسبوع العربية (1 = الاثنين ... 7 = الأحد).
const List<String> kArabicWeekdays = <String>[
  'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد',
];

String arabicWeekdayName(int weekday) {
  if (weekday < 1 || weekday > 7) return '';
  return kArabicWeekdays[weekday - 1];
}

/// سجل تذكير مُسلَّم (للأرشيف و«كم مرة ذكّرتك هذا الأسبوع؟»).
@immutable
class ReminderDeliveryLog {
  const ReminderDeliveryLog({
    required this.reminderId,
    required this.kind,
    required this.deliveredAt,
    this.actionTaken = false,
  });

  final String reminderId;
  final ReminderKind kind;
  final DateTime deliveredAt;
  final bool actionTaken;

  Map<String, dynamic> toJson() => {
        'reminderId': reminderId,
        'kind': kind.name,
        'deliveredAt': deliveredAt.millisecondsSinceEpoch,
        'actionTaken': actionTaken,
      };

  factory ReminderDeliveryLog.fromJson(Map<String, dynamic> j) {
    return ReminderDeliveryLog(
      reminderId: '${j['reminderId']}',
      kind: ReminderKind.fromName(j['kind'] as String?),
      deliveredAt: j['deliveredAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['deliveredAt'] as num).toInt())
          : DateTime.now(),
      actionTaken: j['actionTaken'] == true,
    );
  }
}

/// نصوص تذكير الهدف حسب المتبقي.
class GoalReminderTexts {
  GoalReminderTexts._();

  static String titleFor(int left) {
    if (left <= 0) return 'حققتَ هدفك اليوم!';
    if (left == 1) return 'بقي فصل واحد على هدفك';
    return 'بقي $left فصول على هدفك اليوم';
  }

  static String bodyFor(int left, int read) {
    if (left <= 0) return 'أحسنت! قرأتَ $read ${read == 1 ? 'فصلاً' : 'فصولاً'} اليوم — استرح أو واصل إن أردت.';
    return 'قرأتَ $read ${read == 1 ? 'فصلاً' : 'فصولاً'} حتى الآن — فصل واحد كل حين يكفي.';
  }
}

/// نصوص تذكير العودة بعد غياب.
class WelcomeBackTexts {
  WelcomeBackTexts._();

  static String titleFor(int absentDays) {
    if (absentDays >= 30) return 'غياب طويل — أهلاً بعودتك!';
    if (absentDays >= 14) return 'اشتقنا إليك بعد $absentDays يوماً';
    return 'أهلاً بعودتك بعد $absentDays أيام';
  }

  static String bodyFor(int absentDays) {
    if (absentDays >= 30) {
      return 'مرّ شهر كامل — قصصك ما زالت هنا بانتظارك، ابدأ بفصل واحد.';
    }
    return 'فصل واحد يكفي للعودة إلى عادتك — لا حاجة للّحاق بكل ما فات.';
  }
}

/// خطة تذكيرات الأسبوع (أي الأيام فيها تذكير ومتى).
@immutable
class ReminderWeekPlan {
  const ReminderWeekPlan({required this.days});

  /// اليوم (1=الاثنين..7=الأحد) ← وقت التذكير
  final Map<int, DateTime> days;

  bool hasReminderOn(int weekday) => days.containsKey(weekday);
  int get activeDays => days.length;

  String get summary {
    if (days.isEmpty) return 'لا تذكيرات مجدولة هذا الأسبوع';
    final names = days.keys.map(arabicWeekdayName).join('، ');
    return 'تذكيرات في: $names';
  }
}

/// امتدادات على مركز التذكيرات: السجل وخطة الأسبوع.
extension ReminderCenterHistory on ReminderCenter {

  /// يبني خطة الأسبوع الحالي من الإعدادات (الأيام المفعّلة + الوقت).
  ReminderWeekPlan weekPlan({DateTime? now}) {
    final at = now ?? DateTime.now();
    final days = <int, DateTime>{};
    // ابدأ من يوم الاثنين لهذا الأسبوع.
    final monday = at.subtract(Duration(days: at.weekday - 1));
    for (var i = 0; i < 7; i++) {
      final day = monday.add(Duration(days: i));
      if (!settings.isDayEnabled(day.weekday)) continue;
      if (day.isBefore(DateTime(at.year, at.month, at.day))) continue;
      days[day.weekday] = DateTime(
        day.year, day.month, day.day,
        settings.dailyHour, settings.dailyMinute,
      );
    }
    return ReminderWeekPlan(days: days);
  }

  /// يبني تذكير هدف صريح (للعرض الفوري دون انتظار الموعد اليومي).
  ReadingReminder buildGoalReminder({required int goalChapters, required int readChaptersToday}) {
    final left = (goalChapters - readChaptersToday).clamp(0, 1 << 30).toInt();
    return ReadingReminder(
      id: 'goal_now_${DateTime.now().millisecondsSinceEpoch}',
      kind: ReminderKind.goal,
      title: GoalReminderTexts.titleFor(left),
      body: GoalReminderTexts.bodyFor(left, readChaptersToday),
      scheduledFor: DateTime.now(),
    );
  }

  /// يبني تذكير عودة صريحاً.
  ReadingReminder buildWelcomeBackReminder({required int absentDays}) {
    return ReadingReminder(
      id: 'back_now_${DateTime.now().millisecondsSinceEpoch}',
      kind: ReminderKind.welcomeBack,
      title: WelcomeBackTexts.titleFor(absentDays),
      body: WelcomeBackTexts.bodyFor(absentDays),
      scheduledFor: DateTime.now(),
    );
  }
}

/// إحصاءات تسليم التذكيرات (هذا الأسبوع): كم ذُكِّرت وكم تفاعلت.
@immutable
class ReminderDeliveryStats {
  const ReminderDeliveryStats({
    required this.deliveredThisWeek,
    required this.actionTakenThisWeek,
    required this.totalDelivered,
  });

  final int deliveredThisWeek;
  final int actionTakenThisWeek;
  final int totalDelivered;

  double get actionRate => deliveredThisWeek == 0 ? 0 : actionTakenThisWeek / deliveredThisWeek;
  String get actionRateLabel => deliveredThisWeek == 0 ? '—' : '${(actionRate * 100).round()}٪';

  factory ReminderDeliveryStats.fromLog(List<ReminderDeliveryLog> log, {DateTime? now}) {
    final at = now ?? DateTime.now();
    final weekAgo = at.subtract(const Duration(days: 7));
    final week = log.where((e) => !e.deliveredAt.isBefore(weekAgo)).toList();
    return ReminderDeliveryStats(
      deliveredThisWeek: week.length,
      actionTakenThisWeek: week.where((e) => e.actionTaken).length,
      totalDelivered: log.length,
    );
  }
}
