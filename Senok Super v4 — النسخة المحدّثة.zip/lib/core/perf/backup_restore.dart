// ──────────────────────────────────────────────────────────────────────────
//  النسخ الاحتياطي والاستعادة — تصدير/استيراد مكتبتك كملف واحد
//  ──────────────────────────────────────────────────────────────────────────
//  • الحزمة JSON موقّعة برأس إصدار + بصمة تحقق (FNV-1a) تكشف أي تلف.
//  • «التشفير» هنا تمويه محلي بسيط (XOR بمفتاح من عبارة المرور + Base64)
//    يخفي المحتوى عن العين العابرة؛ ليس بديلاً عن تشفير حقيقي، والواجهة
//    توضح ذلك صراحةً للمستخدم.
//  • الأقسام: المكتبة (الرفوف والمتابَعات)، التقدّم (مواضع القراءة والفصول
//    المقروءة ووقت القراءة)، الإعدادات، الأختام والمواظبة.
//  • بلا خادم: الملف يُحفظ/يُشارَك بيد المستخدم (مشاركة نظامية أو ملف).
// ──────────────────────────────────────────────────────────────────────────
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// قسم من أقسام النسخة الاحتياطية.
enum BackupSection {
  library('library', 'المكتبة', 'الرفوف والمتابَعات والتوصيات'),
  progress('progress', 'التقدّم', 'مواضع القراءة والفصول المقروءة والوقت'),
  settings('settings', 'الإعدادات', 'الثيم والخط ووضع البيانات والتحميل المسبق'),
  stamps('stamps', 'الأختام والمواظبة', 'الأختام المنالة وأيام القراءة والأرقام القياسية');

  const BackupSection(this.key, this.label, this.hint);
  final String key;
  final String label;
  final String hint;

  static BackupSection? fromKey(String? key) {
    for (final s in BackupSection.values) {
      if (s.key == key) return s;
    }
    return null;
  }
}

/// رأس الحزمة: إصدار الصيغة + وقت الإنشاء + الأقسام + البصمة.
@immutable
class BackupManifest {
  const BackupManifest({
    required this.formatVersion,
    required this.createdAt,
    required this.appVersion,
    required this.sections,
    required this.checksum,
    this.device = '',
  });

  final int formatVersion;
  final DateTime createdAt;
  final String appVersion;
  final List<BackupSection> sections;
  final String checksum;
  final String device;

  Map<String, dynamic> toJson() => {
        'formatVersion': formatVersion,
        'createdAt': createdAt.millisecondsSinceEpoch,
        'appVersion': appVersion,
        'sections': sections.map((e) => e.key).toList(),
        'checksum': checksum,
        'device': device,
      };

  factory BackupManifest.fromJson(Map<String, dynamic> j) {
    return BackupManifest(
      formatVersion: (j['formatVersion'] as num?)?.toInt() ?? 0,
      createdAt: j['createdAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['createdAt'] as num).toInt())
          : DateTime.now(),
      appVersion: '${j['appVersion'] ?? ''}',
      sections: ((j['sections'] as List?) ?? const [])
          .map((e) => BackupSection.fromKey('$e'))
          .whereType<BackupSection>()
          .toList(),
      checksum: '${j['checksum'] ?? ''}',
      device: '${j['device'] ?? ''}',
    );
  }
}

/// حزمة نسخ احتياطي كاملة: رأس + بيانات الأقسام.
@immutable
class BackupPackage {
  const BackupPackage({required this.manifest, required this.data});

  final BackupManifest manifest;
  final Map<String, dynamic> data;

  int get sectionCount => manifest.sections.length;

  bool get hasLibrary => manifest.sections.contains(BackupSection.library);
  bool get hasProgress => manifest.sections.contains(BackupSection.progress);
  bool get hasSettings => manifest.sections.contains(BackupSection.settings);
  bool get hasStamps => manifest.sections.contains(BackupSection.stamps);

  /// حجم الحزمة التقريبي بالبايت (بعد الترميز).
  int get approxBytes => utf8.encode(encode()).length;

  /// ترميز الحزمة إلى نص قابل للمشاركة/الحفظ.
  String encode({String? passphrase}) {
    final payload = jsonEncode({'manifest': manifest.toJson(), 'data': data});
    if (passphrase == null || passphrase.isEmpty) {
      return '${BackupCodec.kPlainPrefix}${base64Url.encode(utf8.encode(payload))}';
    }
    return '${BackupCodec.kLockedPrefix}${BackupCodec.obfuscate(payload, passphrase)}';
  }

  /// فك ترميز نص حزمة (يعيد null إن كان النص تالفاً أو عبارة المرور خاطئة).
  static BackupPackage? decode(String encoded, {String? passphrase}) {
    try {
      final payload = BackupCodec.decodePayload(encoded, passphrase: passphrase);
      if (payload == null) return null;
      final root = Map<String, dynamic>.from(jsonDecode(payload) as Map);
      final manifest = BackupManifest.fromJson(Map<String, dynamic>.from(root['manifest'] as Map));
      final data = Map<String, dynamic>.from(root['data'] as Map);
      if (!BackupCodec.verifyChecksum(data, manifest.checksum)) return null;
      return BackupPackage(manifest: manifest, data: data);
    } catch (_) {
      return null;
    }
  }
}

/// نتيجة فحص نص نسخة قبل استيرادها.
@immutable
class BackupValidation {
  const BackupValidation({
    required this.isValid,
    required this.needsPassphrase,
    this.manifest,
    this.error = '',
  });

  final bool isValid;
  final bool needsPassphrase;
  final BackupManifest? manifest;
  final String error;

  String get describe {
    if (isValid && manifest != null) {
      final m = manifest!;
      final date = '${m.createdAt.year}/${m.createdAt.month}/${m.createdAt.day}';
      return 'نسخة صالحة من $date — ${m.sections.map((s) => s.label).join('، ')}';
    }
    return error.isEmpty ? 'النص ليس نسخة احتياطية صالحة' : error;
  }
}

/// نتيجة استيراد نسخة (ما طُبِّق وما تُخطّى وأي أخطاء).
@immutable
class BackupImportResult {
  const BackupImportResult({
    required this.applied,
    required this.skipped,
    required this.errors,
    this.manifest,
  });

  final List<BackupSection> applied;
  final List<BackupSection> skipped;
  final List<String> errors;
  final BackupManifest? manifest;

  bool get success => errors.isEmpty;
  int get appliedCount => applied.length;

  String get summary {
    if (!success) return 'اكتمل الاستيراد مع ${errors.length} أخطاء';
    if (applied.isEmpty) return 'لم يُطبَّق أي قسم';
    return 'استُعيد: ${applied.map((s) => s.label).join('، ')}';
  }
}

/// أدوات الترميز والتحقق: بصمة FNV-1a + تمويه XOR + Base64.
class BackupCodec {
  BackupCodec._();

  static const String kPlainPrefix = 'SENOKBK1.';
  static const String kLockedPrefix = 'SENOKBK1L.';
  static const int kFormatVersion = 1;

  /// بصمة FNV-1a (32 بت) بالنظام الست عشري — تكشف التلف لا التزوير.
  static String checksumOf(String payload) {
    var hash = 0x811c9dc5;
    for (final byte in utf8.encode(payload)) {
      hash ^= byte;
      hash = (hash * 0x01000193) & 0xffffffff;
    }
    return hash.toRadixString(16).padLeft(8, '0');
  }

  static bool verifyChecksum(Map<String, dynamic> data, String checksum) {
    return checksumOf(jsonEncode(data)) == checksum;
  }

  /// تمويه XOR بمفتاح مشتق من عبارة المرور، ثم Base64.
  /// ملاحظة: تمويه لا تشفير — لا يحمي من مهاجم مصمّم.
  static String obfuscate(String plain, String passphrase) {
    final key = _keyBytes(passphrase);
    final bytes = utf8.encode(plain);
    final out = List<int>.generate(bytes.length, (i) => bytes[i] ^ key[i % key.length]);
    return base64Url.encode(out);
  }

  static String? deobfuscate(String encoded, String passphrase) {
    try {
      final key = _keyBytes(passphrase);
      final bytes = base64Url.decode(encoded);
      final out = List<int>.generate(bytes.length, (i) => bytes[i] ^ key[i % key.length]);
      return utf8.decode(out);
    } catch (_) {
      return null;
    }
  }

  static List<int> _keyBytes(String passphrase) {
    final raw = utf8.encode(passphrase);
    if (raw.isEmpty) return <int>[0];
    // خلط بسيط يطوّل المفتاح القصير ويمنع تكرار النمط المباشر.
    final out = <int>[];
    var seed = 0x9e3779b9;
    for (var i = 0; i < 64; i++) {
      seed = (seed * 31 + raw[i % raw.length] + i) & 0xffffffff;
      out.add((seed >> 16) & 0xff);
    }
    return out;
  }

  /// يستخرج الحمولة JSON من نص مرمّز (null إن تعذّر أو كانت عبارة المرور خاطئة).
  static String? decodePayload(String encoded, {String? passphrase}) {
    final text = encoded.trim();
    if (text.startsWith(kLockedPrefix)) {
      if (passphrase == null || passphrase.isEmpty) return null;
      final payload = deobfuscate(text.substring(kLockedPrefix.length), passphrase);
      if (payload == null) return null;
      // تحقق سريع من سلامة فك التمويه: يجب أن يبدأ بـ {.
      if (!payload.trimLeft().startsWith('{')) return null;
      return payload;
    }
    if (text.startsWith(kPlainPrefix)) {
      try {
        return utf8.decode(base64Url.decode(text.substring(kPlainPrefix.length)));
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  /// يبني حزمة من بيانات الأقسام (يحسب البصمة تلقائياً).
  static BackupPackage build({
    required Map<String, dynamic> data,
    required List<BackupSection> sections,
    String appVersion = '0.2.0',
    String device = '',
  }) {
    final manifest = BackupManifest(
      formatVersion: kFormatVersion,
      createdAt: DateTime.now(),
      appVersion: appVersion,
      sections: sections,
      checksum: checksumOf(jsonEncode(data)),
      device: device,
    );
    return BackupPackage(manifest: manifest, data: data);
  }
}

/// مخزن النسخ الاحتياطي: يجمع بيانات التطبيق من SharedPreferences ويعيد تطبيقها.
///
/// مفاتيح البيانات (مطابقة لـ SettingsController والمخازن الأخرى):
///   المكتبة: followed_series, shelf_fav, shelf_later, recommended, series_cache, profile_bio
///   التقدّم: progress, read_chapters, reading_seconds, read_days
///   الإعدادات: theme, accent_id, data_mode, prefetch_mode, font_scale, companion_name,
///             companion_mood, reader_mode, reader_brightness, reader_auto_speed,
///             keep_awake, chain_chapters
///   الأختام: stamps, night_seconds, best_streak, best_day_chapters
class BackupStore extends ChangeNotifier {
  BackupStore._();
  static final BackupStore i = BackupStore._();

  /// نسخة اختبار بذاكرة مستقلة.
  factory BackupStore.testInstance() => BackupStore._();

  static const String _autoKey = 'sard_backup_auto_v1';
  static const String _lastKey = 'sard_backup_last_v1';

  static const Map<BackupSection, List<String>> sectionKeys = {
    BackupSection.library: <String>[
      'followed_series', 'shelf_fav', 'shelf_later', 'recommended',
      'series_cache', 'profile_bio',
    ],
    BackupSection.progress: <String>[
      'progress', 'read_chapters', 'reading_seconds', 'read_days',
    ],
    BackupSection.settings: <String>[
      'theme', 'accent_id', 'data_mode', 'prefetch_mode', 'font_scale',
      'companion_name', 'companion_mood', 'reader_mode', 'reader_brightness',
      'reader_auto_speed', 'keep_awake', 'chain_chapters',
    ],
    BackupSection.stamps: <String>[
      'stamps', 'night_seconds', 'best_streak', 'best_day_chapters',
    ],
  };

  bool _autoEnabled = false;
  int _autoIntervalDays = 7;
  DateTime? _lastBackupAt;
  bool _ready = false;

  bool get autoEnabled => _autoEnabled;
  int get autoIntervalDays => _autoIntervalDays;
  DateTime? get lastBackupAt => _lastBackupAt;
  bool get isReady => _ready;

  /// هل حان موعد النسخة التلقائية؟
  bool get isAutoBackupDue {
    if (!_autoEnabled || _lastBackupAt == null) return _autoEnabled;
    return DateTime.now().difference(_lastBackupAt!).inDays >= _autoIntervalDays;
  }

  Future<void> load() async {
    if (_ready) return;
    final p = await SharedPreferences.getInstance();
    _autoEnabled = p.getBool(_autoKey) ?? false;
    _autoIntervalDays = (p.getInt('${_autoKey}_days') ?? 7).clamp(1, 30).toInt();
    final last = p.getInt(_lastKey);
    if (last != null) _lastBackupAt = DateTime.fromMillisecondsSinceEpoch(last);
    _ready = true;
    notifyListeners();
  }

  Future<void> setAutoBackup(bool enabled, {int? intervalDays}) async {
    _autoEnabled = enabled;
    if (intervalDays != null) {
      _autoIntervalDays = intervalDays.clamp(1, 30).toInt();
    }
    final p = await SharedPreferences.getInstance();
    await p.setBool(_autoKey, _autoEnabled);
    await p.setInt('${_autoKey}_days', _autoIntervalDays);
    notifyListeners();
  }

  /// يجمع بيانات الأقسام المطلوبة من التخزين الدائم.
  Future<Map<String, dynamic>> collect(Set<BackupSection> sections) async {
    final p = await SharedPreferences.getInstance();
    final out = <String, dynamic>{};
    for (final section in sections) {
      final sectionData = <String, dynamic>{};
      for (final key in sectionKeys[section] ?? const <String>[]) {
        final value = _readPref(p, key);
        if (value != null) sectionData[key] = value;
      }
      out[section.key] = sectionData;
    }
    return out;
  }

  static dynamic _readPref(SharedPreferences p, String key) {
    if (p.containsKey(key)) {
      final v = p.get(key);
      if (v is String || v is int || v is double || v is bool || v is List<String>) {
        return v;
      }
    }
    return null;
  }

  /// ينشئ حزمة نسخ احتياطي من الأقسام المطلوبة.
  Future<BackupPackage> exportBackup({
    Set<BackupSection> sections = const {
      BackupSection.library,
      BackupSection.progress,
      BackupSection.settings,
      BackupSection.stamps,
    },
    String appVersion = '0.2.0',
  }) async {
    final data = await collect(sections);
    final package = BackupCodec.build(
      data: data,
      sections: sections.toList(),
      appVersion: appVersion,
    );
    final p = await SharedPreferences.getInstance();
    _lastBackupAt = DateTime.now();
    await p.setInt(_lastKey, _lastBackupAt!.millisecondsSinceEpoch);
    notifyListeners();
    return package;
  }

  /// يفحص نص نسخة دون تطبيقها.
  BackupValidation validate(String encoded, {String? passphrase}) {
    final text = encoded.trim();
    if (text.isEmpty) {
      return const BackupValidation(isValid: false, needsPassphrase: false, error: 'النص فارغ');
    }
    if (text.startsWith(BackupCodec.kLockedPrefix) && (passphrase == null || passphrase.isEmpty)) {
      return const BackupValidation(
        isValid: false,
        needsPassphrase: true,
        error: 'هذه النسخة محمية بعبارة مرور',
      );
    }
    final package = BackupPackage.decode(text, passphrase: passphrase);
    if (package == null) {
      return const BackupValidation(
        isValid: false,
        needsPassphrase: false,
        error: 'تعذّر قراءة النسخة — تأكد من النص أو عبارة المرور',
      );
    }
    if (package.manifest.formatVersion > BackupCodec.kFormatVersion) {
      return BackupValidation(
        isValid: false,
        needsPassphrase: false,
        manifest: package.manifest,
        error: 'النسخة من إصدار أحدث لا يدعمه هذا التطبيق',
      );
    }
    return BackupValidation(isValid: true, needsPassphrase: false, manifest: package.manifest);
  }

  /// يستورد نسخة ويطبّق أقسامها. يعيد نتيجة مفصّلة.
  /// ملاحظة: بعد الاستيراد يجب إعادة تحميل SettingsController (load) لالتقاط
  /// القيم الجديدة في الذاكرة.
  Future<BackupImportResult> importBackup(
    String encoded, {
    String? passphrase,
    Set<BackupSection>? onlySections,
  }) async {
    final validation = validate(encoded, passphrase: passphrase);
    if (!validation.isValid || validation.manifest == null) {
      return BackupImportResult(
        applied: const <BackupSection>[],
        skipped: const <BackupSection>[],
        errors: <String>[validation.error],
      );
    }
    final package = BackupPackage.decode(encoded, passphrase: passphrase);
    if (package == null) {
      return const BackupImportResult(
        applied: <BackupSection>[],
        skipped: <BackupSection>[],
        errors: <String>['تعذّر قراءة النسخة'],
      );
    }
    final applied = <BackupSection>[];
    final skipped = <BackupSection>[];
    final errors = <String>[];
    final p = await SharedPreferences.getInstance();
    for (final section in package.manifest.sections) {
      if (onlySections != null && !onlySections.contains(section)) {
        skipped.add(section);
        continue;
      }
      final sectionData = package.data[section.key];
      if (sectionData is! Map) {
        skipped.add(section);
        continue;
      }
      try {
        for (final entry in sectionData.entries) {
          await _writePref(p, '${entry.key}', entry.value);
        }
        applied.add(section);
      } catch (e) {
        errors.add('تعذّر قسم ${section.label}');
        skipped.add(section);
      }
    }
    notifyListeners();
    return BackupImportResult(
      applied: applied,
      skipped: skipped,
      errors: errors,
      manifest: package.manifest,
    );
  }

  static Future<void> _writePref(SharedPreferences p, String key, dynamic value) async {
    if (value is String) {
      await p.setString(key, value);
    } else if (value is int) {
      await p.setInt(key, value);
    } else if (value is double) {
      await p.setDouble(key, value);
    } else if (value is bool) {
      await p.setBool(key, value);
    } else if (value is List) {
      await p.setStringList(key, value.map((e) => '$e').toList());
    }
  }

  /// ملخص نصي عربي لحزمة (للعرض قبل الاستيراد).
  static String describePackage(BackupPackage package) {
    final m = package.manifest;
    final date = '${m.createdAt.year}/${m.createdAt.month.toString().padLeft(2, '0')}/${m.createdAt.day.toString().padLeft(2, '0')}';
    final sections = m.sections.map((s) => s.label).join('، ');
    final size = formatBackupSize(package.approxBytes);
    return 'نسخة $date · $sections · $size';
  }

  static String formatBackupSize(int bytes) {
    if (bytes < 1024) return '$bytes ب';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} ك.ب';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} م.ب';
  }

  /// عدد الأعمال والفصول في نسخة (تقدير سريع من بياناتها).
  static Map<String, int> estimateContents(BackupPackage package) {
    var series = 0;
    var chapters = 0;
    try {
      final progress = package.data['progress'];
      if (progress is Map) {
        final read = progress['read_chapters'];
        if (read is String) {
          final map = Map<String, dynamic>.from(jsonDecode(read) as Map);
          series = map.length;
          for (final v in map.values) {
            if (v is List) chapters += v.length;
          }
        }
      }
    } catch (_) {}
    return {'series': series, 'chapters': chapters};
  }

  /// يبني نسخة تجريبية صغيرة (للاختبار والمعاينة دون بيانات حقيقية).
  static BackupPackage demoPackage() {
    final data = <String, dynamic>{
      'library': <String, dynamic>{
        'followed_series': <String>['demo_1'],
        'shelf_fav': <String>['demo_1'],
      },
      'progress': <String, dynamic>{
        'read_chapters': jsonEncode(<String, dynamic>{'demo_1': <int>[1, 2, 3]}),
      },
      'settings': <String, dynamic>{'theme': 'obsidian'},
      'stamps': <String, dynamic>{'best_streak': 3},
    };
    return BackupCodec.build(data: data, sections: BackupSection.values, appVersion: '0.2.0');
  }

  /// مسح الحالة بالكامل (للاختبارات فقط).
  Future<void> resetForTest() async {
    _autoEnabled = false;
    _autoIntervalDays = 7;
    _lastBackupAt = null;
    _ready = false;
    final p = await SharedPreferences.getInstance();
    await p.remove(_autoKey);
    await p.remove('${_autoKey}_days');
    await p.remove(_lastKey);
    notifyListeners();
  }
}

/// أقصى حجم مقبول لملف نسخة يُستورد (10 م.ب).
const int kMaxBackupBytes = 10 * 1024 * 1024;

/// يتحقق من حجم نص نسخة قبل محاولة فكّه.
bool backupSizeAcceptable(String encoded) => utf8.encode(encoded).length <= kMaxBackupBytes;

/// أسماء الأقسام العربية لقائمة اختيار سريعة.
List<String> backupSectionLabels(Set<BackupSection> sections) =>
    sections.map((s) => s.label).toList();

/// مساعد ملفات النسخ الاحتياطي: كتابة الحزمة إلى ملف وقراءتها منه.
///
/// يُستعمل من الإعدادات الاحترافية لخيار «حفظ كملف» بدل نسخ النص.
/// الملفات تُحفظ في مجلد مستندات التطبيق باسم يتضمن التاريخ.
class BackupFileHelper {
  BackupFileHelper._();

  static const String kFilePrefix = 'senok_backup_';
  static const String kFileExtension = '.senokbk';

  /// يكتب حزمة مرمّزة إلى ملف جديد ويعيد مساره.
  static Future<String> writeToFile(String encoded, {String? passphrase}) async {
    final dir = await getApplicationDocumentsDirectory();
    final now = DateTime.now();
    final stamp = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}'
        '_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
    final file = File('${dir.path}/$kFilePrefix$stamp$kFileExtension');
    await file.writeAsString(encoded, flush: true);
    return file.path;
  }

  /// يقرأ نص نسخة من ملف (null إن تعذّر).
  static Future<String?> readFromFile(String path) async {
    try {
      final file = File(path);
      if (!await file.exists()) return null;
      final text = await file.readAsString();
      if (text.length > kMaxBackupBytes) return null;
      return text;
    } catch (_) {
      return null;
    }
  }

  /// يسرد ملفات النسخ المحفوظة محلياً (الأحدث أولاً).
  static Future<List<BackupLocalFile>> listLocalBackups() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      if (!await dir.exists()) return const <BackupLocalFile>[];
      final out = <BackupLocalFile>[];
      await for (final entity in dir.list(followLinks: false)) {
        if (entity is! File) continue;
        final name = entity.path.split(Platform.pathSeparator).last;
        if (!name.startsWith(kFilePrefix) || !name.endsWith(kFileExtension)) continue;
        final stat = await entity.stat();
        out.add(BackupLocalFile(path: entity.path, bytes: stat.size, modified: stat.modified));
      }
      out.sort((a, b) => b.modified.compareTo(a.modified));
      return out;
    } catch (_) {
      return const <BackupLocalFile>[];
    }
  }

  /// يحذف ملف نسخة محلية.
  static Future<bool> deleteLocalBackup(String path) async {
    try {
      await File(path).delete();
      return true;
    } catch (_) {
      return false;
    }
  }
}

/// ملف نسخة محفوظ محلياً.
@immutable
class BackupLocalFile {
  const BackupLocalFile({required this.path, required this.bytes, required this.modified});
  final String path;
  final int bytes;
  final DateTime modified;

  String get name => path.split(Platform.pathSeparator).last;
  String get sizeLabel => BackupStore.formatBackupSize(bytes);
  String get dateLabel => '${modified.year}/${modified.month}/${modified.day}';
}

/// جدول النسخ التلقائي: كل كم يوم + آخر نسخة + التالية.
@immutable
class BackupSchedule {
  const BackupSchedule({required this.intervalDays, this.lastBackupAt});

  final int intervalDays;
  final DateTime? lastBackupAt;

  bool get isDue {
    if (lastBackupAt == null) return true;
    return DateTime.now().difference(lastBackupAt!).inDays >= intervalDays;
  }

  DateTime? get nextDueAt => lastBackupAt?.add(Duration(days: intervalDays));

  String get nextDueLabel {
    final next = nextDueAt;
    if (next == null) return 'لم تُنشأ نسخة بعد';
    final diff = next.difference(DateTime.now()).inDays;
    if (diff <= 0) return 'حان موعد نسخة جديدة';
    if (diff == 1) return 'النسخة التالية غداً';
    return 'النسخة التالية بعد $diff أيام';
  }
}

/// معلومات قسم لعرضها في واجهة اختيار الأقسام.
@immutable
class BackupSectionInfo {
  const BackupSectionInfo({
    required this.section,
    required this.keyCount,
    required this.estimatedBytes,
  });

  final BackupSection section;
  final int keyCount;
  final int estimatedBytes;

  String get sizeLabel => BackupStore.formatBackupSize(estimatedBytes);
}

/// يقدّر حجم كل قسم قبل التصدير (للعرض في واجهة التصدير).
Future<List<BackupSectionInfo>> estimateBackupSections() async {
  final p = await SharedPreferences.getInstance();
  final out = <BackupSectionInfo>[];
  for (final section in BackupSection.values) {
    var keys = 0;
    var bytes = 0;
    for (final key in BackupStore.sectionKeys[section] ?? const <String>[]) {
      final value = p.get(key);
      if (value == null) continue;
      keys++;
      if (value is String) {
        bytes += utf8.encode(value).length;
      } else if (value is List) {
        bytes += utf8.encode(value.join(',')).length;
      } else {
        bytes += 8;
      }
    }
    out.add(BackupSectionInfo(section: section, keyCount: keys, estimatedBytes: bytes));
  }
  return out;
}

/// إعدادات مسبقة للتصدير السريع.
class BackupPresets {
  BackupPresets._();

  static const Set<BackupSection> everything = <BackupSection>{
    BackupSection.library,
    BackupSection.progress,
    BackupSection.settings,
    BackupSection.stamps,
  };

  static const Set<BackupSection> libraryOnly = <BackupSection>{BackupSection.library};

  static const Set<BackupSection> progressOnly = <BackupSection>{BackupSection.progress};
}
