// ──────────────────────────────────────────────────────────────────────────
//  مدير التخزين — قياس المساحة وتنظيفها وفرض الحدود
//  ──────────────────────────────────────────────────────────────────────────
//  يقيس:
//    • التنزيلات (مجلدا v1 وv2)  • ذاكرة صور الشبكة المؤقتة
//    • الملفات المؤقتة العامة   • حجم قاعدة التفضيلات (تقديري)
//  التنظيف قواعدي:
//    • الصور المؤقتة تُمسح كلها (قابلة لإعادة التحميل)
//    • التنزيلات تُحذف بالأقدم اكتمالاً أولاً عند تجاوز الحد
//    • لا يُمسح أبداً: التقدّم، الرفوف، الإعدادات، الأختام
// ──────────────────────────────────────────────────────────────────────────
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'download_engine_v2.dart' show formatBytesAr;

/// مستوى امتلاء التخزين نسبةً إلى الحدّ المضبوط.
enum StorageTier {
  healthy('مريح', 'مساحة كافية'),
  warning('اقترب من الحدّ', 'فكّر بتنظيف الصور المؤقتة'),
  critical('ممتلئ تقريباً', 'نظّف الآن لتفادي توقف التنزيلات');

  const StorageTier(this.label, this.hint);
  final String label;
  final String hint;

  static StorageTier fromFraction(double fraction) {
    if (fraction >= 0.9) return StorageTier.critical;
    if (fraction >= 0.75) return StorageTier.warning;
    return StorageTier.healthy;
  }
}

/// نوع ملف/مجلد في تقرير التخزين.
enum StorageKind {
  downloads('التنزيلات'),
  imageCache('صور مؤقتة'),
  tempFiles('ملفات مؤقتة'),
  other('أخرى');

  const StorageKind(this.label);
  final String label;
}

/// ملف واحد في قائمة «الأكبر حجماً».
@immutable
class StorageEntry {
  const StorageEntry({
    required this.path,
    required this.bytes,
    required this.modified,
    required this.kind,
  });

  final String path;
  final int bytes;
  final DateTime modified;
  final StorageKind kind;

  String get name => path.split(Platform.pathSeparator).last;
  String get sizeLabel => formatBytesAr(bytes);

  /// عمر الملف بالأيام.
  int get ageDays => DateTime.now().difference(modified).inDays;

  Map<String, dynamic> toJson() => {
        'path': path,
        'bytes': bytes,
        'modified': modified.millisecondsSinceEpoch,
        'kind': kind.name,
      };
}

/// لقطة استخدام التخزين في لحظة معينة.
@immutable
class StorageUsage {
  const StorageUsage({
    required this.downloadsBytes,
    required this.imageCacheBytes,
    required this.tempBytes,
    required this.otherBytes,
    required this.downloadsCount,
    required this.cacheFilesCount,
    required this.measuredAt,
  });

  final int downloadsBytes;
  final int imageCacheBytes;
  final int tempBytes;
  final int otherBytes;
  final int downloadsCount;
  final int cacheFilesCount;
  final DateTime measuredAt;

  int get totalBytes => downloadsBytes + imageCacheBytes + tempBytes + otherBytes;
  int get reclaimableBytes => imageCacheBytes + tempBytes;
  String get totalLabel => formatBytesAr(totalBytes);
  String get downloadsLabel => formatBytesAr(downloadsBytes);
  String get imageCacheLabel => formatBytesAr(imageCacheBytes);
  String get tempLabel => formatBytesAr(tempBytes);
  String get reclaimableLabel => formatBytesAr(reclaimableBytes);

  double fractionOf(int limitBytes) =>
      limitBytes <= 0 ? 0 : (totalBytes / limitBytes).clamp(0.0, 1.0);

  StorageTier tierFor(int limitBytes) => StorageTier.fromFraction(fractionOf(limitBytes));

  Map<String, dynamic> toJson() => {
        'downloadsBytes': downloadsBytes,
        'imageCacheBytes': imageCacheBytes,
        'tempBytes': tempBytes,
        'otherBytes': otherBytes,
        'downloadsCount': downloadsCount,
        'cacheFilesCount': cacheFilesCount,
        'measuredAt': measuredAt.millisecondsSinceEpoch,
      };

  factory StorageUsage.fromJson(Map<String, dynamic> j) {
    return StorageUsage(
      downloadsBytes: (j['downloadsBytes'] as num?)?.toInt() ?? 0,
      imageCacheBytes: (j['imageCacheBytes'] as num?)?.toInt() ?? 0,
      tempBytes: (j['tempBytes'] as num?)?.toInt() ?? 0,
      otherBytes: (j['otherBytes'] as num?)?.toInt() ?? 0,
      downloadsCount: (j['downloadsCount'] as num?)?.toInt() ?? 0,
      cacheFilesCount: (j['cacheFilesCount'] as num?)?.toInt() ?? 0,
      measuredAt: j['measuredAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['measuredAt'] as num).toInt())
          : DateTime.now(),
    );
  }

  static StorageUsage get empty => StorageUsage(
        downloadsBytes: 0,
        imageCacheBytes: 0,
        tempBytes: 0,
        otherBytes: 0,
        downloadsCount: 0,
        cacheFilesCount: 0,
        measuredAt: DateTime.fromMillisecondsSinceEpoch(0),
      );
}

/// نتيجة عملية تنظيف.
@immutable
class CleanupResult {
  const CleanupResult({
    required this.freedBytes,
    required this.removedFiles,
    required this.removedKinds,
  });

  final int freedBytes;
  final int removedFiles;
  final List<StorageKind> removedKinds;

  String get freedLabel => formatBytesAr(freedBytes);
  bool get didAnything => freedBytes > 0 || removedFiles > 0;

  String get summary {
    if (!didAnything) return 'لا شيء لتنظيفه — التخزين نظيف';
    return 'حُرّر $freedLabel من ${removedFiles} ملف';
  }
}

/// حدود التخزين التي يضبطها المستخدم.
@immutable
class StorageLimits {
  const StorageLimits({
    this.downloadLimitMB = 2048,
    this.cacheLimitMB = 512,
    this.autoCleanCache = true,
    this.keepDownloadsDays = 0,
  });

  /// حدّ التنزيلات بالميغابايت (0 = بلا حدّ)
  final int downloadLimitMB;
  final int cacheLimitMB;
  final bool autoCleanCache;

  /// حذف التنزيلات المكتملة الأقدم من N يوم (0 = لا حذف تلقائي)
  final int keepDownloadsDays;

  int get downloadLimitBytes => downloadLimitMB * 1024 * 1024;
  int get cacheLimitBytes => cacheLimitMB * 1024 * 1024;

  StorageLimits copyWith({
    int? downloadLimitMB,
    int? cacheLimitMB,
    bool? autoCleanCache,
    int? keepDownloadsDays,
  }) {
    return StorageLimits(
      downloadLimitMB: downloadLimitMB ?? this.downloadLimitMB,
      cacheLimitMB: cacheLimitMB ?? this.cacheLimitMB,
      autoCleanCache: autoCleanCache ?? this.autoCleanCache,
      keepDownloadsDays: keepDownloadsDays ?? this.keepDownloadsDays,
    );
  }

  Map<String, dynamic> toJson() => {
        'downloadLimitMB': downloadLimitMB,
        'cacheLimitMB': cacheLimitMB,
        'autoCleanCache': autoCleanCache,
        'keepDownloadsDays': keepDownloadsDays,
      };

  factory StorageLimits.fromJson(Map<String, dynamic> j) {
    return StorageLimits(
      downloadLimitMB: (j['downloadLimitMB'] as num?)?.toInt() ?? 2048,
      cacheLimitMB: (j['cacheLimitMB'] as num?)?.toInt() ?? 512,
      autoCleanCache: j['autoCleanCache'] as bool? ?? true,
      keepDownloadsDays: (j['keepDownloadsDays'] as num?)?.toInt() ?? 0,
    );
  }
}

/// مدير التخزين (مفردة).
///
/// يقيس المساحة فعلياً بمسح المجلدات (مع مهلة زمنية وحماية من الأخطاء)،
/// وينظّف الصور المؤقتة والملفات القديمة، ويفرض حدّ التنزيلات بحذف
/// الأقدم اكتمالاً أولاً. كل العمليات آمنة: أي خطأ في ملف يُتخطّى.
class StorageManager extends ChangeNotifier {
  StorageManager._();
  static final StorageManager i = StorageManager._();

  /// نسخة اختبار بذاكرة مستقلة.
  factory StorageManager.testInstance() => StorageManager._();

  static const String _limitsKey = 'sard_storage_limits_v1';
  static const String _usageKey = 'sard_storage_usage_v1';

  static const Duration kMeasureTimeout = Duration(seconds: 20);

  StorageLimits _limits = const StorageLimits();
  StorageUsage? _lastUsage;
  bool _measuring = false;
  bool _ready = false;

  StorageLimits get limits => _limits;
  StorageUsage? get lastUsage => _lastUsage;
  bool get isMeasuring => _measuring;

  Future<void> load() async {
    if (_ready) return;
    final p = await SharedPreferences.getInstance();
    try {
      final raw = p.getString(_limitsKey);
      if (raw != null && raw.isNotEmpty) {
        _limits = StorageLimits.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      }
    } catch (_) {}
    try {
      final raw = p.getString(_usageKey);
      if (raw != null && raw.isNotEmpty) {
        _lastUsage = StorageUsage.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      }
    } catch (_) {}
    _ready = true;
    notifyListeners();
  }

  Future<void> setLimits(StorageLimits limits) async {
    _limits = limits;
    final p = await SharedPreferences.getInstance();
    await p.setString(_limitsKey, jsonEncode(limits.toJson()));
    notifyListeners();
  }

  Future<Directory> get _docsDir async => getApplicationDocumentsDirectory();
  Future<Directory> get _tempDir async => getTemporaryDirectory();

  /// مجلد ذاكرة صور الشبكة (flutter_cache_manager).
  Future<Directory> get _imageCacheDir async {
    final temp = await _tempDir;
    return Directory('${temp.path}/libCachedImageData');
  }

  Future<List<Directory>> get _downloadDirs async {
    final docs = await _docsDir;
    return <Directory>[
      Directory('${docs.path}/sard_downloads_v2'),
      Directory('${docs.path}/sard_downloads'),
    ];
  }

  /// يقيس الاستخدام الفعلي بمسح المجلدات (آمن ومهلته 20 ثانية).
  Future<StorageUsage> measure() async {
    if (_measuring) return _lastUsage ?? StorageUsage.empty;
    _measuring = true;
    notifyListeners();
    try {
      StorageUsage usage;
      try {
        usage = await _measureInner().timeout(kMeasureTimeout, onTimeout: () {
          return _lastUsage ?? StorageUsage.empty;
        });
      } catch (_) {
        // بيئة بلا قنوات منصة (مثل اختبارات الوحدة): أعد آخر قياس أو صفراً.
        usage = _lastUsage ?? StorageUsage.empty;
      }
      _lastUsage = usage;
      final p = await SharedPreferences.getInstance();
      await p.setString(_usageKey, jsonEncode(usage.toJson()));
      return usage;
    } finally {
      _measuring = false;
      notifyListeners();
    }
  }

  Future<StorageUsage> _measureInner() async {
    var downloadsBytes = 0;
    var downloadsCount = 0;
    for (final dir in await _downloadDirs) {
      final s = await _dirSize(dir);
      downloadsBytes += s.bytes;
      downloadsCount += s.files;
    }
    final cache = await _dirSize(await _imageCacheDir);
    final temp = await _dirSize(await _tempDir, skipNames: <String>{'libCachedImageData'});
    return StorageUsage(
      downloadsBytes: downloadsBytes,
      imageCacheBytes: cache.bytes,
      tempBytes: temp.bytes,
      otherBytes: 0,
      downloadsCount: downloadsCount,
      cacheFilesCount: cache.files,
      measuredAt: DateTime.now(),
    );
  }

  /// حجم مجلد + عدد ملفاته (يتخطّى المجلدات المستثناة والأخطاء).
  Future<({int bytes, int files})> _dirSize(Directory dir, {Set<String> skipNames = const <String>{}}) async {
    var bytes = 0;
    var files = 0;
    try {
      if (!await dir.exists()) return (bytes: 0, files: 0);
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        try {
          if (entity is File) {
            final name = entity.path.split(Platform.pathSeparator).last;
            if (skipNames.contains(name)) continue;
            bytes += await entity.length();
            files++;
          }
        } catch (_) {}
      }
    } catch (_) {}
    return (bytes: bytes, files: files);
  }

  /// أكبر الملفات في مجلدات التطبيق (للتشخيص وعرض «ما الذي يستهلك المساحة؟»).
  Future<List<StorageEntry>> largestFiles({int limit = 20}) async {
    final out = <StorageEntry>[];
    final roots = <Directory>[...await _downloadDirs, await _imageCacheDir];
    for (final root in roots) {
      final kind = root.path.contains('libCachedImageData') ? StorageKind.imageCache : StorageKind.downloads;
      try {
        if (!await root.exists()) continue;
        await for (final entity in root.list(recursive: true, followLinks: false)) {
          try {
            if (entity is File) {
              final stat = await entity.stat();
              out.add(StorageEntry(
                path: entity.path,
                bytes: stat.size,
                modified: stat.modified,
                kind: kind,
              ));
            }
          } catch (_) {}
        }
      } catch (_) {}
    }
    out.sort((a, b) => b.bytes.compareTo(a.bytes));
    return out.take(limit.clamp(1, 100).toInt()).toList();
  }

  /// يمسح ذاكرة صور الشبكة بالكامل (قابلة لإعادة التحميل).
  Future<CleanupResult> clearImageCache() async {
    final before = await _safeDirSize(await _safeImageCacheDir());
    var removed = 0;
    try {
      await DefaultCacheManager().emptyCache();
    } catch (_) {}
    // تأكيد بالمسح اليدوي لأي بقايا.
    try {
      final dir = await _safeImageCacheDir();
      if (dir != null && await dir.exists()) {
        await for (final entity in dir.list(followLinks: false)) {
          try {
            await entity.delete(recursive: true);
            removed++;
          } catch (_) {}
        }
      }
    } catch (_) {}
    final after = await _safeDirSize(await _safeImageCacheDir());
    final freed = math.max(0, before.bytes - after.bytes);
    _lastUsage = await measure();
    return CleanupResult(
      freedBytes: freed,
      removedFiles: math.max(removed, before.files - after.files),
      removedKinds: const <StorageKind>[StorageKind.imageCache],
    );
  }

  /// مجلد ذاكرة الصور مع حماية من غياب قنوات المنصة (null في الاختبارات).
  Future<Directory?> _safeImageCacheDir() async {
    try {
      return await _imageCacheDir;
    } catch (_) {
      return null;
    }
  }

  Future<({int bytes, int files})> _safeDirSize(Directory? dir) async {
    if (dir == null) return (bytes: 0, files: 0);
    return _dirSize(dir);
  }

  /// يمسح الملفات المؤقتة العامة (ما عدا ذاكرة الصور).
  Future<CleanupResult> clearTempFiles() async {
    Directory? temp;
    try {
      temp = await _tempDir;
    } catch (_) {
      temp = null;
    }
    var freed = 0;
    var removed = 0;
    if (temp == null) {
      return const CleanupResult(freedBytes: 0, removedFiles: 0, removedKinds: <StorageKind>[]);
    }
    try {
      if (await temp.exists()) {
        await for (final entity in temp.list(followLinks: false)) {
          try {
            if (entity.path.endsWith('libCachedImageData')) continue;
            if (entity is File) {
              freed += await entity.length();
              await entity.delete();
              removed++;
            } else if (entity is Directory) {
              final s = await _dirSize(entity);
              freed += s.bytes;
              removed += s.files;
              await entity.delete(recursive: true);
            }
          } catch (_) {}
        }
      }
    } catch (_) {}
    _lastUsage = await measure();
    return CleanupResult(
      freedBytes: freed,
      removedFiles: removed,
      removedKinds: const <StorageKind>[StorageKind.tempFiles],
    );
  }

  /// يحذف التنزيلات المكتملة الأقدم من [days] يوماً.
  /// يعيد عدد الملفات المحذوفة والبايتات المحرّرة.
  Future<CleanupResult> clearOldDownloads({required int days}) async {
    if (days <= 0) {
      return const CleanupResult(freedBytes: 0, removedFiles: 0, removedKinds: <StorageKind>[]);
    }
    final cutoff = DateTime.now().subtract(Duration(days: days));
    var freed = 0;
    var removed = 0;
    for (final dir in await _downloadDirs) {
      try {
        if (!await dir.exists()) continue;
        await for (final entity in dir.list(followLinks: false)) {
          try {
            if (entity is! File) continue;
            final stat = await entity.stat();
            if (stat.modified.isBefore(cutoff)) {
              freed += stat.size;
              await entity.delete();
              removed++;
            }
          } catch (_) {}
        }
      } catch (_) {}
    }
    _lastUsage = await measure();
    return CleanupResult(
      freedBytes: freed,
      removedFiles: removed,
      removedKinds: const <StorageKind>[StorageKind.downloads],
    );
  }

  /// يفرض حدّ التنزيلات: إن تجاوز الاستخدام الحدّ، يحذف الأقدم اكتمالاً أولاً.
  /// يعيد نتيجة التنظيف (صفر إن لم يكن هناك تجاوز).
  Future<CleanupResult> enforceDownloadLimit() async {
    final limit = _limits.downloadLimitBytes;
    if (limit <= 0) {
      return const CleanupResult(freedBytes: 0, removedFiles: 0, removedKinds: <StorageKind>[]);
    }
    final usage = await measure();
    if (usage.downloadsBytes <= limit) {
      return const CleanupResult(freedBytes: 0, removedFiles: 0, removedKinds: <StorageKind>[]);
    }
    final files = await largestFiles(limit: 200);
    final downloads = files
        .where((f) => f.kind == StorageKind.downloads)
        .toList()
      ..sort((a, b) => a.modified.compareTo(b.modified)); // الأقدم أولاً
    var need = usage.downloadsBytes - limit;
    var freed = 0;
    var removed = 0;
    for (final entry in downloads) {
      if (need <= 0) break;
      try {
        await File(entry.path).delete();
        freed += entry.bytes;
        need -= entry.bytes;
        removed++;
      } catch (_) {}
    }
    _lastUsage = await measure();
    return CleanupResult(
      freedBytes: freed,
      removedFiles: removed,
      removedKinds: const <StorageKind>[StorageKind.downloads],
    );
  }

  /// تنظيف شامل بضغطة واحدة: صور مؤقتة + ملفات مؤقتة (+ تنزيلات قديمة إن طُلب).
  Future<CleanupResult> cleanAll({bool includeOldDownloads = false, int oldDays = 30}) async {
    var freed = 0;
    var removed = 0;
    final kinds = <StorageKind>[];
    final cache = await clearImageCache();
    freed += cache.freedBytes;
    removed += cache.removedFiles;
    kinds.addAll(cache.removedKinds);
    final temp = await clearTempFiles();
    freed += temp.freedBytes;
    removed += temp.removedFiles;
    kinds.addAll(temp.removedKinds);
    if (includeOldDownloads) {
      final old = await clearOldDownloads(days: oldDays);
      freed += old.freedBytes;
      removed += old.removedFiles;
      kinds.addAll(old.removedKinds);
    }
    return CleanupResult(freedBytes: freed, removedFiles: removed, removedKinds: kinds);
  }

  /// هل يحتاج التخزين إلى تنظيف تلقائي الآن؟ (ذاكرة الصور فوق حدّها)
  Future<bool> get needsAutoClean async {
    final usage = _lastUsage ?? await measure();
    return _limits.autoCleanCache && usage.imageCacheBytes > _limits.cacheLimitBytes;
  }

  /// مسح الحالة بالكامل (للاختبارات فقط).
  Future<void> resetForTest() async {
    _limits = const StorageLimits();
    _lastUsage = null;
    _ready = false;
    final p = await SharedPreferences.getInstance();
    await p.remove(_limitsKey);
    await p.remove(_usageKey);
    notifyListeners();
  }
}

/// يحوّل بايتات إلى وصف عربي مختصر للاستخدام في البطاقات.
String storageUsageLabel(int bytes, int limitBytes) {
  if (limitBytes <= 0) return formatBytesAr(bytes);
  return '${formatBytesAr(bytes)} من ${formatBytesAr(limitBytes)}';
}

/// لقطة اتجاه استخدام التخزين عبر الزمن (أسبوعياً).
@immutable
class StorageTrendPoint {
  const StorageTrendPoint({required this.at, required this.totalBytes});

  final DateTime at;
  final int totalBytes;

  Map<String, dynamic> toJson() => {
        'at': at.millisecondsSinceEpoch,
        'totalBytes': totalBytes,
      };

  factory StorageTrendPoint.fromJson(Map<String, dynamic> j) {
    return StorageTrendPoint(
      at: j['at'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['at'] as num).toInt())
          : DateTime.now(),
      totalBytes: (j['totalBytes'] as num?)?.toInt() ?? 0,
    );
  }
}

/// نوع توصية التخزين.
enum StorageActionKind {
  cleanCache('مسح الصور المؤقتة'),
  cleanTemp('مسح الملفات المؤقتة'),
  deleteOldDownloads('حذف التنزيلات القديمة'),
  raiseLimit('رفع حدّ التنزيلات'),
  nothing('لا إجراء');

  const StorageActionKind(this.label);
  final String label;
}

/// توصية تخزين واحدة قواعديّة (تُبنى من القياس والحدود).
@immutable
class StorageRecommendation {
  const StorageRecommendation({
    required this.title,
    required this.body,
    required this.action,
    required this.estimatedFreedBytes,
  });

  final String title;
  final String body;
  final StorageActionKind action;
  final int estimatedFreedBytes;

  String get freedLabel => formatBytesAr(estimatedFreedBytes);
}

/// يبني توصيات من لقطة استخدام وحدود (قواعد ثابتة وواضحة).
List<StorageRecommendation> buildStorageRecommendations(StorageUsage usage, StorageLimits limits) {
  final out = <StorageRecommendation>[];
  if (usage.imageCacheBytes > limits.cacheLimitBytes && usage.imageCacheBytes > 0) {
    out.add(StorageRecommendation(
      title: 'ذاكرة الصور تجاوزت حدّها',
      body: 'الصور المؤقتة ${usage.imageCacheLabel} والحدّ ${formatBytesAr(limits.cacheLimitBytes)} — مسحها آمن وتُعاد عند الحاجة.',
      action: StorageActionKind.cleanCache,
      estimatedFreedBytes: usage.imageCacheBytes,
    ));
  }
  if (usage.tempBytes > 100 * 1024 * 1024) {
    out.add(StorageRecommendation(
      title: 'ملفات مؤقتة متراكمة',
      body: 'يوجد ${usage.tempLabel} من الملفات المؤقتة يمكن تحريرها فوراً.',
      action: StorageActionKind.cleanTemp,
      estimatedFreedBytes: usage.tempBytes,
    ));
  }
  if (limits.downloadLimitBytes > 0 && usage.downloadsBytes > limits.downloadLimitBytes) {
    final over = usage.downloadsBytes - limits.downloadLimitBytes;
    out.add(StorageRecommendation(
      title: 'التنزيلات فوق الحدّ',
      body: 'تجاوزت التنزيلات الحدّ بـ ${formatBytesAr(over)} — احذف الأقدم أو ارفع الحدّ.',
      action: StorageActionKind.deleteOldDownloads,
      estimatedFreedBytes: over,
    ));
  }
  if (out.isEmpty) {
    out.add(const StorageRecommendation(
      title: 'التخزين بحالة جيدة',
      body: 'لا حاجة لأي إجراء حالياً.',
      action: StorageActionKind.nothing,
      estimatedFreedBytes: 0,
    ));
  }
  return out;
}

/// تقرير تخزين كامل: لقطة + أكبر الملفات + توصيات.
@immutable
class StorageReport {
  const StorageReport({
    required this.usage,
    required this.largest,
    required this.recommendations,
    required this.limits,
  });

  final StorageUsage usage;
  final List<StorageEntry> largest;
  final List<StorageRecommendation> recommendations;
  final StorageLimits limits;

  StorageTier get tier => usage.tierFor(limits.downloadLimitBytes);
  int get totalReclaimable => recommendations.fold<int>(0, (a, r) => a + r.estimatedFreedBytes);
  String get totalReclaimableLabel => formatBytesAr(totalReclaimable);
}

/// امتدادات على مدير التخزين: الاتجاه والتقارير.
extension StorageManagerReports on StorageManager {
  static const String _trendKey = 'sard_storage_trend_v1';
  static const int kMaxTrendPoints = 8;

  /// يسجّل نقطة اتجاه أسبوعية (تُستدعى بعد كل قياس).
  Future<List<StorageTrendPoint>> recordTrendPoint(StorageUsage usage) async {
    final p = await SharedPreferences.getInstance();
    final points = <StorageTrendPoint>[];
    try {
      final raw = p.getString(_trendKey);
      if (raw != null && raw.isNotEmpty) {
        final list = (jsonDecode(raw) as List).cast<Map>();
        for (final e in list) {
          try {
            points.add(StorageTrendPoint.fromJson(Map<String, dynamic>.from(e)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    final now = DateTime.now();
    if (points.isEmpty || now.difference(points.last.at).inDays >= 7) {
      points.add(StorageTrendPoint(at: now, totalBytes: usage.totalBytes));
    } else {
      points[points.length - 1] = StorageTrendPoint(at: now, totalBytes: usage.totalBytes);
    }
    while (points.length > kMaxTrendPoints) {
      points.removeAt(0);
    }
    await p.setString(_trendKey, jsonEncode(points.map((e) => e.toJson()).toList()));
    return points;
  }

  /// يقرأ نقاط الاتجاه المحفوظة.
  Future<List<StorageTrendPoint>> trendPoints() async {
    final p = await SharedPreferences.getInstance();
    final points = <StorageTrendPoint>[];
    try {
      final raw = p.getString(_trendKey);
      if (raw != null && raw.isNotEmpty) {
        final list = (jsonDecode(raw) as List).cast<Map>();
        for (final e in list) {
          try {
            points.add(StorageTrendPoint.fromJson(Map<String, dynamic>.from(e)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    return points;
  }

  /// يبني تقريراً كاملاً (قياس + أكبر الملفات + توصيات).
  Future<StorageReport> buildReport() async {
    final usage = await measure();
    final largest = await largestFiles(limit: 10);
    final recommendations = buildStorageRecommendations(usage, limits);
    return StorageReport(
      usage: usage,
      largest: largest,
      recommendations: recommendations,
      limits: limits,
    );
  }

  /// متوسط النمو الأسبوعي بالبايت (من نقاط الاتجاه؛ 0 إن تعذّر).
  Future<int> weeklyGrowthBytes() async {
    final points = await trendPoints();
    if (points.length < 2) return 0;
    final first = points.first;
    final last = points.last;
    final weeks = last.at.difference(first.at).inDays / 7;
    if (weeks <= 0) return 0;
    return ((last.totalBytes - first.totalBytes) / weeks).round();
  }
}
