// ──────────────────────────────────────────────────────────────────────────
//  خط الصور — ذاكرة مؤقتة ذكية + تحميل تدريجي + توفير بيانات
//  ──────────────────────────────────────────────────────────────────────────
//  • ذاكرة مؤقتة فوق DefaultCacheManager (يأتي مع cached_network_image):
//    حدّ للعمر والعدد، مسح انتقائي، وقياس حجم فعلي.
//  • تحميل تدريجي: صورة منخفضة الجودة أولاً ثم الكاملة مع تلاشٍ ناعم.
//  • جودة تلقائية حسب وضع البيانات والشبكة (توفير البيانات يختار المنخفضة).
//  • بدائل أنيقة عند الفشل: لون مشتق من العمل + حرفه الأول (لا شاشة مكسورة).
// ──────────────────────────────────────────────────────────────────────────
import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:path_provider/path_provider.dart';

import '../data/models.dart';
import '../storage/settings.dart';
import '../theme/app_themes.dart';
import '../../widgets/sard_icons.dart';
import 'download_engine_v2.dart' show V2NetworkCondition;

/// جودة الصورة المطلوبة.
enum ImageQuality {
  low('منخفضة', 480, 'توفير بيانات — تحميل سريع'),
  medium('متوسطة', 900, 'توازن بين الجودة والحجم'),
  high('عالية', 1400, 'جودة كاملة للشاشات الكبيرة'),
  original('الأصلية', 0, 'بلا ضغط — للقراءة الدقيقة');

  const ImageQuality(this.label, this.maxWidth, this.hint);
  final String label;

  /// أقصى عرض بالبكسل (0 = بلا حدّ)
  final int maxWidth;
  final String hint;

  static ImageQuality fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => ImageQuality.medium,
      );
}

/// يختار الجودة تلقائياً حسب وضع البيانات وحالة الشبكة.
/// القاعدة: توفير البيانات أو بيانات الجوال -> منخفضة؛ واي فاي -> عالية؛
/// وضع HD الصريح -> الأصلية على الواي فاي والعالية على الجوال.
ImageQuality qualityFor(DataMode mode, V2NetworkCondition condition) {
  switch (mode) {
    case DataMode.mobile:
      return ImageQuality.low;
    case DataMode.hd:
      return condition == V2NetworkCondition.wifi ? ImageQuality.original : ImageQuality.high;
    case DataMode.always:
      return condition == V2NetworkCondition.wifi ? ImageQuality.high : ImageQuality.medium;
  }
}

/// يحلّ رابط الصفحة حسب الجودة: المنخفضة تستخدم [PageSrc.low] إن وُجد.
String resolvePageUrl(PageSrc src, ImageQuality quality) {
  if (quality == ImageQuality.low && src.low != null && src.low!.isNotEmpty) {
    return src.low!;
  }
  return src.url;
}

/// إحصاءات خط الصور (داخل الجلسة): إصابات الذاكرة مقابل التحميلات.
class ImagePipelineStats {
  int hits = 0;
  int misses = 0;
  int prefetched = 0;
  int failed = 0;

  int get total => hits + misses;
  double get hitRate => total == 0 ? 0 : hits / total;
  String get hitRateLabel => total == 0 ? '—' : '${(hitRate * 100).round()}٪';

  void reset() {
    hits = 0;
    misses = 0;
    prefetched = 0;
    failed = 0;
  }

  Map<String, dynamic> toJson() => {
        'hits': hits,
        'misses': misses,
        'prefetched': prefetched,
        'failed': failed,
      };
}

/// غلاف ذاكرة الصور فوق DefaultCacheManager.
class SenokImageCache {
  SenokImageCache._();
  static final SenokImageCache i = SenokImageCache._();

  /// نسخة اختبار.
  factory SenokImageCache.testInstance() => SenokImageCache._();

  static const Duration kDefaultMaxAge = Duration(days: 30);
  static const int kDefaultMaxObjects = 500;

  final ImagePipelineStats stats = ImagePipelineStats();

  BaseCacheManager get manager => DefaultCacheManager();

  /// يجلب ملف صورة (من الذاكرة إن وُجد وإلا من الشبكة) ويحدّث الإحصاءات.
  Future<File?> getFile(String url, {bool forceRefresh = false}) async {
    if (url.isEmpty) return null;
    try {
      if (!forceRefresh) {
        final cached = await manager.getFileFromCache(url);
        if (cached != null && await cached.file.exists()) {
          stats.hits++;
          return cached.file;
        }
      }
      stats.misses++;
      return await manager.getSingleFile(url);
    } catch (_) {
      stats.failed++;
      return null;
    }
  }

  /// يحمّل صوراً مسبقاً في الخلفية (للفصل التالي مثلاً) دون حظر الواجهة.
  Future<int> prefetch(List<String> urls, {int maxConcurrent = 3}) async {
    var done = 0;
    final queue = urls.where((u) => u.isNotEmpty).toList();
    for (var i = 0; i < queue.length; i += maxConcurrent) {
      final batch = queue.skip(i).take(maxConcurrent);
      final results = await Future.wait(batch.map((u) => getFile(u)));
      for (final f in results) {
        if (f != null) done++;
      }
      stats.prefetched += done;
    }
    return done;
  }

  /// يحمّل صفحات فصل كامل مسبقاً حسب الجودة.
  Future<int> prefetchChapter(List<PageSrc> pages, {ImageQuality quality = ImageQuality.medium}) async {
    final urls = pages.map((p) => resolvePageUrl(p, quality)).toList();
    return prefetch(urls);
  }

  /// يزيل صورة واحدة من الذاكرة.
  Future<void> evict(String url) async {
    if (url.isEmpty) return;
    try {
      await manager.removeFile(url);
    } catch (_) {}
  }

  /// يمسح ذاكرة الصور بالكامل.
  Future<void> clearAll() async {
    try {
      await manager.emptyCache();
    } catch (_) {}
  }

  /// حجم ذاكرة الصور الفعلي بالبايت (بمسح مجلدها).
  Future<int> cacheSizeBytes() async {
    try {
      final temp = await getTemporaryDirectory();
      final dir = Directory('${temp.path}/libCachedImageData');
      if (!await dir.exists()) return 0;
      var bytes = 0;
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        try {
          if (entity is File) bytes += await entity.length();
        } catch (_) {}
      }
      return bytes;
    } catch (_) {
      return 0;
    }
  }

  /// عدد ملفات الذاكرة.
  Future<int> cacheFileCount() async {
    try {
      final temp = await getTemporaryDirectory();
      final dir = Directory('${temp.path}/libCachedImageData');
      if (!await dir.exists()) return 0;
      var n = 0;
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is File) n++;
      }
      return n;
    } catch (_) {
      return 0;
    }
  }
}

/// لون مشتق ثابت من معرّف العمل (لخلفية البديل عند غياب الغلاف).
Color coverToneColor(String seriesId, {bool dark = false}) {
  final seed = seriesId.codeUnits.fold<int>(7, (a, b) => a * 31 + b);
  const tones = <Color>[
    Color(0xFF7A4A2B),
    Color(0xFF2B5A7A),
    Color(0xFF4A6B2F),
    Color(0xFF6B2F4A),
    Color(0xFF2F4A6B),
    Color(0xFF8A6D1B),
    Color(0xFF3D3D6B),
    Color(0xFF6B3D2F),
  ];
  final base = tones[seed % tones.length];
  return dark ? Color.lerp(base, Colors.black, 0.25)! : base;
}

/// غلاف عمل مع تحميل تدريجي وبديل أنيق.
///
/// يعرض: لوناً مشتقاً + حرف العمل أثناء التحميل، والصورة عند وصولها،
/// وبديلاً (الحرف + أيقونة) عند الفشل. لا يكسر التخطيط أبداً.
class SenokCoverImage extends StatelessWidget {
  const SenokCoverImage({
    super.key,
    required this.series,
    this.width,
    this.height,
    this.radius = 12,
    this.fit = BoxFit.cover,
    this.quality = ImageQuality.medium,
    this.showTitle = false,
  });

  final Series series;
  final double? width;
  final double? height;
  final double radius;
  final BoxFit fit;
  final ImageQuality quality;
  final bool showTitle;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final url = series.cover;
    final tone = coverToneColor(series.id, dark: p.isDark);
    final initial = series.title.trim().isEmpty ? '؟' : series.title.trim().characters.first;
    final placeholder = Container(
      color: tone,
      alignment: Alignment.center,
      child: Text(
        initial,
        style: context.ds(size: 34, w: FontWeight.w800, color: Colors.white),
      ),
    );
    Widget image;
    if (url == null || url.isEmpty) {
      image = placeholder;
    } else {
      image = CachedNetworkImage(
        imageUrl: url,
        fit: fit,
        memCacheWidth: quality.maxWidth == 0 ? null : quality.maxWidth,
        fadeInDuration: const Duration(milliseconds: 220),
        fadeOutDuration: const Duration(milliseconds: 120),
        placeholder: (context, _) => placeholder,
        errorWidget: (context, u, e) => Container(
          color: tone,
          alignment: Alignment.center,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(initial, style: context.ds(size: 30, w: FontWeight.w800, color: Colors.white)),
              const SizedBox(height: 4),
              SIcon(SardIcons.cloud_off_rounded, size: 16, color: Colors.white.withAlpha(200)),
            ],
          ),
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: SizedBox(
        width: width,
        height: height,
        child: Stack(
          fit: StackFit.expand,
          children: [
            image,
            if (showTitle)
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(8, 14, 8, 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: <Color>[Colors.transparent, Colors.black.withAlpha(190)],
                    ),
                  ),
                  child: Text(
                    series.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: context.ts(size: 12, w: FontWeight.w700, color: Colors.white),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// صورة صفحة قراءة بتحميل تدريجي: منخفضة الجودة أولاً ثم الكاملة.
///
/// تُستعمل داخل القارئ: تعرض [src.low] فوراً (إن وُجد) ثم تستبدله
/// بالكاملة مع تلاشٍ، فلا يرى القارئ فراغاً أبيض أثناء التحميل.
class ProgressivePageImage extends StatefulWidget {
  const ProgressivePageImage({
    super.key,
    required this.src,
    this.quality = ImageQuality.high,
    this.fit = BoxFit.fitWidth,
    this.background,
  });

  final PageSrc src;
  final ImageQuality quality;
  final BoxFit fit;
  final Color? background;

  @override
  State<ProgressivePageImage> createState() => _ProgressivePageImageState();
}

class _ProgressivePageImageState extends State<ProgressivePageImage> {
  bool _highReady = false;

  @override
  void didUpdateWidget(covariant ProgressivePageImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.src.url != widget.src.url) _highReady = false;
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final highUrl = resolvePageUrl(widget.src, widget.quality);
    final lowUrl = widget.src.low;
    final bg = widget.background ?? p.surfaceHi;
    Widget low;
    if (lowUrl != null && lowUrl.isNotEmpty && lowUrl != highUrl) {
      low = CachedNetworkImage(
        imageUrl: lowUrl,
        fit: widget.fit,
        fadeInDuration: const Duration(milliseconds: 120),
        placeholder: (context, _) => Container(color: bg),
        errorWidget: (context, u, e) => Container(color: bg),
      );
    } else {
      low = Container(color: bg);
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        low,
        CachedNetworkImage(
          imageUrl: highUrl,
          fit: widget.fit,
          memCacheWidth: widget.quality.maxWidth == 0 ? null : widget.quality.maxWidth,
          fadeInDuration: const Duration(milliseconds: 280),
          placeholder: (context, _) => const SizedBox.shrink(),
          errorWidget: (context, u, e) => _PageErrorPlaceholder(background: bg),
          imageBuilder: (context, provider) {
            if (!_highReady) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) setState(() => _highReady = true);
              });
            }
            return Image(image: provider, fit: widget.fit);
          },
        ),
      ],
    );
  }
}

class _PageErrorPlaceholder extends StatelessWidget {
  const _PageErrorPlaceholder({this.background});
  final Color? background;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      color: background ?? p.surfaceHi,
      alignment: Alignment.center,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SIcon(SardIcons.cloud_off_rounded, size: 32, color: p.textDim),
          const SizedBox(height: 8),
          Text('تعذّر تحميل الصفحة', style: context.ts(size: 13, color: p.textDim)),
          const SizedBox(height: 4),
          Text('تحقق من الاتصال ثم أعد المحاولة', style: context.ts(size: 11.5, color: p.textDim)),
        ],
      ),
    );
  }
}

/// صورة رمزية دائرية لمستخدم (بديل: أول حرف من الاسم).
class SenokAvatarImage extends StatelessWidget {
  const SenokAvatarImage({
    super.key,
    required this.name,
    this.imageUrl,
    this.size = 40,
  });

  final String name;
  final String? imageUrl;
  final double size;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final initial = name.trim().isEmpty ? '؟' : name.trim().characters.first;
    final tone = coverToneColor(name, dark: p.isDark);
    final fallback = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: tone, shape: BoxShape.circle),
      child: Text(initial, style: context.ds(size: size * 0.42, w: FontWeight.w800, color: Colors.white)),
    );
    if (imageUrl == null || imageUrl!.isEmpty) return fallback;
    return ClipOval(
      child: CachedNetworkImage(
        imageUrl: imageUrl!,
        width: size,
        height: size,
        fit: BoxFit.cover,
        fadeInDuration: const Duration(milliseconds: 200),
        placeholder: (context, _) => fallback,
        errorWidget: (context, u, e) => fallback,
      ),
    );
  }
}

/// شريط حالة مصغّر لخط الصور (يُستعمل في الإعدادات الاحترافية).
class ImagePipelineStatusTile extends StatelessWidget {
  const ImagePipelineStatusTile({super.key, required this.stats, this.onClear});

  final ImagePipelineStats stats;
  final VoidCallback? onClear;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(p.r(0.8)),
        border: Border.all(color: p.border, width: p.borderW),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(color: tint(p.accent, 0.12), shape: BoxShape.circle),
            child: SIcon(SardIcons.hd_rounded, size: 20, color: p.accent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('خط الصور', style: context.ts(size: 14, w: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  'إصابات الذاكرة ${stats.hitRateLabel} · حُمّل مسبقاً ${stats.prefetched} · فشل ${stats.failed}',
                  style: context.ts(size: 12, color: p.textDim),
                ),
              ],
            ),
          ),
          if (onClear != null)
            TextButton(onPressed: onClear, child: const Text('مسح الذاكرة')),
        ],
      ),
    );
  }
}

/// إعدادات جودة الصور الدائمة (تُحفظ وتُقرأ من التفضيلات).
@immutable
class ImageQualitySettings {
  const ImageQualitySettings({
    this.wifiQuality = ImageQuality.high,
    this.mobileQuality = ImageQuality.low,
    this.autoQuality = true,
    this.prefetchNextChapter = true,
  });

  final ImageQuality wifiQuality;
  final ImageQuality mobileQuality;
  final bool autoQuality;
  final bool prefetchNextChapter;

  ImageQuality qualityForCondition(V2NetworkCondition condition) {
    if (!autoQuality) return wifiQuality;
    return condition == V2NetworkCondition.wifi ? wifiQuality : mobileQuality;
  }

  ImageQualitySettings copyWith({
    ImageQuality? wifiQuality,
    ImageQuality? mobileQuality,
    bool? autoQuality,
    bool? prefetchNextChapter,
  }) {
    return ImageQualitySettings(
      wifiQuality: wifiQuality ?? this.wifiQuality,
      mobileQuality: mobileQuality ?? this.mobileQuality,
      autoQuality: autoQuality ?? this.autoQuality,
      prefetchNextChapter: prefetchNextChapter ?? this.prefetchNextChapter,
    );
  }

  Map<String, dynamic> toJson() => {
        'wifiQuality': wifiQuality.name,
        'mobileQuality': mobileQuality.name,
        'autoQuality': autoQuality,
        'prefetchNextChapter': prefetchNextChapter,
      };

  factory ImageQualitySettings.fromJson(Map<String, dynamic> j) {
    return ImageQualitySettings(
      wifiQuality: ImageQuality.fromName(j['wifiQuality'] as String?),
      mobileQuality: ImageQuality.fromName(j['mobileQuality'] as String?),
      autoQuality: j['autoQuality'] as bool? ?? true,
      prefetchNextChapter: j['prefetchNextChapter'] as bool? ?? true,
    );
  }
}

/// محمّل مسبق للفصول مع تقدّم (للقارئ: «حمّل الفصل التالي أثناء القراءة»).
class SenokImagePrefetcher extends ChangeNotifier {
  SenokImagePrefetcher._();
  static final SenokImagePrefetcher i = SenokImagePrefetcher._();

  bool _running = false;
  int _done = 0;
  int _total = 0;
  String _label = '';

  bool get isRunning => _running;
  int get done => _done;
  int get total => _total;
  double get progress => _total == 0 ? 0 : _done / _total;
  String get label => _label;

  /// يحمّل صفحات فصل مسبقاً مع تحديث التقدّم. يعيد عدد الصفحات الجاهزة.
  Future<int> prefetchChapter(
    List<PageSrc> pages, {
    ImageQuality quality = ImageQuality.medium,
    String label = '',
  }) async {
    if (_running || pages.isEmpty) return 0;
    _running = true;
    _done = 0;
    _total = pages.length;
    _label = label;
    notifyListeners();
    var ready = 0;
    try {
      for (final page in pages) {
        final url = resolvePageUrl(page, quality);
        final file = await SenokImageCache.i.getFile(url);
        if (file != null) ready++;
        _done++;
        notifyListeners();
      }
    } finally {
      _running = false;
      notifyListeners();
    }
    return ready;
  }

  /// يحمّل أغلفة قائمة أعمال مسبقاً (للصفحة الرئيسية).
  Future<int> prefetchCovers(List<Series> series, {ImageQuality quality = ImageQuality.low}) async {
    final urls = series
        .map((s) => s.cover)
        .whereType<String>()
        .where((u) => u.isNotEmpty)
        .toList();
    return SenokImageCache.i.prefetch(urls);
  }

  void reset() {
    _running = false;
    _done = 0;
    _total = 0;
    _label = '';
    notifyListeners();
  }
}

/// منتقي جودة الصور (قطاع اختيار صغير للإعدادات).
class ImageQualityPicker extends StatelessWidget {
  const ImageQualityPicker({
    super.key,
    required this.selected,
    required this.onChanged,
    this.label = 'جودة الصور',
  });

  final ImageQuality selected;
  final ValueChanged<ImageQuality> onChanged;
  final String label;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: context.ts(size: 13.5, w: FontWeight.w600)),
        const SizedBox(height: 6),
        SegmentedButton<ImageQuality>(
          segments: ImageQuality.values
              .map((q) => ButtonSegment<ImageQuality>(value: q, label: Text(q.label)))
              .toList(),
          selected: <ImageQuality>{selected},
          onSelectionChanged: (set) {
            if (set.isNotEmpty) onChanged(set.first);
          },
        ),
        const SizedBox(height: 4),
        Text(selected.hint, style: context.ts(size: 12, color: p.textDim)),
      ],
    );
  }
}

/// شريط تقدّم التحميل المسبق (يُعرض أسفل القارئ أثناء تحميل الفصل التالي).
class PrefetchProgressBar extends StatelessWidget {
  const PrefetchProgressBar({super.key, required this.prefetcher});

  final SenokImagePrefetcher prefetcher;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (!prefetcher.isRunning && prefetcher.done == 0) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: p.surface,
        border: Border(top: BorderSide(color: p.border)),
      ),
      child: Row(
        children: [
          SIcon(SardIcons.download_rounded, size: 16, color: p.accent),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  prefetcher.isRunning
                      ? 'يُحمَّل الفصل التالي مسبقاً… ${prefetcher.done}/${prefetcher.total}'
                      : 'اكتمل التحميل المسبق (${prefetcher.done} صفحة)',
                  style: context.ts(size: 12, w: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: prefetcher.progress,
                    minHeight: 5,
                    backgroundColor: p.border,
                    valueColor: AlwaysStoppedAnimation<Color>(p.accent),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// صورة شبكة عامة بجودة قابلة للضبط وزر إعادة محاولة عند الفشل.
///
/// تُستعمل لأي صورة داخل التطبيق ليست غلاف عمل ولا صفحة فصل
/// (صور المنشورات، الإعلانات، صور الملف الشخصي الكبيرة).
class SenokNetworkImage extends StatefulWidget {
  const SenokNetworkImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.radius = 12,
    this.quality = ImageQuality.medium,
    this.showRetry = true,
  });

  final String url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final double radius;
  final ImageQuality quality;
  final bool showRetry;

  @override
  State<SenokNetworkImage> createState() => _SenokNetworkImageState();
}

class _SenokNetworkImageState extends State<SenokNetworkImage> {
  var _attempt = 0;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ClipRRect(
      borderRadius: BorderRadius.circular(widget.radius),
      child: SizedBox(
        width: widget.width,
        height: widget.height,
        child: CachedNetworkImage(
          key: ValueKey<String>('${widget.url}#$_attempt'),
          imageUrl: widget.url,
          fit: widget.fit,
          memCacheWidth: widget.quality.maxWidth == 0 ? null : widget.quality.maxWidth,
          fadeInDuration: const Duration(milliseconds: 220),
          placeholder: (context, _) => Container(
            color: p.surfaceHi,
            alignment: Alignment.center,
            child: SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2.5, color: p.accent),
            ),
          ),
          errorWidget: (context, u, e) => Container(
            color: p.surfaceHi,
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SIcon(SardIcons.cloud_off_rounded, size: 26, color: p.textDim),
                const SizedBox(height: 6),
                Text('تعذّر تحميل الصورة', style: context.ts(size: 12, color: p.textDim)),
                if (widget.showRetry) ...[
                  const SizedBox(height: 8),
                  InkWell(
                    onTap: () => setState(() => _attempt++),
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: tint(p.accent, 0.14),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text('إعادة المحاولة', style: context.ts(size: 12, w: FontWeight.w700, color: p.accent)),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// بديل غلاف بسيط (حرف + لون) يُستعمل في القوائم الكثيفة دون تحميل صورة.
class CoverPlaceholder extends StatelessWidget {
  const CoverPlaceholder({
    super.key,
    required this.series,
    this.radius = 12,
    this.fontSize = 30,
  });

  final Series series;
  final double radius;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final tone = coverToneColor(series.id, dark: p.isDark);
    final initial = series.title.trim().isEmpty ? '؟' : series.title.trim().characters.first;
    return Container(
      decoration: BoxDecoration(
        color: tone,
        borderRadius: BorderRadius.circular(radius),
      ),
      alignment: Alignment.center,
      child: Text(
        initial,
        style: context.ds(size: fontSize, w: FontWeight.w800, color: Colors.white),
      ),
    );
  }
}

/// شارة جودة صغيرة فوق صورة (مثلاً «HD» أو «توفير»).
class QualityBadge extends StatelessWidget {
  const QualityBadge({super.key, required this.quality});
  final ImageQuality quality;

  @override
  Widget build(BuildContext context) {
    final label = switch (quality) {
      ImageQuality.low => 'توفير',
      ImageQuality.medium => 'متوسطة',
      ImageQuality.high => 'HD',
      ImageQuality.original => 'أصلية',
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(160),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(label, style: context.ts(size: 10, w: FontWeight.w700, color: Colors.white)),
    );
  }
}
