// ──────────────────────────────────────────────────────────────────────────
//  محرك المزامنة — تقدّم القراءة عبر الأجهزة
//  ──────────────────────────────────────────────────────────────────────────
//  قواعده (قواعدية بالكامل، بلا خادم حقيقي ولا ذكاء اصطناعي):
//    • كل سجل تقدّم يحمل طابعاً زمنياً ومعرّف جهاز.
//    • الدمج التلقائي: الفصل الأبعد يفوز، وإن تساوى الفصل فالصفحة الأبعد،
//      وثواني القراءة تُؤخذ بالأعلى (لا تُجمع لتفادي التضخيم).
//    • التعارض: يحدث فقط حين يتغيّر التقدّم محلياً وعلى الخادم معاً بعد
//      آخر مزامنة ناجحة وتختلف قيمتاهما؛ عندها يبقى السجل «معلّقاً» حتى
//      يختار المستخدم: المحلي / الخادم / الدمج.
//    • الخادم هنا واجهة قابلة للحقن ([SyncTransport]) حتى يعمل المحرك
//      دون اتصال حقيقي؛ التطبيق يمرّر دالة دفع/سحب فعلية عند توفرها.
// ──────────────────────────────────────────────────────────────────────────
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// كيف يُحلّ التعارض حين يختار المستخدم.
enum SyncResolution {
  keepLocal('الاحتفاظ بنسختي'),
  keepServer('الاحتفاظ بنسخة الخادم'),
  merge('دمج (الأبعد يفوز)'),
  pending('معلّق — بانتظار قرارك');

  const SyncResolution(this.label);
  final String label;

  static SyncResolution fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => SyncResolution.pending,
      );
}

/// حقل التقدّم الذي وقع فيه التعارض.
enum SyncField {
  chapter('الفصل'),
  page('الصفحة'),
  seconds('وقت القراءة');

  const SyncField(this.label);
  final String label;

  static SyncField fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => SyncField.chapter,
      );
}

/// سجل تقدّم واحد لعمل واحد (وحدة المزامنة).
@immutable
class SyncRecord {
  const SyncRecord({
    required this.seriesId,
    required this.chapter,
    required this.page,
    required this.total,
    required this.seconds,
    required this.updatedAt,
    this.deviceId = 'this_device',
  });

  final String seriesId;
  final int chapter;
  final int page;
  final int total;
  final int seconds;
  final DateTime updatedAt;
  final String deviceId;

  double get fraction => total <= 1 ? 0 : ((page - 1) / (total - 1)).clamp(0.0, 1.0);

  /// «الفصل 12 — صفحة 34 من 120»
  String get describe => 'الفصل $chapter — صفحة $page من $total';

  bool get isEmpty => chapter <= 0 && page <= 0;

  /// هل هذا السجل أحدث من [other]؟
  bool isNewerThan(SyncRecord other) => updatedAt.isAfter(other.updatedAt);

  /// دمج قواعدي: الأبعد يفوز في الفصل والصفحة، والأعلى في الثواني.
  SyncRecord mergeWith(SyncRecord other) {
    final takeOtherChapter =
        other.chapter > chapter || (other.chapter == chapter && other.page > page);
    final mergedChapter = math.max(chapter, other.chapter);
    final mergedPage = mergedChapter == chapter && mergedChapter == other.chapter
        ? math.max(page, other.page)
        : (mergedChapter == other.chapter ? other.page : page);
    final mergedTotal = math.max(total, other.total);
    return SyncRecord(
      seriesId: seriesId,
      chapter: mergedChapter,
      page: takeOtherChapter ? mergedPage : page,
      total: mergedTotal,
      seconds: math.max(seconds, other.seconds),
      updatedAt: updatedAt.isAfter(other.updatedAt) ? updatedAt : other.updatedAt,
      deviceId: updatedAt.isAfter(other.updatedAt) ? deviceId : other.deviceId,
    );
  }

  /// هل يختلف موضع القراءة عن [other] (بغضّ النظر عن الطابع الزمني)؟
  bool differsFrom(SyncRecord other) =>
      chapter != other.chapter || page != other.page || total != other.total;

  SyncRecord copyWith({
    int? chapter,
    int? page,
    int? total,
    int? seconds,
    DateTime? updatedAt,
    String? deviceId,
  }) {
    return SyncRecord(
      seriesId: seriesId,
      chapter: chapter ?? this.chapter,
      page: page ?? this.page,
      total: total ?? this.total,
      seconds: seconds ?? this.seconds,
      updatedAt: updatedAt ?? this.updatedAt,
      deviceId: deviceId ?? this.deviceId,
    );
  }

  Map<String, dynamic> toJson() => {
        'seriesId': seriesId,
        'chapter': chapter,
        'page': page,
        'total': total,
        'seconds': seconds,
        'updatedAt': updatedAt.millisecondsSinceEpoch,
        'deviceId': deviceId,
      };

  factory SyncRecord.fromJson(Map<String, dynamic> j) {
    return SyncRecord(
      seriesId: '${j['seriesId']}',
      chapter: (j['chapter'] as num?)?.toInt() ?? 0,
      page: (j['page'] as num?)?.toInt() ?? 0,
      total: (j['total'] as num?)?.toInt() ?? 1,
      seconds: (j['seconds'] as num?)?.toInt() ?? 0,
      updatedAt: j['updatedAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['updatedAt'] as num).toInt())
          : DateTime.now(),
      deviceId: '${j['deviceId'] ?? 'unknown'}',
    );
  }
}

/// تعارض واحد بانتظار قرار المستخدم.
@immutable
class SyncConflict {
  const SyncConflict({
    required this.id,
    required this.seriesId,
    required this.seriesTitle,
    required this.field,
    required this.local,
    required this.server,
    required this.detectedAt,
    this.resolution = SyncResolution.pending,
    this.resolvedAt,
  });

  final String id;
  final String seriesId;
  final String seriesTitle;
  final SyncField field;
  final SyncRecord local;
  final SyncRecord server;
  final DateTime detectedAt;
  final SyncResolution resolution;
  final DateTime? resolvedAt;

  bool get isResolved => resolution != SyncResolution.pending;
  bool get isPending => resolution == SyncResolution.pending;

  /// وصف عربي قصير: «الفصل محلياً 12 وعلى الخادم 9»
  String get describe {
    String v(SyncRecord r) {
      switch (field) {
        case SyncField.chapter:
          return 'الفصل ${r.chapter}';
        case SyncField.page:
          return 'صفحة ${r.page} من ${r.total}';
        case SyncField.seconds:
          return '${r.seconds ~/ 60} دقيقة';
      }
    }

    return '«$seriesTitle»: ${field.label} محلياً ${v(local)} وعلى الخادم ${v(server)}';
  }

  /// السجل الناتج عن حلّ التعارض حسب [resolution].
  SyncRecord get resolvedRecord {
    switch (resolution) {
      case SyncResolution.keepLocal:
        return local;
      case SyncResolution.keepServer:
        return server;
      case SyncResolution.merge:
        return local.mergeWith(server);
      case SyncResolution.pending:
        return local;
    }
  }

  SyncConflict copyWith({SyncResolution? resolution, DateTime? resolvedAt}) {
    return SyncConflict(
      id: id,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      field: field,
      local: local,
      server: server,
      detectedAt: detectedAt,
      resolution: resolution ?? this.resolution,
      resolvedAt: resolvedAt ?? this.resolvedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'seriesId': seriesId,
        'seriesTitle': seriesTitle,
        'field': field.name,
        'local': local.toJson(),
        'server': server.toJson(),
        'detectedAt': detectedAt.millisecondsSinceEpoch,
        'resolution': resolution.name,
        'resolvedAt': resolvedAt?.millisecondsSinceEpoch,
      };

  factory SyncConflict.fromJson(Map<String, dynamic> j) {
    return SyncConflict(
      id: '${j['id']}',
      seriesId: '${j['seriesId']}',
      seriesTitle: '${j['seriesTitle'] ?? ''}',
      field: SyncField.fromName(j['field'] as String?),
      local: SyncRecord.fromJson(Map<String, dynamic>.from(j['local'] as Map)),
      server: SyncRecord.fromJson(Map<String, dynamic>.from(j['server'] as Map)),
      detectedAt: j['detectedAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['detectedAt'] as num).toInt())
          : DateTime.now(),
      resolution: SyncResolution.fromName(j['resolution'] as String?),
      resolvedAt: j['resolvedAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['resolvedAt'] as num).toInt())
          : null,
    );
  }
}

/// نتيجة مزامنة واحدة (تُعرض للمستخدم وتُحفظ في السجل).
@immutable
class SyncReport {
  const SyncReport({
    required this.at,
    required this.uploaded,
    required this.downloaded,
    required this.merged,
    required this.conflicts,
    required this.duration,
    this.error = '',
  });

  final DateTime at;
  final int uploaded;
  final int downloaded;
  final int merged;
  final int conflicts;
  final Duration duration;
  final String error;

  bool get success => error.isEmpty;
  int get totalChanged => uploaded + downloaded + merged;

  String get summary {
    if (!success) return 'تعذّرت المزامنة: $error';
    if (totalChanged == 0 && conflicts == 0) return 'كل شيء محدَّث — لا تغييرات جديدة';
    final parts = <String>[];
    if (uploaded > 0) parts.add('رُفع $uploaded');
    if (downloaded > 0) parts.add('نُزّل $downloaded');
    if (merged > 0) parts.add('دُمج $merged');
    if (conflicts > 0) parts.add('$conflicts تعارض بانتظارك');
    return parts.join(' · ');
  }

  Map<String, dynamic> toJson() => {
        'at': at.millisecondsSinceEpoch,
        'uploaded': uploaded,
        'downloaded': downloaded,
        'merged': merged,
        'conflicts': conflicts,
        'durationMs': duration.inMilliseconds,
        'error': error,
      };

  factory SyncReport.fromJson(Map<String, dynamic> j) {
    return SyncReport(
      at: j['at'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['at'] as num).toInt())
          : DateTime.now(),
      uploaded: (j['uploaded'] as num?)?.toInt() ?? 0,
      downloaded: (j['downloaded'] as num?)?.toInt() ?? 0,
      merged: (j['merged'] as num?)?.toInt() ?? 0,
      conflicts: (j['conflicts'] as num?)?.toInt() ?? 0,
      duration: Duration(milliseconds: (j['durationMs'] as num?)?.toInt() ?? 0),
      error: '${j['error'] ?? ''}',
    );
  }
}

/// واجهة النقل إلى الخادم — يمرّرها التطبيق عند توفر نقطة نهاية فعلية.
/// إن لم تُمرَّر، يعمل المحرك محلياً فقط ويعيد تقرير «لا خادم».
typedef SyncTransport = Future<List<Map<String, dynamic>>> Function(
  List<Map<String, dynamic>> upload,
);

/// يكشف تعارضاً بين سجلين نسبةً إلى آخر مزامنة ناجحة.
/// يعود null إن لم يكن هناك تعارض (أحدهما لم يتغيّر، أو القيم متطابقة).
SyncConflict? detectSyncConflict({
  required SyncRecord local,
  required SyncRecord server,
  required String seriesTitle,
  required DateTime lastSyncAt,
}) {
  if (!local.differsFrom(server)) return null;
  final localChanged = local.updatedAt.isAfter(lastSyncAt);
  final serverChanged = server.updatedAt.isAfter(lastSyncAt);
  if (!localChanged || !serverChanged) return null;
  final field = local.chapter != server.chapter
      ? SyncField.chapter
      : (local.page != server.page ? SyncField.page : SyncField.seconds);
  return SyncConflict(
    id: '${local.seriesId}_${local.updatedAt.millisecondsSinceEpoch}',
    seriesId: local.seriesId,
    seriesTitle: seriesTitle,
    field: field,
    local: local,
    server: server,
    detectedAt: DateTime.now(),
  );
}

/// يدمج قائمتين من السجلات قواعدياً (الأحدث/الأبعد يفوز)، ويعيد الخريطة المدمجة.
Map<String, SyncRecord> mergeRecordMaps(
  Map<String, SyncRecord> local,
  Map<String, SyncRecord> remote,
) {
  final out = Map<String, SyncRecord>.from(local);
  for (final entry in remote.entries) {
    final existing = out[entry.key];
    out[entry.key] = existing == null ? entry.value : existing.mergeWith(entry.value);
  }
  return out;
}

/// محرك المزامنة (مفردة).
///
/// يحفظ السجلات المحلية وطوابير الرفع والتعارضات في SharedPreferences.
/// الاستعمال:
/// ```dart
/// await SyncEngine.i.load();
/// SyncEngine.i.recordLocalProgress(seriesId: s.id, chapter: 3, page: 40, total: 120, seconds: 900);
/// final report = await SyncEngine.i.syncNow(transport: myTransport);
/// ```
class SyncEngine extends ChangeNotifier {
  SyncEngine._();
  static final SyncEngine i = SyncEngine._();

  /// نسخة اختبار بذاكرة مستقلة.
  factory SyncEngine.testInstance() => SyncEngine._();

  static const String _recordsKey = 'sard_sync_records_v1';
  static const String _queueKey = 'sard_sync_queue_v1';
  static const String _conflictsKey = 'sard_sync_conflicts_v1';
  static const String _historyKey = 'sard_sync_history_v1';
  static const String _lastSyncKey = 'sard_sync_last_v1';
  static const int kMaxHistory = 20;

  final Map<String, SyncRecord> _records = <String, SyncRecord>{};
  final Map<String, SyncRecord> _uploadQueue = <String, SyncRecord>{};
  final List<SyncConflict> _conflicts = <SyncConflict>[];
  final List<SyncReport> _history = <SyncReport>[];
  DateTime _lastSyncAt = DateTime.fromMillisecondsSinceEpoch(0);
  bool _ready = false;
  bool _syncing = false;
  String _deviceId = 'this_device';

  bool get isReady => _ready;
  bool get isSyncing => _syncing;
  DateTime get lastSyncAt => _lastSyncAt;
  bool get hasPendingConflicts => _conflicts.any((c) => c.isPending);
  int get pendingConflictCount => _conflicts.where((c) => c.isPending).length;
  int get pendingUploadCount => _uploadQueue.length;

  Map<String, SyncRecord> get records => Map<String, SyncRecord>.unmodifiable(_records);
  List<SyncConflict> get conflicts => List<SyncConflict>.unmodifiable(_conflicts);
  List<SyncConflict> get pendingConflicts =>
      _conflicts.where((c) => c.isPending).toList();
  List<SyncReport> get history => List<SyncReport>.unmodifiable(_history);
  SyncReport? get lastReport => _history.isEmpty ? null : _history.first;
  List<SyncRecord> get pendingUploads => _uploadQueue.values.toList();

  SyncRecord? recordOf(String seriesId) => _records[seriesId];

  /// معرّف هذا الجهاز (يُضبط مرة من التطبيق؛ افتراضياً «this_device»).
  void setDeviceId(String id) {
    if (id.trim().isEmpty) return;
    _deviceId = id.trim();
  }

  Future<void> load() async {
    if (_ready) return;
    final p = await SharedPreferences.getInstance();
    _records.addAll(_decodeRecords(p.getString(_recordsKey)));
    _uploadQueue.addAll(_decodeRecords(p.getString(_queueKey)));
    try {
      final raw = p.getString(_conflictsKey);
      if (raw != null && raw.isNotEmpty) {
        final list = (jsonDecode(raw) as List).cast<Map>();
        for (final e in list) {
          try {
            _conflicts.add(SyncConflict.fromJson(Map<String, dynamic>.from(e)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    try {
      final raw = p.getString(_historyKey);
      if (raw != null && raw.isNotEmpty) {
        final list = (jsonDecode(raw) as List).cast<Map>();
        for (final e in list) {
          try {
            _history.add(SyncReport.fromJson(Map<String, dynamic>.from(e)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    final last = p.getInt(_lastSyncKey);
    if (last != null) _lastSyncAt = DateTime.fromMillisecondsSinceEpoch(last);
    _ready = true;
    notifyListeners();
  }

  static Map<String, SyncRecord> _decodeRecords(String? raw) {
    final out = <String, SyncRecord>{};
    if (raw == null || raw.isEmpty) return out;
    try {
      final map = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      for (final e in map.entries) {
        if (e.value is Map) {
          out[e.key] = SyncRecord.fromJson(Map<String, dynamic>.from(e.value as Map));
        }
      }
    } catch (_) {}
    return out;
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_recordsKey, jsonEncode(_records.map((k, v) => MapEntry(k, v.toJson()))));
    await p.setString(_queueKey, jsonEncode(_uploadQueue.map((k, v) => MapEntry(k, v.toJson()))));
    await p.setString(_conflictsKey, jsonEncode(_conflicts.map((e) => e.toJson()).toList()));
    await p.setString(_historyKey, jsonEncode(_history.map((e) => e.toJson()).toList()));
    await p.setInt(_lastSyncKey, _lastSyncAt.millisecondsSinceEpoch);
  }

  // ───────── التسجيل المحلي ─────────

  /// يسجّل تقدّم قراءة محلياً ويضعه في طابور الرفع.
  /// إن كان التقدّم الجديد أقدم من المحفوظ يُتجاهل (لا رجوع للخلف).
  Future<SyncRecord> recordLocalProgress({
    required String seriesId,
    required int chapter,
    required int page,
    required int total,
    required int seconds,
    DateTime? at,
  }) async {
    await load();
    final record = SyncRecord(
      seriesId: seriesId,
      chapter: chapter,
      page: page,
      total: total,
      seconds: seconds,
      updatedAt: at ?? DateTime.now(),
      deviceId: _deviceId,
    );
    final existing = _records[seriesId];
    if (existing != null) {
      final merged = existing.mergeWith(record);
      // لا جديد فعلياً: تجاهل.
      if (!merged.differsFrom(existing) && merged.seconds == existing.seconds) {
        return existing;
      }
      _records[seriesId] = merged;
      _uploadQueue[seriesId] = merged;
    } else {
      _records[seriesId] = record;
      _uploadQueue[seriesId] = record;
    }
    await _persist();
    notifyListeners();
    return _records[seriesId]!;
  }

  /// يطبّق سجلات واردة من الخادم: يدمج ما أمكن، ويفتح تعارضات لما اختلف.
  /// يعيد قائمة التعارضات الجديدة (إن وجدت).
  Future<List<SyncConflict>> applyServerRecords(
    List<SyncRecord> incoming, {
    Map<String, String> titlesById = const <String, String>{},
  }) async {
    await load();
    final created = <SyncConflict>[];
    for (final server in incoming) {
      final local = _records[server.seriesId];
      if (local == null) {
        _records[server.seriesId] = server;
        continue;
      }
      if (!local.differsFrom(server)) {
        // نفس الموضع: حدّث الطابع الزمني والثواني فقط.
        if (server.updatedAt.isAfter(local.updatedAt)) {
          _records[server.seriesId] = local.copyWith(
            seconds: math.max(local.seconds, server.seconds),
            updatedAt: server.updatedAt,
          );
        }
        continue;
      }
      final conflict = detectSyncConflict(
        local: local,
        server: server,
        seriesTitle: titlesById[server.seriesId] ?? server.seriesId,
        lastSyncAt: _lastSyncAt,
      );
      if (conflict == null) {
        // لم يتغيّر الطرفان معاً: دمج قواعدي (الأبعد يفوز) — لا رجوع للخلف أبداً.
        final merged = local.mergeWith(server);
        _records[server.seriesId] = merged;
        _uploadQueue[server.seriesId] = merged;
      } else {
        final dup = _conflicts.any((c) =>
            c.seriesId == conflict.seriesId && c.isPending && c.field == conflict.field);
        if (!dup) {
          _conflicts.add(conflict);
          created.add(conflict);
        }
      }
    }
    await _persist();
    notifyListeners();
    return created;
  }

  /// يحلّ تعارضاً معلّقاً بقرار المستخدم ويطبّق النتيجة فوراً.
  Future<SyncRecord?> resolveConflict(String id, SyncResolution resolution) async {
    await load();
    final index = _conflicts.indexWhere((c) => c.id == id);
    if (index < 0) return null;
    final conflict = _conflicts[index];
    if (conflict.isResolved) return conflict.resolvedRecord;
    final solved = conflict.copyWith(resolution: resolution, resolvedAt: DateTime.now());
    _conflicts[index] = solved;
    final record = solved.resolvedRecord;
    _records[conflict.seriesId] = record;
    _uploadQueue[conflict.seriesId] = record;
    await _persist();
    notifyListeners();
    return record;
  }

  /// يحلّ كل التعارضات المعلّقة بالدمج التلقائي (الأبعد يفوز).
  Future<int> resolveAllByMerge() async {
    var n = 0;
    for (final c in pendingConflicts) {
      await resolveConflict(c.id, SyncResolution.merge);
      n++;
    }
    return n;
  }

  /// مزامنة كاملة: رفع الطابور ثم تطبيق ما يرده الخادم.
  /// إن لم تُمرَّر [transport] يعيد تقرير «لا خادم» دون تغيير.
  Future<SyncReport> syncNow({SyncTransport? transport}) async {
    await load();
    if (_syncing) {
      return SyncReport(
        at: DateTime.now(),
        uploaded: 0,
        downloaded: 0,
        merged: 0,
        conflicts: pendingConflictCount,
        duration: Duration.zero,
        error: 'مزامنة جارية بالفعل',
      );
    }
    _syncing = true;
    notifyListeners();
    final stopwatch = Stopwatch()..start();
    try {
      if (transport == null) {
        final report = SyncReport(
          at: DateTime.now(),
          uploaded: 0,
          downloaded: 0,
          merged: 0,
          conflicts: pendingConflictCount,
          duration: stopwatch.elapsed,
          error: 'لا توجد نقطة مزامنة مهيأة — يعمل التطبيق محلياً فقط',
        );
        _pushHistory(report);
        return report;
      }
      final toUpload = _uploadQueue.values.map((e) => e.toJson()).toList();
      final returned = await transport(toUpload).timeout(const Duration(seconds: 45));
      final incoming = <SyncRecord>[];
      for (final raw in returned) {
        try {
          incoming.add(SyncRecord.fromJson(Map<String, dynamic>.from(raw)));
        } catch (_) {}
      }
      final uploaded = toUpload.length;
      _uploadQueue.clear();
      final before = _records.length;
      final created = await applyServerRecords(incoming);
      final merged = _records.length - before;
      _lastSyncAt = DateTime.now();
      final report = SyncReport(
        at: DateTime.now(),
        uploaded: uploaded,
        downloaded: incoming.length,
        merged: merged,
        conflicts: created.length,
        duration: stopwatch.elapsed,
      );
      _pushHistory(report);
      await _persist();
      return report;
    } catch (e) {
      final report = SyncReport(
        at: DateTime.now(),
        uploaded: 0,
        downloaded: 0,
        merged: 0,
        conflicts: pendingConflictCount,
        duration: stopwatch.elapsed,
        error: _friendlyError(e),
      );
      _pushHistory(report);
      return report;
    } finally {
      stopwatch.stop();
      _syncing = false;
      notifyListeners();
    }
  }

  void _pushHistory(SyncReport report) {
    _history.insert(0, report);
    if (_history.length > kMaxHistory) {
      _history.removeRange(kMaxHistory, _history.length);
    }
    unawaited(_persist());
    notifyListeners();
  }

  static String _friendlyError(Object e) {
    final s = e.toString();
    if (s.contains('SocketException') || s.contains('Failed host lookup')) {
      return 'لا يوجد اتصال بالإنترنت';
    }
    if (s.contains('TimeoutException') || s.contains('timed out')) {
      return 'استغرق الاتصال وقتاً طويلاً';
    }
    return 'تعذّرت المزامنة';
  }

  /// تصدير كل السجلات كخريطة (للنسخ الاحتياطي).
  Map<String, dynamic> exportAll() =>
      _records.map((k, v) => MapEntry(k, v.toJson()));

  /// استيراد سجلات (للاستعادة): تُدمج قواعدياً مع الموجود.
  Future<void> importAll(Map<String, dynamic> data) async {
    await load();
    for (final e in data.entries) {
      if (e.value is! Map) continue;
      try {
        final incoming = SyncRecord.fromJson(Map<String, dynamic>.from(e.value as Map));
        final existing = _records[e.key];
        _records[e.key] = existing == null ? incoming : existing.mergeWith(incoming);
      } catch (_) {}
    }
    await _persist();
    notifyListeners();
  }

  /// مسح الحالة بالكامل (للاختبارات فقط).
  Future<void> resetForTest() async {
    _records.clear();
    _uploadQueue.clear();
    _conflicts.clear();
    _history.clear();
    _lastSyncAt = DateTime.fromMillisecondsSinceEpoch(0);
    _ready = false;
    final p = await SharedPreferences.getInstance();
    await p.remove(_recordsKey);
    await p.remove(_queueKey);
    await p.remove(_conflictsKey);
    await p.remove(_historyKey);
    await p.remove(_lastSyncKey);
    notifyListeners();
  }
}

/// جهاز مشارك في المزامنة (يُسجَّل عند أول مزامنة ناجحة).
@immutable
class SyncDevice {
  const SyncDevice({
    required this.id,
    required this.name,
    required this.lastSeen,
    this.isCurrent = false,
  });

  final String id;
  final String name;
  final DateTime lastSeen;
  final bool isCurrent;

  String get lastSeenLabel {
    final diff = DateTime.now().difference(lastSeen);
    if (diff.inMinutes < 1) return 'الآن';
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} د';
    if (diff.inHours < 24) return 'منذ ${diff.inHours} س';
    return 'منذ ${diff.inDays} يوم';
  }

  SyncDevice copyWith({String? name, DateTime? lastSeen, bool? isCurrent}) {
    return SyncDevice(
      id: id,
      name: name ?? this.name,
      lastSeen: lastSeen ?? this.lastSeen,
      isCurrent: isCurrent ?? this.isCurrent,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'lastSeen': lastSeen.millisecondsSinceEpoch,
        'isCurrent': isCurrent,
      };

  factory SyncDevice.fromJson(Map<String, dynamic> j) {
    return SyncDevice(
      id: '${j['id']}',
      name: '${j['name'] ?? 'جهاز'}',
      lastSeen: j['lastSeen'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['lastSeen'] as num).toInt())
          : DateTime.now(),
      isCurrent: j['isCurrent'] == true,
    );
  }
}

/// قاعدة حلّ تلقائي للتعارضات (يضبطها المستخدم من الإعدادات).
enum SyncAutoResolveRule {
  ask('اسألني دائماً', 'كل تعارض ينتظر قرارك'),
  newestWins('الأحدث يفوز', 'الطابع الزمني الأحدث يقرر'),
  mergeAlways('دمج دائماً', 'الفصل والصفحة الأبعد يفوزان'),
  localWins('نسختي دائماً', 'المحلي يفوز دون سؤال'),
  serverWins('الخادم دائماً', 'نسخة الخادم تفوز دون سؤال');

  const SyncAutoResolveRule(this.label, this.hint);
  final String label;
  final String hint;

  static SyncAutoResolveRule fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => SyncAutoResolveRule.ask,
      );
}

/// صحة المزامنة في لمحة (للعرض في الإعدادات).
@immutable
class SyncHealth {
  const SyncHealth({
    required this.lastSyncAt,
    required this.pendingUploads,
    required this.pendingConflicts,
    required this.totalRecords,
    required this.autoRule,
  });

  final DateTime lastSyncAt;
  final int pendingUploads;
  final int pendingConflicts;
  final int totalRecords;
  final SyncAutoResolveRule autoRule;

  bool get neverSynced => lastSyncAt.millisecondsSinceEpoch == 0;
  bool get isHealthy => pendingConflicts == 0 && pendingUploads == 0;
  bool get needsAttention => pendingConflicts > 0;

  String get statusLabel {
    if (neverSynced) return 'لم تتم مزامنة بعد';
    if (pendingConflicts > 0) return '$pendingConflicts تعارض بانتظارك';
    if (pendingUploads > 0) return '$pendingUploads سجل بانتظار الرفع';
    return 'مزامَنة ومحدَّثة';
  }
}

/// تشخيص المزامنة كخريطة (للتصدير أو لشاشة التشخيص).
Map<String, dynamic> syncDiagnostics({
  required DateTime lastSyncAt,
  required int records,
  required int pendingUploads,
  required int pendingConflicts,
  required SyncAutoResolveRule rule,
  SyncReport? lastReport,
}) {
  return <String, dynamic>{
    'lastSyncAt': lastSyncAt.millisecondsSinceEpoch,
    'records': records,
    'pendingUploads': pendingUploads,
    'pendingConflicts': pendingConflicts,
    'autoRule': rule.name,
    'lastReport': lastReport?.toJson(),
    'generatedAt': DateTime.now().millisecondsSinceEpoch,
  };
}

/// يطبّق قاعدة حلّ تلقائي على تعارض واحد ويعيد السجل الناتج.
SyncRecord applyAutoResolveRule(SyncConflict conflict, SyncAutoResolveRule rule) {
  switch (rule) {
    case SyncAutoResolveRule.newestWins:
      return conflict.local.isNewerThan(conflict.server) ? conflict.local : conflict.server;
    case SyncAutoResolveRule.mergeAlways:
      return conflict.local.mergeWith(conflict.server);
    case SyncAutoResolveRule.localWins:
      return conflict.local;
    case SyncAutoResolveRule.serverWins:
      return conflict.server;
    case SyncAutoResolveRule.ask:
      return conflict.local;
  }
}

/// يحوّل قاعدة تلقائية إلى قرار [SyncResolution] قابل للحفظ.
SyncResolution resolutionForRule(SyncAutoResolveRule rule) {
  switch (rule) {
    case SyncAutoResolveRule.newestWins:
    case SyncAutoResolveRule.ask:
      return SyncResolution.pending;
    case SyncAutoResolveRule.mergeAlways:
      return SyncResolution.merge;
    case SyncAutoResolveRule.localWins:
      return SyncResolution.keepLocal;
    case SyncAutoResolveRule.serverWins:
      return SyncResolution.keepServer;
  }
}

/// امتدادات على محرك المزامنة: الأجهزة والقواعد والصحة.
extension SyncEngineDevices on SyncEngine {
  /// صحة المزامنة الحالية في لمحة.
  SyncHealth health({SyncAutoResolveRule rule = SyncAutoResolveRule.ask}) {
    return SyncHealth(
      lastSyncAt: lastSyncAt,
      pendingUploads: pendingUploadCount,
      pendingConflicts: pendingConflictCount,
      totalRecords: records.length,
      autoRule: rule,
    );
  }

  /// يحلّ كل التعارضات المعلّقة حسب قاعدة تلقائية (ما عدا «اسألني»).
  Future<int> resolveAllByRule(SyncAutoResolveRule rule) async {
    if (rule == SyncAutoResolveRule.ask) return 0;
    var n = 0;
    for (final conflict in pendingConflicts) {
      if (rule == SyncAutoResolveRule.newestWins) {
        final winner = conflict.local.isNewerThan(conflict.server)
            ? SyncResolution.keepLocal
            : SyncResolution.keepServer;
        await resolveConflict(conflict.id, winner);
      } else {
        await resolveConflict(conflict.id, resolutionForRule(rule));
      }
      n++;
    }
    return n;
  }
}

/// ملخص التعارضات المعلّقة (للعرض في شاشة المزامنة).
@immutable
class SyncConflictSummary {
  const SyncConflictSummary({
    required this.total,
    required this.byField,
    required this.oldest,
    required this.newest,
  });

  final int total;
  final Map<SyncField, int> byField;
  final DateTime? oldest;
  final DateTime? newest;

  factory SyncConflictSummary.fromConflicts(List<SyncConflict> conflicts) {
    final pending = conflicts.where((c) => c.isPending).toList();
    final byField = <SyncField, int>{};
    DateTime? oldest;
    DateTime? newest;
    for (final c in pending) {
      byField[c.field] = (byField[c.field] ?? 0) + 1;
      if (oldest == null || c.detectedAt.isBefore(oldest)) oldest = c.detectedAt;
      if (newest == null || c.detectedAt.isAfter(newest)) newest = c.detectedAt;
    }
    return SyncConflictSummary(
      total: pending.length,
      byField: byField,
      oldest: oldest,
      newest: newest,
    );
  }

  String get describe {
    if (total == 0) return 'لا تعارضات معلّقة';
    final parts = byField.entries.map((e) => '${e.value} في ${e.key.label}').join('، ');
    return '$total تعارض: $parts';
  }
}

/// تصدير سجلات المزامنة كنص (للتشخيص أو النسخ الاحتياطي اليدوي).
String exportSyncRecordsText(Map<String, SyncRecord> records) {
  final buffer = StringBuffer('سجلات مزامنة Senok — ${DateTime.now().year}/${DateTime.now().month}/${DateTime.now().day}\n');
  final sorted = records.values.toList()
    ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  for (final r in sorted) {
    buffer.writeln('${r.seriesId}: ${r.describe} — ${r.seconds ~/ 60} دقيقة');
  }
  return buffer.toString();
}

/// امتدادات تشخيصية على محرك المزامنة.
extension SyncEngineDiagnostics on SyncEngine {
  /// ملخص التعارضات المعلّقة.
  SyncConflictSummary get conflictSummary => SyncConflictSummary.fromConflicts(conflicts);

  /// نص تشخيصي مختصر للعرض.
  String get diagnosticsText {
    final h = health();
    final buffer = StringBuffer('المزامنة: ${h.statusLabel}\n');
    buffer.writeln('السجلات: ${records.length} · بانتظار الرفع: $pendingUploadCount');
    buffer.writeln(conflictSummary.describe);
    if (lastReport != null) buffer.writeln('آخر مزامنة: ${lastReport!.summary}');
    return buffer.toString();
  }
}
