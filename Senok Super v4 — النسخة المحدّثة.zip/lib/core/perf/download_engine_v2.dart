// ──────────────────────────────────────────────────────────────────────────
//  محرك التنزيل v2 — طابور تنزيل احترافي للفصول (أوفلاين)
//  ──────────────────────────────────────────────────────────────────────────
//  يحلّ محل مدير التنزيل البسيط (DownloadManager v1) دون حذفه: v2 يضيف
//    • طابوراً بأولويات (عاجل / عالٍ / عادي / منخفض) وحدّاً للتنزيلات المتزامنة
//    • استئنافاً حقيقياً من آخر صفحة مكتملة بعد الإيقاف أو انقطاع الشبكة
//    • سياسات شبكة (واي فاي فقط / واي فاي+بيانات / أي شبكة) وحدّاً يومياً للبيانات
//    • إعادة محاولة تلقائية بخطوات متباعدة، وإحصاءات (سرعة، حجم، عدد)
//    • حفظاً دائماً للطابور في SharedPreferences واسترجاعه بعد إعادة التشغيل
//  كل المنطق قواعدي ومحلّي بالكامل؛ لا ذكاء اصطناعي ولا خادم خارجي.
// ──────────────────────────────────────────────────────────────────────────
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/models.dart';

/// أولوية مهمة التنزيل في الطابور (الأعلى تُنفَّذ أولاً).
enum V2DownloadPriority {
  low('منخفضة', 0),
  normal('عادية', 1),
  high('عالية', 2),
  urgent('عاجلة', 3);

  const V2DownloadPriority(this.label, this.weight);
  final String label;
  final int weight;

  static V2DownloadPriority fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => V2DownloadPriority.normal,
      );
}

/// حالة مهمة تنزيل واحدة.
enum V2DownloadState {
  queued('في الانتظار'),
  downloading('يُحمَّل'),
  paused('متوقف مؤقتاً'),
  completed('مكتمل'),
  failed('فشل'),
  cancelled('ملغى');

  const V2DownloadState(this.label);
  final String label;

  bool get isActive => this == V2DownloadState.downloading;
  bool get isWaiting => this == V2DownloadState.queued;
  bool get isFinished =>
      this == V2DownloadState.completed || this == V2DownloadState.cancelled;
  bool get canResume =>
      this == V2DownloadState.paused || this == V2DownloadState.failed;

  static V2DownloadState fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => V2DownloadState.paused,
      );
}

/// سياسة الشبكة المسموحة للتنزيل.
enum V2NetworkPolicy {
  wifiOnly('واي فاي فقط', 'لا يُنزَّل على بيانات الجوال أبداً'),
  wifiOrMobile('واي فاي وبيانات', 'يُنزَّل على أي شبكة مع حدّ يومي للبيانات'),
  any('أي شبكة', 'يُنزَّل دون قيود (قد يستهلك بيانات الجوال)');

  const V2NetworkPolicy(this.label, this.hint);
  final String label;
  final String hint;

  static V2NetworkPolicy fromName(String? name) => values.firstWhere(
        (e) => e.name == name,
        orElse: () => V2NetworkPolicy.wifiOnly,
      );
}

/// حالة الشبكة الحالية كما يراها المحرك.
enum V2NetworkCondition {
  wifi('واي فاي'),
  mobile('بيانات الجوال'),
  offline('دون اتصال'),
  unknown('غير معروفة');

  const V2NetworkCondition(this.label);
  final String label;

  bool get isOnline => this == V2NetworkCondition.wifi || this == V2NetworkCondition.mobile;
}

/// خطأ تنزيل موصوف للمستخدم بالعربية.
class V2DownloadException implements Exception {
  const V2DownloadException(this.message, {this.code = 'download_failed'});
  final String message;
  final String code;

  @override
  String toString() => message;
}

/// مهمة تنزيل فصل واحد: كل صفحاته + موضع الاستئناف + إحصاءاته.
@immutable
class V2DownloadJob {
  const V2DownloadJob({
    required this.id,
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.pageUrls,
    this.cover,
    this.files = const <String>[],
    this.completedPages = 0,
    this.state = V2DownloadState.queued,
    this.priority = V2DownloadPriority.normal,
    this.bytesDownloaded = 0,
    this.totalBytes = 0,
    this.error = '',
    this.retries = 0,
    this.createdAt,
    this.startedAt,
    this.finishedAt,
  });

  final String id;
  final String seriesId;
  final String seriesTitle;
  final int chapter;
  final List<String> pageUrls;
  final String? cover;

  /// مسارات الملفات المحفوظة (بالترتيب، بطول [pageUrls] عند الاكتمال)
  final List<String> files;

  /// عدد الصفحات المكتملة — نقطة الاستئناف
  final int completedPages;
  final V2DownloadState state;
  final V2DownloadPriority priority;
  final int bytesDownloaded;
  final int totalBytes;
  final String error;
  final int retries;
  final DateTime? createdAt;
  final DateTime? startedAt;
  final DateTime? finishedAt;

  int get totalPages => pageUrls.length;
  int get remainingPages => (totalPages - completedPages).clamp(0, totalPages);
  double get progress => totalPages == 0 ? 0 : completedPages / totalPages;
  bool get isComplete => state == V2DownloadState.completed;
  bool get isActive => state.isActive;
  bool get canResume => state.canResume && remainingPages > 0;
  bool get canPause => state == V2DownloadState.downloading || state == V2DownloadState.queued;

  /// نسبة مئوية صحيحة 0..100
  int get percent => (progress * 100).round().clamp(0, 100);

  /// حجم الصفحات المتبقية تقديرياً (متوسط 350 ك.ب للصفحة عند جهل الحجم)
  int get estimatedRemainingBytes {
    if (totalBytes > 0 && completedPages > 0) {
      final avg = totalBytes ~/ completedPages;
      return avg * remainingPages;
    }
    return remainingPages * 350 * 1024;
  }

  /// مدة التنزيل حتى الآن
  Duration? get elapsed {
    final s = startedAt;
    if (s == null) return null;
    return (finishedAt ?? DateTime.now()).difference(s);
  }

  /// السرعة المتوسطة (بايت/ثانية) منذ البدء
  double get averageSpeed {
    final e = elapsed;
    if (e == null || e.inSeconds <= 0 || bytesDownloaded <= 0) return 0;
    return bytesDownloaded / e.inSeconds;
  }

  /// الوقت المتبقي تقديرياً بالثواني (null إن تعذّر التقدير)
  int? get estimatedSecondsLeft {
    final speed = averageSpeed;
    if (speed <= 0) return null;
    return (estimatedRemainingBytes / speed).ceil();
  }

  /// نص عربي للوقت المتبقي: «~3 د» أو «~40 ث»
  String get etaLabel {
    final s = estimatedSecondsLeft;
    if (s == null) return '—';
    if (s < 60) return '~$s ث';
    final m = s ~/ 60;
    if (m < 60) return '~$m د';
    return '~${m ~/ 60} س ${m % 60} د';
  }

  /// عنوان العرض: «اسم العمل — الفصل 12»
  String get displayTitle => '$seriesTitle — الفصل $chapter';

  V2DownloadJob copyWith({
    List<String>? files,
    int? completedPages,
    V2DownloadState? state,
    V2DownloadPriority? priority,
    int? bytesDownloaded,
    int? totalBytes,
    String? error,
    int? retries,
    DateTime? startedAt,
    DateTime? finishedAt,
  }) {
    return V2DownloadJob(
      id: id,
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      pageUrls: pageUrls,
      cover: cover,
      files: files ?? this.files,
      completedPages: completedPages ?? this.completedPages,
      state: state ?? this.state,
      priority: priority ?? this.priority,
      bytesDownloaded: bytesDownloaded ?? this.bytesDownloaded,
      totalBytes: totalBytes ?? this.totalBytes,
      error: error ?? this.error,
      retries: retries ?? this.retries,
      createdAt: createdAt,
      startedAt: startedAt ?? this.startedAt,
      finishedAt: finishedAt ?? this.finishedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'seriesId': seriesId,
        'seriesTitle': seriesTitle,
        'chapter': chapter,
        'pageUrls': pageUrls,
        'cover': cover,
        'files': files,
        'completedPages': completedPages,
        'state': state.name,
        'priority': priority.name,
        'bytesDownloaded': bytesDownloaded,
        'totalBytes': totalBytes,
        'error': error,
        'retries': retries,
        'createdAt': createdAt?.millisecondsSinceEpoch,
        'startedAt': startedAt?.millisecondsSinceEpoch,
        'finishedAt': finishedAt?.millisecondsSinceEpoch,
      };

  factory V2DownloadJob.fromJson(Map<String, dynamic> j) {
    DateTime? dt(dynamic v) =>
        v is num ? DateTime.fromMillisecondsSinceEpoch(v.toInt()) : null;
    return V2DownloadJob(
      id: '${j['id']}',
      seriesId: '${j['seriesId']}',
      seriesTitle: '${j['seriesTitle'] ?? ''}',
      chapter: (j['chapter'] as num?)?.toInt() ?? 0,
      pageUrls: ((j['pageUrls'] as List?) ?? const []).map((e) => '$e').toList(),
      cover: j['cover'] as String?,
      files: ((j['files'] as List?) ?? const []).map((e) => '$e').toList(),
      completedPages: (j['completedPages'] as num?)?.toInt() ?? 0,
      state: V2DownloadState.fromName(j['state'] as String?),
      priority: V2DownloadPriority.fromName(j['priority'] as String?),
      bytesDownloaded: (j['bytesDownloaded'] as num?)?.toInt() ?? 0,
      totalBytes: (j['totalBytes'] as num?)?.toInt() ?? 0,
      error: '${j['error'] ?? ''}',
      retries: (j['retries'] as num?)?.toInt() ?? 0,
      createdAt: dt(j['createdAt']),
      startedAt: dt(j['startedAt']),
      finishedAt: dt(j['finishedAt']),
    );
  }
}

/// إحصاءات مجمّعة لمحرك التنزيل (تُحفظ وتُعرض في الإعدادات الاحترافية).
@immutable
class V2DownloadStats {
  const V2DownloadStats({
    this.queued = 0,
    this.active = 0,
    this.completed = 0,
    this.failed = 0,
    this.bytesDownloaded = 0,
    this.bytesTotal = 0,
    this.todayBytes = 0,
    this.todayCount = 0,
    this.totalJobs = 0,
    this.lastCompletedAt,
  });

  final int queued;
  final int active;
  final int completed;
  final int failed;
  final int bytesDownloaded;
  final int bytesTotal;
  final int todayBytes;
  final int todayCount;
  final int totalJobs;
  final DateTime? lastCompletedAt;

  double get overallProgress => bytesTotal <= 0 ? 0 : (bytesDownloaded / bytesTotal).clamp(0.0, 1.0);
  int get overallPercent => (overallProgress * 100).round();
  bool get hasActive => active > 0 || queued > 0;

  V2DownloadStats copyWith({
    int? queued,
    int? active,
    int? completed,
    int? failed,
    int? bytesDownloaded,
    int? bytesTotal,
    int? todayBytes,
    int? todayCount,
    int? totalJobs,
    DateTime? lastCompletedAt,
  }) {
    return V2DownloadStats(
      queued: queued ?? this.queued,
      active: active ?? this.active,
      completed: completed ?? this.completed,
      failed: failed ?? this.failed,
      bytesDownloaded: bytesDownloaded ?? this.bytesDownloaded,
      bytesTotal: bytesTotal ?? this.bytesTotal,
      todayBytes: todayBytes ?? this.todayBytes,
      todayCount: todayCount ?? this.todayCount,
      totalJobs: totalJobs ?? this.totalJobs,
      lastCompletedAt: lastCompletedAt ?? this.lastCompletedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'queued': queued,
        'active': active,
        'completed': completed,
        'failed': failed,
        'bytesDownloaded': bytesDownloaded,
        'bytesTotal': bytesTotal,
        'todayBytes': todayBytes,
        'todayCount': todayCount,
        'totalJobs': totalJobs,
        'lastCompletedAt': lastCompletedAt?.millisecondsSinceEpoch,
      };

  factory V2DownloadStats.fromJson(Map<String, dynamic> j) {
    return V2DownloadStats(
      queued: (j['queued'] as num?)?.toInt() ?? 0,
      active: (j['active'] as num?)?.toInt() ?? 0,
      completed: (j['completed'] as num?)?.toInt() ?? 0,
      failed: (j['failed'] as num?)?.toInt() ?? 0,
      bytesDownloaded: (j['bytesDownloaded'] as num?)?.toInt() ?? 0,
      bytesTotal: (j['bytesTotal'] as num?)?.toInt() ?? 0,
      todayBytes: (j['todayBytes'] as num?)?.toInt() ?? 0,
      todayCount: (j['todayCount'] as num?)?.toInt() ?? 0,
      totalJobs: (j['totalJobs'] as num?)?.toInt() ?? 0,
      lastCompletedAt: j['lastCompletedAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['lastCompletedAt'] as num).toInt())
          : null,
    );
  }

  static V2DownloadStats fromJobs(List<V2DownloadJob> jobs, {int todayBytes = 0, int todayCount = 0}) {
    var queued = 0;
    var active = 0;
    var completed = 0;
    var failed = 0;
    var bytes = 0;
    var total = 0;
    DateTime? last;
    for (final j in jobs) {
      switch (j.state) {
        case V2DownloadState.queued:
          queued++;
          break;
        case V2DownloadState.downloading:
          active++;
          break;
        case V2DownloadState.completed:
          completed++;
          if (last == null || (j.finishedAt != null && j.finishedAt!.isAfter(last))) {
            last = j.finishedAt;
          }
          break;
        case V2DownloadState.failed:
          failed++;
          break;
        case V2DownloadState.paused:
        case V2DownloadState.cancelled:
          break;
      }
      bytes += j.bytesDownloaded;
      total += j.totalBytes;
    }
    return V2DownloadStats(
      queued: queued,
      active: active,
      completed: completed,
      failed: failed,
      bytesDownloaded: bytes,
      bytesTotal: total,
      todayBytes: todayBytes,
      todayCount: todayCount,
      totalJobs: jobs.length,
      lastCompletedAt: last,
    );
  }
}

/// تنسيق حجم بالعربية: 512 -> «512 ب»، 2048 -> «2 ك.ب»، 5.5 م.ب، 1.2 غ.ب.
String formatBytesAr(int bytes) {
  if (bytes < 0) bytes = 0;
  if (bytes < 1024) return '$bytes ب';
  const units = <String>['ك.ب', 'م.ب', 'غ.ب'];
  var v = bytes / 1024.0;
  var u = 0;
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024;
    u++;
  }
  final s = v >= 100 ? v.toStringAsFixed(0) : v.toStringAsFixed(1);
  final clean = s.endsWith('.0') ? s.substring(0, s.length - 2) : s;
  return '$clean ${units[u]}';
}

/// تنسيق سرعة بالعربية: 1536 -> «1.5 ك.ب/ث».
String formatSpeedAr(double bytesPerSecond) {
  if (bytesPerSecond <= 0) return '0 ب/ث';
  return '${formatBytesAr(bytesPerSecond.round())}/ث';
}

/// مفتاح يوم بصيغة YYYY-MM-DD لعدّادات «اليوم».
String v2DayKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// مراقب شبكة خفيف فوق connectivity_plus.
/// يُستعمل من المحرك لاتخاذ قرارات سياسة الشبكة، ويمكن تثبيت حالته في
/// الاختبارات عبر [overrideCondition] دون لمس الجهاز.
class V2NetworkMonitor {
  V2NetworkMonitor._();
  static final V2NetworkMonitor i = V2NetworkMonitor._();

  V2NetworkCondition? _override;
  StreamSubscription<List<ConnectivityResult>>? _sub;
  V2NetworkCondition _current = V2NetworkCondition.unknown;
  final StreamController<V2NetworkCondition> _controller =
      StreamController<V2NetworkCondition>.broadcast();

  V2NetworkCondition get current => _override ?? _current;
  Stream<V2NetworkCondition> get onChange => _controller.stream;

  /// تثبيت حالة للاختبار (null = العودة للكشف الحقيقي).
  void overrideCondition(V2NetworkCondition? c) {
    _override = c;
    _controller.add(current);
  }

  Future<V2NetworkCondition> detect() async {
    if (_override != null) return _override!;
    try {
      final results = await Connectivity().checkConnectivity().timeout(const Duration(seconds: 5));
      _current = _fromResults(results);
    } catch (_) {
      _current = V2NetworkCondition.unknown;
    }
    return _current;
  }

  void startListening() {
    if (_sub != null) return;
    try {
      _sub = Connectivity().onConnectivityChanged.listen((results) {
        final next = _fromResults(results);
        if (next != _current) {
          _current = next;
          _controller.add(current);
        }
      });
    } catch (_) {
      // بيئة بلا قنوات منصة (اختبارات): يبقى الكشف اليدوي عبر detect().
      _sub = null;
    }
    unawaited(detect());
  }

  void dispose() {
    _sub?.cancel();
    _sub = null;
  }

  static V2NetworkCondition _fromResults(List<ConnectivityResult> results) {
    if (results.isEmpty || results.contains(ConnectivityResult.none)) {
      return V2NetworkCondition.offline;
    }
    if (results.contains(ConnectivityResult.wifi) ||
        results.contains(ConnectivityResult.ethernet)) {
      return V2NetworkCondition.wifi;
    }
    if (results.contains(ConnectivityResult.mobile)) {
      return V2NetworkCondition.mobile;
    }
    return V2NetworkCondition.unknown;
  }
}

/// محرك التنزيل v2.
///
/// الاستعمال:
/// ```dart
/// await V2DownloadEngine.i.load();
/// await V2DownloadEngine.i.enqueue(
///   seriesId: s.id, seriesTitle: s.title, chapter: 12,
///   pages: chapterPages, priority: V2DownloadPriority.high,
/// );
/// ```
/// يستمع المحرك لتغيّر الشبكة تلقائياً: عند فقدان الاتصال يوقف المهام النشطة
/// (مع حفظ موضعها)، وعند عودة الواي فاي يستأنفها إن كان الاستئناف التلقائي مفعّلاً.
class V2DownloadEngine extends ChangeNotifier {
  V2DownloadEngine._();
  static final V2DownloadEngine i = V2DownloadEngine._();

  /// نسخة اختبار بذاكرة مستقلة (لا تشارك حالة المفردة).
  factory V2DownloadEngine.testInstance() => V2DownloadEngine._();

  static const String _jobsKey = 'sard_dl_v2_jobs_v1';
  static const String _prefsKey = 'sard_dl_v2_prefs_v1';
  static const String _cellularKeyPrefix = 'sard_dl_v2_cellular_';

  static const int kDefaultMaxConcurrent = 2;
  static const int kDefaultCellularLimitMB = 200;
  static const int kMaxRetries = 3;

  final List<V2DownloadJob> _jobs = <V2DownloadJob>[];
  final Set<String> _pausedIds = <String>{};
  final Set<String> _cancelledIds = <String>{};
  final Map<String, int> _activeSpeeds = <String, int>{};

  bool _ready = false;
  int _maxConcurrent = kDefaultMaxConcurrent;
  V2NetworkPolicy _policy = V2NetworkPolicy.wifiOnly;
  int _cellularLimitMB = kDefaultCellularLimitMB;
  bool _autoResume = true;
  int _todayCellularBytes = 0;
  int _todayCount = 0;
  String _todayKey = v2DayKey(DateTime.now());
  StreamSubscription<V2NetworkCondition>? _netSub;
  int _running = 0;

  List<V2DownloadJob> get jobs => List<V2DownloadJob>.unmodifiable(_jobs);
  List<V2DownloadJob> get activeJobs =>
      _jobs.where((j) => j.state.isActive || j.state.isWaiting).toList();
  List<V2DownloadJob> get completedJobs =>
      _jobs.where((j) => j.state == V2DownloadState.completed).toList();
  List<V2DownloadJob> get failedJobs =>
      _jobs.where((j) => j.state == V2DownloadState.failed).toList();
  List<V2DownloadJob> get pausedJobs =>
      _jobs.where((j) => j.state == V2DownloadState.paused).toList();

  int get maxConcurrent => _maxConcurrent;
  V2NetworkPolicy get policy => _policy;
  int get cellularLimitMB => _cellularLimitMB;
  bool get autoResume => _autoResume;
  bool get isReady => _ready;

  V2DownloadStats get stats => V2DownloadStats.fromJobs(
        _jobs,
        todayBytes: _todayCellularBytes,
        todayCount: _todayCount,
      );

  /// بايتات بيانات الجوال المستهلكة اليوم (للحدّ اليومي).
  int get todayCellularBytes => _todayCellularBytes;
  int get cellularLimitBytes => _cellularLimitMB * 1024 * 1024;
  bool get cellularLimitReached => _todayCellularBytes >= cellularLimitBytes;
  double get cellularUsageFraction =>
      cellularLimitBytes <= 0 ? 0 : (_todayCellularBytes / cellularLimitBytes).clamp(0.0, 1.0);

  Future<Directory> get _baseDir async {
    final d = await getApplicationDocumentsDirectory();
    final dir = Directory('${d.path}/sard_downloads_v2');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// تحميل الطابور والإعدادات من التخزين الدائم.
  Future<void> load() async {
    if (_ready) return;
    final p = await SharedPreferences.getInstance();
    try {
      final raw = p.getString(_jobsKey);
      if (raw != null && raw.isNotEmpty) {
        final list = (jsonDecode(raw) as List).cast<Map>();
        for (final e in list) {
          try {
            _jobs.add(V2DownloadJob.fromJson(Map<String, dynamic>.from(e)));
          } catch (_) {}
        }
      }
    } catch (_) {}
    // المهام التي كانت نشطة عند إغلاق التطبيق تعود «متوقفة» لاستئنافها يدوياً.
    for (var k = 0; k < _jobs.length; k++) {
      final j = _jobs[k];
      if (j.state == V2DownloadState.downloading || j.state == V2DownloadState.queued) {
        _jobs[k] = j.copyWith(state: V2DownloadState.paused);
      }
    }
    try {
      final raw = p.getString(_prefsKey);
      if (raw != null && raw.isNotEmpty) {
        final m = Map<String, dynamic>.from(jsonDecode(raw) as Map);
        _maxConcurrent = ((m['maxConcurrent'] as num?)?.toInt() ?? kDefaultMaxConcurrent)
            .clamp(1, 5)
            .toInt();
        _policy = V2NetworkPolicy.fromName(m['policy'] as String?);
        _cellularLimitMB = ((m['cellularLimitMB'] as num?)?.toInt() ?? kDefaultCellularLimitMB)
            .clamp(0, 2048)
            .toInt();
        _autoResume = m['autoResume'] as bool? ?? true;
      }
    } catch (_) {}
    _todayKey = v2DayKey(DateTime.now());
    _todayCellularBytes = p.getInt('$_cellularKeyPrefix$_todayKey') ?? 0;
    _todayCount = p.getInt('${_cellularKeyPrefix}count_$_todayKey') ?? 0;
    _ready = true;
    await _persist();
    V2NetworkMonitor.i.startListening();
    _netSub ??= V2NetworkMonitor.i.onChange.listen(_onNetworkChanged);
    notifyListeners();
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_jobsKey, jsonEncode(_jobs.map((e) => e.toJson()).toList()));
    await p.setString(
      _prefsKey,
      jsonEncode({
        'maxConcurrent': _maxConcurrent,
        'policy': _policy.name,
        'cellularLimitMB': _cellularLimitMB,
        'autoResume': _autoResume,
      }),
    );
  }

  Future<void> _persistCellular() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('$_cellularKeyPrefix$_todayKey', _todayCellularBytes);
    await p.setInt('${_cellularKeyPrefix}count_$_todayKey', _todayCount);
  }

  void _rollDayIfNeeded() {
    final k = v2DayKey(DateTime.now());
    if (k != _todayKey) {
      _todayKey = k;
      _todayCellularBytes = 0;
      _todayCount = 0;
      unawaited(_persistCellular());
    }
  }

  void _onNetworkChanged(V2NetworkCondition condition) {
    if (!_ready) return;
    if (condition == V2NetworkCondition.offline) {
      // أوقف النشط مع حفظ الموضع؛ الاستئناف عند عودة الشبكة.
      for (final j in _jobs.where((e) => e.state.isActive).toList()) {
        _pausedIds.add(j.id);
      }
      notifyListeners();
      return;
    }
    if (_autoResume) {
      unawaited(_pump());
    }
  }

  // ───────── الإعدادات ─────────

  Future<void> setMaxConcurrent(int n) async {
    _maxConcurrent = n.clamp(1, 5).toInt();
    await _persist();
    notifyListeners();
    unawaited(_pump());
  }

  Future<void> setPolicy(V2NetworkPolicy policy) async {
    _policy = policy;
    await _persist();
    notifyListeners();
    unawaited(_pump());
  }

  Future<void> setCellularLimitMB(int mb) async {
    _cellularLimitMB = mb.clamp(0, 2048).toInt();
    await _persist();
    notifyListeners();
  }

  Future<void> setAutoResume(bool v) async {
    _autoResume = v;
    await _persist();
    notifyListeners();
  }

  // ───────── الاستعلام ─────────

  V2DownloadJob? job(String id) {
    for (final j in _jobs) {
      if (j.id == id) return j;
    }
    return null;
  }

  V2DownloadJob? jobForChapter(String seriesId, int chapter) {
    for (final j in _jobs) {
      if (j.seriesId == seriesId && j.chapter == chapter) return j;
    }
    return null;
  }

  List<V2DownloadJob> jobsForSeries(String seriesId) =>
      _jobs.where((j) => j.seriesId == seriesId).toList();

  bool isDownloaded(String seriesId, int chapter) {
    final j = jobForChapter(seriesId, chapter);
    return j != null && j.isComplete;
  }

  /// مسارات ملفات الفصل المنزَّل (null إن لم يكتمل أو فقدت ملفاته).
  Future<List<String>?> downloadedFiles(String seriesId, int chapter) async {
    final j = jobForChapter(seriesId, chapter);
    if (j == null || !j.isComplete || j.files.length != j.pageUrls.length) return null;
    for (final f in j.files) {
      if (!await File(f).exists()) return null;
    }
    return List<String>.from(j.files);
  }

  // ───────── الطابور ─────────

  /// إضافة فصل إلى الطابور (أو إعادته إن كان موجوداً غير مكتمل).
  /// تُرمى [V2DownloadException] إن كانت قائمة الصفحات فارغة.
  Future<V2DownloadJob> enqueue({
    required String seriesId,
    required String seriesTitle,
    required int chapter,
    required List<PageSrc> pages,
    String? cover,
    V2DownloadPriority priority = V2DownloadPriority.normal,
  }) async {
    await load();
    if (pages.isEmpty) {
      throw const V2DownloadException('لا توجد صفحات لتنزيلها في هذا الفصل');
    }
    final old = jobForChapter(seriesId, chapter);
    if (old != null) {
      if (old.isComplete) return old;
      if (old.state.isActive || old.state.isWaiting) return old;
      final revived = old.copyWith(
        state: V2DownloadState.queued,
        priority: priority,
        error: '',
      );
      _replace(revived);
      await _persist();
      notifyListeners();
      unawaited(_pump());
      return revived;
    }
    final job = V2DownloadJob(
      id: '${seriesId}_${chapter}_${DateTime.now().millisecondsSinceEpoch}',
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      pageUrls: pages.map((e) => e.url).toList(),
      cover: cover,
      priority: priority,
      createdAt: DateTime.now(),
    );
    // الأولويات العالية تتقدّم في الطابور.
    var at = _jobs.length;
    for (var k = 0; k < _jobs.length; k++) {
      if (_jobs[k].priority.weight < priority.weight &&
          (_jobs[k].state.isWaiting || _jobs[k].state == V2DownloadState.paused)) {
        at = k;
        break;
      }
    }
    _jobs.insert(at, job);
    await _persist();
    notifyListeners();
    unawaited(_pump());
    return job;
  }

  /// تنزيل عدة فصول دفعة واحدة (مثلاً: «حمّل الفصول العشرة التالية»).
  Future<List<V2DownloadJob>> enqueueChapters({
    required Series series,
    required List<int> chapters,
    required Map<int, List<PageSrc>> pagesByChapter,
    V2DownloadPriority priority = V2DownloadPriority.low,
  }) async {
    final out = <V2DownloadJob>[];
    for (final c in chapters) {
      final pages = pagesByChapter[c];
      if (pages == null || pages.isEmpty) continue;
      out.add(await enqueue(
        seriesId: series.id,
        seriesTitle: series.title,
        chapter: c,
        pages: pages,
        cover: series.cover,
        priority: priority,
      ));
    }
    return out;
  }

  Future<void> pause(String id) async {
    _pausedIds.add(id);
    final j = job(id);
    if (j != null && (j.state.isActive || j.state.isWaiting)) {
      _replace(j.copyWith(state: V2DownloadState.paused));
      await _persist();
      notifyListeners();
    }
    unawaited(_pump());
  }

  Future<void> resume(String id) async {
    final j = job(id);
    if (j == null || !j.canResume) return;
    _pausedIds.remove(id);
    _cancelledIds.remove(id);
    _replace(j.copyWith(state: V2DownloadState.queued, error: ''));
    await _persist();
    notifyListeners();
    unawaited(_pump());
  }

  Future<void> retry(String id) async {
    final j = job(id);
    if (j == null || j.state != V2DownloadState.failed) return;
    _replace(j.copyWith(state: V2DownloadState.queued, retries: 0, error: ''));
    await _persist();
    notifyListeners();
    unawaited(_pump());
  }

  Future<void> cancel(String id) async {
    _cancelledIds.add(id);
    _pausedIds.add(id);
    final j = job(id);
    if (j != null && !j.state.isFinished) {
      _replace(j.copyWith(state: V2DownloadState.cancelled));
      await _persist();
      notifyListeners();
    }
    unawaited(_pump());
  }

  Future<void> remove(String id) async {
    final j = job(id);
    if (j == null) return;
    _cancelledIds.add(id);
    _pausedIds.add(id);
    for (final f in j.files) {
      try {
        await File(f).delete();
      } catch (_) {}
    }
    _jobs.removeWhere((e) => e.id == id);
    await _persist();
    notifyListeners();
  }

  Future<void> pauseAll() async {
    var changed = false;
    for (var k = 0; k < _jobs.length; k++) {
      final j = _jobs[k];
      if (j.state.isActive || j.state.isWaiting) {
        _pausedIds.add(j.id);
        _jobs[k] = j.copyWith(state: V2DownloadState.paused);
        changed = true;
      }
    }
    if (changed) {
      await _persist();
      notifyListeners();
    }
  }

  Future<void> resumeAll() async {
    var changed = false;
    for (var k = 0; k < _jobs.length; k++) {
      final j = _jobs[k];
      if (j.canResume) {
        _pausedIds.remove(j.id);
        _jobs[k] = j.copyWith(state: V2DownloadState.queued, error: '');
        changed = true;
      }
    }
    if (changed) {
      await _persist();
      notifyListeners();
      unawaited(_pump());
    }
  }

  Future<void> retryAllFailed() async {
    for (final j in failedJobs) {
      await retry(j.id);
    }
  }

  Future<void> clearCompleted() async {
    final done = _jobs.where((j) => j.state == V2DownloadState.completed).toList();
    for (final j in done) {
      for (final f in j.files) {
        try {
          await File(f).delete();
        } catch (_) {}
      }
    }
    _jobs.removeWhere((j) => j.state == V2DownloadState.completed);
    await _persist();
    notifyListeners();
  }

  Future<void> clearCancelled() async {
    _jobs.removeWhere((j) => j.state == V2DownloadState.cancelled);
    await _persist();
    notifyListeners();
  }

  void _replace(V2DownloadJob job) {
    final k = _jobs.indexWhere((e) => e.id == job.id);
    if (k >= 0) _jobs[k] = job;
  }

  // ───────── تشغيل الطابور ─────────

  /// ترتيب الطابور: الأولوية الأعلى أولاً، ثم الأقدم.
  static int compareQueue(V2DownloadJob a, V2DownloadJob b) {
    final byPriority = b.priority.weight.compareTo(a.priority.weight);
    if (byPriority != 0) return byPriority;
    final ac = a.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
    final bc = b.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
    return ac.compareTo(bc);
  }

  Future<void> _pump() async {
    if (!_ready) return;
    _rollDayIfNeeded();
    final condition = await V2NetworkMonitor.i.detect();
    if (!condition.isOnline) return;
    if (_policy == V2NetworkPolicy.wifiOnly && condition != V2NetworkCondition.wifi) {
      return;
    }
    if (_policy == V2NetworkPolicy.wifiOrMobile &&
        condition == V2NetworkCondition.mobile &&
        cellularLimitReached) {
      return;
    }
    final waiting = _jobs.where((j) => j.state.isWaiting).toList()..sort(compareQueue);
    for (final j in waiting) {
      if (_running >= _maxConcurrent) return;
      if (_pausedIds.contains(j.id) || _cancelledIds.contains(j.id)) continue;
      _running++;
      unawaited(_run(j.id).whenComplete(() {
        _running = math.max(0, _running - 1);
        unawaited(_pump());
      }));
    }
  }

  Future<void> _run(String id) async {
    var index = _jobs.indexWhere((e) => e.id == id);
    if (index < 0) return;
    var job = _jobs[index];
    if (job.isComplete || job.state.isFinished) return;
    _pausedIds.remove(id);
    job = job.copyWith(
      state: V2DownloadState.downloading,
      error: '',
      startedAt: job.startedAt ?? DateTime.now(),
    );
    _jobs[index] = job;
    await _persist();
    notifyListeners();

    try {
      final dir = await _baseDir;
      final files = List<String>.from(job.files);
      var bytes = job.bytesDownloaded;
      var total = job.totalBytes;
      for (var i = job.completedPages; i < job.pageUrls.length; i++) {
        if (_pausedIds.contains(id) || _cancelledIds.contains(id)) {
          await _replaceAndSave(id, job.copyWith(
            files: files,
            completedPages: i,
            bytesDownloaded: bytes,
            totalBytes: total,
            state: _cancelledIds.contains(id) ? V2DownloadState.cancelled : V2DownloadState.paused,
          ));
          return;
        }
        final condition = await V2NetworkMonitor.i.detect();
        if (!condition.isOnline) {
          await _replaceAndSave(id, job.copyWith(
            files: files,
            completedPages: i,
            bytesDownloaded: bytes,
            totalBytes: total,
            state: V2DownloadState.paused,
            error: 'انقطع الاتصال — سيُستأنف تلقائياً',
          ));
          return;
        }
        if (_policy == V2NetworkPolicy.wifiOnly && condition != V2NetworkCondition.wifi) {
          await _replaceAndSave(id, job.copyWith(
            files: files,
            completedPages: i,
            bytesDownloaded: bytes,
            totalBytes: total,
            state: V2DownloadState.paused,
            error: 'بانتظار الواي فاي (السياسة: واي فاي فقط)',
          ));
          return;
        }
        if (condition == V2NetworkCondition.mobile && _policy == V2NetworkPolicy.wifiOrMobile) {
          _rollDayIfNeeded();
          if (cellularLimitReached) {
            await _replaceAndSave(id, job.copyWith(
              files: files,
              completedPages: i,
              bytesDownloaded: bytes,
              totalBytes: total,
              state: V2DownloadState.paused,
              error: 'بلغتَ حدّ بيانات الجوال اليومي ($_cellularLimitMB م.ب)',
            ));
            return;
          }
        }
        final url = job.pageUrls[i];
        final data = await _downloadPage(url, condition);
        final ext = _safeExt(url);
        final file = File('${dir.path}/${id}_$i.$ext');
        await file.writeAsBytes(data, flush: true);
        if (files.length <= i) {
          files.add(file.path);
        } else {
          files[i] = file.path;
        }
        bytes += data.length;
        total += data.length;
        if (condition == V2NetworkCondition.mobile) {
          _todayCellularBytes += data.length;
          unawaited(_persistCellular());
        }
        job = job.copyWith(
          files: files,
          completedPages: i + 1,
          bytesDownloaded: bytes,
          totalBytes: total,
        );
        _jobs[index] = job;
        _activeSpeeds[id] = data.length;
        await _persist();
        notifyListeners();
      }
      _todayCount++;
      await _persistCellular();
      await _replaceAndSave(id, job.copyWith(
        state: V2DownloadState.completed,
        completedPages: job.pageUrls.length,
        finishedAt: DateTime.now(),
      ));
    } catch (e) {
      final current = job.copyWith(
        files: List<String>.from(job.files),
        completedPages: job.completedPages,
        bytesDownloaded: job.bytesDownloaded,
        totalBytes: job.totalBytes,
      );
      if (current.retries < kMaxRetries && !_cancelledIds.contains(id)) {
        // إعادة محاولة بعد تأخير متباعد (2ث، 5ث، 12ث) ثم فشل نهائي.
        final attempt = current.retries + 1;
        final wait = Duration(seconds: <int>[2, 5, 12][attempt - 1]);
        await _replaceAndSave(id, current.copyWith(
          state: V2DownloadState.paused,
          retries: attempt,
          error: 'تعذّر الاتصال — إعادة المحاولة $attempt من $kMaxRetries بعد ${wait.inSeconds} ث',
        ));
        await Future<void>.delayed(wait);
        if (_pausedIds.contains(id) || _cancelledIds.contains(id)) return;
        final again = jobForChapter(current.seriesId, current.chapter);
        if (again != null && again.state == V2DownloadState.paused) {
          await resume(id);
        }
        return;
      }
      await _replaceAndSave(id, current.copyWith(
        state: V2DownloadState.failed,
        error: _friendlyError(e),
        finishedAt: DateTime.now(),
      ));
    }
  }

  Future<List<int>> _downloadPage(String url, V2NetworkCondition condition) async {
    final uri = Uri.parse(url);
    final response = await http
        .get(uri, headers: const {'User-Agent': 'Senok/2.0'})
        .timeout(const Duration(seconds: 35));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException('HTTP ${response.statusCode}');
    }
    if (response.bodyBytes.isEmpty) {
      throw const V2DownloadException('صفحة فارغة من الخادم');
    }
    return response.bodyBytes;
  }

  static String _safeExt(String url) {
    final raw = Uri.tryParse(url)?.path.split('.').last.toLowerCase().split('?').first ?? 'jpg';
    return <String>['jpg', 'jpeg', 'png', 'webp', 'gif'].contains(raw) ? raw : 'jpg';
  }

  static String _friendlyError(Object e) {
    final s = e.toString();
    if (s.contains('SocketException') || s.contains('Failed host lookup')) {
      return 'لا يوجد اتصال بالإنترنت';
    }
    if (s.contains('TimeoutException') || s.contains('timed out')) {
      return 'استغرق الاتصال وقتاً طويلاً';
    }
    if (s.contains('HttpException')) {
      return 'تعذّر تحميل الصفحة من الخادم';
    }
    if (s.contains('404')) return 'الصفحة غير موجودة على الخادم';
    return 'تعذّر التنزيل: $s';
  }

  Future<void> _replaceAndSave(String id, V2DownloadJob job) async {
    _replace(job);
    await _persist();
    notifyListeners();
  }

  /// مسح الحالة بالكامل (للاختبارات فقط).
  Future<void> resetForTest() async {
    _jobs.clear();
    _pausedIds.clear();
    _cancelledIds.clear();
    _activeSpeeds.clear();
    _running = 0;
    _todayCellularBytes = 0;
    _todayCount = 0;
    _ready = false;
    final p = await SharedPreferences.getInstance();
    await p.remove(_jobsKey);
    await p.remove(_prefsKey);
    notifyListeners();
  }

  @override
  void dispose() {
    _netSub?.cancel();
    super.dispose();
  }
}

/// عينة سرعة لحظية (بايتات خلال ثانية) لتقدير السرعة المتدحرجة.
@immutable
class V2SpeedSample {
  const V2SpeedSample({required this.at, required this.bytes});
  final DateTime at;
  final int bytes;
}

/// متتبع سرعة متدحرج: متوسط آخر N عينات (افتراضياً 10 ثوانٍ).
/// يمنع قفزات «الوقت المتبقي» عند تذبذب الشبكة.
class V2SpeedTracker {
  V2SpeedTracker({this.window = const Duration(seconds: 10)});

  final Duration window;
  final List<V2SpeedSample> _samples = <V2SpeedSample>[];

  void add(int bytes, {DateTime? at}) {
    final now = at ?? DateTime.now();
    _samples.add(V2SpeedSample(at: now, bytes: bytes));
    _prune(now);
  }

  void _prune(DateTime now) {
    final cutoff = now.subtract(window);
    _samples.removeWhere((s) => s.at.isBefore(cutoff));
  }

  /// السرعة المتوسطة (بايت/ثانية) خلال النافذة.
  double get bytesPerSecond {
    if (_samples.isEmpty) return 0;
    final now = DateTime.now();
    _prune(now);
    if (_samples.isEmpty) return 0;
    final total = _samples.fold<int>(0, (a, s) => a + s.bytes);
    final span = now.difference(_samples.first.at).inMilliseconds / 1000.0;
    if (span <= 0) return total.toDouble();
    return total / span;
  }

  String get label => formatSpeedAr(bytesPerSecond);
  bool get hasData => _samples.isNotEmpty;
  void clear() => _samples.clear();
}

/// سجل تنزيل منتهٍ (للأرشيف والإحصاءات طويلة المدى).
@immutable
class V2DownloadHistoryEntry {
  const V2DownloadHistoryEntry({
    required this.jobId,
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.state,
    required this.bytes,
    required this.pages,
    required this.finishedAt,
    this.error = '',
  });

  final String jobId;
  final String seriesId;
  final String seriesTitle;
  final int chapter;
  final V2DownloadState state;
  final int bytes;
  final int pages;
  final DateTime finishedAt;
  final String error;

  bool get succeeded => state == V2DownloadState.completed;

  Map<String, dynamic> toJson() => {
        'jobId': jobId,
        'seriesId': seriesId,
        'seriesTitle': seriesTitle,
        'chapter': chapter,
        'state': state.name,
        'bytes': bytes,
        'pages': pages,
        'finishedAt': finishedAt.millisecondsSinceEpoch,
        'error': error,
      };

  factory V2DownloadHistoryEntry.fromJson(Map<String, dynamic> j) {
    return V2DownloadHistoryEntry(
      jobId: '${j['jobId']}',
      seriesId: '${j['seriesId']}',
      seriesTitle: '${j['seriesTitle'] ?? ''}',
      chapter: (j['chapter'] as num?)?.toInt() ?? 0,
      state: V2DownloadState.fromName(j['state'] as String?),
      bytes: (j['bytes'] as num?)?.toInt() ?? 0,
      pages: (j['pages'] as num?)?.toInt() ?? 0,
      finishedAt: j['finishedAt'] is num
          ? DateTime.fromMillisecondsSinceEpoch((j['finishedAt'] as num).toInt())
          : DateTime.now(),
      error: '${j['error'] ?? ''}',
    );
  }
}

/// لقطة طابور قابلة للتسلسل (للواجهات المصغّرة والإشعارات).
@immutable
class V2QueueSnapshot {
  const V2QueueSnapshot({
    required this.total,
    required this.active,
    required this.queued,
    required this.completed,
    required this.failed,
    required this.overallProgress,
    this.currentJobTitle,
    this.currentJobProgress,
  });

  final int total;
  final int active;
  final int queued;
  final int completed;
  final int failed;
  final double overallProgress;
  final String? currentJobTitle;
  final double? currentJobProgress;

  factory V2QueueSnapshot.fromEngine(V2DownloadEngine engine) {
    final stats = engine.stats;
    final current = engine.jobs.where((j) => j.state.isActive).toList();
    current.sort(V2DownloadEngine.compareQueue);
    return V2QueueSnapshot(
      total: stats.totalJobs,
      active: stats.active,
      queued: stats.queued,
      completed: stats.completed,
      failed: stats.failed,
      overallProgress: stats.overallProgress,
      currentJobTitle: current.isEmpty ? null : current.first.displayTitle,
      currentJobProgress: current.isEmpty ? null : current.first.progress,
    );
  }

  String get summary {
    if (total == 0) return 'لا توجد تنزيلات';
    if (active > 0 && currentJobTitle != null) {
      return 'يُنزَّل الآن: $currentJobTitle';
    }
    if (queued > 0) return '$queued في الانتظار · $completed مكتمل';
    return '$completed مكتمل · $failed فشل';
  }
}

/// إعدادات مسبقة شائعة للطابور.
class V2QueuePresets {
  V2QueuePresets._();

  /// توفير البيانات: واي فاي فقط، تنزيل واحد، حدّ يومي 100 م.ب.
  static const Map<String, dynamic> dataSaver = <String, dynamic>{
    'policy': 'wifiOnly',
    'maxConcurrent': 1,
    'cellularLimitMB': 100,
    'autoResume': true,
  };

  /// متوازن: واي فاي فقط، تنزيلان، استئناف تلقائي.
  static const Map<String, dynamic> balanced = <String, dynamic>{
    'policy': 'wifiOnly',
    'maxConcurrent': 2,
    'cellularLimitMB': 200,
    'autoResume': true,
  };

  /// سريع: أي شبكة، 4 تنزيلات متزامنة، حدّ يومي 1 غ.ب.
  static const Map<String, dynamic> fast = <String, dynamic>{
    'policy': 'any',
    'maxConcurrent': 4,
    'cellularLimitMB': 1024,
    'autoResume': true,
  };
}

/// امتدادات عمليات جماعية على المحرك (تُستعمل من شاشات المكتبة).
extension V2DownloadEngineBatch on V2DownloadEngine {
  /// يوقف كل تنزيلات عمل واحد.
  Future<void> pauseSeries(String seriesId) async {
    for (final j in jobsForSeries(seriesId)) {
      await pause(j.id);
    }
  }

  /// يستأنف كل تنزيلات عمل واحد القابلة للاستئناف.
  Future<void> resumeSeries(String seriesId) async {
    for (final j in jobsForSeries(seriesId)) {
      if (j.canResume) await resume(j.id);
    }
  }

  /// يحذف كل تنزيلات عمل واحد (مع ملفاتها).
  Future<void> removeSeries(String seriesId) async {
    for (final j in jobsForSeries(seriesId).toList()) {
      await remove(j.id);
    }
  }

  /// عدد فصول العمل المنزَّلة بالكامل.
  int downloadedChaptersCount(String seriesId) =>
      jobsForSeries(seriesId).where((j) => j.isComplete).length;

  /// إجمالي بايتات التنزيلات المكتملة.
  int get totalDownloadedBytes =>
      jobs.where((j) => j.isComplete).fold<int>(0, (a, j) => a + j.bytesDownloaded);

  /// إجمالي بايتات كل المهام (بما فيها غير المكتملة).
  int get totalBytesAllJobs => jobs.fold<int>(0, (a, j) => a + j.bytesDownloaded);
}

/// يقدّر زمن تنزيل فصل من حجمه وسرعة الشبكة الحالية.
String estimateDownloadTime(int bytes, double bytesPerSecond) {
  if (bytes <= 0) return '—';
  if (bytesPerSecond <= 0) return 'غير معروف';
  final seconds = bytes / bytesPerSecond;
  if (seconds < 60) return '~${seconds.ceil()} ث';
  final minutes = seconds / 60;
  if (minutes < 60) return '~${minutes.ceil()} د';
  return '~${(minutes / 60).toStringAsFixed(1)} س';
}

/// يقدّر حجم فصل من عدد صفحاته (متوسط 350 ك.ب للصفحة).
int estimateChapterBytes(int pages, {int bytesPerPage = 350 * 1024}) =>
    pages * bytesPerPage;

/// حدث في سجل محرك التنزيل (للتشخيص).
enum V2EngineEventKind {
  enqueued('أُضيف إلى الطابور'),
  started('بدأ التنزيل'),
  paused('أُوقف مؤقتاً'),
  resumed('استُؤنف'),
  completed('اكتمل'),
  failed('فشل'),
  cancelled('أُلغي'),
  removed('حُذف'),
  retried('أُعيدت المحاولة');

  const V2EngineEventKind(this.label);
  final String label;
}

/// حدث واحد في سجل المحرك.
@immutable
class V2EngineEvent {
  const V2EngineEvent({required this.kind, required this.message, required this.at});
  final V2EngineEventKind kind;
  final String message;
  final DateTime at;

  Map<String, dynamic> toJson() => {
        'kind': kind.name,
        'message': message,
        'at': at.millisecondsSinceEpoch,
      };
}

/// سجل أحداث محرك التنزيل (آخر 100 حدث، في الذاكرة).
class V2EngineEventLog {
  final List<V2EngineEvent> _events = <V2EngineEvent>[];
  static const int kMaxEvents = 100;

  List<V2EngineEvent> get events => List<V2EngineEvent>.unmodifiable(_events);

  void add(V2EngineEventKind kind, String message) {
    _events.add(V2EngineEvent(kind: kind, message: message, at: DateTime.now()));
    while (_events.length > kMaxEvents) {
      _events.removeAt(0);
    }
  }

  List<V2EngineEvent> ofKind(V2EngineEventKind kind) =>
      _events.where((e) => e.kind == kind).toList();

  int countOf(V2EngineEventKind kind) => _events.where((e) => e.kind == kind).length;
  void clear() => _events.clear();

  List<Map<String, dynamic>> toJson() => _events.map((e) => e.toJson()).toList();
}

/// تشخيص المحرك كخريطة (لشاشة التشخيص أو التصدير).
Map<String, dynamic> v2EngineDiagnostics(V2DownloadEngine engine, V2NetworkCondition condition) {
  final stats = engine.stats;
  return <String, dynamic>{
    'network': condition.name,
    'policy': engine.policy.name,
    'maxConcurrent': engine.maxConcurrent,
    'autoResume': engine.autoResume,
    'cellularLimitMB': engine.cellularLimitMB,
    'todayCellularBytes': engine.todayCellularBytes,
    'cellularLimitReached': engine.cellularLimitReached,
    'jobs': stats.toJson(),
    'generatedAt': DateTime.now().millisecondsSinceEpoch,
  };
}

/// نص مشاركة لمهمة تنزيل (للعرض في السجل أو المشاركة).
extension V2DownloadJobShare on V2DownloadJob {
  String toShareText() {
    if (isComplete) {
      return 'حمّلت «$seriesTitle — الفصل $chapter» للقراءة دون اتصال (${formatBytesAr(bytesDownloaded)}).';
    }
    return 'أحمّل «$seriesTitle — الفصل $chapter»: $percent٪ مكتمل.';
  }

  /// وصف مختصر للحالة مع السبب عند الفشل.
  String get statusDetail {
    if (error.isNotEmpty) return '${state.label}: $error';
    if (state == V2DownloadState.downloading) return '${state.label} · $percent٪ · $etaLabel';
    return state.label;
  }
}
