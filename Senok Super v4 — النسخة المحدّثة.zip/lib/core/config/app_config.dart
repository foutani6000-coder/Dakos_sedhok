/// كل القيم هنا تأتي من ملف build_config.json
/// عبر --dart-define-from-file (انظر .github/workflows/build.yml).
/// غيّر رابط السيرفر في build_config.json فقط، ولا تضعه في أي ملف آخر.
import 'package:shared_preferences/shared_preferences.dart';

class AppConfig {
  AppConfig._();

  static const String appName =
      String.fromEnvironment('APP_NAME', defaultValue: 'Senok');
  static const String _rawBase =
      String.fromEnvironment('API_BASE_URL', defaultValue: '');
  static const String apiKey =
      String.fromEnvironment('API_KEY', defaultValue: '');
  static const String googleServerClientId =
      String.fromEnvironment('GOOGLE_SERVER_CLIENT_ID', defaultValue: '');
  static const String version = '0.2.0';

  /// عند true: إن أعاد السيرفر قائمة فصول/صفحات فارغة أو فشل تحميلها، يعرض التطبيق
  /// فصولاً وصفحات تجريبية للتجربة. اجعلها "false" في build_config.json للإنتاج.
  static const bool demoFallback =
      bool.fromEnvironment('DEMO_FALLBACK', defaultValue: true);

  static const String _prefKey = 'api_base_url_override';
  static String _override = '';

  /// يقرأ الرابط الذي ضبطه المستخدم من الإعدادات (إن وُجد) ويتقدّم على build_config.json
  static Future<void> loadOverride() async {
    final p = await SharedPreferences.getInstance();
    _override = (p.getString(_prefKey) ?? '').trim();
  }

  static Future<void> saveOverride(String v) async {
    final p = await SharedPreferences.getInstance();
    _override = v.trim();
    if (_override.isEmpty) {
      await p.remove(_prefKey);
    } else {
      await p.setString(_prefKey, _override);
    }
  }

  /// الرابط بدون "/" في النهاية
  static String get apiBaseUrl {
    final u = (_override.isNotEmpty ? _override : _rawBase).trim();
    return u.endsWith('/') ? u.substring(0, u.length - 1) : u;
  }

  /// إذا كان الرابط فارغاً يعمل التطبيق ببيانات تجريبية
  static bool get useMock => apiBaseUrl.isEmpty;
}
