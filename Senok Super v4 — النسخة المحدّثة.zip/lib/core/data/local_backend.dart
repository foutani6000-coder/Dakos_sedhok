import 'dart:convert';

import '../storage/auth_store.dart';
import 'api_client.dart';
import 'mock_data.dart';

/// خادم وهمي يعمل داخل التطبيق نفسه عندما يكون API_BASE_URL فارغاً.
/// يغطي الحسابات والمكتبة والأخبار والإشعارات دون أي اتصال بالإنترنت.
class LocalBackend {
  LocalBackend._();

  static final Set<String> _followed = <String>{};
  static final Map<String, dynamic> _progress = <String, dynamic>{};
  static final List<Map<String, dynamic>> _lists = <Map<String, dynamic>>[];

  static final List<Map<String, dynamic>> _news = <Map<String, dynamic>>[
    {
      'id': 'n1',
      'title': 'إطلاق النسخة التجريبية من Senok',
      'body': 'أهلاً بك في Senok! هذه نسخة تجريبية تعمل بدون خادم لتجربة كل الواجهات قبل الإصدار.',
      'created_at': 'اليوم',
      'category': 'إعلان',
    },
    {
      'id': 'n2',
      'title': 'فصول جديدة هذا الأسبوع',
      'body': 'تمت إضافة فصول جديدة لعدة أعمال. تابع أعمالك المفضلة لتصلك الإشعارات.',
      'created_at': 'أمس',
      'category': 'تحديث',
    },
    {
      'id': 'n3',
      'title': 'تحسينات القارئ',
      'body': 'وضع القراءة العمودي وصفحة بصفحة والتكبير وحفظ التقدّم متاحة الآن.',
      'created_at': 'قبل يومين',
      'category': 'ميزات',
    },
  ];

  static Future<dynamic> handle(String method, String path,
      {Map<String, String>? query, Object? body}) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    final b = body is Map ? Map<String, dynamic>.from(body) : <String, dynamic>{};

    // ───────── الحساب ─────────
    if (method == 'POST' && path == '/auth/login') {
      return _session('${b['email'] ?? ''}', null);
    }
    if (method == 'POST' && path == '/auth/register') {
      return _session('${b['email'] ?? ''}', '${b['name'] ?? ''}');
    }
    if (method == 'POST' && path == '/auth/google') {
      return _session('demo.google@example.com', 'مستخدم Google (تجريبي)');
    }
    if (method == 'POST' && path == '/auth/forgot-password') {
      return <String, dynamic>{'message': 'تم'};
    }
    if (path == '/users/me') {
      final current = await _currentUser();
      if (method == 'POST') {
        final name = '${b['name'] ?? ''}'.trim();
        if (name.isNotEmpty) current['name'] = name;
        current['avatar_url'] = '${b['avatar_url'] ?? ''}';
        final token = await AuthStore.token();
        await AuthStore.save(
          (token == null || token.isEmpty) ? 'demo-token' : token,
          userJson: jsonEncode(current),
        );
      }
      return <String, dynamic>{'user': current};
    }

    // ───────── المكتبة ─────────
    if (method == 'GET' && path == '/library') {
      final followed = <Map<String, dynamic>>[];
      for (final s in MockData.all) {
        if (_followed.contains(s.id)) followed.add(s.toJson());
      }
      final history = <Map<String, dynamic>>[];
      _progress.forEach((id, v) {
        String title = 'عمل';
        for (final s in MockData.all) {
          if (s.id == id) title = s.title;
        }
        final m = v is Map ? v : const {};
        history.add({
          'series_id': id,
          'title': title,
          'chapter': m['chapter'] ?? m['chapter_number'] ?? '',
          'page': m['page'] ?? '',
        });
      });
      return <String, dynamic>{'followed': followed, 'lists': _lists, 'history': history};
    }
    if (method == 'POST' && path == '/library/sync') {
      _followed.clear();
      final f = b['followed_series'];
      if (f is List) {
        for (final e in f) {
          _followed.add('$e');
        }
      }
      final p = b['progress'];
      if (p is Map) {
        _progress
          ..clear()
          ..addAll(Map<String, dynamic>.from(p));
      }
      return <String, dynamic>{'ok': true};
    }
    if (method == 'POST' && path == '/library/lists') {
      _lists.add({
        'id': 'l${_lists.length + 1}',
        'name': '${b['name'] ?? ''}',
        'is_public': b['is_public'] == true,
      });
      return <String, dynamic>{'ok': true};
    }
    if (method == 'POST' && path.startsWith('/library/lists/')) {
      return <String, dynamic>{'ok': true};
    }

    // ───────── الأخبار والإشعارات ─────────
    if (method == 'GET' && path == '/news') return _news;
    if (method == 'GET' && path.startsWith('/news/')) {
      final id = path.substring('/news/'.length);
      for (final n in _news) {
        if (n['id'] == id) return n;
      }
      return _news.first;
    }
    if (method == 'GET' && path == '/notifications') {
      final ids = (query?['series_ids'] ?? '').split(',').where((e) => e.isNotEmpty);
      final out = <Map<String, dynamic>>[];
      for (final id in ids) {
        for (final s in MockData.all) {
          if (s.id == id) {
            out.add({
              'id': 'n_$id',
              'title': 'فصل جديد',
              'body': 'صدر الفصل ${s.chapters} من ${s.title}',
              'created_at': 'قبل ساعة',
              'series_id': id,
              'chapter': s.chapters,
              'read': false,
            });
          }
        }
      }
      return out;
    }

    if (method == 'POST' && path.endsWith('/rating')) {
      return <String, dynamic>{'ok': true};
    }

    throw ApiException('غير موجود (وضع تجريبي): $path', failure: ApiFailure.notFound);
  }

  static Future<Map<String, dynamic>> _session(String email, String? name) async {
    final e = email.trim().toLowerCase();
    final n = (name != null && name.trim().isNotEmpty)
        ? name.trim()
        : (e.contains('@') ? e.split('@').first : 'قارئ');
    return <String, dynamic>{
      'token': 'demo-token',
      'user': <String, dynamic>{
        'id': 'demo_${e.hashCode.abs()}',
        'name': n,
        'email': e,
        'avatar_url': '',
      },
    };
  }

  static Future<Map<String, dynamic>> _currentUser() async {
    final fallback = <String, dynamic>{
      'id': 'demo',
      'name': 'قارئ',
      'email': 'demo@example.com',
      'avatar_url': '',
    };
    final raw = await AuthStore.userJson();
    if (raw == null || raw.isEmpty) return fallback;
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return fallback;
    }
  }
}
