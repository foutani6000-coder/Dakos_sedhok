class Series {
  const Series({
    required this.id,
    required this.title,
    this.cover,
    this.type = 'مانهوا كورية',
    this.status = 'مستمر',
    this.chapters = 0,
    this.rating = 0,
    this.views = 0,
    this.genres = const [],
    this.synopsis = '',
    this.isNew = false,
    this.year = 2025,
  });

  final String id;
  final String title;
  final String? cover;
  final String type;
  final String status;
  final int chapters;
  final double rating;
  final int views;
  final List<String> genres;
  final String synopsis;
  final bool isNew;
  final int year;

  /// رقم ثابت لتوليد غلاف فني عند غياب الصورة
  int get seed => id.codeUnits.fold<int>(7, (a, b) => a * 31 + b) & 0x7fffffff;

  bool get ongoing => status == 'مستمر';

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'cover': cover,
        'type': type,
        'status': status,
        'chapters': chapters,
        'rating': rating,
        'views': views,
        'genres': genres,
        'synopsis': synopsis,
        'is_new': isNew,
        'year': year,
      };

  factory Series.fromJson(Map<String, dynamic> j) {
    return Series(
      id: '${j['id']}',
      title: '${j['title']}',
      cover: j['cover'] as String?,
      type: (j['type'] ?? 'مانهوا كورية') as String,
      status: (j['status'] ?? 'مستمر') as String,
      chapters: (j['chapters'] as num?)?.toInt() ?? 0,
      rating: (j['rating'] as num?)?.toDouble() ?? 0,
      views: (j['views'] as num?)?.toInt() ?? 0,
      genres: ((j['genres'] as List?) ?? const []).map((e) => '$e').toList(),
      synopsis: (j['synopsis'] ?? '') as String,
      isNew: j['is_new'] == true,
      year: int.tryParse('${j['year'] ?? 2025}') ?? 2025,
    );
  }
}

class Chapter {
  const Chapter({
    required this.number,
    required this.title,
    required this.pages,
    required this.date,
    this.isNew = false,
  });

  final int number;
  final String title;
  final int pages;
  final String date;
  final bool isNew;

  /// يقبل السيرفر صيغاً متنوعة: number كعدد أو نص ("12" أو "12.5")،
  /// و pages كعدد أو كقائمة صفحات، و date أو created_at.
  factory Chapter.fromJson(Map<String, dynamic> j) {
    int toInt(dynamic v) {
      if (v is num) return v.toInt();
      final d = double.tryParse('${v ?? ''}'.trim());
      return d?.toInt() ?? 0;
    }

    var number = toInt(j['number'] ?? j['chapter'] ?? j['index']);
    final title = '${j['title'] ?? j['name'] ?? ''}';
    if (number == 0) {
      final m = RegExp(r'\d+').firstMatch(title);
      if (m != null) number = int.parse(m.group(0)!);
    }
    final pg = j['pages'] ?? j['pages_count'] ?? j['page_count'];
    return Chapter(
      number: number,
      title: title,
      pages: pg is List ? pg.length : toInt(pg),
      date: '${j['date'] ?? j['created_at'] ?? j['published_at'] ?? ''}',
      isNew: j['is_new'] == true || j['new'] == true,
    );
  }
}

/// صفحة واحدة من فصل: رابط الجودة الكاملة + رابط اختياري بجودة مخفّضة.
class PageSrc {
  const PageSrc(this.url, {this.low});
  final String url;
  final String? low;

  bool get isMock => url.startsWith('mock:');

  /// يقبل السيرفر إما نصاً "url" أو كائناً {url, low}
  factory PageSrc.fromJson(dynamic j) {
    if (j is Map) {
      final lowRaw = j['low'] ?? j['url_low'];
      final low = lowRaw == null ? null : '$lowRaw';
      return PageSrc('${j['url'] ?? j['image'] ?? j['src'] ?? ''}', low: (low == null || low.isEmpty) ? null : low);
    }
    return PageSrc('$j');
  }
}

class HomeData {
  const HomeData({
    required this.featured,
    required this.suggestions,
    required this.latest,
    required this.popular,
  });

  final List<Series> featured;
  final List<Series> suggestions;
  final List<Series> latest;
  final List<Series> popular;
}

/// 276000 -> "276 ألف"، 1250000 -> "1.3 م"
String formatCount(int n) {
  if (n < 1000) return '$n';
  if (n < 1000000) return '${_trim(n / 1000)} ألف';
  return '${_trim(n / 1000000)} م';
}

String _trim(double v) {
  final s = v >= 100 ? v.toStringAsFixed(0) : v.toStringAsFixed(1);
  return s.endsWith('.0') ? s.substring(0, s.length - 2) : s;
}


class SardComment {
  const SardComment({required this.id,required this.seriesId,required this.author,required this.text,
    required this.createdAt,this.likes=0,this.liked=false,this.parentId,this.authorId='',this.badge=SardBadge.none});
  final String id,seriesId,author,text,createdAt,authorId;
  final SardBadge badge;
  final int likes;
  final bool liked;
  final String? parentId;
  factory SardComment.fromJson(Map<String,dynamic> j)=>SardComment(
    id:'${j['id']}',seriesId:'${j['series_id'] ?? ''}',author:'${j['author'] ?? 'قارئ'}',
    text:'${j['text'] ?? ''}',createdAt:'${j['created_at'] ?? ''}',
    likes:(j['likes'] as num? ?? 0).toInt(),liked:j['liked']==true,parentId:j['parent_id']?.toString());
}

class SardNews {
  const SardNews({required this.id,required this.title,required this.body,required this.createdAt,
    this.category='أخبار',this.image});
  final String id,title,body,createdAt,category;
  final String? image;
  factory SardNews.fromJson(Map<String,dynamic> j)=>SardNews(
    id:'${j['id']}',title:'${j['title'] ?? ''}',body:'${j['body'] ?? j['content'] ?? ''}',
    createdAt:'${j['created_at'] ?? ''}',category:'${j['category'] ?? 'أخبار'}',image:j['image'] as String?);
}

class SardNotification {
  const SardNotification({required this.id,required this.title,required this.body,
    required this.createdAt,this.seriesId,this.chapter,this.read=false});
  final String id,title,body,createdAt;
  final String? seriesId;
  final int? chapter;
  final bool read;
  factory SardNotification.fromJson(Map<String,dynamic> j)=>SardNotification(
    id:'${j['id']}',title:'${j['title'] ?? 'فصل جديد'}',body:'${j['body'] ?? ''}',
    createdAt:'${j['created_at'] ?? ''}',seriesId:j['series_id']?.toString(),
    chapter:(j['chapter'] as num?)?.toInt(),read:j['read']==true);
}


/// التفاعلات الخمسة (رسوماتها SVG في widgets/reaction_icons.dart)
enum SardReaction {
  like('like', 'إعجاب'),
  love('love', 'أحببته'),
  laugh('laugh', 'أضحكني'),
  wow('wow', 'مذهل'),
  sad('sad', 'أحزنني');

  const SardReaction(this.key, this.label);
  final String key;
  final String label;

  static SardReaction? fromKey(dynamic v) {
    final t = '${v ?? ''}'.trim().toLowerCase();
    for (final r in SardReaction.values) {
      if (r.key == t) return r;
    }
    return null;
  }
}

/// خيار في استفتاء
class SardPollOption {
  const SardPollOption({required this.id, required this.text, this.votes = 0});
  final String id, text;
  final int votes;

  SardPollOption copyWith({int? votes}) => SardPollOption(id: id, text: text, votes: votes ?? this.votes);

  factory SardPollOption.fromJson(Map<String, dynamic> j) => SardPollOption(
        id: '${j['id']}',
        text: '${j['text'] ?? j['label'] ?? ''}',
        votes: (j['votes'] as num? ?? 0).toInt(),
      );
}

/// استفتاء مرفق بمنشور (من 2 إلى 5 خيارات)
class SardPoll {
  const SardPoll({required this.question, required this.options, this.myVote});
  final String question;
  final List<SardPollOption> options;

  /// معرّف الخيار الذي صوّتُّ له (null = لم أصوّت)
  final String? myVote;

  int get totalVotes => options.fold<int>(0, (a, o) => a + o.votes);

  /// يغيّر تصويتي (أو يسحبه إن ضغطت نفس الخيار) ويعدّل العدّادات
  SardPoll withVote(String? optionId) {
    final next = optionId == myVote ? null : optionId;
    final opts = options.map((o) {
      var v = o.votes;
      if (o.id == myVote) v -= 1;
      if (o.id == next) v += 1;
      return o.copyWith(votes: v < 0 ? 0 : v);
    }).toList();
    return SardPoll(question: question, options: opts, myVote: next);
  }

  factory SardPoll.fromJson(Map<String, dynamic> j) => SardPoll(
        question: '${j['question'] ?? ''}',
        options: ((j['options'] as List?) ?? const [])
            .whereType<Map>()
            .map((e) => SardPollOption.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        myVote: (j['my_vote'] ?? j['voted'])?.toString(),
      );
}

/// منشور في صفحة «المنشورات»: نص + صور + استفتاء + تفاعلات + تعليقات
class SardPost {
  const SardPost({
    required this.id,
    required this.author,
    required this.body,
    required this.createdAt,
    this.tag = '',
    this.comments = 0,
    this.authorId = '',
    this.badge = SardBadge.none,
    this.images = const [],
    this.poll,
    this.reactions = const {},
    this.myReaction,
  });
  final String id, author, body, createdAt, tag, authorId;
  final int comments;
  final SardBadge badge;

  /// روابط (http) أو مسارات ملفات محلية
  final List<String> images;
  final SardPoll? poll;
  final Map<SardReaction, int> reactions;
  final SardReaction? myReaction;

  int get likes => reactions.values.fold<int>(0, (a, b) => a + b);
  bool get liked => myReaction != null;

  /// أكثر التفاعلات حضوراً (للعرض المصغّر)
  List<SardReaction> get topReactions {
    final l = reactions.entries.where((e) => e.value > 0).toList()..sort((a, b) => b.value.compareTo(a.value));
    return l.take(3).map((e) => e.key).toList();
  }

  /// يضع تفاعلي بالضبط (null = سحب التفاعل) ويعدّل العدّادات
  SardPost react(SardReaction? r) {
    final next = r;
    final m = Map<SardReaction, int>.from(reactions);
    if (myReaction != null) m[myReaction!] = ((m[myReaction!] ?? 1) - 1).clamp(0, 1 << 30).toInt();
    if (next != null) m[next] = (m[next] ?? 0) + 1;
    return SardPost(
      id: id, author: author, body: body, createdAt: createdAt, tag: tag, comments: comments,
      authorId: authorId, badge: badge, images: images, poll: poll, reactions: m, myReaction: next,
    );
  }

  SardPost copyWith({int? comments, SardPoll? poll}) => SardPost(
        id: id, author: author, body: body, createdAt: createdAt, tag: tag,
        comments: comments ?? this.comments,
        authorId: authorId, badge: badge, images: images,
        poll: poll ?? this.poll,
        reactions: reactions, myReaction: myReaction,
      );

  factory SardPost.fromJson(Map<String, dynamic> j) {
    final rx = <SardReaction, int>{};
    final raw = j['reactions'];
    if (raw is Map) {
      raw.forEach((k, v) {
        final r = SardReaction.fromKey(k);
        if (r != null) rx[r] = (v as num? ?? 0).toInt();
      });
    } else if (j['likes'] is num) {
      rx[SardReaction.like] = (j['likes'] as num).toInt();
    }
    return SardPost(
      id: '${j['id']}',
      author: '${j['author'] ?? 'قارئ'}',
      body: '${j['body'] ?? j['text'] ?? ''}',
      createdAt: '${j['created_at'] ?? ''}',
      tag: '${j['tag'] ?? ''}',
      comments: (j['comments'] as num? ?? 0).toInt(),
      authorId: '${j['author_id'] ?? j['user_id'] ?? ''}',
      badge: SardBadge.fromJson(j['badge'] ?? j['verified']),
      images: ((j['images'] as List?) ?? const []).map((e) => e is Map ? '${e['url']}' : '$e').toList(),
      poll: j['poll'] is Map ? SardPoll.fromJson(Map<String, dynamic>.from(j['poll'] as Map)) : null,
      reactions: rx,
      myReaction: SardReaction.fromKey(j['my_reaction']) ?? (j['liked'] == true ? SardReaction.like : null),
    );
  }
}

/// محادثة (عنصر في قائمة المحادثات)
class SardChat {
  const SardChat({
    required this.id,
    required this.name,
    required this.lastMessage,
    required this.time,
    this.unread = 0,
    this.userId = '',
    this.badge = SardBadge.none,
  });
  final String id, name, lastMessage, time, userId;
  final int unread;
  final SardBadge badge;

  factory SardChat.fromJson(Map<String, dynamic> j) => SardChat(
        id: '${j['id']}',
        name: '${j['name'] ?? 'قارئ'}',
        lastMessage: '${j['last_message'] ?? ''}',
        time: '${j['time'] ?? j['updated_at'] ?? ''}',
        unread: (j['unread'] as num? ?? 0).toInt(),
        userId: '${j['user_id'] ?? j['author_id'] ?? ''}',
        badge: SardBadge.fromJson(j['badge'] ?? j['verified']),
      );
}

/// رسالة داخل محادثة
class SardChatMessage {
  const SardChatMessage({
    required this.id,
    required this.text,
    required this.mine,
    required this.time,
  });
  final String id, text, time;
  final bool mine;

  factory SardChatMessage.fromJson(Map<String, dynamic> j) => SardChatMessage(
        id: '${j['id']}',
        text: '${j['text'] ?? j['body'] ?? ''}',
        mine: j['mine'] == true,
        time: '${j['created_at'] ?? j['time'] ?? ''}',
      );
}

/// غرفة قراءة مشتركة: صديقان يقرآن الفصل نفسه، ويرى كل منهما موضع الآخر.
/// الدردشة داخل الغرفة هي محادثة عادية معرّفها [chatId] (نظام المحادثات نفسه).
class SardReadRoom {
  const SardReadRoom({
    required this.id,
    required this.chatId,
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.friendId,
    required this.friendName,
    this.friendBadge = SardBadge.none,
    this.friendChapter = 0,
    this.friendPage = 0,
    this.friendTotal = 0,
    this.friendOnline = false,
  });

  final String id, chatId, seriesId, seriesTitle, friendId, friendName;

  /// الفصل الذي أنشئت عليه الغرفة
  final int chapter;
  final SardBadge friendBadge;

  /// موضع الصديق الحالي (0 = لم يبدأ/غير معروف)
  final int friendChapter, friendPage, friendTotal;
  final bool friendOnline;

  bool get friendKnown => friendChapter > 0 && friendPage > 0;

  SardReadRoom copyWith({int? friendChapter, int? friendPage, int? friendTotal, bool? friendOnline}) => SardReadRoom(
        id: id,
        chatId: chatId,
        seriesId: seriesId,
        seriesTitle: seriesTitle,
        chapter: chapter,
        friendId: friendId,
        friendName: friendName,
        friendBadge: friendBadge,
        friendChapter: friendChapter ?? this.friendChapter,
        friendPage: friendPage ?? this.friendPage,
        friendTotal: friendTotal ?? this.friendTotal,
        friendOnline: friendOnline ?? this.friendOnline,
      );

  static int _i(dynamic v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}') ?? 0;

  factory SardReadRoom.fromJson(Map<String, dynamic> j) {
    final id = '${j['id']}';
    final f = j['friend'] is Map ? Map<String, dynamic>.from(j['friend'] as Map) : const <String, dynamic>{};
    final pos = f['position'] is Map ? Map<String, dynamic>.from(f['position'] as Map) : const <String, dynamic>{};
    return SardReadRoom(
      id: id,
      chatId: '${j['chat_id'] ?? 'room_$id'}',
      seriesId: '${j['series_id'] ?? ''}',
      seriesTitle: '${j['series_title'] ?? ''}',
      chapter: _i(j['chapter']),
      friendId: '${f['id'] ?? j['friend_id'] ?? ''}',
      friendName: '${f['name'] ?? j['friend_name'] ?? 'قارئ'}',
      friendBadge: SardBadge.fromJson(f['badge'] ?? j['friend_badge']),
      friendChapter: _i(pos['chapter'] ?? j['friend_chapter']),
      friendPage: _i(pos['page'] ?? j['friend_page']),
      friendTotal: _i(pos['total'] ?? j['friend_total']),
      friendOnline: (f['online'] ?? j['friend_online']) == true,
    );
  }
}

// ───────── التوثيقات والملفات الشخصية ─────────

/// أنواع التوثيق. غيّر المعنى/الاسم هنا فقط وسيتحدّث في كل التطبيق.
///   بنفسجي = فريق Senok · أزرق = حساب موثّق · أصفر = مترجم معتمد
enum SardBadge {
  none('', ''),
  purple('فريق Senok', 'حساب رسمي من فريق Senok (إدارة ومشرفون).'),
  blue('حساب موثّق', 'حساب تم التحقق من هويته وأصالته.'),
  yellow('مترجم معتمد', 'مترجم أو ناشر معتمد يساهم بفصول في Senok.');

  const SardBadge(this.label, this.description);
  final String label;
  final String description;

  bool get isNone => this == SardBadge.none;

  /// يقبل السيرفر: "purple" / "blue" / "yellow" أو بالعربية، أو true (= أزرق).
  static SardBadge fromJson(dynamic v) {
    if (v == true) return SardBadge.blue;
    final t = '${v ?? ''}'.trim().toLowerCase();
    switch (t) {
      case 'purple':
      case 'violet':
      case 'بنفسجي':
        return SardBadge.purple;
      case 'blue':
      case 'verified':
      case 'أزرق':
        return SardBadge.blue;
      case 'yellow':
      case 'gold':
      case 'أصفر':
        return SardBadge.yellow;
    }
    return SardBadge.none;
  }

  String get key => name;
}

/// ترشيح مانهوا/مانغا من مستخدم (العمل + ملاحظته)
class SardRecommendation {
  const SardRecommendation({required this.series, this.note = ''});
  final Series series;
  final String note;

  factory SardRecommendation.fromJson(Map<String, dynamic> j) {
    final raw = j['series'] is Map ? Map<String, dynamic>.from(j['series'] as Map) : j;
    return SardRecommendation(series: Series.fromJson(raw), note: '${j['note'] ?? j['reason'] ?? ''}');
  }
}

/// الملف الشخصي العام لأي مستخدم
class SardUserProfile {
  const SardUserProfile({
    required this.id,
    required this.name,
    this.avatarUrl = '',
    this.bio = '',
    this.joined = '',
    this.badge = SardBadge.none,
    this.chaptersRead = 0,
    this.readingSeconds = 0,
    this.recommendations = const [],
    this.posts = const [],
  });

  final String id, name, avatarUrl, bio, joined;
  final SardBadge badge;
  final int chaptersRead;
  final int readingSeconds;
  final List<SardRecommendation> recommendations;
  final List<SardPost> posts;

  factory SardUserProfile.fromJson(Map<String, dynamic> j) {
    List<Map<String, dynamic>> maps(dynamic v) =>
        ((v as List?) ?? const []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    return SardUserProfile(
      id: '${j['id'] ?? ''}',
      name: '${j['name'] ?? j['username'] ?? 'قارئ'}',
      avatarUrl: '${j['avatar_url'] ?? j['image'] ?? ''}',
      bio: '${j['bio'] ?? ''}',
      joined: '${j['joined'] ?? j['created_at'] ?? ''}',
      badge: SardBadge.fromJson(j['badge'] ?? j['verified']),
      chaptersRead: (j['chapters_read'] as num?)?.toInt() ?? 0,
      readingSeconds: (j['reading_seconds'] as num?)?.toInt() ??
          (((j['reading_hours'] as num?) ?? 0) * 3600).round(),
      recommendations: maps(j['recommendations'] ?? j['recommended']).map(SardRecommendation.fromJson).toList(),
      posts: maps(j['posts']).map(SardPost.fromJson).toList(),
    );
  }
}

/// 12300 ثانية -> "3 س 25 د"
String formatReadingTime(int seconds) {
  if (seconds < 60) return seconds <= 0 ? '0 د' : 'أقل من دقيقة';
  final h = seconds ~/ 3600;
  final m = (seconds % 3600) ~/ 60;
  if (h == 0) return '$m د';
  if (m == 0) return '$h س';
  return '$h س $m د';
}

/// عدد الساعات بالكسر: "3.4"
String readingHoursLabel(int seconds) => (seconds / 3600).toStringAsFixed(1);
