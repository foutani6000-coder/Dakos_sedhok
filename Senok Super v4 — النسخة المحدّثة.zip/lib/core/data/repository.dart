import '../config/app_config.dart';
import 'api_client.dart';
import 'mock_data.dart';
import 'models.dart';
import 'search_filters.dart';

/// طبقة البيانات الوحيدة. الواجهات لا تتكلم مع السيرفر مباشرة.
///
/// العقد المتوقع من السيرفر (عدّله هنا فقط):
///   GET /home                      -> {featured:[], suggestions:[], latest:[], popular:[]}
///   GET /search?q=&type=&sort=     -> [Series]
///   GET /series/{id}/chapters      -> [Chapter]
///   GET /series/{id}/chapters/{n}/pages -> ["url", ...] أو [{url, low}, ...] أو {pages:[...]}
class SardRepository {
  SardRepository({ApiClient? api}) : api = api ?? ApiClient();
  final ApiClient api;

  bool get mock => AppConfig.useMock;

  Future<void> _delay() => Future<void>.delayed(const Duration(milliseconds: 700));

  List<Series> _series(dynamic list) => ((list as List?) ?? const [])
      .map((e) => Series.fromJson(e as Map<String, dynamic>))
      .toList();

  Future<HomeData> home() async {
    if (mock) {
      await _delay();
      return MockData.home();
    }
    final j = await api.get('/home') as Map<String, dynamic>;
    return HomeData(
      featured: _series(j['featured']),
      suggestions: _series(j['suggestions']),
      latest: _series(j['latest']),
      popular: _series(j['popular']),
    );
  }

  Future<List<Series>> search(String q, {String type = '', String sort = 'new'}) async {
    if (mock) {
      await Future<void>.delayed(const Duration(milliseconds: 400));
      return MockData.search(q, type, sort);
    }
    final j = await api.get('/search', query: {'q': q, 'type': type, 'sort': sort});
    return _series(j);
  }

  Future<List<Series>> advancedSearch(String q, {List<String> genres = const [], String status = '', String year = '', List<String> exclude = const [], String type = '', String sort = 'new'}) async {
    if (mock) {
      final all = await search(q, type: type, sort: sort);
      return all.where((s) => (status.isEmpty || s.status == status) &&
        (genres.isEmpty || genres.every(s.genres.contains)) &&
        (year.isEmpty || s.year.toString() == year) && !exclude.any((g) => s.genres.contains(g))).toList();
    }
    final j = await api.get('/search', query: {'q': q, 'type': type, 'sort': sort,
      'genres': genres.join(','), 'status': status, 'year': year, 'exclude': exclude.join(',')});
    return _series(j is Map ? (j['results'] ?? j['items'] ?? []) : j);
  }

  /// بحث متقدم بمجموعة فلاتر كاملة (النوع، الفصول، التقييم، السنة...).
  Future<List<Series>> searchFiltered(String q, SearchFilters f) async {
    if (mock) {
      final all = await search(q);
      return f.apply(all);
    }
    final j = await api.get('/search', query: f.toQuery(q));
    return f.apply(_series(j is Map ? (j['results'] ?? j['items'] ?? []) : j));
  }

  Future<void> rateSeries(String id, int rating) async {
    if (rating < 1 || rating > 10) throw ArgumentError('التقييم يجب أن يكون من 1 إلى 10');
    if (mock) { _mockRatings[id] = rating; return; }
    await api.post('/series/$id/rating', body: {'rating': rating});
  }

  Future<List<Series>> section(String section, {int page = 1, int limit = 20}) async {
    if (mock) {
      final h = await home();
      final items = section == 'featured' ? h.featured : section == 'latest' ? h.latest : section == 'suggestions' ? h.suggestions : h.popular;
      final start = (page - 1) * limit;
      return start >= items.length ? [] : items.skip(start).take(limit).toList();
    }
    final j = await api.get('/catalog/$section', query: {'page': '$page', 'limit': '$limit'});
    return _series(j is Map ? (j['items'] ?? j['results'] ?? []) : j);
  }

  Future<List<Series>> category(String genre, {int page = 1, int limit = 20}) async {
    if (mock) {
      final h = await home();
      final all = [...h.featured, ...h.suggestions, ...h.latest, ...h.popular];
      final items = all.where((s) => s.genres.contains(genre)).toList();
      final start = (page - 1) * limit;
      return start >= items.length ? [] : items.skip(start).take(limit).toList();
    }
    final j = await api.get('/genres/${Uri.encodeComponent(genre)}', query: {'page': '$page', 'limit': '$limit'});
    return _series(j is Map ? (j['items'] ?? j['results'] ?? []) : j);
  }

  Future<Map<String, dynamic>> fetchProfile() async {
    final j = await api.get('/users/me');
    return j is Map ? Map<String, dynamic>.from(j['user'] is Map ? j['user'] : j) : {};
  }

  Future<List<Chapter>> chapters(Series s) async {
    if (mock) {
      await Future<void>.delayed(const Duration(milliseconds: 350));
      return MockData.chaptersFor(s);
    }
    try {
      final j = await api.get('/series/${s.id}/chapters');
      // قائمة خام أو داخل مفتاح (chapters/items/data/results)
      final raw = j is List
          ? j
          : (j is Map ? (j['chapters'] ?? j['items'] ?? j['data'] ?? j['results']) : null);
      if (raw is! List) {
        throw ApiException('Invalid chapters response', failure: ApiFailure.invalidResponse);
      }
      final list = raw
          .whereType<Map>()
          .map((e) => Chapter.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      if (list.isEmpty && AppConfig.demoFallback) return MockData.chaptersFor(s);
      return list;
    } catch (_) {
      if (AppConfig.demoFallback) return MockData.chaptersFor(s);
      rethrow;
    }
  }

  /// صفحات الفصل بالترتيب. `low` اختياري (نسخة مخفّضة لتوفير البيانات).
  Future<List<PageSrc>> pages(String seriesId, int chapter) async {
    if (mock) {
      await Future<void>.delayed(const Duration(milliseconds: 450));
      return MockData.pagesFor(seriesId, chapter);
    }
    try {
      final j = await api.get('/series/$seriesId/chapters/$chapter/pages');
      final raw = j is Map ? (j['pages'] ?? j['images'] ?? j['items'] ?? j['data']) : j;
      final list = raw is List ? raw : const [];
      final pages = list.map(PageSrc.fromJson).where((p) => p.url.isNotEmpty).toList();
      if (pages.isEmpty && AppConfig.demoFallback) return MockData.pagesFor(seriesId, chapter);
      return pages;
    } catch (_) {
      if (AppConfig.demoFallback) return MockData.pagesFor(seriesId, chapter);
      rethrow;
    }
  }
}


// ───────── المجتمع والتعليقات والإشعارات (20–25) ─────────
final Map<String, List<SardComment>> _mockComments = {};

/// تعليقات تجريبية بتوثيقات مختلفة (وضع بدون سيرفر)
List<SardComment> _seedComments(String seriesId) => [
      SardComment(id: '${seriesId}_c1', seriesId: seriesId, author: 'نورا القارئة', authorId: 'u_nora', badge: SardBadge.purple,
          text: 'من أجمل ما قرأت هذا العام، أنصح به بشدة.', createdAt: 'قبل ساعة', likes: 12),
      SardComment(id: '${seriesId}_c2', seriesId: seriesId, author: 'أبو ياسر', authorId: 'u_yaser', badge: SardBadge.blue,
          text: 'الرسم والحبكة متوازنان، والفصول الأخيرة ممتازة.', createdAt: 'قبل 3 ساعات', likes: 7),
      SardComment(id: '${seriesId}_c3', seriesId: seriesId, author: 'ليلى', authorId: 'u_layla', badge: SardBadge.yellow,
          text: 'أعمل على ترجمة فصول جديدة قريباً بإذن الله.', createdAt: 'أمس', likes: 5),
      SardComment(id: '${seriesId}_c4', seriesId: seriesId, author: 'سيف', authorId: 'u_saif',
          text: 'هل أكمله أم أنتظر المزيد من الفصول؟', createdAt: 'أمس', likes: 1),
    ];
extension SardCommunityRepository on SardRepository {
  Future<List<SardComment>> comments(String seriesId) async {
    if (mock) return List.unmodifiable(_mockComments.putIfAbsent(seriesId, () => _seedComments(seriesId)));
    final j=await api.get('/series/$seriesId/comments');
    return ((j is Map ? j['comments'] : j) as List? ?? const [])
      .map((e)=>SardComment.fromJson(Map<String,dynamic>.from(e as Map))).toList();
  }
  Future<SardComment?> addComment(String seriesId,String text,{String? parentId}) async {
    if (mock) {
      final item=SardComment(id:'local_${DateTime.now().millisecondsSinceEpoch}',
        seriesId:seriesId,author:'أنت',text:text,createdAt:'الآن',parentId:parentId);
      (_mockComments[seriesId] ??= []).insert(0,item);
      return item;
    }
    final j=await api.post('/series/$seriesId/comments',body:{'text':text,'parent_id':parentId});
    return j is Map ? SardComment.fromJson(Map<String,dynamic>.from(j)) : null;
  }
  Future<void> likeComment(String seriesId,String commentId) async {
    if (mock) {
      final list=_mockComments[seriesId] ?? [];
      final i=list.indexWhere((e)=>e.id==commentId);
      if(i>=0) { final c=list[i]; list[i]=SardComment(id:c.id,seriesId:c.seriesId,author:c.author,authorId:c.authorId,badge:c.badge,text:c.text,createdAt:c.createdAt,likes:c.likes+1,liked:true,parentId:c.parentId); }
      return;
    }
    await api.post('/series/$seriesId/comments/$commentId/like');
  }
  Future<List<SardNews>> news() async {
    final j=await api.get('/news');
    return ((j is Map ? j['news'] : j) as List? ?? const [])
      .map((e)=>SardNews.fromJson(Map<String,dynamic>.from(e as Map))).toList();
  }
  Future<SardNews> newsDetail(String id) async {
    final j=await api.get('/news/$id');
    return SardNews.fromJson(Map<String,dynamic>.from(j is Map && j['news'] is Map ? j['news'] : j));
  }
  Future<List<SardNotification>> notifications(List<String> followedIds) async {
    if (followedIds.isEmpty) return const [];
    final j=await api.get('/notifications',query:{'series_ids':followedIds.join(',')});
    return ((j is Map ? j['notifications'] : j) as List? ?? const [])
      .map((e)=>SardNotification.fromJson(Map<String,dynamic>.from(e as Map))).toList();
  }
}

final Map<String, int> _mockRatings = {};


extension SardRelatedRepository on SardRepository {
  Future<List<Series>> related(Series series, {int limit = 12}) async {
    if (mock) {
      final all = MockData.all.where((s) => s.id != series.id && s.genres.any(series.genres.contains)).toList();
      return all.take(limit).toList();
    }
    final j = await api.get('/series/${series.id}/related', query: {'limit': '$limit'});
    return _series(j is Map ? (j['items'] ?? j['results'] ?? []) : j);
  }
}
