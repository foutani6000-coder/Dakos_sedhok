import 'models.dart';

/// بيانات تجريبية تُستعمل عندما يكون API_BASE_URL فارغاً.
class MockData {
  MockData._();

  static const List<Series> all = [
    Series(
      id: 'm1',
      title: 'The Last Ink Knight',
      type: 'مانهوا كورية',
      chapters: 115,
      rating: 9.5,
      views: 1250000,
      genres: ['أكشن', 'فانتازيا', 'مغامرات'],
      synopsis:
          'فارس منسيّ يستيقظ بعد قرنٍ من الحبر والدم، ليكتشف أن مملكته كُتبت من جديد بيد عدوه. عليه أن يمحو السطور التي لا تخصّه قبل أن تمحوه.',
    ),
    Series(
      id: 'm2',
      title: 'Moonlit Mercenary',
      type: 'مانهوا كورية',
      chapters: 73,
      rating: 9.1,
      views: 842000,
      genres: ['أكشن', 'غموض'],
      synopsis:
          'مرتزق لا ينام إلا تحت ضوء القمر، وكل عقد يوقّعه يقرّبه أكثر من سرٍّ دفنه أسياده القدامى.',
    ),
    Series(
      id: 'm3',
      title: 'Crown of Ash',
      type: 'مانغا يابانية',
      chapters: 182,
      rating: 8.8,
      views: 2100000,
      genres: ['دراما', 'فانتازيا', 'انتقام'],
      synopsis:
          'حين احترق العرش لم يبقَ منه سوى رمادٍ يحمل اسم وريثٍ واحد. رحلة طويلة نحو تاجٍ لم يعد أحد يريده.',
    ),
    Series(
      id: 'm4',
      title: 'Rebirth of the Silent Blade',
      type: 'مانهوا صينية',
      chapters: 240,
      rating: 8.4,
      views: 3400000,
      genres: ['أكشن', 'فنون قتالية'],
      synopsis:
          'سيّاف صامت يعود إلى لحظة هزيمته الأولى بذكريات حياةٍ كاملة، وسيفٍ لم يتعلّم الكلام بعد.',
    ),
    Series(
      id: 'm5',
      title: 'Tower of Echoes',
      type: 'مانهوا كورية',
      chapters: 24,
      rating: 7.0,
      views: 96000,
      isNew: true,
      genres: ['مغامرات', 'خيال علمي'],
      synopsis:
          'برجٌ يردّد أصداء من صعدوه قبلهم. كل طابق يسأل سؤالاً واحداً: من تكون حين لا يسمعك أحد؟',
    ),
    Series(
      id: 'm6',
      title: 'Velvet Dungeon',
      type: 'مانهوا كورية',
      chapters: 74,
      rating: 8.2,
      views: 410000,
      isNew: true,
      genres: ['رومانسي', 'فانتازيا'],
      synopsis:
          'قبو قديم تحت قصر الدوق يخبّئ بابًا لا يُفتح إلا لمن يعرف اسمه الحقيقي.',
    ),
    Series(
      id: 'm7',
      title: 'Night Cartographer',
      type: 'مانغا يابانية',
      chapters: 56,
      status: 'مكتمل',
      rating: 9.26,
      views: 276000,
      genres: ['غموض', 'دراما'],
      synopsis:
          'رسّام خرائط يرسم مدنًا لا وجود لها، إلى أن بدأت المدن ترسم نفسها على جدران بيته.',
    ),
    Series(
      id: 'm8',
      title: 'Iron Sakura',
      type: 'مانغا يابانية',
      chapters: 91,
      rating: 8.9,
      views: 735000,
      genres: ['أكشن', 'دراما'],
      synopsis:
          'في مدينة من فولاذ، شجرة ساكورا وحيدة ما زالت تزهر. ومن يحرسها يعرف أن الربيع له ثمن.',
    ),
    Series(
      id: 'm9',
      title: 'Hollow Throne Protocol',
      type: 'مانهوا صينية',
      chapters: 14,
      rating: 6.8,
      views: 38000,
      isNew: true,
      genres: ['خيال علمي', 'إثارة'],
      synopsis:
          'نظام قديم يختار حاكماً كل عشر سنوات، وهذا العام اختار شخصاً لم يطلب العرش قط.',
    ),
    Series(
      id: 'm10',
      title: 'Whisper of the Lantern Girl',
      type: 'مانهوا كورية',
      chapters: 48,
      rating: 8.0,
      views: 188000,
      genres: ['رومانسي', 'غموض'],
      synopsis:
          'فتاة تحمل فانوساً لا يضيء إلا حين يقترب الكذب. وكل من حولها يعرف ذلك.',
    ),
  ];

  static HomeData home() {
    final byViews = [...all]..sort((a, b) => b.views.compareTo(a.views));
    final fresh = [...all]..sort((a, b) => (b.isNew ? 1 : 0).compareTo(a.isNew ? 1 : 0));
    return HomeData(
      featured: all.take(5).toList(),
      suggestions: [...all.reversed],
      latest: fresh,
      popular: byViews,
    );
  }

  static List<Series> search(String q, String type, String sort) {
    final query = q.toLowerCase();
    final l = all
        .where((s) =>
            (query.isEmpty || s.title.toLowerCase().contains(query)) &&
            (type.isEmpty || s.type == type))
        .toList();
    if (sort == 'views') {
      l.sort((a, b) => b.views.compareTo(a.views));
    } else if (sort == 'rating') {
      l.sort((a, b) => b.rating.compareTo(a.rating));
    } else {
      l.sort((a, b) => (b.isNew ? 1 : 0).compareTo(a.isNew ? 1 : 0));
    }
    return l;
  }

  static List<Chapter> chaptersFor(Series s) {
    return List.generate(s.chapters, (i) {
      final n = s.chapters - i;
      String date;
      if (i == 0) {
        date = 'قبل ساعتين';
      } else if (i < 9) {
        date = '2026/11/${(20 - i).toString().padLeft(2, '0')}';
      } else {
        date = '2026/10/${(28 - (i % 27)).toString().padLeft(2, '0')}';
      }
      return Chapter(
        number: n,
        title: 'فصل $n',
        pages: 14 + (n * 7) % 11,
        date: date,
        isNew: i == 0,
      );
    });
  }

  /// صفحات فصل تجريبية: روابط وهمية تُرسم محلياً (انظر widgets/mock_page.dart)
  static List<PageSrc> pagesFor(String seriesId, int chapter) {
    final count = 14 + (chapter * 7) % 11;
    final base = seriesId.codeUnits.fold<int>(11, (a, b) => a * 31 + b) & 0xffff;
    return List.generate(
      count,
      (i) => PageSrc('mock:${base + chapter * 97}:${i + 1}:$count'),
    );
  }
}
