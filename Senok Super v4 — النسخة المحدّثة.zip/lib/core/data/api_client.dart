import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../storage/auth_store.dart';
import 'local_backend.dart';

enum ApiFailure { offline, timeout, unauthorized, forbidden, notFound, server, invalidResponse, unknown }

/// خطأ موحّد قابل للعرض للمستخدم بدلاً من تفاصيل HTTP الخام.
class ApiException implements Exception {
  ApiException(this.message, {this.failure = ApiFailure.unknown, this.statusCode});
  final String message;
  final ApiFailure failure;
  final int? statusCode;

  String get userMessage => switch (failure) {
    ApiFailure.offline => 'لا يوجد اتصال بالإنترنت. تحقق من الشبكة وحاول مجدداً.',
    ApiFailure.timeout => 'استغرق الاتصال وقتاً طويلاً. حاول مرة أخرى.',
    ApiFailure.unauthorized => 'انتهت جلسة الدخول. سجّل الدخول مجدداً.',
    ApiFailure.forbidden => 'ليست لديك صلاحية لتنفيذ هذا الإجراء.',
    ApiFailure.notFound => 'المحتوى المطلوب غير موجود.',
    ApiFailure.server => 'الخادم يواجه مشكلة مؤقتة. حاول لاحقاً.',
    ApiFailure.invalidResponse => 'وصل رد غير صالح من الخادم.',
    ApiFailure.unknown => message,
  };

  @override
  String toString() => userMessage;

  factory ApiException.fromStatus(int code) => ApiException(
    'HTTP $code', statusCode: code,
    failure: switch (code) {
      401 => ApiFailure.unauthorized,
      403 => ApiFailure.forbidden,
      404 => ApiFailure.notFound,
      >= 500 => ApiFailure.server,
      _ => ApiFailure.unknown,
    },
  );
}

/// عميل HTTP موحّد. كل الاتصالات تمر من هنا، والرابط من AppConfig فقط.
class ApiClient {
  static const Duration _timeout = Duration(seconds: 15);

  Future<Map<String, String>> _headers({bool json = false}) async {
    final headers = <String, String>{'Accept': 'application/json'};
    if (json) headers['Content-Type'] = 'application/json';
    final token = await AuthStore.token();
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    } else if (AppConfig.apiKey.isNotEmpty) {
      headers['Authorization'] = 'Bearer ${AppConfig.apiKey}';
    }
    return headers;
  }

  Future<dynamic> _decode(http.Response response) async {
    if (response.statusCode >= 400) throw ApiException.fromStatus(response.statusCode);
    if (response.bodyBytes.isEmpty) return null;
    try {
      return jsonDecode(utf8.decode(response.bodyBytes));
    } on FormatException {
      throw ApiException('Invalid JSON response', failure: ApiFailure.invalidResponse);
    }
  }

  Future<T> _guard<T>(Future<T> Function() action, {Duration? timeout}) async {
    try {
      return await action().timeout(timeout ?? _timeout);
    } on ApiException {
      rethrow;
    } on TimeoutException {
      throw ApiException('Request timed out', failure: ApiFailure.timeout);
    } on SocketException {
      throw ApiException('Network unavailable', failure: ApiFailure.offline);
    } on http.ClientException {
      throw ApiException('Network unavailable', failure: ApiFailure.offline);
    } on FormatException {
      throw ApiException('Invalid response', failure: ApiFailure.invalidResponse);
    }
  }

  Future<dynamic> get(String path, {Map<String, String>? query}) {
    if (AppConfig.useMock) return LocalBackend.handle('GET', path, query: query);
    return _guard(() async {
      final uri = Uri.parse('${AppConfig.apiBaseUrl}$path').replace(
        queryParameters: (query == null || query.isEmpty) ? null : query,
      );
      final response = await http.get(uri, headers: await _headers());
      return _decode(response);
    });
  }

  /// رفع ملفات (صور) مع حقول نصية. [files]: اسم الحقل -> مسارات ملفات محلية.
  Future<dynamic> postMultipart(String path, {Map<String, String> fields = const {}, Map<String, List<String>> files = const {}}) {
    if (AppConfig.useMock) return LocalBackend.handle('POST', path, body: fields);
    return _guard(() async {
      final req = http.MultipartRequest('POST', Uri.parse('${AppConfig.apiBaseUrl}$path'));
      req.headers.addAll(await _headers());
      req.fields.addAll(fields);
      for (final e in files.entries) {
        for (final f in e.value) {
          req.files.add(await http.MultipartFile.fromPath(e.key, f));
        }
      }
      final response = await http.Response.fromStream(await req.send());
      return _decode(response);
    }, timeout: const Duration(seconds: 90));
  }

  Future<dynamic> post(String path, {Object? body}) {
    if (AppConfig.useMock) return LocalBackend.handle('POST', path, body: body);
    return _guard(() async {
      final uri = Uri.parse('${AppConfig.apiBaseUrl}$path');
      final response = await http.post(uri, headers: await _headers(json: true), body: jsonEncode(body ?? {}));
      return _decode(response);
    });
  }
}
