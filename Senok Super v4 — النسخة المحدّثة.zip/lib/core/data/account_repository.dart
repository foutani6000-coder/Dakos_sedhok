import 'dart:convert';
import 'package:google_sign_in/google_sign_in.dart';
import '../storage/auth_store.dart';
import '../config/app_config.dart';
import '../storage/settings.dart';
import 'api_client.dart';
import 'models.dart';

class AccountRepository {
  AccountRepository(this.api);
  final ApiClient api;
  late final GoogleSignIn _google = GoogleSignIn(
    scopes: ['email', 'profile'],
    serverClientId: AppConfig.googleServerClientId.isEmpty ? null : AppConfig.googleServerClientId,
  );

  Future<Map<String, dynamic>> _accept(dynamic value) async {
    if (value is! Map) throw ApiException('استجابة تسجيل الدخول غير صالحة');
    final map = Map<String, dynamic>.from(value);
    final token = '${map['token'] ?? map['access_token'] ?? ''}';
    if (token.isEmpty) throw ApiException('${map['message'] ?? 'لم يُرجع السيرفر رمز الدخول'}');
    final user = map['user'] is Map ? Map<String, dynamic>.from(map['user']) : <String, dynamic>{};
    await AuthStore.save(token, userJson: jsonEncode(user));
    return user;
  }

  Future<Map<String, dynamic>> signIn(String email, String password) async =>
      _accept(await api.post('/auth/login', body: {'email': email, 'password': password}));

  Future<Map<String, dynamic>> signUp(String name, String email, String password) async =>
      _accept(await api.post('/auth/register', body: {'name': name, 'email': email, 'password': password}));

  Future<void> forgotPassword(String email) async {
    await api.post('/auth/forgot-password', body: {'email': email});
  }

  Future<Map<String, dynamic>> signInGoogle() async {
    if (AppConfig.useMock) return _accept(await api.post('/auth/google', body: {}));
    final account = await _google.signIn();
    if (account == null) throw ApiException('تم إلغاء تسجيل الدخول');
    final auth = await account.authentication;
    final idToken = auth.idToken;
    if (idToken == null || idToken.isEmpty) throw ApiException('تعذر الحصول على رمز Google');
    return _accept(await api.post('/auth/google', body: {'id_token': idToken}));
  }

  Future<void> signOut() async {
    await AuthStore.clear();
    try { await _google.signOut(); } catch (_) {}
  }

  Future<bool> get signedIn async => (await AuthStore.token())?.isNotEmpty == true;
  Future<Map<String, dynamic>> fetchProfile() async {
    final j = await api.get('/users/me');
    final value = j is Map && j['user'] is Map ? j['user'] : j;
    return value is Map ? Map<String, dynamic>.from(value) : await profile;
  }

  Future<void> updateProfile(String name, String avatarUrl, {String bio = ''}) async {
    await api.post('/users/me', body: {'name': name, 'avatar_url': avatarUrl, 'bio': bio});
  }

  /// يحفظ التعديل محلياً أيضاً حتى يعمل بدون حساب/سيرفر
  Future<void> saveProfileLocally(String name, String avatarUrl, {String bio = ''}) async {
    final u = await profile;
    if (name.isNotEmpty) u['name'] = name;
    u['avatar_url'] = avatarUrl;
    u['bio'] = bio;
    final token = await AuthStore.token();
    await AuthStore.save((token == null || token.isEmpty) ? 'local-profile' : token, userJson: jsonEncode(u));
  }

  Future<Map<String, dynamic>> get profile async {
    final raw = await AuthStore.userJson();
    if (raw == null) return {};
    try { return Map<String, dynamic>.from(jsonDecode(raw) as Map); } catch (_) { return {}; }
  }

  Future<Map<String, dynamic>> library() async {
    final j = await api.get('/library');
    return j is Map ? Map<String, dynamic>.from(j) : {};
  }

  Future<void> syncLibrary(SettingsController settings) async {
    final history = <Map<String, dynamic>>[];
    // التقدم محفوظ محلياً؛ نرسل العناصر التي يتيحها SettingsController.
    for (final id in settings.followedSeries) {
      history.add({'series_id': id, 'followed': true});
    }
    await api.post('/library/sync', body: {
      'followed_series': settings.followedSeries.toList(),
      'read_chapters': settings.exportReadChapters(),
      'progress': settings.exportProgress(),
      'reading_seconds': settings.exportReadingSeconds(),
      'recommended': settings.recommendedIds,
      'local_flags': history,
    });
  }

  Future<void> createList(String name, {bool isPublic = false}) async =>
      api.post('/library/lists', body: {'name': name, 'is_public': isPublic});
  Future<void> addToList(String listId, String seriesId) async =>
      api.post('/library/lists/$listId/items', body: {'series_id': seriesId});
}

class LibraryData {
  const LibraryData({this.followed = const [], this.lists = const [], this.history = const []});
  final List<Series> followed;
  final List<Map<String, dynamic>> lists;
  final List<Map<String, dynamic>> history;
  factory LibraryData.fromJson(Map<String, dynamic> j) => LibraryData(
    followed: ((j['followed'] ?? j['following'] ?? []) as List).whereType<Map>().map((e) => Series.fromJson(Map<String, dynamic>.from(e))).toList(),
    lists: ((j['lists'] ?? []) as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(),
    history: ((j['history'] ?? j['reading_history'] ?? []) as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(),
  );
}
