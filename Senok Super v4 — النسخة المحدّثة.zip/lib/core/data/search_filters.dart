import 'models.dart';

/// مجموعة فلاتر البحث المتقدم. غير قابلة للتعديل: كل تغيير ينتج نسخة جديدة.
class SearchFilters {
  const SearchFilters({
    this.types = const {},
    this.genres = const {},
    this.exclude = const {},
    this.matchAllGenres = true,
    this.statuses = const {},
    this.chaptersMin,
    this.chaptersMax,
    this.minRating = 0,
    this.minViews = 0,
    this.yearFrom,
    this.yearTo,
    this.onlyNew = false,
    this.sort = 'new',
  });

  final Set<String> types;
  final Set<String> genres;
  final Set<String> exclude;

  /// true: يجب أن يحوي العمل كل التصنيفات المختارة. false: أي تصنيف منها يكفي.
  final bool matchAllGenres;
  final Set<String> statuses;
  final int? chaptersMin;
  final int? chaptersMax;
  final double minRating;
  final int minViews;
  final int? yearFrom;
  final int? yearTo;
  final bool onlyNew;
  final String sort;

  static const SearchFilters none = SearchFilters();

  static const typeOptions = ['مانهوا كورية', 'مانغا يابانية', 'مانهوا صينية'];
  static const statusOptions = ['مستمر', 'مكتمل', 'متوقف'];
  static const genreOptions = [
    'أكشن',
    'مغامرة',
    'دراما',
    'فانتازيا',
    'خيال علمي',
    'كوميديا',
    'غموض',
    'إثارة',
    'رعب',
    'رومانسي',
    'مدرسي',
    'فنون قتالية',
    'انتقام',
  ];

  /// عدد الفلاتر المفعّلة (بدون الترتيب).
  int get activeCount {
    var n = 0;
    if (types.isNotEmpty) n++;
    if (genres.isNotEmpty) n++;
    if (exclude.isNotEmpty) n++;
    if (statuses.isNotEmpty) n++;
    if (chaptersMin != null || chaptersMax != null) n++;
    if (minRating > 0) n++;
    if (minViews > 0) n++;
    if (yearFrom != null || yearTo != null) n++;
    if (onlyNew) n++;
    return n;
  }

  bool get isActive => activeCount > 0;

  SearchFilters copyWith({
    Set<String>? types,
    Set<String>? genres,
    Set<String>? exclude,
    bool? matchAllGenres,
    Set<String>? statuses,
    int? chaptersMin,
    int? chaptersMax,
    bool clearChapters = false,
    double? minRating,
    int? minViews,
    int? yearFrom,
    int? yearTo,
    bool clearYears = false,
    bool? onlyNew,
    String? sort,
  }) {
    return SearchFilters(
      types: types ?? this.types,
      genres: genres ?? this.genres,
      exclude: exclude ?? this.exclude,
      matchAllGenres: matchAllGenres ?? this.matchAllGenres,
      statuses: statuses ?? this.statuses,
      chaptersMin: clearChapters ? null : (chaptersMin ?? this.chaptersMin),
      chaptersMax: clearChapters ? null : (chaptersMax ?? this.chaptersMax),
      minRating: minRating ?? this.minRating,
      minViews: minViews ?? this.minViews,
      yearFrom: clearYears ? null : (yearFrom ?? this.yearFrom),
      yearTo: clearYears ? null : (yearTo ?? this.yearTo),
      onlyNew: onlyNew ?? this.onlyNew,
      sort: sort ?? this.sort,
    );
  }

  bool matches(Series s) {
    if (types.isNotEmpty && !types.contains(s.type)) return false;
    if (statuses.isNotEmpty && !statuses.contains(s.status)) return false;
    if (genres.isNotEmpty) {
      final ok = matchAllGenres ? genres.every(s.genres.contains) : genres.any(s.genres.contains);
      if (!ok) return false;
    }
    if (exclude.any(s.genres.contains)) return false;
    if (chaptersMin != null && s.chapters < chaptersMin!) return false;
    if (chaptersMax != null && s.chapters > chaptersMax!) return false;
    if (minRating > 0 && s.rating < minRating) return false;
    if (minViews > 0 && s.views < minViews) return false;
    if (yearFrom != null && s.year < yearFrom!) return false;
    if (yearTo != null && s.year > yearTo!) return false;
    if (onlyNew && !s.isNew) return false;
    return true;
  }

  List<Series> apply(List<Series> input) {
    final l = input.where(matches).toList();
    switch (sort) {
      case 'views':
        l.sort((a, b) => b.views.compareTo(a.views));
      case 'rating':
        l.sort((a, b) => b.rating.compareTo(a.rating));
      case 'chapters':
        l.sort((a, b) => b.chapters.compareTo(a.chapters));
      case 'chapters_asc':
        l.sort((a, b) => a.chapters.compareTo(b.chapters));
      case 'year':
        l.sort((a, b) => b.year.compareTo(a.year));
    }
    return l;
  }

  /// وسائط الاستعلام للسيرفر (السيرفر قد يتجاهل ما لا يعرفه، والتصفية تتكرر محلياً).
  Map<String, String> toQuery(String q) => {
        'q': q,
        'type': types.join(','),
        'sort': sort,
        'genres': genres.join(','),
        'exclude': exclude.join(','),
        'genre_mode': matchAllGenres ? 'all' : 'any',
        'status': statuses.length == 1 ? statuses.first : '',
        'chapters_min': chaptersMin?.toString() ?? '',
        'chapters_max': chaptersMax?.toString() ?? '',
        'min_rating': minRating > 0 ? minRating.toString() : '',
        'year_from': yearFrom?.toString() ?? '',
        'year_to': yearTo?.toString() ?? '',
      };

  /// وصف مختصر للفلاتر المفعّلة لعرضها كشرائح قابلة للإزالة.
  List<(String, SearchFilters)> activeChips() {
    final out = <(String, SearchFilters)>[];
    for (final t in types) {
      out.add((t, copyWith(types: {...types}..remove(t))));
    }
    for (final g in genres) {
      out.add((g, copyWith(genres: {...genres}..remove(g))));
    }
    for (final g in exclude) {
      out.add(('بدون $g', copyWith(exclude: {...exclude}..remove(g))));
    }
    for (final st in statuses) {
      out.add((st, copyWith(statuses: {...statuses}..remove(st))));
    }
    if (chaptersMin != null || chaptersMax != null) {
      final label = chaptersMin != null && chaptersMax != null
          ? '${chaptersMin!}–${chaptersMax!} فصل'
          : chaptersMin != null
              ? '${chaptersMin!}+ فصل'
              : 'حتى ${chaptersMax!} فصل';
      out.add((label, copyWith(clearChapters: true)));
    }
    if (minRating > 0) out.add(('تقييم ${minRating.toStringAsFixed(1)}+', copyWith(minRating: 0)));
    if (minViews > 0) out.add(('مشاهدات ${_short(minViews)}+', copyWith(minViews: 0)));
    if (yearFrom != null || yearTo != null) {
      final label = yearFrom != null && yearTo != null
          ? '$yearFrom–$yearTo'
          : yearFrom != null
              ? 'من $yearFrom'
              : 'حتى $yearTo';
      out.add((label, copyWith(clearYears: true)));
    }
    if (onlyNew) out.add(('جديد فقط', copyWith(onlyNew: false)));
    return out;
  }

  static String _short(int v) {
    if (v >= 1000000) return '${(v / 1000000).toStringAsFixed(v % 1000000 == 0 ? 0 : 1)} م';
    if (v >= 1000) return '${(v / 1000).round()} ألف';
    return '$v';
  }
}
