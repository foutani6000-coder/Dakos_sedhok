
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

enum DownloadStatus { queued, downloading, paused, completed, failed }

class DownloadTask {
  DownloadTask({
    required this.id, required this.seriesId, required this.seriesTitle,
    required this.cover, required this.chapter, required this.urls,
    this.files = const [], this.completedPages = 0,
    this.status = DownloadStatus.queued, this.error = '',
  });
  final String id, seriesId, seriesTitle;
  final String? cover;
  final int chapter;
  final List<String> urls;
  final List<String> files;
  final int completedPages;
  final DownloadStatus status;
  final String error;
  double get progress => urls.isEmpty ? 0 : completedPages / urls.length;
  bool get isComplete => status == DownloadStatus.completed;
  Map<String, dynamic> toJson() => {
    'id':id,'seriesId':seriesId,'seriesTitle':seriesTitle,'cover':cover,
    'chapter':chapter,'urls':urls,'files':files,'completedPages':completedPages,
    'status':status.name,'error':error,
  };
  factory DownloadTask.fromJson(Map<String,dynamic> j) => DownloadTask(
    id: '${j['id']}', seriesId: '${j['seriesId']}', seriesTitle: '${j['seriesTitle']}',
    cover: j['cover'] as String?, chapter: (j['chapter'] as num).toInt(),
    urls: (j['urls'] as List).cast<String>(), files: (j['files'] as List? ?? const []).cast<String>(),
    completedPages: (j['completedPages'] as num? ?? 0).toInt(),
    status: DownloadStatus.values.firstWhere((e)=>e.name==j['status'],orElse:()=>DownloadStatus.paused),
    error: '${j['error'] ?? ''}',
  );
  DownloadTask copy({List<String>? files,int? completedPages,DownloadStatus? status,String? error}) => DownloadTask(
    id:id,seriesId:seriesId,seriesTitle:seriesTitle,cover:cover,chapter:chapter,urls:urls,
    files:files??this.files,completedPages:completedPages??this.completedPages,
    status:status??this.status,error:error??this.error);
}

class DownloadManager extends ChangeNotifier {
  DownloadManager._();
  static final DownloadManager instance = DownloadManager._();
  static const _key = 'sard_download_tasks_v1';
  final List<DownloadTask> _tasks = [];
  final Set<String> _paused = {};
  bool _ready = false;
  List<DownloadTask> get tasks => List.unmodifiable(_tasks);
  Future<Directory> get _base async {
    final d = await getApplicationDocumentsDirectory();
    final dir = Directory('${d.path}/sard_downloads');
    if (!await dir.exists()) await dir.create(recursive:true);
    return dir;
  }

  Future<void> init() async {
    if (_ready) return;
    final p = await SharedPreferences.getInstance();
    try {
      final raw = p.getString(_key);
      if (raw != null) {
        final list = (jsonDecode(raw) as List).cast<Map>();
        _tasks.addAll(list.map((e)=>DownloadTask.fromJson(Map<String,dynamic>.from(e))));
      }
    } catch (_) {}
    for (var i=0;i<_tasks.length;i++) {
      if (_tasks[i].status == DownloadStatus.downloading || _tasks[i].status == DownloadStatus.queued) {
        _tasks[i] = _tasks[i].copy(status: DownloadStatus.paused);
      }
    }
    _ready = true;
    await _persist();
    notifyListeners();
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key,jsonEncode(_tasks.map((e)=>e.toJson()).toList()));
  }

  DownloadTask? task(String seriesId,int chapter) {
    for(final t in _tasks) { if(t.seriesId==seriesId && t.chapter==chapter) return t; }
    return null;
  }

  Future<void> enqueue({required String seriesId,required String title,String? cover,required int chapter,required List<PageSrc> pages}) async {
    await init();
    if(pages.isEmpty) throw Exception('لا توجد صفحات لتنزيلها');
    final old=task(seriesId,chapter);
    if(old!=null) {
      if(old.isComplete) return;
      if(old.status==DownloadStatus.downloading) return;
      _tasks.remove(old);
    }
    final t=DownloadTask(id:'${seriesId}_${chapter}_${DateTime.now().millisecondsSinceEpoch}',
      seriesId:seriesId,seriesTitle:title,cover:cover,chapter:chapter,
      urls:pages.map((e)=>e.url).toList());
    _tasks.insert(0,t);
    await _persist(); notifyListeners();
    unawaited(_run(t.id));
  }

  Future<void> _run(String id) async {
    var index=_tasks.indexWhere((e)=>e.id==id);
    if(index<0) return;
    var t=_tasks[index];
    if(t.isComplete) return;
    _paused.remove(id);
    t=t.copy(status:DownloadStatus.downloading,error:'');
    _tasks[index]=t; await _persist(); notifyListeners();
    try {
      final dir=await _base;
      final files=List<String>.from(t.files);
      for(var i=t.completedPages;i<t.urls.length;i++) {
        if(_paused.contains(id)) {
          await _replace(id,t.copy(files:files,status:DownloadStatus.paused,completedPages:i)); return;
        }
        final uri=Uri.parse(t.urls[i]);
        final response=await http.get(uri).timeout(const Duration(seconds:35));
        if(response.statusCode<200 || response.statusCode>=300) throw HttpException('HTTP ${response.statusCode}');
        final ext=(uri.path.split('.').last.toLowerCase().split('?').first);
        final safeExt=['jpg','jpeg','png','webp','gif'].contains(ext)?ext:'jpg';
        final file=File('${dir.path}/${id}_$i.$safeExt');
        await file.writeAsBytes(response.bodyBytes,flush:true);
        if(files.length<=i) files.add(file.path); else files[i]=file.path;
        t=t.copy(files:files,completedPages:i+1);
        await _replace(id,t);
      }
      await _replace(id,t.copy(status:DownloadStatus.completed,completedPages:t.urls.length));
    } catch(e) {
      await _replace(id,t.copy(status:DownloadStatus.failed,error:e.toString()));
    }
  }

  Future<void> _replace(String id,DownloadTask task) async {
    final i=_tasks.indexWhere((e)=>e.id==id);
    if(i<0) return;
    _tasks[i]=task;
    await _persist();
    notifyListeners();
  }

  Future<void> pause(String id) async {
    _paused.add(id);
    final i=_tasks.indexWhere((e)=>e.id==id);
    if(i>=0 && _tasks[i].status!=DownloadStatus.downloading) {
      _tasks[i]=_tasks[i].copy(status:DownloadStatus.paused); await _persist(); notifyListeners();
    }
  }
  Future<void> resume(String id) async {
    final i=_tasks.indexWhere((e)=>e.id==id);
    if(i<0 || _tasks[i].isComplete) return;
    unawaited(_run(id));
  }

  Future<void> delete(String id) async {
    final t=taskById(id); if(t==null) return;
    _paused.add(id);
    for(final f in t.files) { try { await File(f).delete(); } catch(_) {} }
    _tasks.removeWhere((e)=>e.id==id);
    await _persist(); notifyListeners();
  }
  DownloadTask? taskById(String id) {
    for(final t in _tasks) { if(t.id==id) return t; }
    return null;
  }
  Future<void> clearCompleted() async {
    final done=_tasks.where((e)=>e.isComplete).toList();
    for(final t in done) { for(final f in t.files) { try { await File(f).delete(); } catch(_) {} } }
    _tasks.removeWhere((e)=>e.isComplete);
    await _persist(); notifyListeners();
  }
  Future<void> clearAll() async {
    for(final t in List<DownloadTask>.from(_tasks)) { await delete(t.id); }
  }
  Future<List<PageSrc>?> offlinePages(String seriesId,int chapter) async {
    await init();
    final t=task(seriesId,chapter);
    if(t==null || !t.isComplete || t.files.length!=t.urls.length) return null;
    for(final path in t.files) { if(!await File(path).exists()) return null; }
    return t.files.map((p)=>PageSrc('file:$p')).toList();
  }
}
