import 'dart:convert';

import 'mock_data.dart';
import 'models.dart';
import 'repository.dart';

/// المنشورات والمحادثات.
///
/// العقد المتوقع من السيرفر (عدّله هنا فقط):
///   GET  /posts                      -> [Post] أو {posts:[...]}
///   POST /posts {body, tag}          -> Post
///   POST /posts/{id}/like            -> أي رد ناجح
///   GET  /chats                      -> [Chat] أو {chats:[...]}
///   GET  /chats/{id}/messages        -> [Message] أو {messages:[...]}
///   POST /chats/{id}/messages {text} -> Message
///   POST /read-rooms {series_id, series_title, chapter, friend_id} -> ReadRoom
///   GET  /read-rooms/{id}            -> ReadRoom (يتضمن موضع الصديق friend.position)
///   POST /read-rooms/{id}/position {chapter, page, total} -> أي رد ناجح
///   POST /read-rooms/{id}/leave      -> أي رد ناجح
///   (دردشة الغرفة = GET/POST /chats/{room.chat_id}/messages نفسها)
///
/// عند ترك API_BASE_URL فارغاً تعمل الصفحتان ببيانات تجريبية محلية.
final List<SardPost> _mockPosts = [
  const SardPost(id: 'p1', authorId: 'u_nora', badge: SardBadge.purple, author: 'نورا القارئة', tag: 'توصية', createdAt: 'قبل ساعة', comments: 9, reactions: {SardReaction.like: 26, SardReaction.love: 15, SardReaction.wow: 7},
      body: 'أنهيت الفصل الأخير للتو ولا أصدّق النهاية! أي عمل تنصحونني به بعد هذا؟'),
  const SardPost(id: 'p2', authorId: 'u_yaser', badge: SardBadge.blue, author: 'أبو ياسر', tag: 'نقاش', createdAt: 'قبل 3 ساعات', comments: 14, reactions: {SardReaction.like: 19, SardReaction.laugh: 8, SardReaction.wow: 4},
      poll: SardPoll(question: 'ما طريقة القراءة المفضلة لديك؟', options: [
        SardPollOption(id: 'o1', text: 'عمودي (ويبتون)', votes: 41),
        SardPollOption(id: 'o2', text: 'صفحة بصفحة', votes: 27),
        SardPollOption(id: 'o3', text: 'حسب العمل', votes: 12),
      ]),
      body: 'برأيكم: هل القراءة العمودية أفضل من صفحة بصفحة للمانغا اليابانية؟'),
  const SardPost(id: 'p3', authorId: 'u_layla', badge: SardBadge.yellow, author: 'ليلى', tag: 'ترجمة', createdAt: 'أمس', comments: 4, reactions: {SardReaction.like: 14, SardReaction.love: 8},
      body: 'ننتظر فصولاً جديدة هذا الأسبوع، تابعوا الأعمال المفضلة لتصلكم الإشعارات.'),
  const SardPost(id: 'p3b', authorId: 'u_saif', author: 'سيف', tag: 'ترشيح', createdAt: 'أمس', comments: 2, reactions: {SardReaction.like: 11, SardReaction.wow: 6},
      body: 'أفضل أعمال الغموض التي قرأتها هذا العام؟ أبحث عن قصة بحبكة محكمة.'),
];

final List<SardChat> _mockChats = [
  const SardChat(id: 'c1', userId: 'u_nora', badge: SardBadge.purple, name: 'نورا القارئة', lastMessage: 'شكراً على الترشيح، سأقرؤه الليلة!', time: '20:12', unread: 2),
  const SardChat(id: 'c2', userId: 'u_yaser', badge: SardBadge.blue, name: 'أبو ياسر', lastMessage: 'هل وصلك الفصل الجديد؟', time: '18:40', unread: 0),
  const SardChat(id: 'c3', name: 'مجموعة المانهوا', lastMessage: 'ليلى: انضموا للنقاش في المنشورات', time: 'أمس', unread: 5),
  const SardChat(id: 'c4', userId: 'u_saif', name: 'سيف', lastMessage: 'تمام، اتفقنا 👍', time: 'الأحد', unread: 0),
];

final Map<String, List<SardChatMessage>> _mockMessages = {
  'c1': [
    const SardChatMessage(id: 'm1', text: 'مرحباً! قرأتِ العمل الذي رشّحته لك؟', mine: true, time: '20:05'),
    const SardChatMessage(id: 'm2', text: 'شكراً على الترشيح، سأقرؤه الليلة!', mine: false, time: '20:12'),
  ],
  'c2': [
    const SardChatMessage(id: 'm3', text: 'هل وصلك الفصل الجديد؟', mine: false, time: '18:40'),
  ],
  'c3': [
    const SardChatMessage(id: 'm4', text: 'ليلى: انضموا للنقاش في المنشورات', mine: false, time: 'أمس'),
  ],
  'c4': [
    const SardChatMessage(id: 'm5', text: 'تمام، اتفقنا 👍', mine: false, time: 'الأحد'),
  ],
};

final Map<String, List<SardComment>> _mockPostComments = {};

List<SardComment> _seedPostComments(String postId) => [
      SardComment(id: '${postId}_pc1', seriesId: postId, author: 'أبو ياسر', authorId: 'u_yaser', badge: SardBadge.blue, text: 'اتفق معك تماماً 👏', createdAt: 'قبل ساعة'),
      SardComment(id: '${postId}_pc2', seriesId: postId, author: 'ليلى', authorId: 'u_layla', badge: SardBadge.yellow, text: 'شكراً على المشاركة، أفادني كثيراً.', createdAt: 'قبل ساعتين'),
    ];

/// مستخدمون تجريبيون لصفحات البروفايل العامة (وضع بدون سيرفر)
final Map<String, Map<String, dynamic>> _mockUsers = {
  'u_nora': {
    'name': 'نورا القارئة', 'badge': 'purple', 'joined': 'منذ 2023',
    'bio': 'من فريق Senok. أحب الفانتازيا والدراما، وأرشّح لكم كل أسبوع عملاً يستحق.',
    'chapters_read': 2140, 'reading_seconds': 612000,
    'recommended': {'m1': 'حبكة محكمة ورسم مذهل.', 'm3': 'نهاية ستبقى في ذاكرتك.', 'm2': 'بداية بطيئة لكنها تستحق.'},
  },
  'u_yaser': {
    'name': 'أبو ياسر', 'badge': 'blue', 'joined': 'منذ 2024',
    'bio': 'قارئ مانغا منذ 15 عاماً، موثّق ومهتم بالنقاش الهادئ.',
    'chapters_read': 1320, 'reading_seconds': 402000,
    'recommended': {'m4': 'فنون قتالية بأسلوب مختلف.', 'm2': 'ممتاز لمحبي الغموض.'},
  },
  'u_layla': {
    'name': 'ليلى', 'badge': 'yellow', 'joined': 'منذ 2024',
    'bio': 'مترجمة معتمدة. أترجم الأعمال الكورية وأحب الرومانسية والفانتازيا.',
    'chapters_read': 980, 'reading_seconds': 287000,
    'recommended': {'m5': 'عمل جديد بفكرة طازجة.', 'm1': 'يستحق كل ساعة.'},
  },
  'u_saif': {
    'name': 'سيف', 'badge': 'none', 'joined': 'منذ 2025',
    'bio': 'أبحث دائماً عن قصة بحبكة محكمة.',
    'chapters_read': 214, 'reading_seconds': 51000,
    'recommended': {'m3': 'أفضل ما قرأت هذا العام.'},
  },
};

List<T> _list<T>(dynamic j, String key, T Function(Map<String, dynamic>) f) =>
    ((j is Map ? j[key] : j) as List? ?? const [])
        .map((e) => f(Map<String, dynamic>.from(e as Map)))
        .toList();

/// حالة غرفة قراءة تجريبية (وضع بدون سيرفر): صديق افتراضي يتقدّم كل بضع ثوانٍ.
class _MockRoomState {
  _MockRoomState({required this.room, required this.startPage, required this.total}) : started = DateTime.now();
  SardReadRoom room;
  final int startPage, total;
  final DateTime started;
}

final Map<String, _MockRoomState> _mockRooms = {};
const _mockRoomReplies = ['وصلت لنفس المكان 👀', 'هذا المشهد جميل!', 'لا تسبقني بالحرق 😅', 'أكمل، سأتبعك'];

extension SardSocialRepository on SardRepository {
  // ───────── المنشورات ─────────
  Future<List<SardPost>> posts() async {
    if (mock) {
      await Future<void>.delayed(const Duration(milliseconds: 450));
      return List.of(_mockPosts);
    }
    return _list(await api.get('/posts'), 'posts', SardPost.fromJson);
  }

  /// POST /posts (multipart): body, tag, poll (JSON: {question, options:[..]})، images[] ملفات.
  Future<SardPost?> addPost(String body, {String tag = '', List<String> images = const [], SardPoll? poll}) async {
    if (mock) {
      final p = SardPost(
        id: 'local_${DateTime.now().millisecondsSinceEpoch}',
        author: 'أنت',
        body: body,
        tag: tag,
        createdAt: 'الآن',
        images: images,
        poll: poll,
      );
      _mockPosts.insert(0, p);
      return p;
    }
    final fields = <String, String>{'body': body, 'tag': tag};
    if (poll != null) {
      fields['poll'] = jsonEncode({'question': poll.question, 'options': poll.options.map((o) => o.text).toList()});
    }
    final j = await api.postMultipart('/posts', fields: fields, files: {'images': images});
    return j is Map ? SardPost.fromJson(Map<String, dynamic>.from(j)) : null;
  }

  /// POST /posts/{id}/react {reaction: like|love|laugh|wow|sad|null}
  Future<void> reactPost(String id, SardReaction? r) async {
    if (mock) {
      final i = _mockPosts.indexWhere((e) => e.id == id);
      if (i >= 0) _mockPosts[i] = _mockPosts[i].react(r);
      return;
    }
    await api.post('/posts/$id/react', body: {'reaction': r?.key});
  }

  /// POST /posts/{id}/vote {option_id: id|null}
  Future<void> votePoll(String id, String? optionId) async {
    if (mock) {
      final i = _mockPosts.indexWhere((e) => e.id == id);
      if (i >= 0 && _mockPosts[i].poll != null) {
        _mockPosts[i] = _mockPosts[i].copyWith(poll: _mockPosts[i].poll!.withVote(optionId));
      }
      return;
    }
    await api.post('/posts/$id/vote', body: {'option_id': optionId});
  }

  // ───────── تعليقات المنشورات (seriesId يحمل هنا معرّف المنشور) ─────────
  Future<List<SardComment>> postComments(String postId) async {
    if (mock) {
      return List.unmodifiable(_mockPostComments.putIfAbsent(postId, () => _seedPostComments(postId)));
    }
    return _list(await api.get('/posts/$postId/comments'), 'comments', SardComment.fromJson);
  }

  Future<SardComment?> addPostComment(String postId, String text) async {
    if (mock) {
      final c = SardComment(id: 'pc_${DateTime.now().millisecondsSinceEpoch}', seriesId: postId, author: 'أنت', text: text, createdAt: 'الآن');
      (_mockPostComments[postId] ??= _seedPostComments(postId)).insert(0, c);
      final i = _mockPosts.indexWhere((e) => e.id == postId);
      if (i >= 0) _mockPosts[i] = _mockPosts[i].copyWith(comments: _mockPosts[i].comments + 1);
      return c;
    }
    final j = await api.post('/posts/$postId/comments', body: {'text': text});
    return j is Map ? SardComment.fromJson(Map<String, dynamic>.from(j)) : null;
  }

  // ───────── البروفايلات العامة ─────────
  /// GET /users/{id} -> {id,name,avatar_url,bio,joined,badge:"purple|blue|yellow",
  ///   chapters_read, reading_seconds, recommendations:[{series:{..},note}], posts:[..]}
  Future<SardUserProfile> userProfile(String id) async {
    if (mock) {
      await Future<void>.delayed(const Duration(milliseconds: 300));
      final u = _mockUsers[id];
      if (u == null) return SardUserProfile(id: id, name: 'قارئ');
      final recs = <SardRecommendation>[];
      (u['recommended'] as Map).forEach((sid, note) {
        for (final s in MockData.all) {
          if (s.id == '$sid') recs.add(SardRecommendation(series: s, note: '$note'));
        }
      });
      return SardUserProfile(
        id: id,
        name: '${u['name']}',
        bio: '${u['bio']}',
        joined: '${u['joined']}',
        badge: SardBadge.fromJson(u['badge']),
        chaptersRead: u['chapters_read'] as int,
        readingSeconds: u['reading_seconds'] as int,
        recommendations: recs,
        posts: _mockPosts.where((p) => p.authorId == id).toList(),
      );
    }
    final j = await api.get('/users/$id');
    final m = j is Map && j['user'] is Map ? j['user'] : j;
    return SardUserProfile.fromJson(Map<String, dynamic>.from(m as Map));
  }

  // ───────── المحادثات ─────────
  Future<List<SardChat>> chats() async {
    if (mock) {
      await Future<void>.delayed(const Duration(milliseconds: 350));
      return List.of(_mockChats);
    }
    return _list(await api.get('/chats'), 'chats', SardChat.fromJson);
  }

  Future<List<SardChatMessage>> chatMessages(String chatId) async {
    if (mock) return List.of(_mockMessages[chatId] ?? const <SardChatMessage>[]);
    return _list(await api.get('/chats/$chatId/messages'), 'messages', SardChatMessage.fromJson);
  }

  Future<SardChatMessage> sendMessage(String chatId, String text) async {
    if (mock) {
      final m = SardChatMessage(id: 'local_${DateTime.now().millisecondsSinceEpoch}', text: text, mine: true, time: 'الآن');
      (_mockMessages[chatId] ??= []).add(m);
      return m;
    }
    final j = await api.post('/chats/$chatId/messages', body: {'text': text});
    return j is Map
        ? SardChatMessage.fromJson(Map<String, dynamic>.from(j))
        : SardChatMessage(id: 'local_${DateTime.now().millisecondsSinceEpoch}', text: text, mine: true, time: 'الآن');
  }

  // ───────── القراءة المشتركة ─────────

  /// تنشئ غرفة بين المستخدم و[friendId] على فصل محدّد.
  Future<SardReadRoom> createReadRoom({
    required String seriesId,
    required String seriesTitle,
    required int chapter,
    required String friendId,
    required String friendName,
    SardBadge friendBadge = SardBadge.none,
  }) async {
    if (mock) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      final id = 'r${DateTime.now().millisecondsSinceEpoch}';
      final room = SardReadRoom(
        id: id,
        chatId: 'room_$id',
        seriesId: seriesId,
        seriesTitle: seriesTitle,
        chapter: chapter,
        friendId: friendId,
        friendName: friendName,
        friendBadge: friendBadge,
        friendChapter: chapter,
        friendPage: 1,
        friendTotal: 24,
        friendOnline: true,
      );
      _mockRooms[id] = _MockRoomState(room: room, startPage: 1, total: 24);
      _mockMessages[room.chatId] = [
        SardChatMessage(id: 'sys_$id', text: 'بدأت قراءة مشتركة لـ «$seriesTitle» — فصل $chapter. اكتب هنا وأنت تقرأ!', mine: false, time: 'الآن'),
      ];
      return room;
    }
    final j = await api.post('/read-rooms', body: {
      'series_id': seriesId,
      'series_title': seriesTitle,
      'chapter': chapter,
      'friend_id': friendId,
    });
    final m = j is Map && j['room'] is Map ? j['room'] : j;
    final room = SardReadRoom.fromJson(Map<String, dynamic>.from(m as Map));
    // يكمل ما لم يرسله السيرفر من بيانات العرض
    return SardReadRoom(
      id: room.id,
      chatId: room.chatId,
      seriesId: room.seriesId.isEmpty ? seriesId : room.seriesId,
      seriesTitle: room.seriesTitle.isEmpty ? seriesTitle : room.seriesTitle,
      chapter: room.chapter == 0 ? chapter : room.chapter,
      friendId: room.friendId.isEmpty ? friendId : room.friendId,
      friendName: room.friendName == 'قارئ' ? friendName : room.friendName,
      friendBadge: room.friendBadge.isNone ? friendBadge : room.friendBadge,
      friendChapter: room.friendChapter,
      friendPage: room.friendPage,
      friendTotal: room.friendTotal,
      friendOnline: room.friendOnline,
    );
  }

  /// حالة الغرفة الحالية (موضع الصديق). تُستدعى دورياً أثناء القراءة.
  Future<SardReadRoom> readRoom(SardReadRoom current) async {
    if (mock) {
      final st = _mockRooms[current.id];
      if (st == null) return current;
      final steps = DateTime.now().difference(st.started).inSeconds ~/ 7;
      final page = (st.startPage + steps).clamp(1, st.total).toInt();
      st.room = st.room.copyWith(friendChapter: current.chapter, friendPage: page, friendTotal: st.total, friendOnline: true);
      return st.room;
    }
    final j = await api.get('/read-rooms/${current.id}');
    final m = j is Map && j['room'] is Map ? j['room'] : j;
    final fresh = SardReadRoom.fromJson(Map<String, dynamic>.from(m as Map));
    return current.copyWith(
      friendChapter: fresh.friendChapter,
      friendPage: fresh.friendPage,
      friendTotal: fresh.friendTotal,
      friendOnline: fresh.friendOnline,
    );
  }

  /// يرسل موضع المستخدم الحالي في الغرفة.
  Future<void> updateReadPosition(String roomId, {required int chapter, required int page, required int total}) async {
    if (mock) return;
    await api.post('/read-rooms/$roomId/position', body: {'chapter': chapter, 'page': page, 'total': total});
  }

  Future<void> leaveReadRoom(String roomId) async {
    if (mock) {
      _mockRooms.remove(roomId);
      return;
    }
    await api.post('/read-rooms/$roomId/leave');
  }

  /// رد تجريبي من الصديق الافتراضي بعد رسالة المستخدم (وضع بدون سيرفر فقط).
  void mockFriendReply(String chatId) {
    if (!mock || !chatId.startsWith('room_')) return;
    Future<void>.delayed(const Duration(milliseconds: 2200), () {
      final list = _mockMessages[chatId];
      if (list == null) return;
      final text = _mockRoomReplies[list.length % _mockRoomReplies.length];
      list.add(SardChatMessage(id: 'mr_${DateTime.now().millisecondsSinceEpoch}', text: text, mine: false, time: 'الآن'));
    });
  }
}
