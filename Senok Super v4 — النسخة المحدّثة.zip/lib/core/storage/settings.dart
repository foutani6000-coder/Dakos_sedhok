import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/models.dart';
import '../stamps/stamps.dart';

enum DataMode { hd, mobile, always }

/// التحميل المسبق الذكي لصفحات الفصل التالي: إيقاف / على الواي فاي فقط / دائماً
enum PrefetchMode { off, wifi, always }

/// وضع القراءة: عمودي (ويبتون) / صفحة بصفحة يمين←يسار (مانغا) / يسار←يمين
enum ReaderMode { vertical, pagedRtl, pagedLtr }

/// آخر موضع قراءة لعمل واحد
@immutable
class ReadProgress {
  const ReadProgress({
    required this.chapter,
    required this.page,
    required this.total,
  });

  final int chapter;

  /// رقم الصفحة (يبدأ من 1)
  final int page;
  final int total;

  /// نسبة التقدم داخل الفصل 0..1
  double get fraction => total <= 1 ? 0 : ((page - 1) / (total - 1)).clamp(0.0, 1.0);

  Map<String, dynamic> toJson() => {'c': chapter, 'p': page, 't': total};

  factory ReadProgress.fromJson(Map<String, dynamic> j) => ReadProgress(
        chapter: (j['c'] as num?)?.toInt() ?? 1,
        page: (j['p'] as num?)?.toInt() ?? 1,
        total: (j['t'] as num?)?.toInt() ?? 1,
      );
}

class SettingsController extends ChangeNotifier {
  SettingsController._(this._p) {
    _progress = _decode('progress').map(
      (k, v) => MapEntry(k, ReadProgress.fromJson(v as Map<String, dynamic>)),
    );
    _read = _decode('read_chapters').map(
      (k, v) => MapEntry(k, ((v as List).map((e) => (e as num).toInt())).toSet()),
    );
    _seconds = _decode('reading_seconds').map((k, v) => MapEntry(k, (v as num).toInt()));
    _readDays = (_p.getStringList('read_days') ?? const <String>[]).toSet();
    _stamps = _decode('stamps').map((k, v) => MapEntry(k, (v as num).toInt()));
    _night = _p.getInt('night_seconds') ?? 0;
    _bestStreak = _p.getInt('best_streak') ?? 0;
    _bestDay = _p.getInt('best_day_chapters') ?? 0;
    final today = _dayKey(DateTime.now());
    _dayCount = _p.getString('day_count_date') == today ? (_p.getInt('day_count') ?? 0) : 0;
    // منح الأختام المستحقة من تاريخ سابق بصمت (دون إشعارات)
    _checkStamps(silent: true);
  }
  final SharedPreferences _p;
  late Map<String, ReadProgress> _progress;
  late Map<String, Set<int>> _read;
  late Map<String, int> _seconds;
  late Set<String> _readDays;
  late Map<String, int> _stamps;
  late int _night;
  late int _bestStreak;
  late int _bestDay;
  late int _dayCount;

  /// الختم الذي يُعرض الآن كإشعار احتفالي (يستمع له StampToastHost)
  final ValueNotifier<StampDef?> stampToast = ValueNotifier<StampDef?>(null);
  final List<StampDef> _toastQueue = <StampDef>[];

  static Future<SettingsController> load() async {
    return SettingsController._(await SharedPreferences.getInstance());
  }

  Map<String, dynamic> _decode(String key) {
    try {
      final raw = _p.getString(key);
      if (raw == null || raw.isEmpty) return {};
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return {};
    }
  }

  /// themeId may be one of the five fixed palettes or 'system'.
  String get themeId => _p.getString('theme') ?? 'obsidian';

  /// لون التمييز (قرمزي افتراضياً).
  String get accentId => _p.getString('accent_id') ?? 'auto';

  void setAccentId(String id) {
    _p.setString('accent_id', id);
    notifyListeners();
  }

  DataMode get dataMode {
    final i = (_p.getInt('data_mode') ?? 0).clamp(0, DataMode.values.length - 1);
    return DataMode.values[i.toInt()];
  }

  /// التحميل المسبق للصفحات القادمة والفصل التالي (الافتراضي: على الواي فاي فقط)
  PrefetchMode get prefetchMode {
    final i = (_p.getInt('prefetch_mode') ?? 1).clamp(0, PrefetchMode.values.length - 1);
    return PrefetchMode.values[i.toInt()];
  }

  void setPrefetchMode(PrefetchMode m) {
    _p.setInt('prefetch_mode', m.index);
    notifyListeners();
  }

  bool get onboarded => _p.getBool('onboarded') ?? false;

  /// معامل حجم الخط في كل التطبيق (0.75..1.15). الافتراضي 0.88 أصغر من الحجم الأصلي.
  double get fontScale => (_p.getDouble('font_scale') ?? 0.88).clamp(0.75, 1.15).toDouble();

  void setFontScale(double v) {
    _p.setDouble('font_scale', v.clamp(0.75, 1.15).toDouble());
    notifyListeners();
  }

  Set<String> get followedSeries => (_p.getStringList('followed_series') ?? const <String>[]).toSet();
  bool isFollowing(String id) => followedSeries.contains(id);
  void setFollowing(String id, bool value) {
    final ids = followedSeries;
    if (value) { ids.add(id); } else { ids.remove(id); }
    _p.setStringList('followed_series', ids.toList());
    notifyListeners();
    _checkStamps();
  }

  void setTheme(String id) {
    _p.setString('theme', id);
    // عند تغيير الثيم يعود لونه المميّز تلقائياً
    _p.setString('accent_id', 'auto');
    notifyListeners();
  }

  void setDataMode(DataMode m) {
    _p.setInt('data_mode', m.index);
    notifyListeners();
  }

  // ───────── رفيقي ─────────
  String get companionName => _p.getString('companion_name') ?? 'حبّار';
  int get companionMood => _p.getInt('companion_mood') ?? 0;
  void setCompanionName(String v) {
    _p.setString('companion_name', v.trim().isEmpty ? 'حبّار' : v.trim());
    notifyListeners();
  }
  void setCompanionMood(int i) {
    _p.setInt('companion_mood', i);
    notifyListeners();
  }

  void finishOnboarding() {
    _p.setBool('onboarded', true);
    notifyListeners();
  }

  // ───────── إعدادات القارئ (البنود 14 و19) ─────────

  ReaderMode get readerMode {
    final i = (_p.getInt('reader_mode') ?? 0).clamp(0, ReaderMode.values.length - 1);
    return ReaderMode.values[i.toInt()];
  }

  /// سطوع القارئ 0.25..1 (تعتيم داخل التطبيق دون لمس سطوع النظام)
  double get readerBrightness =>
      (_p.getDouble('reader_brightness') ?? 1.0).clamp(0.25, 1.0).toDouble();

  /// سرعة التمرير التلقائي: 0 بطيء، 1 متوسط، 2 سريع
  int get readerAutoSpeed => (_p.getInt('reader_auto_speed') ?? 1).clamp(0, 2).toInt();

  bool get keepAwake => _p.getBool('keep_awake') ?? true;

  /// القراءة المتصلة: يتابع الوضع العمودي الفصل التالي دون انقطاع
  bool get chainChapters => _p.getBool('chain_chapters') ?? true;
  void setChainChapters(bool v) => _p.setBool('chain_chapters', v);

  // هذه الدوال لا تستدعي notifyListeners حتى لا يُعاد بناء التطبيق كله
  // أثناء القراءة؛ القارئ يحتفظ بنسخة محلية من القيمة.
  void setReaderMode(ReaderMode m) => _p.setInt('reader_mode', m.index);
  void setReaderBrightness(double v) => _p.setDouble('reader_brightness', v);
  void setKeepAwake(bool v) => _p.setBool('keep_awake', v);
  void setReaderAutoSpeed(int v) => _p.setInt('reader_auto_speed', v.clamp(0, 2).toInt());

  // ───────── التقدّم في القراءة (البند 16) ─────────

  ReadProgress? progressOf(String seriesId) => _progress[seriesId];

  Set<int> readChapters(String seriesId) => _read[seriesId] ?? const <int>{};

  void saveProgress(String seriesId, int chapter, int page, int total) {
    _progress.remove(seriesId); // يعيد العمل لآخر الترتيب = الأحدث
    _progress[seriesId] = ReadProgress(chapter: chapter, page: page, total: total);
    _p.setString(
      'progress',
      jsonEncode(_progress.map((k, v) => MapEntry(k, v.toJson()))),
    );
    _checkStamps();
  }

  // ───────── وقت القراءة ─────────

  /// إجمالي الثواني التي قضيتها داخل القارئ
  int get totalReadingSeconds => _seconds.values.fold<int>(0, (a, b) => a + b);

  /// إجمالي الفصول المقروءة في كل الأعمال
  int get totalChaptersRead => _read.values.fold<int>(0, (a, b) => a + b.length);

  int readingSecondsOf(String seriesId) => _seconds[seriesId] ?? 0;

  /// الأعمال مرتّبة بحسب الوقت المقضي (الأكثر أولاً)
  List<String> get topReadIds {
    final ids = <String>{..._seconds.keys, ..._read.keys}.toList();
    ids.sort((a, b) => readingSecondsOf(b).compareTo(readingSecondsOf(a)));
    return ids;
  }

  /// لا يستدعي notifyListeners (يُنادى أثناء القراءة)
  void addReadingSeconds(String seriesId, int seconds) {
    if (seconds <= 0) return;
    _seconds[seriesId] = (_seconds[seriesId] ?? 0) + seconds;
    _p.setString('reading_seconds', jsonEncode(_seconds));
    if (DateTime.now().hour < 5) {
      _night += seconds;
      _p.setInt('night_seconds', _night);
    }
    _touchToday();
    _checkStamps();
  }

  Map<String, dynamic> exportReadingSeconds() => Map<String, dynamic>.from(_seconds);

  // ───────── الملف الشخصي والتوصيات ─────────

  /// الأعمال التي أوصي بها (الأحدث أولاً)
  List<String> get recommendedIds => _ids('recommended');
  bool isRecommended(String id) => recommendedIds.contains(id);
  void setRecommended(Series s, bool value) {
    cacheSeries(s);
    final ids = recommendedIds..remove(s.id);
    if (value) ids.insert(0, s.id);
    _p.setStringList('recommended', ids);
    notifyListeners();
    _checkStamps();
  }

  String get profileBio => _p.getString('profile_bio') ?? '';
  void setProfileBio(String v) {
    _p.setString('profile_bio', v.trim());
    notifyListeners();
  }

  Map<String, dynamic> exportProgress() => _progress.map((k, v) => MapEntry(k, v.toJson()));
  Map<String, dynamic> exportReadChapters() => _read.map((k, v) => MapEntry(k, v.toList()));

  void importLibraryState({Map<String, dynamic>? progress, Map<String, dynamic>? readChapters, List<String>? followed}) {
    if (progress != null) {
      _progress = progress.map((k, v) => MapEntry(k, ReadProgress.fromJson(Map<String, dynamic>.from(v as Map))));
      _p.setString('progress', jsonEncode(exportProgress()));
    }
    if (readChapters != null) {
      _read = readChapters.map((k, v) => MapEntry(k, (v as List).map((e) => (e as num).toInt()).toSet()));
      _p.setString('read_chapters', jsonEncode(exportReadChapters()));
    }
    if (followed != null) _p.setStringList('followed_series', followed);
    _checkStamps(silent: true);
    notifyListeners();
  }

  // ───────── الرفوف: المفضلة / أقرؤها حالياً / القراءة لاحقاً ─────────

  /// نسخة محفوظة من بيانات العمل لعرضه في الرفوف دون اتصال
  void cacheSeries(Series s) {
    final m = _decode('series_cache');
    m[s.id] = s.toJson();
    _p.setString('series_cache', jsonEncode(m));
  }

  Series? cachedSeries(String id) {
    final raw = _decode('series_cache')[id];
    if (raw is! Map) return null;
    try {
      return Series.fromJson(Map<String, dynamic>.from(raw));
    } catch (_) {
      return null;
    }
  }

  List<String> _ids(String key) => List<String>.from(_p.getStringList(key) ?? const <String>[]);

  List<String> get favoriteIds => _ids('shelf_fav');
  List<String> get laterIds => _ids('shelf_later');

  /// الأعمال قيد القراءة: كل عمل له تقدّم محفوظ (الأحدث أولاً)
  List<String> get readingIds => _progress.keys.toList().reversed.toList();

  bool isFavorite(String id) => favoriteIds.contains(id);
  bool isReadLater(String id) => laterIds.contains(id);

  void setFavorite(Series s, bool value) {
    cacheSeries(s);
    final ids = favoriteIds..remove(s.id);
    if (value) ids.insert(0, s.id);
    _p.setStringList('shelf_fav', ids);
    notifyListeners();
    _checkStamps();
  }

  void setReadLater(Series s, bool value) {
    cacheSeries(s);
    final ids = laterIds..remove(s.id);
    if (value) ids.insert(0, s.id);
    _p.setStringList('shelf_later', ids);
    notifyListeners();
  }

  /// إزالة عمل من قائمة «أقرؤها حالياً» (يحذف تقدّمه)
  void removeProgress(String seriesId) {
    _progress.remove(seriesId);
    _p.setString('progress', jsonEncode(exportProgress()));
    notifyListeners();
  }

  void markRead(String seriesId, int chapter) {
    final s = _read.putIfAbsent(seriesId, () => <int>{});
    if (!s.add(chapter)) return;
    _p.setString(
      'read_chapters',
      jsonEncode(_read.map((k, v) => MapEntry(k, v.toList()))),
    );
    _touchToday();
    final key = _dayKey(DateTime.now());
    if (_p.getString('day_count_date') != key) {
      _p.setString('day_count_date', key);
      _dayCount = 0;
    }
    _dayCount++;
    _p.setInt('day_count', _dayCount);
    if (_dayCount > _bestDay) {
      _bestDay = _dayCount;
      _p.setInt('best_day_chapters', _bestDay);
    }
    _checkStamps();
  }

  // ───────── الأختام والمواظبة ─────────

  static String _dayKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void _touchToday() {
    if (_readDays.add(_dayKey(DateTime.now()))) {
      _p.setStringList('read_days', _readDays.toList());
    }
  }

  /// هل قرأت في هذا اليوم؟
  bool readOnDay(DateTime d) => _readDays.contains(_dayKey(d));

  /// عدد أيام القراءة في سنة معيّنة
  int readDaysInYear(int year) {
    final prefix = '$year-';
    return _readDays.where((k) => k.startsWith(prefix)).length;
  }

  /// أكثر نوع قرأتَ فيه (حسب الوقت والفصول) من بيانات الأعمال المحفوظة، أو null
  String? get topGenre {
    final cache = _decode('series_cache');
    final score = <String, int>{};
    final ids = <String>{..._seconds.keys, ..._read.keys};
    for (final id in ids) {
      final raw = cache[id];
      if (raw is! Map) continue;
      final g = raw['genres'];
      if (g is! List) continue;
      final w = (_seconds[id] ?? 0) + (_read[id]?.length ?? 0) * 60;
      for (final e in g) {
        final k = '$e';
        if (k.isEmpty) continue;
        score[k] = (score[k] ?? 0) + w;
      }
    }
    String? best;
    var bestValue = 0;
    for (final e in score.entries) {
      if (e.value > bestValue) {
        best = e.key;
        bestValue = e.value;
      }
    }
    return best;
  }

  /// أيام القراءة المتتالية. تبقى الشعلة حيّة إن قرأت أمس ولم تقرأ اليوم بعد.
  int get streak {
    var d = DateTime.now();
    if (!readOnDay(d)) d = DateTime(d.year, d.month, d.day - 1);
    var n = 0;
    while (readOnDay(d)) {
      n++;
      d = DateTime(d.year, d.month, d.day - 1);
    }
    return n;
  }

  int get bestStreak => _bestStreak > streak ? _bestStreak : streak;

  StampStats get stampStats => StampStats(
        chapters: totalChaptersRead,
        minutes: totalReadingSeconds ~/ 60,
        started: _progress.length,
        followed: followedSeries.length,
        favorites: favoriteIds.length,
        recommended: recommendedIds.length,
        streak: bestStreak,
        nightMinutes: _night ~/ 60,
        bestDayChapters: _bestDay,
      );

  /// الأختام المنالة: المعرّف ← وقت النيل (بالميلي ثانية)
  Map<String, int> get unlockedStamps => Map<String, int>.unmodifiable(_stamps);
  bool hasStamp(String id) => _stamps.containsKey(id);

  /// تُنادى بعد كل حدث قد يحقق ختماً. لا تستدعي notifyListeners حتى لا يُعاد
  /// بناء التطبيق أثناء القراءة؛ الإشعار الاحتفالي يصل عبر [stampToast].
  void _checkStamps({bool silent = false}) {
    final cur = streak;
    if (cur > _bestStreak) {
      _bestStreak = cur;
      _p.setInt('best_streak', cur);
    }
    final st = stampStats;
    var changed = false;
    for (final d in kStamps) {
      if (_stamps.containsKey(d.id)) continue;
      if (d.value(st) >= d.target) {
        _stamps[d.id] = DateTime.now().millisecondsSinceEpoch;
        if (!silent) _toastQueue.add(d);
        changed = true;
      }
    }
    if (!changed) return;
    _p.setString('stamps', jsonEncode(_stamps));
    _pumpToast();
  }

  void _pumpToast() {
    if (stampToast.value != null || _toastQueue.isEmpty) return;
    stampToast.value = _toastQueue.removeAt(0);
  }

  /// يُنادى حين ينتهي عرض الإشعار الحالي ليظهر التالي إن وُجد
  void dismissStampToast() {
    stampToast.value = null;
    _pumpToast();
  }
}
