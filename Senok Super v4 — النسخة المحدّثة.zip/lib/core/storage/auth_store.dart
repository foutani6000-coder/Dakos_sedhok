import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthStore {
  AuthStore._();
  static const _storage = FlutterSecureStorage();
  static const _tokenKey = 'sard_access_token';
  static const _userKey = 'sard_user_json';

  static Future<String?> token() => _storage.read(key: _tokenKey);
  static Future<void> save(String token, {String? userJson}) async {
    await _storage.write(key: _tokenKey, value: token);
    if (userJson != null) await _storage.write(key: _userKey, value: userJson);
  }
  static Future<String?> userJson() => _storage.read(key: _userKey);
  static Future<void> clear() async {
    await _storage.delete(key: _tokenKey);
    await _storage.delete(key: _userKey);
  }
}
