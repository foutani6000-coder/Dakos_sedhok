import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../data/models.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// محرك «الرائج» — TrendingEngine
/// قواعد ثابتة وشفافة (لا ذكاء اصطناعي):
///
///  النقاط = شعبية المشاهدات (0..45) + التقييم (0..25)
///          + الحداثة (0..15) + الزخم المقدَّر (0..15)
///
/// الزخم المقدَّر: السيرفر لا يرسل مشاهدات يومية، لذا تُقدَّر سرعة
/// الانتشار من رقم العمل الثابت (seed) — حتمية وقابلة للاختبار،
/// ويُذكر في الواجهة أنها تقدير. حين يوفّر السيرفر مشاهدات يومية
/// تُستبدل هذه النقاط ببيانات حقيقية دون تغيير الواجهة.
/// ──────────────────────────────────────────────────────────────────────────

/// الفترة الزمنية لقائمة الرائج.
enum TrendingPeriod {
  today('اليوم', 1),
  week('هذا الأسبوع', 7),
  month('هذا الشهر', 30),
  allTime('كل الأوقات', 36500);

  const TrendingPeriod(this.label, this.windowDays);

  /// التسمية العربية.
  final String label;

  /// طول النافذة بالأيام (يؤثر في وزن الحداثة والزخم).
  final int windowDays;

  /// هل الفترة قصيرة (يوم/أسبوع)؟ الزخم فيها أهم من التراكم.
  bool get isShort => windowDays <= 7;
}

/// عمل مع نقاط الرائج وتفصيلها.
@immutable
class TrendingEntry {
  const TrendingEntry({
    required this.series,
    required this.score,
    required this.viewsScore,
    required this.ratingScore,
    required this.freshnessScore,
    required this.momentumScore,
    required this.rank,
    required this.period,
  });

  final Series series;

  /// مجموع النقاط (0..100).
  final double score;

  /// نقاط المشاهدات (0..45).
  final double viewsScore;

  /// نقاط التقييم (0..25).
  final double ratingScore;

  /// نقاط الحداثة (0..15).
  final double freshnessScore;

  /// نقاط الزخم المقدَّر (0..15).
  final double momentumScore;

  /// الترتيب في القائمة (يبدأ من 1).
  final int rank;

  final TrendingPeriod period;

  /// نص عربي يشرح لماذا يتصدّر («مشاهدات عالية وتقييم 9.2»).
  String get why {
    final parts = <String>[];
    if (viewsScore >= 30) parts.add('مشاهدات عالية جداً');
    if (ratingScore >= 20) {
      parts.add('تقييم ${series.rating.toStringAsFixed(1)}');
    }
    if (freshnessScore >= 10) parts.add('صدر حديثاً');
    if (momentumScore >= 11) parts.add('ينتشر بسرعة');
    if (series.isNew) parts.add('جديد');
    if (parts.isEmpty) return 'من الأكثر قراءة';
    return parts.join(' · ');
  }
}

/// محرك الرائج (دوال ثابتة حتمية).
class TrendingEngine {
  TrendingEngine._();

  /// أقصى نقاط لكل مكوّن.
  static const double viewsMax = 45;
  static const double ratingMax = 25;
  static const double freshnessMax = 15;
  static const double momentumMax = 15;

  /// يرتّب الأعمال حسب نقاط الرائج في [period].
  static List<TrendingEntry> rank(
    List<Series> all, {
    TrendingPeriod period = TrendingPeriod.week,
    DateTime? now,
    int limit = 20,
  }) {
    final current = now ?? DateTime.now();
    final entries = <TrendingEntry>[];
    for (final s in all) {
      final views = _viewsScore(s, period);
      final rating = _ratingScore(s);
      final fresh = _freshnessScore(s, current, period);
      final momentum = _momentumScore(s, period);
      final total = views + rating + fresh + momentum;
      entries.add(TrendingEntry(
        series: s,
        score: total,
        viewsScore: views,
        ratingScore: rating,
        freshnessScore: fresh,
        momentumScore: momentum,
        rank: 0,
        period: period,
      ));
    }
    entries.sort((a, b) => b.score.compareTo(a.score));
    final ranked = <TrendingEntry>[];
    final top = entries.take(limit).toList();
    for (var i = 0; i < top.length; i++) {
      final e = top[i];
      ranked.add(TrendingEntry(
        series: e.series,
        score: e.score,
        viewsScore: e.viewsScore,
        ratingScore: e.ratingScore,
        freshnessScore: e.freshnessScore,
        momentumScore: e.momentumScore,
        rank: i + 1,
        period: e.period,
      ));
    }
    return ranked;
  }

  /// نقاط المشاهدات: لوغاريتم، مع تقليل أثر التراكم في الفترات القصيرة.
  static double _viewsScore(Series s, TrendingPeriod period) {
    if (s.views <= 0) return 0;
    final base = (math.log(s.views + 1) / math.log(10000000))
        .clamp(0.0, 1.0)
        .toDouble();
    final shrink = period.isShort ? 0.8 : 1.0;
    return base * viewsMax * shrink;
  }

  /// نقاط التقييم: 10 = كامل، 7 = ثلث تقريباً، أقل من 6 = صفر.
  static double _ratingScore(Series s) {
    if (s.rating <= 6) return 0;
    return ((s.rating - 6) / 4).clamp(0.0, 1.0).toDouble() * ratingMax;
  }

  /// نقاط الحداثة: سنة الإصدار، وأقوى في الفترات القصيرة.
  static double _freshnessScore(
      Series s, DateTime now, TrendingPeriod period) {
    final age = now.year - s.year;
    var pts = 0.0;
    if (age <= 0) {
      pts = freshnessMax;
    } else if (age == 1) {
      pts = 11;
    } else if (age == 2) {
      pts = 7;
    } else if (age == 3) {
      pts = 3;
    }
    if (s.isNew) pts += 2;
    if (period == TrendingPeriod.allTime) pts *= 0.5;
    return pts.clamp(0.0, freshnessMax).toDouble();
  }

  /// زخم الانتشار المقدَّر (0..15) من رقم العمل الثابت.
  ///
  /// تُحسب سرعة يومية تقديرية: أعمال ببذرة عالية تنتشر أسرع،
  /// ويُضاعف الأثر في الفترات القصيرة. حتمي 100٪ وقابل للاختبار.
  static double _momentumScore(Series s, TrendingPeriod period) {
    // سرعة تقديرية يومية: 0..1 من البذرة، مع تفضيل الأعمال الأحدث.
    final seedFactor = ((s.seed % 1000) / 1000).toDouble();
    final chapterFactor = (s.chapters / 200).clamp(0.0, 1.0).toDouble();
    var velocity = seedFactor * 0.7 + chapterFactor * 0.3;
    if (s.isNew) velocity = (velocity + 0.25).clamp(0.0, 1.0).toDouble();
    final periodBoost = period.isShort ? 1.0 : 0.6;
    return velocity * momentumMax * periodBoost;
  }

  /// «صاعد بقوة»: زخم عالٍ وتقييم جيد (يُعرض بشارة خاصة).
  static bool isRising(TrendingEntry e) =>
      e.momentumScore >= 11 && e.series.rating >= 8;

  /// الرائج في تصنيف واحد.
  static List<TrendingEntry> topByGenre(
    List<Series> all,
    String genre, {
    TrendingPeriod period = TrendingPeriod.week,
    DateTime? now,
    int limit = 10,
  }) {
    final filtered = all.where((s) => s.genres.contains(genre)).toList();
    return rank(filtered, period: period, now: now, limit: limit);
  }

  /// الأعلى تقييماً بغض النظر عن المشاهدات.
  static List<Series> topRated(List<Series> all, {int limit = 10}) {
    final list = all.where((s) => s.rating > 0).toList()
      ..sort((a, b) => b.rating.compareTo(a.rating));
    return list.take(limit).toList();
  }

  /// الأكثر مشاهدة.
  static List<Series> mostViewed(List<Series> all, {int limit = 10}) {
    final list = List<Series>.from(all)
      ..sort((a, b) => b.views.compareTo(a.views));
    return list.take(limit).toList();
  }

  /// الجديد هذا الأسبوع (سنة حديثة أو معلَّم كجديد).
  static List<Series> freshThisWeek(List<Series> all, {DateTime? now}) {
    final current = now ?? DateTime.now();
    final list = all
        .where((s) => s.isNew || s.year >= current.year)
        .toList();
    list.sort((a, b) {
      final byYear = b.year.compareTo(a.year);
      if (byYear != 0) return byYear;
      return b.rating.compareTo(a.rating);
    });
    return list;
  }

  /// ملخص عربي لقائمة الرائج (يُعرض فوق القائمة).
  static String summaryFor(List<TrendingEntry> entries, TrendingPeriod p) {
    if (entries.isEmpty) return 'لا توجد أعمال رائجة ${p.label} بعد.';
    final top = entries.first.series;
    return 'الأكثر رواجاً ${p.label}: «${top.title}» يتصدّر بـ'
        '${formatCount(top.views)} مشاهدة وتقييم '
        '${top.rating.toStringAsFixed(1)}.';
  }
}

/// بطاقة «الرائج» المصغّرة: ترتيب + عنوان + نقاط، تُستخدم في
/// القوائم الأفقية. (الواجهة الكاملة في discover_screen.dart).
class TrendingRankLabel {
  TrendingRankLabel._();

  /// نص الترتيب: 1..3 مميزة، والبقية رقمية عادية.
  static String label(int rank) => '#$rank';

  /// هل الترتيب ضمن الثلاثة الأوائل (يُعرض بذهبي)؟
  static bool isPodium(int rank) => rank <= 3;
}
