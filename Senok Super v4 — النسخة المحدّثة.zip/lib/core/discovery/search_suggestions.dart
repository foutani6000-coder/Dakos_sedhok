import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/models.dart';
import 'taste_profile.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// اقتراحات البحث — SearchSuggestions
/// قواعد ثابتة: مطابقة بادئة/احتواء على العناوين والتصنيفات،
/// ثم اقتراحات من الذوق، ثم آخر عمليات البحث.
/// ──────────────────────────────────────────────────────────────────────────

/// مفتاح التخزين المحلي لآخر عمليات البحث.
const String kRecentQueriesPrefsKey = 'disc_recent_queries_v1';

/// أقصى عدد عمليات بحث محفوظة.
const int kRecentQueriesMax = 12;

/// نوع الاقتراح (يحدد أيقونته وسلوكه).
enum SuggestionKind {
  /// عملية بحث سابقة.
  history('عملية بحث سابقة'),
  /// عنوان عمل مطابق.
  title('عمل'),
  /// تصنيف مطابق.
  genre('تصنيف'),
  /// نوع عمل مطابق.
  type('نوع'),
  /// اقتراح شائع من الذوق.
  popular('مقترح لك');

  const SuggestionKind(this.label);
  final String label;
}

/// اقتراح واحد في قائمة البحث.
@immutable
class SearchSuggestion {
  const SearchSuggestion({
    required this.text,
    required this.kind,
    this.seriesId,
    this.subtitle,
  });

  /// النص الذي يُكتب في حقل البحث عند اختياره.
  final String text;

  final SuggestionKind kind;

  /// معرّف العمل إن كان الاقتراح عنوان عمل.
  final String? seriesId;

  /// سطر ثانوي للعرض (مثلاً «أكشن · تقييم 9.1»).
  final String? subtitle;

  @override
  bool operator ==(Object other) =>
      other is SearchSuggestion &&
      other.text == text &&
      other.kind == kind &&
      other.seriesId == seriesId;

  @override
  int get hashCode => Object.hash(text, kind, seriesId);
}

/// محرك اقتراحات البحث (دوال ثابتة حتمية).
class SearchSuggestionEngine {
  SearchSuggestionEngine._();

  /// يولّد اقتراحات لنص بحث [query] (فارغ = اقتراحات عامة).
  static List<SearchSuggestion> suggest({
    required String query,
    required List<Series> all,
    TasteProfile? profile,
    List<String> recentQueries = const [],
    int limit = 8,
  }) {
    final q = query.trim();
    final out = <SearchSuggestion>[];
    if (q.isEmpty) {
      return _generalSuggestions(
        all: all,
        profile: profile,
        recentQueries: recentQueries,
        limit: limit,
      );
    }
    final lower = q.toLowerCase();

    // 1) عمليات بحث سابقة مطابقة.
    for (final r in recentQueries) {
      if (r.toLowerCase().startsWith(lower)) {
        out.add(SearchSuggestion(text: r, kind: SuggestionKind.history));
      }
    }

    // 2) عناوين أعمال: البادئة أولاً ثم الاحتواء.
    final starts = <Series>[];
    final contains = <Series>[];
    for (final s in all) {
      final t = s.title.toLowerCase();
      if (t.startsWith(lower)) {
        starts.add(s);
      } else if (t.contains(lower)) {
        contains.add(s);
      }
    }
    starts.sort((a, b) => b.views.compareTo(a.views));
    contains.sort((a, b) => b.views.compareTo(a.views));
    for (final s in [...starts, ...contains]) {
      out.add(SearchSuggestion(
        text: s.title,
        kind: SuggestionKind.title,
        seriesId: s.id,
        subtitle: [
          if (s.genres.isNotEmpty) s.genres.first,
          if (s.rating > 0) 'تقييم ${s.rating.toStringAsFixed(1)}',
        ].join(' · '),
      ));
    }

    // 3) تصنيفات مطابقة.
    for (final g in kKnownGenres) {
      if (g.toLowerCase().contains(lower) ||
          lower.contains(g.toLowerCase())) {
        out.add(SearchSuggestion(
          text: g,
          kind: SuggestionKind.genre,
          subtitle: 'تصنيف',
        ));
      }
    }

    // 4) أنواع مطابقة.
    const types = <String>['مانهوا كورية', 'مانغا يابانية', 'مانهوا صينية'];
    for (final t in types) {
      if (t.contains(q)) {
        out.add(SearchSuggestion(
          text: t,
          kind: SuggestionKind.type,
          subtitle: 'نوع',
        ));
      }
    }

    return _dedupe(out).take(limit).toList();
  }

  /// اقتراحات عامة عند حقل بحث فارغ.
  static List<SearchSuggestion> _generalSuggestions({
    required List<Series> all,
    TasteProfile? profile,
    List<String> recentQueries = const [],
    int limit = 8,
  }) {
    final out = <SearchSuggestion>[];

    // عمليات البحث الأخيرة أولاً.
    for (final r in recentQueries.take(3)) {
      out.add(SearchSuggestion(text: r, kind: SuggestionKind.history));
    }

    // تصنيفات الذوق الأعلى.
    final p = profile ?? TasteProfile.empty;
    for (final g in p.topGenres(3)) {
      out.add(SearchSuggestion(
        text: g,
        kind: SuggestionKind.popular,
        subtitle: 'من ذوقك',
      ));
    }

    // أكثر الأعمال مشاهدة (شائع).
    final sorted = List<Series>.from(all)
      ..sort((a, b) => b.views.compareTo(a.views));
    for (final s in sorted.take(3)) {
      out.add(SearchSuggestion(
        text: s.title,
        kind: SuggestionKind.title,
        seriesId: s.id,
        subtitle: 'الأكثر مشاهدة',
      ));
    }

    // تصنيفات شائعة إن بقي مكان.
    for (final g in const ['أكشن', 'فانتازيا', 'رومانسي', 'غموض']) {
      if (out.length >= limit) break;
      if (!out.any((e) => e.text == g)) {
        out.add(SearchSuggestion(
          text: g,
          kind: SuggestionKind.popular,
          subtitle: 'تصنيف شائع',
        ));
      }
    }

    return _dedupe(out).take(limit).toList();
  }

  /// يزيل التكرار مع الحفاظ على الترتيب.
  static List<SearchSuggestion> _dedupe(List<SearchSuggestion> input) {
    final seen = <SearchSuggestion>{};
    final out = <SearchSuggestion>[];
    for (final s in input) {
      if (seen.add(s)) out.add(s);
    }
    return out;
  }

  /// يصحّح خطأ إملائياً شائعاً في نص البحث (قواعد بسيطة).
  static String normalizeQuery(String raw) {
    var q = raw.trim();
    // إزالة التشكيل (فتحة، ضمة، كسرة، شدة، سكون، تنوين).
    q = q.replaceAll(RegExp('[\u064B-\u0652\u0670]'), '');
    // توحيد الهمزات والألفات.
    q = q.replaceAll('أ', 'ا').replaceAll('إ', 'ا').replaceAll('آ', 'ا');
    q = q.replaceAll('ة', 'ه').replaceAll('ى', 'ي');
    // إزالة المسافات المكررة.
    q = q.replaceAll(RegExp(r'\s+'), ' ');
    return q.trim();
  }

  /// هل نص البحث يطابق عنوان عمل (بعد التطبيع)؟
  static bool matchesTitle(String query, Series s) {
    final q = normalizeQuery(query);
    if (q.isEmpty) return false;
    final title = normalizeQuery(s.title);
    return title.contains(q);
  }

  /// يرتّب نتائج بحث نصي: تطابق العنوان أولاً ثم التقييم.
  static List<Series> rankTextResults(String query, List<Series> all) {
    final q = normalizeQuery(query);
    if (q.isEmpty) return const [];
    final starts = <Series>[];
    final contains = <Series>[];
    for (final s in all) {
      final t = normalizeQuery(s.title);
      if (t.startsWith(q)) {
        starts.add(s);
      } else if (t.contains(q)) {
        contains.add(s);
      }
    }
    starts.sort((a, b) => b.views.compareTo(a.views));
    contains.sort((a, b) => b.rating.compareTo(a.rating));
    return [...starts, ...contains];
  }
}

/// مخزن آخر عمليات البحث (نسخة واحدة [RecentQueriesStore.i]).
class RecentQueriesStore extends ChangeNotifier {
  RecentQueriesStore._(this._prefs) {
    _readFromPrefs();
  }

  RecentQueriesStore._deferred() : _prefs = null;

  /// النسخة الوحيدة في التطبيق.
  static final RecentQueriesStore i = RecentQueriesStore._deferred();

  /// نسخة للاختبارات مبنية على تفضيلات جاهزة (متزامنة).
  factory RecentQueriesStore.testInstance(SharedPreferences prefs) =>
      RecentQueriesStore._(prefs);

  /// نسخة جديدة محمّلة من التخزين.
  static Future<RecentQueriesStore> loadNew() async =>
      RecentQueriesStore._(await SharedPreferences.getInstance());

  SharedPreferences? _prefs;
  List<String> _queries = const [];

  /// آخر عمليات البحث (الأحدث أولاً).
  List<String> get queries => List.unmodifiable(_queries);

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _readFromPrefs();
    notifyListeners();
  }

  void _readFromPrefs() {
    final raw = _prefs?.getString(kRecentQueriesPrefsKey);
    if (raw == null || raw.isEmpty) {
      _queries = const [];
      return;
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        _queries = decoded
            .map((e) => '$e'.trim())
            .where((e) => e.isNotEmpty)
            .take(kRecentQueriesMax)
            .toList();
      }
    } catch (_) {
      _queries = const [];
    }
  }

  Future<bool> _persist() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    return prefs.setString(kRecentQueriesPrefsKey, jsonEncode(_queries));
  }

  void _saveAndNotify() {
    unawaited(_persist());
    notifyListeners();
  }

  /// يضيف عملية بحث (تُنقل للأعلى إن وُجدت).
  void add(String query) {
    final q = query.trim();
    if (q.isEmpty) return;
    _queries = [q, ..._queries.where((e) => e != q)]
        .take(kRecentQueriesMax)
        .toList();
    _saveAndNotify();
  }

  /// يحذف عملية بحث واحدة.
  void remove(String query) {
    _queries = _queries.where((e) => e != query).toList();
    _saveAndNotify();
  }

  /// يمسح السجل كاملاً.
  void clear() {
    _queries = const [];
    _saveAndNotify();
  }
}

/// عبارات بحث شائعة جاهزة (تُعرض كشرائح تحت حقل البحث).
class PopularSearchPhrases {
  PopularSearchPhrases._();

  static const List<String> phrases = <String>[
    'أكشن',
    'فانتازيا',
    'رومانسي',
    'انتقام',
    'الأعلى تقييماً',
    'مكتمل',
    'جديد',
    'فنون قتالية',
    'غموض',
    'مدرسي',
  ];

  /// عبارات مخصصة حسب ذوق المستخدم (التصنيفات الأعلى أولاً).
  static List<String> forProfile(TasteProfile? profile) {
    final out = <String>[];
    final p = profile ?? TasteProfile.empty;
    out.addAll(p.topGenres(4));
    for (final phrase in phrases) {
      if (out.length >= 8) break;
      if (!out.contains(phrase)) out.add(phrase);
    }
    return out;
  }
}
