import 'dart:math' as math;

import '../data/models.dart';
import 'taste_profile.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// محرك التوصيات — RecommendationEngine
/// قواعد ثابتة وشفافة (لا ذكاء اصطناعي):
///
///  النقاط = تقارب الذوق (0..40) + تشابه مع المقروء (0..25)
///          + التقييم (0..15) + الشعبية (0..10)
///          + الحداثة (0..6) + الجديد (4) + تنويع
///
/// كل توصية تحمل أسباباً عربية قابلة للعرض («لأنك قرأت أكشن»).
/// ──────────────────────────────────────────────────────────────────────────

/// سبب واحد من أسباب التوصية.
class RecommendationReason {
  const RecommendationReason({
    required this.label,
    required this.points,
  });

  /// نص عربي قصير، مثلاً «لأنك تحب الأكشن».
  final String label;

  /// النقاط التي أضافها هذا السبب.
  final double points;

  @override
  String toString() => '$label (+${points.toStringAsFixed(0)})';
}

/// عمل مع نقاطه وأسباب ترشيحه.
class ScoredSeries {
  const ScoredSeries({
    required this.series,
    required this.score,
    required this.reasons,
  });

  final Series series;

  /// مجموع النقاط (0..100 تقريباً).
  final double score;

  /// الأسباب مرتبة من الأقوى إلى الأضعف.
  final List<RecommendationReason> reasons;

  /// أهم سببين للعرض تحت العنوان.
  List<String> get topReasonLabels =>
      reasons.take(2).map((r) => r.label).toList();

  /// نص عربي واحد يجمع الأسباب («لأنك تحب الأكشن ولأنه الأعلى تقييماً»).
  String get explanation {
    if (reasons.isEmpty) return 'مقترح لك من Senok.';
    if (reasons.length == 1) return reasons.first.label;
    final head = reasons.take(2).map((r) => r.label).join('، ');
    return '$head.';
  }
}

/// مدخلات محرك التوصيات (كلها اختيارية ما عدا القائمة).
class RecommendationInput {
  const RecommendationInput({
    required this.all,
    this.profile,
    this.followedIds = const {},
    this.readIds = const {},
    this.favoriteIds = const {},
    this.finishedIds = const {},
    this.readChapters = const {},
    this.now,
  });

  /// كل الأعمال المتاحة للترشيح.
  final List<Series> all;

  /// ملف ذوق المستخدم (إن وُجد).
  final TasteProfile? profile;

  /// الأعمال المتابَعة (تُستبعد من التوصيات افتراضياً).
  final Set<String> followedIds;

  /// الأعمال المقروءة جزئياً على الأقل.
  final Set<String> readIds;

  /// الأعمال المفضّلة.
  final Set<String> favoriteIds;

  /// الأعمال المكتملة قراءتها.
  final Set<String> finishedIds;

  /// معرّف العمل ← عدد الفصول المقروءة منه.
  final Map<String, int> readChapters;

  /// «الآن» (للاختبارات؛ الافتراضي DateTime.now()).
  final DateTime? now;
}

/// محرك توصيات قواعدي خالص (دوال ثابتة، حتمية، قابلة للاختبار).
class RecommendationEngine {
  RecommendationEngine._();

  /// أقصى نقاط لكل مكوّن (المجموع النظري 100).
  static const double tasteMax = 40;
  static const double similarityMax = 25;
  static const double ratingMax = 15;
  static const double popularityMax = 10;
  static const double freshnessMax = 6;
  static const double newBonus = 4;

  /// يرشّح أفضل [limit] عملاً من [input.all].
  ///
  /// يُستبعد افتراضياً كل ما هو متابَع أو مقروء أو مكتمل
  /// (مرّر [excludeKnown] = false لإبقائها مع خصم نقاط).
  static List<ScoredSeries> recommend(
    RecommendationInput input, {
    int limit = 12,
    bool excludeKnown = true,
  }) {
    final now = input.now ?? DateTime.now();
    final profile = input.profile ?? TasteProfile.empty;
    final readSeries = input.all
        .where((s) => input.readIds.contains(s.id))
        .toList(growable: false);
    final favoriteSeries = input.all
        .where((s) => input.favoriteIds.contains(s.id))
        .toList(growable: false);

    final scored = <ScoredSeries>[];
    for (final s in input.all) {
      final known = input.followedIds.contains(s.id) ||
          input.readIds.contains(s.id) ||
          input.finishedIds.contains(s.id);
      if (excludeKnown && known) continue;

      final reasons = <RecommendationReason>[];

      // 1) تقارب الذوق (0..40)
      final affinity = profile.affinityScore(s);
      if (affinity > 0) {
        reasons.add(RecommendationReason(
          label: _tasteLabel(s, profile),
          points: affinity * tasteMax,
        ));
      }

      // 2) تشابه مع المقروء/المفضّل (0..25)
      final sim = _similarity(s, readSeries, favoriteSeries);
      if (sim.points > 0) reasons.add(sim);

      // 3) التقييم (0..15): تقييم 10 = 15 نقطة، و5 = 0.
      if (s.rating > 0) {
        final pts = ((s.rating - 5).clamp(0.0, 5.0) / 5.0) * ratingMax;
        if (pts > 0) {
          reasons.add(RecommendationReason(
            label: 'تقييمه ${s.rating.toStringAsFixed(1)} من 10',
            points: pts,
          ));
        }
      }

      // 4) الشعبية (0..10): لوغاريتم المشاهدات.
      if (s.views > 0) {
        final pts =
            (math.log(s.views + 1) / math.log(10000000)).clamp(0.0, 1.0) *
                popularityMax;
        if (pts >= 3) {
          reasons.add(RecommendationReason(
            label: 'يقرؤه ${formatCount(s.views)} قارئ',
            points: pts,
          ));
        }
      }

      // 5) الحداثة (0..6): سنة الإصدار.
      final age = now.year - s.year;
      if (age <= 0) {
        reasons.add(const RecommendationReason(
            label: 'صدر هذا العام', points: freshnessMax));
      } else if (age == 1) {
        reasons.add(const RecommendationReason(
            label: 'صدر العام الماضي', points: 4));
      } else if (age == 2) {
        reasons.add(const RecommendationReason(
            label: 'صدر قبل عامين', points: 2));
      }

      // 6) مكافأة «جديد».
      if (s.isNew) {
        reasons.add(const RecommendationReason(
            label: 'وصل حديثاً إلى Senok', points: newBonus));
      }

      // خصم خفيف للمعروف عند عدم استبعاده.
      var total = reasons.fold<double>(0, (a, r) => a + r.points);
      if (!excludeKnown && known) {
        total *= 0.55;
        reasons.add(const RecommendationReason(
            label: 'قرأته من قبل', points: 0));
      }

      if (total <= 0) continue;
      reasons.sort((a, b) => b.points.compareTo(a.points));
      scored.add(ScoredSeries(series: s, score: total, reasons: reasons));
    }

    // تنويع: لا نسمح لأكثر من 3 أعمال من التصنيف المهيمن نفسه
    // في أول 6 نتائج، حتى لا تتكرر الاقتراحات.
    scored.sort((a, b) => b.score.compareTo(a.score));
    return _diversify(scored, limit);
  }

  /// أعمال مشابهة لعمل معيّن (تصنيفات مشتركة + النوع نفسه + التقييم).
  static List<ScoredSeries> similarTo(
    Series target,
    List<Series> all, {
    int limit = 8,
  }) {
    final out = <ScoredSeries>[];
    for (final s in all) {
      if (s.id == target.id) continue;
      final shared = s.genres.where(target.genres.contains).toList();
      if (shared.isEmpty && s.type != target.type) continue;
      final reasons = <RecommendationReason>[];
      var total = 0.0;
      if (shared.isNotEmpty) {
        final pts = shared.length * 9.0;
        total += pts;
        reasons.add(RecommendationReason(
          label: 'يشترك معه في: ${shared.take(2).join('، ')}',
          points: pts,
        ));
      }
      if (s.type == target.type) {
        total += 6;
        reasons.add(RecommendationReason(
            label: 'من النوع نفسه (${s.type})', points: 6));
      }
      if (s.rating >= 8) {
        total += 5;
        reasons.add(RecommendationReason(
          label: 'تقييمه ${s.rating.toStringAsFixed(1)}',
          points: 5,
        ));
      }
      if (s.isNew) {
        total += 3;
        reasons.add(
            const RecommendationReason(label: 'جديد', points: 3));
      }
      reasons.sort((a, b) => b.points.compareTo(a.points));
      out.add(ScoredSeries(series: s, score: total, reasons: reasons));
    }
    out.sort((a, b) => b.score.compareTo(a.score));
    return out.take(limit).toList();
  }

  /// «لأنك قرأت X» — أعمال مشابهة لآخر ما قرأه المستخدم.
  static List<ScoredSeries> becauseYouRead(
    List<Series> recentlyRead,
    List<Series> all, {
    int limit = 8,
  }) {
    if (recentlyRead.isEmpty) return const [];
    final byId = <String, ScoredSeries>{};
    for (final read in recentlyRead.take(3)) {
      for (final sim in similarTo(read, all, limit: 6)) {
        final old = byId[sim.series.id];
        if (old == null || sim.score > old.score) {
          byId[sim.series.id] = sim;
        }
      }
    }
    final out = byId.values.toList()
      ..sort((a, b) => b.score.compareTo(a.score));
    return out.take(limit).toList();
  }

  /// توصيات «قد يعجبك أيضاً» لعمل واحد (اسم بديل واضح).
  static List<ScoredSeries> alsoLike(Series target, List<Series> all,
          {int limit = 8}) =>
      similarTo(target, all, limit: limit);

  // ───────── أدوات داخلية ─────────

  static String _tasteLabel(Series s, TasteProfile profile) {
    final liked = s.genres
        .where((g) => profile.genreWeight(g) >= 6)
        .toList();
    if (liked.isNotEmpty) {
      return 'لأنك تحب «${liked.first}»';
    }
    final any = s.genres
        .where((g) => profile.genreWeight(g) > 0)
        .toList();
    if (any.isNotEmpty) {
      return 'يناسب ذوقك في «${any.first}»';
    }
    return 'مقترح حسب ذوقك';
  }

  /// تشابه عمل مع المقروء والمفضّل.
  static RecommendationReason _similarity(
    Series s,
    List<Series> readSeries,
    List<Series> favoriteSeries,
  ) {
    var best = 0.0;
    String? bestTitle;
    var fromFavorite = false;

    for (final r in readSeries) {
      final shared = s.genres.where(r.genres.contains).length;
      if (shared == 0) continue;
      final pts = shared * 6.0 + (s.type == r.type ? 3.0 : 0.0);
      if (pts > best) {
        best = pts;
        bestTitle = r.title;
      }
    }
    for (final f in favoriteSeries) {
      final shared = s.genres.where(f.genres.contains).length;
      if (shared == 0) continue;
      final pts = shared * 8.0 + (s.type == f.type ? 4.0 : 0.0);
      if (pts > best) {
        best = pts;
        bestTitle = f.title;
        fromFavorite = true;
      }
    }
    if (best <= 0 || bestTitle == null) {
      return const RecommendationReason(label: '', points: 0);
    }
    final label = fromFavorite
        ? 'يشبه مفضّلتك «$bestTitle»'
        : 'يشبه ما قرأت: «$bestTitle»';
    return RecommendationReason(
        label: label, points: best.clamp(0.0, similarityMax).toDouble());
  }

  /// تنويع النتائج: يحدّ من هيمنة تصنيف واحد على الصدارة.
  static List<ScoredSeries> _diversify(List<ScoredSeries> sorted, int limit) {
    if (sorted.length <= limit) return sorted.take(limit).toList();
    final out = <ScoredSeries>[];
    final genreCount = <String, int>{};
    final rest = <ScoredSeries>[];
    for (final item in sorted) {
      final g = item.series.genres.isEmpty
          ? '—'
          : item.series.genres.first;
      final count = genreCount[g] ?? 0;
      if (out.length < 6 && count >= 3) {
        rest.add(item);
        continue;
      }
      genreCount[g] = count + 1;
      out.add(item);
      if (out.length >= limit) break;
    }
    if (out.length < limit) {
      out.addAll(rest.take(limit - out.length));
    }
    return out.take(limit).toList();
  }
}

/// ترشيحات «مختارات المحرر» القواعدية: الأعلى تقييماً مع حداثة.
///
/// تُستخدم في قسم ثابت على شاشة الاكتشاف حين لا يوجد ذوق بعد.
class EditorPicks {
  EditorPicks._();

  /// أفضل الأعمال حسب التقييم ثم المشاهدات، مع تفضيل الحديث.
  static List<Series> pick(
    List<Series> all, {
    int limit = 6,
    DateTime? now,
  }) {
    final current = now ?? DateTime.now();
    final list = all.where((s) => s.rating >= 7.5).toList();
    list.sort((a, b) {
      final scoreA = a.rating * 10 +
          math.log(a.views + 1) +
          (current.year - a.year <= 1 ? 2 : 0);
      final scoreB = b.rating * 10 +
          math.log(b.views + 1) +
          (current.year - b.year <= 1 ? 2 : 0);
      return scoreB.compareTo(scoreA);
    });
    return list.take(limit).toList();
  }

  /// «جوهرة مخفية»: تقييم عالٍ ومشاهدات متواضعة.
  static List<Series> hiddenGems(List<Series> all, {int limit = 6}) {
    final list = all
        .where((s) => s.rating >= 8.5 && s.views < 50000)
        .toList();
    list.sort((a, b) => b.rating.compareTo(a.rating));
    return list.take(limit).toList();
  }

  /// «الأكثر فصولاً»: أعمال طويلة مكتملة لمن يحب الماراثون.
  static List<Series> marathonReads(List<Series> all, {int limit = 6}) {
    final list = all
        .where((s) => s.status == 'مكتمل' && s.chapters >= 50)
        .toList();
    list.sort((a, b) => b.chapters.compareTo(a.chapters));
    return list.take(limit).toList();
  }
}
