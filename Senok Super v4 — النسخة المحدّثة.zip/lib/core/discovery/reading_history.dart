import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/models.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// سجل القراءة — ReadingHistory
/// كل فصل يُقرأ يُسجَّل هنا (محلياً فقط): العمل، رقم الفصل، الثواني، الوقت.
/// منه تُشتق الوتيرة ووقت الإنهاء والإحصاءات والتحديات والموجز الأسبوعي.
/// ──────────────────────────────────────────────────────────────────────────

/// مفتاح التخزين المحلي للسجل.
const String kReadingHistoryPrefsKey = 'disc_reading_history_v1';

/// أقصى عدد إدخالات يُحتفظ بها (الأحدث أولاً).
const int kReadingHistoryMaxEntries = 500;

/// مفتاح يوم بصيغة YYYY-MM-DD (للمقارنة والتجميع).
String dayKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// تاريخ عربي مختصر: «26 نوفمبر 2026».
String formatSardDay(DateTime d) {
  const months = <String>[
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر',
  ];
  return '${d.day} ${months[d.month - 1]} ${d.year}';
}

/// وصف زمني نسبي: «الآن»، «قبل ساعة»، «أمس»، «قبل 3 أيام»...
String relativeDayLabel(DateTime d, {DateTime? now}) {
  final current = now ?? DateTime.now();
  final today = DateTime(current.year, current.month, current.day);
  final day = DateTime(d.year, d.month, d.day);
  final diff = today.difference(day).inDays;
  if (diff <= 0) {
    final hours = current.difference(d).inHours;
    if (hours <= 0) return 'الآن';
    if (hours == 1) return 'قبل ساعة';
    if (hours == 2) return 'قبل ساعتين';
    if (hours < 11) return 'قبل $hours ساعات';
    return 'اليوم';
  }
  if (diff == 1) return 'أمس';
  if (diff == 2) return 'قبل يومين';
  if (diff < 11) return 'قبل $diff أيام';
  if (diff < 30) return 'قبل ${(diff / 7).floor()} أسابيع';
  return formatSardDay(d);
}

/// إدخال واحد في سجل القراءة: فصل واحد قُرئ في وقت محدد.
@immutable
class ReadingHistoryEntry {
  const ReadingHistoryEntry({
    required this.seriesId,
    required this.seriesTitle,
    required this.chapter,
    required this.at,
    this.seconds = 0,
  });

  /// معرّف العمل.
  final String seriesId;

  /// عنوان العمل وقت التسجيل (للعرض دون الحاجة لذاكرة الأعمال).
  final String seriesTitle;

  /// رقم الفصل المقروء.
  final int chapter;

  /// وقت إنهاء قراءة الفصل.
  final DateTime at;

  /// ثواني القراءة التقديرية لهذا الفصل.
  final int seconds;

  /// مفتاح اليوم الذي قُرئ فيه.
  String get day => dayKey(at);

  /// هل قُرئ بعد منتصف الليل (00:00–05:00)؟ (لتحدي «بومة الليل»).
  bool get isNightOwl => at.hour < 5;

  Map<String, dynamic> toJson() => {
        'series_id': seriesId,
        'series_title': seriesTitle,
        'chapter': chapter,
        'at': at.toIso8601String(),
        'seconds': seconds,
      };

  factory ReadingHistoryEntry.fromJson(Map<String, dynamic> j) {
    return ReadingHistoryEntry(
      seriesId: '${j['series_id'] ?? ''}',
      seriesTitle: '${j['series_title'] ?? ''}',
      chapter: (j['chapter'] as num?)?.toInt() ?? 0,
      at: DateTime.tryParse('${j['at'] ?? ''}') ?? DateTime.now(),
      seconds: (j['seconds'] as num?)?.toInt() ?? 0,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is ReadingHistoryEntry &&
      other.seriesId == seriesId &&
      other.chapter == chapter &&
      other.at == at;

  @override
  int get hashCode => Object.hash(seriesId, chapter, at);
}

/// مقدّر الوتيرة ووقت الإنهاء (دوال ثابتة حتمية).
class PaceEstimator {
  PaceEstimator._();

  /// متوسط الفصول في اليوم النشط (أيام القراءة فقط).
  static double chaptersPerActiveDay({
    required int totalChapters,
    required int activeDays,
  }) {
    if (totalChapters <= 0 || activeDays <= 0) return 0;
    return totalChapters / activeDays;
  }

  /// متوسط الدقائق في الفصل الواحد (تقدير من الثواني المسجلة).
  static double minutesPerChapter({
    required int totalSeconds,
    required int totalChapters,
  }) {
    if (totalSeconds <= 0 || totalChapters <= 0) return 0;
    return totalSeconds / 60 / totalChapters;
  }

  /// أيام الإنهاء التقديرية لعدد فصول متبقٍ بالوتيرة الحالية.
  static double estimatedDaysToFinish({
    required int remainingChapters,
    required double chaptersPerDay,
  }) {
    if (remainingChapters <= 0) return 0;
    if (chaptersPerDay <= 0) return double.infinity;
    return remainingChapters / chaptersPerDay;
  }

  /// تاريخ الإنهاء التقديري.
  static DateTime? estimatedFinishDate({
    required int remainingChapters,
    required double chaptersPerDay,
    DateTime? from,
  }) {
    final days = estimatedDaysToFinish(
      remainingChapters: remainingChapters,
      chaptersPerDay: chaptersPerDay,
    );
    if (days.isInfinite) return null;
    final start = from ?? DateTime.now();
    return start.add(Duration(days: days.ceil()));
  }

  /// نص عربي لوقت الإنهاء («نحو 12 يوماً» أو «غير معروف بعد»).
  static String finishLabel({
    required int remainingChapters,
    required double chaptersPerDay,
  }) {
    final days = estimatedDaysToFinish(
      remainingChapters: remainingChapters,
      chaptersPerDay: chaptersPerDay,
    );
    if (remainingChapters <= 0) return 'أنهيت كل الفصول';
    if (days.isInfinite) return 'اقرأ بعض الفصول أولاً لنقدّر الوقت';
    final d = days.ceil();
    if (d <= 1) return 'تنهيه اليوم تقريباً';
    if (d == 2) return 'تنهيه بعد يومين تقريباً';
    if (d < 11) return 'تنهيه خلال $d أيام تقريباً';
    if (d < 30) return 'تنهيه خلال نحو ${(d / 7).ceil()} أسابيع';
    if (d < 365) return 'تنهيه خلال نحو ${(d / 30).ceil()} أشهر';
    return 'تنهيه خلال نحو ${(d / 365).toStringAsFixed(1)} سنوات';
  }

  /// متوسط فصول اليوم في آخر [days] يوماً (يشمل أيام الصفر).
  static double chaptersPerCalendarDay(
    List<ReadingHistoryEntry> entries, {
    int days = 7,
    DateTime? now,
  }) {
    if (days <= 0) return 0;
    final current = now ?? DateTime.now();
    final start = DateTime(current.year, current.month, current.day)
        .subtract(Duration(days: days - 1));
    final count = entries.where((e) => !e.at.isBefore(start)).length;
    return count / days;
  }
}

/// ملخص سجل القراءة لفترة معينة.
@immutable
class HistorySummary {
  const HistorySummary({
    required this.chapters,
    required this.seconds,
    required this.activeDays,
    required this.distinctSeries,
    required this.topSeriesTitle,
    required this.topSeriesChapters,
  });

  final int chapters;
  final int seconds;
  final int activeDays;
  final int distinctSeries;
  final String topSeriesTitle;
  final int topSeriesChapters;

  double get chaptersPerActiveDay => PaceEstimator.chaptersPerActiveDay(
        totalChapters: chapters,
        activeDays: activeDays,
      );

  double get minutesPerChapter => PaceEstimator.minutesPerChapter(
        totalSeconds: seconds,
        totalChapters: chapters,
      );

  static const HistorySummary empty = HistorySummary(
    chapters: 0,
    seconds: 0,
    activeDays: 0,
    distinctSeries: 0,
    topSeriesTitle: '',
    topSeriesChapters: 0,
  );
}

/// مخزن سجل القراءة (نسخة واحدة [ReadingHistoryStore.i]).
class ReadingHistoryStore extends ChangeNotifier {
  ReadingHistoryStore._(this._prefs) {
    _readFromPrefs();
  }

  ReadingHistoryStore._deferred() : _prefs = null;

  /// النسخة الوحيدة في التطبيق.
  static final ReadingHistoryStore i = ReadingHistoryStore._deferred();

  /// نسخة للاختبارات مبنية على تفضيلات جاهزة (متزامنة).
  factory ReadingHistoryStore.testInstance(SharedPreferences prefs) =>
      ReadingHistoryStore._(prefs);

  /// نسخة جديدة محمّلة من التخزين.
  static Future<ReadingHistoryStore> loadNew() async =>
      ReadingHistoryStore._(await SharedPreferences.getInstance());

  SharedPreferences? _prefs;
  List<ReadingHistoryEntry> _entries = const [];

  /// كل الإدخالات (الأحدث أولاً).
  List<ReadingHistoryEntry> get entries => List.unmodifiable(_entries);

  /// عدد الفصول المسجلة.
  int get totalChapters => _entries.length;

  /// إجمالي ثواني القراءة المسجلة.
  int get totalSeconds =>
      _entries.fold<int>(0, (a, e) => a + e.seconds);

  /// عدد الأيام المختلفة التي قُرئ فيها.
  int get activeDays => _entries.map((e) => e.day).toSet().length;

  /// عدد الأعمال المختلفة المقروءة.
  int get distinctSeries => _entries.map((e) => e.seriesId).toSet().length;

  /// آخر عمل قُرئ.
  ReadingHistoryEntry? get lastEntry =>
      _entries.isEmpty ? null : _entries.first;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _readFromPrefs();
    notifyListeners();
  }

  void _readFromPrefs() {
    final raw = _prefs?.getString(kReadingHistoryPrefsKey);
    if (raw == null || raw.isEmpty) {
      _entries = const [];
      return;
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        final list = decoded
            .whereType<Map>()
            .map((e) => ReadingHistoryEntry.fromJson(
                Map<String, dynamic>.from(e)))
            .toList();
        list.sort((a, b) => b.at.compareTo(a.at));
        _entries = list.take(kReadingHistoryMaxEntries).toList();
      }
    } catch (_) {
      _entries = const [];
    }
  }

  Future<bool> _persist() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    final raw = jsonEncode(_entries.map((e) => e.toJson()).toList());
    return prefs.setString(kReadingHistoryPrefsKey, raw);
  }

  void _saveAndNotify() {
    unawaited(_persist());
    notifyListeners();
  }

  /// يسجّل فصلاً مقروءاً (يتجاهل التكرار الدقيق للفصل نفسه).
  void recordRead({
    required String seriesId,
    required String seriesTitle,
    required int chapter,
    int seconds = 0,
    DateTime? at,
  }) {
    final time = at ?? DateTime.now();
    final entry = ReadingHistoryEntry(
      seriesId: seriesId,
      seriesTitle: seriesTitle,
      chapter: chapter,
      seconds: seconds,
      at: time,
    );
    if (_entries.contains(entry)) return;
    _entries = [entry, ..._entries]
        .take(kReadingHistoryMaxEntries)
        .toList();
    _saveAndNotify();
  }

  /// يسجّل فصلاً من كائن [Series] مباشرة.
  void recordSeriesChapter(Series s, int chapter, {int seconds = 0}) {
    recordRead(
      seriesId: s.id,
      seriesTitle: s.title,
      chapter: chapter,
      seconds: seconds,
    );
  }

  /// إدخالات عمل معيّن (الأحدث أولاً).
  List<ReadingHistoryEntry> entriesForSeries(String seriesId) =>
      _entries.where((e) => e.seriesId == seriesId).toList();

  /// عدد فصول عمل معيّن المقروءة.
  int chaptersReadOf(String seriesId) =>
      entriesForSeries(seriesId).length;

  /// هل قُرئ فصل معيّن من عمل معيّن؟
  bool hasRead(String seriesId, int chapter) => _entries.any(
      (e) => e.seriesId == seriesId && e.chapter == chapter);

  /// آخر فصل مقروء من عمل معيّن (الأعلى رقماً)، أو null.
  int? lastChapterOf(String seriesId) {
    var best = 0;
    for (final e in _entries) {
      if (e.seriesId == seriesId && e.chapter > best) best = e.chapter;
    }
    return best == 0 ? null : best;
  }

  /// فصول مقروءة في يوم معيّن.
  int chaptersOnDay(DateTime d) {
    final key = dayKey(d);
    return _entries.where((e) => e.day == key).length;
  }

  /// هل قُرئ أي فصل في يوم معيّن؟
  bool readOnDay(DateTime d) => chaptersOnDay(d) > 0;

  /// عدد الأيام المتتالية حتى اليوم (بما فيه إن قُرئ اليوم).
  int streak({DateTime? now}) {
    final current = now ?? DateTime.now();
    var d = DateTime(current.year, current.month, current.day);
    if (!readOnDay(d)) {
      d = d.subtract(const Duration(days: 1));
    }
    var n = 0;
    while (readOnDay(d)) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  /// إدخالات فترة معيّنة [from]..[to] (شاملة).
  List<ReadingHistoryEntry> entriesBetween(DateTime from, DateTime to) =>
      _entries
          .where((e) => !e.at.isBefore(from) && !e.at.isAfter(to))
          .toList();

  /// إدخالات آخر [days] يوماً.
  List<ReadingHistoryEntry> lastDays(int days, {DateTime? now}) {
    final current = now ?? DateTime.now();
    final start = DateTime(current.year, current.month, current.day)
        .subtract(Duration(days: days - 1));
    return entriesBetween(start, current);
  }

  /// ملخص فترة معيّنة.
  HistorySummary summaryBetween(DateTime from, DateTime to) {
    final list = entriesBetween(from, to);
    final bySeries = <String, int>{};
    final titles = <String, String>{};
    for (final e in list) {
      bySeries[e.seriesId] = (bySeries[e.seriesId] ?? 0) + 1;
      titles[e.seriesId] = e.seriesTitle;
    }
    var topId = '';
    var topCount = 0;
    for (final e in bySeries.entries) {
      if (e.value > topCount) {
        topId = e.key;
        topCount = e.value;
      }
    }
    return HistorySummary(
      chapters: list.length,
      seconds: list.fold<int>(0, (a, e) => a + e.seconds),
      activeDays: list.map((e) => e.day).toSet().length,
      distinctSeries: bySeries.length,
      topSeriesTitle: topId.isEmpty ? '' : (titles[topId] ?? ''),
      topSeriesChapters: topCount,
    );
  }

  /// ملخص آخر [days] يوماً.
  HistorySummary summaryLastDays(int days, {DateTime? now}) {
    final current = now ?? DateTime.now();
    final start = DateTime(current.year, current.month, current.day)
        .subtract(Duration(days: days - 1));
    return summaryBetween(start, current);
  }

  /// توزيع الفصول على أشهر سنة معيّنة (الشهر 1..12 ← العدد).
  Map<int, int> chaptersByMonth(int year) {
    final out = <int, int>{};
    for (var m = 1; m <= 12; m++) {
      out[m] = 0;
    }
    for (final e in _entries) {
      if (e.at.year == year) {
        out[e.at.month] = (out[e.at.month] ?? 0) + 1;
      }
    }
    return out;
  }

  /// توزيع الفصول على أيام الأسبوع (0 = الاثنين .. 6 = الأحد).
  Map<int, int> chaptersByWeekday() {
    final out = <int, int>{};
    for (var i = 0; i < 7; i++) {
      out[i] = 0;
    }
    for (final e in _entries) {
      out[(e.at.weekday - 1) % 7] =
          (out[(e.at.weekday - 1) % 7] ?? 0) + 1;
    }
    return out;
  }

  /// أكثر عمل قراءةً (المعرّف ← عدد الفصول).
  MapEntry<String, int>? get mostReadSeries {
    if (_entries.isEmpty) return null;
    final counts = <String, int>{};
    for (final e in _entries) {
      counts[e.seriesId] = (counts[e.seriesId] ?? 0) + 1;
    }
    var best = counts.entries.first;
    for (final e in counts.entries) {
      if (e.value > best.value) best = e;
    }
    return best;
  }

  /// خريطة العمل ← عدد الفصول المقروءة (لبناء ملف الذوق).
  Map<String, int> get readChaptersBySeries {
    final out = <String, int>{};
    for (final e in _entries) {
      out[e.seriesId] = (out[e.seriesId] ?? 0) + 1;
    }
    return out;
  }

  /// خريطة العمل ← آخر وقت قراءة (لبناء ملف الذوق).
  Map<String, DateTime> get lastReadAtBySeries {
    final out = <String, DateTime>{};
    for (final e in _entries) {
      final old = out[e.seriesId];
      if (old == null || e.at.isAfter(old)) out[e.seriesId] = e.at;
    }
    return out;
  }

  /// يصدّر السجل كاملاً (للنسخ الاحتياطي).
  String exportJson() =>
      jsonEncode(_entries.map((e) => e.toJson()).toList());

  /// يستورد سجلاً (يستبدل الحالي). يعيد عدد الإدخالات المستوردة.
  int importJson(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return 0;
      final list = decoded
          .whereType<Map>()
          .map((e) => ReadingHistoryEntry.fromJson(
              Map<String, dynamic>.from(e)))
          .toList();
      list.sort((a, b) => b.at.compareTo(a.at));
      _entries = list.take(kReadingHistoryMaxEntries).toList();
      _saveAndNotify();
      return _entries.length;
    } catch (_) {
      return 0;
    }
  }

  /// يمسح السجل كاملاً.
  void clear() {
    _entries = const [];
    _saveAndNotify();
  }

  /// يحذف إدخالات عمل معيّن.
  void removeSeries(String seriesId) {
    _entries = _entries.where((e) => e.seriesId != seriesId).toList();
    _saveAndNotify();
  }
}

/// يحوّل ثواني قراءة إلى دقائق تقديرية للعرض.
int estimateMinutes(int seconds) => (seconds / 60).round();

/// يقدّر دقائق قراءة فصل واحد (5 دقائق افتراضياً للفصل الطويل).
int estimateChapterMinutes({int pages = 0}) {
  if (pages <= 0) return 5;
  // نحو 20 ثانية للصفحة.
  return math.max(1, (pages * 20 / 60).round());
}
