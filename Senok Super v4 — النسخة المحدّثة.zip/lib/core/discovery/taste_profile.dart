import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/models.dart';

/// ──────────────────────────────────────────────────────────────────────────
/// ملفّ الذوق — TasteProfile
/// يلخّص ذوق القارئ في أوزان رقمية لكل تصنيف، فيتعلّم محرك التوصيات
/// من القراءة الفعلية بدلاً من سؤال المستخدم عن تفضيلاته.
/// كل شيء قواعدي: لا ذكاء اصطناعي، لا اتصال بالسيرفر.
/// ──────────────────────────────────────────────────────────────────────────

/// مفتاح التخزين المحلي لملف الذوق.
const String kTasteProfilePrefsKey = 'disc_taste_profile_v1';

/// أعلى وزن يمكن أن يصل إليه تصنيف (0..10).
const double kTasteMaxWeight = 10;

/// كل التصنيفات المعروفة في التطبيق (من SearchFilters.genreOptions).
const List<String> kKnownGenres = <String>[
  'أكشن',
  'مغامرة',
  'دراما',
  'فانتازيا',
  'خيال علمي',
  'كوميديا',
  'غموض',
  'إثارة',
  'رعب',
  'رومانسي',
  'مدرسي',
  'فنون قتالية',
  'انتقام',
];

/// تصنيفات يصعب الخلط بينها في الاسم (أسماء بديلة من السيرفر).
const Map<String, String> kGenreAliases = <String, String>{
  'مغامرات': 'مغامرة',
  'أكشن وإثارة': 'أكشن',
  'فانتازيا وخيال': 'فانتازيا',
  'رومانسية': 'رومانسي',
  'كوميدي': 'كوميديا',
  'درامي': 'دراما',
  'رعب وإثارة': 'رعب',
  'مدرسة': 'مدرسي',
  'قتال': 'فنون قتالية',
};

/// يوحّد اسم تصنيف قادم من السيرفر أو من بيانات قديمة.
String normalizeGenre(String raw) {
  final t = raw.trim();
  if (t.isEmpty) return '';
  if (kKnownGenres.contains(t)) return t;
  return kGenreAliases[t] ?? t;
}

/// ملف ذوق غير قابل للتعديل: كل تغيير ينتج نسخة جديدة.
///
/// الوزن 0 يعني «لا اهتمام ظاهر»، و10 يعني «التصنيف المفضّل».
/// تُبنى الأوزان من القراءة الفعلية (انظر [TasteProfileBuilder])،
/// ويمكن للمستخدم ضبطها يدوياً من شاشة «ضبط ذوقي».
@immutable
class TasteProfile {
  const TasteProfile({
    this.genreWeights = const {},
    this.likedTypes = const {},
    this.dislikedGenres = const {},
    this.updatedAt,
  });

  /// وزن كل تصنيف (0..10). الغائب = 0.
  final Map<String, double> genreWeights;

  /// أنواع الأعمال المفضّلة (مثلاً «مانهوا كورية»).
  final Set<String> likedTypes;

  /// تصنيفات لا يريدها المستخدم (تُستبعد من التوصيات).
  final Set<String> dislikedGenres;

  /// آخر تحديث للملف.
  final DateTime? updatedAt;

  static const TasteProfile empty = TasteProfile();

  /// وزن تصنيف واحد (0 إن لم يكن موجوداً).
  double genreWeight(String genre) => genreWeights[normalizeGenre(genre)] ?? 0;

  /// هل يكره المستخدم هذا التصنيف؟
  bool dislikes(String genre) => dislikedGenres.contains(normalizeGenre(genre));

  /// التصنيفات مرتبة من الأعلى وزناً إلى الأقل.
  List<String> topGenres([int limit = 5]) {
    final entries = genreWeights.entries.where((e) => e.value > 0).toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries.take(limit).map((e) => e.key).toList();
  }

  /// التصنيف الأعلى وزناً، أو null إن لم يوجد أي وزن.
  String? get dominantGenre {
    final top = topGenres(1);
    return top.isEmpty ? null : top.first;
  }

  /// هل الملف فارغ تماماً (لم يُسجَّل أي ذوق بعد)؟
  bool get isEmpty =>
      genreWeights.values.every((w) => w <= 0) &&
      likedTypes.isEmpty &&
      dislikedGenres.isEmpty;

  /// عدد التصنيفات التي لها وزن إيجابي.
  int get knownGenreCount =>
      genreWeights.values.where((w) => w > 0).length;

  /// درجة تقارب عمل مع ذوق المستخدم (0..1).
  ///
  ///  • متوسط أوزان تصنيفات العمل مقسوماً على 10.
  ///  • +0.15 إن كان نوع العمل مفضّلاً (يُحدّ بحد أقصى 1).
  ///  • 0 إن احتوى العمل تصنيفاً مكروهاً.
  double affinityScore(Series s) {
    if (s.genres.any(dislikes)) return 0;
    if (s.genres.isEmpty) return likedTypes.contains(s.type) ? 0.15 : 0.05;
    var sum = 0.0;
    for (final g in s.genres) {
      sum += genreWeight(g);
    }
    var score = (sum / s.genres.length) / kTasteMaxWeight;
    if (likedTypes.contains(s.type)) score += 0.15;
    return score.clamp(0.0, 1.0);
  }

  /// هل ينصح بهذا العمل بقوة (تقارب 0.6 فأكثر)؟
  bool stronglyLikes(Series s) => affinityScore(s) >= 0.6;

  /// وصف عربي قصير لذوق المستخدم (يُعرض في شاشة الإعدادات).
  String describe() {
    if (isEmpty) return 'لم نتعرّف على ذوقك بعد — اقرأ بعض الفصول وسنقترح عليك.';
    final top = topGenres(3);
    if (top.isEmpty) return 'ذوقك قيد التكوين.';
    if (top.length == 1) return 'تميل إلى تصنيف «${top.first}».';
    if (top.length == 2) return 'تميل إلى «${top.first}» و«${top[1]}».';
    return 'تميل إلى «${top.first}» و«${top[1]}» و«${top[2]}».';
  }

  /// نسبة اكتمال الملف (كم تصنيفاً معروفاً من أصل المعروفة).
  double get completeness =>
      (knownGenreCount / kKnownGenres.length).clamp(0.0, 1.0);

  TasteProfile copyWith({
    Map<String, double>? genreWeights,
    Set<String>? likedTypes,
    Set<String>? dislikedGenres,
    DateTime? updatedAt,
  }) {
    return TasteProfile(
      genreWeights: genreWeights ?? this.genreWeights,
      likedTypes: likedTypes ?? this.likedTypes,
      dislikedGenres: dislikedGenres ?? this.dislikedGenres,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  /// نسخة بوزن جديد لتصنيف واحد (يُقصّ إلى 0..10).
  TasteProfile withGenreWeight(String genre, double weight) {
    final g = normalizeGenre(genre);
    if (g.isEmpty) return this;
    final m = Map<String, double>.from(genreWeights);
    final w = weight.clamp(0.0, kTasteMaxWeight).toDouble();
    if (w <= 0) {
      m.remove(g);
    } else {
      m[g] = w;
    }
    return copyWith(genreWeights: m, updatedAt: DateTime.now());
  }

  /// نسخة بزيادة وزن تصنيف بمقدار [delta] (يُقصّ إلى 0..10).
  TasteProfile bumpGenre(String genre, double delta) {
    return withGenreWeight(genre, genreWeight(genre) + delta);
  }

  /// نسخة تُضيف تصنيفاً إلى المكروهات (ويُصفَّر وزنه).
  TasteProfile withDisliked(String genre, bool disliked) {
    final g = normalizeGenre(genre);
    if (g.isEmpty) return this;
    final set = Set<String>.from(dislikedGenres);
    if (disliked) {
      set.add(g);
    } else {
      set.remove(g);
    }
    final next = copyWith(dislikedGenres: set, updatedAt: DateTime.now());
    return disliked ? next.withGenreWeight(g, 0) : next;
  }

  /// نسخة تُضيف نوع عمل إلى المفضّلة أو تزيله.
  TasteProfile withLikedType(String type, bool liked) {
    final set = Set<String>.from(likedTypes);
    if (liked) {
      set.add(type);
    } else {
      set.remove(type);
    }
    return copyWith(likedTypes: set, updatedAt: DateTime.now());
  }

  /// دمج ملف آخر (تُجمع الأوزان وتُقصّ إلى الحد الأقصى).
  TasteProfile merge(TasteProfile other) {
    final m = Map<String, double>.from(genreWeights);
    for (final e in other.genreWeights.entries) {
      m[e.key] = ((m[e.key] ?? 0) + e.value).clamp(0.0, kTasteMaxWeight).toDouble();
    }
    return TasteProfile(
      genreWeights: m,
      likedTypes: {...likedTypes, ...other.likedTypes},
      dislikedGenres: {...dislikedGenres, ...other.dislikedGenres},
      updatedAt: DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'genre_weights': genreWeights,
        'liked_types': likedTypes.toList(),
        'disliked_genres': dislikedGenres.toList(),
        'updated_at': updatedAt?.toIso8601String(),
      };

  factory TasteProfile.fromJson(Map<String, dynamic> j) {
    final weights = <String, double>{};
    final raw = j['genre_weights'];
    if (raw is Map) {
      raw.forEach((k, v) {
        final g = normalizeGenre('$k');
        if (g.isEmpty) return;
        final w = (v as num?)?.toDouble() ?? 0;
        if (w > 0) weights[g] = w.clamp(0.0, kTasteMaxWeight).toDouble();
      });
    }
    return TasteProfile(
      genreWeights: weights,
      likedTypes: ((j['liked_types'] as List?) ?? const [])
          .map((e) => '$e')
          .where((e) => e.isNotEmpty)
          .toSet(),
      dislikedGenres: ((j['disliked_genres'] as List?) ?? const [])
          .map((e) => normalizeGenre('$e'))
          .where((e) => e.isNotEmpty)
          .toSet(),
      updatedAt: j['updated_at'] == null
          ? null
          : DateTime.tryParse('${j['updated_at']}'),
    );
  }

  String toJsonString() => jsonEncode(toJson());

  static TasteProfile? fromJsonString(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) return TasteProfile.fromJson(decoded);
      if (decoded is Map) {
        return TasteProfile.fromJson(Map<String, dynamic>.from(decoded));
      }
    } catch (_) {
      return null;
    }
    return null;
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! TasteProfile) return false;
    if (likedTypes.length != other.likedTypes.length ||
        dislikedGenres.length != other.dislikedGenres.length ||
        genreWeights.length != other.genreWeights.length) {
      return false;
    }
    for (final e in genreWeights.entries) {
      if ((other.genreWeights[e.key] ?? -1) != e.value) return false;
    }
    return likedTypes.containsAll(other.likedTypes) &&
        dislikedGenres.containsAll(other.dislikedGenres);
  }

  @override
  int get hashCode => Object.hash(
        Object.hashAllUnordered(
            genreWeights.entries.map((e) => Object.hash(e.key, e.value))),
        Object.hashAllUnordered(likedTypes),
        Object.hashAllUnordered(dislikedGenres),
      );
}

/// يبني ملف ذوق من سجل القراءة الفعلي (قواعد ثابتة وشفافة):
///
///  • كل فصل مقروء يضيف 0.25 إلى كل تصنيف من تصنيفات العمل.
///  • إكمال عمل (قراءة كل فصوله) يضيف 2.0 إضافية لتصنيفاته.
///  • تقييم عالٍ (8+) يضيف 1.5، وتقييم منخفض (أقل من 5) يخصم 1.0.
///  • الأعمال الأحدث قراءةً تُرجَّح بمعامل حداثة (آخر 30 يوماً = كامل).
///  • النوع الأكثر قراءةً يدخل المفضّلة إن تجاوز 60٪ من الفصول.
class TasteProfileBuilder {
  TasteProfileBuilder._();

  /// وزن الفصل الواحد المقروء.
  static const double chapterWeight = 0.25;

  /// مكافأة إكمال عمل كامل.
  static const double finishBonus = 2.0;

  /// مكافأة التقييم العالي (8 فأكثر من 10).
  static const double highRatingBonus = 1.5;

  /// خصم التقييم المنخفض (أقل من 5 من 10).
  static const double lowRatingPenalty = 1.0;

  /// يبني ملفاً من قوائم جاهزة.
  ///
  /// [readChapters]: معرّف العمل ← عدد الفصول المقروءة منه.
  /// [finishedIds]: الأعمال المكتملة قراءتها.
  /// [ratings]: معرّف العمل ← تقييم المستخدم (1..10).
  /// [lastReadAt]: معرّف العمل ← آخر مرة قُرئ فيها (للحداثة).
  /// [seriesById]: خريطة المعرّف ← العمل (لتصنيفاته ونوعه).
  static TasteProfile buildFromHistory({
    required Map<String, int> readChapters,
    required Map<String, Series> seriesById,
    Set<String> finishedIds = const {},
    Map<String, double> ratings = const {},
    Map<String, DateTime> lastReadAt = const {},
    DateTime? now,
  }) {
    final current = now ?? DateTime.now();
    final weights = <String, double>{};
    final typeChapters = <String, int>{};
    var totalChapters = 0;

    void add(String genre, double delta) {
      final g = normalizeGenre(genre);
      if (g.isEmpty) return;
      weights[g] = ((weights[g] ?? 0) + delta)
          .clamp(0.0, kTasteMaxWeight)
          .toDouble();
    }

    for (final entry in readChapters.entries) {
      final s = seriesById[entry.key];
      if (s == null || entry.value <= 0) continue;
      totalChapters += entry.value;
      typeChapters[s.type] = (typeChapters[s.type] ?? 0) + entry.value;

      // معامل الحداثة: قراءة حديثة (آخر 30 يوماً) بوزن كامل،
      // وتتناقص حتى 0.4 بعد 180 يوماً.
      var recency = 1.0;
      final last = lastReadAt[entry.key];
      if (last != null) {
        final days = current.difference(last).inDays;
        if (days > 30) {
          recency = (1.0 - (days - 30) / 300).clamp(0.4, 1.0).toDouble();
        }
      }
      final perChapter = chapterWeight * recency;
      for (final g in s.genres) {
        add(g, perChapter * entry.value);
      }
      if (finishedIds.contains(entry.key)) {
        for (final g in s.genres) {
          add(g, finishBonus);
        }
      }
      final rating = ratings[entry.key];
      if (rating != null) {
        if (rating >= 8) {
          for (final g in s.genres) {
            add(g, highRatingBonus);
          }
        } else if (rating < 5) {
          for (final g in s.genres) {
            add(g, -lowRatingPenalty);
          }
        }
      }
    }

    final likedTypes = <String>{};
    if (totalChapters > 0) {
      for (final e in typeChapters.entries) {
        if (e.value / totalChapters >= 0.6) likedTypes.add(e.key);
      }
    }

    return TasteProfile(
      genreWeights: weights,
      likedTypes: likedTypes,
      updatedAt: current,
    );
  }

  /// يبني ملفاً من قائمة أعمال مقروءة فقط (بدون أعداد فصول).
  static TasteProfile buildFromSeriesList(
    List<Series> read, {
    DateTime? now,
  }) {
    final chapters = <String, int>{};
    final byId = <String, Series>{};
    for (final s in read) {
      chapters[s.id] = (chapters[s.id] ?? 0) + 1;
      byId[s.id] = s;
    }
    return buildFromHistory(
      readChapters: chapters,
      seriesById: byId,
      now: now,
    );
  }
}

/// مخزن ملف الذوق: نسخة واحدة في التطبيق ([TasteProfileStore.i]).
///
/// يُحمَّل من SharedPreferences عند الإقلاع ([load])، ويُحفَظ تلقائياً
/// بعد كل تغيير. يعمل أيضاً دون تحميل (ذاكرة فقط) حتى يُحمَّل.
class TasteProfileStore extends ChangeNotifier {
  TasteProfileStore._(this._prefs) {
    _readFromPrefs();
  }

  TasteProfileStore._deferred() : _prefs = null;

  /// النسخة الوحيدة في التطبيق.
  static final TasteProfileStore i = TasteProfileStore._deferred();

  /// نسخة للاختبارات مبنية على تفضيلات جاهزة (متزامنة).
  factory TasteProfileStore.testInstance(SharedPreferences prefs) =>
      TasteProfileStore._(prefs);

  /// نسخة جديدة محمّلة من التخزين (للاستخدام خارج النسخة الوحيدة).
  static Future<TasteProfileStore> loadNew() async =>
      TasteProfileStore._(await SharedPreferences.getInstance());

  SharedPreferences? _prefs;
  TasteProfile _profile = TasteProfile.empty;

  TasteProfile get profile => _profile;

  /// يحمّل الملف من التخزين (يُنادى مرة عند الإقلاع).
  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    _readFromPrefs();
    notifyListeners();
  }

  void _readFromPrefs() {
    final raw = _prefs?.getString(kTasteProfilePrefsKey);
    _profile = TasteProfile.fromJsonString(raw) ?? TasteProfile.empty;
  }

  Future<bool> _persist() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    return prefs.setString(kTasteProfilePrefsKey, _profile.toJsonString());
  }

  void _saveAndNotify() {
    unawaited(_persist());
    notifyListeners();
  }

  /// يستبدل الملف كاملاً (مثلاً بعد استيراد نسخة احتياطية).
  void replaceProfile(TasteProfile next) {
    _profile = next;
    _saveAndNotify();
  }

  /// يحمّل ملفاً من كائن [TasteProfile] جاهز (اسم بديل واضح).
  void loadFromProfile(TasteProfile next) => replaceProfile(next);

  /// يضبط وزن تصنيف يدوياً (من شاشة «ضبط ذوقي»).
  void setGenreWeight(String genre, double weight) {
    _profile = _profile.withGenreWeight(genre, weight);
    _saveAndNotify();
  }

  /// يزيد وزن تصنيف بمقدار [delta].
  void bumpGenre(String genre, double delta) {
    _profile = _profile.bumpGenre(genre, delta);
    _saveAndNotify();
  }

  /// يعلّم تصنيفاً كمكروه أو يزيل الكره عنه.
  void setDisliked(String genre, bool disliked) {
    _profile = _profile.withDisliked(genre, disliked);
    _saveAndNotify();
  }

  /// يعلّم نوع عمل كمفضّل أو يزيله.
  void setLikedType(String type, bool liked) {
    _profile = _profile.withLikedType(type, liked);
    _saveAndNotify();
  }

  /// يسجّل قراءة فصول من عمل: يرفع أوزان تصنيفاته.
  void recordSeriesRead(Series s, {int chapters = 1}) {
    if (chapters <= 0) return;
    var next = _profile;
    for (final g in s.genres) {
      next = next.bumpGenre(g, TasteProfileBuilder.chapterWeight * chapters);
    }
    _profile = next.copyWith(updatedAt: DateTime.now());
    _saveAndNotify();
  }

  /// يسجّل تقييم مستخدم لعمل (1..10).
  void recordRating(Series s, double rating) {
    if (rating < 1 || rating > 10) return;
    var next = _profile;
    if (rating >= 8) {
      for (final g in s.genres) {
        next = next.bumpGenre(g, TasteProfileBuilder.highRatingBonus);
      }
    } else if (rating < 5) {
      for (final g in s.genres) {
        next = next.bumpGenre(g, -TasteProfileBuilder.lowRatingPenalty);
      }
    }
    _profile = next.copyWith(updatedAt: DateTime.now());
    _saveAndNotify();
  }

  /// يسجّل إكمال عمل: مكافأة إضافية لتصنيفاته.
  void recordFinished(Series s) {
    var next = _profile;
    for (final g in s.genres) {
      next = next.bumpGenre(g, TasteProfileBuilder.finishBonus);
    }
    _profile = next.copyWith(updatedAt: DateTime.now());
    _saveAndNotify();
  }

  /// يعيد بناء الملف كاملاً من سجل القراءة.
  void rebuildFromHistory({
    required Map<String, int> readChapters,
    required Map<String, Series> seriesById,
    Set<String> finishedIds = const {},
    Map<String, double> ratings = const {},
    Map<String, DateTime> lastReadAt = const {},
  }) {
    _profile = TasteProfileBuilder.buildFromHistory(
      readChapters: readChapters,
      seriesById: seriesById,
      finishedIds: finishedIds,
      ratings: ratings,
      lastReadAt: lastReadAt,
    );
    _saveAndNotify();
  }

  /// يمسح الملف ويعيد ضبطه (مع إبقاء نسخة فارغة محفوظة).
  void reset() {
    _profile = TasteProfile.empty;
    _saveAndNotify();
  }

  /// وزن تصنيف واحد (اختصار مريح للواجهات).
  double genreWeight(String genre) => _profile.genreWeight(genre);

  /// وصف عربي قصير للذوق الحالي.
  String describe() => _profile.describe();
}
