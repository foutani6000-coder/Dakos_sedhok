import '../../features/account/auth_screen.dart';
import '../../features/account/library_screen.dart';
import '../../features/account/profile_screen.dart';
import '../../features/account/shelf_screen.dart';
import '../../features/details/details_screen.dart';
import '../../features/home/catalog_screen.dart';
import '../../features/misc/chats_screen.dart';
import '../../features/misc/companion_screen.dart';
import '../../features/misc/news_detail_screen.dart';
import '../../features/misc/notifications_screen.dart';
import '../../features/misc/settings_screen.dart';
import '../../features/reader/reader_screen.dart';
import '../../features/search/search_screen.dart';
import 'package:flutter/widgets.dart';

/// يربط كل شاشة تُفتح عبر sardRoute بمعرّف شرحها في guide_content.dart.
/// شاشة غير مذكورة هنا = لا شرح تلقائي لها.
String? guideIdForPage(Widget page) {
  if (page is DetailsScreen) return 'screen.details';
  if (page is ReaderScreen) return 'screen.reader';
  if (page is CatalogScreen) return 'screen.catalog';
  if (page is SearchScreen) return 'tab.search';
  if (page is ShelfScreen) return 'screen.shelf';
  if (page is ProfileScreen) return 'screen.profile';
  if (page is LibraryScreen) return 'screen.library';
  if (page is ChatsScreen) return 'screen.chats';
  if (page is ChatScreen) return 'screen.chat';
  if (page is CompanionScreen) return 'screen.companion';
  if (page is SettingsScreen) return 'screen.settings';
  if (page is AuthScreen) return 'screen.auth';
  if (page is NotificationsScreen) return 'screen.notifications';
  if (page is NewsDetailScreen) return 'screen.news';
  return null;
}
