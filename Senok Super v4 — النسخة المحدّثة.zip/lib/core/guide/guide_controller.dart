import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'guide_content.dart';

/// طلب عرض شرح واحد.
class GuideRequest {
  GuideRequest(this.id, this.entry, {this.blocking = false, this.lift = 0});
  final String id;
  final GuideEntry entry;

  /// true = يحجب اللمس حتى يضغط المستخدم «فهمت» (يُستعمل قبل تنفيذ إجراء زر).
  final bool blocking;

  /// ارتفاع إضافي من الأسفل (مثلاً لتفادي شريط التنقل).
  final double lift;
  final Completer<void> done = Completer<void>();
}

/// عقل المساعدة: يحفظ ما شرحته سابقاً، ويدير طابور الشروحات.
class GuideController extends ChangeNotifier {
  GuideController._(this._p) {
    _seen = (_p.getStringList(_kSeen) ?? const <String>[]).toSet();
    _enabled = _p.getBool(_kEnabled) ?? true;
  }

  static const _kSeen = 'guide_seen';
  static const _kEnabled = 'guide_enabled';

  /// نسخة عامة للوصول من أي مكان (حتى من خارج شجرة الودجت).
  static late GuideController instance;

  static Future<GuideController> load() async {
    instance = GuideController._(await SharedPreferences.getInstance());
    return instance;
  }

  final SharedPreferences _p;
  late Set<String> _seen;
  late bool _enabled;

  final List<GuideRequest> _queue = <GuideRequest>[];
  GuideRequest? _current;
  int _step = 0;

  bool get enabled => _enabled;
  GuideRequest? get current => _current;
  int get step => _step;
  int get seenCount => _seen.length;
  int get totalCount => kGuide.length;

  bool hasSeen(String id) => _seen.contains(id);

  bool _queued(String id) => _current?.id == id || _queue.any((r) => r.id == id);

  /// يعرض شرح [id] إن كانت المساعدة مفعّلة ولم يره المستخدم من قبل.
  /// الـ Future يكتمل عند إغلاق الشرح (أو فوراً إن لم يلزم عرضه).
  Future<void> show(String id, {bool blocking = false, double lift = 0}) {
    final entry = kGuide[id];
    if (!_enabled || entry == null || _seen.contains(id) || _queued(id)) {
      return Future<void>.value();
    }
    final r = GuideRequest(id, entry, blocking: blocking, lift: lift);
    _queue.add(r);
    // المستخدم ضغط زراً: نؤجّل الشرح غير الحاجب الظاهر الآن ونعرض شرح الزر أولاً
    if (r.blocking && _current != null && !_current!.blocking) {
      _queue.insert(0, _current!);
      _current = null;
      _step = 0;
    }
    _pump();
    return r.done.future;
  }

  /// يشرح الزر عند أول ضغطة ثم ينفّذ [action] بعد «فهمت».
  /// وإن سبق شرحه ينفّذ [action] فوراً.
  void run(String id, VoidCallback action) {
    final entry = kGuide[id];
    if (!_enabled || entry == null || _seen.contains(id) || _queued(id)) {
      action();
      return;
    }
    show(id, blocking: true).then((_) => action());
  }

  void _pump() {
    if (_current != null || _queue.isEmpty) return;
    // الشروحات الحاجبة (قبل إجراء) تتقدّم على غيرها
    final i = _queue.indexWhere((r) => r.blocking);
    _current = _queue.removeAt(i < 0 ? 0 : i);
    _step = 0;
    notifyListeners();
  }

  /// الخطوة التالية، وعند آخر خطوة يُغلق الشرح ويُحفظ كمقروء.
  void next() {
    final c = _current;
    if (c == null) return;
    if (_step < c.entry.steps.length - 1) {
      _step++;
      notifyListeners();
    } else {
      dismiss();
    }
  }

  /// إغلاق الشرح الحالي وحفظه كمقروء.
  void dismiss() {
    final c = _current;
    if (c == null) return;
    _seen.add(c.id);
    _p.setStringList(_kSeen, _seen.toList());
    _current = null;
    _step = 0;
    if (!c.done.isCompleted) c.done.complete();
    _pump();
    notifyListeners();
  }

  /// يغلق الشرح الحالي ويوقف المساعدة بالكامل (يمكن إعادتها من الإعدادات).
  void stopAll() {
    _enabled = false;
    _p.setBool(_kEnabled, false);
    final pending = <GuideRequest>[if (_current != null) _current!, ..._queue];
    _queue.clear();
    _current = null;
    _step = 0;
    for (final r in pending) {
      if (!r.done.isCompleted) r.done.complete();
    }
    notifyListeners();
  }

  void setEnabled(bool v) {
    if (v == _enabled) return;
    if (!v) {
      stopAll();
      return;
    }
    _enabled = true;
    _p.setBool(_kEnabled, true);
    notifyListeners();
  }

  /// يمسح ما رآه المستخدم لتعود كل الشروحات من جديد.
  void resetAll() {
    _seen.clear();
    _p.remove(_kSeen);
    _enabled = true;
    _p.setBool(_kEnabled, true);
    notifyListeners();
  }
}
