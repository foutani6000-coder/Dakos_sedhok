/// ──────────────────────────────────────────────────────────────────────────
/// حزمة إمكانية الوصول — Accessibility Suite
/// إعدادات وصول مركزية: تكبير النص، ودفء لوني مريح للعين (راحة العين)،
/// وأهداف لمس لا تقل عن 48 نقطة، وتقليل الحركة، وتباين عالٍ.
/// تُطبَّق عبر A11yScope حول شجرة الواجهة، وتُحفظ محلياً.
/// ──────────────────────────────────────────────────────────────────────────
library;

import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/theme/app_themes.dart';
import '../../widgets/sard_icons.dart';

/// نطاقات القيم المسموحة (تُطبَّق عند القراءة من JSON وعند التعيين).
const double kMinTextScale = 1.0;
const double kMaxTextScale = 2.0;
const double kMinEyeWarmth = 0.05;
const double kMaxEyeWarmth = 0.35;

/// أقل حجم مستهدف للمس (نقطة) عند تفعيل «أهداف لمس كبيرة».
const double kMinTouchTargetSize = 48.0;

/// إعدادات إمكانية الوصول (غير قابلة للتغيير — تُستبدل بنسخة جديدة).
@immutable
class A11ySettings {
  const A11ySettings({
    this.textScale = 1.0,
    this.eyeComfortWarmth = 0.18,
    this.minTouchTarget = true,
    this.reduceMotion = false,
    this.highContrast = false,
    this.boldText = false,
  });

  /// معامل تكبير النص (1.0..2.0). الافتراضي 1.0.
  final double textScale;

  /// شدة الدفء اللوني المريح للعين (0.05..0.35). الافتراضي 0.18.
  /// 0 تعني بلا طبقة دافئة؛ القيمة هنا تُستعمل شفافيةً لطبقة كهرمانية.
  final double eyeComfortWarmth;

  /// أهداف لمس كبيرة: لا يقل أي زر عن 48 نقطة.
  final bool minTouchTarget;

  /// تقليل الحركة والانتقالات.
  final bool reduceMotion;

  /// تباين عالٍ: نصوص أغمق/أفتح وحدود أوضح.
  final bool highContrast;

  /// نص عريض في كل التطبيق.
  final bool boldText;

  static const A11ySettings defaults = A11ySettings();

  A11ySettings copyWith({
    double? textScale,
    double? eyeComfortWarmth,
    bool? minTouchTarget,
    bool? reduceMotion,
    bool? highContrast,
    bool? boldText,
  }) =>
      A11ySettings(
        textScale: textScale ?? this.textScale,
        eyeComfortWarmth: eyeComfortWarmth ?? this.eyeComfortWarmth,
        minTouchTarget: minTouchTarget ?? this.minTouchTarget,
        reduceMotion: reduceMotion ?? this.reduceMotion,
        highContrast: highContrast ?? this.highContrast,
        boldText: boldText ?? this.boldText,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'text_scale': textScale,
        'eye_comfort_warmth': eyeComfortWarmth,
        'min_touch_target': minTouchTarget,
        'reduce_motion': reduceMotion,
        'high_contrast': highContrast,
        'bold_text': boldText,
      };

  /// يقرأ JSON مع تقليم النطاقات إلى الحدود المسموحة.
  factory A11ySettings.fromJson(Map<String, dynamic> j) {
    double clampScale(dynamic v, double fallback, double min, double max) {
      final d = (v as num?)?.toDouble() ?? fallback;
      if (d.isNaN) return fallback;
      return d.clamp(min, max).toDouble();
    }

    return A11ySettings(
      textScale: clampScale(
          j['text_scale'], 1.0, kMinTextScale, kMaxTextScale),
      eyeComfortWarmth: clampScale(
          j['eye_comfort_warmth'], 0.18, kMinEyeWarmth, kMaxEyeWarmth),
      minTouchTarget: j['min_touch_target'] as bool? ?? true,
      reduceMotion: j['reduce_motion'] as bool? ?? false,
      highContrast: j['high_contrast'] as bool? ?? false,
      boldText: j['bold_text'] as bool? ?? false,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is A11ySettings &&
      other.textScale == textScale &&
      other.eyeComfortWarmth == eyeComfortWarmth &&
      other.minTouchTarget == minTouchTarget &&
      other.reduceMotion == reduceMotion &&
      other.highContrast == highContrast &&
      other.boldText == boldText;

  @override
  int get hashCode => Object.hash(
        textScale,
        eyeComfortWarmth,
        minTouchTarget,
        reduceMotion,
        highContrast,
        boldText,
      );
}

// ───────────────────────── مخزن إعدادات الوصول ─────────────────────────

/// مخزن إعدادات إمكانية الوصول (المفتاح `a11y_settings_v1`).
class A11yStore extends ChangeNotifier {
  A11yStore._(this._p, this._settings);

  final SharedPreferences _p;
  A11ySettings _settings;

  /// يبني مخزناً من تفضيلات جاهزة (للاختبارات والتكامل اليدوي).
  A11yStore.forPrefs(SharedPreferences prefs) : this._(prefs, _read(prefs));

  static const String kStoreKey = 'a11y_settings_v1';

  /// يفتح المخزن من التخزين المحلي.
  static Future<A11yStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    return A11yStore._(prefs, _read(prefs));
  }

  /// نسخة للاختبارات: تبذر التفضيلات ثم تفتح المخزن.
  static Future<A11yStore> testInstance({Map<String, Object>? seed}) async {
    // ignore: invalid_use_of_visible_for_testing_member
    SharedPreferences.setMockInitialValues(seed ?? const <String, Object>{});
    final prefs = await SharedPreferences.getInstance();
    return A11yStore._(prefs, _read(prefs));
  }

  static A11ySettings _read(SharedPreferences prefs) {
    try {
      final raw = prefs.getString(kStoreKey);
      if (raw == null || raw.isEmpty) return A11ySettings.defaults;
      return A11ySettings.fromJson(
          Map<String, dynamic>.from(jsonDecode(raw) as Map));
    } catch (_) {
      return A11ySettings.defaults;
    }
  }

  Future<void> _save() async {
    await _p.setString(kStoreKey, jsonEncode(_settings.toJson()));
  }

  /// الإعدادات الحالية.
  A11ySettings get settings => _settings;

  double get textScale => _settings.textScale;
  double get eyeComfortWarmth => _settings.eyeComfortWarmth;
  bool get minTouchTarget => _settings.minTouchTarget;
  bool get reduceMotion => _settings.reduceMotion;
  bool get highContrast => _settings.highContrast;
  bool get boldText => _settings.boldText;

  /// يستبدل الإعدادات كاملة ويحفظها.
  Future<void> update(A11ySettings next) async {
    _settings = next;
    await _save();
    notifyListeners();
  }

  /// يعيد الإعدادات إلى الافتراضية.
  Future<void> reset() async {
    await update(A11ySettings.defaults);
  }

  /// يعيّن تكبير النص مع التقليم إلى 1.0..2.0.
  Future<void> setTextScale(double v) async {
    final clamped = v.isNaN ? 1.0 : v.clamp(kMinTextScale, kMaxTextScale).toDouble();
    await update(_settings.copyWith(textScale: clamped));
  }

  /// يعيّن دفء راحة العين مع التقليم إلى 0.05..0.35.
  Future<void> setEyeComfortWarmth(double v) async {
    final clamped = v.isNaN
        ? 0.18
        : v.clamp(kMinEyeWarmth, kMaxEyeWarmth).toDouble();
    await update(_settings.copyWith(eyeComfortWarmth: clamped));
  }

  /// يبدّل خياراً منطقياً واحداً بالاسم.
  Future<void> setFlag(String key, bool value) async {
    switch (key) {
      case 'min_touch_target':
        await update(_settings.copyWith(minTouchTarget: value));
      case 'reduce_motion':
        await update(_settings.copyWith(reduceMotion: value));
      case 'high_contrast':
        await update(_settings.copyWith(highContrast: value));
      case 'bold_text':
        await update(_settings.copyWith(boldText: value));
    }
  }

  /// أقل حجم لمس مطبّق حالياً (48 عند التفعيل، و0 عند الإيقاف).
  double get minTouchSize =>
      _settings.minTouchTarget ? kMinTouchTargetSize : 0;

  /// معامل تكبير النص المطبّق في MediaQuery.
  TextScaler get textScaler => TextScaler.linear(_settings.textScale);

  /// لون طبقة الدفء (كهرماني) مع شفافيتها.
  Color get eyeComfortOverlayColor =>
      const Color(0xFFFFB020).withValues(alpha: _settings.eyeComfortWarmth);
}

// ───────────────────────── تطبيق الإعدادات على الواجهة ─────────────────────────

/// يغلّف شجرة الواجهة بإعدادات الوصول: تكبير النص + طبقة دفء العين.
/// يُوضع حول MaterialApp.builder أو حول الشاشة.
class A11yScope extends StatelessWidget {
  const A11yScope({super.key, required this.store, required this.child});

  final A11yStore store;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (ctx, _) {
        final s = store.settings;
        return MediaQuery(
          data: MediaQuery.of(ctx).copyWith(
            textScaler: TextScaler.linear(s.textScale),
            // عند تفعيل تقليل الحركة، تُعطَّل حركات النظام.
            disableAnimations: s.reduceMotion,
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              child,
              // طبقة دفء خفيفة فوق كل شيء (لا تعترض اللمس).
              IgnorePointer(
                child: Container(
                  color: const Color(0xFFFFB020)
                      .withValues(alpha: s.eyeComfortWarmth),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// زر يضمن حداً أدنى لحجم اللمس (48 نقطة) عند تفعيل الإعداد.
class A11yTapTarget extends StatelessWidget {
  const A11yTapTarget({
    super.key,
    required this.child,
    this.minSize = kMinTouchTargetSize,
  });

  final Widget child;
  final double minSize;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<A11yStore>();
    if (!store.minTouchTarget) return child;
    return ConstrainedBox(
      constraints: BoxConstraints(
        minWidth: minSize,
        minHeight: minSize,
      ),
      child: child,
    );
  }
}

/// يحوّل لوناً إلى نسخة أعلى تبايناً مع لون الخلفية (تقريبي قواعدي).
Color a11yHighContrast(Color color, {required bool darkBackground}) {
  if (darkBackground) {
    // على خلفية داكنة: فتّح اللون.
    return Color.lerp(color, Colors.white, 0.45) ?? color;
  }
  // على خلفية فاتحة: غمّق اللون.
  return Color.lerp(color, Colors.black, 0.45) ?? color;
}

/// نسبة التباين التقريبية بين لونين (1..21) حسب WCAG.
double a11yContrastRatio(Color a, Color b) {
  double channel(int v) {
    final x = v / 255.0;
    if (x <= 0.03928) return x / 12.92;
    return math.pow((x + 0.055) / 1.055, 2.4).toDouble();
  }

  double lum(Color c) =>
      0.2126 * channel(c.red) +
      0.7152 * channel(c.green) +
      0.0722 * channel(c.blue);

  final l1 = lum(a);
  final l2 = lum(b);
  final hi = l1 > l2 ? l1 : l2;
  final lo = l1 > l2 ? l2 : l1;
  return (hi + 0.05) / (lo + 0.05);
}

// ───────────────────────── شاشة إعدادات الوصول ─────────────────────────

/// شاشة إعدادات إمكانية الوصول: منزلقات + مفاتيح + معاينة حية.
class A11ySettingsScreen extends StatelessWidget {
  const A11ySettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final store = context.watch<A11yStore>();
    final s = store.settings;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        backgroundColor: p.bg,
        elevation: 0,
        title: Text('إمكانية الوصول',
            style: context.ds(size: 20, color: p.text)),
        actions: [
          TextButton(
            onPressed: () => store.reset(),
            child: Text('إعادة تعيين',
                style: context.ts(size: 13.5, w: FontWeight.w700, color: p.accent)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          _A11yPreviewCard(settings: s),
          const SizedBox(height: 16),
          _A11ySectionTitle(title: 'القراءة المريحة'),
          _A11ySliderTile(
            icon: SardIcons.chrome_reader_mode_rounded,
            title: 'حجم النص',
            subtitle: 'تكبير نصوص التطبيق من 1.0 إلى 2.0',
            valueLabel: '×${s.textScale.toStringAsFixed(1)}',
            value: s.textScale,
            min: kMinTextScale,
            max: kMaxTextScale,
            divisions: 10,
            onChanged: (v) => store.setTextScale(v),
          ),
          _A11ySliderTile(
            icon: SardIcons.wb_sunny_rounded,
            title: 'راحة العين (دفء اللون)',
            subtitle: 'طبقة كهرمانية خفيفة تقلل إجهاد العين ليلاً',
            valueLabel: '${(s.eyeComfortWarmth * 100).round()}٪',
            value: s.eyeComfortWarmth,
            min: kMinEyeWarmth,
            max: kMaxEyeWarmth,
            divisions: 6,
            onChanged: (v) => store.setEyeComfortWarmth(v),
          ),
          const SizedBox(height: 8),
          _A11ySectionTitle(title: 'التفاعل'),
          _A11ySwitchTile(
            icon: SardIcons.check_circle_rounded,
            title: 'أهداف لمس كبيرة',
            subtitle: 'لا يقل أي زر عن 48 نقطة ليسهل الضغط عليه',
            value: s.minTouchTarget,
            onChanged: (v) => store.setFlag('min_touch_target', v),
          ),
          _A11ySwitchTile(
            icon: SardIcons.pause_rounded,
            title: 'تقليل الحركة',
            subtitle: 'إيقاف الحركات والانتقالات المتحركة',
            value: s.reduceMotion,
            onChanged: (v) => store.setFlag('reduce_motion', v),
          ),
          const SizedBox(height: 8),
          _A11ySectionTitle(title: 'الوضوح'),
          _A11ySwitchTile(
            icon: SardIcons.visibility_rounded,
            title: 'تباين عالٍ',
            subtitle: 'نصوص أوضح وحدود أبرز',
            value: s.highContrast,
            onChanged: (v) => store.setFlag('high_contrast', v),
          ),
          _A11ySwitchTile(
            icon: SardIcons.menu_book_rounded,
            title: 'نص عريض',
            subtitle: 'خط أثقل في كل التطبيق',
            value: s.boldText,
            onChanged: (v) => store.setFlag('bold_text', v),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: p.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SIcon(SardIcons.info_outline_rounded,
                        size: 17, color: p.accent),
                    const SizedBox(width: 8),
                    Text('كيف تُطبَّق هذه الإعدادات؟',
                        style: context.ts(
                            size: 13.5, w: FontWeight.w700, color: p.text)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  'يغلّف التطبيق مكوّن A11yScope فيطبّق تكبير النص وطبقة الدفء '
                  'وتقليل الحركة على كل الشاشات فوراً، وتُحفظ اختياراتك على جهازك.',
                  style: context.ts(size: 12.5, color: p.textDim, height: 1.8),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _A11ySectionTitle extends StatelessWidget {
  const _A11ySectionTitle({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, top: 4),
      child: Text(title, style: context.ds(size: 16, color: context.pal.text)),
    );
  }
}

/// بطاقة معاينة حية تعرض أثر الإعدادات على نص تجريبي.
class _A11yPreviewCard extends StatelessWidget {
  const _A11yPreviewCard({required this.settings});

  final A11ySettings settings;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('معاينة حية',
              style: context.ts(size: 12, w: FontWeight.w700, color: p.accent)),
          const SizedBox(height: 8),
          MediaQuery(
            data: MediaQuery.of(context).copyWith(
              textScaler: TextScaler.linear(settings.textScale),
            ),
            child: Text(
              'هكذا سيبدو النص في التطبيق: «في أعمق الظلام يولد أشد النور سطوعاً».',
              style: TextStyle(
                fontSize: 15,
                fontWeight:
                    settings.boldText ? FontWeight.w700 : FontWeight.w400,
                color: settings.highContrast
                    ? (p.brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black)
                    : p.text,
                height: 1.8,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _PreviewChip(label: 'تكبير ×${settings.textScale.toStringAsFixed(1)}'),
              const SizedBox(width: 6),
              _PreviewChip(
                  label: 'دفء ${(settings.eyeComfortWarmth * 100).round()}٪'),
              const SizedBox(width: 6),
              _PreviewChip(
                  label: settings.minTouchTarget
                      ? 'لمس 48'
                      : 'لمس عادي'),
            ],
          ),
        ],
      ),
    );
  }
}

class _PreviewChip extends StatelessWidget {
  const _PreviewChip({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: p.bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: p.border),
      ),
      child: Text(label, style: context.ts(size: 11.5, color: p.textDim)),
    );
  }
}

class _A11ySliderTile extends StatelessWidget {
  const _A11ySliderTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.valueLabel,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
  });

  final SIconData icon;
  final String title;
  final String subtitle;
  final String valueLabel;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: p.accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: SIcon(icon, size: 19, color: p.accent),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: context.ts(
                            size: 14, w: FontWeight.w700, color: p.text)),
                    Text(subtitle,
                        style: context.ts(size: 12, color: p.textDim),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: p.bg,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: p.border),
                ),
                child: Text(valueLabel,
                    style: context.ts(size: 12.5, w: FontWeight.w700, color: p.text)),
              ),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            activeColor: p.accent,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _A11ySwitchTile extends StatelessWidget {
  const _A11ySwitchTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final SIconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: p.accent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: SIcon(icon, size: 19, color: p.accent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: context.ts(
                        size: 14, w: FontWeight.w700, color: p.text)),
                Text(subtitle,
                    style: context.ts(size: 12, color: p.textDim),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: p.accent,
          ),
        ],
      ),
    );
  }
}
