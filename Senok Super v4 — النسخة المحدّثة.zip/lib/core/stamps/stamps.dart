import 'package:flutter/material.dart';

import '../../widgets/sard_icons.dart';

/// نظام الأختام: إنجازات بهوية «حبر وختم». تُمنح تلقائياً حين تتحقق شروطها،
/// وتُحفظ محلياً في [SettingsController] (تاريخ كل ختم + أيام القراءة).

/// لقطة من إحصاءات القارئ تُقاس عليها شروط الأختام.
class StampStats {
  const StampStats({
    this.chapters = 0,
    this.minutes = 0,
    this.started = 0,
    this.followed = 0,
    this.favorites = 0,
    this.recommended = 0,
    this.streak = 0,
    this.nightMinutes = 0,
    this.bestDayChapters = 0,
  });

  final int chapters;
  final int minutes;
  final int started;
  final int followed;
  final int favorites;
  final int recommended;
  final int streak;
  final int nightMinutes;
  final int bestDayChapters;
}

enum StampGroup { reading, time, streak, library, special }

extension StampGroupX on StampGroup {
  String get label => switch (this) {
        StampGroup.reading => 'القراءة',
        StampGroup.time => 'الوقت',
        StampGroup.streak => 'المواظبة',
        StampGroup.library => 'المكتبة',
        StampGroup.special => 'ختومٌ خاصة',
      };
}

/// درجة الختم: تحدّد لونه وندرته.
enum StampTier { bronze, silver, gold, legend }

extension StampTierX on StampTier {
  String get label => switch (this) {
        StampTier.bronze => 'برونزي',
        StampTier.silver => 'فضي',
        StampTier.gold => 'ذهبي',
        StampTier.legend => 'أسطوري',
      };

  Color get color => switch (this) {
        StampTier.bronze => const Color(0xFFD08A58),
        StampTier.silver => const Color(0xFFB9C4D6),
        StampTier.gold => const Color(0xFFF2C14E),
        StampTier.legend => const Color(0xFFB66DFF),
      };
}

class StampDef {
  const StampDef({
    required this.id,
    required this.title,
    required this.desc,
    required this.icon,
    required this.group,
    required this.tier,
    required this.target,
    required this.unit,
    required this.value,
  });

  final String id;
  final String title;
  final String desc;
  final SIconData icon;
  final StampGroup group;
  final StampTier tier;

  /// القيمة المطلوبة لنيل الختم، ووحدتها للعرض (فصل، دقيقة، يوم...)
  final int target;
  final String unit;

  /// يقرأ التقدّم الحالي من الإحصاءات
  final int Function(StampStats s) value;
}

/// كل الأختام. أضف ختماً جديداً بإضافة سطر هنا فقط.
final List<StampDef> kStamps = <StampDef>[
  // ── القراءة ──
  StampDef(
    id: 'first_stamp',
    title: 'الختم الأول',
    desc: 'أنهِ قراءة أول فصل لك على Senok.',
    icon: SardIcons.auto_stories_rounded,
    group: StampGroup.reading,
    tier: StampTier.bronze,
    target: 1,
    unit: 'فصل',
    value: (s) => s.chapters,
  ),
  StampDef(
    id: 'chapters_10',
    title: 'قارئ مبتدئ',
    desc: 'أنهِ قراءة 10 فصول.',
    icon: SardIcons.menu_book_rounded,
    group: StampGroup.reading,
    tier: StampTier.bronze,
    target: 10,
    unit: 'فصل',
    value: (s) => s.chapters,
  ),
  StampDef(
    id: 'chapters_50',
    title: 'قارئ نشِط',
    desc: 'أنهِ قراءة 50 فصلاً.',
    icon: SardIcons.menu_book_rounded,
    group: StampGroup.reading,
    tier: StampTier.silver,
    target: 50,
    unit: 'فصل',
    value: (s) => s.chapters,
  ),
  StampDef(
    id: 'chapters_200',
    title: 'قارئ نهِم',
    desc: 'أنهِ قراءة 200 فصل.',
    icon: SardIcons.local_fire_department_rounded,
    group: StampGroup.reading,
    tier: StampTier.gold,
    target: 200,
    unit: 'فصل',
    value: (s) => s.chapters,
  ),
  StampDef(
    id: 'chapters_500',
    title: 'خازن الحكايات',
    desc: 'أنهِ قراءة 500 فصل. حكاياتك صارت مكتبة.',
    icon: SardIcons.auto_awesome_rounded,
    group: StampGroup.reading,
    tier: StampTier.legend,
    target: 500,
    unit: 'فصل',
    value: (s) => s.chapters,
  ),

  // ── الوقت ──
  StampDef(
    id: 'time_60',
    title: 'ساعة حبر',
    desc: 'اقضِ ساعة كاملة داخل القارئ.',
    icon: SardIcons.history_rounded,
    group: StampGroup.time,
    tier: StampTier.bronze,
    target: 60,
    unit: 'دقيقة',
    value: (s) => s.minutes,
  ),
  StampDef(
    id: 'time_600',
    title: 'عشر ساعات',
    desc: 'اقضِ 10 ساعات داخل القارئ.',
    icon: SardIcons.history_rounded,
    group: StampGroup.time,
    tier: StampTier.silver,
    target: 600,
    unit: 'دقيقة',
    value: (s) => s.minutes,
  ),
  StampDef(
    id: 'time_3000',
    title: 'ساكن الصفحات',
    desc: 'اقضِ 50 ساعة داخل القارئ.',
    icon: SardIcons.bolt_rounded,
    group: StampGroup.time,
    tier: StampTier.gold,
    target: 3000,
    unit: 'دقيقة',
    value: (s) => s.minutes,
  ),

  // ── المواظبة ──
  StampDef(
    id: 'streak_3',
    title: 'بداية الشعلة',
    desc: 'اقرأ 3 أيام متتالية.',
    icon: SardIcons.local_fire_department_rounded,
    group: StampGroup.streak,
    tier: StampTier.bronze,
    target: 3,
    unit: 'يوم',
    value: (s) => s.streak,
  ),
  StampDef(
    id: 'streak_7',
    title: 'أسبوع مواظبة',
    desc: 'اقرأ 7 أيام متتالية.',
    icon: SardIcons.local_fire_department_rounded,
    group: StampGroup.streak,
    tier: StampTier.silver,
    target: 7,
    unit: 'يوم',
    value: (s) => s.streak,
  ),
  StampDef(
    id: 'streak_30',
    title: 'شهر الوفاء',
    desc: 'اقرأ 30 يوماً متتالياً.',
    icon: SardIcons.local_fire_department_rounded,
    group: StampGroup.streak,
    tier: StampTier.gold,
    target: 30,
    unit: 'يوم',
    value: (s) => s.streak,
  ),
  StampDef(
    id: 'streak_100',
    title: 'مئة يوم',
    desc: 'اقرأ 100 يوم متتالية. لا شعلة أثبت من شعلتك.',
    icon: SardIcons.auto_awesome_rounded,
    group: StampGroup.streak,
    tier: StampTier.legend,
    target: 100,
    unit: 'يوم',
    value: (s) => s.streak,
  ),

  // ── المكتبة ──
  StampDef(
    id: 'started_5',
    title: 'مستكشف',
    desc: 'ابدأ قراءة 5 أعمال مختلفة.',
    icon: SardIcons.explore_rounded,
    group: StampGroup.library,
    tier: StampTier.bronze,
    target: 5,
    unit: 'عمل',
    value: (s) => s.started,
  ),
  StampDef(
    id: 'started_20',
    title: 'رحّالة',
    desc: 'ابدأ قراءة 20 عملاً مختلفاً.',
    icon: SardIcons.explore_rounded,
    group: StampGroup.library,
    tier: StampTier.silver,
    target: 20,
    unit: 'عمل',
    value: (s) => s.started,
  ),
  StampDef(
    id: 'follow_1',
    title: 'أول متابَعة',
    desc: 'تابِع عملك الأول لتصلك فصوله الجديدة.',
    icon: SardIcons.bookmark_rounded,
    group: StampGroup.library,
    tier: StampTier.bronze,
    target: 1,
    unit: 'عمل',
    value: (s) => s.followed,
  ),
  StampDef(
    id: 'follow_10',
    title: 'جامع الحكايات',
    desc: 'تابِع 10 أعمال.',
    icon: SardIcons.collections_bookmark_rounded,
    group: StampGroup.library,
    tier: StampTier.silver,
    target: 10,
    unit: 'عمل',
    value: (s) => s.followed,
  ),
  StampDef(
    id: 'fav_5',
    title: 'ذوّاق',
    desc: 'ضع 5 أعمال في مفضلتك.',
    icon: SardIcons.favorite_rounded,
    group: StampGroup.library,
    tier: StampTier.bronze,
    target: 5,
    unit: 'عمل',
    value: (s) => s.favorites,
  ),
  StampDef(
    id: 'rec_1',
    title: 'صوت الذوق',
    desc: 'أوصِ بعملك الأول ليظهر في ملفك.',
    icon: SardIcons.thumb_up_rounded,
    group: StampGroup.library,
    tier: StampTier.bronze,
    target: 1,
    unit: 'عمل',
    value: (s) => s.recommended,
  ),
  StampDef(
    id: 'rec_5',
    title: 'ناصح أمين',
    desc: 'أوصِ بـ 5 أعمال.',
    icon: SardIcons.groups_rounded,
    group: StampGroup.library,
    tier: StampTier.silver,
    target: 5,
    unit: 'عمل',
    value: (s) => s.recommended,
  ),

  // ── خاصة ──
  StampDef(
    id: 'night_30',
    title: 'بومة الليل',
    desc: 'اقرأ 30 دقيقة بين منتصف الليل والخامسة فجراً.',
    icon: SardIcons.nightlight_round,
    group: StampGroup.special,
    tier: StampTier.silver,
    target: 30,
    unit: 'دقيقة',
    value: (s) => s.nightMinutes,
  ),
  StampDef(
    id: 'marathon_5',
    title: 'ماراثون الفصول',
    desc: 'أنهِ 5 فصول في يوم واحد.',
    icon: SardIcons.bolt_rounded,
    group: StampGroup.special,
    tier: StampTier.gold,
    target: 5,
    unit: 'فصل',
    value: (s) => s.bestDayChapters,
  ),
];

StampDef? stampById(String id) {
  for (final d in kStamps) {
    if (d.id == id) return d;
  }
  return null;
}
