import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/gestures.dart' show PointerDeviceKind;
import 'package:flutter/material.dart';

/// لون بشفافية (بدل withOpacity)
Color tint(Color c, double o) =>
    c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

/// سلوك تمرير موحّد: ارتداد ناعم على كل المنصات بدون وهج الحافة،
/// ويعمل بالسحب بالإصبع أو الماوس.
class SardScrollBehavior extends MaterialScrollBehavior {
  const SardScrollBehavior();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) => const BouncingScrollPhysics();

  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) => child;

  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.stylus,
        PointerDeviceKind.trackpad,
      };
}

/// ظل ناعم متعدد الطبقات (خفيف وعصري)
List<BoxShadow> softShadow(SardPalette p, {double strength = 1}) {
  final a = (p.isDark ? 0.30 : 0.06) * strength;
  return [
    BoxShadow(color: tint(Colors.black, a), blurRadius: 24, offset: const Offset(0, 10)),
    BoxShadow(color: tint(Colors.black, a * 0.45), blurRadius: 4, offset: const Offset(0, 1)),
    if (p.glow > 0) BoxShadow(color: tint(p.accent, 0.14 * p.glow), blurRadius: 18),
  ];
}

/// زوج الخطوط (كلاهما مدمج في الحزمة ويعمل دون إنترنت):
///  • [sardFont] = Alexandria للعناوين والأرقام الكبيرة (واسع وعريض، حضور قوي) — يُستعمل عبر ds().
///  • [sardBodyFont] = Tajawal للنصوص والواجهة (أضيق وأوضح للقراءة الطويلة) — يُستعمل عبر ts().
/// كل خط احتياطي للآخر، فلا يظهر مربّع فارغ لأي حرف نادر.
/// الأوزان: 800 عناوين رئيسية، 700 عناوين البطاقات والأقسام،
/// 600 عناوين فرعية، 500 أوصاف ونصوص ثانوية، 400 نصوص عادية.
const String sardFont = 'Alexandria';
const String sardBodyFont = 'Tajawal';

/// Tajawal أضيق وأصغر بصرياً من Alexandria بنفس المقاس (~12%)، فنكبّر مقاسه
/// قليلاً ليتوازن مع العناوين. مقاييس الخط العمودية (الصعود/الهبوط) في ملفات
/// Tajawal مضبوطة لتطابق نسبة Alexandria فيقع الخطان على نفس خط الأساس.
const double kBodyOptical = 1.1;

/// لوحة ألوان ثيم واحد.
///
/// هوية «Senok»: حبر دافئ وورق قديم مع ختم قرمزي (مثل ختم الخطّاط).
/// الألوان الأساسية دافئة (بنّي/عاجي) وليست رمادية باردة، ولون التمييز
/// قرمزي افتراضياً ويمكن للمستخدم تغييره من الإعدادات.
@immutable
class SardPalette extends ThemeExtension<SardPalette> {
  const SardPalette({
    required this.id,
    required this.name,
    required this.brightness,
    required this.bg,
    required this.surface,
    required this.surfaceHi,
    required this.border,
    required this.text,
    required this.textDim,
    required this.accent,
    required this.onAccent,
    this.gold = const Color(0xFFE9B44C),
    this.radius = 24,
    this.borderW = 1,
    this.glow = 0,
    this.glass = false,
    this.tag = '',
  });

  final String id;
  final String name;
  final Brightness brightness;
  final Color bg;
  final Color surface;
  final Color surfaceHi;
  final Color border;
  final Color text;
  final Color textDim;
  final Color accent;
  final Color onAccent;

  /// لون ثانوي ذهبي (للتقييم والنجوم والتمييز الصغير)
  final Color gold;

  /// شكل الثيم: نصف قطر الزوايا الأساسي (البطاقات والأزرار والنوافذ)
  final double radius;

  /// سماكة الإطارات
  final double borderW;

  /// شدة التوهّج حول العناصر المميّزة 0..1
  final double glow;

  /// أسطح زجاجية شفافة
  final bool glass;

  /// وصف قصير لشكل الثيم (يظهر في المنتقي)
  final String tag;

  /// زاوية أصغر/أكبر نسبةً إلى الأساس
  double r(double factor) => radius * factor;

  bool get isDark => brightness == Brightness.dark;

  @override
  SardPalette copyWith({Color? bg, Color? surface, Color? accent, Color? onAccent}) {
    return SardPalette(
      id: id,
      name: name,
      brightness: brightness,
      bg: bg ?? this.bg,
      surface: surface ?? this.surface,
      surfaceHi: surfaceHi,
      border: border,
      text: text,
      textDim: textDim,
      accent: accent ?? this.accent,
      onAccent: onAccent ?? this.onAccent,
      gold: gold,
      radius: radius,
      borderW: borderW,
      glow: glow,
      glass: glass,
      tag: tag,
    );
  }

  @override
  SardPalette lerp(ThemeExtension<SardPalette>? other, double t) {
    if (other is! SardPalette) return this;
    return SardPalette(
      id: t < 0.5 ? id : other.id,
      name: t < 0.5 ? name : other.name,
      brightness: t < 0.5 ? brightness : other.brightness,
      bg: Color.lerp(bg, other.bg, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      surfaceHi: Color.lerp(surfaceHi, other.surfaceHi, t)!,
      border: Color.lerp(border, other.border, t)!,
      text: Color.lerp(text, other.text, t)!,
      textDim: Color.lerp(textDim, other.textDim, t)!,
      accent: Color.lerp(accent, other.accent, t)!,
      onAccent: Color.lerp(onAccent, other.onAccent, t)!,
      gold: Color.lerp(gold, other.gold, t)!,
      radius: radius + (other.radius - radius) * t,
      borderW: borderW + (other.borderW - borderW) * t,
      glow: glow + (other.glow - glow) * t,
      glass: t < 0.5 ? glass : other.glass,
      tag: t < 0.5 ? tag : other.tag,
    );
  }
}

class SardThemes {
  SardThemes._();

  /// ورق: عاجي دافئ كصفحة كتاب
  static const paper = SardPalette(
    id: 'paper',
    name: 'ورق',
    brightness: Brightness.light,
    bg: Color(0xFFF5F0E6),
    surface: Color(0xFFFCFAF5),
    surfaceHi: Color(0xFFEBE4D5),
    border: Color(0xFFDED5C2),
    text: Color(0xFF1C1612),
    textDim: Color(0xFF7B6F62),
    accent: Color(0xFFE63E2A),
    onAccent: Color(0xFFFFFFFF),
    gold: Color(0xFFC98A12),
  );

  /// رمل: بيج أغمق قليلاً
  static const pearl = SardPalette(
    id: 'pearl',
    name: 'رمل',
    brightness: Brightness.light,
    bg: Color(0xFFE8DFCB),
    surface: Color(0xFFF2EBDB),
    surfaceHi: Color(0xFFDDD2BB),
    border: Color(0xFFCABDA2),
    text: Color(0xFF241C14),
    textDim: Color(0xFF6F6252),
    accent: Color(0xFFE63E2A),
    onAccent: Color(0xFFFFFFFF),
    gold: Color(0xFFB57A0C),
  );

  /// غسق: بنفسجي ليلي هادئ
  static const ash = SardPalette(
    id: 'ash',
    name: 'غسق',
    brightness: Brightness.dark,
    bg: Color(0xFF1E1B29),
    surface: Color(0xFF282437),
    surfaceHi: Color(0xFF342F47),
    border: Color(0xFF433D5A),
    text: Color(0xFFF3EFF8),
    textDim: Color(0xFFA7A0BC),
    accent: Color(0xFFFF5A3F),
    onAccent: Color(0xFFFFFFFF),
  );

  /// حبر: بنّي داكن دافئ
  static const graphite = SardPalette(
    id: 'graphite',
    name: 'حبر',
    brightness: Brightness.dark,
    bg: Color(0xFF14110F),
    surface: Color(0xFF1D1917),
    surfaceHi: Color(0xFF29231F),
    border: Color(0xFF362F2A),
    text: Color(0xFFF4EEE4),
    textDim: Color(0xFF9D9286),
    accent: Color(0xFFFF5A3F),
    onAccent: Color(0xFFFFFFFF),
  );

  /// ليل: أسود عميق (OLED) بدفء خفيف
  static const obsidian = SardPalette(
    id: 'obsidian',
    name: 'ليل',
    brightness: Brightness.dark,
    bg: Color(0xFF080706),
    surface: Color(0xFF12100E),
    surfaceHi: Color(0xFF1C1916),
    border: Color(0xFF2A2521),
    text: Color(0xFFF8F3EA),
    textDim: Color(0xFF8F857A),
    accent: Color(0xFFFF5A3F),
    onAccent: Color(0xFFFFFFFF),
  );

  // ───────── ثيمات جديدة بأشكال مختلفة ─────────

  /// محيط: أزرق بحري، زوايا كبيرة ناعمة
  static const ocean = SardPalette(
    id: 'ocean',
    name: 'محيط',
    brightness: Brightness.dark,
    bg: Color(0xFF07161F),
    surface: Color(0xFF0D2530),
    surfaceHi: Color(0xFF14354A),
    border: Color(0xFF1E4A63),
    text: Color(0xFFEAF7FB),
    textDim: Color(0xFF86AFC0),
    accent: Color(0xFF22C7D6),
    onAccent: Color(0xFF06222A),
    gold: Color(0xFFFFC857),
    radius: 28,
    borderW: 1,
    tag: 'زوايا ناعمة',
  );

  /// ساكورا: فاتح وردي، أشكال حبّة (Pill)
  static const sakura = SardPalette(
    id: 'sakura',
    name: 'ساكورا',
    brightness: Brightness.light,
    bg: Color(0xFFFFF1F4),
    surface: Color(0xFFFFFFFF),
    surfaceHi: Color(0xFFFFE0E8),
    border: Color(0xFFF6C9D5),
    text: Color(0xFF3A1824),
    textDim: Color(0xFF9A6B7A),
    accent: Color(0xFFE0457B),
    onAccent: Color(0xFFFFFFFF),
    gold: Color(0xFFE8A33D),
    radius: 34,
    borderW: 1.2,
    tag: 'حبّات مستديرة',
  );

  /// غابة: أخضر داكن، زوايا شبه حادة وإطار سميك
  static const forest = SardPalette(
    id: 'forest',
    name: 'غابة',
    brightness: Brightness.dark,
    bg: Color(0xFF0C1A12),
    surface: Color(0xFF12281B),
    surfaceHi: Color(0xFF1B3A28),
    border: Color(0xFF2B5439),
    text: Color(0xFFEAF6EC),
    textDim: Color(0xFF88AB93),
    accent: Color(0xFF3DDC84),
    onAccent: Color(0xFF05210F),
    gold: Color(0xFFE9C46A),
    radius: 8,
    borderW: 1.6,
    tag: 'حواف حادة',
  );

  /// نيون: أسود مع توهّج، زوايا متوسطة
  static const neon = SardPalette(
    id: 'neon',
    name: 'نيون',
    brightness: Brightness.dark,
    bg: Color(0xFF050509),
    surface: Color(0xFF0D0D16),
    surfaceHi: Color(0xFF171726),
    border: Color(0xFF2A2A45),
    text: Color(0xFFF2F2FF),
    textDim: Color(0xFF8C8CB0),
    accent: Color(0xFFB44CFF),
    onAccent: Color(0xFFFFFFFF),
    gold: Color(0xFF00E5FF),
    radius: 14,
    borderW: 1.4,
    glow: 0.9,
    tag: 'توهّج',
  );

  /// غروب: بنفسجي/برتقالي، أسطح زجاجية شفافة
  static const sunset = SardPalette(
    id: 'sunset',
    name: 'غروب',
    brightness: Brightness.dark,
    bg: Color(0xFF1B1030),
    surface: Color(0xFF2A1A47),
    surfaceHi: Color(0xFF3A2461),
    border: Color(0xFF58397F),
    text: Color(0xFFFFF3EA),
    textDim: Color(0xFFC2A8D8),
    accent: Color(0xFFFF8A3D),
    onAccent: Color(0xFF2A1203),
    gold: Color(0xFFFFD166),
    radius: 24,
    borderW: 1,
    glow: 0.35,
    glass: true,
    tag: 'زجاجي',
  );

  static const List<SardPalette> all = [
    paper, pearl, ash, graphite, obsidian, ocean, sakura, forest, neon, sunset,
  ];

  static SardPalette byId(String id) =>
      all.firstWhere((p) => p.id == id, orElse: () => obsidian);
}

/// ألوان التمييز المتاحة للمستخدم.
const Map<String, Color> sardAccentTones = {
  'vermilion': Color(0xFFE63E2A),
  'amber': Color(0xFFF0A21A),
  'jade': Color(0xFF0F9D75),
  'indigo': Color(0xFF5B5BEA),
  'rose': Color(0xFFE0457B),
};

const String sardDefaultAccent = 'auto';

SardPalette applyAccent(SardPalette palette, String accentId) {
  // 'auto' = لون الثيم نفسه (لكل ثيم لونه المميّز)
  if (accentId == 'auto' || !sardAccentTones.containsKey(accentId)) return palette;
  final color = sardAccentTones[accentId]!;
  // على الثيمات الداكنة نفتح اللون قليلاً ليبقى واضحاً.
  final shown = palette.isDark ? Color.lerp(color, Colors.white, 0.1)! : color;
  final onColor = shown.computeLuminance() > 0.4
      ? const Color(0xFF1A1410)
      : const Color(0xFFFFFFFF);
  return palette.copyWith(accent: shown, onAccent: onColor);
}

ThemeData buildTheme(SardPalette p) {
  final base = ThemeData(
    brightness: p.brightness,
    useMaterial3: true,
    fontFamily: sardBodyFont,
  );
  // Tajawal للنصوص، وAlexandria للعناوين الكبيرة (انظر ts() وds() أدناه).
  // letterSpacing = 0 مهم للعربية: التباعد بين الأحرف يقطع اتصالها.
  final body = base.textTheme.apply(
    fontFamily: sardBodyFont,
    fontFamilyFallback: const [sardFont],
    fontSizeFactor: kBodyOptical,
    bodyColor: p.text,
    displayColor: p.text,
  );
  TextStyle? z(TextStyle? s) => s?.copyWith(letterSpacing: 0);
  TextStyle? disp(TextStyle? s, double size, FontWeight w) => s?.copyWith(
        fontFamily: sardFont,
        fontFamilyFallback: const [sardBodyFont],
        fontSize: size,
        fontWeight: w,
        letterSpacing: 0,
      );
  final text = body.copyWith(
    displayLarge: disp(body.displayLarge, 46, FontWeight.w800),
    displayMedium: disp(body.displayMedium, 38, FontWeight.w800),
    displaySmall: disp(body.displaySmall, 32, FontWeight.w800),
    headlineLarge: disp(body.headlineLarge, 28, FontWeight.w800),
    headlineMedium: disp(body.headlineMedium, 25, FontWeight.w700),
    headlineSmall: disp(body.headlineSmall, 22, FontWeight.w700),
    titleLarge: disp(body.titleLarge, 19, FontWeight.w700),
    titleMedium: z(body.titleMedium),
    titleSmall: z(body.titleSmall),
    bodyLarge: z(body.bodyLarge),
    bodyMedium: z(body.bodyMedium),
    bodySmall: z(body.bodySmall),
    labelLarge: z(body.labelLarge),
    labelMedium: z(body.labelMedium),
    labelSmall: z(body.labelSmall),
  );
  final shape18 = RoundedRectangleBorder(borderRadius: BorderRadius.circular(p.r(0.9)));
  return base.copyWith(
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg,
    colorScheme: ColorScheme(
      brightness: p.brightness,
      primary: p.accent,
      onPrimary: p.onAccent,
      secondary: p.gold,
      onSecondary: const Color(0xFF1A1410),
      error: const Color(0xFFE5484D),
      onError: Colors.white,
      surface: p.surface,
      onSurface: p.text,
    ),
    textTheme: text,
    primaryTextTheme: text,
    splashFactory: NoSplash.splashFactory,
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: CupertinoPageTransitionsBuilder(),
      TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
    }),
    highlightColor: Colors.transparent,
    dividerColor: p.border,
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      iconTheme: IconThemeData(color: p.text),
      titleTextStyle: TextStyle(
        fontFamily: sardFont,
        fontFamilyFallback: const [sardBodyFont],
        fontSize: 20,
        fontWeight: FontWeight.w800,
        letterSpacing: 0,
        color: p.text,
      ),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(p.r(1.4))),
      ),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: p.accent,
      linearTrackColor: p.border,
      circularTrackColor: Colors.transparent,
    ),
    sliderTheme: SliderThemeData(
      activeTrackColor: p.accent,
      inactiveTrackColor: p.border,
      thumbColor: p.accent,
      overlayColor: tint(p.accent, 0.12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.accent,
        foregroundColor: p.onAccent,
        shape: shape18,
        textStyle: text.labelLarge?.copyWith(fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: p.text,
        side: BorderSide(color: p.border),
        shape: shape18,
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: p.accent),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: p.isDark ? p.surfaceHi : p.text,
      behavior: SnackBarBehavior.floating,
      elevation: 0,
      contentTextStyle: text.bodyMedium?.copyWith(
        color: p.isDark ? p.text : p.bg,
        fontWeight: FontWeight.w500,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(p.r(0.8)),
        side: BorderSide(color: p.isDark ? p.border : Colors.transparent),
      ),
    ),
    extensions: <ThemeExtension<dynamic>>[p],
  );
}

extension SardContext on BuildContext {
  SardPalette get pal => Theme.of(this).extension<SardPalette>()!;

  /// نمط نص بخط Tajawal (للنصوص العادية والواجهة). المقاس يُضرب في [kBodyOptical].
  /// بدون وزن صريح: 400 للنص العادي، و500 للنص الثانوي (الملوَّن/الخافت).
  TextStyle ts({
    double size = 14,
    FontWeight? w,
    Color? color,
    double? height,
  }) {
    final weight = w == null
        ? (color == null ? FontWeight.w400 : FontWeight.w500)
        : (w.value < 400 ? FontWeight.w400 : (w.value > 800 ? FontWeight.w800 : w));
    return Theme.of(this).textTheme.bodyMedium!.copyWith(
          fontFamily: sardBodyFont,
          fontFamilyFallback: const [sardFont],
          fontSize: size * kBodyOptical,
          fontWeight: weight,
          letterSpacing: 0,
          color: color,
          height: height,
        );
  }

  /// نمط العناوين بخط Alexandria: 800 للعناوين الرئيسية (الكبيرة)، و700 لعناوين الأقسام والبطاقات.
  TextStyle ds({
    double size = 22,
    FontWeight? w,
    Color? color,
    double? height,
  }) {
    final weight = w == null
        ? (size >= 24 ? FontWeight.w800 : FontWeight.w700)
        : (w.value < 400 ? FontWeight.w400 : (w.value > 800 ? FontWeight.w800 : w));
    return TextStyle(
      fontFamily: sardFont,
      fontFamilyFallback: const [sardBodyFont],
      fontSize: size,
      fontWeight: weight,
      letterSpacing: 0,
      color: color ?? pal.text,
      height: height ?? 1.2,
    );
  }
}
