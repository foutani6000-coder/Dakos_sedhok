// خادم سرد + لوحة الأدمن — بدون أي مكتبات خارجية (Node 18+)
// التشغيل: ADMIN_PASSWORD=كلمة_سر node server.js   ثم افتح http://localhost:3000
const dns = require('dns').promises;
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000, DB = path.join(__dirname, 'data.json');
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
let ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD) {
  if (process.env.NODE_ENV === 'production') { console.error('حدّد ADMIN_PASSWORD في الإنتاج'); process.exit(1); }
  ADMIN_PASSWORD = 'admin123'; // حساب تجريبي محلي فقط
  console.log('حساب الأدمن التجريبي المحلي  ->  المستخدم: ' + ADMIN_USER + '  كلمة السر: ' + ADMIN_PASSWORD);
}
const sameStr = (a, b) => { const x = crypto.createHash('sha256').update(String(a)).digest(), y = crypto.createHash('sha256').update(String(b)).digest(); return crypto.timingSafeEqual(x, y); };
let fails = {};
let db = fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB, 'utf8')) : { series: [], chapters: [], users: [], activity: [] };
const save = () => fs.writeFileSync(DB, JSON.stringify(db));
const id = () => crypto.randomBytes(6).toString('hex');
const adminTokens = new Set(), userTokens = new Map();
const hash = (p, s = crypto.randomBytes(8).toString('hex')) => s + ':' + crypto.scryptSync(p, s, 32).toString('hex');
const check = (p, h) => hash(p, h.split(':')[0]) === h;
const log = (uid, type, detail = '') => { db.activity.unshift({ id: id(), uid, type, detail, at: Date.now() }); db.activity.length = Math.min(db.activity.length, 5000); save(); };
const pub = u => ({ id: u.id, name: u.name, email: u.email, banned: u.banned, ban_reason: u.ban_reason, created_at: u.created_at, last_seen: u.last_seen });
const send = (res, code, body) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(body, (k, v) => typeof v === 'string' && v.startsWith('/media/') ? res.base + v : v)); };
const rel = (res, v) => typeof v === 'string' && v.startsWith(res.base + '/media/') ? v.slice(res.base.length) : v;
const body = req => new Promise(r => { let b = ''; req.on('data', c => { b += c; if (b.length > 4e6) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const bearer = req => (req.headers.authorization || '').replace('Bearer ', '');
// ===== الاستيراد من خلاصة JSON يوفرها مصدر مرخّص =====
const isPriv = ip => !process.env.IMPORT_ALLOW_PRIVATE && /^(10\.|127\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.|::1|fc|fd|fe80)/i.test(ip);
async function safeFetch(u, accept, hops = 0) {
  const x = new URL(u); if (!['http:', 'https:'].includes(x.protocol)) throw new Error('رابط غير مدعوم');
  const allow = (process.env.IMPORT_ALLOWED_HOSTS || '').split(',').map(v => v.trim()).filter(Boolean);
  if (allow.length && !allow.includes(x.hostname)) throw new Error('هذا المضيف غير مسموح (IMPORT_ALLOWED_HOSTS)');
  const { address } = await dns.lookup(x.hostname); if (isPriv(address)) throw new Error('عنوان داخلي غير مسموح');
  const r = await fetch(u, { signal: AbortSignal.timeout(30000), redirect: 'manual', headers: { Accept: accept } });
  if ([301, 302, 303, 307, 308].includes(r.status) && r.headers.get('location')) { if (hops >= 3) throw new Error('تحويلات كثيرة'); return safeFetch(new URL(r.headers.get('location'), u).href, accept, hops + 1); }
  return r;
}
async function fetchFeed(u) {
  const r = await safeFetch(u, 'application/json'); if (!r.ok) throw new Error('فشل الجلب: ' + r.status);
  const t = await r.text(); if (t.length > 2e7) throw new Error('الخلاصة كبيرة جداً');
  try { return JSON.parse(t); } catch { throw new Error('الخلاصة ليست JSON صالحاً'); }
}
// ===== التخزين المحلي للصور (نسخ بايتات الصورة كما هي دون أي ضغط) =====
const MEDIA = path.join(__dirname, 'media'); fs.mkdirSync(MEDIA, { recursive: true });
const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif' }, MIME = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', avif: 'image/avif' };
async function saveImg(url, dir, name) {
  const r = await safeFetch(url, 'image/*'); if (!r.ok) throw new Error('HTTP ' + r.status);
  const ext = EXT[(r.headers.get('content-type') || '').split(';')[0].trim()]; if (!ext) throw new Error('الرابط ليس صورة');
  const buf = Buffer.from(await r.arrayBuffer()); if (buf.length > 30e6) throw new Error('صورة أكبر من 30MB');
  fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(path.join(dir, name + '.' + ext), buf); return name + '.' + ext;
}
const retry = async fn => { for (let i = 0; ; i++) try { return await fn(); } catch (e) { if (i >= 2) throw e; await new Promise(r => setTimeout(r, 800 * (i + 1))); } };
const dirSize = d => { let n = 0; try { for (const f of fs.readdirSync(d, { withFileTypes: true })) n += f.isDirectory() ? dirSize(path.join(d, f.name)) : fs.statSync(path.join(d, f.name)).size; } catch {} return n; };
const jobs = {};
async function mirrorSeries(sid) {
  const s = db.series.find(x => x.id === sid); if (!s || (jobs[sid] && jobs[sid].running)) return;
  const job = jobs[sid] = { running: true, total: 0, done: 0, failed: 0, last: '' };
  try {
    if (/^https?:/.test(s.cover || '')) { try { const f = await retry(() => saveImg(s.cover, path.join(MEDIA, sid), 'cover')); s.cover = '/media/' + sid + '/' + f; save(); } catch (e) { job.last = 'الغلاف: ' + e.message; } }
    const todo = db.chapters.filter(c => c.series_id === sid && !c.mirrored); job.total = todo.length;
    for (const c of todo) {
      try {
        const dir = path.join(MEDIA, sid, c.id), out = new Array(c.pages.length); let i = 0;
        await Promise.all(Array.from({ length: 4 }, async () => { while (i < c.pages.length) { const k = i++, u = c.pages[k]; if (!/^https?:/.test(u)) { out[k] = u; continue; } const f = await retry(() => saveImg(u, dir, String(k + 1).padStart(3, '0'))); out[k] = '/media/' + sid + '/' + c.id + '/' + f; } }));
        c.src_pages = c.src_pages || c.pages; c.pages = out; c.mirrored = true; job.done++; save();
      } catch (e) { job.failed++; job.last = 'فصل ' + c.number + ': ' + e.message; fs.rmSync(path.join(MEDIA, sid, c.id), { recursive: true, force: true }); }
    }
  } finally { job.running = false; }
}
const okUrl = v => typeof v === 'string' && /^https?:\/\//.test(v);
// ===== صيغة التطبيق (Series/Chapter كما يقرؤها Flutter) =====
const sViews = s => db.chapters.filter(c => c.series_id === s.id).reduce((a, c) => a + (c.views || 0), 0);
const sLast = s => Math.max(s.created_at, ...db.chapters.filter(c => c.series_id === s.id).map(c => c.created_at));
const appSeries = s => ({ id: s.id, title: s.title, cover: s.cover || null, type: 'مانهوا', status: s.status === 'completed' ? 'مكتمل' : 'مستمر', chapters: db.chapters.filter(c => c.series_id === s.id).length, rating: 0, views: sViews(s), genres: s.genres || [], synopsis: s.description || '', is_new: Date.now() - sLast(s) < 7 * 864e5, year: new Date(s.created_at).getFullYear() });
const byLatest = (a, b) => sLast(b) - sLast(a), byViews = (a, b) => sViews(b) - sViews(a);
const section = (name) => { const l = [...db.series]; return (name === 'popular' || name === 'featured' ? l.sort(byViews) : l.sort(byLatest)).map(appSeries); };
const page = (l, q) => { const n = Math.max(1, +q.get('limit') || 20), pg = Math.max(1, +q.get('page') || 1); return l.slice((pg - 1) * n, pg * n); };
const ser = s => ({ ...s, chapters_count: db.chapters.filter(c => c.series_id === s.id).length });

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), p = url.pathname.replace(/\/$/, '') || '/', m = req.method;
  if (p === '/' || p === '/admin') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(fs.readFileSync(path.join(__dirname, 'admin.html'))); }
  res.base = (process.env.PUBLIC_URL || ('http://' + req.headers.host)).replace(/\/$/, '');
  let mm = p.match(/^\/media\/([a-f0-9]+)\/((?:[a-f0-9]+\/\d{3,5})|cover)\.(jpg|png|webp|gif|avif)$/);
  if (mm && req.method === 'GET') { const f = path.join(MEDIA, mm[1], mm[2] + '.' + mm[3]); if (!f.startsWith(MEDIA) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'Content-Type': MIME[mm[3]], 'Cache-Control': 'public, max-age=31536000, immutable' }); return fs.createReadStream(f).pipe(res); }
  const b = ['POST', 'PUT'].includes(m) ? await body(req) : {};
  const t = bearer(req);
  try {
    // ===== حسابات التطبيق =====
    if (m === 'POST' && p === '/auth/register') {
      if (!b.email || !b.password || b.password.length < 6) return send(res, 400, { error: 'بيانات غير صالحة' });
      if (db.users.some(u => u.email === b.email.toLowerCase())) return send(res, 409, { error: 'البريد مستخدم' });
      const u = { id: id(), name: b.name || 'قارئ', email: b.email.toLowerCase(), pass: hash(b.password), banned: false, created_at: Date.now(), last_seen: Date.now() };
      db.users.push(u); log(u.id, 'register'); const tk = crypto.randomBytes(24).toString('hex'); userTokens.set(tk, u.id);
      return send(res, 200, { token: tk, user: pub(u) });
    }
    if (m === 'POST' && p === '/auth/login') {
      const u = db.users.find(x => x.email === (b.email || '').toLowerCase());
      if (!u || !check(b.password || '', u.pass)) return send(res, 401, { error: 'بيانات الدخول خاطئة' });
      if (u.banned) return send(res, 403, { error: 'تم حظر حسابك' + (u.ban_reason ? ': ' + u.ban_reason : '') });
      u.last_seen = Date.now(); log(u.id, 'login'); const tk = crypto.randomBytes(24).toString('hex'); userTokens.set(tk, u.id);
      return send(res, 200, { token: tk, user: pub(u) });
    }
    let g;
    if (m === 'GET' && p === '/series') return send(res, 200, db.series.map(appSeries));
    if (m === 'GET' && p === '/home') return send(res, 200, { featured: section('featured').slice(0, 6), suggestions: section('suggestions').slice(0, 20), latest: section('latest').slice(0, 20), popular: section('popular').slice(0, 20) });
    if (m === 'GET' && p === '/search') {
      const q = (url.searchParams.get('q') || '').trim().toLowerCase(), csv = k => (url.searchParams.get(k) || '').split(',').map(x => x.trim()).filter(Boolean);
      const gs = csv('genres'), ex = csv('exclude'), st = url.searchParams.get('status'), yr = url.searchParams.get('year');
      let l = db.series.filter(x => (!q || (x.title + ' ' + x.description).toLowerCase().includes(q)) && gs.every(g => (x.genres || []).includes(g)) && !ex.some(g => (x.genres || []).includes(g)) && (!st || appSeries(x).status === st) && (!yr || String(new Date(x.created_at).getFullYear()) === yr));
      l.sort(url.searchParams.get('sort') === 'popular' ? byViews : byLatest); return send(res, 200, l.map(appSeries));
    }
    if (m === 'GET' && (g = p.match(/^\/catalog\/(\w+)$/))) return send(res, 200, page(section(g[1]), url.searchParams));
    if (m === 'GET' && (g = p.match(/^\/genres\/(.+)$/))) { const gn = decodeURIComponent(g[1]); return send(res, 200, page(section('latest').filter(x => x.genres.includes(gn)), url.searchParams)); }
    if (m === 'GET' && (g = p.match(/^\/series\/(\w+)\/related$/))) { const c = db.series.find(x => x.id === g[1]); return send(res, 200, page(section('popular').filter(x => c && x.id !== c.id && x.genres.some(t => (c.genres || []).includes(t))), url.searchParams)); }
    if (m === 'GET' && ['/news', '/notifications'].includes(p)) return send(res, 200, []);
    if (m === 'GET' && /^\/series\/\w+\/comments$/.test(p)) return send(res, 200, []);
    if (m === 'GET' && (g = p.match(/^\/series\/(\w+)\/chapters$/))) return send(res, 200, db.chapters.filter(c => c.series_id === g[1]).sort((a, b) => a.number - b.number).map(c => ({ number: c.number, title: c.title, pages: c.pages.length, date: new Date(c.created_at).toISOString().slice(0, 10), is_new: Date.now() - c.created_at < 3 * 864e5 })));
    if (m === 'GET' && (g = p.match(/^\/series\/(\w+)\/chapters\/([\d.]+)\/pages$/))) {
      const uid = userTokens.get(t), u = db.users.find(x => x.id === uid);
      if (u && u.banned) return send(res, 403, { error: 'تم حظر حسابك' });
      const c = db.chapters.find(x => x.series_id === g[1] && String(x.number) === g[2]); if (!c) return send(res, 404, { error: 'غير موجود' });
      if (u) { u.last_seen = Date.now(); log(u.id, 'read', `${(db.series.find(s => s.id === c.series_id) || {}).title} — فصل ${c.number}`); }
      c.views = (c.views || 0) + 1; save(); return send(res, 200, c.pages);
    }
    // ===== الأدمن =====
    if (m === 'POST' && p === '/admin/login') {
      const ip = req.socket.remoteAddress, f = fails[ip] || { n: 0, t: 0 };
      if (f.n >= 5 && Date.now() - f.t < 60000) return send(res, 429, { error: 'محاولات كثيرة، انتظر دقيقة' });
      if (!sameStr(b.username || '', ADMIN_USER) || !sameStr(b.password || '', ADMIN_PASSWORD)) { fails[ip] = { n: f.n + 1, t: Date.now() }; return send(res, 401, { error: 'بيانات الأدمن غير صحيحة' }); }
      delete fails[ip];
      const tk = crypto.randomBytes(24).toString('hex'); adminTokens.add(tk); return send(res, 200, { token: tk });
    }
    if (!p.startsWith('/admin/')) return send(res, 404, { error: 'غير موجود' });
    if (!adminTokens.has(t)) return send(res, 401, { error: 'غير مصرّح' });
    if (p === '/admin/stats') {
      const day = Date.now() - 864e5;
      return send(res, 200, { users: db.users.length, banned: db.users.filter(u => u.banned).length, active24: db.users.filter(u => u.last_seen > day).length, series: db.series.length, chapters: db.chapters.length, views: db.chapters.reduce((a, c) => a + (c.views || 0), 0), media_mb: Math.round(dirSize(MEDIA) / 1048576), recent: db.activity.slice(0, 8).map(a => ({ ...a, user: (db.users.find(u => u.id === a.uid) || {}).name })) });
    }
    if (p === '/admin/import/feed' && m === 'POST') {
      const f = await fetchFeed(b.url || ''); let s = b.series_id ? db.series.find(x => x.id === b.series_id) : db.series.find(x => f.title && x.title === String(f.title));
      if (!s) {
        if (!f.title) return send(res, 400, { error: 'الخلاصة بلا عنوان' });
        s = { id: id(), title: String(f.title), cover: okUrl(f.cover) ? f.cover : '', description: String(f.description || ''), status: f.status === 'completed' ? 'completed' : 'ongoing', genres: Array.isArray(f.genres) ? f.genres.map(String) : [], created_at: Date.now() }; db.series.push(s);
      }
      let added = 0, skipped = 0;
      for (const c of (Array.isArray(f.chapters) ? f.chapters : []).slice(0, 20000)) {
        const n = Number(c.number);
        if (!n || !Array.isArray(c.pages) || !c.pages.length || !c.pages.every(okUrl) || db.chapters.some(x => x.series_id === s.id && x.number === n)) { skipped++; continue; }
        db.chapters.push({ id: id(), series_id: s.id, number: n, title: String(c.title || ''), pages: c.pages, views: 0, created_at: Date.now() }); added++;
      }
      save(); if (b.mirror) mirrorSeries(s.id); return send(res, 200, { series_id: s.id, title: s.title, added, skipped, mirroring: !!b.mirror });
    }
    if (p === '/admin/jobs' && m === 'GET') return send(res, 200, jobs);
    if (m === 'POST' && (g = p.match(/^\/admin\/series\/(\w+)\/mirror$/))) { if (!db.series.some(x => x.id === g[1])) return send(res, 404, { error: 'غير موجود' }); mirrorSeries(g[1]); return send(res, 200, { started: true }); }
    if (p === '/admin/series' && m === 'GET') return send(res, 200, db.series.map(ser));
    if (p === '/admin/series' && m === 'POST') {
      if (!b.title) return send(res, 400, { error: 'العنوان مطلوب' });
      const s = { id: id(), title: b.title, cover: b.cover || '', description: b.description || '', status: b.status || 'ongoing', genres: b.genres || [], created_at: Date.now() };
      db.series.push(s); save(); return send(res, 200, ser(s));
    }
    if ((g = p.match(/^\/admin\/series\/(\w+)$/))) {
      const s = db.series.find(x => x.id === g[1]); if (!s) return send(res, 404, { error: 'غير موجود' });
      if (m === 'PUT') { Object.assign(s, { title: b.title ?? s.title, cover: b.cover !== undefined ? rel(res, b.cover) : s.cover, description: b.description ?? s.description, status: b.status ?? s.status, genres: b.genres ?? s.genres }); save(); return send(res, 200, ser(s)); }
      if (m === 'DELETE') { fs.rmSync(path.join(MEDIA, s.id), { recursive: true, force: true }); db.series = db.series.filter(x => x !== s); db.chapters = db.chapters.filter(c => c.series_id !== s.id); save(); return send(res, 200, { ok: true }); }
    }
    if ((g = p.match(/^\/admin\/series\/(\w+)\/chapters$/))) {
      if (m === 'GET') return send(res, 200, db.chapters.filter(c => c.series_id === g[1]).sort((a, b) => a.number - b.number));
      if (m === 'POST') {
        const n = Number(b.number); if (!n || db.chapters.some(c => c.series_id === g[1] && c.number === n)) return send(res, 400, { error: 'رقم الفصل مفقود أو مكرر' });
        const c = { id: id(), series_id: g[1], number: n, title: b.title || '', pages: b.pages || [], views: 0, created_at: Date.now() };
        db.chapters.push(c); save(); return send(res, 200, c);
      }
    }
    if (m === 'POST' && (g = p.match(/^\/admin\/series\/(\w+)\/chapters\/bulk$/))) {
      if (!db.series.some(x => x.id === g[1])) return send(res, 404, { error: 'العمل غير موجود' });
      let added = 0, skipped = 0;
      for (const c of (b.chapters || []).slice(0, 500)) {
        const n = Number(c.number);
        if (!n || !Array.isArray(c.pages) || db.chapters.some(x => x.series_id === g[1] && x.number === n)) { skipped++; continue; }
        db.chapters.push({ id: id(), series_id: g[1], number: n, title: String(c.title || ''), pages: c.pages.map(String), views: 0, created_at: Date.now() }); added++;
      }
      save(); return send(res, 200, { added, skipped });
    }
    if ((g = p.match(/^\/admin\/chapters\/(\w+)$/))) {
      const c = db.chapters.find(x => x.id === g[1]); if (!c) return send(res, 404, { error: 'غير موجود' });
      if (m === 'PUT') { Object.assign(c, { number: b.number ? Number(b.number) : c.number, title: b.title ?? c.title, pages: b.pages ? b.pages.map(u => rel(res, u)) : c.pages }); if (b.pages) c.mirrored = b.pages.every(u => !/^https?:/.test(rel(res, u))); save(); return send(res, 200, c); }
      if (m === 'DELETE') { fs.rmSync(path.join(MEDIA, c.series_id, c.id), { recursive: true, force: true }); db.chapters = db.chapters.filter(x => x !== c); save(); return send(res, 200, { ok: true }); }
    }
    if (p === '/admin/users' && m === 'GET') return send(res, 200, db.users.map(u => ({ ...pub(u), reads: db.activity.filter(a => a.uid === u.id && a.type === 'read').length })));
    if ((g = p.match(/^\/admin\/users\/(\w+)\/(ban|activity)$/)) || (g = p.match(/^\/admin\/users\/(\w+)()$/))) {
      const u = db.users.find(x => x.id === g[1]); if (!u) return send(res, 404, { error: 'غير موجود' });
      if (g[2] === 'activity') return send(res, 200, db.activity.filter(a => a.uid === u.id).slice(0, 100));
      if (g[2] === 'ban' && m === 'POST') { u.banned = !!b.banned; u.ban_reason = u.banned ? (b.reason || '') : ''; if (u.banned) for (const [k, v] of userTokens) if (v === u.id) userTokens.delete(k); log(u.id, u.banned ? 'banned' : 'unbanned', u.ban_reason); return send(res, 200, pub(u)); }
      if (m === 'DELETE') { db.users = db.users.filter(x => x !== u); db.activity = db.activity.filter(a => a.uid !== u.id); save(); return send(res, 200, { ok: true }); }
    }
    if (p === '/admin/activity') return send(res, 200, db.activity.slice(0, 200).map(a => ({ ...a, user: (db.users.find(u => u.id === a.uid) || {}).name || '—' })));
    send(res, 404, { error: 'غير موجود' });
  } catch (e) { console.error(e); send(res, 500, { error: 'خطأ في الخادم' }); }
}).listen(PORT, () => console.log('لوحة الأدمن: http://localhost:' + PORT + '/admin'));
