#!/usr/bin/env python3
"""يولّد ملصقات SVG للأختام في assets/stamps/ (مفتوح + مقفل لكل ختم).
التشغيل:  python3 scripts/gen_stamp_svgs.py
"""
import math, os

OUT = os.path.join(os.path.dirname(__file__), '..', 'assets', 'stamps')

PAL = {
    'bronze': dict(light='#F6D3B0', mid='#D08A58', dark='#8A4B22', ink='#5C2E12'),
    'silver': dict(light='#FAFCFF', mid='#B9C4D6', dark='#6F7C93', ink='#3B4557'),
    'gold':   dict(light='#FFF0B8', mid='#F2C14E', dark='#B8841A', ink='#6B4A08'),
    'legend': dict(light='#EBD3FF', mid='#B66DFF', dark='#6A2DBA', ink='#2E0F63'),
    'locked': dict(light='#ECECEF', mid='#C2C2C8', dark='#8D8D95', ink='#6A6A72'),
}

# id: (tier, motif, stars)
STAMPS = {
    'first_stamp': ('bronze', 'stamp', 0),
    'chapters_10': ('bronze', 'open_book', 1),
    'chapters_50': ('silver', 'open_book', 2),
    'chapters_200': ('gold', 'books_stack', 3),
    'chapters_500': ('legend', 'crown_book', 0),
    'time_60': ('bronze', 'hourglass', 1),
    'time_600': ('silver', 'clock', 2),
    'time_3000': ('gold', 'clock', 3),
    'streak_3': ('bronze', 'flame', 1),
    'streak_7': ('silver', 'flame', 2),
    'streak_30': ('gold', 'flame', 3),
    'streak_100': ('legend', 'flame_crown', 0),
    'started_5': ('bronze', 'compass', 1),
    'started_20': ('silver', 'compass', 2),
    'follow_1': ('bronze', 'bookmark', 0),
    'follow_10': ('silver', 'bookmarks', 0),
    'fav_5': ('bronze', 'heart', 0),
    'rec_1': ('bronze', 'thumb', 0),
    'rec_5': ('silver', 'people', 0),
    'night_30': ('silver', 'moon', 0),
    'marathon_5': ('gold', 'bolt', 0),
}


def star(cx, cy, r, fill, stroke):
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * 0.45
        pts.append(f'{cx + rr*math.cos(a):.2f},{cy + rr*math.sin(a):.2f}')
    return f'<polygon points="{" ".join(pts)}" fill="{fill}" stroke="{stroke}" stroke-width="1" stroke-linejoin="round"/>'


def burst(n, R, r):
    pts = []
    for i in range(n * 2):
        a = -math.pi / 2 + i * math.pi / n
        rr = R if i % 2 == 0 else r
        pts.append(f'{50 + rr*math.cos(a):.2f},{50 + rr*math.sin(a):.2f}')
    return 'M' + ' L'.join(pts) + ' Z'


def crown(c, dy=0):
    return (f'<g transform="translate(0 {dy})"><path d="M35 46 L38 31 L45 39 L50 28 L55 39 L62 31 L65 46 Z" '
            f'fill="{c["mid"]}" stroke="{c["ink"]}" stroke-width="2.4" stroke-linejoin="round"/>'
            f'<rect x="35" y="46" width="30" height="5" rx="2" fill="{c["dark"]}" stroke="{c["ink"]}" stroke-width="2"/>'
            f'<circle cx="38" cy="31" r="2" fill="{c["light"]}"/><circle cx="50" cy="28" r="2.2" fill="{c["light"]}"/>'
            f'<circle cx="62" cy="31" r="2" fill="{c["light"]}"/></g>')


def motif(name, c):
    I, L, M, D = c['ink'], c['light'], c['mid'], c['dark']
    sw = f'stroke="{I}" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"'
    if name == 'stamp':
        return (f'<rect x="33" y="55" width="34" height="9" rx="3" fill="{M}" {sw}/>'
                f'<path d="M43 55 L45 44 H55 L57 55 Z" fill="{L}" {sw}/>'
                f'<circle cx="50" cy="36" r="8" fill="{M}" {sw}/>'
                f'<path d="M36 69 H64" {sw} fill="none"/>')
    if name == 'open_book':
        return (f'<path d="M50 38 C44 33 34 33 27 35 V63 C34 61 44 61 50 66 C56 61 66 61 73 63 V35 C66 33 56 33 50 38 Z" fill="{L}" {sw}/>'
                f'<path d="M50 38 V66" {sw} fill="none"/>'
                f'<path d="M33 42 H44 M33 49 H44 M56 42 H67 M56 49 H67" stroke="{M}" stroke-width="2.2" stroke-linecap="round"/>')
    if name == 'books_stack':
        return (f'<rect x="30" y="55" width="40" height="10" rx="2.5" fill="{D}" {sw}/>'
                f'<rect x="34" y="44" width="34" height="10" rx="2.5" fill="{L}" {sw}/>'
                f'<rect x="31" y="33" width="36" height="10" rx="2.5" fill="{M}" {sw}/>'
                f'<path d="M36 60 H44 M40 49 H48 M37 38 H45" stroke="{I}" stroke-width="1.8" stroke-linecap="round" opacity=".6"/>')
    if name == 'crown_book':
        return (crown(c, -4) +
                f'<path d="M50 56 C45 52 37 52 31 54 V68 C37 66 45 66 50 70 C55 66 63 66 69 68 V54 C63 52 55 52 50 56 Z" fill="{L}" {sw}/>'
                f'<path d="M50 56 V70" {sw} fill="none"/>')
    if name == 'hourglass':
        return (f'<path d="M40 32 H60 V38 C60 46 54 48 52 50 C54 52 60 54 60 62 V68 H40 V62 C40 54 46 52 48 50 C46 48 40 46 40 38 Z" fill="{L}" {sw}/>'
                f'<path d="M44 63 H56 L50 56 Z" fill="{M}"/>'
                f'<path d="M36 32 H64 M36 68 H64" {sw} fill="none"/>')
    if name == 'clock':
        ticks = ''.join(
            f'<line x1="{50+14*math.cos(math.radians(a)):.1f}" y1="{50+14*math.sin(math.radians(a)):.1f}" x2="{50+16.5*math.cos(math.radians(a)):.1f}" y2="{50+16.5*math.sin(math.radians(a)):.1f}" stroke="{M}" stroke-width="2" stroke-linecap="round"/>'
            for a in (0, 90, 180, 270))
        return (f'<rect x="46" y="27" width="8" height="5" rx="2" fill="{D}" {sw}/>'
                f'<circle cx="50" cy="50" r="19" fill="{L}" {sw}/>{ticks}'
                f'<path d="M50 50 V39 M50 50 L58 55" {sw} fill="none"/><circle cx="50" cy="50" r="2.4" fill="{I}"/>')
    if name in ('flame', 'flame_crown'):
        body = (f'<path d="M50 29 C52 38 63 42 63 55 C63 63 57 69 50 69 C43 69 37 63 37 55 C37 48 42 45 44 40 C45 44 47 45 48 45 C47 40 48 34 50 29 Z" fill="{M}" {sw}/>'
                f'<path d="M50 47 C52 51 57 53 57 59 C57 63 54 65 50 65 C46 65 43 63 43 59 C43 55 48 53 50 47 Z" fill="{L}" stroke="{I}" stroke-width="1.6" stroke-linejoin="round"/>')
        if name == 'flame':
            return body
        return (f'<g transform="translate(0 7) translate(50 50) scale(.68) translate(-50 -50)">{body}</g>'
                f'<g transform="translate(50 25) scale(.74) translate(-50 -28)">{crown(c, 0)}</g>')
    if name == 'compass':
        return (f'<circle cx="50" cy="50" r="19" fill="{L}" {sw}/>'
                f'<path d="M50 35 L56 50 L44 50 Z" fill="{M}" stroke="{I}" stroke-width="2" stroke-linejoin="round"/>'
                f'<path d="M50 65 L56 50 L44 50 Z" fill="{D}" stroke="{I}" stroke-width="2" stroke-linejoin="round"/>'
                f'<circle cx="50" cy="50" r="2.4" fill="{I}"/>'
                f'<path d="M50 32 V35 M50 65 V68 M32 50 H35 M65 50 H68" stroke="{I}" stroke-width="2" stroke-linecap="round"/>')
    if name == 'bookmark':
        return (f'<path d="M39 31 H61 V69 L50 60 L39 69 Z" fill="{M}" {sw}/>'
                f'<path d="M44 37 V50" stroke="{L}" stroke-width="2.4" stroke-linecap="round"/>')
    if name == 'bookmarks':
        return (f'<path d="M47 31 H69 V67 L58 58 L47 67 Z" fill="{D}" {sw}/>'
                f'<path d="M31 35 H53 V71 L42 62 L31 71 Z" fill="{M}" {sw}/>'
                f'<path d="M36 41 V54" stroke="{L}" stroke-width="2.4" stroke-linecap="round"/>')
    if name == 'heart':
        return (f'<path d="M50 69 C28 53 33 33 45 35 C48 35.5 50 38 50 41 C50 38 52 35.5 55 35 C67 33 72 53 50 69 Z" fill="{M}" {sw}/>'
                f'<path d="M38 41 C36 44 37 48 40 51" stroke="{L}" stroke-width="2.6" fill="none" stroke-linecap="round"/>')
    if name == 'thumb':
        return (f'<rect x="31" y="48" width="10" height="21" rx="2.5" fill="{D}" {sw}/>'
                f'<path d="M44 48 L50 33 C55 33 57 38 55 45 H67 C70 45 71 48 70.5 50.5 L68 63 C67.5 66 65.5 69 62 69 H44 Z" fill="{M}" {sw}/>')
    if name == 'people':
        return (f'<circle cx="36" cy="42" r="5.5" fill="{D}" {sw}/><circle cx="64" cy="42" r="5.5" fill="{D}" {sw}/>'
                f'<path d="M26 66 C26 55 42 53 46 58 L46 66 Z M74 66 C74 55 58 53 54 58 L54 66 Z" fill="{D}" {sw}/>'
                f'<circle cx="50" cy="38" r="7" fill="{M}" {sw}/>'
                f'<path d="M37 69 C37 56 63 56 63 69 Z" fill="{L}" {sw}/>')
    if name == 'moon':
        return (f'<path d="M58 31 C45 33 38 44 41 55 C44 66 55 71 65 66 C53 64 48 52 52 42 C54 38 56 35 58 31 Z" fill="{M}" {sw}/>'
                + star(66, 40, 4.5, L, I) + star(72, 54, 3.2, L, I))
    if name == 'bolt':
        return (f'<path d="M55 29 L37 54 H48 L44 71 L64 44 H52 Z" fill="{M}" {sw}/>'
                f'<path d="M52 38 L45 49" stroke="{L}" stroke-width="2.4" stroke-linecap="round"/>')
    raise ValueError(name)


def sticker(tier, mot, stars, locked=False):
    c = PAL['locked' if locked else tier]
    n, R, r = {'bronze': (20, 47, 43), 'silver': (24, 47, 44), 'gold': (16, 48, 40), 'legend': (24, 48.5, 40)}[tier]
    body = burst(n, R, r)
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">',
           '<defs>',
           f'<linearGradient id="g" x1="0.15" y1="0" x2="0.85" y2="1"><stop offset="0" stop-color="{c["light"]}"/><stop offset="0.5" stop-color="{c["mid"]}"/><stop offset="1" stop-color="{c["dark"]}"/></linearGradient>',
           f'<radialGradient id="d" cx="0.38" cy="0.3" r="0.9"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="{c["light"]}"/></radialGradient>',
           '</defs>',
           f'<path d="{body}" fill="url(#g)" stroke="#FFFFFF" stroke-width="3.2" stroke-linejoin="round"/>',
           f'<circle cx="50" cy="50" r="36" fill="none" stroke="{c["light"]}" stroke-width="2" opacity=".9"/>',
           f'<circle cx="50" cy="50" r="33" fill="url(#d)" stroke="{c["dark"]}" stroke-width="1.6"/>']
    if tier in ('gold', 'legend'):
        out.append(f'<circle cx="50" cy="50" r="38.5" fill="none" stroke="{c["dark"]}" stroke-width="1.4" stroke-dasharray="1.6 3.4" stroke-linecap="round"/>')
    if tier == 'legend':
        for a in (0, 90, 180, 270):
            x, y = 50 + 44 * math.cos(math.radians(a - 90)), 50 + 44 * math.sin(math.radians(a - 90))
            out.append(f'<path d="M{x:.1f} {y-3:.1f} L{x+3:.1f} {y:.1f} L{x:.1f} {y+3:.1f} L{x-3:.1f} {y:.1f} Z" fill="#FFFFFF" stroke="{c["ink"]}" stroke-width="1"/>')
    # لمعة
    out.append('<path d="M21 40 A31 31 0 0 1 45 20" fill="none" stroke="#FFFFFF" stroke-opacity=".7" stroke-width="3" stroke-linecap="round"/>')
    out.append(f'<g opacity="{0.55 if locked else 1}">{motif(mot, c)}</g>')
    if stars:
        total = stars * 9
        x0 = 50 - total / 2 + 4.5
        for i in range(stars):
            out.append(star(x0 + i * 9, 76, 4.4, c['mid'] if locked else '#FFD23F', c['ink']))
    out.append('</svg>')
    return '\n'.join(out)


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    for sid, (tier, mot, stars) in STAMPS.items():
        for locked in (False, True):
            name = f'{sid}_locked.svg' if locked else f'{sid}.svg'
            with open(os.path.join(OUT, name), 'w', encoding='utf-8') as f:
                f.write(sticker(tier, mot, stars, locked))
    print('generated', len(STAMPS) * 2, 'files')
