import json
import pathlib
import re

root = pathlib.Path('.')
cfg = json.loads((root / 'build_config.json').read_text(encoding='utf-8'))
manifest = root / 'android/app/src/main/AndroidManifest.xml'
text = manifest.read_text(encoding='utf-8')

if 'android.permission.INTERNET' not in text:
    text = re.sub(
        r'(<manifest[^>]*>)',
        lambda m: m.group(1) + '\n    <uses-permission android:name="android.permission.INTERNET"/>',
        text,
        count=1,
    )
name = str(cfg.get('APP_NAME', 'Senok')).replace('&', '&amp;').replace('"', '&quot;')
text = re.sub(r'android:label="[^"]*"', f'android:label="{name}"', text, count=1)
# HTTP غير مشفّر (للتجربة المحلية فقط): فعّله بـ "ALLOW_HTTP": true في build_config.json وأطفئه في الإصدار النهائي
if cfg.get('ALLOW_HTTP') is True and 'usesCleartextTraffic' not in text:
    text = text.replace('<application', '<application android:usesCleartextTraffic="true"', 1)
manifest.write_text(text, encoding='utf-8')

# Optional release signing: only active when android/key.properties exists.
# Without key.properties the build keeps using the debug key (so CI still works).
gradle = root / 'android/app/build.gradle.kts'
if gradle.exists():
    source = gradle.read_text(encoding='utf-8')
    if 'sardSigningFile' not in source:
        # Kotlin imports must be at the very top of the file.
        if 'import java.util.Properties' not in source:
            source = 'import java.util.Properties\n' + source

        signing = '''
    val sardSigningFile = rootProject.file("key.properties")
    val sardSigningProps = Properties()
    if (sardSigningFile.exists()) {
        sardSigningFile.inputStream().use { sardSigningProps.load(it) }
        signingConfigs {
            create("release") {
                keyAlias = sardSigningProps.getProperty("keyAlias")
                keyPassword = sardSigningProps.getProperty("keyPassword")
                storeFile = file(sardSigningProps.getProperty("storeFile"))
                storePassword = sardSigningProps.getProperty("storePassword")
            }
        }
    }
'''
        # Put the signing block right after "android {" (works for any template layout).
        source, n = re.subn(r'(\nandroid\s*\{\n)', lambda m: m.group(1) + signing, source, count=1)

        debug_line = 'signingConfig = signingConfigs.getByName("debug")'
        release_line = (
            'signingConfig = if (sardSigningFile.exists()) '
            'signingConfigs.getByName("release") else signingConfigs.getByName("debug")'
        )
        if n == 1 and debug_line in source:
            source = source.replace(debug_line, release_line, 1)
        elif n == 1:
            # Template without the debug line: leave release signing untouched.
            pass
    # Lint can crash the release build (lintVitalAnalyzeRelease); the APK does not need it.
    if 'checkReleaseBuilds' not in source:
        lint = """
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
"""
        source = re.sub(r'(\nandroid\s*\{\n)', lambda m: m.group(1) + lint, source, count=1)
    gradle.write_text(source, encoding='utf-8')
print('Android manifest and optional release signing configuration patched:', name)
